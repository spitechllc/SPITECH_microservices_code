﻿using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Infrastructure.Repositories;
using System.Data;

namespace SpiTech.UserStoreManagement.Infrastructure.UnitOfWorks
{
    public sealed class UnitOfWork : BaseUnitOfWork, IUnitOfWork
    {
        public UnitOfWork(string connectionString,
                         System.IServiceProvider serviceProvider,
                        IsolationLevel isolationLevel = IsolationLevel.ReadCommitted)
                        : base(connectionString, serviceProvider, isolationLevel)
        {
        }

        private IUserRepository _users = null;
        private IPhoneRepository _phones = null;
        private IEmailRepository _emails = null;
        private IAddressRepository _addresses = null;
        private ICompanyRepository _companies = null;
        private IStoreRepository _stores = null;
        private ICategoryTypeRepository _categories = null;
        private IDesignationRepository _designations = null;
        private IRegionRepository _regions = null;
        private ITitleRepository _titles = null;
        private ICategoryTypeLevelRepository _categoryTypeLevels = null;
        private ICountryRepository _countries = null;
        private IStateRepository _states = null;
        private IStoreAmenityRepository _storeAmenities = null;
        private IStoreHoursRepository _storeHours = null;
        private IWeekDaysRepository _weekDays = null;
        private IAmenityRepository _amenities = null;
        private ICarWashTypeRepository _carWashTypes = null;
        private ITimeZoneRepository _timeZones = null;
        private IPosSystemRepository _posSystems = null;
        private ISaleAgentRepository _saleAgents = null;
        private IResellerRepository _resellers = null;
        private IStoreCategoryRepository _storeCategories = null;
        private IStoreGroupRepository _storeGroups = null;
        private IStoreGroupStoresRepository _storeGroupStores = null;
        private IStoreGroupUsersRepository _storeGroupUsers = null;

        public IUserRepository Users => _users ??= new UserRepository(this, serviceProvider);

        public IPhoneRepository Phones => _phones ??= new PhoneRepository(this, serviceProvider);
        public IEmailRepository Emails => _emails ??= new EmailRepository(this, serviceProvider);
        public IAddressRepository Addresses => _addresses ??= new AddressRepository(this, serviceProvider);
        public ICompanyRepository Companies => _companies ??= new CompanyRepository(this, serviceProvider);
        public IStoreRepository Stores => _stores ??= new StoreRepository(this, serviceProvider);
        public ICategoryTypeRepository Categories => _categories ??= new CategoryTypeRepository(this, serviceProvider);
        public IDesignationRepository Designations => _designations ??= new DesignationRepository(this, serviceProvider);
        public IRegionRepository Regions => _regions ??= new RegionRepository(this, serviceProvider);
        public ITitleRepository Titles => _titles ??= new TitleRepository(this, serviceProvider);
        public ICategoryTypeLevelRepository CategoryTypeLevels => _categoryTypeLevels ??= new CategoryTypeLevelRepository(this, serviceProvider);
        public ICountryRepository Countries => _countries ??= new CountryRepository(this, serviceProvider);
        public IStateRepository States => _states ??= new StateRepository(this, serviceProvider);
        public IStoreAmenityRepository StoreAmenities => _storeAmenities ??= new StoreAmenityRepository(this, serviceProvider);
        public IStoreHoursRepository StoreHours => _storeHours ??= new StoreHoursRepository(this, serviceProvider);
        public IWeekDaysRepository WeekDays => _weekDays ??= new WeekDaysRepository(this, serviceProvider);
        public IAmenityRepository Amenities => _amenities ??= new AmenityRepository(this, serviceProvider);
        public ICarWashTypeRepository CarWashTypes => _carWashTypes ??= new CarWashTypeRepository(this, serviceProvider);
        public ITimeZoneRepository TimeZones => _timeZones ??= new TimeZoneRepository(this, serviceProvider);

        public IPosSystemRepository PosSystems => _posSystems ??= new PosSystemRepository(this, serviceProvider);

        public ISaleAgentRepository SaleAgents => _saleAgents ??= new SaleAgentRepository(this, serviceProvider);

        public IResellerRepository Resellers => _resellers ??= new ResellerRepository(this, serviceProvider);

        public IStoreCategoryRepository StoreCategories => _storeCategories ??= new StoreCategoryRepository(this, serviceProvider);

        public IStoreGroupRepository StoreGroups => _storeGroups ??= new StoreGroupRepository(this, serviceProvider);
        public IStoreGroupStoresRepository StoreGroupStores => _storeGroupStores ??= new StoreGroupStoresRepository(this, serviceProvider);
        public IStoreGroupUsersRepository StoreGroupUsers => _storeGroupUsers ??= new StoreGroupUsersRepository(this, serviceProvider);

        public override void ResetRepositories()
        {
            _users = null;
            _phones = null;
            _emails = null;
            _addresses = null;
            _companies = null;
            _stores = null;
            _categories = null;
            _designations = null;
            _regions = null;
            _titles = null;
            _categoryTypeLevels = null;
            _countries = null;
            _states = null;
            _storeAmenities = null;
            _storeHours = null;
            _weekDays = null;
            _amenities = null;
            _carWashTypes = null;
            _timeZones = null;
            _posSystems=null;
            _saleAgents = null;
            _resellers = null;
            _storeCategories = null;
            _storeGroups = null;
            _storeGroupStores = null;
            _storeGroupUsers = null;
        }
    }
}
