﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class StoreCategoryRepository : Repository<StoreCategory>, IStoreCategoryRepository
    {
        public StoreCategoryRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<IEnumerable<StoreCategoryModel>> GetStoreCategoryById(int id)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from StoreCategory where IsActive=1");
            DynamicParameters para = new();
            if (id > 0)
            {
                sbquery.Append($" and Id=@Id");
                para.Add("Id", id);
            }

            return (await DbConnection.QueryAsync<StoreCategoryModel>(sbquery.ToString(), para, DbTransaction)).ToList();
        }

        public async Task<IEnumerable<StoreCategoryModel>> GetStoreCategory()
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from StoreCategory where IsActive=1");

            return (await DbConnection.QueryAsync<StoreCategoryModel>(sbquery.ToString(), null, DbTransaction)).ToList();
        }
    }
}
