﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Database;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class StoreHoursRepository : Repository<StoreHours>, IStoreHoursRepository
    {

        public StoreHoursRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<List<StoreHoursResult>> GetHoursByStoreId(int StoreId)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"select d.Name, h.OpenTime,h.CloseTime, h.Is24Hours FROM [StoreHours] h inner join [WeekDays] d on h.weekdayid = d.weekdayid where h.IsActive=1");
            DynamicParameters para = new();

            if (StoreId > 0)
            {
                sbquery.Append($" and h.StoreId=@StoreId ");
                para.Add("StoreId", StoreId);
            }

            sbquery.Append($" order by d.WeekDayId");

            return (await DbConnection.QueryAsync<StoreHoursResult>(sbquery.ToString(), para, DbTransaction)).ToList();
        }

        public async Task<List<StoreHours>> GetStoreHoursByStoreId(int StoreId)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from StoreHours where IsActive=1");

            DynamicParameters para = new();

            if (StoreId > 0)
            {
                sbquery.Append($" and StoreId=@StoreId");
                para.Add("StoreId", StoreId);
            }

            return (await DbConnection.QueryAsync<StoreHours>(sbquery.ToString(), para, DbTransaction)).ToList();
        }

        public async Task<StoreHours> GetStoreHoursByWeekId(int StoreId, int WeekId)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from StoreHours where IsActive=1");

            DynamicParameters para = new();
            if (StoreId > 0)
            {
                sbquery.Append($" and StoreId=@StoreId");
                para.Add("StoreId", StoreId);
            }
            if (WeekId > 0)
            {
                sbquery.Append($" and weekdayid=@WeekId");
                para.Add("WeekId", WeekId);
            }

            return (await DbConnection.QueryAsync<StoreHours>(sbquery.ToString(), para, DbTransaction)).FirstOrDefault();
        }

        public async Task<List<StoreHoursResultModel>> GetStoreHoursListByStoreIds(string[] storeIds)
        {
            StringBuilder sbquery = new();

            DynamicParameters para = new();
            sbquery.Append($"select d.Name, h.* FROM [StoreHours] h inner join [WeekDays] d on h.weekdayid = d.weekdayid where h.IsActive=1");

            if (storeIds != null && storeIds.Any())
            {
                sbquery.Append($" and h.StoreId  in (select KeyValue from @StoreIds)");
                para.Add("StoreIds", storeIds.GetTableValuedParameter("[dbo].[UdtStringKeys]", "KeyValue"));
            }

            sbquery.Append($" order by d.WeekDayId");

            return (await DbConnection.QueryAsync<StoreHoursResultModel>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
    }
}
