﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class UserRepository : Repository<User>, IUserRepository
    {
        public UserRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public List<User> Get(int entityId, EntityCategoryType entityCategoryType)
        {
            string entityColumn = entityCategoryType == EntityCategoryType.Company ? "CompanyId" : entityCategoryType == EntityCategoryType.Store ? "StoreId" : "UserId";

            DynamicParameters para = new();
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from Users where IsActive=1");

            if (entityId > 0)
            {
                para.Add("entityId", entityId);
                sbquery.Append($" and {entityColumn}=@entityId");
            }

            if (entityCategoryType == EntityCategoryType.Company)
            {
                sbquery.Append($" and isnull(StoreId,0)=0");
            }

            sbquery.Append($" order by UserId desc");

            return DbConnection.Query<User>(sbquery.ToString(), para, DbTransaction).ToList();
        }

        public async Task<List<UserModel>> GetUserWithPaging(string firstName, string lastName, string? roleId, int? storeId, string email,string phone, string storeName, int? pageIndex, int? pageSize, StoreUserSortBy? sortBy, SortOrderEnum? sortOrder,string statename, string city, string zipcode )
        {
            StringBuilder sbquery = new(); 
            DynamicParameters para = new();

            sbquery.Append($"Select count(1) over() as TotalRecord, U.* from Users U left Join (select EmailAddress,UserId, RANK () OVER (PARTITION BY UserId ORDER BY EmailId) RankNo from Email where UserId>0) E ON U.UserId=E.UserId  AND E.RankNo=1 left Join (select PhoneNumber,UserId, RANK () OVER (PARTITION BY UserId ORDER BY PhoneId) RankNo from Phone where UserId>0) P ON U.UserId=P.UserId AND P.RankNo=1 left Join (select Ad.UserId, Ad.City,Ad.CompanyId,Ad.ZipCode,Ad.StateId,St.StateName, RANK () OVER (PARTITION BY UserId ORDER BY AddressId) RankNo from Address Ad inner join State St on St.StateId=Ad.StateId  where UserId>0) A ON U.UserId=A.UserId left join Store S on U.StoreId=S.storeId where 1=1 ");

            if (!string.IsNullOrEmpty(firstName))
            {
                sbquery.Append($" and U.FirstName like @FirstName");
                para.Add("FirstName", $"%{firstName}%");
            }
            else if (!string.IsNullOrEmpty(lastName))
            {
                sbquery.Append($" and U.LastName like @LastName");
                para.Add("LastName", $"%{lastName}%");
            }
            //else if (roleId>0)
            //{
            //    sbquery.Append($" and U.FirstName like @FirstName");
            //    para.Add("FirstName", $"%{role}%");
            //}
            else if (storeId.HasValue)
            {
                sbquery.Append($" and U.StoreId = @storeId");
                para.Add("storeId", storeId);
            }
            else if(!string.IsNullOrEmpty(email))
            {
                sbquery.Append($" and E.EmailAddress like @EmailAddress ");
                para.Add("EmailAddress", $"%{email}%");
            }
            else if (!string.IsNullOrEmpty(phone))
            {
                sbquery.Append($" and P.PhoneNumber like @PhoneNumber ");
                para.Add("PhoneNumber", $"%{phone}%");
            }
            else if (!string.IsNullOrEmpty(storeName))
            {
                sbquery.Append($" and S.StoreName like @StoreName ");
                para.Add("StoreName", $"%{storeName}%");
            }
            if (!string.IsNullOrEmpty(statename))
            {
                sbquery.Append($" and A.StateName like @statename");
                para.Add("statename", $"%{statename}%");
            }
            if (!string.IsNullOrEmpty(city))
            {
                sbquery.Append($" and A.City like @city");
                para.Add("city", $"%{city}%");
            }
            if (!string.IsNullOrEmpty(zipcode))
            {
                sbquery.Append($" and A.ZipCode like @zipCode");
                para.Add("zipCode", $"%{zipcode}%");
            }

            if (sortBy != null && sortOrder != null && sortBy.Value != StoreUserSortBy.None && sortOrder.Value != SortOrderEnum.None)
            {
                if(sortBy.Value == StoreUserSortBy.EmailAddress)
                {
                    sbquery.Append($" Order by E.{sortBy} {sortOrder}");
                }
                else if (sortBy.Value == StoreUserSortBy.PhoneNumber)
                {
                    sbquery.Append($" Order by P.{sortBy} {sortOrder}");
                }
                else
                {
                    if (sortBy.Value != StoreUserSortBy.Role)
                    {
                        sbquery.Append($" Order by U.{sortBy} {sortOrder}");
                    }
                }
            }
            else
            {
                sbquery.Append($" Order by U.UserId desc");
            }

            if (pageIndex.HasValue && pageSize.HasValue)
            {
                int skiprow = (pageIndex.Value - 1) * pageSize.Value;

                sbquery.Append($" OFFSET {skiprow} rows fetch next {pageSize.Value} rows only");
            }

            return (await DbConnection.QueryAsync<UserModel>(sbquery.ToString(), para, DbTransaction)).ToList();
            //return data.GroupBy(t => t.UserId).Select(s => s.FirstOrDefault()).ToList();
        }

        public async Task<User> GetUser(int entityId, EntityCategoryType entityCategoryType)
        {
            string entityColumn = entityCategoryType == EntityCategoryType.Company ? "CompanyId" : entityCategoryType == EntityCategoryType.Store ? "StoreId" : "UserId";

            DynamicParameters para = new();
            StringBuilder sbquery = new();

            sbquery.Append($"Select * from Users where IsActive=1");

            if (entityId > 0)
            {
                para.Add("entityId", entityId);
                sbquery.Append($" and {entityColumn}=@entityId");
            }

            if (entityCategoryType == EntityCategoryType.Company)
            {
                sbquery.Append($" and isnull(StoreId,0)=0");
            }

            return (await DbConnection.QueryAsync<User>(sbquery.ToString(), para, DbTransaction)).FirstOrDefault();
        }

        public async Task<List<UserModel>> GetUserByIdsWithPaging(List<int> ids, EntityCategoryType entityCategoryType)
        {
            string entityColumn = entityCategoryType == EntityCategoryType.Company ? "CompanyId" : entityCategoryType == EntityCategoryType.Store ? "StoreId" : "UserId";

            StringBuilder sbquery = new();
            DynamicParameters para = new();

            sbquery.Append($"Select count(1) over() as TotalRecord,  * from Users where 1=1 ");

            if (ids.Count() > 0)
            {
                sbquery.Append($" and {entityColumn} in @Ids");
                para.Add("Ids", ids);
            }

            if (entityCategoryType == EntityCategoryType.Company)
            {
                sbquery.Append($" and isnull(StoreId,0)=0");
            }
            sbquery.Append($" order by UserId desc");

            return (await DbConnection.QueryAsync<UserModel>(sbquery.ToString(), para, DbTransaction)).ToList();
        }

        public async Task<List<UserModel>> GetOwnersWithPaging(string firstName, string lastName, string? roleId, int? storeId, string email, string phone, string storeName, int? pageIndex, int? pageSize, StoreUserSortBy? sortBy, SortOrderEnum? sortOrder, string statename, string city, string zipcode,int[] userIds)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();
            para.Add("UserIds", userIds);

            sbquery.Append($"Select count(1) over() as TotalRecord, U.* ,C.Id,C.Name from Users U left Join (select EmailAddress,UserId, RANK () OVER (PARTITION BY UserId ORDER BY EmailId) RankNo from Email where UserId>0) E ON U.UserId=E.UserId  AND E.RankNo=1 left Join (select PhoneNumber,UserId, RANK () OVER (PARTITION BY UserId ORDER BY PhoneId) RankNo from Phone where UserId>0) P ON U.UserId=P.UserId AND P.RankNo=1 left Join (select Ad.UserId, Ad.City,Ad.CompanyId,Ad.ZipCode,Ad.StateId,St.StateName, RANK () OVER (PARTITION BY UserId ORDER BY AddressId) RankNo from Address Ad inner join State St on St.StateId=Ad.StateId  where UserId>0) A ON U.UserId=A.UserId left join Store S on U.StoreId=S.storeId  left join Company C on C.Id=A.CompanyId where U.UserId in @UserIds ");

            if (!string.IsNullOrEmpty(firstName))
            {
                sbquery.Append($" and U.FirstName like @FirstName");
                para.Add("FirstName", $"%{firstName}%");
            }
            else if (!string.IsNullOrEmpty(lastName))
            {
                sbquery.Append($" and U.LastName like @LastName");
                para.Add("LastName", $"%{lastName}%");
            }
            //else if (roleId>0)
            //{
            //    sbquery.Append($" and U.FirstName like @FirstName");
            //    para.Add("FirstName", $"%{role}%");
            //}
            else if (storeId.HasValue)
            {
                sbquery.Append($" and U.StoreId = @storeId");
                para.Add("storeId", storeId);
            }
            else if (!string.IsNullOrEmpty(email))
            {
                sbquery.Append($" and E.EmailAddress like @EmailAddress ");
                para.Add("EmailAddress", $"%{email}%");
            }
            else if (!string.IsNullOrEmpty(phone))
            {
                sbquery.Append($" and P.PhoneNumber like @PhoneNumber ");
                para.Add("PhoneNumber", $"%{phone}%");
            }
            else if (!string.IsNullOrEmpty(storeName))
            {
                sbquery.Append($" and S.StoreName like @StoreName ");
                para.Add("StoreName", $"%{storeName}%");
            }
            if (!string.IsNullOrEmpty(statename))
            {
                sbquery.Append($" and A.StateName like @statename");
                para.Add("statename", $"%{statename}%");
            }
            if (!string.IsNullOrEmpty(city))
            {
                sbquery.Append($" and A.City like @city");
                para.Add("city", $"%{city}%");
            }
            if (!string.IsNullOrEmpty(zipcode))
            {
                sbquery.Append($" and A.ZipCode like @zipCode");
                para.Add("zipCode", $"%{zipcode}%");
            }

            if (sortBy != null && sortOrder != null && sortBy.Value != StoreUserSortBy.None && sortOrder.Value != SortOrderEnum.None)
            {
                if (sortBy.Value == StoreUserSortBy.EmailAddress)
                {
                    sbquery.Append($" Order by E.{sortBy} {sortOrder}");
                }
                else if (sortBy.Value == StoreUserSortBy.PhoneNumber)
                {
                    sbquery.Append($" Order by P.{sortBy} {sortOrder}");
                }
                else if (sortBy.Value == StoreUserSortBy.CompanyId)
                {
                    sbquery.Append($" Order by C.Id {sortOrder}");
                }
                else if (sortBy.Value == StoreUserSortBy.CompanyName)
                {
                    sbquery.Append($" Order by C.Name {sortOrder}");
                }
                else
                {
                    sbquery.Append($" Order by U.{sortBy} {sortOrder}");
                }
                    
                
            }
            else
            {
                sbquery.Append($" Order by U.UserId desc");
            }

            if (pageIndex.HasValue && pageSize.HasValue)
            {
                int skiprow = (pageIndex.Value - 1) * pageSize.Value;

                sbquery.Append($" OFFSET {skiprow} rows fetch next {pageSize.Value} rows only");
            }
            try
            {
                return (await DbConnection.QueryAsync<UserModel>(sbquery.ToString(), para, DbTransaction)).ToList();
            }
            catch(Exception ex)
            {
                throw;
            }

           
            //return data.GroupBy(t => t.UserId).Select(s => s.FirstOrDefault()).ToList();
        }
    }
}
