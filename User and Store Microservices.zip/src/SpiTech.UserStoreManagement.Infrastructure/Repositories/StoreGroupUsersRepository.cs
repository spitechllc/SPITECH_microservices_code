﻿using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class StoreGroupUsersRepository : Repository<StoreGroupUsers>, IStoreGroupUsersRepository
    {
        public StoreGroupUsersRepository(IBaseUnitOfWork dbContext, System.IServiceProvider serviceProvider) : base(dbContext, serviceProvider)
        {
        }

        public async Task<List<StoreGroupUsers>> GetByStoreGroupId(int StoreGroupId)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select  * from StoreGroupUsers where IsActive=1");
            DynamicParameters para = new();

            if (StoreGroupId > 0)
            {
                para.Add("StoreGroupId", StoreGroupId);
                sbquery.Append($" and StoreGroupId=@StoreGroupId");
            }
            sbquery.Append($" order by UserId desc");
            return (await DbConnection.QueryAsync<StoreGroupUsers>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
        public async Task<List<StoreGroupUsersModel>> GetById(int StoreGroupUsersId)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select  * from StoreGroupUsers where IsActive=1");
            DynamicParameters para = new();

            if (StoreGroupUsersId > 0)
            {
                para.Add("StoreGroupUsersId", StoreGroupUsersId);
                sbquery.Append($" and StoreGroupUsersId=@StoreGroupUsersId");
            }
            sbquery.Append($" order by UserId desc");
            return (await DbConnection.QueryAsync<StoreGroupUsersModel>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
        public async Task<List<StoreGroupUsersModel>> GetByUserId(int UserId)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select  SGU.*,SGS.StoreId,S.StoreName from StoreGroupUsers SGU inner join StoreGroupStores SGS on SGS.StoreGroupId=SGU.StoreGroupId inner join Store S on SGS.StoreId=S.StoreId where SGU.IsActive=1");
            DynamicParameters para = new();

            if (UserId > 0)
            {
                para.Add("UserId", UserId);
                sbquery.Append($" and UserId=@UserId");
            }
            sbquery.Append($" order by SGS.StoreId");
            return (await DbConnection.QueryAsync<StoreGroupUsersModel>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
    }
}
