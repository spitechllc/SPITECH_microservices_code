﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class CategoryTypeRepository : Repository<CategoryType>, ICategoryTypeRepository
    {
        public CategoryTypeRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<IEnumerable<CategoryType>> GetCategoryById(int id)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from CategoryType where IsActive=1");
            DynamicParameters para = new();
            if (id > 0)
            {
                sbquery.Append($" and id=@Id");
                para.Add("Id", id);
            }

            return (await DbConnection.QueryAsync<CategoryType>(sbquery.ToString(), para, DbTransaction)).ToList();
        }

        public async Task<IEnumerable<CategoryType>> GetCategory()
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from CategoryType where IsActive=1");

            return (await DbConnection.QueryAsync<CategoryType>(sbquery.ToString(), null, DbTransaction)).ToList();
        }
    }
}
