﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class CategoryTypeLevelRepository : Repository<CategoryTypeLevel>, ICategoryTypeLevelRepository
    {
        public CategoryTypeLevelRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<IEnumerable<CategoryTypeLevel>> GetCategoryTypeLevel(string categorytype)
        {
            int categorytypeid = (int)Enum.Parse(typeof(EntityCategoryTypeLevel), categorytype);

            StringBuilder sbquery = new();
            sbquery.Append($"Select * from CategoryTypeLevel where IsActive=1");
            DynamicParameters para = new();

            if (categorytypeid > 0)
            {
                sbquery.Append($" and CategoryTypeId=@categorytypeid");
                para.Add("categorytypeid", categorytypeid);
            }

            return (await DbConnection.QueryAsync<CategoryTypeLevel>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
    }
}
