﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class RegionRepository : Repository<Region>, IRegionRepository
    {
        public RegionRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
        public async Task<IEnumerable<Region>> GetRegionById(int Id)
        {
            DynamicParameters para = new();
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from Region where IsActive=1");

            if (Id > 0)
            {
                para.Add("Id", Id);
                sbquery.Append($" and RegionId=@Id");
            }
            return (await DbConnection.QueryAsync<Region>(sbquery.ToString(), para, DbTransaction)).ToList();
        }

        public async Task<IEnumerable<Region>> GetRegion()
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from Region where IsActive=1");

            return (await DbConnection.QueryAsync<Region>(sbquery.ToString(), null, DbTransaction)).ToList();
        }
    }
}
