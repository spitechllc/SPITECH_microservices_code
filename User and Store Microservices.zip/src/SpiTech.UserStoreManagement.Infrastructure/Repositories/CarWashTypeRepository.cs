﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Database;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class CarWashTypeRepository : Repository<CarWashType>, ICarWashTypeRepository
    {
        public CarWashTypeRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<List<CarWashTypeModel>> GetByStoreId(int storeId)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"select * from CarWashType where IsActive=1");
            DynamicParameters para = new();

            if (storeId > 0)
            {
                sbquery.Append($" and StoreId =@StoreId");
                para.Add("StoreId", storeId);
            }

            return (await DbConnection.QueryAsync<CarWashTypeModel>(sbquery.ToString(), para, DbTransaction)).ToList();
        }

        public async Task<List<CarWashTypeModel>> GetListByStoreIds(string[] storeIds)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"select * from CarWashType where IsActive=1");
            DynamicParameters para = new();

            if (storeIds.Count() > 0)
            {
                sbquery.Append($" and StoreId in (select KeyValue from @StoreIds)");
                para.Add("StoreIds", storeIds.GetTableValuedParameter("[dbo].[UdtStringKeys]", "KeyValue"));
            }

            return (await DbConnection.QueryAsync<CarWashTypeModel>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
    }
}
