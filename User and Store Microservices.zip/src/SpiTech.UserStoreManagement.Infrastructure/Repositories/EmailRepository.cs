﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Database;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class EmailRepository : Repository<Email>, IEmailRepository
    {
        public EmailRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public List<Email> Get(int entityId, EntityCategoryType entityCategoryType)
        {
            string entityColumn = entityCategoryType == EntityCategoryType.Company ? "CompanyId" : entityCategoryType == EntityCategoryType.Store ? "StoreId" : entityCategoryType == EntityCategoryType.User ? "UserId" : entityCategoryType == EntityCategoryType.SaleAgent ? "SaleAgentId" : "ResellerId"; 
            DynamicParameters para = new();
            StringBuilder sbquery = new();

            sbquery.Append($"Select * from Email where IsActive=1");

            if (entityId > 0)
            {
                sbquery.Append($" and {entityColumn}=@entityId");
                para.Add("entityId", entityId);
            }

            if (entityCategoryType == EntityCategoryType.Company)
            {
                sbquery.Append($" and isnull(StoreId,0)=0");

            }

            return DbConnection.Query<Email>(sbquery.ToString(), para, DbTransaction).ToList();
        }

        public List<Email> GetEmailList(string[] entityIds, EntityCategoryType entityCategoryType)
        {
            string entityColumn = entityCategoryType == EntityCategoryType.Company ? "CompanyId" : entityCategoryType == EntityCategoryType.Store ? "StoreId" : entityCategoryType == EntityCategoryType.User ? "UserId":entityCategoryType==EntityCategoryType.SaleAgent ? "SaleAgentId":"ResellerId";

            StringBuilder sbquery = new();
            sbquery.Append($"Select * from Email where IsActive=1");
            DynamicParameters para = new();

            if (entityIds != null && entityIds.Any())
            {
                sbquery.Append($" and {entityColumn} in (select KeyValue from @entityIds)");
                para.Add("entityIds", entityIds.GetTableValuedParameter("[dbo].[UdtStringKeys]", "KeyValue"));
                
            }
            else
            {
                sbquery.Append($" and {entityColumn} is not null and {entityColumn} > 0");
            }

            if (entityCategoryType == EntityCategoryType.Company)
            {
                sbquery.Append($" and isnull(StoreId,0)=0");
            }
           
                return DbConnection.Query<Email>(sbquery.ToString(), para, DbTransaction).ToList();            
            
        }
        public async Task<Email> GetPrimaryEmail(int entityId, EntityCategoryType entityCategoryType)
        {
            string entityColumn = entityCategoryType == EntityCategoryType.Company ? "CompanyId" : entityCategoryType == EntityCategoryType.Store ? "StoreId" : entityCategoryType == EntityCategoryType.User ? "UserId" : entityCategoryType == EntityCategoryType.SaleAgent ? "SaleAgentId" : "ResellerId"; 

            StringBuilder sbquery = new();
            sbquery.Append("Select e.* from Email e inner join [CategoryTypeLevel] L on L.Id =e.CategoryTypeLevelId  and L.IsPrimary = 1 and e.IsActive=1");

            DynamicParameters para = new();

            if (entityId > 0)
            {
                sbquery.Append($" and {entityColumn}=@entityId ");
                para.Add("entityId", entityId);
            }

            if (entityCategoryType == EntityCategoryType.Company)
            {
                sbquery.Append($" and isnull(StoreId,0)=0");
            }

            return (await DbConnection.QueryAsync<Email>(sbquery.ToString(), para, DbTransaction)).FirstOrDefault();
        }

        public List<int> GetUserIdByEmail(string email)
        {
            DynamicParameters para = new();

            StringBuilder sbquery = new();
            sbquery.Append($"Select UserId from Email where IsActive=1");

            if (!string.IsNullOrEmpty(email))
            {
                sbquery.Append($" and EmailAddress =@EmailAddress and isnull(UserId,'')<>'' ");
                para.Add("EmailAddress", email);
            }

            return DbConnection.Query<int>(sbquery.ToString(), para, DbTransaction).ToList();
        }
        public async Task<Email> GetDuplicateEmail(int entityId, EntityCategoryType entityCategoryType,string email)
        {
            string entityColumn = entityCategoryType == EntityCategoryType.Company ? "CompanyId" : entityCategoryType == EntityCategoryType.Store ? "StoreId" : entityCategoryType == EntityCategoryType.User ? "UserId" : entityCategoryType == EntityCategoryType.SaleAgent ? "SaleAgentId" : "ResellerId";
            DynamicParameters para = new();
            StringBuilder sbquery = new();

            para.Add("Email", email);

            sbquery.Append($"Select * from Email where IsActive=1 and Email=@Email");
           
            if (entityId > 0)
            {
                sbquery.Append($" and {entityColumn}!=@entityId");
                para.Add("entityId", entityId);
            }
            else
            {
                sbquery.Append($" and {entityColumn} is not null or {entityColumn} !=''");
            }

            if (entityCategoryType == EntityCategoryType.Company)
            {
                sbquery.Append($" and isnull(StoreId,0)=0");

            }
            return (await DbConnection.QueryAsync<Email>(sbquery.ToString(), para, DbTransaction)).FirstOrDefault();
        }
    }
}
