﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class SaleAgentRepository : Repository<SaleAgent>, ISaleAgentRepository
    {
        public SaleAgentRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<List<SaleAgentModel>> GetSaleAgentByFilters(string name, string mobile, string email, string storeName, int? skip, int? take, SaleAgentSortBy? sortBy, SortOrderEnum? sortOrder)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();

            sbquery.Append($"select SA.*, count(SA.SaleAgentId) over() as TotalRecord From SaleAgent SA Left join (select EmailAddress,saleAgentId, RANK () OVER (PARTITION BY saleAgentId ORDER BY EmailId) RankNo from Email where saleAgentId>0 ) E  on SA.SaleAgentId = E.SaleAgentId AND E.RankNo=1 Left join (select PhoneNumber,saleAgentId, RANK () OVER (PARTITION BY saleAgentId ORDER BY PhoneId) RankNo from Phone where saleAgentId>0 ) P  on SA.SaleAgentId = P.SaleAgentId AND P.RankNo=1  Where SA.IsActive = 1 ");//Left join[Store] S  on SA.SaleAgentId = S.SaleAgentId 

            if (!string.IsNullOrWhiteSpace(name))
            {
                sbquery.Append($" and SA.FirstName +' '+SA.LastName like @Name");
                para.Add("Name", $"%{name}%");
            }
            if (!string.IsNullOrWhiteSpace(mobile))
            {
                sbquery.Append($" and SA.SaleAgentId in (Select SaleAgentId from Phone where PhoneNumber = @Mobile)");
                para.Add("Mobile", mobile);
            }
            if (!string.IsNullOrWhiteSpace(email))
            {
                sbquery.Append($" and SA.SaleAgentId in (Select SaleAgentId from Email where EmailAddress = @Email)");
                para.Add("Email", email);
            }
            if (!string.IsNullOrWhiteSpace(storeName))
            {
                sbquery.Append($" and SA.SaleAgentId in (Select SaleAgentId from Store where StoreName like @StoreName) ");
                para.Add("StoreName", $"%{storeName}%");
            }

            if (sortBy != null && sortOrder != null && sortBy.Value != SaleAgentSortBy.None && sortOrder.Value != SortOrderEnum.None)
            {
                if (sortBy.Value == SaleAgentSortBy.EmailAddress)
                    sbquery.Append($" Order by E.{sortBy} {sortOrder}");
                else if (sortBy.Value == SaleAgentSortBy.PhoneNumber)
                    sbquery.Append($" Order by P.{sortBy} {sortOrder}");
                else
                    sbquery.Append($" Order by SA.{sortBy} {sortOrder}");
            }
            else
            {
                sbquery.Append($" Order by SA.SaleAgentId desc ");
            }

            if (skip.HasValue && take.HasValue)
            {
                int skiprow = (skip.Value - 1) * take.Value;
                sbquery.Append($" OFFSET {skiprow} rows fetch next {take.Value} rows only");
            }

            return (await DbConnection.QueryAsync<SaleAgentModel>(sbquery.ToString(), para, DbTransaction)).ToList();

            //return result.GroupBy(t => t.SaleAgentId).Select(t => t.FirstOrDefault()).Where(t => t != null).ToList();
        }

        public async Task<List<SaleAgentModel>> GetSaleAgents(int[] saleAgentIds)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();
            para.Add("saleAgentIds", saleAgentIds);

            sbquery.Append($"select * From SaleAgent Where IsActive = 1 and saleAgentId in @saleAgentIds");

            return (await DbConnection.QueryAsync<SaleAgentModel>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
    }
}
