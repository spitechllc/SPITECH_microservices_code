﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class DesignationRepository : Repository<Designation>, IDesignationRepository
    {
        public DesignationRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
        public async Task<IEnumerable<Designation>> GetDesignationById(int Id)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();

            sbquery.Append($"Select * from Designation where IsActive=1");
            if (Id > 0)
            {
                sbquery.Append($" and DesignationId=@Id");
                para.Add("Id", Id);

            }
            return (await DbConnection.QueryAsync<Designation>(sbquery.ToString(), para, DbTransaction)).ToList();
        }

        public async Task<IEnumerable<Designation>> GetDesignation()
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from Designation where IsActive=1");

            return (await DbConnection.QueryAsync<Designation>(sbquery.ToString(), null, DbTransaction)).ToList();
        }
    }
}
