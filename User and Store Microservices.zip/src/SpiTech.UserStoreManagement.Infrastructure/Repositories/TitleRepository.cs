﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class TitleRepository : Repository<Title>, ITitleRepository
    {
        public TitleRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<IEnumerable<Title>> GetTitleById(int Id)
        {
            DynamicParameters para = new();
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from Title where IsActive=1");

            if (Id > 0)
            {
                para.Add("TitleId", Id);
                sbquery.Append($" and TitleId=@TitleId");
            }

            return (await DbConnection.QueryAsync<Title>(sbquery.ToString(), para, DbTransaction)).ToList();
        }

        public async Task<IEnumerable<Title>> GetTitle()
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from Title where IsActive=1");

            return (await DbConnection.QueryAsync<Title>(sbquery.ToString(), null, DbTransaction)).ToList();
        }
    }
}
