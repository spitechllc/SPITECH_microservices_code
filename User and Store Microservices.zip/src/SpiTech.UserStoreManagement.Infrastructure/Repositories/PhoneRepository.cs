﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Database;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class PhoneRepository : Repository<Phone>, IPhoneRepository
    {
        public PhoneRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public List<Phone> Get(int entityId, EntityCategoryType entityCategoryType)
        {
            string entityColumn = entityCategoryType == EntityCategoryType.Company ? "CompanyId" : entityCategoryType == EntityCategoryType.Store ? "StoreId" : entityCategoryType == EntityCategoryType.User ? "UserId" : entityCategoryType == EntityCategoryType.SaleAgent ? "SaleAgentId" : "ResellerId"; ;

            DynamicParameters para = new();
            StringBuilder sbquery = new();

            sbquery.Append($"Select * from Phone where IsActive=1");

            if (entityId > 0)
            {
                sbquery.Append($" and {entityColumn}=@entityId");
                para.Add("entityId", entityId);
            }

            if (entityCategoryType == EntityCategoryType.Company)
            {
                sbquery.Append($" and isnull(StoreId,0)=0");
            }

            return DbConnection.Query<Phone>(sbquery.ToString(), para, DbTransaction).ToList();
        }

        public List<Phone> GetPhoneList(string[] entityIds, EntityCategoryType entityCategoryType)
        {
            string entityColumn = entityCategoryType == EntityCategoryType.Company ? "CompanyId" : entityCategoryType == EntityCategoryType.Store ? "StoreId" : entityCategoryType == EntityCategoryType.User ? "UserId" : entityCategoryType == EntityCategoryType.SaleAgent ? "SaleAgentId" : "ResellerId"; ;

            DynamicParameters para = new();
            StringBuilder sbquery = new();

            sbquery.Append($"Select * from Phone where IsActive=1");

            if (entityIds != null && entityIds.Any())
            {
                sbquery.Append($" and {entityColumn} in (select KeyValue from @entityIds)");
                para.Add("entityIds", entityIds.GetTableValuedParameter("[dbo].[UdtStringKeys]", "KeyValue"));

            }
            else
            {
                sbquery.Append($" and {entityColumn} is not null and {entityColumn} > 0");
            }

            if (entityCategoryType == EntityCategoryType.Company)
            {
                sbquery.Append($" and isnull(StoreId,0)=0");
            }

            return DbConnection.Query<Phone>(sbquery.ToString(), para, DbTransaction).ToList();
        }

        public async Task<Phone> GetPrimaryPhone(int entityId, EntityCategoryType entityCategoryType)
        {
            string entityColumn = entityCategoryType == EntityCategoryType.Company ? "CompanyId" : entityCategoryType == EntityCategoryType.Store ? "StoreId" : entityCategoryType == EntityCategoryType.User ? "UserId" : entityCategoryType == EntityCategoryType.SaleAgent ? "SaleAgentId" : "ResellerId"; ;

            DynamicParameters para = new();
            StringBuilder sbquery = new();

            sbquery.Append("Select p.* from Phone p inner join [CategoryTypeLevel] L on L.Id =p.CategoryTypeLevelId  and L.IsPrimary = 1 and p.IsActive=1");

            if (entityId > 0)
            {
                sbquery.Append($" and {entityColumn}=@entityId ");
                para.Add("entityId", entityId);
            }

            if (entityCategoryType == EntityCategoryType.Company)
            {
                sbquery.Append($" and isnull(StoreId,0)=0");
            }

            return (await DbConnection.QueryAsync<Phone>(sbquery.ToString(), para, DbTransaction)).FirstOrDefault();
        }

        public List<int> GetUserIdByPhone(string phone)
        {
            DynamicParameters para = new();
            StringBuilder sbquery = new();

            sbquery.Append($"Select UserId from Phone where IsActive=1");

            if (!string.IsNullOrEmpty(phone))
            {
                para.Add("PhoneNumber", phone);
                sbquery.Append($" and PhoneNumber = @PhoneNumber and isnull(UserId,'')<>''");
            }

            return DbConnection.Query<int>(sbquery.ToString(), para, DbTransaction).ToList();
        }
    }
}
