﻿using AutoMapper;
using Dapper;
using Dapper.Contrib.Extensions;
using DapperExtensions;
using SpiTech.ApplicationCore.Database;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.FilterOptions;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class StoreRepository : Repository<Store>, IStoreRepository
    {
        public StoreRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
        public async Task<List<StoreSearchResult>> GetByCompanyId(int companyId)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select s.*,c.Name as Company,sc.Name as StoreCategory from Store s inner join company c on s.companyid=c.id left join storecategory sc on s.StoreCategoryId=sc.Id where 1=1");
            DynamicParameters para = new();

            if (companyId > 0)
            {
                sbquery.Append($" and CompanyId=@companyId");
                para.Add("companyId", companyId);
            }
            sbquery.Append($" order by s.StoreId desc");
            return (await DbConnection.QueryAsync<StoreSearchResult>(sbquery.ToString(), para, DbTransaction)).ToList();
        }

        public async Task<IEnumerable<StoreSearchResult>> GetStoreByFilter(StoreFilter filter, int? PageIndex, int? PageSize, Sortable sortable)
        {
            try
            {
                int skiprow = 0;
                if (PageIndex.HasValue && PageSize.HasValue)
                {
                    skiprow = (PageIndex.Value - 1) * PageSize.Value;

                }
                IEnumerable<StoreSearchResult> list = await DbConnection.QueryAsync<StoreSearchResult>("GetStore", new
                {
                    Latitude = filter.Latitude,
                    Longitude = filter.Longitude,
                    Distance = filter.Distance,
                    City = filter.City,
                    StateId = filter.StateId,
                    CountryId = filter.CountryId,
                    Zipcode = filter.ZipCode,
                    SkipRow = skiprow,
                    PageSize = PageSize ?? 0,
                    AmenitiesId = filter.AmenitiesId == null ? "" : string.Join(",", filter.AmenitiesId)
                }, DbTransaction, null, CommandType.StoredProcedure);

                return await Task.FromResult(list);
            }
            catch (Exception ex) { return null; };
        }

        public async Task<int> UpdateLogo(string url, int Storeid)
        {
            return await DbConnection.ExecuteAsync($"Update Store set StoreImage='{url}' where Storeid={Storeid}", null, DbTransaction);
        }



        public async Task<List<StoreInfoModel>> GetStoreInfo(int[] storeIds)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();

            sbquery.Append($"Select S.*, T.TimeZoneName, SA.FirstName+' '+SA.LastName AS SaleAgentName, SA.IsActive IsSaleAgentActive, R.FirstName+' '+R.LastName AS ResellerName, R.IsActive IsResellerActive, R.CompanyName ResellerCompanyName  from Store S Left Join TimeZone T On S.TimeZoneId = T.TimeZoneId Left Join SaleAgent SA On S.SaleAgentId = SA.SaleAgentId Left Join Reseller R On S.ResellerId = R.ResellerId where 1=1");
            sbquery.Append($" and StoreId in @storeIds");
            para.Add("storeIds", storeIds);

            return (await DbConnection.QueryAsync<StoreInfoModel>(sbquery.ToString(), para, DbTransaction)).ToList();
        }

        public async Task<StoreInfoModel> GetMasterStoreInfo()
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();

            sbquery.Append($"Select S.*, T.TimeZoneName, SA.FirstName+' '+SA.LastName AS SaleAgentName, SA.IsActive IsSaleAgentActive, R.FirstName+' '+R.LastName AS ResellerName, R.IsActive IsResellerActive, R.CompanyName ResellerCompanyName  from Store S Left Join TimeZone T On S.TimeZoneId = T.TimeZoneId Left Join SaleAgent SA On S.SaleAgentId = SA.SaleAgentId Left Join Reseller R On S.ResellerId = R.ResellerId where IsMasterStore = 1");

            return await DbConnection.QueryFirstOrDefaultAsync<StoreInfoModel>(sbquery.ToString(), para, DbTransaction);
        }


        public async Task<StoreInfoModel> GetStoreInfo(int? storeId, string siteId)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();

            sbquery.Append($"Select S.*, T.TimeZoneName, SA.FirstName+' '+SA.LastName AS SaleAgentName, SA.IsActive IsSaleAgentActive, R.FirstName+' '+R.LastName AS ResellerName, R.IsActive IsResellerActive, R.CompanyName ResellerCompanyName  from Store S Left Join TimeZone T On S.TimeZoneId = T.TimeZoneId Left Join SaleAgent SA On S.SaleAgentId = SA.SaleAgentId Left Join Reseller R On S.ResellerId = R.ResellerId where 1=1");

            if (storeId.HasValue && storeId.Value > 0)
            {
                sbquery.Append($" and StoreId =@StoreId");
                para.Add("StoreId", storeId.Value);
            }
            else
            {
                sbquery.Append($" and SiteId=@siteId");
                para.Add("siteId", siteId);
            }

            return (await DbConnection.QueryAsync<StoreInfoModel>(sbquery.ToString(), para, DbTransaction)).FirstOrDefault();
        }

        public async Task<Store> GetStore(string siteId, int? storeId)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();

            sbquery.Append($"Select * from Store S where S.IsActive=1");

            if (storeId.HasValue && storeId.Value > 0)
            {
                sbquery.Append($" and StoreId =@StoreId");
                para.Add("StoreId", storeId.Value);
            }
            else
            {
                sbquery.Append($" and SiteId=@siteId");
                para.Add("siteId", siteId);
            }

            return (await DbConnection.QueryAsync<Store>(sbquery.ToString(), para, DbTransaction)).FirstOrDefault();
        }

        public async Task<List<Store>> GetStoreAutoComplete(string siteId, string StoreName, int StoreId)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from Store S where S.IsActive=1");
            DynamicParameters para = new();

            if (!string.IsNullOrEmpty(StoreName) && StoreName.ToLower() != "null")
            {
                sbquery.Append($" and StoreName like @StoreName");
                para.Add("StoreName", $"%{StoreName}%");
            }
            else if (!string.IsNullOrWhiteSpace(siteId))
            {
                sbquery.Append($" and SiteId like @siteId");
                para.Add("siteId", $"%{siteId}%");
            }
            else if (StoreId > 0)
            {
                sbquery.Append($" and StoreId like @StoreId");
                para.Add("StoreId", $"%{StoreId}%");
            }
            sbquery.Append($" order by S.StoreId desc");
            return (await DbConnection.QueryAsync<Store>(sbquery.ToString(), para, DbTransaction)).ToList();
        }

        public async Task<Store> ValidateSiteId(string SiteId, int? StoreId)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from Store S where S.IsActive=1");

            DynamicParameters para = new();

            if (!string.IsNullOrEmpty(SiteId))
            {
                sbquery.Append($" and SiteId=@SiteId");
                para.Add("SiteId", SiteId);
            }

            if (StoreId > 0)
            {
                sbquery.Append($" and StoreId!=@StoreId");
                para.Add("StoreId", StoreId);
            }

            return (await DbConnection.QueryAsync<Store>(sbquery.ToString(), para, DbTransaction)).FirstOrDefault();
        }

        public async Task<List<StoresSearchModel>> GetStoreWithPaging(int storeId, string storename, string siteId, string companyName, int? pageIndex, int? pageSize, string[] includeSiteIds, string[] excludeSiteIds, StoreSortBy? sortBy, SortOrderEnum? sortOrder, string statename, string city, string zipcode)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();

            sbquery.Append($"Select count(1) over() as TotalRecord,s.*,c.Name as Company, m.FirstName+ ' '+m.LastName MangerName, rm.FirstName+ ' '+rm.LastName  RegionalManagerName, SA.FirstName+ ' '+SA.LastName SaleAgentName,RS.FirstName+ ' '+RS.LastName ResellerName,RS.CompanyName as ResellerCompanyName,sc.Name as StoreCategory from Store s inner join company c on s.companyid=c.id Left Join  Users m on s.[MangerId] = m.UserId  Left Join  Users rm on s.[RegionalManagerId] = rm.UserId  Left join  SaleAgent SA on s.SaleAgentId = SA.SaleAgentId left join Reseller RS on s.ResellerId=RS.ResellerId left Join (select Ad.StoreId, Ad.City,Ad.CompanyId,Ad.ZipCode,Ad.StateId,St.StateName, RANK () OVER (PARTITION BY StoreId ORDER BY AddressId) RankNo from Address Ad inner join State St on St.StateId=Ad.StateId and Ad.IsActive=1  where StoreId>0) A ON S.StoreId=A.StoreId left join StoreCategory sc on s.StoreCategoryId=sc.Id where 1=1 ");

            if (!string.IsNullOrEmpty(storename))
            {
                sbquery.Append($" and s.StoreName like @StoreName");
                para.Add("StoreName", $"%{storename}%");
            }

            if (!string.IsNullOrWhiteSpace(siteId))
            {
                sbquery.Append($" and s.SiteId like @SiteId");
                para.Add("SiteId", siteId);
            }

            if (!string.IsNullOrEmpty(companyName))
            {
                sbquery.Append($" and c.Name like @CompanyName");
                para.Add("CompanyName", $"%{companyName}%");
            }

            if (storeId > 0)
            {
                sbquery.Append($" and s.StoreId = @StoreId");
                para.Add("StoreId", storeId);
            }

            if (includeSiteIds != null)
            {
                sbquery.Append($" and s.SiteId in (select KeyValue from @includeSiteIds)");
                para.Add("includeSiteIds", includeSiteIds.GetTableValuedParameter("[dbo].[UdtStringKeys]", "KeyValue"));
            }

            if (excludeSiteIds != null)
            {
                sbquery.Append($" and s.SiteId not in (select KeyValue from @excludeSiteIds)");
                para.Add("excludeSiteIds", excludeSiteIds.GetTableValuedParameter("[dbo].[UdtStringKeys]", "KeyValue"));
            }
            if (!string.IsNullOrEmpty(statename))
            {
                sbquery.Append($" and A.StateName like @statename");
                para.Add("statename", $"%{statename}%");
            }
            if (!string.IsNullOrEmpty(city))
            {
                sbquery.Append($" and A.City like @city");
                para.Add("city", $"%{city}%");
            }
            if (!string.IsNullOrEmpty(zipcode))
            {
                sbquery.Append($" and A.ZipCode like @zipCode");
                para.Add("zipCode", $"%{zipcode}%");
            }

            if (sortBy != null && sortOrder != null && sortBy.Value != StoreSortBy.None && sortOrder.Value != SortOrderEnum.None)
            {
                if (sortBy.Value == StoreSortBy.CompanyName)
                {
                    sbquery.Append($" Order by c.Name {sortOrder} ");
                }
                else
                {
                    if (sortBy.Value != StoreSortBy.LastTransactionDate && sortBy.Value != StoreSortBy.LastHeartBeatTime)
                    {
                        sbquery.Append($" Order by s.{sortBy} {sortOrder} ");
                    }
                    else
                    {
                        sbquery.Append($" Order by s.StoreId desc");
                    }
                }
            }
            else
            {
                sbquery.Append($" Order by s.StoreId desc");
            }

            if (pageIndex.HasValue && pageSize.HasValue)
            {
                int skiprow = (pageIndex.Value - 1) * pageSize.Value;

                sbquery.Append($" OFFSET {skiprow} rows fetch next {pageSize.Value} rows only");
            }

            return (await DbConnection.QueryAsync<StoresSearchModel>(sbquery.ToString(), para, DbTransaction)).ToList();
        }

        public async Task<List<Store>> GetStoreBySiteIds(string[] siteIds)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from Store S where S.IsActive=1");
            DynamicParameters para = new();

            if (siteIds != null && siteIds.Any())
            {
                sbquery.Append($" and SiteId in @siteIds");
                para.Add("siteIds", siteIds);
            }
            sbquery.Append($" order by S.StoreId desc");
            return (await DbConnection.QueryAsync<Store>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
        public async Task<List<StoreModelForSummary>> GetStoreSummaryById(int StoreId, int? PageIndex, int? PageSize, string SortBy, string SortOrder)
        {
            StringBuilder sbquery = new();
            sbquery.Append($" Select  S.StoreId, S.MaxAuthorizeAmount, S.StoreName, ISNULL(S.ConsentCashReward,0) As ConsentCashReward, S.DisableEod, S.DisableBilling, S.EnableACHLoyalty, S.EnableCardLoyalty, S.LoyaltyProgramId, A.AddressLine1 , A.AddressLine2 , A.Longitude , A.Latitude , A.ZipCode  from Store S Left join [Address] A on S.StoreId=A.StoreId and A.IsActive=1 where S.IsActive=1");
            DynamicParameters para = new();

            if (StoreId > 0)
            {
                sbquery.Append($" and S.StoreId=StoreId");
                para.Add("StoreId", StoreId);
            }
            if (!string.IsNullOrEmpty(SortBy) && !string.IsNullOrEmpty(SortOrder))
            {
                sbquery.Append($" Order by S.{SortBy} {SortOrder}");
            }
            else
            {
                sbquery.Append($" Order by S.StoreId desc");
            }

            if (PageIndex.HasValue && PageSize.HasValue)
            {
                int skiprow = (PageIndex.Value - 1) * PageSize.Value;

                sbquery.Append($" OFFSET {skiprow} rows fetch next {PageSize.Value} rows only");
            }


            return (await DbConnection.QueryAsync<StoreModelForSummary>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
        public async Task<List<StoreSaleAgentModel>> GetBySaleAgentId(int saleAgentId)
        {
            StringBuilder sbquery = new StringBuilder();
            DynamicParameters dynamicParams = new DynamicParameters();

            sbquery.Append($"Select * from Store where 1=1");

            if (saleAgentId > 0)
            {
                dynamicParams.Add("SaleAgentId", saleAgentId);
                sbquery.Append($" and SaleAgentId=@SaleAgentId");
            }
            sbquery.Append($" order by StoreId desc");
            return (await this.DbConnection.QueryAsync<StoreSaleAgentModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }

        public async Task<List<StoreSaleAgentModel>> GetBySaleAgentIds(int[] saleAgentIds)
        {
            StringBuilder sbquery = new StringBuilder();
            DynamicParameters dynamicParams = new DynamicParameters();

            sbquery.Append($"Select * from Store where 1=1");

            if (saleAgentIds != null && saleAgentIds.Any())
            {
                dynamicParams.Add("saleAgentIds", saleAgentIds);
                sbquery.Append($" and SaleAgentId in @saleAgentIds");
            }
            sbquery.Append($" order by StoreId desc");
            return (await this.DbConnection.QueryAsync<StoreSaleAgentModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }

        public async Task<IEnumerable<StoreModelForSummary>> GetStoreSummaryByFilter(StoreFilter filter, int? PageIndex, int? PageSize, Sortable sortable)
        {
            int skiprow = 0;
            if (PageIndex.HasValue && PageSize.HasValue)
            {
                skiprow = (PageIndex.Value - 1) * PageSize.Value;

            }
            IEnumerable<StoreModelForSummary> list = await DbConnection.QueryAsync<StoreModelForSummary>("GetStore", new
            {
                Latitude = filter.Latitude,
                Longitude = filter.Longitude,
                Distance = filter.Distance,
                City = filter.City,
                StateId = filter.StateId,
                CountryId = filter.CountryId,
                Zipcode = filter.ZipCode,
                SkipRow = skiprow,
                PageSize = PageSize ?? 0,
                AmenitiesId = filter.AmenitiesId == null ? "" : string.Join(",", filter.AmenitiesId)
            }, DbTransaction, null, CommandType.StoredProcedure);

            return await Task.FromResult(list);
        }


        public async Task<IEnumerable<StoreSearchModel>> StoreSearch(int[] amenityIds, string longitude, string latitude, int distance, int pageIndex, int pageSize)
        {
            int skipRow = 0;
            if (pageIndex > 0 && pageSize > 10)
            {
                skipRow = (pageIndex - 1) * pageSize;
            }

            IEnumerable<StoreSearchModel> result = await DbConnection.QueryAsync<StoreSearchModel>("StoreSearch", new
            {
                Latitude = latitude,
                Longitude = longitude,
                Distance = distance,
                AmenityIds = amenityIds == null ? "" : string.Join(",", amenityIds),
                SkipRow = skipRow,
                PageSize = pageSize
            }, DbTransaction, null, CommandType.StoredProcedure);

            return result;
        }
        public async Task<bool> UpdateStoresSaleAgent(int SaleAgentId, int[] Storeids)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("saleAgentId", SaleAgentId);
            dynamicParams.Add("storeids", Storeids);

            string query = @"Update Store set SaleAgentId= @saleAgentId where StoreId in @storeids";

            return (await DbConnection.ExecuteAsync(query, dynamicParams, DbTransaction)) > 0;

        }
        public async Task<bool> RemoveSaleAgentfromStores(int[] Storeids)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("storeids", Storeids);

            string query = @"Update Store set SaleAgentId= null where StoreId in @storeids";

            return (await DbConnection.ExecuteAsync(query, dynamicParams, DbTransaction)) > 0;

        }

        public async Task<bool> UpdateStoresReseller(int ResellerId, int[] CompanyIds)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("resellerId", ResellerId);
            dynamicParams.Add("companyIds", CompanyIds);

            string query = @"Update store set ResellerId= @resellerId where CompanyId in @companyIds";

            return (await DbConnection.ExecuteAsync(query, dynamicParams, DbTransaction)) > 0;

        }
        public async Task<bool> RemoveResellerfromStores(int[] comapnyIds)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("comapnyIds", comapnyIds);

            string query = @"Update store set ResellerId= null where CompanyId in @comapnyIds";

            return (await DbConnection.ExecuteAsync(query, dynamicParams, DbTransaction)) > 0;

        }
        public async Task<List<StoreSearchResult>> GetByCompanyIds(int[] companyIds, int? pageIndex, int? pageSize, StoreSortBy? sortBy, SortOrderEnum? sortOrder)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select count(1) over() as TotalRecord,s.*,c.Name as Company from Store s inner join company c on s.companyid=c.id where 1=1");
            DynamicParameters para = new();

            if (companyIds != null && companyIds.Count() > 0)
            {
                sbquery.Append($" and CompanyId in @companyIds");
                para.Add("companyIds", companyIds);
            }
            if (sortBy != null && sortOrder != null && sortBy.Value != StoreSortBy.None && sortOrder.Value != SortOrderEnum.None)
            {
                if (sortBy.Value == StoreSortBy.CompanyName)
                {
                    sbquery.Append($" Order by c.Name {sortOrder} ");
                }
                else
                {
                    sbquery.Append($" Order by s.{sortBy} {sortOrder} ");
                }
            }
            else
            {
                sbquery.Append($" Order by s.StoreId desc");
            }

            if (pageIndex.HasValue && pageSize.HasValue)
            {
                int skiprow = (pageIndex.Value - 1) * pageSize.Value;

                sbquery.Append($" OFFSET {skiprow} rows fetch next {pageSize.Value} rows only");
            }
            return (await DbConnection.QueryAsync<StoreSearchResult>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
        public async Task<List<StoreSearchResult>> GetCompaniesByStoreId(int[] storeIds)
        {
            DynamicParameters para = new();
            StringBuilder sbquery = new();
            sbquery.Append($"Select C.Name as Company,S.* from Company C inner join Store S on S.CompanyId=C.Id where S.IsActive=1");

            if (storeIds.Count() > 0)
            {
                para.Add("StoreIds", storeIds);
                sbquery.Append($" and StoreId in @StoreIds");
            }

            return (await DbConnection.QueryAsync<StoreSearchResult>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
        public async Task<List<StoresSearchModel>> GetStoresForDashboard(int? stateId, string city, string zipcode, int? userId, string roleId, int? companyId, int[] storeGroupIds)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();

            sbquery.Append($"Select count(1) over() as TotalRecord,s.*,c.Name as Company, m.FirstName+ ' '+m.LastName MangerName, rm.FirstName+ ' '+rm.LastName  RegionalManagerName, SA.FirstName+ ' '+SA.LastName SaleAgentName,RS.FirstName+ ' '+RS.LastName ResellerName,RS.CompanyName as ResellerCompanyName from Store s inner join company c on s.companyid=c.id Left Join  Users m on s.[MangerId] = m.UserId  Left Join  Users rm on s.[RegionalManagerId] = rm.UserId  Left join  SaleAgent SA on s.SaleAgentId = SA.SaleAgentId left join Reseller RS on s.ResellerId=RS.ResellerId left Join (select Ad.StoreId, Ad.City,Ad.CompanyId,Ad.ZipCode,Ad.StateId,St.StateName, RANK () OVER (PARTITION BY StoreId ORDER BY AddressId) RankNo from Address Ad inner join State St on St.StateId=Ad.StateId and Ad.IsActive=1 where StoreId>0) A ON S.StoreId=A.StoreId where 1=1 ");

            if (stateId != null && (stateId ?? 0) > 0)
            {
                sbquery.Append($" and A.StateId = @stateId");
                para.Add("stateId", (stateId ?? 0));
            }
            if (!string.IsNullOrEmpty(city))
            {
                sbquery.Append($" and A.City like @city");
                para.Add("city", $"%{city}%");
            }
            if (!string.IsNullOrEmpty(zipcode))
            {
                sbquery.Append($" and A.ZipCode like @zipCode");
                para.Add("zipCode", $"%{zipcode}%");
            }
            if (companyId != null && (companyId ?? 0) > 0)
            {
                sbquery.Append($" and S.CompanyId = @companyId");
                para.Add("companyId", (companyId ?? 0));
            }
            if (storeGroupIds != null)
            {
                if (storeGroupIds.Any())
                {
                    para.Add("StoreGroupIds", storeGroupIds.ToArray().GetTableValuedParameter("[dbo].[UdtIntKeys]", "KeyValue"));
                    sbquery.Append($" and (s.StoreId in (Select StoreId from StoreGroupStores where StoreGroupId in((select KeyValue from @StoreGroupIds))))");
                }
            }
            if (!string.IsNullOrWhiteSpace(roleId))
            {
                if (roleId == "StoreOwner")
                {
                    para.Add("@ownerId", userId);
                    sbquery.Append($" and (s.StoreId in (Select StoreId from [dbo].[Store] where CompanyId in(select Id from Company where OwnerId=@ownerId)))");
                }
                else
                {
                    if (roleId != "SuperAdmin" && roleId != "Admin")
                    {
                        para.Add("@userIdToken", userId);
                        sbquery.Append($" and (s.StoreId in (Select StoreId from [dbo].[Users] where UserId=@userIdToken))");
                    }
                }
            }
            sbquery.Append($" Order by s.StoreId desc");


            return (await DbConnection.QueryAsync<StoresSearchModel>(sbquery.ToString(), para, DbTransaction)).ToList();

        }

        public async Task<string> TotalStoreCount()
        {
            DynamicParameters para = new();
            StringBuilder sbquery = new();
            sbquery.Append($"select COUNT(distinct StoreId) from Store where IsActive = 1");
            return (await DbConnection.QueryAsync<string>(sbquery.ToString(), para, DbTransaction)).First();
        }
        public async Task<List<StoreTenantMasterModel>> GetStoreTenantMaster()
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from TenantMaster");
            return (await DbConnection.QueryAsync<StoreTenantMasterModel>(sbquery.ToString(), null, DbTransaction)).ToList();
        }
        public async Task<string> GetStoreTenantMasterByTenantId(int TenantId)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();
            para.Add("@TenantId", TenantId);
            string query = $@"Select TenantName from TenantMaster where Id = @TenantId";
            var result = await DbConnection.ExecuteScalarAsync(query, para, DbTransaction);
            return result.ToString();
        }
        public async Task<int> AddStoreTenantMapping(int storeId, int tenantId)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();
            para.Add("@StoreId", storeId);
            para.Add("@TenantId", tenantId);
            string query = $@"insert into StoreTenantMapping(StoreId,TenantId)Values(@StoreId,@TenantId)";
            int result = await DbConnection.ExecuteAsync(query, para, DbTransaction);
            return result;
        }
        public async Task<int> UpdateStoreTenantMapping(int storeId, int Id, int tenantId)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();
            para.Add("@StoreId", storeId);
            para.Add("@TenantId", tenantId);
            para.Add("@Id", Id);
            string query = $@"Update StoreTenantMapping Set TenantId = @TenantId where StoreId = @StoreId and Id  = @Id";
            int result = await DbConnection.ExecuteAsync(query, para, DbTransaction);
            return result;
        }
        public async Task<List<StoreTenantMappingUpdateModel>> GetStoreTenantMasterByStoreId(int storeId)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();
            para.Add("@StoreId", storeId);
            string query = $@"Select * from StoreTenantMapping where StoreId = @StoreId";
            return (await DbConnection.QueryAsync<StoreTenantMappingUpdateModel>(query, para, DbTransaction)).ToList();
        }
        public async Task DeleteStoreTenantMasterByIds(int storeId , int id)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();
            para.Add("@StoreId", storeId);
            para.Add("@Id", id);
            string query = $@"Delete from StoreTenantMapping where StoreId = @StoreId and Id  = @Id";
            await DbConnection.ExecuteAsync(query, para, DbTransaction);
        }
        public async Task<List<StoreTenantMappingUpdateModel>> GetStoreTenantByStoreIdandTenantId(int storeId, int Id)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();
            para.Add("@StoreId", storeId);
            para.Add("@Id", Id);
            string query = $@"Select * from StoreTenantMapping where StoreId = @StoreId and ID = @Id";
            return (await DbConnection.QueryAsync<StoreTenantMappingUpdateModel>(query, para, DbTransaction)).ToList();
        }
        public async Task<int> GetStoreIdByTenantId(int TenantId)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();
            para.Add("@TenantId", TenantId);
            string query = $@"select StoreId from StoreTenantMapping where TenantId = @TenantId";
            var result = await DbConnection.ExecuteScalarAsync(query, para, DbTransaction);
            return Convert.ToInt32(result);
        }
        public async Task<List<StoreTenantMappingUpdateModel>> GetStoreTenantMasterByStoreIds(int storeId)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();
            para.Add("@StoreId", storeId);
            string query = $@"Select TenantId from StoreTenantMapping where StoreId = @StoreId";
            return (await DbConnection.QueryAsync<StoreTenantMappingUpdateModel>(query, para, DbTransaction)).ToList();
        }
        public async Task<List<StoreTenantMappingSearchModel>> GetStoreIdsByTenantId(int TenantId)
        {
            List<int> ints = new List<int>();
            StringBuilder sbquery = new();
            DynamicParameters para = new();
            para.Add("@TenantId", TenantId);
            string query = $@"select StoreId from StoreTenantMapping where TenantId = @TenantId";
            return (await DbConnection.QueryAsync<StoreTenantMappingSearchModel>(query, para, DbTransaction)).ToList();
        }
        public async Task<List<StoreTenantMappingUpdateModel>> GetStoreIdAndIdByTenantId(int storeId, int tenantId)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();
            para.Add("@StoreId", storeId);
            para.Add("@TenantId", tenantId);
            string query = $@"select * from StoreTenantMapping where TenantId = @TenantId and StoreId =@StoreId";
            return (await DbConnection.QueryAsync<StoreTenantMappingUpdateModel>(query, para, DbTransaction)).ToList();
        }
        public async Task<List<StoreTenantMappingUpdateModel>> GetStoreTenantByStoreIds(int storeId)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();
            para.Add("@StoreId", storeId);
            string query = $@"Select * from StoreTenantMapping where StoreId = @StoreId";
            return (await DbConnection.QueryAsync<StoreTenantMappingUpdateModel>(query, para, DbTransaction)).ToList();
        }
    }
}
