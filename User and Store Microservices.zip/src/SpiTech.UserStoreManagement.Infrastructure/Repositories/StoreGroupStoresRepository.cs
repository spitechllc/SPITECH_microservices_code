﻿using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class StoreGroupStoresRepository : Repository<StoreGroupStores>, IStoreGroupStoresRepository
    {
        public StoreGroupStoresRepository(IBaseUnitOfWork dbContext, System.IServiceProvider serviceProvider) : base(dbContext, serviceProvider)
        {
        }

        public async Task<List<StoreGroupStoresModel>> GetByStoreGroupId(int StoreGroupId)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select  SGS.StoreGroupStoresId,SGS.StoreGroupId,SGS.StoreId,S.StoreName from StoreGroupStores SGS inner join Store S on SGS.StoreId=S.StoreId where SGS.IsActive=1");
            DynamicParameters para = new();

            if (StoreGroupId > 0)
            {
                para.Add("StoreGroupId", StoreGroupId);
                sbquery.Append($" and StoreGroupId=@StoreGroupId");
            }
            sbquery.Append($" order by S.StoreName desc");
            return (await DbConnection.QueryAsync<StoreGroupStoresModel>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
    }
}
