﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Database;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class StoreAmenityRepository : Repository<StoreAmenity>, IStoreAmenityRepository
    {
        public StoreAmenityRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<List<StoreAmenitySearchResult>> GetAmenityByStoreId(int StoreId)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"select a.AmenityName, sa.AmenityId, sa.StoreAmenityId  from [StoreAmenity] sa inner join [Amenity] a on sa.AmenityId = a.AmenityId where sa.IsActive=1");
            DynamicParameters para = new();

            if (StoreId > 0)
            {
                sbquery.Append($" and sa.StoreId =@StoreId");
                para.Add("@StoreId", StoreId);
            }

            return (await DbConnection.QueryAsync<StoreAmenitySearchResult>(sbquery.ToString(), para, DbTransaction)).ToList();

        }

        public async Task<List<StoreAmenityResultModel>> GetAmenityListByStoreIds(string[] storeIds)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"select a.AmenityName, sa.AmenityId, sa.StoreAmenityId, sa.StoreId  from [StoreAmenity] sa inner join [Amenity] a on sa.AmenityId = a.AmenityId where sa.IsActive=1");
            DynamicParameters para = new();

            if (storeIds != null && storeIds.Any())
            {
                sbquery.Append($" and sa.StoreId  in (select KeyValue from @StoreIds)");
                para.Add("StoreIds", storeIds.GetTableValuedParameter("[dbo].[UdtStringKeys]", "KeyValue"));
            }

            return (await DbConnection.QueryAsync<StoreAmenityResultModel>(sbquery.ToString(), para, DbTransaction)).ToList();

        }
    }
}
