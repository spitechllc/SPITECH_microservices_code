﻿using AutoMapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class TimeZoneRepository : Repository<TimeZoneEntity>, ITimeZoneRepository
    {
        public TimeZoneRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
    }
}
