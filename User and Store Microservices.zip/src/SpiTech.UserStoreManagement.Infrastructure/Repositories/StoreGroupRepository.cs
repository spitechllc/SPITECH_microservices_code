﻿using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class StoreGroupRepository : Repository<StoreGroup>, IStoreGroupRepository
    {
        public StoreGroupRepository(IBaseUnitOfWork dbContext, System.IServiceProvider serviceProvider) : base(dbContext, serviceProvider)
        {
        }

        public async Task<List<StoreGroupModel>> GetStoreGroup(int? StoreGroupId)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select distinct SG.StoreGroupId,SG.StoreGroupName from StoreGroup SG where SG.IsActive=1");
            DynamicParameters para = new();

            if ((StoreGroupId ?? 0) > 0)
            {
                sbquery.Append($" and StoreGroupId = @StoreGroupId");
                para.Add("StoreGroupId", StoreGroupId);
            }
            sbquery.Append($" order by StoreGroupId");
            return (await DbConnection.QueryAsync<StoreGroupModel>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
        public async Task<List<StoreGroup>> GetStoreGroupAutoComplete(int StoreGroupId, string StoreGroupName)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select SG.StoreGroupId,SG.StoreGroupName from StoreGroup SG  where SG.IsActive=1");
            DynamicParameters para = new();

            if (!string.IsNullOrEmpty(StoreGroupName) && StoreGroupName.ToLower() != "null")
            {
                sbquery.Append($" and StoreGroupName like @StoreGroupName");
                para.Add("StoreGroupName", $"%{StoreGroupName}%");
            }
            else if (StoreGroupId > 0)
            {
                sbquery.Append($" and StoreGroupId like @StoreGroupId");
                para.Add("StoreGroupId", $"%{StoreGroupId}%");
            }
            sbquery.Append($" order by StoreGroupName desc");
            return (await DbConnection.QueryAsync<StoreGroup>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
    }
}
