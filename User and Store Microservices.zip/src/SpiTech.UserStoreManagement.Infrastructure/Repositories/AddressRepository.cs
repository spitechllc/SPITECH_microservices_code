﻿using Dapper;
using SpiTech.ApplicationCore.Database;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class AddressRepository : Repository<Address>, IAddressRepository
    {
        public AddressRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public List<AddressModel> Get(int entityId, EntityCategoryType entityCategoryType)
        {
            string entityColumn = entityCategoryType == EntityCategoryType.Company ? "CompanyId" : entityCategoryType == EntityCategoryType.Store ? "StoreId" : entityCategoryType == EntityCategoryType.User ? "UserId" : entityCategoryType == EntityCategoryType.SaleAgent ? "SaleAgentId" : "ResellerId";

            DynamicParameters para = new();
            StringBuilder sbquery = new();

            sbquery.Append("Select a.*, c.CountryName as Country, s.StateName as State from Address a left join Country c on a.CountryId = c.CountryId left join State s on a.StateId = s.StateId where a.IsActive=1");

            if (entityId > 0)
            {
                sbquery.Append($" and {entityColumn}=@entityId ");
                para.Add("entityId", entityId);
            }

            if (entityCategoryType == EntityCategoryType.Company)
            {
                sbquery.Append($" and isnull(StoreId,0)=0");

            }

            return DbConnection.Query<AddressModel>(sbquery.ToString(), para, DbTransaction).ToList();
        }

        public async Task<AddressModel> GetPrimaryAddress(int entityId, EntityCategoryType entityCategoryType)
        {
            string entityColumn = entityCategoryType == EntityCategoryType.Company ? "CompanyId" : entityCategoryType == EntityCategoryType.Store ? "StoreId" : entityCategoryType == EntityCategoryType.User ? "UserId" : entityCategoryType == EntityCategoryType.SaleAgent ? "SaleAgentId" : "ResellerId";
            DynamicParameters para = new();

            StringBuilder sbquery = new();
            sbquery.Append("Select a.*, c.CountryName as Country, s.StateName as State from Address a inner join [CategoryTypeLevel] L on L.Id =a.CategoryTypeLevelId  and L.IsPrimary = 1 left join Country c on a.CountryId = c.CountryId left join State s on a.StateId = s.StateId where a.IsActive=1");

            if (entityId > 0)
            {
                sbquery.Append($" and {entityColumn}=@entityId ");
                para.Add("entityId", entityId);
            }

            if (entityCategoryType == EntityCategoryType.Company)
            {
                sbquery.Append($" and isnull(StoreId,0)=0");

            }
            return (await DbConnection.QueryAsync<AddressModel>(sbquery.ToString(), para, DbTransaction)).FirstOrDefault();
        }

        public List<AddressModel> GetPrimaryAddressStore(int entityId, EntityCategoryType entityCategoryType)
        {
            string entityColumn = entityCategoryType == EntityCategoryType.Company ? "CompanyId" : entityCategoryType == EntityCategoryType.Store ? "StoreId" : entityCategoryType == EntityCategoryType.User ? "UserId" : entityCategoryType == EntityCategoryType.SaleAgent ? "SaleAgentId" : "ResellerId";
            DynamicParameters para = new();

            StringBuilder sbquery = new();
            sbquery.Append("Select a.*, c.CountryName as Country, s.StateName as State from Address a inner join [CategoryTypeLevel] L on L.Id =a.CategoryTypeLevelId  and L.IsPrimary = 1 left join Country c on a.CountryId = c.CountryId left join State s on a.StateId = s.StateId where a.IsActive=1");

            if (entityId > 0)
            {
                sbquery.Append($" and {entityColumn}=@entityId ");
                para.Add("entityId", entityId);
            }

            if (entityCategoryType == EntityCategoryType.Company)
            {
                sbquery.Append($" and isnull(StoreId,0)=0");
            }

            return DbConnection.Query<AddressModel>(sbquery.ToString(), para, DbTransaction).ToList();
        }

        public async Task<List<AddressModel>> GetPrimaryAddressStoreByIds(string[] entityIds, EntityCategoryType entityCategoryType)
        {
            string entityColumn = entityCategoryType == EntityCategoryType.Company ? "CompanyId" : entityCategoryType == EntityCategoryType.Store ? "StoreId" : entityCategoryType == EntityCategoryType.User ? "UserId" : entityCategoryType == EntityCategoryType.SaleAgent ? "SaleAgentId" : "ResellerId";
            DynamicParameters para = new();

            StringBuilder sbquery = new();

            sbquery.Append("Select a.*, c.CountryName as Country, s.StateName as State from Address a inner join [CategoryTypeLevel] L on L.Id =a.CategoryTypeLevelId  and L.IsPrimary = 1 left join Country c on a.CountryId = c.CountryId left join State s on a.StateId = s.StateId where a.IsActive=1");

            if (entityIds != null && entityIds.Any())
            {
                sbquery.Append($" and {entityColumn} in (select KeyValue from @entityIds)");
                para.Add("entityIds", entityIds.GetTableValuedParameter("[dbo].[UdtStringKeys]", "KeyValue"));

            }
            else
            {
                sbquery.Append($" and {entityColumn} is not null and {entityColumn} > 0");
            }

            if (entityCategoryType == EntityCategoryType.Company)
            {
                sbquery.Append($" and isnull(StoreId,0)=0");
            }

            return (await DbConnection.QueryAsync<AddressModel>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
    }
}
