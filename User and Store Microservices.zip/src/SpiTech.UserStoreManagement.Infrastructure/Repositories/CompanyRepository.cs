﻿using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class CompanyRepository : Repository<Company>, ICompanyRepository
    {
        public CompanyRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<Company> GetCompanyById(int companyId)
        {
            DynamicParameters para = new();
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from Company where IsActive=1");

            if (companyId > 0)
            {
                para.Add("Id", companyId);
                sbquery.Append($" and Id=@Id");
            }

            return (await DbConnection.QueryAsync<Company>(sbquery.ToString(), para, DbTransaction)).FirstOrDefault();
        }

        public async Task<List<Company>> GetCompanyByUserId(int userid)
        {
            DynamicParameters para = new();
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from Company C inner join users U on U.companyid=C.Id where C.IsActive=1");

            if (userid > 0)
            {
                para.Add("Id", userid);
                sbquery.Append($" and UserId=@Id");
            }
            sbquery.Append($" order by C.Id desc");
            return (await DbConnection.QueryAsync<Company>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
        public async Task<string> CheckCompany(string companyname, int id)
        {
            DynamicParameters para = new();
            StringBuilder sbquery = new();
            sbquery.Append($"Select Name from Company where IsActive=1");

            if (!string.IsNullOrEmpty(companyname))
            {
                para.Add("Name", companyname);
                sbquery.Append($" and Name=@Name");
            }

            if (id > 0)
            {
                para.Add("id", id);
                sbquery.Append($" and Id!=@id");
            }

            return (await DbConnection.QueryAsync<CompanyModel>(sbquery.ToString(), para, DbTransaction)).Select(x => x.Name).FirstOrDefault();
        }

        public async Task<List<CompanyModel>> GetCompanyWithPaging(string CompanyName, string City, int? StateId, string ZipCode, int? PageIndex, int? PageSize, string SortBy, string SortOrder)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select count(1) over() as TotalRecord,  C.*,(Select count(1) from store where companyID=C.ID)TotalStores from Company C left Join (select City,CompanyId,ZipCode,StateId, RANK () OVER (PARTITION BY CompanyId ORDER BY AddressId) RankNo from Address where CompanyId>0) A ON C.Id=A.CompanyId AND A.RankNo=1 where IsActive=1 ");
            DynamicParameters para = new();

            if (!string.IsNullOrEmpty(CompanyName))
            {
                sbquery.Append($" and Name like @CompanyName");
                para.Add("CompanyName", $"%{CompanyName}%");
            }
            if (!string.IsNullOrEmpty(City))
            {
                sbquery.Append($" and A.City like @city");
                para.Add("city", $"%{City}%");
            }
            if (StateId.HasValue)
            {
                sbquery.Append($" and A.StateId like @stateId");
                para.Add("stateId", $"%{StateId}%");
            }
            if (!string.IsNullOrEmpty(ZipCode))
            {
                sbquery.Append($" and A.ZipCode like @zipCode");
                para.Add("zipCode", $"%{ZipCode}%");
            }

            if (!string.IsNullOrEmpty(SortBy) && !string.IsNullOrEmpty(SortOrder))
            {
                sbquery.Append($" Order by {SortBy} {SortOrder}");
            }
            else
            {
                sbquery.Append($" Order by Id desc");
            }

            if (PageIndex.HasValue && PageSize.HasValue)
            {
                int skiprow = (PageIndex.Value - 1) * PageSize.Value;

                sbquery.Append($" OFFSET {skiprow} rows fetch next {PageSize.Value} rows only");
            }

            return (await DbConnection.QueryAsync<CompanyModel>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
        public async Task<List<Company>> GetCompanyAutoComplete(int CompanyId, string CompanyName)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from Company where IsActive=1");
            DynamicParameters para = new();

            if (!string.IsNullOrEmpty(CompanyName) && CompanyName.ToLower() != "null")
            {
                sbquery.Append($" and Name like @CompanyName");
                para.Add("CompanyName", $"%{CompanyName}%");
            }
            else if(CompanyId>0)
            {
                sbquery.Append($" and Id like @CompanyId");
                para.Add("CompanyId", $"%{CompanyId}%");
            }
            sbquery.Append($" order by Id desc");
            return (await DbConnection.QueryAsync<Company>(sbquery.ToString(), para, DbTransaction)).ToList();
        }

        public async Task<List<CompanySearchModel>> GetByResellerId(int resellerId)
        {
            StringBuilder sbquery = new StringBuilder();
            DynamicParameters dynamicParams = new DynamicParameters();

            sbquery.Append($"Select * from Company where 1=1");

            if (resellerId > 0)
            {
                dynamicParams.Add("ResellerId", resellerId);
                sbquery.Append($" and ResellerId=@ResellerId");
            }
            sbquery.Append($" order by Id desc");
            return (await this.DbConnection.QueryAsync<CompanySearchModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }

        public async Task<List<CompanySearchModel>> GetByResellerIds(int[] resellerIds)
        {
            StringBuilder sbquery = new StringBuilder();
            DynamicParameters dynamicParams = new DynamicParameters();

            sbquery.Append($"Select * from Company where 1=1");

            if (resellerIds != null && resellerIds.Any())
            {
                dynamicParams.Add("resellerIds", resellerIds);
                sbquery.Append($" and ResellerId in @resellerIds");
            }
            sbquery.Append($" order by Id desc");
            return (await this.DbConnection.QueryAsync<CompanySearchModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }

        public async Task<bool> UpdateCompanyReseller(int ResellerId, int[] CompanyIds)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("resellerId", ResellerId);
            dynamicParams.Add("companyIds", CompanyIds);

            string query = @"Update company set ResellerId= @resellerId where Id in @companyIds";

            return (await DbConnection.ExecuteAsync(query, dynamicParams, DbTransaction)) > 0;

        }
        public async Task<bool> RemoveResellerfromCompanies(int[] comapnyIds)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("comapnyIds", comapnyIds);

            string query = @"Update company set ResellerId= null where Id in @comapnyIds";

            return (await DbConnection.ExecuteAsync(query, dynamicParams, DbTransaction)) > 0;

        }
        public async Task<bool> UpdateCompanyOwner(int OwnerId, int[] CompanyIds)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("ownerId", OwnerId);
            dynamicParams.Add("companyIds", CompanyIds);

            string query = @"Update company set OwnerId= @ownerId where Id in @companyIds";

            return (await DbConnection.ExecuteAsync(query, dynamicParams, DbTransaction)) > 0;

        }
        public async Task<bool> RemoveOwnerfromCompanies(int[] comapnyIds)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("comapnyIds", comapnyIds);

            string query = @"Update company set OwnerId= null where Id in @comapnyIds";

            return (await DbConnection.ExecuteAsync(query, dynamicParams, DbTransaction)) > 0;

        }
        public async Task<List<CompanySearchModel>> GetByOwnerId(int ownerId)
        {
            StringBuilder sbquery = new StringBuilder();
            DynamicParameters dynamicParams = new DynamicParameters();

            sbquery.Append($"Select * from Company where 1=1");

            if (ownerId > 0)
            {
                dynamicParams.Add("ownerId", ownerId);
                sbquery.Append($" and OwnerId=@ownerId");
            }
            sbquery.Append($" order by Id desc");
            return (await this.DbConnection.QueryAsync<CompanySearchModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }
        public async Task<List<CompanySearchModel>> GetByOwnerIds(int[] ownerIds)
        {
            StringBuilder sbquery = new StringBuilder();
            DynamicParameters dynamicParams = new DynamicParameters();

            sbquery.Append($"Select * from Company where 1=1");

            if (ownerIds != null && ownerIds.Any())
            {
                dynamicParams.Add("ownerIds", ownerIds);
                sbquery.Append($" and OwnerId in @ownerIds");
            }
            sbquery.Append($" order by OwnerId desc");
            return (await this.DbConnection.QueryAsync<CompanySearchModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }
        public async Task<string> GetCompaniesOwner(int ownerId,int[] companyIds)
        {
            StringBuilder sbquery = new StringBuilder();
            DynamicParameters dynamicParams = new DynamicParameters();

            sbquery.Append($"SELECT SUBSTRING((SELECT ','+Name  AS [text()] FROM company WHERE Id in @companyIds and OwnerId!=@ownerId ORDER BY Id FOR XML PATH (''), TYPE).value('text()[1]','nvarchar(max)'), 2, 1000) [Name]");

            if (ownerId > 0)
            {
                dynamicParams.Add("ownerId", ownerId);
               // sbquery.Append($" and OwnerId!=@ownerId");
            }
            if(companyIds.Count()>0)
            {
                dynamicParams.Add("companyIds", companyIds);
               // sbquery.Append($" and Id in ");
            }
           
            return (await this.DbConnection.QueryFirstAsync<string>(sbquery.ToString(), dynamicParams, DbTransaction));
        }
        public async Task<string> GetCompaniesReseller(int resellerId, int[] companyIds)
        {
            StringBuilder sbquery = new StringBuilder();
            DynamicParameters dynamicParams = new DynamicParameters();

            sbquery.Append($"SELECT SUBSTRING((SELECT ','+Name  AS [text()] FROM company WHERE Id in @companyIds and ResellerId!=@resellerId ORDER BY Id FOR XML PATH (''), TYPE).value('text()[1]','nvarchar(max)'), 2, 1000) [Name]");

            if (resellerId > 0)
            {
                dynamicParams.Add("resellerId", resellerId);
              //  sbquery.Append($" and ResellerId!=@resellerId");
            }
            if (companyIds.Count() > 0)
            {
                dynamicParams.Add("companyIds", companyIds);
               // sbquery.Append($" and Id in @companyIds");
            }

            return (await this.DbConnection.QueryFirstAsync<string>(sbquery.ToString(), dynamicParams, DbTransaction));
        }
    }
}