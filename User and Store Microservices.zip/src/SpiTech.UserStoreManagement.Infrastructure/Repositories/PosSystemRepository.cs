﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class PosSystemRepository : Repository<PosSystem>, IPosSystemRepository
    {
        public PosSystemRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
        public async Task<List<PosSystem>> GetAllActive()
        {
            StringBuilder sbquery = new();
            sbquery.Append("Select * from PosSystem where Isactive=1");
            return (await DbConnection.QueryAsync<PosSystem>(sbquery.ToString(), null, DbTransaction)).ToList();
        }
    }
}
