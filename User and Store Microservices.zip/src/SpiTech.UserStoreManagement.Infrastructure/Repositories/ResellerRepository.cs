﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class ResellerRepository : Repository<Reseller>, IResellerRepository
    {
        public ResellerRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<List<ResellerModel>> GetResellerByFilters(string companyName, string name, string mobile, string email, string company, int? skip, int? take, ResellerSortBy? sortBy, SortOrderEnum? sortOrder)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();

            sbquery.Append($"select RS.*, count(RS.ResellerId) over() as TotalRecord From Reseller RS Left join (select EmailAddress,resellerId, RANK () OVER (PARTITION BY resellerId ORDER BY EmailId) RankNo from Email where resellerId>0 ) E  on RS.ResellerId = E.ResellerId AND E.RankNo=1 Left join (select PhoneNumber,resellerId, RANK () OVER (PARTITION BY resellerId ORDER BY PhoneId) RankNo from Phone where resellerId>0 ) P  on RS.ResellerId = P.ResellerId AND P.RankNo=1  Where RS.IsActive = 1 ");

            if (!string.IsNullOrWhiteSpace(companyName))
            {
                sbquery.Append($" and RS.CompanyName like @companyName");
                para.Add("companyName", $"%{companyName}%");
            }
            if (!string.IsNullOrWhiteSpace(name))
            {
                sbquery.Append($" and RS.FirstName +' '+RS.LastName like @Name");
                para.Add("Name", $"%{name}%");
            }
            if (!string.IsNullOrWhiteSpace(mobile))
            {
                sbquery.Append($" and RS.ResellerId in (Select ResellerId from Phone where PhoneNumber = @Mobile)");
                para.Add("Mobile", mobile);
            }
            if (!string.IsNullOrWhiteSpace(email))
            {
                sbquery.Append($" and RS.ResellerId in (Select ResellerId from Email where EmailAddress = @Email)");
                para.Add("Email", email);
            }
            if (!string.IsNullOrWhiteSpace(company))
            {
                sbquery.Append($" and RS.ResellerId in (Select ResellerId from Company where Name like @company) ");
                para.Add("company", $"%{company}%");
            }

            if (sortBy != null && sortOrder != null && sortBy.Value != ResellerSortBy.None && sortOrder.Value != SortOrderEnum.None)
            {
                if (sortBy.Value == ResellerSortBy.EmailAddress)
                    sbquery.Append($" Order by E.{sortBy} {sortOrder}");
                else if (sortBy.Value == ResellerSortBy.PhoneNumber)
                    sbquery.Append($" Order by P.{sortBy} {sortOrder}");
                else
                    sbquery.Append($" Order by RS.{sortBy} {sortOrder}");
            }
            else
            {
                sbquery.Append($" Order by RS.ResellerId desc ");
            }

            if (skip.HasValue && take.HasValue)
            {
                int skiprow = (skip.Value - 1) * take.Value;
                sbquery.Append($" OFFSET {skiprow} rows fetch next {take.Value} rows only");
            }

            return (await DbConnection.QueryAsync<ResellerModel>(sbquery.ToString(), para, DbTransaction)).ToList();
        }

        public async Task<List<ResellerModel>> GetResellers(int[] resellerIds)
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();
            para.Add("ResellerIds", resellerIds);

            sbquery.Append($"select * From Reseller Where IsActive = 1 and resellerid in @resellerIds");

            return (await DbConnection.QueryAsync<ResellerModel>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
    }
}
