﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Infrastructure.Repositories
{
    public class StateRepository : Repository<State>, IStateRepository
    {
        public StateRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<IEnumerable<State>> GetState(int? stateId = null)
        {
            DynamicParameters para = new();
            StringBuilder sbquery = new();

            sbquery.Append($"Select * from State where IsActive=1");

            if (stateId.HasValue && stateId.Value > 0)
            {
                para.Add("StateId", stateId.Value);
                sbquery.Append($" and StateId=@StateId");
            }

            return (await DbConnection.QueryAsync<State>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
        public async Task<IEnumerable<State>> GetStateByCountryId(int id)
        {
            DynamicParameters para = new();
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from State where IsActive=1");

            if (id > 0)
            {
                para.Add("CountryId", id);
                sbquery.Append($" and CountryId=@CountryId");
            }

            return (await DbConnection.QueryAsync<State>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
        public async Task<List<State>> GetStateAutoComplete(int StateId, string StateName)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select * from State where IsActive=1");
            DynamicParameters para = new();

            if (!string.IsNullOrEmpty(StateName) && StateName.ToLower() != "null")
            {
                sbquery.Append($" and StateName like @StateName");
                para.Add("StateName", $"%{StateName}%");
            }
            else if (StateId > 0)
            {
                sbquery.Append($" and StateId like @StateId");
                para.Add("StateId", $"%{StateId}%");
            }
            sbquery.Append($" order by StateId desc");
            return (await DbConnection.QueryAsync<State>(sbquery.ToString(), para, DbTransaction)).ToList();
        }
    }
}
