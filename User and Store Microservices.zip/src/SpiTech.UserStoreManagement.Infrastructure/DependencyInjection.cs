﻿using FluentValidation;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Infrastructure.UnitOfWorks;
using System.Reflection;

namespace SpiTech.UserStoreManagement.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            string connectionString = configuration.GetConnectionString("UserStoreManagement");
            services
                .AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());

            services.AddScoped<IUnitOfWork, UnitOfWork>(serviceProvider => new UnitOfWork(connectionString, serviceProvider));

            return services;
        }
    }
}