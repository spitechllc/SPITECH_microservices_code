using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using SpiTech.Application.Logging;
using SpiTech.Application.Logging.Extensions;
using System;

namespace SpiTech.UserStoreManagement.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            LoggerExtensions.InitializeLogger();
            Logger.Information("UserStoreManagement API starting");
            try
            {
                CreateHostBuilder(args).Build().Run();
                Logger.Information($"UserStoreManagement Application started in environment: {Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")}");
            }
            catch (Exception e)
            {
                Logger.Error("UserStoreManagement API Host terminated unexpected", e);
                throw;
            }
            finally
            {
                Logger.Information("UserStoreManagement API stopped");
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            return Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseLogger();
                    webBuilder.UseStartup<Startup>();
                    webBuilder.ConfigureKestrel((options) =>
                    {
                        options.AddServerHeader = false;
                    });
                });
        }
    }
}
