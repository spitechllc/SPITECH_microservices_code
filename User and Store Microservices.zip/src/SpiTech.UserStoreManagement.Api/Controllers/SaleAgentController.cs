﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.UserStoreManagement.Application.Commands.CreateSaleAgent;
using SpiTech.UserStoreManagement.Application.Commands.UpdateSaleAgent;
using SpiTech.UserStoreManagement.Application.Queries.GetSaleAgentById;
using SpiTech.UserStoreManagement.Application.Queries.GetSaleAgentByIds;
using SpiTech.UserStoreManagement.Application.Queries.GetSaleAgents;
using SpiTech.UserStoreManagement.Domain.Entities;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.UserStoreManagement.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class SaleAgentController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<SaleAgentController> _logger;

        public SaleAgentController(IMediator mediator, ILogger<SaleAgentController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }
        /// <summary>
        /// Method will return saleAgent details by saleAgent id.
        /// </summary>
        /// <param name="saleAgentId">Varriable of Int</param>
        /// <returns>It will return in the form of SaleAgentModel</returns> 
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_SaleAgent_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("{saleAgentId}")]
        public async Task<ActionResult<SaleAgentModel>> GetById([FromRoute] int saleAgentId)
        {
            return Ok(await _mediator.Send(new GetSaleAgentByIdQuery() { SaleAgentId = saleAgentId }).ConfigureAwait(false));
        }
        /// <summary>
        /// GetByIds to get SaleAgent by respective ids.
        /// </summary>
        /// <param name="request">Object of GetSaleAgentByIdsQuery</param>
        /// <returns>It will return ResponseList in the form of SaleAgent</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_SaleAgent_SaleAgents")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("SaleAgents")]
        public async Task<ActionResult<ResponseList<SaleAgent>>> GetByIds([FromBody] GetSaleAgentByIdsQuery request)
        {
            return Ok(new ResponseList<SaleAgentModel>(await _mediator.Send(request).ConfigureAwait(false)));
        }

        /// <summary>
        /// Method will return SaleAgent details list.
        /// </summary>
        /// <param name="query">Object of GetSaleAgentsQuery</param>
        /// <returns>It will return PaginatedList in the form of SaleAgentModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_SaleAgent_GetAllSaleAgents")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetAllSaleAgents")]
        public async Task<ActionResult<PaginatedList<SaleAgentModel>>> GetAllSaleAgent([FromQuery] GetSaleAgentsQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will use for create new saleagent
        /// </summary>
        /// <param name="command">Object of CreateSaleAgentCommand</param>
        /// <returns>It will return in the form of Int</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_SaleAgent_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost]
        public async Task<ActionResult<int>> Post([FromBody] CreateSaleAgentCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }
        /// <summary>
        /// Method will update existing saleagent information 
        /// </summary>
        /// <param name="command">Object of UpdateSaleAgentCommand</param>
        /// <returns>It will return in the form of bool</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_SaleAgent_Patch")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch]
        public async Task<ActionResult<bool>> Update([FromBody] UpdateSaleAgentCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }
    }
}
