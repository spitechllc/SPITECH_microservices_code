﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.Queries.GetState;
using SpiTech.UserStoreManagement.Application.Queries.GetStateAutoComplete;
using SpiTech.UserStoreManagement.Application.Queries.GetStateByCountryId;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.UserStoreManagement.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class StateController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<StateController> _logger;
        public StateController(IMediator mediator, ILogger<StateController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }
        /// <summary>
        /// Method will return list of states.
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of StateModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_State_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet]
        public async Task<ActionResult<ResponseList<StateModel>>> GetState()
        {
            return Ok(await _mediator.Send(new GetStateQuery()).ConfigureAwait(false));
        }
        /// <summary>
        /// Method will return list of states for particular country.
        /// </summary>
        /// <param name="Countryid">Varriable of int</param>
        /// <returns>It will return ResponseList in the form of StateModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_State_ByCountryId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("ByCountryId/{Countryid}")]
        public async Task<ActionResult<ResponseList<StateModel>>> GetStateByCountryId(int Countryid)
        {
            return Ok(await _mediator.Send(new GetStateByCountryIdQuery() { CountryId = Countryid }).ConfigureAwait(false));
        }
        /// <summary>
        /// StateAutoComplete to search company by keywords.
        /// </summary>
        /// <param name="request">Object of GetStateAutoCompleteQuery</param>
        /// <returns>It will return ResponseList in the form of StateAutoCompleteModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_State_StateAutoComplete")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("StateAutoComplete")]
        public async Task<ActionResult<ResponseList<StateAutoCompleteModel>>> StateAutoComplete([FromQuery] GetStateAutoCompleteQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }
    }
}

