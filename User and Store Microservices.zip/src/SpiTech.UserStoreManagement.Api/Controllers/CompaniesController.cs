﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.UserStoreManagement.Application.Commands.AddOwnerCompany;
using SpiTech.UserStoreManagement.Application.Commands.AddResellerCompany;
using SpiTech.UserStoreManagement.Application.Commands.CreateCompany;
using SpiTech.UserStoreManagement.Application.Commands.UpdateCompany;
using SpiTech.UserStoreManagement.Application.Queries.GetCompanyAutoComplete;
using SpiTech.UserStoreManagement.Application.Queries.GetCompanyById;
using SpiTech.UserStoreManagement.Application.Queries.GetCompanyByUserId;
using SpiTech.UserStoreManagement.Application.Queries.GetCompanyOwnerById;
using SpiTech.UserStoreManagement.Application.Queries.GetCompanyOwners;
using SpiTech.UserStoreManagement.Application.Queries.GetCompanyWithPaging;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.UserStoreManagement.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class CompaniesController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<CompaniesController> _logger;

        public CompaniesController(IMediator mediator, ILogger<CompaniesController> logger)
        {
            _mediator = mediator;
            _logger = logger;

        }

        /// <summary>
        /// Method will return company details by company id.
        /// </summary>
        /// <param name="companyId">Varriable of int</param>
        /// <returns>It will return in the form of CompanyModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Companies_ByCompanyId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("ByCompanyId/{companyId}")]
        public async Task<ActionResult<CompanyModel>> ByCompanyId(int companyId)
        {
            return Ok(await _mediator.Send(new GetCompanyByIdQuery() { CompanyId = companyId }).ConfigureAwait(false));
        }
        /// <summary>
        /// Method will return list of companies for particular user.
        /// </summary>
        /// <param name="userid">Varriable of int</param>
        /// <returns>It will return ResponseList in the form of CompanyModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Companies_ByUserId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("ByUserId/{userid}")]
        public async Task<ActionResult<ResponseList<CompanyModel>>> ByCompanyUserId(int userid)
        {
            return Ok(await _mediator.Send(new GetCompanyByUserIdQuery() { UserId = userid }).ConfigureAwait(false));
        }

        /// <summary>
        /// Method is to get paginated list of companies.
        /// </summary>
        /// <param name="request">Object of GetCompanyWithPagingQuery</param>
        /// <returns>It will return PaginatedList in the form of CompanyModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Companies_WithPaging")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("WithPaging")]
        public async Task<ActionResult<PaginatedList<CompanyModel>>> GetCompanyWithPaging([FromQuery] GetCompanyWithPagingQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will be used for creating new company.
        /// </summary>
        /// <param name="command">Object of CreateCompanyCommand</param>
        /// <returns>It will return  in the form of int</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Companies_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost]
        public async Task<ActionResult<int>> Post([FromBody] CreateCompanyCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));

        }
        /// <summary>
        /// Method will be used to update existing company details
        /// </summary>
        /// <param name="command">Object of UpdateCompanyCommand</param>
        /// <returns>It will return  in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Companies_Patch")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch]
        public async Task<ActionResult<ResponseModel>> Update([FromBody] UpdateCompanyCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }
        /// <summary>
        /// companyautocomplete to search company by keywords
        /// </summary>
        /// <param name="request">Object of GetCompanyAutoCompleteQuery</param>
        /// <returns>It will return ResponseList in the form of CompanyAutoCompleteModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Companies_CompanyAutoComplete")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("CompanyAutoComplete")]
        public async Task<ActionResult<ResponseList<CompanyAutoCompleteModel>>> CompanyAutoComplete([FromQuery] GetCompanyAutoCompleteQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }
        /// <summary>
        /// Method will be used to update existing company Reseller Details
        /// </summary>
        /// <param name="command">Object of AddResellerCompanyCommand</param>
        /// <returns>It will return  in the form of bool</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Companies_UpdateReseller")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch("UpdateReseller")]
        public async Task<ActionResult<bool>> UpdateReseller([FromBody] AddResellerCompanyCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will be used for creating new company owner.
        /// </summary>
        /// <param name="command">Object of AddOwnerCompanyCommand</param>
        /// <returns>It will return  in the form of bool</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Companies_AddOwnerCompanies")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch("AddOwnerCompanies")]
        public async Task<ActionResult<bool>> AddOwnerCompanies([FromBody] AddOwnerCompanyCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will return owner details by owner id.
        /// </summary>
        /// <param name="ownerId">Varriable of int</param>
        /// <returns>It will return  in the form of CompanyOwnerModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Companies_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("{ownerId}")]
        public async Task<ActionResult<CompanyOwnerModel>> GetById([FromRoute] int ownerId)
        {
            return Ok(await _mediator.Send(new GetCompanyOwnerByIdQuery() { OwnerId = ownerId }).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will return owner details list.
        /// </summary>
        /// <param name="request">Object of GetCompanyOwnersQuery</param>
        /// <returns>It will return PaginatedList in the form of CompanyOwnerModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Companies_GetAllOwners")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetAllOwners")]
        public async Task<ActionResult<PaginatedList<CompanyOwnerModel>>> GetAllOwners([FromQuery] GetCompanyOwnersQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }
    }
}
