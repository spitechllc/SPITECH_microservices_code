﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.Queries.GetTimeZone;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.UserStoreManagement.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class TimeZoneController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<TimeZoneController> _logger;

        public TimeZoneController(IMediator mediator, ILogger<TimeZoneController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        /// <summary>
        ///  Method will return time zone details.
        /// </summary>
        ///  <param></param>
        /// <returns>It will return ResponseList in the form of TimeZoneModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_TimeZone_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet]
        public async Task<ActionResult<ResponseList<TimeZoneModel>>> Get()
        {
            return Ok(await _mediator.Send(new GetTimeZoneQuery()).ConfigureAwait(false));
        }
    }
}
