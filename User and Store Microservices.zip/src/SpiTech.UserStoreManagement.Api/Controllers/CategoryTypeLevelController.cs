﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.Queries.GetCategoryTypeLevel;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.UserStoreManagement.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class CategoryTypeLevelController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<CategoryTypeLevelController> _logger;
        public CategoryTypeLevelController(IMediator mediator, ILogger<CategoryTypeLevelController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        /// <summary>
        /// Method will return list of category type level for company category.
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of CategoryTypeLevelModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_CategoryTypeLevel_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("{categoryType}")]
        public async Task<ActionResult<ResponseList<CategoryTypeLevelModel>>> GetCategoryTypeLevel(string categoryType)
        {
            return Ok(await _mediator.Send(new GetCategoryTypeLevelQuery() { CategoryType = categoryType }).ConfigureAwait(false));
        }
    }
}
