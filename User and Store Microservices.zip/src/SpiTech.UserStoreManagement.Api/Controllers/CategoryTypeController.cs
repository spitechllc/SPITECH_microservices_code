﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.Queries.GetCategoryType;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.UserStoreManagement.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class CategoryTypeController : Controller
    {
        private readonly IMediator _mediator;
        private readonly ILogger<CategoryTypeController> _logger;

        public CategoryTypeController(IMediator mediator, ILogger<CategoryTypeController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        /// <summary>
        /// Method will return list of category type.
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of CategoryTypeModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_CategoryType_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet]
        public async Task<ActionResult<ResponseList<CategoryTypeModel>>> GetCategory()
        {
            return Ok(await _mediator.Send(new GetCategoryTypeQuery()).ConfigureAwait(false));
        }
    }
}
