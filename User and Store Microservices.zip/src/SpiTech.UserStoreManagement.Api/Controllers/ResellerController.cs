﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.UserStoreManagement.Application.Commands.CreateReseller;
using SpiTech.UserStoreManagement.Application.Commands.UpdateReseller;
using SpiTech.UserStoreManagement.Application.Queries.GetResellerById;
using SpiTech.UserStoreManagement.Application.Queries.GetResellerByIds;
using SpiTech.UserStoreManagement.Application.Queries.GetResellers;
using SpiTech.UserStoreManagement.Domain.Entities;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.UserStoreManagement.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class ResellerController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<ResellerController> _logger;

        public ResellerController(IMediator mediator, ILogger<ResellerController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }
        /// <summary>
        /// Method will return reseller details by reseller id.
        /// </summary>
        /// <param name="resellerId">Varriable of int</param>
        /// <returns>It will return in the form of ResellerModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Reseller_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("{resellerId}")]
        public async Task<ActionResult<ResellerModel>> GetById([FromRoute] int resellerId)
        {
            return Ok(await _mediator.Send(new GetResellerByIdQuery() { ResellerId = resellerId }).ConfigureAwait(false));
        }

        /// <summary>
        /// getbyids to get resellers by respective ids.
        /// </summary>
        /// <param name="request">Object of GetResellerByIdsQuery</param>
        /// <returns>It will return ResponseList in the form of Reseller</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Reseller_Resellers")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("Resellers")]
        public async Task<ActionResult<ResponseList<Reseller>>> GetByIds([FromBody] GetResellerByIdsQuery request)
        {
            return Ok(new ResponseList<ResellerModel>(await _mediator.Send(request).ConfigureAwait(false)));
        }

        /// <summary>
        /// Method will return reseller details list.
        /// </summary>
        /// <param name="query">Object of GetResellersQuery</param>
        /// <returns>It will return PaginatedList in the form of ResellerModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Reseller_GetAllResellers")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetAllResellers")]
        public async Task<ActionResult<PaginatedList<ResellerModel>>> GetAllResellers([FromQuery] GetResellersQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will use for create new saleagent
        /// </summary>
        /// <param name="command">Object of CreateResellerCommand</param>
        /// <returns>It will return in the form of Int</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Reseller_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost]
        public async Task<ActionResult<int>> Post([FromBody] CreateResellerCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }
        /// <summary>
        /// Method will update existing saleagent information 
        /// </summary>
        /// <param name="command">Object of UpdateResellerCommand</param>
        /// <returns>It will return in the form of bool</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Reseller_Patch")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch]
        public async Task<ActionResult<bool>> Update([FromBody] UpdateResellerCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }
    }
}
