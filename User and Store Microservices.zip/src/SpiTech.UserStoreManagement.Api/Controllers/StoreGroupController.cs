﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.Commands.CreateStoreGroup;
using SpiTech.UserStoreManagement.Application.Commands.MapUserWithStoreGroup;
using SpiTech.UserStoreManagement.Application.Commands.UpdateStoreGroup;
using SpiTech.UserStoreManagement.Application.Commands.UpdateUserMappingWithStoreGroup;
using SpiTech.UserStoreManagement.Application.Queries.GetStoreGroupAutoComplete;
using SpiTech.UserStoreManagement.Application.Queries.GetStoreGroups;
using SpiTech.UserStoreManagement.Application.Queries.GetStoreGroupStoresByUserId;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Net;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class StoreGroupController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly SpiTech.Application.Logging.Interfaces.ILogger<StoreGroupController> _logger;

        public StoreGroupController(IMediator mediator, SpiTech.Application.Logging.Interfaces.ILogger<StoreGroupController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        /// <summary>
        ///  Method will return all store groups 
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of StoreGroup</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_StoreGroup_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet]
        public async Task<ActionResult<ResponseList<StoreGroupModel>>> Get([FromQuery]GetStoreGroupsQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// StoreGroupAutoComplete to search storegroup by keywords.
        /// </summary>
        /// <param name="request">Object of GetStoreGroupAutoCompleteQuery</param>
        /// <returns>It will return ResponseList in the form of StoreGroupModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_StoreGroup_StoreGroupAutoComplete")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("StoreGroupAutoComplete")]
        public async Task<ActionResult<ResponseList<StoreGroup>>> StateAutoComplete([FromQuery] GetStoreGroupAutoCompleteQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }


        /// <summary>
        /// Method will be used for creating new storegroup.
        /// </summary>
        /// <param name="command">Object of CreateStoreGroupModel</param>
        /// <returns>It will return in the form of int</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_StoreGroup_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost]
        public async Task<ActionResult<int>> Post([FromBody] CreateStoreGroupCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));

        }
        /// <summary>
        /// Method will be used to update existing storegroup details
        /// </summary>
        /// <param name="command">Object of UpdateStoreGroupModel</param>
        /// <returns>It will return in the form of bool</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_StoreGroup_Patch")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch]
        public async Task<ActionResult<bool>> Update([FromBody] UpdateStoreGroupCommand command)
        {            
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }


        /// <summary>
        ///  Method will return all stores by userid
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of StoreGroupUserModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_StoreGroup_StoreGroupStoresByUserId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("StoreGroupStoresByUserId")]
        public async Task<ActionResult<ResponseList<StoreGroupUsersModel>>> GetStoreGroupStoresByUserId([FromQuery] GetStoreGroupStoresByUserIdQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will be used for creating new storegroup.
        /// </summary>
        /// <param name="model">Object of CreateStoreGroupModel</param>
        /// <returns>It will return in the form of int</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_StoreGroup_MapUserWithStoreGroup")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("MapUserWithStoreGroup")]
        public async Task<ActionResult<int>> MapUserWithStoreGroup([FromBody] MapUserWithStoreGroupCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));

        }

        /// <summary>
        /// Method will be used for creating new storegroup.
        /// </summary>
        /// <param name="model">Object of CreateStoreGroupModel</param>
        /// <returns>It will return in the form of int</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_StoreGroup_UpdateUserMappingWithStoreGroup")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch("UpdateUserMappingWithStoreGroup")]
        public async Task<ActionResult<int>> UpdateUserMappingWithStoreGroup([FromBody] UpdateUserMappingWithStoreGroupCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));

        }
    }
}