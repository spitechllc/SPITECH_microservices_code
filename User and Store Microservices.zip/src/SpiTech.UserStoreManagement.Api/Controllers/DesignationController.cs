﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.Queries.GetDesignation;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.UserStoreManagement.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class DesignationController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<DesignationController> _logger;

        public DesignationController(IMediator mediator, ILogger<DesignationController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }
        /// <summary>
        /// Method will return list of designations.
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of DesignationModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Designation_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet]
        public async Task<ActionResult<ResponseList<DesignationModel>>> GetDesignation()
        {
            return Ok(await _mediator.Send(new GetDesignationQuery()).ConfigureAwait(false));
        }
    }
}
