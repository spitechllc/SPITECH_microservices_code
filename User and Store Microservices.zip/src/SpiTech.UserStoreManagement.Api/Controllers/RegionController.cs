﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.Queries.GetRegion;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.UserStoreManagement.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class RegionController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<RegionController> _logger;
        public RegionController(IMediator mediator, ILogger<RegionController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }
        /// <summary>
        /// Method will return list of Regions.
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of RegionModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Region_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet]
        public async Task<ActionResult<ResponseList<RegionModel>>> GetRegion()
        {
            return Ok(await _mediator.Send(new GetRegionQuery()).ConfigureAwait(false));
        }
    }
}
