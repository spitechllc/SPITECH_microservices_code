﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.UserStoreManagement.Application.Commands.CreateUser;
using SpiTech.UserStoreManagement.Application.Commands.UpdateUser;
using SpiTech.UserStoreManagement.Application.Queries.GetUserByFilter;
using SpiTech.UserStoreManagement.Application.Queries.GetUserById;
using SpiTech.UserStoreManagement.Application.Queries.GetUserWithPaging;
using SpiTech.UserStoreManagement.Application.Queries.GetUserWithPrimaryDetails;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.UserStoreManagement.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<UsersController> _logger;

        public UsersController(IMediator mediator, ILogger<UsersController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        /// <summary>
        /// Method will return store particular store user information
        /// </summary>
        /// <param name="userId">Varriable of int</param>
        /// <returns>It will return in the form of UserModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Users_ByUserId")]
        [HttpGet("ByUserId/{userId}")]
        public async Task<ActionResult<UserModel>> GetUser(int userId)
        {
            return Ok(await _mediator.Send(new GetUserByIdQuery() { UserId = userId }).ConfigureAwait(false));
        }

        /// <summary>
        /// getUserWithPaging is to get paginated list of user
        /// </summary>
        /// <param name="request">Object of GetUserWithPagingQuery</param>
        /// <returns>It will return PaginatedList in the form of UserModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Users_WithPaging")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("WithPaging")]
        public async Task<ActionResult<PaginatedList<UserModel>>> GetUserWithPaging([FromQuery] GetUserWithPagingQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will return list of users availble under the entities e.g. Company, Store and User
        /// </summary>
        /// <param name="entityId">Varriable of int</param>
        /// <param name="entityName"> Object of EntityCategoryType and 1 for Company, 2 for Store, 3 for User</param>
        /// <returns>It will return ResponseList in the form of UserModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Users_ByEntityId")]
        [HttpGet("ByEntityId/{entityId}")]
        public async Task<ActionResult<ResponseList<UserModel>>> GetUserList([FromRoute] int entityId, [FromQuery] EntityCategoryType entityName)
        {
            return Ok(await _mediator.Send(new GetUserByFilterQuery() { EntityId = entityId, EntityType = entityName }).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will return user primary details by some fields
        /// </summary>
        /// <param name="entityId">Varriable of int </param>
        /// <param name="entityName">Object of EntityCategoryType</param>
        /// <returns>It will return in the form of UserUpdateModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Users_WithPrimaryDetails")]
        [HttpGet("WithPrimaryDetails/{entityId}")]
        public async Task<ActionResult<UserUpdateModel>> GetUserWithPrimaryDetails([FromRoute] int entityId, [FromQuery] EntityCategoryType entityName)
        {
            return Ok(await _mediator.Send(new GetUserWithPrimaryDetailsQuery() { entityId = entityId, entityType = entityName }).ConfigureAwait(false));
        }
        /// <summary>
        /// Method will create new store user 
        /// </summary>
        /// <param name="command">Varriable of int</param>
        /// <returns>It will return in the form of int</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Users_Post")]
        [HttpPost]
        public async Task<ActionResult<int>> Post([FromBody] CreateUserCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }
        /// <summary>
        /// Method will update existing store user 
        /// </summary>
        /// <param name="command">Object of UpdateUserCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Users_Patch")]
        [HttpPatch]
        public async Task<ActionResult<ResponseModel>> Update([FromBody] UpdateUserCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }
    }
}
