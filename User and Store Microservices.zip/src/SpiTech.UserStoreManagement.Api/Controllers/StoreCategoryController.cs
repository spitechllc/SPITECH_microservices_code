﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.Queries.GetStoreCategory;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.UserStoreManagement.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class StoreCategoryController : Controller
    {
        private readonly IMediator _mediator;
        private readonly ILogger<StoreCategoryController> _logger;

        public StoreCategoryController(IMediator mediator, ILogger<StoreCategoryController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        /// <summary>
        /// Method will return list of category type.
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of StoreCategoryModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_StoreCategory_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet]
        public async Task<ActionResult<ResponseList<StoreCategoryModel>>> GetStoreCategory()
        {
            return Ok(await _mediator.Send(new GetStoreCategoryQuery()).ConfigureAwait(false));
        }
    }
}
