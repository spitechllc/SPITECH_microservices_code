﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.UserStoreManagement.Application.Commands.AddSaleAgentStores;
using SpiTech.UserStoreManagement.Application.Commands.CreateStore;
using SpiTech.UserStoreManagement.Application.Commands.CreateStoreHours;
using SpiTech.UserStoreManagement.Application.Commands.DeleteStoreTanantMapping;
using SpiTech.UserStoreManagement.Application.Commands.UpdateStore;
using SpiTech.UserStoreManagement.Application.Commands.UpdateStoreHours;
using SpiTech.UserStoreManagement.Application.Queries.GetCompanyByStoreId;
using SpiTech.UserStoreManagement.Application.Queries.GetMasterStoreInfo;
using SpiTech.UserStoreManagement.Application.Queries.GetPosSystem;
using SpiTech.UserStoreManagement.Application.Queries.GetStoreAutoComplete;
using SpiTech.UserStoreManagement.Application.Queries.GetStoreByCompanyId;
using SpiTech.UserStoreManagement.Application.Queries.GetStoreByCompanyIds;
using SpiTech.UserStoreManagement.Application.Queries.GetStoreById;
using SpiTech.UserStoreManagement.Application.Queries.GetStoreBySiteId;
using SpiTech.UserStoreManagement.Application.Queries.GetStoreCount;
using SpiTech.UserStoreManagement.Application.Queries.GetStoreHoursByStoreId;
using SpiTech.UserStoreManagement.Application.Queries.GetStoreInfoById;
using SpiTech.UserStoreManagement.Application.Queries.GetStoreInfoByIds;
using SpiTech.UserStoreManagement.Application.Queries.GetStoreListByFilter;
using SpiTech.UserStoreManagement.Application.Queries.GetStoresForDashboard;
using SpiTech.UserStoreManagement.Application.Queries.GetStoresPrimaryDetailsBySiteIds;
using SpiTech.UserStoreManagement.Application.Queries.GetStoreSummaryById;
using SpiTech.UserStoreManagement.Application.Queries.GetStoreTenantMaster;
using SpiTech.UserStoreManagement.Application.Queries.GetStoreWithPaging;
using SpiTech.UserStoreManagement.Application.Queries.GetWeekDays;
using SpiTech.UserStoreManagement.Application.Queries.StoreSearch;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.FilterOptions;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.UserStoreManagement.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class StoresController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<StoresController> _logger;

        public StoresController(IMediator mediator, ILogger<StoresController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }
        /// <summary>
        /// StoreSearch to store by keywords.
        /// </summary>
        /// <param name="query">Object of StoreSearchQuery</param>
        /// <returns>It will return PaginatedList in the form of StoreSearchModel</returns>
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("search")]
        public async Task<ActionResult<PaginatedList<StoreSearchModel>>> StoreSearch([FromQuery] StoreSearchQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        ///  Method will return list of Store by Some particular field.
        /// </summary>
        /// <param name="filter">Object of StoreFilter</param>
        /// <param name="PageSize">Varriable of int</param>
        /// <param name="PageIndex">Varriable of int</param>
        /// <param name="sortable">Object of Sortable</param>
        /// <returns>It will return PaginatedList in the form of StoreModelForSummaryWithTenant</returns>
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("StoreSummary")]
        public async Task<ActionResult<PaginatedList<StoreModelForSummaryWithTenant>>> StoreSummary([FromQuery] StoreFilter filter, int? PageSize, int? PageIndex, [FromQuery] Sortable sortable)
        {
            return Ok(await _mediator.Send(new GetStoreSummaryByIdQuery { filter = filter, PageSize = PageSize, PageIndex = PageIndex, sortable = sortable}).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will return store details by store id.
        /// </summary>
        /// <param name="storeId">Varriable of int</param>
        /// <returns>It will return in the form of StoreSearchResult</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("{storeId}")]
        [AllowAnonymous]
        public async Task<ActionResult<StoreSearchResult>> GetById([FromRoute] int storeId)
        {
            return Ok(await _mediator.Send(new GetStoreByIdQuery() { StoreId = storeId }).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will return store details by Some particular field.
        /// </summary>
        /// <param name="filter">Object of StoreFilter</param>
        /// <param name="PageSize">Varriable of int</param>
        /// <param name="PageIndex">Varriable of int</param>
        /// <param name="sortable">Object of Sortable</param>
        /// <returns>It will return PaginatedList in the form of StoreSearchResult</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("StoresList")]
        [AllowAnonymous]
        public async Task<ActionResult<PaginatedList<StoreSearchResult>>> GetStores([FromQuery] StoreFilter filter, int? PageIndex, int? PageSize,
          [FromQuery] Sortable sortable)
        {
            return Ok(await _mediator.Send(new GetStoreListByFilterQuery { filter = filter, PageSize = PageSize, PageIndex = PageIndex, sortable = sortable }).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will return Master store infprmation.
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseModel in the form of StoreInfoModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_GetMasterStoreInfo")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetMasterStoreInfo")]
        public async Task<ActionResult<ResponseModel<StoreInfoModel>>> GetMasterStoreInfo()
        {
            return Ok(await _mediator.Send(new GetMasterStoreInfoQuery()).ConfigureAwait(false));
        }

        /// <summary>
        /// getStoreInfo to get resellers by respective ids.
        /// </summary>
        /// <param name="request">Object of GetStoreInfoByIdQuery</param>
        /// <returns>It will return ResponseModel in the form of StoreInfoModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_GetStoreInfo")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetStoreInfo")]
        public async Task<ActionResult<ResponseModel<StoreInfoModel>>> GetStoreInfo([FromQuery] GetStoreInfoByIdQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        /// getStoreInfo to get store by store ids.
        /// </summary>
        /// <param name="storeIds">Varriable of Int array</param>
        /// <returns>It will return ResponseList in the form of StoreInfoModel</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_StoreInfos")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("StoreInfos")]
        public async Task<ActionResult<ResponseList<StoreInfoModel>>> GetStoreInfo([FromBody] int[] storeIds)
        {
            var result = new ResponseList<StoreInfoModel>(await _mediator.Send(new GetStoreInfoByIdsQuery { StoreIds = storeIds }).ConfigureAwait(false));
            return Ok(result);
        }

        /// <summary>
        /// byCompanyId to get store company Detail by company ids.
        /// </summary>
        /// <param name="companyId">Varriable of int</param>
        /// <returns>It will return ResponseList in the form of StoreSearchResult</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_ByCompanyId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("ByCompanyId/{companyId}")]
        public async Task<ActionResult<ResponseList<StoreSearchResult>>> ByCompanyId(int companyId)
        {
            return Ok(await _mediator.Send(new GetStoreByCompanyIdQuery() { CompanyId = companyId }));
        }

        /// <summary>
        /// Method will use for create new store
        /// </summary>
        /// <param name="command">Object of CreateStoreCommand</param>
        /// <returns>It will return in the form of int</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_Post")]
        [HttpPost]
        public async Task<ActionResult<int>> Post([FromBody] CreateStoreCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will update existing store information 
        /// </summary>
        /// <param name="command">Object of UpdateStoreCommand</param>
        /// <returns>It will return in the form of bool</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_patch")]
        [HttpPatch]
        public async Task<ActionResult<bool>> Update([FromBody] UpdateStoreCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will return all weekdays 
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of WeekDaysModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_WeekDays")]
        [HttpGet("WeekDays")]
        public async Task<ActionResult<ResponseList<WeekDaysModel>>> GetWeekDays()
        {
            return Ok(await _mediator.Send(new GetWeekDaysQuery()).ConfigureAwait(false));
        }

        /// <summary>
        /// This method will add store working hours 
        /// </summary>
        /// <param name="command">Object of CreateStoreHoursCommand</param>
        /// <returns>It will return  in the form of int</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_HoursPost")]
        [HttpPost("Hours")]
        public async Task<ActionResult<int>> PostHours([FromBody] CreateStoreHoursCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// This method will update existing store working hours  
        /// </summary>
        /// <param name="command">Object of UpdateStoreHoursCommand</param>
        /// <returns>It will return in the form of int</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_HoursPatch")]
        [HttpPatch("Hours")]
        public async Task<ActionResult<int>> UpdateHours([FromBody] UpdateStoreHoursCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// for get all working hours details of particular store 
        /// </summary>
        /// <param name="storeId">Varriable of int</param>
        /// <returns>It will return ResponseList in the form of StoreHoursModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_Hours")]
        [HttpGet("Hours/{storeId}")]
        public async Task<ActionResult<ResponseList<StoreHoursModel>>> GetHours([FromRoute] int storeId)
        {
            return Ok(await _mediator.Send(new GetStoreHoursByStoreIdQuery() { StoreId = storeId }).ConfigureAwait(false));
        }

        /// <summary>
        /// GetStoreWithPaging is to get paginated list of store.
        /// </summary>
        /// <param name="request">Object of GetStoreWithPagingQuery</param>
        /// <returns>It will return PaginatedList in the form of StoresSearchModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_WithPaging")]
        [HttpGet("WithPaging")]
        public async Task<ActionResult<PaginatedList<StoresSearchModel>>> GetStoreWithPaging([FromQuery] GetStoreWithPagingQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will return store details by site id.
        /// </summary>
        /// <param name="request">Object of GetStoreBySiteIdQuery</param>
        /// <returns>It will return in the form of StoreSearchResult</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_StoreBySiteId")]
        [HttpGet("StoreBySiteId")]
        public async Task<ActionResult<StoreSearchResult>> GetStoreBySiteId([FromQuery] GetStoreBySiteIdQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        /// storeAutoComplete to search company by keywords.
        /// </summary>
        /// <param name="request">Object of StoreAutoCompleteQuery</param>
        /// <returns>It will return ResponseList in the form of StoreAutoCompleteModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_StoreAutoComplete")]
        [HttpGet("StoreAutoComplete")]
        public async Task<ActionResult<ResponseList<StoreAutoCompleteModel>>> StoreAutoComplete([FromQuery] StoreAutoCompleteQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        ///  Method will return store primary detailss by site id.
        /// </summary>
        /// <param name="request">Object of GetStoresPrimaryDetailsBySiteIdsQuery</param>
        /// <returns>It will return List in the form of StoreSearchResult</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_GetStoresPrimaryDetailsBySiteIds")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetStoresPrimaryDetailsBySiteIds")]
        public async Task<ActionResult<List<StoreSearchResult>>> GetStoresPrimaryDetailsBySiteIds([FromQuery] GetStoresPrimaryDetailsBySiteIdsQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        ///  Method will return store POS System list.
        /// </summary
        /// <param></param>
        /// <returns>It will return ResponseList in the form of PosSystem</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_PosSystem")]
        [HttpGet("PosSystem")]
        public async Task<ActionResult<ResponseList<PosSystem>>> GetPosSystem()
        {
            return Ok(await _mediator.Send(new GetPosSystemQuery()));
        }

        /// <summary>
        /// Method will update existing saleagent information 
        /// </summary>
        /// <param name="command">Object of AddSaleAgentStoresCommand</param>
        /// <returns>It will return in the form of bool</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_UpdateSaleAgent")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch("UpdateSaleAgent")]
        public async Task<ActionResult<bool>> UpdateSaleAgent([FromBody] AddSaleAgentStoresCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        ///  tetByCompanyIds to get company by respective ids.
        /// </summary
        /// <param name="query">Object of GetStoreByCompanyIdsQuery</param>
        /// <returns>It will return ResponseList in the form of StoreSearchResult</returns>
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_GetByCompanyIds")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("GetByCompanyIds")]
        public async Task<ActionResult<ResponseList<StoreSearchResult>>> GetByCompanyIds([FromBody] GetStoreByCompanyIdsQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_GetCompaniesByStoreId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetCompaniesByStoreId")]
        public async Task<ActionResult<ResponseList<StoreSearchResult>>> GetCompaniesByStoreId([FromQuery] GetCompanyByStoreIdQuery request)
        {
             return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        /// GetStoresForDashboard is to get response list of store.
        /// </summary>
        /// <param name="model">Object of GetStoresForDashboardModel</param>
        /// <returns>It will return ResponseList in the form of StoresSearchModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "UserStoreApi_Stores_ForDashboard")]
        [HttpPost("ForDashboard")]
        public async Task<ActionResult<ResponseList<StoresSearchModel>>> GetStoresForDashboard([FromBody] GetStoresForDashboardQuery request)
        {
            _logger.Warn("GetStoresForDashboard strat");
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        /// Get Total active store
        /// </summary>
        /// <returns></returns>        
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("StoreCount")]
        public async Task<ActionResult<int>> GetStoreCount([FromQuery] GetStoreCountQuery request)
        {
            _logger.Warn($"StoreCount begin");
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }
        /// <summary>
        ///  Method will return the list of tenant master 
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of StoreTenantMasterModel</returns>
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetStoreTenantMaster")]
        public async Task<ActionResult<ResponseList<StoreTenantMasterModel>>> GetStoreTenantMaster()
        {
            return Ok(await _mediator.Send(new GetStoreTenantMasterQuery()).ConfigureAwait(false));
        }
        /// <summary>
        /// Delete the Store Mapping Data.
        /// </summary>
        /// <param name="model">Object of GetStoresForDashboardModel</param>
        /// <returns>It will return ResponseList in the form of StoresSearchModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("DeleteStoreTanantMapping")]
        public async Task<ActionResult<string>> DeleteStoreTanantMapping([FromBody] DeleteStoreTanantMappingCommand request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }
    }
}
