using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using SpiTech.Application.Logging.Extensions;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.ApplicationCore.Security;
using SpiTech.ApplicationCore.ServiceCollection;
using SpiTech.Service.Clients;
using SpiTech.UserStoreManagement.Application;
using SpiTech.UserStoreManagement.Infrastructure;

namespace SpiTech.UserStoreManagement.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddApplicationCore(Configuration).AddInfrastructure(Configuration).AddApplication(Configuration);
            services.AddIdentityClient(Configuration).AddMppaClient(Configuration).AddTransactionClient(Configuration).AddPaymentClient(Configuration);          

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "UserStoreManagement Api",
                    Version = "v1",
                    Description = "The UserStoreManagement Microservice HTTP API.",
                });
                SwaggerGenSetup.Setup(options);
            });

            services.AddAPIAuthentication(Configuration, "userstoreapi");
            services.AddAPIAuthorization();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseMiddleware(typeof(CustomResponseHeaderMiddleware));
           
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            //app.UseGlobalExceptionHandler();

            app.UseSwagger().UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "SpiTech.UserStoreManagement.Api V1");
            });

            app.UseLogger();
            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();
            
            app.UseMiniProfiler();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
