﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface IStoreGroupStoresRepository : IRepository<StoreGroupStores>
    {
        Task<List<StoreGroupStoresModel>> GetByStoreGroupId(int StoreGroupId);
    }
}
