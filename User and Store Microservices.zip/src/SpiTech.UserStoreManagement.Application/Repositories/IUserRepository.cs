﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface IUserRepository : IRepository<User>
    {
        List<User> Get(int entityId, EntityCategoryType entityCategoryType);
        Task<List<UserModel>> GetUserWithPaging(string firstName, string lastName, string? roleId, int? storeId, string email, string phone, string storeName, int? pageIndex, int? pageSize, StoreUserSortBy? sortBy, SortOrderEnum? sortOrder,string statename, string City, string Zipcode);
        Task<List<UserModel>> GetUserByIdsWithPaging(List<int> ids, EntityCategoryType entityCategoryType);
        Task<User> GetUser(int entityId, EntityCategoryType entityCategoryType); 
        Task<List<UserModel>> GetOwnersWithPaging(string firstName, string lastName, string? roleId, int? storeId, string email, string phone, string storeName, int? pageIndex, int? pageSize, StoreUserSortBy? sortBy, SortOrderEnum? sortOrder, string statename, string city, string zipcode,int[] userIds);
    }
}
