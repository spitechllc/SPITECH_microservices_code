﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface IAmenityRepository : IRepository<Amenity>
    {
        Task<List<Amenity>> GetAllActive();
    }
}
