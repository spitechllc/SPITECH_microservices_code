﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface ISaleAgentRepository : IRepository<SaleAgent>
    {
        Task<List<SaleAgentModel>> GetSaleAgents(int[] saleAgentIds);
        Task<List<SaleAgentModel>> GetSaleAgentByFilters(string name, string mobile, string email, string storeName, int? skip, int? take, SaleAgentSortBy? sortBy, SortOrderEnum? sortOrder); 
    }
}
