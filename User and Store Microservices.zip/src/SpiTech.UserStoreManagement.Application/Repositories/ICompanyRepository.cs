﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface ICompanyRepository : IRepository<Company>
    {
        Task<Company> GetCompanyById(int id);
        Task<List<Company>> GetCompanyByUserId(int userid);
        Task<string> CheckCompany(string companyName, int id);
        Task<List<CompanyModel>> GetCompanyWithPaging(string CompanyName,string City,int?StateId,string ZipCode, int? Skip, int? Take, string SortBy, string SortOrder);

        Task<List<Company>> GetCompanyAutoComplete(int CompanyId, string CompanyName);
        Task<List<CompanySearchModel>> GetByResellerId(int resellerId);
        Task<List<CompanySearchModel>> GetByResellerIds(int[] resellerIds);
        Task<bool> UpdateCompanyReseller(int ResellerId, int[] CompanyIds);
        Task<bool> RemoveResellerfromCompanies(int[] comapnyIds);
        Task<bool> UpdateCompanyOwner(int OwnerId, int[] CompanyIds);
        Task<bool> RemoveOwnerfromCompanies(int[] comapnyIds);
        Task<List<CompanySearchModel>> GetByOwnerId(int ownerId);
        Task<List<CompanySearchModel>> GetByOwnerIds(int[] ownerIds);
        Task<string> GetCompaniesOwner(int ownerId, int[] companyIds);
        Task<string> GetCompaniesReseller(int resellerId, int[] companyIds);
    }
}
