﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface IEmailRepository : IRepository<Email>
    {
        List<Email> Get(int entityId, EntityCategoryType entityCategoryType);
        List<Email> GetEmailList(string[] entityIds, EntityCategoryType entityCategoryType);
        Task<Email> GetPrimaryEmail(int entityId, EntityCategoryType entityCategoryType);
        List<int> GetUserIdByEmail(string email);
        Task<Email> GetDuplicateEmail(int entityId, EntityCategoryType entityCategoryType,string email);
    }
}
