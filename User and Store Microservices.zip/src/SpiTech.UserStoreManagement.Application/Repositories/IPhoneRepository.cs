﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface IPhoneRepository : IRepository<Phone>
    {
        List<Phone> Get(int entityId, EntityCategoryType entityCategoryType);
        List<Phone> GetPhoneList(string[] entityIds, EntityCategoryType entityCategoryType);
        Task<Phone> GetPrimaryPhone(int entityId, EntityCategoryType entityCategoryType);
        List<int> GetUserIdByPhone(string phone);
    }
}
