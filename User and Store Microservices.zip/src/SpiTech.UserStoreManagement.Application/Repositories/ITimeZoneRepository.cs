﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface ITimeZoneRepository : IRepository<TimeZoneEntity>
    {
    }
}
