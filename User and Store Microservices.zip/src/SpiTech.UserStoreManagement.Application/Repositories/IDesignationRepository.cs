﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface IDesignationRepository : IRepository<Designation>
    {
        Task<IEnumerable<Designation>> GetDesignationById(int id);
        Task<IEnumerable<Designation>> GetDesignation();
    }
}
