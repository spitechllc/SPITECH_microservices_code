﻿using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.FilterOptions;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface IStoreRepository : IRepository<Store>
    {
        Task<StoreInfoModel> GetMasterStoreInfo();
        Task<List<StoreInfoModel>> GetStoreInfo(int[] storeIds);
        Task<StoreInfoModel> GetStoreInfo(int? storeId, string siteId);
        Task<List<StoreSearchResult>> GetByCompanyId(int companyId);
        Task<IEnumerable<StoreSearchResult>> GetStoreByFilter(StoreFilter filter, int? PageIndex, int? PageSize, Sortable sortable);
        Task<int> UpdateLogo(string url, int Storeid);
        Task<Store> GetStore(string siteId, int? storeId);
        Task<List<Store>> GetStoreAutoComplete(string siteId, string StoreName,int StoreId);
        Task<Store> ValidateSiteId(string SiteId, int? StoreId);
        Task<List<StoresSearchModel>> GetStoreWithPaging(int storeId, string storename, string siteId, string companyName, int? pageIndex, int? pageSize, string[] includeSiteIds, string[] excludeSiteIds, StoreSortBy? sortBy, SortOrderEnum? sortOrder, string statename, string city, string zipcode);
        Task<List<Store>> GetStoreBySiteIds(string[] siteIds);
        Task<List<StoreModelForSummary>> GetStoreSummaryById(int StoreId, int? Skip, int? Take, string SortBy, string SortOrder);
        Task<List<StoreSaleAgentModel>> GetBySaleAgentId(int saleAgentId);
        Task<List<StoreSaleAgentModel>> GetBySaleAgentIds(int[] saleAgentIds);
        Task<IEnumerable<StoreModelForSummary>> GetStoreSummaryByFilter(StoreFilter filter, int? PageIndex, int? PageSize, Sortable sortable);
       Task<IEnumerable<StoreSearchModel>> StoreSearch(int[] amenityIds, string longitude, string latitude, int distance, int pageIndex, int pageSize);
        Task<bool> UpdateStoresSaleAgent(int SaleAgentId, int[] Storeids);
        Task<bool> RemoveSaleAgentfromStores(int[] Storeids);
        Task<bool> UpdateStoresReseller(int ResellerId, int[] CompanyIds);
        Task<bool> RemoveResellerfromStores(int[] comapnyIds);
        Task<List<StoreSearchResult>> GetByCompanyIds(int[] companyIds, int? pageIndex, int? pageSize, StoreSortBy? sortBy, SortOrderEnum? sortOrder);
        Task<List<StoreSearchResult>> GetCompaniesByStoreId(int[] storeIds);
        Task<List<StoresSearchModel>> GetStoresForDashboard(int? stateId, string city, string zipcode, int? userId, string roleId, int? companyId, int[] storeGroupIds);
        Task<string> TotalStoreCount();
        Task<List<StoreTenantMasterModel>> GetStoreTenantMaster();
        Task<List<StoreTenantMappingUpdateModel>> GetStoreTenantByStoreIdandTenantId(int storeId, int Id);
        Task<string> GetStoreTenantMasterByTenantId(int TenantId);
        Task<int> AddStoreTenantMapping(int storeId, int tenantId);
        Task<int> UpdateStoreTenantMapping(int storeId, int Id, int tenantId);
        Task<List<StoreTenantMappingUpdateModel>> GetStoreTenantMasterByStoreId(int storeId);
        Task DeleteStoreTenantMasterByIds(int storeId, int id);
        Task<int> GetStoreIdByTenantId(int TenantId);
        Task<List<StoreTenantMappingUpdateModel>> GetStoreTenantMasterByStoreIds(int storeId);
        Task<List<StoreTenantMappingSearchModel>> GetStoreIdsByTenantId(int TenantId);
        Task<List<StoreTenantMappingUpdateModel>> GetStoreIdAndIdByTenantId(int storeId, int tenantId);
        Task<List<StoreTenantMappingUpdateModel>> GetStoreTenantByStoreIds(int storeId);
    }
}
