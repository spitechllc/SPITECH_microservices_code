﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface IStoreGroupUsersRepository : IRepository<StoreGroupUsers>
    {
        Task<List<StoreGroupUsers>> GetByStoreGroupId(int StoreGroupId);
        Task<List<StoreGroupUsersModel>> GetById(int StoreGroupUsersId);
        Task<List<StoreGroupUsersModel>> GetByUserId(int StoreGroupId);
    }
}
