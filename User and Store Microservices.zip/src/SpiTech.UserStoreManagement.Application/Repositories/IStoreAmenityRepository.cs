﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface IStoreAmenityRepository : IRepository<StoreAmenity>
    {
        Task<List<StoreAmenitySearchResult>> GetAmenityByStoreId(int StoreId);
        Task<List<StoreAmenityResultModel>> GetAmenityListByStoreIds(string[] storeIds);
    }
}
