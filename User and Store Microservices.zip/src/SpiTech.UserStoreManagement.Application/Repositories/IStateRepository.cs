﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface IStateRepository : IRepository<State>
    {
        Task<IEnumerable<State>> GetState(int? stateId = null);
        Task<IEnumerable<State>> GetStateByCountryId(int id);
        Task<List<State>> GetStateAutoComplete(int StateId, string StateName);
    }
}
