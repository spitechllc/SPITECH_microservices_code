﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface ICarWashTypeRepository : IRepository<CarWashType>
    {
        Task<List<CarWashTypeModel>> GetByStoreId(int StoreId);
        Task<List<CarWashTypeModel>> GetListByStoreIds(string[] StoreIds);
    }

}
