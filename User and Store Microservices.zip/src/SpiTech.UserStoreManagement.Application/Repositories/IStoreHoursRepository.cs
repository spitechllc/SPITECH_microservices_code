﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface IStoreHoursRepository : IRepository<StoreHours>
    {
        Task<List<StoreHours>> GetStoreHoursByStoreId(int StoreId);
        Task<List<StoreHoursResultModel>> GetStoreHoursListByStoreIds(string[] storeIds);
        Task<List<StoreHoursResult>> GetHoursByStoreId(int StoreId);
        Task<StoreHours> GetStoreHoursByWeekId(int StoreId, int WeekId);
    }
}
