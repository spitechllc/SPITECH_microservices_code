﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface IStoreGroupRepository : IRepository<StoreGroup>
    {
        Task<List<StoreGroupModel>> GetStoreGroup(int? StoreGroupId);
        Task<List<StoreGroup>> GetStoreGroupAutoComplete(int StoreGroupId, string StoreGroupName);
    }
}
