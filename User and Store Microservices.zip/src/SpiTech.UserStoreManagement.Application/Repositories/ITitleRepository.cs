﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface ITitleRepository : IRepository<Title>
    {
        Task<IEnumerable<Title>> GetTitle();
    }
}
