﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface IResellerRepository : IRepository<Reseller>
    {
        Task<List<ResellerModel>> GetResellers(int[] resellerIds);
        Task<List<ResellerModel>> GetResellerByFilters(string companyName, string name, string mobile, string email, string company, int? skip, int? take, ResellerSortBy? sortBy, SortOrderEnum? sortOrder); 
    }
}
