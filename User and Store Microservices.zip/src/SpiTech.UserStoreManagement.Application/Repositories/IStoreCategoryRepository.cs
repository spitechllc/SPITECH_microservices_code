﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface IStoreCategoryRepository : IRepository<StoreCategory>
    {
        Task<IEnumerable<StoreCategoryModel>> GetStoreCategoryById(int id);
        Task<IEnumerable<StoreCategoryModel>> GetStoreCategory();
    }
}
