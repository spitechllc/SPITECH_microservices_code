﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Repositories
{
    public interface IAddressRepository : IRepository<Address>
    {
        List<AddressModel> Get(int entityId, EntityCategoryType entityCategoryType);
        Task<AddressModel> GetPrimaryAddress(int entityId, EntityCategoryType entityCategoryType);
        List<AddressModel> GetPrimaryAddressStore(int entityId, EntityCategoryType entityCategoryType);
        Task<List<AddressModel>> GetPrimaryAddressStoreByIds(string[] entityIds, EntityCategoryType entityCategoryType);
    }
}
