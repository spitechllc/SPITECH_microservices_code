﻿using FluentValidation;
using SpiTech.UserStoreManagement.Application.CommonValidators;

namespace SpiTech.UserStoreManagement.Application.Commands.MapUserWithStoreGroup
{
    public class MapUserWithStoreGroupValidator : AbstractValidator<MapUserWithStoreGroupCommand>
    {
        public MapUserWithStoreGroupValidator()
        {
            RuleFor(x => x.StoreGroupId).NotNull().GreaterThan(0);
            RuleFor(x => x.UserIds).NotNull().NotEmpty();
        }
    }
}
