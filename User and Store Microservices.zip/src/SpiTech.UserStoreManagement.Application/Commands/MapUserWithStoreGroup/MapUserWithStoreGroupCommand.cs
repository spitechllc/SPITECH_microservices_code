﻿using MediatR;

namespace SpiTech.UserStoreManagement.Application.Commands.MapUserWithStoreGroup
{
    public class MapUserWithStoreGroupCommand : IRequest<int>
    {
        public int StoreGroupId { get; set; }

        public int[] UserIds { get; set; }

    }
}
