﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Commands.MapUserWithStoreGroup
{
    public class MapUserWithStoreGroupHandler : IRequestHandler<MapUserWithStoreGroupCommand, int>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<MapUserWithStoreGroupHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        public MapUserWithStoreGroupHandler(IMediator mediator,
                                   IMapper mapper,
                                   IUnitOfWork context,
                                   ILogger<MapUserWithStoreGroupHandler> logger)
        {
            _mediator = mediator;
            _mapper = mapper;
            _context = context;
            _logger = logger;
        }

        public async Task<int> Handle(MapUserWithStoreGroupCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
           
            int storeGroupUsersId = 0;

            try
            {
                foreach (var item in command.UserIds)
                {
                    storeGroupUsersId = await _context.StoreGroupUsers.Add(new Domain.Entities.StoreGroupUsers
                    {
                        StoreGroupId = command.StoreGroupId,
                        UserId = item,
                    });

                    _context.Commit();
                }
            }
            catch (Exception ex)
            {
                _context.Rollback();
                _logger.Error(ex);
              
                throw;
            }

            _logger.TraceExitMethod(nameof(Handle), storeGroupUsersId);

            return await Task.FromResult(storeGroupUsersId);
        }

       
    }
}