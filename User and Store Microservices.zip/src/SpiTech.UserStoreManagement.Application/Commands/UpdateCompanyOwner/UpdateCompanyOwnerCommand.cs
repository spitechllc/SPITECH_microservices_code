﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateCompanyOwner
{
    public class UpdateCompanyOwnerCommand : IRequest<ResponseModel>
    {
       public UserUpdateModel Owners { get; set; }
    }
}
