﻿using FluentValidation;
using SpiTech.UserStoreManagement.Application.CommonValidators;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateCompanyOwner
{
    public class UpdateCompanyOwnerValidator : AbstractValidator<UpdateCompanyOwnerCommand>
    {
        public UpdateCompanyOwnerValidator()
        {
             RuleFor(q => q.Owners).SetValidator(new UserUpdateModelValidator());

        }
    }
}
