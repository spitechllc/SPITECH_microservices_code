﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Service.Clients.Execeptions;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateCompanyOwner
{
    public class UpdateCompanyOwnerHandler : IRequestHandler<UpdateCompanyOwnerCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateCompanyOwnerHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IIdentityServiceClient identityapiclient;

        public UpdateCompanyOwnerHandler(IUnitOfWork context,
                                    ILogger<UpdateCompanyOwnerHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper,
                                    IIdentityServiceClient identityclient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            identityapiclient = identityclient;
        }

        public async Task<ResponseModel> Handle(UpdateCompanyOwnerCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
           
            bool userId = false;

           
                try
                {
                if (command.Owners != null)
                {
                    #region check duplicate category
                    foreach (PhoneModel phone in command.Owners.Phones)
                    {
                        int chkphonecategory = command.Owners.Phones.Count(x => x.CategoryTypeLevelId == phone.CategoryTypeLevelId);
                        if (chkphonecategory > 1)
                        {
                            throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Phone Category"));
                        }
                    }
                    foreach (EmailModel email in command.Owners.Emails)
                    {
                        int chkemailcategory = command.Owners.Emails.Count(x => x.CategoryTypeLevelId == email.CategoryTypeLevelId);
                        if (chkemailcategory > 1)
                        {
                            throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Email Category"));
                        }
                    }
                    foreach (AddressModel address in command.Owners.Addresses)
                    {
                        int chkaddresscategory = command.Owners.Addresses.Count(x => x.CategoryTypeLevelId == address.CategoryTypeLevelId);
                        if (chkaddresscategory > 1)
                        {
                            throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Address Category"));
                        }
                    }
                    #endregion

                    //user.UserId==Todo httpClient to Post User to identity Server
                    Service.Clients.Identity.UpdateProfileCommand updateuser = new()
                    {
                        UserId = command.Owners.UserId,
                        FirstName = command.Owners.FirstName,
                        LastName = command.Owners.LastName,
                    };

                    foreach (AddressModel addr in command.Owners.Addresses)
                    {
                        if (addr.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.UserAddressMain)
                        {
                            updateuser.AddressLine1 = addr.AddressLine1;
                            updateuser.AddressLine2 = addr.AddressLine1;
                            updateuser.City = addr.City;
                            updateuser.State = addr.StateId.ToString();
                            updateuser.Country = addr.CountryId.ToString();
                            updateuser.Latitude = addr.Latitude.ToString();
                            updateuser.Longitude = addr.Longitude.ToString();
                            updateuser.ZipCode = addr.ZipCode;
                        }
                    }
                    foreach (EmailModel email in command.Owners.Emails)
                    {
                        if (email.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.UserEmailMain)
                        {
                            updateuser.Email = email.Email;
                        }
                    }

                    foreach (PhoneModel phn in command.Owners.Phones)
                    {
                        if (phn.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.UserPhoneMain)
                        {
                            updateuser.MobileNumber = phn.Number;
                            updateuser.CountryCode = phn.CountryCode;
                        }
                    }
                    try
                    {
                        Service.Clients.Identity.UserSearchResultResponseModel userUpdateProfile = await identityapiclient.UpdateProfileAsync(updateuser);
                        if (userUpdateProfile == null)
                        {
                            throw new ValidationException(new ValidationFailure("User", $"Some Error Occured"));
                        }
                    }
                    catch (ApiException<Service.Clients.Identity.ValidationProblemDetails> validationex)
                    {
                        throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
                    }
                    userId = await _context.Users.Update(new Domain.Entities.User
                    {
                        UserId = command.Owners.UserId,
                        FirstName = command.Owners.FirstName,
                        LastName = command.Owners.LastName,
                        RegionId = command.Owners.RegionId,
                        Title = command.Owners.Title,
                        DesignationId = command.Owners.DesignationId,
                    });

                    await AddUpdate(command.Owners.Phones, command.Owners.Emails, command.Owners.Addresses, command.Owners);
                }
                }
                catch (Exception)
                {
                    _context.Rollback();
                    throw;
                }
                _logger.TraceExitMethod(nameof(Handle), userId);

                await Task.FromResult(userId);
                return new ResponseModel() { Success = true, Message = "Success" };
           
           
        }

       

        private async Task AddUpdate(IEnumerable<PhoneModel> phones, IEnumerable<EmailModel> emails, IEnumerable<AddressModel> addresses, UserUpdateModel user)
        {
            try
            {
                int AddressId = 0;

                if (phones != null)
                {
                    List<Phone> phoneList = _context.Phones.Get(user.UserId, EntityCategoryType.User);

                    foreach (PhoneModel phone in phones)
                    {
                        Phone model = new()
                        {
                            PhoneId = phone.PhoneId,
                            AreaCode = phone.AreaCode,
                            CompanyId = null,
                            UserId = user.UserId,
                            StoreId = null,
                            PhoneNumber = phone.Number,
                            CountryCode = phone.CountryCode,
                            CategoryTypeLevelId = phone.CategoryTypeLevelId,
                            IsActive = phone.IsActive
                        };

                        if (phone.PhoneId <= 0)
                        {
                            phone.PhoneId = await _context.Phones.Add(model);
                        }
                        else
                        {
                            await _context.Phones.Update(model);
                        }
                    }

                    foreach (Phone phone in phoneList)
                    {
                        PhoneModel deletedphone = phones.FirstOrDefault(t => t.PhoneId == phone.PhoneId);
                        if (deletedphone == null)
                        {

                            phone.IsActive = false;
                            await _context.Phones.Update(phone);
                        }
                    }
                }

                if (emails != null)
                {
                    List<Email> emailList = _context.Emails.Get(user.UserId, EntityCategoryType.User);

                    foreach (EmailModel email in emails)
                    {
                      
                        Email model = new()
                        {
                            EmailId = email.EmailId,
                            CategoryTypeLevelId = email.CategoryTypeLevelId,
                            EmailAddress = email.Email,
                            CompanyId = null,
                            UserId = user.UserId,
                            StoreId = null,
                            IsActive = email.IsActive

                        };

                        if (email.EmailId <= 0)
                        {
                            email.EmailId = await _context.Emails.Add(model);
                        }
                        else
                        {
                            await _context.Emails.Update(model);
                        }


                    }
                    foreach (Email email in emailList)
                    {
                        EmailModel deletedemail = emails.FirstOrDefault(t => t.EmailId == email.EmailId);
                        if (deletedemail == null)
                        {
                            email.IsActive = false;
                            await _context.Emails.Update(email);
                        }
                    }
                }

                if (addresses != null && addresses.Count() > 0)
                {
                    List<AddressModel> addresseslList = _context.Addresses.Get(user.UserId, EntityCategoryType.User);

                    foreach (AddressModel address in addresses)
                    {
                        Address model = new()
                        {
                            AddressId = address.AddressId,
                            CategoryTypeLevelId = address.CategoryTypeLevelId,//TODO
                            AddressLine1 = address.AddressLine1,
                            AddressLine2 = address.AddressLine2,
                            City = address.City,
                            StateId = address.StateId,
                            CountryId = address.CountryId,
                            Latitude = address.Latitude,
                            Longitude = address.Longitude,
                            ZipCode = address.ZipCode,
                            CompanyId = null,
                            UserId = user.UserId,
                            StoreId = null,
                            IsActive = address.IsActive
                        };

                        if (address.AddressId <= 0)
                        {
                            address.AddressId = await _context.Addresses.Add(model);
                        }
                        else
                        {
                            await _context.Addresses.Update(model);
                        }

                        if (address.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.UserAddressMain)
                        {
                            AddressId = address.AddressId;
                        }

                    }
                    foreach (AddressModel address in addresseslList)
                    {
                        AddressModel deletedaddress = addresses.FirstOrDefault(t => t.AddressId == address.AddressId);
                        if (deletedaddress == null)
                        {
                            Address storeAddress = _mapper.Map<Address>(address);
                            storeAddress.IsActive = false;
                            await _context.Addresses.Update(storeAddress);
                        }
                    }
                }

            }
            catch (Exception) { };
        }

       

    }
}