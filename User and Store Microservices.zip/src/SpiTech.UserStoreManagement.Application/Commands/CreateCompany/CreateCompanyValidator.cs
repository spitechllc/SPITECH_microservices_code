﻿using FluentValidation;
using SpiTech.UserStoreManagement.Application.CommonValidators;

namespace SpiTech.UserStoreManagement.Application.Commands.CreateCompany
{
    public class CreateCompanyValidator : AbstractValidator<CreateCompanyCommand>
    {
        public CreateCompanyValidator()
        {
            RuleFor(x => x.Name).NotNull().Length(1, 200);

            RuleForEach(x => x.Addresses).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Addresses).SetValidator(new AddressModelValidator());
            });

            RuleForEach(x => x.Emails).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Emails).SetValidator(new EmailModelValidator());
            });

            RuleForEach(x => x.Phones).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Phones).SetValidator(new PhoneModelValidator());
            });

           // RuleFor(q => q.Owners).SetValidator(new UserValidator());
        }
    }
}
