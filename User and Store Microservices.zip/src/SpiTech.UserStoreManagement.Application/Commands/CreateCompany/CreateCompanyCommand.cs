﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Application.Commands.CreateCompany
{
    public class CreateCompanyCommand : IRequest<int>
    {
        public string Name { get; set; }
        public string Url { get; set; }
        public string Note { get; set; }
        public string MCC_SICNumber { get; set; }

        public IEnumerable<AddressModel> Addresses { get; set; }
        public IEnumerable<PhoneModel> Phones { get; set; }
        public IEnumerable<EmailModel> Emails { get; set; }
        // public UserModel Owners { get; set; }
        public ICollection<string> RoleIds { get; set; }
    }
}
