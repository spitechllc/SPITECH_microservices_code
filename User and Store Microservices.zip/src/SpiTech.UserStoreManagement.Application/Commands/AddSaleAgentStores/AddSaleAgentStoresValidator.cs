﻿using FluentValidation;
using SpiTech.UserStoreManagement.Application.CommonValidators;

namespace SpiTech.UserStoreManagement.Application.Commands.AddSaleAgentStores
{
    public class AddSaleAgentStoresValidator : AbstractValidator<AddSaleAgentStoresCommand>
    {
        public AddSaleAgentStoresValidator()
        {
            RuleFor(x => x.SaleAgentId).GreaterThan(0).WithMessage("SaleAgentId is required");
            RuleFor(x => x.StoreIds).NotNull().NotEmpty();
        }
    }
}
