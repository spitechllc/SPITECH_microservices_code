﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Application.Commands.AddSaleAgentStores
{
    public class AddSaleAgentStoresCommand : IRequest<bool>
    {
        public int[] StoreIds { get; set; }
        public int SaleAgentId { get; set; }

    }
}
