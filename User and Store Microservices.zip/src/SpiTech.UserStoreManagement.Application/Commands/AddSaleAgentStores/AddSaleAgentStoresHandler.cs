﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Store;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Commands.AddSaleAgentStores
{
    public class AddSaleAgentStoresHandler : IRequestHandler<AddSaleAgentStoresCommand, bool>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<AddSaleAgentStoresHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        public AddSaleAgentStoresHandler(IMediator mediator,
                                   IMapper mapper,
                                   IUnitOfWork context,
                                   ILogger<AddSaleAgentStoresHandler> logger)
        {
            _mediator = mediator;
            _mapper = mapper;
            _context = context;
            _logger = logger;
        }

        public async Task<bool> Handle(AddSaleAgentStoresCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            List<int> deletedStores = new List<int>();
            var dbstore = await _context.Stores.GetBySaleAgentId(command.SaleAgentId);
            if (dbstore != null)
            {
                foreach (var store in dbstore)
                {

                    if (!command.StoreIds.Contains(store.StoreId))
                    {
                        deletedStores.Add(store.StoreId);
                    }
                }

            }
            //assign saleagent id to stores
            var res = await _context.Stores.UpdateStoresSaleAgent(command.SaleAgentId, command.StoreIds);

            //remove saaleagentid from stores
            if (deletedStores.Count() > 0)
            {
                var deleteSaleAgent = await _context.Stores.RemoveSaleAgentfromStores(deletedStores.ToArray());
            }
            _context.Commit();
            _logger.TraceExitMethod(nameof(Handle), res);

            return res;
        }


    }
}