﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.Service.Clients.Execeptions;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateCompany
{
    public class UpdateCompanyHandler : IRequestHandler<UpdateCompanyCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateCompanyHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IIdentityServiceClient identityapiclient;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IEventDispatcher _eventDispatcher;
        private string emailids;

        public UpdateCompanyHandler(IUnitOfWork context,
                                    ILogger<UpdateCompanyHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper,
                                    IIdentityServiceClient identityclient,
                                    IUserAuthenticationProvider userAuthenticationProvider,
                                    IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            identityapiclient = identityclient;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _eventDispatcher = eventDispatcher;
        }

        public async Task<ResponseModel> Handle(UpdateCompanyCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            string companyname = await _context.Companies.CheckCompany(command.Name, command.Id);
            bool companyId = false;

            if (companyname == null)
            {
                #region check duplicate category
                foreach (PhoneModel phone in command.Phones)
                {
                    int chkphonecategory = command.Phones.Count(x => x.CategoryTypeLevelId == phone.CategoryTypeLevelId);
                    if (chkphonecategory > 1)
                    {
                        throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Phone Category"));
                    }
                }
                foreach (EmailModel email in command.Emails)
                {
                    int chkemailcategory = command.Emails.Count(x => x.CategoryTypeLevelId == email.CategoryTypeLevelId);
                    if (chkemailcategory > 1)
                    {
                        throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Email Category"));
                    }
                }
                foreach (AddressModel address in command.Addresses)
                {
                    int chkaddresscategory = command.Addresses.Count(x => x.CategoryTypeLevelId == address.CategoryTypeLevelId);
                    if (chkaddresscategory > 1)
                    {
                        throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Address Category"));
                    }
                }
                #endregion
                try
                {
                    companyId = await _context.Companies.Update(new Domain.Entities.Company
                    {
                        Id = command.Id,
                        Name = command.Name,
                        Note = command.Note,
                        Url = command.Url,
                        MCC_SICNumber = command.MCC_SICNumber,
                        IsActive = command.IsActive
                    });

                   // await UpdateUser(command.Owners, command.Id);
                    await UpdateCompany(command.Phones, command.Emails, command.Addresses, command.Id);
                    _context.Commit();
                    await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.UpdateCompany, "Company Updated.", false, null);
                }
                catch (Exception ex)
                {
                    _context.Rollback();
                    await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.UpdateCompany, "Company Updation Failed.", true, ex.Message);
                    throw;
                }
                _logger.TraceExitMethod(nameof(Handle), companyId);

                await Task.FromResult(companyId);
                return new ResponseModel() { Success = true, Message = "Success" };
            }
            else
            {
                return new ResponseModel() { Success = false, Message = "Company Name Already Exist" };
            }
        }

        private async Task UpdateUser(UserUpdateModel user, int companyId)
        {
            if (user != null)
            {
                #region check duplicate category
                foreach (PhoneModel phone in user.Phones)
                {
                    int chkphonecategory = user.Phones.Count(x => x.CategoryTypeLevelId == phone.CategoryTypeLevelId);
                    if (chkphonecategory > 1)
                    {
                        throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Phone Category"));
                    }
                }
                foreach (EmailModel email in user.Emails)
                {
                    int chkemailcategory = user.Emails.Count(x => x.CategoryTypeLevelId == email.CategoryTypeLevelId);
                    if (chkemailcategory > 1)
                    {
                        throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Email Category"));
                    }
                }
                foreach (AddressModel address in user.Addresses)
                {
                    int chkaddresscategory = user.Addresses.Count(x => x.CategoryTypeLevelId == address.CategoryTypeLevelId);
                    if (chkaddresscategory > 1)
                    {
                        throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Address Category"));
                    }
                }
                #endregion

                //user.UserId==Todo httpClient to Post User to identity Server
                Service.Clients.Identity.UpdateProfileCommand updateuser = new()
                {
                    UserId = user.UserId,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    CompanyId = user.CompanyId
                };

                foreach (AddressModel addr in user.Addresses)
                {
                    if (addr.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.UserAddressMain)
                    {
                        updateuser.AddressLine1 = addr.AddressLine1;
                        updateuser.AddressLine2 = addr.AddressLine1;
                        updateuser.City = addr.City;
                        updateuser.State = addr.StateId.ToString();
                        updateuser.Country = addr.CountryId.ToString();
                        updateuser.Latitude = addr.Latitude.ToString();
                        updateuser.Longitude = addr.Longitude.ToString();
                        updateuser.ZipCode = addr.ZipCode;
                    }
                }
                foreach (EmailModel email in user.Emails)
                {
                    if (email.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.UserEmailMain)
                    {
                        updateuser.Email = email.Email;
                    }
                }

                foreach (PhoneModel phn in user.Phones)
                {
                    if (phn.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.UserPhoneMain)
                    {
                        updateuser.MobileNumber = phn.Number;
                        updateuser.CountryCode = phn.CountryCode;
                    }
                }
                try
                {
                    Service.Clients.Identity.UserSearchResultResponseModel userUpdateProfile = await identityapiclient.UpdateProfileAsync(updateuser);
                    if (userUpdateProfile == null)
                    {
                        throw new ValidationException(new ValidationFailure("User", $"Some Error Occured"));
                    }
                }
                catch (ApiException<Service.Clients.Identity.ValidationProblemDetails> validationex)
                {
                    throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
                }
                bool userId = await _context.Users.Update(new Domain.Entities.User
                {
                    UserId = user.UserId,
                    CompanyId = companyId,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    RegionId = user.RegionId,
                    Title = user.Title,
                    DesignationId = user.DesignationId,
                });

                await AddUpdate(user.Phones, user.Emails, user.Addresses, user);

            }
        }

        private async Task AddUpdate(IEnumerable<PhoneModel> phones, IEnumerable<EmailModel> emails, IEnumerable<AddressModel> addresses, UserUpdateModel user)
        {
            try
            {
                int AddressId = 0;

                if (phones != null)
                {
                    List<Phone> phoneList = _context.Phones.Get(user.UserId, EntityCategoryType.User);

                    foreach (PhoneModel phone in phones)
                    {
                        Phone model = new()
                        {
                            PhoneId = phone.PhoneId,
                            AreaCode = phone.AreaCode,
                            CompanyId = null,
                            UserId = user.UserId,
                            StoreId = null,
                            PhoneNumber = phone.Number,
                            CountryCode = phone.CountryCode,
                            CategoryTypeLevelId = phone.CategoryTypeLevelId,
                            IsActive = phone.IsActive
                        };

                        if (phone.PhoneId <= 0)
                        {
                            phone.PhoneId = await _context.Phones.Add(model);
                        }
                        else
                        {
                            await _context.Phones.Update(model);
                        }
                    }

                    foreach (Phone phone in phoneList)
                    {
                        PhoneModel deletedphone = phones.FirstOrDefault(t => t.PhoneId == phone.PhoneId);
                        if (deletedphone == null)
                        {

                            phone.IsActive = false;
                            await _context.Phones.Update(phone);
                        }
                    }
                }

                if (emails != null)
                {
                    List<Email> emailList = _context.Emails.Get(user.UserId, EntityCategoryType.User);

                    foreach (EmailModel email in emails)
                    {
                        emailids = email.Email + ",";
                        Email model = new()
                        {
                            EmailId = email.EmailId,
                            CategoryTypeLevelId = email.CategoryTypeLevelId,
                            EmailAddress = email.Email,
                            CompanyId = null,
                            UserId = user.UserId,
                            StoreId = null,
                            IsActive = email.IsActive

                        };

                        if (email.EmailId <= 0)
                        {
                            email.EmailId = await _context.Emails.Add(model);
                        }
                        else
                        {
                            await _context.Emails.Update(model);
                        }


                    }
                    foreach (Email email in emailList)
                    {
                        EmailModel deletedemail = emails.FirstOrDefault(t => t.EmailId == email.EmailId);
                        if (deletedemail == null)
                        {
                            email.IsActive = false;
                            await _context.Emails.Update(email);
                        }
                    }
                }

                if (addresses != null && addresses.Count() > 0)
                {
                    List<AddressModel> addresseslList = _context.Addresses.Get(user.UserId, EntityCategoryType.User);

                    foreach (AddressModel address in addresses)
                    {
                        Address model = new()
                        {
                            AddressId = address.AddressId,
                            CategoryTypeLevelId = address.CategoryTypeLevelId,//TODO
                            AddressLine1 = address.AddressLine1,
                            AddressLine2 = address.AddressLine2,
                            City = address.City,
                            StateId = address.StateId,
                            CountryId = address.CountryId,
                            Latitude = address.Latitude,
                            Longitude = address.Longitude,
                            ZipCode = address.ZipCode,
                            CompanyId = null,
                            UserId = user.UserId,
                            StoreId = null,
                            IsActive = address.IsActive
                        };

                        if (address.AddressId <= 0)
                        {
                            address.AddressId = await _context.Addresses.Add(model);
                        }
                        else
                        {
                            await _context.Addresses.Update(model);
                        }

                        if (address.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.UserAddressMain)
                        {
                            AddressId = address.AddressId;
                        }

                    }
                    foreach (AddressModel address in addresseslList)
                    {
                        AddressModel deletedaddress = addresses.FirstOrDefault(t => t.AddressId == address.AddressId);
                        if (deletedaddress == null)
                        {
                            Address storeAddress = _mapper.Map<Address>(address);
                            storeAddress.IsActive = false;
                            await _context.Addresses.Update(storeAddress);
                        }
                    }
                }

            }
            catch (Exception) { };
        }

        private async Task UpdateCompany(IEnumerable<PhoneModel> phones, IEnumerable<EmailModel> emails, IEnumerable<AddressModel> addresses, int CompanyId)
        {

            int AddressId = 0;

            if (phones != null)
            {
                List<Phone> phoneList = _context.Phones.Get(CompanyId, EntityCategoryType.Company);

                foreach (PhoneModel phone in phones)
                {
                    Phone model = new()
                    {
                        PhoneId = phone.PhoneId,
                        AreaCode = phone.AreaCode,
                        CompanyId = CompanyId,
                        UserId = null,
                        PhoneNumber = phone.Number,
                        CountryCode = phone.CountryCode,
                        CategoryTypeLevelId = phone.CategoryTypeLevelId,
                        IsActive = phone.IsActive
                    };

                    if (phone.PhoneId <= 0)
                    {
                        phone.PhoneId = await _context.Phones.Add(model);
                    }
                    else
                    {
                        await _context.Phones.Update(model);
                    }
                }

                foreach (Phone phone in phoneList)
                {
                    PhoneModel deletedphone = phones.FirstOrDefault(t => t.PhoneId == phone.PhoneId);
                    if (deletedphone == null)
                    {
                        phone.IsActive = false;
                        await _context.Phones.Update(phone);
                    }
                }
            }

            if (emails != null)
            {
                List<Email> emailList = _context.Emails.Get(CompanyId, EntityCategoryType.Company);

                foreach (EmailModel email in emails)
                {
                    emailids = email.Email + ",";
                    Email model = new()
                    {
                        EmailId = email.EmailId,
                        CategoryTypeLevelId = email.CategoryTypeLevelId,
                        EmailAddress = email.Email,
                        CompanyId = CompanyId,
                        UserId = null,
                        StoreId = null,
                        IsActive = email.IsActive

                    };

                    if (email.EmailId <= 0)
                    {
                        email.EmailId = await _context.Emails.Add(model);
                    }
                    else
                    {
                        await _context.Emails.Update(model);
                    }


                }
                foreach (Email email in emailList)
                {
                    EmailModel deletedemail = emails.FirstOrDefault(t => t.EmailId == email.EmailId);
                    if (deletedemail == null)
                    {
                        email.IsActive = false;
                        await _context.Emails.Update(email);
                    }
                }
            }

            if (addresses != null && addresses.Count() > 0)
            {
                List<AddressModel> addresseslList = _context.Addresses.Get(CompanyId, EntityCategoryType.Company);

                foreach (AddressModel address in addresses)
                {
                    Address addrmodel = new()
                    {
                        AddressId = address.AddressId,
                        CategoryTypeLevelId = address.CategoryTypeLevelId,//TODO
                        AddressLine1 = address.AddressLine1,
                        AddressLine2 = address.AddressLine2,
                        City = address.City,
                        StateId = address.StateId,
                        CountryId = address.CountryId,
                        Latitude = address.Latitude,
                        Longitude = address.Longitude,
                        ZipCode = address.ZipCode,
                        CompanyId = CompanyId,
                        UserId = null,
                        IsActive = address.IsActive
                    };

                    if (address.AddressId <= 0)
                    {
                        address.AddressId = await _context.Addresses.Add(addrmodel);
                    }
                    else
                    {
                        await _context.Addresses.Update(addrmodel);
                    }

                    if (address.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.CompanyAddressMain)
                    {
                        AddressId = address.AddressId;
                    }

                }
                foreach (AddressModel address in addresseslList)
                {
                    AddressModel deletedaddress = addresses.Where(t => t.AddressId == address.AddressId).FirstOrDefault();
                    if (deletedaddress == null)
                    {
                        Address storeAddress = _mapper.Map<Address>(address);
                        storeAddress.IsActive = false;
                        await _context.Addresses.Update(storeAddress);
                    }
                }
            }
        }

        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = "",
                IsError = isError,
                ErrorMessage = errorMessage

            });
        }
    }
}