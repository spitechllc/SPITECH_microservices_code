﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateCompany
{
    public class UpdateCompanyCommand : IRequest<ResponseModel>
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Url { get; set; }
        public string Note { get; set; }
        public string MCC_SICNumber { get; set; }
        public bool IsActive { get; set; } = true;

        public IEnumerable<AddressModel> Addresses { get; set; }
        public IEnumerable<PhoneModel> Phones { get; set; }
        public IEnumerable<EmailModel> Emails { get; set; }
       // public UserUpdateModel Owners { get; set; }
    }
}
