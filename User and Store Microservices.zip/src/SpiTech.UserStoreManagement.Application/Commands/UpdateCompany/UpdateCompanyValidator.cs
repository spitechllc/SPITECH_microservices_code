﻿using FluentValidation;
using SpiTech.UserStoreManagement.Application.CommonValidators;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateCompany
{
    public class UpdateCompanyValidator : AbstractValidator<UpdateCompanyCommand>
    {
        public UpdateCompanyValidator()
        {
            RuleFor(x => x.Name).NotNull().Length(1, 50);
            // RuleFor(x => x.Url).NotNull().Length(1, 50);

            RuleForEach(x => x.Addresses).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Addresses).SetValidator(new AddressModelValidator());
            });

            RuleForEach(x => x.Emails).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Emails).SetValidator(new EmailModelValidator());
            });

            RuleForEach(x => x.Phones).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Phones).SetValidator(new PhoneModelValidator());
            });


          //  RuleFor(q => q.Owners).SetValidator(new UserUpdateModelValidator());

        }
    }
}
