﻿using FluentValidation;
using SpiTech.UserStoreManagement.Application.CommonValidators;

namespace SpiTech.UserStoreManagement.Application.Commands.AddResellerCompany
{
    public class AddResellerCompanyValidator : AbstractValidator<AddResellerCompanyCommand>
    {
        public AddResellerCompanyValidator()
        {
            RuleFor(x => x.ResellerId).GreaterThan(0).WithMessage("ResellerId is required");
            RuleFor(x => x.CompanyIds).NotNull().NotEmpty();
        }
    }
}
