﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Application.Commands.AddResellerCompany
{
    public class AddResellerCompanyCommand : IRequest<bool>
    {
        public int[] CompanyIds { get; set; }
        public int ResellerId { get; set; }

    }
}
