﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Store;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Commands.AddResellerCompany
{
    public class AddResellerCompanyHandler : IRequestHandler<AddResellerCompanyCommand, bool>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<AddResellerCompanyHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        public AddResellerCompanyHandler(IMediator mediator,
                                   IMapper mapper,
                                   IUnitOfWork context,
                                   ILogger<AddResellerCompanyHandler> logger)
        {
            _mediator = mediator;
            _mapper = mapper;
            _context = context;
            _logger = logger;
        }

        public async Task<bool> Handle(AddResellerCompanyCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            List<int> deletedCompanies = new List<int>();
            var dbcompany = await _context.Companies.GetByResellerId(command.ResellerId);
            if (dbcompany != null)
            {
                foreach (var company in dbcompany)
                {

                    if (!command.CompanyIds.Contains(company.Id))
                    {
                        deletedCompanies.Add(company.Id);
                    }
                }

            }
            string companyReseller = await _context.Companies.GetCompaniesReseller(command.ResellerId, command.CompanyIds);
            if (!string.IsNullOrEmpty(companyReseller))
            {
                throw new ValidationException(new ValidationFailure("Company", $"Company "+ companyReseller+" already assigned to anoter reseller"));
            }
            //assign reseller id to companies
            var res = await _context.Companies.UpdateCompanyReseller(command.ResellerId, command.CompanyIds);
            //assign reseller id to stores
            var storeRes = await _context.Stores.UpdateStoresReseller(command.ResellerId, command.CompanyIds);

            //remove reseller from companies
            if (deletedCompanies.Count() > 0)
            {
                var deleteResellerStore = await _context.Stores.RemoveResellerfromStores(deletedCompanies.ToArray());
                var deleteReseller = await _context.Companies.RemoveResellerfromCompanies(deletedCompanies.ToArray());
            }
            _context.Commit();
            _logger.TraceExitMethod(nameof(Handle), res);

            return res;
        }


    }
}