﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateStoreHours
{
    public class UpdateStoreHoursCommand : IRequest<int>
    {
        public bool Is24Hours { get; set; }
        public int StoreId { get; set; }
        public IEnumerable<StoreHoursModel> StoreHours { get; set; }
    }
}
