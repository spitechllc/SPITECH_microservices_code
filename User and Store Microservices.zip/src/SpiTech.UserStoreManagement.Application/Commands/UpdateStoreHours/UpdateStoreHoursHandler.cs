﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateStoreHours
{
    public class UpdateStoreHoursHandler : IRequestHandler<UpdateStoreHoursCommand, int>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateStoreHoursHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public UpdateStoreHoursHandler(IUnitOfWork context,
                                    ILogger<UpdateStoreHoursHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<int> Handle(UpdateStoreHoursCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            try
            {
                if (command.Is24Hours)
                {
                    System.Collections.Generic.IEnumerable<Domain.Entities.WeekDays> weekdays = await _context.WeekDays.GetAll();
                    foreach (Domain.Entities.WeekDays wday in weekdays)
                    {
                        Domain.Entities.StoreHours model = new()
                        {
                            WeekDayId = wday.WeekDayId,
                            OpenTime = "23:59",
                            CloseTime = "12:00",
                            StoreId = command.StoreId,
                            Is24Hours = command.Is24Hours
                        };

                        Domain.Entities.StoreHours sthour = await _context.StoreHours.GetStoreHoursByWeekId(command.StoreId, wday.WeekDayId);
                        if (sthour == null)
                        {
                            await _context.StoreHours.Add(model);
                        }
                        else
                        {
                            model.StoreHoursId = sthour.StoreHoursId;
                            await _context.StoreHours.Update(model);
                        }
                    }
                }
                else
                {
                    foreach (Domain.Models.StoreHoursModel storehour in command.StoreHours)
                    {

                        Domain.Entities.StoreHours model = new()
                        {
                            WeekDayId = storehour.WeekDayId,
                            StoreId = command.StoreId,
                            OpenTime = storehour.OpenTime,
                            CloseTime = storehour.CloseTime,
                            StoreHoursId = storehour.StoreHoursId
                        };

                        await _context.StoreHours.Update(model);
                    }
                }
                _context.Commit();
            }
            catch (Exception ex)
            {
                _context.Rollback();
                _logger.Error(ex);
                throw;
            }

            _logger.TraceEnterMethod(nameof(Handle), command);

            return await Task.FromResult(1);
        }
    }
}