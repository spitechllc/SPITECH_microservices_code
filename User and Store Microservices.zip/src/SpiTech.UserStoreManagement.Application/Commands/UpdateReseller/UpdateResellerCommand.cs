﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediatR;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateReseller
{
    public class UpdateResellerCommand : IRequest<bool>
    {
        public int ResellerId { get; set; }
        public string CompanyName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public IEnumerable<AddressModel> Addresses { get; set; }
        public IEnumerable<PhoneModel> Phones { get; set; }
        public IEnumerable<EmailModel> Emails { get; set; }
    }
}                                                                                                 
