﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Commands.CreateReseller
{
    public class CreateResellerHandler : IRequestHandler<CreateResellerCommand, int>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateResellerHandler> _logger;
        private readonly IStorageService storageService;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        public CreateResellerHandler(IMediator mediator,
                                   IMapper mapper,
                                   IUnitOfWork context,
                                   ILogger<CreateResellerHandler> logger,
                                   IStorageServiceFactory storageServiceFactory,
                                   IEventDispatcher eventDispatcher,
                                   IUserAuthenticationProvider userAuthenticationProvider)
        {
            _mediator = mediator;
            _mapper = mapper;
            _context = context;
            _logger = logger;
            this.storageService = storageServiceFactory.Get(ContainerType.StoreImages);
            _eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<int> Handle(CreateResellerCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

          
            var resellerId = 0;

            try
            {
                resellerId = await _context.Resellers.Add(new Domain.Entities.Reseller
                {
                    CompanyName=command.CompanyName,
                    FirstName = command.FirstName,
                    LastName = command.LastName
                });

            var res = await Add(command.Phones, command.Emails, command.Addresses, resellerId);
                _context.Commit();
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.CreateReseller, "Reseller Added.", false, null);
            }
            catch (Exception ex)
            {
                _context.Rollback();
                _logger.Error(ex);
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.CreateReseller, "Add Reseller Failed.", true, ex.Message);
                throw;
            }

            _logger.TraceExitMethod(nameof(Handle), resellerId);

          
            return await Task.FromResult(resellerId);
        }
        private async Task<bool> Add(IEnumerable<PhoneModel> phones, IEnumerable<EmailModel> emails, IEnumerable<AddressModel> addresses, int ResellerId)
        {

           
            if (phones != null)
            {
                foreach (var phone in phones)
                {
                    phone.PhoneId = await _context.Phones.Add(new Domain.Entities.Phone
                    {
                        AreaCode = phone.AreaCode,
                        CompanyId = null,
                        UserId = null,
                        ResellerId = ResellerId,
                        PhoneNumber = phone.Number,
                        CountryCode = phone.CountryCode,
                        CategoryTypeLevelId = phone.CategoryTypeLevelId
                    });
                }
            }

            if (emails != null)
            {
                foreach (var email in emails)
                {
                    email.EmailId = await _context.Emails.Add(new Domain.Entities.Email
                    {
                        CategoryTypeLevelId = email.CategoryTypeLevelId,
                        EmailAddress = email.Email,
                        CompanyId = null,
                        UserId = null,
                        ResellerId = ResellerId
                    });
                }
            }

            if (addresses != null)
            {

                foreach (var address in addresses)
                {

                    address.AddressId = await _context.Addresses.Add(new Domain.Entities.Address
                    {
                        CategoryTypeLevelId = address.CategoryTypeLevelId,//TODO
                        AddressLine1 = address.AddressLine1,
                        AddressLine2 = address.AddressLine2,
                        City = address.City,
                        StateId = address.StateId,
                        CountryId = address.CountryId,
                        Latitude = address.Latitude,
                        Longitude = address.Longitude,
                        ZipCode = address.ZipCode,
                        CompanyId = null,
                        UserId = null,
                        ResellerId = ResellerId
                    });

                   
                }
            }


            return true;
        }

        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = "",
                IsError = isError,
                ErrorMessage = errorMessage

            });
        }
    }
}