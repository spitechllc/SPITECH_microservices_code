﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateStoreGroup
{
    public class UpdateStoreGroupHandler : IRequestHandler<UpdateStoreGroupCommand, bool>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateStoreGroupHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        public UpdateStoreGroupHandler(IMediator mediator,
                                   IMapper mapper,
                                   IUnitOfWork context,
                                   ILogger<UpdateStoreGroupHandler> logger)
        {
            _mediator = mediator;
            _mapper = mapper;
            _context = context;
            _logger = logger;
        }

        public async Task<bool> Handle(UpdateStoreGroupCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            bool result = false;
            StoreGroup dbstoregroup = await _context.StoreGroups.Get(command.StoreGroupId);
            if (dbstoregroup == null)
            {
                throw new ValidationException(new ValidationFailure("StoreGroupId", $"StoreGroup does not exist"));
            }

            StoreGroup storeGroupmodel = new()
            {
                StoreGroupId = command.StoreGroupId,
                StoreGroupName = command.StoreGroupName,
                IsActive = command.IsActive,
            };

            if (command.Stores != null)
            {
                IEnumerable<StoreGroupStores> storeGroupStoresList = _mapper.Map<IEnumerable<StoreGroupStores>>(await _context.StoreGroupStores.GetByStoreGroupId(command.StoreGroupId));

                foreach (var item in command.Stores)
                {
                    bool stt = false;
                    int id = 0;
                    if (storeGroupStoresList != null && storeGroupStoresList.Count() > 0)
                    {
                        var data = storeGroupStoresList?.Where(t => t.StoreId == item).FirstOrDefault();

                        if (data != null)
                        {
                            id = data.StoreGroupStoresId;
                            stt = true;
                        }
                        else
                        {
                            id = 0;
                            stt = true;
                        }
                    }
                    StoreGroupStores model = new()
                    {
                        StoreGroupStoresId = id,
                        StoreGroupId = command.StoreGroupId,
                        StoreId = item,
                        IsActive = stt
                    };

                    if (id <= 0)
                    {
                        id = await _context.StoreGroupStores.Add(model);
                    }
                    else
                    {
                        await _context.StoreGroupStores.Update(model);
                    }
                }

                foreach (StoreGroupStores stores in storeGroupStoresList)
                {
                    int storeId = command.Stores.Where(t => t == stores.StoreId).FirstOrDefault();

                    StoreGroupStoresModel deletedstores = _mapper.Map<StoreGroupStoresModel>(storeGroupStoresList?.Where(t => t.StoreId == storeId).FirstOrDefault());
                    if (deletedstores == null)
                    {
                        stores.IsActive = false;
                        await _context.StoreGroupStores.Update(stores);
                    }

                }
            }
                if (command.Users != null)
                {
                    IEnumerable<StoreGroupUsers> storeGroupUsersList = await _context.StoreGroupUsers.GetByStoreGroupId(command.StoreGroupId);

                    foreach (var item in command.Users)
                    {
                        bool stt = false;
                        int id = 0;
                        if (storeGroupUsersList != null && storeGroupUsersList.Count() > 0)
                        {
                            var data = storeGroupUsersList?.Where(t => t.UserId == item).FirstOrDefault();

                            if (data != null)
                            {
                                id = data.StoreGroupUsersId;
                                stt = true;
                            }
                            else
                            {

                                id = 0;
                                stt = true;
                            }
                        }
                        StoreGroupUsers model = new()
                        {
                            StoreGroupUsersId = id,
                            StoreGroupId = command.StoreGroupId,
                            UserId = item,
                            IsActive = stt
                        };

                        if (id <= 0)
                        {
                            id = await _context.StoreGroupUsers.Add(model);
                        }
                        else
                        {
                            await _context.StoreGroupUsers.Update(model);
                        }
                    }
                }

                try
                {
                    result = await _context.StoreGroups.Update(storeGroupmodel);


                    _context.Commit();
                    _logger.TraceExitMethod(nameof(Handle), result);
                    return await Task.FromResult(result);
                }
                catch (Exception ex)
                {
                    _context.Rollback();
                    _logger.Error(ex);
                    throw;
                }

            

        }
    }
}
