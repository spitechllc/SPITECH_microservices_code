﻿using FluentValidation;
using SpiTech.UserStoreManagement.Application.CommonValidators;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateStoreGroup
{
    public class UpdateStoreGroupValidator : AbstractValidator<UpdateStoreGroupCommand>
    {
        public UpdateStoreGroupValidator()
        {
            RuleFor(x => x.StoreGroupName).NotNull().Length(1, 200);
        }
    }

}
