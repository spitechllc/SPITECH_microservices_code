﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateStoreGroup
{
    public class UpdateStoreGroupCommand : IRequest<bool>
    {
        public int StoreGroupId { get; set; }
        public string StoreGroupName { get; set; }
        // public IEnumerable<StoreGroupStoresModel> Stores { get; set; }
        public int[] Stores { get; set; }
        public int[] Users { get; set; }
        public bool IsActive { get; set; }
    }
}
