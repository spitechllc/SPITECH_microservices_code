﻿using FluentValidation;
using SpiTech.UserStoreManagement.Application.CommonValidators;

namespace SpiTech.UserStoreManagement.Application.Commands.CreateStore
{
    public class CreateStorValidator : AbstractValidator<CreateStoreCommand>
    {
        public CreateStorValidator()
        {
            RuleFor(x => x.StoreName).NotNull().WithMessage("StoreName is required").Length(1, 200);
            RuleFor(x => x.SiteId).NotNull().WithMessage("SiteId is required").Length(1, 50).WithMessage("SiteId must be between 1 to 50 character.");

            RuleForEach(x => x.Addresses).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Addresses).SetValidator(new AddressModelValidator());
            });

            RuleForEach(x => x.Emails).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Emails).SetValidator(new EmailModelValidator());
            });

            RuleForEach(x => x.Phones).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Phones).SetValidator(new PhoneModelValidator());
            });

            RuleForEach(x => x.Amenities).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Amenities).SetValidator(new StoreAmenityValidator());
            });

            RuleFor(x => x.MaxAuthorizeAmount).GreaterThan(0).WithMessage("MaxAuthorizeAmount is required");
        }
    }
}
