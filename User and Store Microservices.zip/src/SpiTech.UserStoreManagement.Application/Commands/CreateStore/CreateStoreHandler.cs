﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents.Events.Store;
using SpiTech.UserStoreManagement.Application.Queries.GetCarWashTypeByStoreId;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using static IdentityServer4.Models.IdentityResources;

namespace SpiTech.UserStoreManagement.Application.Commands.CreateStore
{
    public class CreateStoreHandler : IRequestHandler<CreateStoreCommand, int>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateStoreHandler> _logger;
        private readonly IStorageService storageService;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        public CreateStoreHandler(IMediator mediator,
                                   IMapper mapper,
                                   IUnitOfWork context,
                                   ILogger<CreateStoreHandler> logger,
                                   IStorageServiceFactory storageServiceFactory,
                                   IEventDispatcher eventDispatcher, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _mediator = mediator;
            _mapper = mapper;
            _context = context;
            _logger = logger;
            storageService = storageServiceFactory.Get(ContainerType.StoreImages);
            _eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<int> Handle(CreateStoreCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            int resellerId = 0;
            Domain.Entities.Store dbstore = await _context.Stores.ValidateSiteId(command.SiteId, 0);
            CompanyModel companyModel = _mapper.Map<CompanyModel>(await _context.Companies.GetCompanyById(command.CompanyId));
            if (dbstore != null)
            {
                throw new ValidationException(new ValidationFailure("SiteId", $"SiteId already exist"));
            }
            if (companyModel != null)
            {
                if (companyModel.ResellerId.HasValue)
                {
                    resellerId = (int)companyModel.ResellerId;
                }
            }
            #region check duplicate category
            foreach (PhoneModel phone in command.Phones)
            {
                int chkphonecategory = command.Phones.Count(x => x.CategoryTypeLevelId == phone.CategoryTypeLevelId);
                if (chkphonecategory > 1)
                {
                    throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Phone Category"));
                }
            }
            foreach (EmailModel email in command.Emails)
            {
                int chkemailcategory = command.Emails.Count(x => x.CategoryTypeLevelId == email.CategoryTypeLevelId);
                if (chkemailcategory > 1)
                {
                    throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Email Category"));
                }

                //Email emailModel = await _context.Emails.Get(email.Email);
                //if (emailModel != null)
                //{
                //    throw new ValidationException(new ValidationFailure("Email", $"Email already exist"));
                //}
            }
            foreach (AddressModel address in command.Addresses)
            {
                int chkaddresscategory = command.Addresses.Count(x => x.CategoryTypeLevelId == address.CategoryTypeLevelId);
                if (chkaddresscategory > 1)
                {
                    throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Address Category"));
                }
            }
            #endregion

            int storeId = 0;
            int addressId = 0;
            string Azurefileurl = string.Empty;

            try
            {
                storeId = await _context.Stores.Add(new Domain.Entities.Store
                {
                    StoreName = command.StoreName,
                    SiteId = command.SiteId,
                    StoreUrl = command.StoreUrl,
                    MangerId = command.ManagerId.Value,
                    RegionId = command.RegionId,
                    RegionalManagerId = command.RegionManagerId,
                    PosId = command.POSId,
                    PosName = command.PosName,
                    Description = command.Description,
                    Note = command.Note,
                    TimeZoneId = command.TimeZoneId,
                    CompanyId = command.CompanyId,
                    MaxAuthorizeAmount = command.MaxAuthorizeAmount,
                    EnableBilling = command.EnableBilling,
                    ConsentCashReward = command.ConsentCashReward,
                    SaleAgentId = command.SaleAgentId,
                    DisableBilling = command.DisableBilling,
                    DisableEod = command.DisableEod,
                    EnableACHLoyalty = command.EnableACHLoyalty,
                    EnableCardLoyalty = command.EnableCardLoyalty,
                    LoyaltyProgramId = command.LoyaltyProgramId,
                    ResellerId = resellerId,
                    StoreCategoryId = command.StoreCategoryId

                });

                #region upload image over Azure
                if (!string.IsNullOrEmpty(command.StoreImage))
                {

                    if (!((command.StoreImage.Length % 4 == 0) && Regex.IsMatch(command.StoreImage, @"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.None)))
                    {
                        throw new ValidationException(new ValidationFailure("StoreImage", $"Invalid base64"));
                    }
                    else
                    {
                        string filename = storeId + "_" + UniqueIdGenerator.Generate() + "_storelogo.jpeg";
                        Azurefileurl = await SaveImage(command.StoreImage, filename);

                        if (!string.IsNullOrEmpty(Azurefileurl))
                        {
                            await _context.Stores.UpdateLogo(Azurefileurl, storeId);
                        }
                    }
                }
                #endregion
                addressId = await Add(command.Phones, command.Emails, command.Addresses, command.Amenities, storeId, command.AppIds);
                _context.Commit();
            }
            catch (Exception ex)
            {
                _context.Rollback();
                _logger.Error(ex);
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.AddStore, "Store Creation Failed.", true, ex.Message);
                throw;
            }

            _logger.TraceExitMethod(nameof(Handle), storeId);

            AddressModel addressEvent = command.Addresses?.Where(x => x.CategoryTypeLevelId ==
            (int)PrimaryCategoryTypeLevel.StoreAddressMain).FirstOrDefault();
            await DispachStoreEvent(command, storeId, addressId, Azurefileurl, addressEvent);
            await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.AddStore, "New Store Created.", false, null);
            return await Task.FromResult(storeId);
        }

        private async Task DispachStoreEvent(CreateStoreCommand command,
                                            int storeId,
                                            int addressId,
                                            string storeImage,
                                            AddressModel address)
        {
            StoreEvent storeEvent = new()
            {
                IsCreated = true,
                StoreId = storeId,
                StoreName = command.StoreName,
                SiteId = command.SiteId,
                StoreUrl = command.StoreUrl,
                Description = command.Description,
                Note = command.Note,
                StoreImage = storeImage,
                MaxAuthorizeAmount = command.MaxAuthorizeAmount
            };

            if (command.Emails != null)
            {
                storeEvent.EmailIds = string.Join(",", command.Emails.Select(x => x.Email));
            }

            if (command.Phones != null)
            {
                storeEvent.PhoneNos = string.Join(",", command.Phones.Select(x => x.Number));
            }

            if (address != null)
            {
                storeEvent.AddressId = addressId;
                storeEvent.CategoryTypeLevelId = address.CategoryTypeLevelId;
                storeEvent.AddressLine1 = address.AddressLine1;
                storeEvent.AddressLine2 = address.AddressLine2;
                storeEvent.City = address.City;
                storeEvent.CountryId = address.CountryId;
                storeEvent.Country = address.Country;
                storeEvent.StateId = address.StateId;
                storeEvent.State = address.State;
                storeEvent.Longitude = address.Longitude;
                storeEvent.Latitude = address.Latitude;
                storeEvent.ZipCode = address.ZipCode;
                storeEvent.CompanyId = command.CompanyId;
            }

            await _eventDispatcher.Dispatch(storeEvent);
        }

        private async Task<string> SaveImage(string base64image, string filename)
        {
            await storageService.UploadBlob(base64image, filename);
            Blob res = await storageService.GetFile(filename);
            return res != null ? res.StorageUri : string.Empty;
        }

        private async Task<int> Add(IEnumerable<PhoneModel> phones, IEnumerable<EmailModel> emails, IEnumerable<AddressModel> addresses, IEnumerable<StoreAmenityModel> Amenities, int StoreId, int[] AppIds)
        {

            int AddressId = 0;
            if (phones != null)
            {
                foreach (PhoneModel phone in phones)
                {
                    phone.PhoneId = await _context.Phones.Add(new Domain.Entities.Phone
                    {
                        AreaCode = phone.AreaCode,
                        CompanyId = null,
                        UserId = null,
                        StoreId = StoreId,
                        PhoneNumber = phone.Number,
                        CountryCode = phone.CountryCode,
                        CategoryTypeLevelId = phone.CategoryTypeLevelId
                    });
                }
            }

            if (emails != null)
            {
                foreach (EmailModel email in emails)
                {
                    email.EmailId = await _context.Emails.Add(new Domain.Entities.Email
                    {
                        CategoryTypeLevelId = email.CategoryTypeLevelId,
                        EmailAddress = email.Email,
                        CompanyId = null,
                        UserId = null,
                        StoreId = StoreId
                    });
                }
            }

            if (addresses != null)
            {

                foreach (AddressModel address in addresses)
                {

                    address.AddressId = await _context.Addresses.Add(new Domain.Entities.Address
                    {
                        CategoryTypeLevelId = address.CategoryTypeLevelId,//TODO
                        AddressLine1 = address.AddressLine1,
                        AddressLine2 = address.AddressLine2,
                        City = address.City,
                        StateId = address.StateId,
                        CountryId = address.CountryId,
                        Latitude = address.Latitude,
                        Longitude = address.Longitude,
                        ZipCode = address.ZipCode,
                        CompanyId = null,
                        UserId = null,
                        StoreId = StoreId
                    });

                    if (address.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.StoreAddressMain)
                    {
                        AddressId = address.AddressId;
                    }

                }
            }

            if (Amenities != null)
            {
                foreach (StoreAmenityModel amenity in Amenities)
                {
                    amenity.StoreAmenityId = await _context.StoreAmenities.Add(new Domain.Entities.StoreAmenity
                    {
                        AmenityId = amenity.AmenityId,
                        StoreId = StoreId
                    });
                }
            }

            if (AppIds != null)
            {
                for (int i = 0; i < AppIds.Length; i++)
                {
                    int storeIds = StoreId;
                    int tenantId = AppIds[i];
                    await _context.Stores.AddStoreTenantMapping(storeIds, tenantId);
                    _context.Commit();
                }
            }
            else
            {
                int storeIds = StoreId;
                int tenantId = 1;
                await _context.Stores.AddStoreTenantMapping(storeIds, tenantId);
                _context.Commit();
            }

            return AddressId;
        }

        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = "",
                IsError = isError,
                ErrorMessage = errorMessage
            });
        }
    }
}