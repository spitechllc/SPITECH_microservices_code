﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Application.Commands.CreateStore
{
    public class CreateStoreCommand : IRequest<int>
    {
        public string StoreName { get; set; }

        public string SiteId { get; set; }
        public string StoreUrl { get; set; }
        public int? ManagerId { get; set; }
        public int RegionId { get; set; }
        public int RegionManagerId { get; set; }
        public int POSId { get; set; }
        public string PosName { get; set; }
        public string Description { get; set; }
        public string Note { get; set; }
        public int TimeZoneId { get; set; }
        public string StoreImage { get; set; }
        public bool IsActive { get; set; } = true;

        public int CompanyId { get; set; }
        public decimal MaxAuthorizeAmount { get; set; }
        public bool? EnableBilling { get; set; }
        public bool? ConsentCashReward { get; set; }
        public int? SaleAgentId { get; set; }
        public bool DisableEod { get; set; }
        public bool DisableBilling { get; set; }

        public bool EnableACHLoyalty { get; set; }
        public bool EnableCardLoyalty { get; set; }
        public string LoyaltyProgramId { get; set; }
        public int? StoreCategoryId { get; set; }

        public IEnumerable<AddressModel> Addresses { get; set; }
        public IEnumerable<PhoneModel> Phones { get; set; }
        public IEnumerable<EmailModel> Emails { get; set; }

        public IEnumerable<StoreAmenityModel> Amenities { get; set; }
        public int[] AppIds { get; set; }

    }
}
