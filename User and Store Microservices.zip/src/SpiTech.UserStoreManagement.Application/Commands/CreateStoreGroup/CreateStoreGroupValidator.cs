﻿using FluentValidation;
using SpiTech.UserStoreManagement.Application.CommonValidators;

namespace SpiTech.UserStoreManagement.Application.Commands.CreateStoreGroup
{
    public class CreateStoreGroupValidator : AbstractValidator<CreateStoreGroupCommand>
    {
        public CreateStoreGroupValidator()
        {
            RuleFor(x => x.StoreGroupName).NotNull().WithMessage("StoreGroupName is required").Length(1, 200);
        }
    }
}
