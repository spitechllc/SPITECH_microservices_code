﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Commands.CreateStoreGroup
{
    public class CreateStoreGroupHandler : IRequestHandler<CreateStoreGroupCommand, int>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateStoreGroupHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        public CreateStoreGroupHandler(IMediator mediator,
                                   IMapper mapper,
                                   IUnitOfWork context,
                                   ILogger<CreateStoreGroupHandler> logger)
        {
            _mediator = mediator;
            _mapper = mapper;
            _context = context;
            _logger = logger;
        }

        public async Task<int> Handle(CreateStoreGroupCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
           

            int storeGroupId = 0;
            int storeGroupStoresId = 0;
            int storeGroupUsersId = 0;

            try
            {
                storeGroupId= await _context.StoreGroups.Add(new Domain.Entities.StoreGroup
                {
                    StoreGroupName = command.StoreGroupName,
                });

                foreach (var item in command.Stores)
                {
                    storeGroupStoresId = await _context.StoreGroupStores.Add(new Domain.Entities.StoreGroupStores
                    {
                        StoreGroupId = storeGroupId,
                        StoreId = item,
                    });
                }
                foreach (var item in command.UserIds)
                {
                    storeGroupUsersId = await _context.StoreGroupUsers.Add(new Domain.Entities.StoreGroupUsers
                    {
                        StoreGroupId = storeGroupId,
                        UserId = item,
                    });

                }
                _context.Commit();
            }
            catch (Exception ex)
            {
                _context.Rollback();
                _logger.Error(ex);
              
                throw;
            }

            _logger.TraceExitMethod(nameof(Handle), storeGroupId);

            return await Task.FromResult(storeGroupId);
        }

       
    }
}