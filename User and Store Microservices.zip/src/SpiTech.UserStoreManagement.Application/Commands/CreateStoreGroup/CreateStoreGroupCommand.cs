﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Application.Commands.CreateStoreGroup
{
    public class CreateStoreGroupCommand : IRequest<int>
    {
        public string StoreGroupName { get; set; }

       // public IEnumerable<StoreGroupStoresModel> Stores { get; set; }
        public int[] Stores { get; set; }
        public int[] UserIds { get; set; }
        public bool IsActive { get; set; } = true;
    }
}
