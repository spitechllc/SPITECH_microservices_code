﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Store;
using SpiTech.Service.Clients.Identity;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Commands.CreateUser
{
    public class CreateUserHandler : IRequestHandler<CreateUserCommand, int>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateUserHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IIdentityServiceClient identityapiclient;
        private readonly IEventDispatcher eventDispatcher;

        public CreateUserHandler(IUnitOfWork context,
                                    ILogger<CreateUserHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper,
                                    IIdentityServiceClient identityclient,
                                    IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            identityapiclient = identityclient;
            this.eventDispatcher = eventDispatcher;
        }

        public async Task<int> Handle(CreateUserCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            #region check duplicate category

            if (command.Phones != null)
            {
                foreach (PhoneModel phone in command.Phones)
                {
                    int chkphonecategory = command.Phones.Count(x => x.CategoryTypeLevelId == phone.CategoryTypeLevelId);
                    if (chkphonecategory > 1)
                    {
                        throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Phone Category"));
                    }
                }
            }

            if (command.Emails != null)
            {
                foreach (EmailModel email in command.Emails)
                {
                    int chkemailcategory = command.Emails.Count(x => x.CategoryTypeLevelId == email.CategoryTypeLevelId);
                    if (chkemailcategory > 1)
                    {
                        throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Email Category"));
                    }
                }
            }

            if (command.Addresses != null)
            {
                foreach (AddressModel address in command.Addresses)
                {
                    int chkaddresscategory = command.Addresses.Count(x => x.CategoryTypeLevelId == address.CategoryTypeLevelId);
                    if (chkaddresscategory > 1)
                    {
                        throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Address Category"));
                    }
                }
            }

            if (command.RoleIds != null)
            {
                foreach (string role in command.RoleIds)
                {
                    //if (role == 2)
                    //{
                    //    if (command.CompanyId <= 0)
                    //    {
                    //        throw new ValidationException(new ValidationFailure("CompanyId", $"CompanyId is required"));
                    //    }
                    //}
                    if (role == "StoreManager" || role == "StoreRegional" || role == "StoreSupervisor")
                    {
                        if (command.CompanyId <= 0)
                        {
                            throw new ValidationException(new ValidationFailure("CompanyId", $"CompanyId is required"));
                        }
                        if (command.StoreId <= 0)
                        {
                            throw new ValidationException(new ValidationFailure("StoreId", $"StoreId is required"));
                        }
                    }
                }
            }
            #endregion
            int userid = 0;

            try
            {
                StoreUserModel storeuser = new()
                {
                    UserName = command.UserName,
                    Password = command.Password,
                    FirstName = command.FirstName,
                    LastName = command.LastName,
                    StoreId = command.StoreId,
                    RoleIds = command.RoleIds
                };

                if (command.Addresses != null)
                {
                    foreach (AddressModel addr in command.Addresses)
                    {
                        if (addr.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.UserAddressMain)
                        {
                            storeuser.AddressLine1 = addr.AddressLine1;
                            storeuser.AddressLine2 = addr.AddressLine1;
                            storeuser.City = addr.City;
                            storeuser.State = addr.StateId.ToString();
                            storeuser.Country = addr.CountryId.ToString();
                            storeuser.Latitude = addr.Latitude.ToString();
                            storeuser.Longitude = addr.Longitude.ToString();
                            storeuser.ZipCode = addr.ZipCode;
                        }
                    }
                }

                if (command.Emails != null)
                {
                    foreach (EmailModel email in command.Emails)
                    {
                        if (email.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.UserEmailMain)
                        {
                            storeuser.Email = email.Email;
                        }
                    }
                }

                if (command.Phones != null)
                {
                    foreach (PhoneModel phn in command.Phones)
                    {
                        if (phn.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.UserPhoneMain)
                        {
                            storeuser.MobileNumber = phn.Number;
                            storeuser.CountryCode = phn.CountryCode;
                        }
                    }
                }

                StoreUserResponseModel storeUserRegister = await identityapiclient.StoreUserRegisterAsync(storeuser, cancellationToken);

                if (storeUserRegister == null)
                {
                    throw new ValidationException(new ValidationFailure("User", $"User not saved over identity server"));
                }

                userid = storeUserRegister.UserId;

                int UserId = await _context.Users.Add(new Domain.Entities.User
                {
                    UserId = userid,
                    CompanyId = command.CompanyId,
                    StoreId = command.StoreId,
                    FirstName = command.FirstName,
                    LastName = command.LastName,
                    RegionId = command.RegionId,
                    Title = command.Title,
                    DesignationId = command.DesignationId
                });

                await Add(command.Phones, command.Emails, command.Addresses, null, command, null, userid);
                _context.Commit();
            }
            catch (Exception)
            {
                _context.Rollback();
                throw;
            }

            _logger.TraceExitMethod(nameof(Handle), userid);

            await eventDispatcher.Dispatch(new StoreUserEvent()
            {
                UserId = userid,
                Title = command.Title,
                FirstName = command.FirstName,
                LastName = command.LastName,
                DesignationId = command.DesignationId ?? 0,
                CompanyId = command.CompanyId,
                StoreId = command.StoreId,
                ManagerId = command.ManagerId,
                RegionId = command.RegionId,
                Emails= command.Emails.Select(x => x.Email).ToList(),
            });

            return userid;
        }

        private async Task Add(IEnumerable<PhoneModel> phones, IEnumerable<EmailModel> emails, IEnumerable<AddressModel> addresses, int? companyId, CreateUserCommand user, int? storeId, int? userId)
        {
            if (phones != null)
            {
                foreach (PhoneModel phone in phones)
                {
                    phone.PhoneId = await _context.Phones.Add(new Domain.Entities.Phone
                    {
                        AreaCode = phone.AreaCode,
                        CompanyId = companyId,
                        StoreId = storeId,
                        UserId = userId,
                        PhoneNumber = phone.Number,
                        CountryCode = phone.CountryCode,
                        CategoryTypeLevelId = phone.CategoryTypeLevelId
                    });
                }
            }

            if (emails != null)
            {
                foreach (EmailModel email in emails)
                {
                    email.EmailId = await _context.Emails.Add(new Domain.Entities.Email
                    {
                        CategoryTypeLevelId = email.CategoryTypeLevelId,
                        EmailAddress = email.Email,
                        CompanyId = companyId,
                        UserId = userId,
                        StoreId = storeId,
                    });
                }
            }

            if (addresses != null)
            {
                foreach (AddressModel address in addresses)
                {
                    address.AddressId = await _context.Addresses.Add(new Domain.Entities.Address
                    {
                        CategoryTypeLevelId = address.CategoryTypeLevelId,
                        AddressLine1 = address.AddressLine1,
                        AddressLine2 = address.AddressLine2,
                        City = address.City,
                        StateId = address.StateId,
                        CountryId = address.CountryId,
                        Latitude = address.Latitude,
                        Longitude = address.Longitude,
                        ZipCode = address.ZipCode,
                        CompanyId = companyId,
                        UserId = userId,
                        StoreId = storeId
                    });
                }
            }
        }
    }
}
