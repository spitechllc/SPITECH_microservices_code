﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Application.Commands.CreateUser
{
    public class CreateUserCommand : IRequest<int>
    {
        public int Title { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int? DesignationId { get; set; }
        public int CompanyId { get; set; }
        public int StoreId { get; set; }
        public int ManagerId { get; set; }
        public int RegionId { get; set; }

        public IEnumerable<AddressModel> Addresses { get; set; }
        public IEnumerable<PhoneModel> Phones { get; set; }
        public IEnumerable<EmailModel> Emails { get; set; }
        public ICollection<string> RoleIds { get; set; }
    }
}
