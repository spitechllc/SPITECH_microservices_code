﻿using FluentValidation;

namespace SpiTech.UserStoreManagement.Application.Commands.CreateUser
{
    public class CreateUserValidator : AbstractValidator<CreateUserCommand>
    {
        public CreateUserValidator()
        {
            RuleFor(x => x.UserName).NotNull().NotEmpty().Length(1, 50);
            RuleFor(x => x.FirstName).NotNull().NotEmpty().Length(1, 50);
            RuleFor(x => x.LastName).NotNull().NotEmpty().Length(1, 50);
            RuleFor(x => x.Password).NotNull().NotEmpty().Length(8, 20);
            //RuleFor(x => x.CompanyId).GreaterThan(0).WithMessage("CompanyId is required");
            //RuleFor(x => x.StoreId).GreaterThan(0).WithMessage("StoreId is required");
            //RuleFor(x => x.RoleIds.Count).GreaterThan(0).NotNull().WithMessage("RoleIds is required");
            //RuleForEach(x =>x.RoleIds).GreaterThan(0).WithMessage("RoleIds is required");
            RuleForEach(x => x.Emails).ChildRules(c => c.RuleFor(email => email.Email).EmailAddress().NotEmpty().WithMessage("Emails Required"));
        }
    }
}
