﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Application.Commands.CreateCompanyOwner
{
    public class CreateCompanyOwnerCommand : IRequest<int>
    {
        public UserModel Owners { get; set; }
        public ICollection<string> RoleIds { get; set; }
    }
}
