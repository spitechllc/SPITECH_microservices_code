﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.Service.Clients.Identity;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using UserModel = SpiTech.UserStoreManagement.Domain.Models.UserModel;

namespace SpiTech.UserStoreManagement.Application.Commands.CreateCompanyOwner
{
    public class CreateCompanyOwnerHandler : IRequestHandler<CreateCompanyOwnerCommand, int>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateCompanyOwnerHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IIdentityServiceClient identityapiclient;

        public CreateCompanyOwnerHandler(IUnitOfWork context,
                                    ILogger<CreateCompanyOwnerHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper,
                                    IIdentityServiceClient identityclient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            identityapiclient = identityclient;
        }

        public async Task<int> Handle(CreateCompanyOwnerCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            int userid = 0;
                try
                {

                #region check duplicate category
                foreach (PhoneModel phone in command.Owners.Phones)
                {
                    int chkphonecategory = command.Owners.Phones.Count(x => x.CategoryTypeLevelId == phone.CategoryTypeLevelId);
                    if (chkphonecategory > 1)
                    {
                        throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Phone Category"));
                    }
                }
                foreach (EmailModel email in command.Owners.Emails)
                {
                    int chkemailcategory = command.Owners.Emails.Count(x => x.CategoryTypeLevelId == email.CategoryTypeLevelId);
                    if (chkemailcategory > 1)
                    {
                        throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Email Category"));
                    }
                }
                foreach (AddressModel address in command.Owners.Addresses)
                {
                    int chkaddresscategory = command.Owners.Addresses.Count(x => x.CategoryTypeLevelId == address.CategoryTypeLevelId);
                    if (chkaddresscategory > 1)
                    {
                        throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Address Category"));
                    }
                }
                #endregion

                StoreUserModel storeuser = new()
                {
                    UserName = command.Owners.UserName,
                    Password = command.Owners.Password,
                    FirstName = command.Owners.FirstName,
                    LastName = command.Owners.LastName,                   
                    RoleIds = command.RoleIds,
                };

                foreach (AddressModel addr in command.Owners.Addresses)
                {
                    if (addr.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.UserAddressMain)
                    {
                        storeuser.AddressLine1 = addr.AddressLine1;
                        storeuser.AddressLine2 = addr.AddressLine1;
                        storeuser.City = addr.City;
                        storeuser.State = addr.StateId.ToString();
                        storeuser.Country = addr.CountryId.ToString();
                        storeuser.Latitude = addr.Latitude.ToString();
                        storeuser.Longitude = addr.Longitude.ToString();
                        storeuser.ZipCode = addr.ZipCode;
                    }
                }
                foreach (EmailModel email in command.Owners.Emails)
                {
                    if (email.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.UserEmailMain)
                    {
                        storeuser.Email = email.Email;
                    }
                }

                foreach (PhoneModel phn in command.Owners.Phones)
                {
                    if (phn.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.UserPhoneMain)
                    {
                        storeuser.MobileNumber = phn.Number;
                        storeuser.CountryCode = phn.CountryCode;
                    }
                }

                StoreUserResponseModel users = await identityapiclient.StoreUserRegisterAsync(storeuser);

                if (users == null)
                {
                    throw new ValidationException(new ValidationFailure("IdentityUser", $"command.Owners not saved over identity server"));
                }

                 userid = users.UserId;

                command.Owners.UserId = await _context.Users.Add(new Domain.Entities.User
                {
                    UserId = userid,
                    FirstName = command.Owners.FirstName,
                    LastName = command.Owners.LastName,
                    RegionId = command.Owners.RegionId,
                    Title = command.Owners.Title,
                    DesignationId = command.Owners.DesignationId,

                });
                command.Owners.UserId = userid;
                await Add(command.Owners.Phones, command.Owners.Emails, command.Owners.Addresses, null, command.Owners);

                _context.Commit();
                }
                catch (Exception)
                {
                    _context.Rollback();
                    throw;
                }

                _logger.TraceExitMethod(nameof(Handle), userid);

                return await Task.FromResult(userid);
           
        }

        private async Task Add(IEnumerable<PhoneModel> phones, IEnumerable<EmailModel> emails, IEnumerable<AddressModel> addresses, int? companyId, UserModel users)
        {

            if (phones != null)
            {
                foreach (PhoneModel phone in phones)
                {
                    phone.PhoneId = await _context.Phones.Add(new Domain.Entities.Phone
                    {
                        AreaCode = phone.AreaCode,
                        UserId = users?.UserId,
                        PhoneNumber = phone.Number,
                        CountryCode = phone.CountryCode,
                        CategoryTypeLevelId = phone.CategoryTypeLevelId
                    });
                }
            }

            if (emails != null)
            {
                foreach (EmailModel email in emails)
                {
                    email.EmailId = await _context.Emails.Add(new Domain.Entities.Email
                    {
                        CategoryTypeLevelId = email.CategoryTypeLevelId,//TODO
                        EmailAddress = email.Email,
                        UserId = users?.UserId,
                    });
                }
            }

            if (addresses != null)
            {
                foreach (AddressModel address in addresses)
                {
                    address.AddressId = await _context.Addresses.Add(new Domain.Entities.Address
                    {
                        CategoryTypeLevelId = address.CategoryTypeLevelId,//TODO
                        AddressLine1 = address.AddressLine1,
                        AddressLine2 = address.AddressLine2,
                        City = address.City,
                        StateId = address.StateId,
                        CountryId = address.CountryId,
                        Latitude = address.Latitude,
                        Longitude = address.Longitude,
                        ZipCode = address.ZipCode,
                        CompanyId = companyId,
                        UserId = users?.UserId,
                    });
                }
            }
        }
    }
}