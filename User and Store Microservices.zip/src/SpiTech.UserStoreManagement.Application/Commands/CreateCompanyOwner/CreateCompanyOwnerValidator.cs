﻿using FluentValidation;
using SpiTech.UserStoreManagement.Application.CommonValidators;

namespace SpiTech.UserStoreManagement.Application.Commands.CreateCompanyOwner
{
    public class CreateCompanyOwnerValidator : AbstractValidator<CreateCompanyOwnerCommand>
    {
        public CreateCompanyOwnerValidator()
        {
            RuleFor(q => q.Owners).SetValidator(new UserValidator());
        }
    }
}
