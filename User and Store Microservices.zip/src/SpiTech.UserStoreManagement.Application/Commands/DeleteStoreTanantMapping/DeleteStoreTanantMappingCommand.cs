﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Commands.DeleteStoreTanantMapping
{
    public class DeleteStoreTanantMappingCommand : IRequest<string>
    {
        public int Id { get; set; }
        public int StoreId { get; set; }
    }
}
