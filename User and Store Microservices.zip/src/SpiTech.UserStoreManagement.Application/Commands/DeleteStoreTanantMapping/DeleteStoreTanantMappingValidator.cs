﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Commands.DeleteStoreTanantMapping
{
    public class DeleteStoreTanantMappingValidator : AbstractValidator<DeleteStoreTanantMappingCommand>
    {
        public DeleteStoreTanantMappingValidator()
        {
            RuleFor(x => x.Id).NotNull().WithMessage("Id is required");
            RuleFor(x => x.StoreId).NotNull().WithMessage("StoreId is required");
        }
    }
}
