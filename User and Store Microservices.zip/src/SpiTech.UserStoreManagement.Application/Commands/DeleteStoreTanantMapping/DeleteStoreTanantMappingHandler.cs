﻿using AutoMapper;
using MediatR;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.UserStoreManagement.Application.Commands.CreateStore;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Threading;
using System;
using SpiTech.Application.Logging.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace SpiTech.UserStoreManagement.Application.Commands.DeleteStoreTanantMapping
{
    public class DeleteStoreTanantMappingHandler : IRequestHandler<DeleteStoreTanantMappingCommand, string>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<DeleteStoreTanantMappingHandler> _logger;
        private readonly IStorageService storageService;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        public DeleteStoreTanantMappingHandler(IMediator mediator,
                                   IMapper mapper,
                                   IUnitOfWork context,
                                   ILogger<DeleteStoreTanantMappingHandler> logger,
                                   IStorageServiceFactory storageServiceFactory,
                                   IEventDispatcher eventDispatcher, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _mediator = mediator;
            _mapper = mapper;
            _context = context;
            _logger = logger;
            storageService = storageServiceFactory.Get(ContainerType.StoreImages);
            _eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<string> Handle(DeleteStoreTanantMappingCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            int StoreId = command.StoreId;
            int Id = command.Id;
            await _context.Stores.DeleteStoreTenantMasterByIds(StoreId, Id);
            _context.Commit();
            return await Task.FromResult("Deleted Successfully");
        }
    }
}
