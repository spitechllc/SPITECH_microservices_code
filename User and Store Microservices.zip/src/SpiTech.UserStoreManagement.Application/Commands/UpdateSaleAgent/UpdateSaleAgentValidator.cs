﻿using FluentValidation;
using SpiTech.UserStoreManagement.Application.CommonValidators;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateSaleAgent
{
    public  class UpdateSaleAgentValidator : AbstractValidator<UpdateSaleAgentCommand>
    {
        public UpdateSaleAgentValidator()
        {
            RuleFor(x => x.SaleAgentId).GreaterThan(0).WithMessage("SaleAgentId is required");
            RuleFor(x => x.FirstName).NotNull().WithMessage("FirstName is required").Length(1, 100).WithMessage("FirstName must be between 1 to 100 character.");
            RuleFor(x => x.LastName).NotNull().WithMessage("LastName is required").Length(1, 100).WithMessage("LastName must be between 1 to 100 character.");
            RuleForEach(x => x.Addresses).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Addresses).SetValidator(new AddressModelValidator());
            });

            RuleForEach(x => x.Emails).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Emails).SetValidator(new EmailModelValidator());
            });

            RuleForEach(x => x.Phones).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Phones).SetValidator(new PhoneModelValidator());
            });
        }
    }

}
