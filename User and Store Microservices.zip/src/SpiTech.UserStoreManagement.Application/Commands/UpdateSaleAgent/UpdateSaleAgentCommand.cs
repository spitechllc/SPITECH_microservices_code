﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediatR;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateSaleAgent
{
    public class UpdateSaleAgentCommand : IRequest<bool>
    {
        public int SaleAgentId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public IEnumerable<AddressModel> Addresses { get; set; }
        public IEnumerable<PhoneModel> Phones { get; set; }
        public IEnumerable<EmailModel> Emails { get; set; }
    }
}                                                                                                 
