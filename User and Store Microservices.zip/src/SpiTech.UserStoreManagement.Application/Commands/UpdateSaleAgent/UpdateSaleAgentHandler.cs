﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateSaleAgent
{
    public class UpdateSaleAgentHandler : IRequestHandler<UpdateSaleAgentCommand, bool>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateSaleAgentHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IEventDispatcher _eventDispatcher;
        public UpdateSaleAgentHandler(IMediator mediator,
                                   IMapper mapper,
                                   IUnitOfWork context,
                                   ILogger<UpdateSaleAgentHandler> logger, IUserAuthenticationProvider userAuthenticationProvider, IEventDispatcher eventDispatcher)
        {
            _mediator = mediator;
            _mapper = mapper;
            _context = context;
            _logger = logger;
            _eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<bool> Handle(UpdateSaleAgentCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
         
            var saleAgent = await _context.SaleAgents.Get(command.SaleAgentId);
            if (saleAgent == null)
            {
                throw new ValidationException(new ValidationFailure("SaleAgentId", $"SaleAgent does not exist"));
            }
          
            var model = new Domain.Entities.SaleAgent();

            model.SaleAgentId = command.SaleAgentId;
            model.FirstName = command.FirstName;
            model.LastName = command.LastName;

            var result = false;
            try
            {
                result = await _context.SaleAgents.Update(model);

                var res = await AddUpdate(command.Phones, command.Emails, command.Addresses,  command.SaleAgentId);
                _context.Commit();
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.UpdateSaleAgent, "SaleAgent Updated.", false, null);
            }
            catch (Exception ex)
            {
                _context.Rollback();
                _logger.Error(ex);
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.UpdateSaleAgent, "Update SaleAgent Failed.", true, ex.Message);
                throw;
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return await Task.FromResult(result);
        }
        private async Task<bool> AddUpdate(IEnumerable<PhoneModel> phones, IEnumerable<EmailModel> emails, IEnumerable<AddressModel> addresses,  int SaleAgentId)
        {
           
            if (phones != null)
            {
                var phoneList = _context.Phones.Get(SaleAgentId, EntityCategoryType.SaleAgent);

                foreach (var phone in phones)
                {
                    var model = new Domain.Entities.Phone
                    {
                        PhoneId = phone.PhoneId,
                        AreaCode = phone.AreaCode,
                        CompanyId = null,
                        UserId = null,
                        StoreId = null,
                        SaleAgentId= SaleAgentId,
                        PhoneNumber = phone.Number,
                        CountryCode = phone.CountryCode,
                        CategoryTypeLevelId = phone.CategoryTypeLevelId,
                        IsActive = phone.IsActive
                    };

                    if (phone.PhoneId <= 0)
                    {
                        phone.PhoneId = await _context.Phones.Add(model);
                    }
                    else
                    {
                        await _context.Phones.Update(model);
                    }
                }

                foreach (var phone in phoneList)
                {
                    var deletedphone = phones.FirstOrDefault(t => t.PhoneId == phone.PhoneId);
                    if (deletedphone == null)
                    {
                        phone.IsActive = false;
                        await _context.Phones.Update(phone);
                    }
                }
            }

            if (emails != null)
            {
                var emailList = _context.Emails.Get(SaleAgentId, EntityCategoryType.SaleAgent);

                foreach (var email in emails)
                {
                  var model = new Domain.Entities.Email
                    {
                        EmailId = email.EmailId,
                        CategoryTypeLevelId = email.CategoryTypeLevelId,
                        EmailAddress = email.Email,
                        CompanyId = null,
                        UserId = null,
                        StoreId = null,
                        SaleAgentId= SaleAgentId,
                        IsActive = email.IsActive

                    };

                    if (email.EmailId <= 0)
                    {
                        email.EmailId = await _context.Emails.Add(model);
                    }
                    else
                    {
                        await _context.Emails.Update(model);
                    }


                }
                foreach (var email in emailList)
                {
                    var deletedemail = emails.FirstOrDefault(t => t.EmailId == email.EmailId);
                    if (deletedemail == null)
                    {
                        email.IsActive = false;
                        await _context.Emails.Update(email);
                    }
                }
            }

            if (addresses != null && addresses.Count() > 0)
            {
                var addresseslList = _context.Addresses.Get(SaleAgentId, EntityCategoryType.SaleAgent);

                foreach (var address in addresses)
                {
                    var model = new Domain.Entities.Address
                    {
                        AddressId = address.AddressId,
                        CategoryTypeLevelId = address.CategoryTypeLevelId,//TODO
                        AddressLine1 = address.AddressLine1,
                        AddressLine2 = address.AddressLine2,
                        City = address.City,
                        StateId = address.StateId,
                        CountryId = address.CountryId,
                        Latitude = address.Latitude,
                        Longitude = address.Longitude,
                        ZipCode = address.ZipCode,
                        CompanyId = null,
                        UserId = null,
                        StoreId=null,
                        SaleAgentId = SaleAgentId,
                        IsActive = address.IsActive
                    };

                    if (address.AddressId <= 0)
                    {
                        address.AddressId = await _context.Addresses.Add(model);
                    }
                    else
                    {
                        await _context.Addresses.Update(model);
                    }
                   

                }
                foreach (var address in addresseslList)
                {
                    var deletedaddress = addresses.FirstOrDefault(t => t.AddressId == address.AddressId);
                    if (deletedaddress == null)
                    {
                        Address storeAddress = _mapper.Map<Address>(address);
                        storeAddress.IsActive = false;
                        await _context.Addresses.Update(storeAddress);
                    }
                }
            }



            return true;
        }

        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = "",
                IsError = isError,
                ErrorMessage = errorMessage

            });
        }
    }
}
