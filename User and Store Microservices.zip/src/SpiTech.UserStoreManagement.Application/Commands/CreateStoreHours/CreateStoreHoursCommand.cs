﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Application.Commands.CreateStoreHours
{
    public class CreateStoreHoursCommand : IRequest<int>
    {

        public bool Is24Hours { get; set; }
        public int StoreId { get; set; }
        public IEnumerable<StoreHoursModel> StoreHours { get; set; }
    }
}
