﻿using FluentValidation;

namespace SpiTech.UserStoreManagement.Application.Commands.CreateStoreHours
{
    public class CreateStoreHoursValidator : AbstractValidator<CreateStoreHoursCommand>
    {
        public CreateStoreHoursValidator()
        {
            RuleFor(h => h.StoreId).GreaterThan(0).WithMessage("StoreId must be greater than 0");
        }
    }
}
