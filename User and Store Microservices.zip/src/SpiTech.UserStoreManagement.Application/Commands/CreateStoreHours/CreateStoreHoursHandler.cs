﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Commands.CreateStoreHours
{
    public class CreateStoreHoursHandler : IRequestHandler<CreateStoreHoursCommand, int>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateStoreHoursHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        public CreateStoreHoursHandler(IUnitOfWork context,
                                 ILogger<CreateStoreHoursHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<int> Handle(CreateStoreHoursCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            await _context.Execute(async () =>
            {
                if (command.Is24Hours)
                {
                    System.Collections.Generic.IEnumerable<Domain.Entities.WeekDays> weekdays = await _context.WeekDays.GetAll();
                    foreach (Domain.Entities.WeekDays wday in weekdays)
                    {
                        await _context.StoreHours.Add(new Domain.Entities.StoreHours()
                        {
                            WeekDayId = wday.WeekDayId,
                            OpenTime = "23:59",
                            CloseTime = "12:00",
                            StoreId = command.StoreId,
                            Is24Hours = command.Is24Hours
                        });
                    }
                }
                else
                {
                    foreach (Domain.Models.StoreHoursModel hour in command.StoreHours)
                    {
                        await _context.StoreHours.Add(new Domain.Entities.StoreHours()
                        {
                            WeekDayId = hour.WeekDayId,
                            OpenTime = hour.OpenTime,
                            CloseTime = hour.CloseTime,
                            StoreId = command.StoreId,
                            Is24Hours = command.Is24Hours
                        });
                    }
                }
            });
            return await Task.FromResult(1);
        }
    }
}
