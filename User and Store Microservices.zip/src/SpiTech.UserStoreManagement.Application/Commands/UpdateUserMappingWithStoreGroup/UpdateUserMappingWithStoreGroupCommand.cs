﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateUserMappingWithStoreGroup
{
    public class UpdateUserMappingWithStoreGroupCommand : IRequest<ResponseModel>
    {
        
        public int StoreGroupId { get; set; }
        public IEnumerable<StoreGroupUsersModel> storeGroupUsers { get; set; }
    }
   
}
