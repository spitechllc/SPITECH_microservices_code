﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateUserMappingWithStoreGroup
{
    public class UpdateUserMappingWithStoreGroupHandler : IRequestHandler<UpdateUserMappingWithStoreGroupCommand, ResponseModel>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateUserMappingWithStoreGroupHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        public UpdateUserMappingWithStoreGroupHandler(IMediator mediator,
                                   IMapper mapper,
                                   IUnitOfWork context,
                                   ILogger<UpdateUserMappingWithStoreGroupHandler> logger)
        {
            _mediator = mediator;
            _mapper = mapper;
            _context = context;
            _logger = logger;
        }

        public async Task<ResponseModel> Handle(UpdateUserMappingWithStoreGroupCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);          
            

            try
            {
                IEnumerable<StoreGroupUsers> storeGroupUsersList =await _context.StoreGroupUsers.GetByStoreGroupId(command.StoreGroupId);
                foreach (var item in command.storeGroupUsers)
                {
                    Domain.Entities.StoreGroupUsers model = new Domain.Entities.StoreGroupUsers
                    {
                        StoreGroupUsersId=item.StoreGroupUsersId,
                        StoreGroupId = command.StoreGroupId,
                        UserId = item.UserId,
                    };

                    if (item.StoreGroupUsersId <= 0)
                    {
                        item.StoreGroupUsersId = await _context.StoreGroupUsers.Add(model);
                    }
                    else
                    {
                        await _context.StoreGroupUsers.Update(model);
                    }
                    
                }
                foreach (StoreGroupUsers storeGroupUser in storeGroupUsersList)
                {
                    StoreGroupUsersModel deletedusers = command.storeGroupUsers.FirstOrDefault(t => t.StoreGroupUsersId == storeGroupUser.StoreGroupUsersId);
                    if (deletedusers == null)
                    {
                        storeGroupUser.IsActive = false;
                        await _context.StoreGroupUsers.Update(storeGroupUser);
                    }
                }
                _context.Commit();

                _logger.TraceExitMethod(nameof(Handle));

                return new ResponseModel { Success = true, Message = "Success" };
            }
            catch (Exception ex)
            {
                _context.Rollback();
                _logger.Error(ex);
              return new ResponseModel { Success = false, Message = "Fail" };
                
            }

        }

       
    }
}