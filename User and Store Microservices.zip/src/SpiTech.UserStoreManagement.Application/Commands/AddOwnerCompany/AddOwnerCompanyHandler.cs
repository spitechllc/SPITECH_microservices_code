﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Commands.AddOwnerCompany
{
    public class AddOwnerCompanyHandler : IRequestHandler<AddOwnerCompanyCommand, bool>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<AddOwnerCompanyHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        public AddOwnerCompanyHandler(IMediator mediator,
                                   IMapper mapper,
                                   IUnitOfWork context,
                                   ILogger<AddOwnerCompanyHandler> logger)
        {
            _mediator = mediator;
            _mapper = mapper;
            _context = context;
            _logger = logger;
        }

        public async Task<bool> Handle(AddOwnerCompanyCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            List<int> deletedCompanies = new List<int>();
            var dbcompany = await _context.Companies.GetByOwnerId(command.OwnerId);
            if (dbcompany != null)
            {
                foreach (var company in dbcompany)
                {

                    if (!command.CompanyIds.Contains(company.Id))
                    {
                        deletedCompanies.Add(company.Id);
                    }
                }

            }
            //check if company assigned to another owner
            string companyOwner = await _context.Companies.GetCompaniesOwner(command.OwnerId,command.CompanyIds);
            if (!string.IsNullOrEmpty(companyOwner))
            {
                throw new ValidationException(new ValidationFailure("Company", $"Company "+ companyOwner+" already assigned to anoter owner"));
            }
            //assign owner id to company
            var res = await _context.Companies.UpdateCompanyOwner(command.OwnerId, command.CompanyIds);

            //remove owner from company
            if (deletedCompanies.Count() > 0)
            {
                var deleteOwner = await _context.Companies.RemoveOwnerfromCompanies(deletedCompanies.ToArray());
            }
            _context.Commit();
            _logger.TraceExitMethod(nameof(Handle), res);

            return res;
        }


    }
}