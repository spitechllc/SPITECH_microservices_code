﻿using FluentValidation;
using SpiTech.UserStoreManagement.Application.CommonValidators;

namespace SpiTech.UserStoreManagement.Application.Commands.AddOwnerCompany
{
    public class AddOwnerCompanyValidator : AbstractValidator<AddOwnerCompanyCommand>
    {
        public AddOwnerCompanyValidator()
        {
            RuleFor(x => x.OwnerId).GreaterThan(0).WithMessage("OwnerId is required");
            RuleFor(x => x.CompanyIds).NotNull().NotEmpty();
        }
    }
}
