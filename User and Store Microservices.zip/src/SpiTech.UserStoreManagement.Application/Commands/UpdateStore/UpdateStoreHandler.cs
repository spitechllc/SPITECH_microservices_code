﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents.Events.Store;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateStore
{
    public class UpdateStoreHandler : IRequestHandler<UpdateStoreCommand, bool>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateStoreHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        private readonly IStorageService storageService;
        private string emailids;

        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        public UpdateStoreHandler(IMediator mediator,
                                   IMapper mapper,
                                   IUnitOfWork context,
                                   ILogger<UpdateStoreHandler> logger,
                                   IStorageServiceFactory storageServiceFactory,
                                   IEventDispatcher eventDispatcher, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _mediator = mediator;
            _mapper = mapper;
            _context = context;
            _logger = logger;
            storageService = storageServiceFactory.Get(ContainerType.StoreImages);
            _eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<bool> Handle(UpdateStoreCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            int AddressId = 0;
            Store dbstore = await _context.Stores.ValidateSiteId(command.SiteId, command.StoreId);
            if (dbstore != null)
            {
                throw new ValidationException(new ValidationFailure("SiteId", $"SiteId already exist"));
            }
            Store store = await _context.Stores.Get(command.StoreId);
            #region check duplicate category
            foreach (PhoneModel phone in command.Phones)
            {
                int chkphonecategory = command.Phones.Count(x => x.CategoryTypeLevelId == phone.CategoryTypeLevelId);
                if (chkphonecategory > 1)
                {
                    throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Phone Category"));
                }
            }
            foreach (EmailModel email in command.Emails)
            {
                int chkemailcategory = command.Emails.Count(x => x.CategoryTypeLevelId == email.CategoryTypeLevelId);
                if (chkemailcategory > 1)
                {
                    throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Email Category"));
                }
                //Email emailModel = await _context.Emails.GetDuplicateEmail(command.StoreId,EntityCategoryType.Store,email.Email);
                //if (emailModel != null)
                //{
                //    throw new ValidationException(new ValidationFailure("Email", $"Email already exist"));
                //}
            }
            foreach (AddressModel address in command.Addresses)
            {
                int chkaddresscategory = command.Addresses.Count(x => x.CategoryTypeLevelId == address.CategoryTypeLevelId);
                if (chkaddresscategory > 1)
                {
                    throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Address Category"));
                }
            }
            #endregion

            Store model = new()
            {
                StoreId = command.StoreId,
                StoreName = command.StoreName,
                SiteId = command.SiteId,
                StoreUrl = command.StoreUrl,
                MangerId = command.ManagerId.Value,
                RegionId = command.RegionId,
                RegionalManagerId = command.RegionManagerId,
                PosId = command.POSId,
                PosName = command.PosName,
                Description = command.Description,
                Note = command.Note,
                TimeZoneId = command.TimeZoneId,
                CompanyId = command.CompanyId,
                MaxAuthorizeAmount = command.MaxAuthorizeAmount,
                IsActive = command.IsActive,
                EnableBilling = command.EnableBilling,
                ConsentCashReward = command.ConsentCashReward,
                IsMasterStore = store.IsMasterStore,
                SaleAgentId = command.SaleAgentId,
                DisableBilling = command.DisableBilling,
                DisableEod = command.DisableEod,
                EnableACHLoyalty = command.EnableACHLoyalty,
                EnableCardLoyalty = command.EnableCardLoyalty,
                LoyaltyProgramId = command.LoyaltyProgramId,
                StoreCategoryId = command.StoreCategoryId
            };

            string Azurefileurl = string.Empty;

            if (!string.IsNullOrEmpty(command.StoreImage))
            {

                if (!((command.StoreImage.Length % 4 == 0) && Regex.IsMatch(command.StoreImage, @"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.None)))
                {
                    throw new ValidationException(new ValidationFailure("StoreImage", $"Invalid base64"));
                }
                else
                {
                    string filename = command.StoreId + "_" + UniqueIdGenerator.Generate() + "_storelogo.jpeg";
                    Azurefileurl = await SaveImage(command.StoreImage, filename);

                    if (!string.IsNullOrEmpty(Azurefileurl))
                    {
                        model.StoreImage = Azurefileurl;
                    }
                }
            }
            else
            {
                if (store != null)
                {

                    model.StoreImage = store.StoreImage;
                }
            }

            bool result = false;
            try
            {
                result = await _context.Stores.Update(model);

                AddressId = await AddUpdate(command.Phones, command.Emails, command.Addresses, command.Amenities, command.StoreId, command.AppIds);
                _context.Commit();
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.UpdateStore, "Store Updated.", false, null);
            }
            catch (Exception ex)
            {
                _context.Rollback();
                _logger.Error(ex);
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.UpdateStore, "Store Updation Failed.", true, ex.Message);
                throw;
            }
            #region  send event notification 

            AddressModel Padds = command.Addresses?.Where(x => x.CategoryTypeLevelId ==
            (int)PrimaryCategoryTypeLevel.StoreAddressMain).FirstOrDefault();

            StoreEvent storeevent = new()
            {
                IsCreated = false,
                StoreId = command.StoreId,
                StoreName = command.StoreName,
                SiteId = command.SiteId,
                StoreUrl = command.StoreUrl,
                Description = command.Description,
                Note = command.Note,
                StoreImage = Azurefileurl
            };
            if (command.Emails != null)
            {
                storeevent.EmailIds = string.Join(",", command.Emails.Select(x => x.Email));
            }
            if (command.Phones != null)
            {
                storeevent.PhoneNos = string.Join(",", command.Phones.Select(x => x.Number));
            }

            //string emailval = string.Join(",", command.Emails.Select(x=>x.Email))
            //string val= string.Join(",",emailval.)
            storeevent.MaxAuthorizeAmount = command.MaxAuthorizeAmount;
            if (Padds != null)
            {
                storeevent.AddressId = AddressId;
                storeevent.CategoryTypeLevelId = Padds.CategoryTypeLevelId;
                storeevent.AddressLine1 = Padds.AddressLine1;
                storeevent.AddressLine2 = Padds.AddressLine2;
                storeevent.CountryId = Padds.CountryId;
                storeevent.StateId = Padds.StateId;
                storeevent.City = Padds.City;
                storeevent.Longitude = Padds.Longitude;
                storeevent.Latitude = Padds.Latitude;
                storeevent.ZipCode = Padds.ZipCode;
                storeevent.CompanyId = command.CompanyId;
                storeevent.IsActive = command.IsActive;
            }

            await _eventDispatcher.Dispatch(storeevent);

            #endregion

            _logger.TraceExitMethod(nameof(Handle), result);

            return await Task.FromResult(result);
        }

        private async Task<string> SaveImage(string base64image, string filename)
        {
            await storageService.UploadBlob(base64image, filename);
            Blob res = await storageService.GetFile(filename);
            return res != null ? res.StorageUri : string.Empty;
        }

        private async Task<int> AddUpdate(IEnumerable<PhoneModel> phones, IEnumerable<EmailModel> emails, IEnumerable<AddressModel> addresses, IEnumerable<StoreAmenityModel> amenities, int StoreId, int[] AppIds)
        {
            int AddressId = 0;

            if (phones != null)
            {
                List<Phone> phoneList = _context.Phones.Get(StoreId, EntityCategoryType.Store);

                foreach (PhoneModel phone in phones)
                {
                    Phone model = new()
                    {
                        PhoneId = phone.PhoneId,
                        AreaCode = phone.AreaCode,
                        CompanyId = null,
                        UserId = null,
                        StoreId = StoreId,
                        PhoneNumber = phone.Number,
                        CountryCode = phone.CountryCode,
                        CategoryTypeLevelId = phone.CategoryTypeLevelId,
                        IsActive = phone.IsActive
                    };

                    if (phone.PhoneId <= 0)
                    {
                        phone.PhoneId = await _context.Phones.Add(model);
                    }
                    else
                    {
                        await _context.Phones.Update(model);
                    }
                }

                foreach (Phone phone in phoneList)
                {
                    PhoneModel deletedphone = phones.FirstOrDefault(t => t.PhoneId == phone.PhoneId);
                    if (deletedphone == null)
                    {
                        phone.IsActive = false;
                        await _context.Phones.Update(phone);
                    }
                }
            }

            if (emails != null)
            {
                List<Email> emailList = _context.Emails.Get(StoreId, EntityCategoryType.Store);

                foreach (EmailModel email in emails)
                {
                    emailids = email.Email + ",";
                    Email model = new()
                    {
                        EmailId = email.EmailId,
                        CategoryTypeLevelId = email.CategoryTypeLevelId,
                        EmailAddress = email.Email,
                        CompanyId = null,
                        UserId = null,
                        StoreId = StoreId,
                        IsActive = email.IsActive

                    };

                    if (email.EmailId <= 0)
                    {
                        email.EmailId = await _context.Emails.Add(model);
                    }
                    else
                    {
                        await _context.Emails.Update(model);
                    }


                }
                foreach (Email email in emailList)
                {
                    EmailModel deletedemail = emails.FirstOrDefault(t => t.EmailId == email.EmailId);
                    if (deletedemail == null)
                    {
                        email.IsActive = false;
                        await _context.Emails.Update(email);
                    }
                }
            }

            if (addresses != null && addresses.Count() > 0)
            {
                List<AddressModel> addresseslList = _context.Addresses.Get(StoreId, EntityCategoryType.Store);

                foreach (AddressModel address in addresses)
                {
                    Address model = new()
                    {
                        AddressId = address.AddressId,
                        CategoryTypeLevelId = address.CategoryTypeLevelId,//TODO
                        AddressLine1 = address.AddressLine1,
                        AddressLine2 = address.AddressLine2,
                        City = address.City,
                        StateId = address.StateId,
                        CountryId = address.CountryId,
                        Latitude = address.Latitude,
                        Longitude = address.Longitude,
                        ZipCode = address.ZipCode,
                        CompanyId = null,
                        UserId = null,
                        StoreId = StoreId,
                        IsActive = address.IsActive
                    };

                    if (address.AddressId <= 0)
                    {
                        address.AddressId = await _context.Addresses.Add(model);
                    }
                    else
                    {
                        await _context.Addresses.Update(model);
                    }

                    if (address.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.StoreAddressMain)
                    {
                        AddressId = address.AddressId;
                    }

                }
                foreach (AddressModel address in addresseslList)
                {
                    AddressModel deletedaddress = addresses.FirstOrDefault(t => t.AddressId == address.AddressId);
                    if (deletedaddress == null)
                    {
                        Address storeAddress = _mapper.Map<Address>(address);
                        storeAddress.IsActive = false;
                        await _context.Addresses.Update(storeAddress);
                    }
                }
            }


            if (amenities != null && amenities.Count() > 0)
            {
                List<StoreAmenitySearchResult> amenitieslList = await _context.StoreAmenities.GetAmenityByStoreId(StoreId);

                foreach (StoreAmenityModel amenity in amenities)
                {
                    StoreAmenity model = new()
                    {
                        StoreId = StoreId,
                        StoreAmenityId = amenity.StoreAmenityId,
                        AmenityId = amenity.AmenityId

                    };

                    if (amenity.StoreAmenityId <= 0)
                    {
                        amenity.StoreAmenityId = await _context.StoreAmenities.Add(model);
                    }
                    else
                    {
                        await _context.StoreAmenities.Update(model);
                    }
                }
                foreach (StoreAmenitySearchResult amenity in amenitieslList)
                {
                    StoreAmenityModel deletedamenity = amenities.FirstOrDefault(t => t.StoreAmenityId == amenity.StoreAmenityId);
                    if (deletedamenity == null)
                    {
                        StoreAmenity storeAmenity = _mapper.Map<StoreAmenity>(amenity);
                        storeAmenity.IsActive = false;
                        await _context.StoreAmenities.Update(storeAmenity);
                    }
                }
                if (AppIds != null)
                {
                    int storeIds = StoreId;
                    var data = await _context.Stores.GetStoreTenantByStoreIds(storeIds);
                    foreach (var obj in data)
                    {
                        int Id = obj.Id;
                        await _context.Stores.DeleteStoreTenantMasterByIds(storeIds, Id);
                    }
                    for (int i = 0; i < AppIds.Length; i++)
                    {
                        int tenantId = AppIds[i];
                        await _context.Stores.AddStoreTenantMapping(storeIds, tenantId);
                        _context.Commit();
                    }
                }
                else
                {
                    int storeIds = StoreId;
                    var data = await _context.Stores.GetStoreTenantByStoreIds(storeIds);
                    foreach (var obj in data)
                    {
                        int Id = obj.Id;
                        await _context.Stores.DeleteStoreTenantMasterByIds(storeIds, Id);
                    }
                    int tenantId = 1;
                    await _context.Stores.AddStoreTenantMapping(storeIds, tenantId);
                    _context.Commit();
                }
            }

            return AddressId;
        }

        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = "",
                IsError = isError,
                ErrorMessage = errorMessage

            });
        }
    }
}
