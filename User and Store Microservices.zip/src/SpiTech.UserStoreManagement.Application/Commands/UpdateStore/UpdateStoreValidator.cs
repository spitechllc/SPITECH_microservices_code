﻿using FluentValidation;
using SpiTech.UserStoreManagement.Application.CommonValidators;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateStore
{
    public class UpdateStoreValidator : AbstractValidator<UpdateStoreCommand>
    {
        public UpdateStoreValidator()
        {
            RuleFor(x => x.StoreName).NotNull().Length(1, 50);
            //RuleFor(x => x.StoreUrl).NotNull().Length(1, 50);
            RuleFor(x => x.SiteId).NotNull().Length(1, 50);

            RuleForEach(x => x.Addresses).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Addresses).SetValidator(new AddressModelValidator());
            });

            RuleForEach(x => x.Emails).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Emails).SetValidator(new EmailModelValidator());
            });

            RuleForEach(x => x.Phones).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Phones).SetValidator(new PhoneModelValidator());
            });

            RuleForEach(x => x.Amenities).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Amenities).SetValidator(new StoreAmenityValidator());
            });
            RuleFor(x => x.MaxAuthorizeAmount).GreaterThan(0).WithMessage("MaxAuthorizeAmount is required");
        }
    }

}
