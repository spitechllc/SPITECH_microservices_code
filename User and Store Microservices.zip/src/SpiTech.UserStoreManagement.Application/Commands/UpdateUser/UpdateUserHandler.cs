﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateUser
{
    public class UpdateUserHandler : IRequestHandler<UpdateUserCommand, ResponseModel>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateUserHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IIdentityServiceClient identityapiclient;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private string emailids;
        public UpdateUserHandler(IUnitOfWork context,
                                   ILogger<UpdateUserHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper,
                                   IIdentityServiceClient identityclient, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            identityapiclient = identityclient;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<ResponseModel> Handle(UpdateUserCommand command, CancellationToken cancellationToken)
        {
            bool result = false;
            _logger.TraceEnterMethod(nameof(Handle), command);
            this.userAuthenticationProvider.ValidateUserAccess(command.UserId);

            #region check duplicate category
            if (command.Phones != null)
            {
                foreach (PhoneModel phone in command.Phones)
                {
                    int chkphonecategory = command.Phones.Count(x => x.CategoryTypeLevelId == phone.CategoryTypeLevelId);
                    if (chkphonecategory > 1)
                    {
                        throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Phone Category"));
                    }
                }
            }

            if (command.Emails != null)
            {
                foreach (EmailModel email in command.Emails)
                {
                    int chkemailcategory = command.Emails.Count(x => x.CategoryTypeLevelId == email.CategoryTypeLevelId);
                    if (chkemailcategory > 1)
                    {
                        throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Email Category"));
                    }
                }
            }

            if (command.Addresses != null)
            {
                foreach (AddressModel address in command.Addresses)
                {
                    int chkaddresscategory = command.Addresses.Count(x => x.CategoryTypeLevelId == address.CategoryTypeLevelId);
                    if (chkaddresscategory > 1)
                    {
                        throw new ValidationException(new ValidationFailure("CategoryLevel", $"Duplicate Address Category"));
                    }
                }
            }

            if (command.RoleIds != null)
            {
                foreach (string role in command.RoleIds)
                {
                    //if (role == 2)
                    //{
                    //    if (command.CompanyId <= 0)
                    //    {
                    //        throw new ValidationException(new ValidationFailure("CompanyId", $"CompanyId is required"));
                    //    }
                    //}
                    if (role == "StoreManager" || role == "StoreRegional" || role == "StoreSupervisor")
                    {
                        if (command.CompanyId <= 0)
                        {
                            throw new ValidationException(new ValidationFailure("CompanyId", $"CompanyId is required"));
                        }
                        if (command.StoreId <= 0)
                        {
                            throw new ValidationException(new ValidationFailure("StoreId", $"StoreId is required"));
                        }
                    }
                }
            }
            #endregion

            try
            {
                Service.Clients.Identity.UpdateProfileCommand updateuser = new()
                {
                    UserId = command.UserId,
                    FirstName = command.FirstName,
                    LastName = command.LastName,
                    CompanyId = command.CompanyId,
                    StoreId = command.StoreId,
                    RoleIds = command.RoleIds
                    
                };

                if(command.IsImageChanged)
                {
                    updateuser.PhotoUrlbase64 = command.PhotoUrlbase64;
                }

                if (command.Addresses != null)
                {
                    foreach (AddressModel addr in command.Addresses)
                    {
                        if (addr.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.UserAddressMain)
                        {
                            updateuser.AddressLine1 = addr.AddressLine1;
                            updateuser.AddressLine2 = addr.AddressLine1;
                            updateuser.City = addr.City;
                            updateuser.State = addr.StateId.ToString();
                            updateuser.Country = addr.CountryId.ToString();
                            updateuser.Latitude = addr.Latitude.ToString();
                            updateuser.Longitude = addr.Longitude.ToString();
                            updateuser.ZipCode = addr.ZipCode;
                        }
                    }
                }

                if (command.Emails != null)
                {
                    foreach (EmailModel email in command.Emails)
                    {
                        if (email.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.UserEmailMain)
                        {
                            updateuser.Email = email.Email;
                        }
                    }
                }

                if (command.Phones != null)
                {
                    foreach (PhoneModel phn in command.Phones)
                    {
                        if (phn.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.UserPhoneMain)
                        {
                            updateuser.MobileNumber = phn.Number;
                            updateuser.CountryCode = phn.CountryCode;
                        }
                    }
                }

                Service.Clients.Identity.UserSearchResultResponseModel updateResponse = await identityapiclient.UpdateProfileAsync(updateuser);
                if (updateResponse == null || !updateResponse.Success)
                {
                    throw new ValidationException(new ValidationFailure("User", $"Some Error Occured"));
                }

                result = await _context.Users.Update(new Domain.Entities.User
                {
                    UserId = command.UserId,
                    CompanyId = command.CompanyId,
                    StoreId = command.StoreId,
                    FirstName = command.FirstName,
                    LastName = command.LastName,
                    RegionId = command.RegionId,
                    Title = command.Title,
                    DesignationId = command.DesignationId,
                    IsActive = command.IsActive
                });

                await AddUpdate(command.Phones, command.Emails, command.Addresses, null, command);

                _logger.TraceExitMethod(nameof(Handle), result);
                _context.Commit();
            }
            catch
            {
                _context.Rollback();
                throw;
            }

            return result ? new ResponseModel { Success = true, Message = "Success" } : new ResponseModel { Success = false, Message = "Fail" };
        }

        private async Task AddUpdate(IEnumerable<PhoneModel> phones, IEnumerable<EmailModel> emails, IEnumerable<AddressModel> addresses, int? CompanyId, UpdateUserCommand user)
        {
            try
            {
                int AddressId = 0;

                if (phones != null)
                {
                    List<Phone> phoneList = _context.Phones.Get(user.UserId, EntityCategoryType.User);

                    foreach (PhoneModel phone in phones)
                    {
                        Phone model = new()
                        {
                            PhoneId = phone.PhoneId,
                            AreaCode = phone.AreaCode,
                            CompanyId = null,
                            UserId = user.UserId,
                            StoreId = null,
                            PhoneNumber = phone.Number,
                            CountryCode = phone.CountryCode,
                            CategoryTypeLevelId = phone.CategoryTypeLevelId,
                            IsActive = phone.IsActive
                        };

                        if (phone.PhoneId <= 0)
                        {
                            phone.PhoneId = await _context.Phones.Add(model);
                        }
                        else
                        {
                            await _context.Phones.Update(model);
                        }
                    }

                    foreach (Phone phone in phoneList)
                    {
                        PhoneModel deletedphone = phones.FirstOrDefault(t => t.PhoneId == phone.PhoneId);
                        if (deletedphone == null)
                        {
                            phone.IsActive = false;
                            await _context.Phones.Update(phone);
                        }
                    }
                }

                if (emails != null)
                {
                    List<Email> emailList = _context.Emails.Get(user.UserId, EntityCategoryType.User);

                    foreach (EmailModel email in emails)
                    {
                        emailids = email.Email + ",";
                        Email model = new()
                        {
                            EmailId = email.EmailId,
                            CategoryTypeLevelId = email.CategoryTypeLevelId,
                            EmailAddress = email.Email,
                            CompanyId = null,
                            UserId = user.UserId,
                            StoreId = null,
                            IsActive = email.IsActive

                        };

                        if (email.EmailId <= 0)
                        {
                            email.EmailId = await _context.Emails.Add(model);
                        }
                        else
                        {
                            await _context.Emails.Update(model);
                        }


                    }
                    foreach (Email email in emailList)
                    {
                        EmailModel deletedemail = emails.FirstOrDefault(t => t.EmailId == email.EmailId);
                        if (deletedemail == null)
                        {
                            email.IsActive = false;
                            await _context.Emails.Update(email);
                        }
                    }
                }

                if (addresses != null && addresses.Count() > 0)
                {
                    List<AddressModel> addresseslList = _context.Addresses.Get(user.UserId, EntityCategoryType.User);

                    foreach (AddressModel address in addresses)
                    {
                        Address model = new()
                        {
                            AddressId = address.AddressId,
                            CategoryTypeLevelId = address.CategoryTypeLevelId,//TODO
                            AddressLine1 = address.AddressLine1,
                            AddressLine2 = address.AddressLine2,
                            City = address.City,
                            StateId = address.StateId,
                            CountryId = address.CountryId,
                            Latitude = address.Latitude,
                            Longitude = address.Longitude,
                            ZipCode = address.ZipCode,
                            CompanyId = null,
                            UserId = user.UserId,
                            StoreId = null,
                            IsActive = address.IsActive
                        };

                        if (address.AddressId <= 0)
                        {
                            address.AddressId = await _context.Addresses.Add(model);
                        }
                        else
                        {
                            await _context.Addresses.Update(model);
                        }

                        if (address.CategoryTypeLevelId == (int)PrimaryCategoryTypeLevel.UserAddressMain)
                        {
                            AddressId = address.AddressId;
                        }

                    }
                    foreach (AddressModel address in addresseslList)
                    {
                        AddressModel deletedaddress = addresses.FirstOrDefault(t => t.AddressId == address.AddressId);
                        if (deletedaddress == null)
                        {
                            Address storeAddress = _mapper.Map<Address>(address);
                            storeAddress.IsActive = false;
                            await _context.Addresses.Update(storeAddress);
                        }
                    }
                }

            }
            catch (Exception) { };
        }
    }
}
