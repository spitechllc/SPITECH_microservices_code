﻿using FluentValidation;

namespace SpiTech.UserStoreManagement.Application.Commands.UpdateUser
{
    public class UpdateUserValidator : AbstractValidator<UpdateUserCommand>
    {
        public UpdateUserValidator()
        {
            RuleFor(x => x.UserId).NotNull().WithMessage("UserId is required");
            RuleForEach(x => x.Emails).ChildRules(c => c.RuleFor(email => email.Email).EmailAddress().NotEmpty().WithMessage("Emails Required"));

            // RuleFor(x => x.CompanyId).GreaterThan(0).WithMessage("CompanyId is required");
            // RuleFor(x => x.StoreId).GreaterThan(0).WithMessage("StoreId is required");
        }
    }
}
