﻿using AutoMapper;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;

namespace SpiTech.UserStoreManagement.Application.Abstracts
{
    public class ApplicationBase
    {
        public IUnitOfWork UnitOfWork { get; set; }
        public IMapper Mapper { get; set; }

        public ApplicationBase(IUnitOfWork unitOfWork, IMapper mapper)
        {
            UnitOfWork = unitOfWork;
            Mapper = mapper;
        }
    }
}
