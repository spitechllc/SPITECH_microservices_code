﻿using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.UserStoreManagement.Application.Repositories;

namespace SpiTech.UserStoreManagement.Application.UnitOfWorks
{
    public interface IUnitOfWork : IBaseUnitOfWork
    {
        IUserRepository Users { get; }
        IPhoneRepository Phones { get; }
        IEmailRepository Emails { get; }
        IAddressRepository Addresses { get; }
        ICompanyRepository Companies { get; }
        IStoreRepository Stores { get; }
        ICategoryTypeRepository Categories { get; }
        IDesignationRepository Designations { get; }
        IRegionRepository Regions { get; }
        ITitleRepository Titles { get; }
        ICategoryTypeLevelRepository CategoryTypeLevels { get; }
        ICountryRepository Countries { get; }
        IStateRepository States { get; }
        IAmenityRepository Amenities { get; }
        IStoreAmenityRepository StoreAmenities { get; }
        IWeekDaysRepository WeekDays { get; }
        IStoreHoursRepository StoreHours { get; }
        ICarWashTypeRepository CarWashTypes { get; }
        ITimeZoneRepository TimeZones { get; }
        IPosSystemRepository PosSystems { get; }
        ISaleAgentRepository SaleAgents { get; }
        IResellerRepository Resellers { get; }
        IStoreCategoryRepository StoreCategories { get; }
        IStoreGroupRepository StoreGroups { get; }
        IStoreGroupStoresRepository StoreGroupStores { get; }
        IStoreGroupUsersRepository StoreGroupUsers { get; }
    }
}
