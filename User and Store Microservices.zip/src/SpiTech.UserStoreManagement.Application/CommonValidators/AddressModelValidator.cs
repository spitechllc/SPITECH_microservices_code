﻿using FluentValidation;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.CommonValidators
{
    public class AddressModelValidator : AbstractValidator<AddressModel>
    {
        public AddressModelValidator()
        {
            RuleFor(x => x.AddressLine1).NotNull().Length(1, 50);
            // RuleFor(x => x.AddressLine2).NotNull().Length(1, 50);
            RuleFor(x => x.City).NotNull().Length(1, 50);
            RuleFor(x => x.StateId).GreaterThan(0);
            RuleFor(x => x.CountryId).GreaterThan(0);
            RuleFor(x => x.CategoryTypeLevelId).GreaterThan(0);

            When(t => t.Latitude != null, () =>
            {
                RuleFor(x => x).Must(LatitudeValidation).WithMessage("Latitude must be between -90 and 90 degrees inclusive.");
            });

            When(t => t.Longitude != null, () =>
            {
                RuleFor(x => x).Must(LongitudeValidation).WithMessage("Longitude must be between -180 and 180 degrees inclusive.");
            });
        }

        private static bool LatitudeValidation(AddressModel address)
        {
            return address.Latitude >= -90 && address.Latitude <= 90;
        }

        private static bool LongitudeValidation(AddressModel address)
        {
            return address.Longitude >= -180 && address.Longitude <= 180;
        }
    }
}
