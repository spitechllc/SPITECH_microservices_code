﻿using FluentValidation;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.CommonValidators
{
    public class EmailModelValidator : AbstractValidator<EmailModel>
    {
        public EmailModelValidator()
        {
            RuleFor(x => x.Email).NotNull().Length(1, 200);
            RuleFor(x => x.CategoryTypeLevelId).GreaterThan(0);
        }
    }
}
