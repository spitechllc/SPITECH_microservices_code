﻿using FluentValidation;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.CommonValidators
{
    public class PhoneModelValidator : AbstractValidator<PhoneModel>
    {
        public PhoneModelValidator()
        {
            RuleFor(x => x.Number).NotNull().Length(1, 20);
            RuleFor(x => x.CountryCode).NotNull().Length(1, 10);
            RuleFor(x => x.CategoryTypeLevelId).GreaterThan(0);
        }
    }
}
