﻿using FluentValidation;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.CommonValidators
{
    public class UserValidator : AbstractValidator<UserModel>
    {
        public UserValidator()
        {
            RuleFor(x => x.FirstName).NotNull().Length(1, 50);
            RuleFor(x => x.LastName).NotNull().Length(1, 50);
            RuleFor(x => x.UserName).NotNull().Length(1, 50);
            RuleFor(x => x.Password).NotNull().Length(1, 50);
            //  RuleFor(x => x.CompanyId).GreaterThan(0);
            // RuleFor(x => x.Title).GreaterThan(0);
            RuleForEach(x => x.Addresses).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Addresses).SetValidator(new AddressModelValidator());
            });
            RuleForEach(x => x.Emails).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Emails).SetValidator(new EmailModelValidator());
            });
            RuleForEach(x => x.Phones).NotNull().DependentRules(() =>
            {
                RuleForEach(q => q.Phones).SetValidator(new PhoneModelValidator());
            });
        }
    }
}
