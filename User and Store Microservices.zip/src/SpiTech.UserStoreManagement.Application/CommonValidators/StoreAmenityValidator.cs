﻿using FluentValidation;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.CommonValidators
{
    public class StoreAmenityValidator : AbstractValidator<StoreAmenityModel>
    {

        public StoreAmenityValidator()
        {
            RuleFor(a => a.AmenityId).GreaterThan(0).WithMessage("Amenity Name is required");
        }
    }
}
