﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreByCompanyId
{
    public class GetStoreByCompanyIdQuery : IRequest<ResponseList<StoreSearchResult>>
    {
        public int CompanyId { get; set; }
    }
}
