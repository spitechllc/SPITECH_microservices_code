﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetCompanyById
{
    public class GetCompanyByIdQuery : IRequest<CompanyModel>
    {
        public int CompanyId { get; set; }
    }
}
