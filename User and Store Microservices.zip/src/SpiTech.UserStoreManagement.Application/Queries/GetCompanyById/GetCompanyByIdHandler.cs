﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetCompanyById
{
    public class GetCompanyByIdHandler : IRequestHandler<GetCompanyByIdQuery, CompanyModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetCompanyByIdHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetCompanyByIdHandler(IUnitOfWork context,
                                   ILogger<GetCompanyByIdHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<CompanyModel> Handle(GetCompanyByIdQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            CompanyModel company = null;

            var companyFromDB = await _context.Companies.GetCompanyById(query.CompanyId);

            if (companyFromDB != null)
            {
                company = _mapper.Map<CompanyModel>(companyFromDB);

                company.Addresses = _context.Addresses.Get(company.Id, EntityCategoryType.Company);
                company.Emails = _mapper.Map<List<EmailModel>>(_context.Emails.Get(company.Id, EntityCategoryType.Company));
                company.Phones = _mapper.Map<List<PhoneModel>>(_context.Phones.Get(company.Id, EntityCategoryType.Company));
                // company.Owners = _mapper.Map<List<UserModel>>(_context.Users.Get(companylist.Id, EntityCategoryType.Company)).FirstOrDefault();

                //if (company.Owners != null)
                //{
                //    company.Owners.Addresses = _context.Addresses.Get(companylist.Owners.UserId, EntityCategoryType.User);
                //    company.Owners.Emails = _mapper.Map<List<EmailModel>>(_context.Emails.Get(companylist.Owners.UserId, EntityCategoryType.User));
                //    company.Owners.Phones = _mapper.Map<List<PhoneModel>>(_context.Phones.Get(companylist.Owners.UserId, EntityCategoryType.User));
                //}
            }

            _logger.TraceExitMethod(nameof(Handle), company);
            return company;
        }


    }
}
