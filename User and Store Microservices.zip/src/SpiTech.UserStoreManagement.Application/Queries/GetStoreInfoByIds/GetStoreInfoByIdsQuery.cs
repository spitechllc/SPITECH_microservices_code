﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreInfoByIds
{
    public class GetStoreInfoByIdsQuery : IRequest<List<StoreInfoModel>>
    {
        public int[] StoreIds { get; set; }
    }
}
