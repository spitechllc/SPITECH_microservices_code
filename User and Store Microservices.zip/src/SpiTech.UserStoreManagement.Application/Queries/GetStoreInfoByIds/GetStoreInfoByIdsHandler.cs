﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreInfoByIds
{
    public class GetStoreInfoByIdsQueryHandler : IRequestHandler<GetStoreInfoByIdsQuery, List<StoreInfoModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetStoreInfoByIdsQueryHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetStoreInfoByIdsQueryHandler(IUnitOfWork context,
                                    ILogger<GetStoreInfoByIdsQueryHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<List<StoreInfoModel>> Handle(GetStoreInfoByIdsQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            var result = await _context.Stores.GetStoreInfo(query.StoreIds);

            if (result != null && result.Any())
            {
                string[] ids = query.StoreIds.Select(x => x.ToString()).Distinct().ToArray(); 
                var addresses = await _context.Addresses.GetPrimaryAddressStoreByIds(ids, EntityCategoryType.Store);
                var emails = _context.Emails.GetEmailList(ids, EntityCategoryType.Store);
                var phones = _context.Phones.GetPhoneList(ids, EntityCategoryType.Store);

                foreach (var store in result)
                {
                    store.Addresses = addresses.Where(s => s.StoreId == store.StoreId);
                    store.Emails = _mapper.Map<List<EmailModel>>(emails.Where(s => s.StoreId == store.StoreId));
                    store.Phones = _mapper.Map<List<PhoneModel>>(phones.Where(s => s.StoreId == store.StoreId));
                }
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return await Task.FromResult(result);
        }
    }
}
