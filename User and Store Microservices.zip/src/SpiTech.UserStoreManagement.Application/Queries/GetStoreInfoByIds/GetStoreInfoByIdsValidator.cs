﻿using FluentValidation;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreInfoByIds
{
    public class GetStoreInfoByIdsQueryValidator : AbstractValidator<GetStoreInfoByIdsQuery>
    {
        public GetStoreInfoByIdsQueryValidator()
        {
            RuleFor(s => s.StoreIds).NotNull().NotEmpty();
        }
    }
}
