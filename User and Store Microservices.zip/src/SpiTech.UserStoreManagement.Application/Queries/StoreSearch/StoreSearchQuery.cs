﻿using MediatR;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.StoreSearch
{
    public class StoreSearchQuery : IRequest<PaginatedList<StoreSearchModel>>
    {
        public string Longitude { get; set; }
        public string Latitude { get; set; }
        public int Distance { get; set; }
        public int[] AmenityIds { get; set; }
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
    }
}