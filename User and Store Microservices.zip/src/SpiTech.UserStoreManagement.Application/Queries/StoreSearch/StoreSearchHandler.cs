﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Service.Clients.Mppa;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.StoreSearch
{
    public class StoreSearchHandler : IRequestHandler<StoreSearchQuery, PaginatedList<StoreSearchModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<StoreSearchHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IMppaServiceClient _mppaapiclient;

        public StoreSearchHandler(IUnitOfWork context,
                                    ILogger<StoreSearchHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper,
                                    IMppaServiceClient mppaapiclient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _mppaapiclient = mppaapiclient;
        }

        public async Task<PaginatedList<StoreSearchModel>> Handle(StoreSearchQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            var result = await _context.Stores.StoreSearch(query.AmenityIds, query.Longitude, query.Latitude, query.Distance, query.PageIndex, query.PageSize);

            int totalrecord = 0;
            if (result != null && result.Count() > 0)
            {
                totalrecord = result.Select(x => x.TotalRecord).FirstOrDefault();
            }

            if (query.PageSize > 0)
            {
                string[] siteIds = result.Where(s => !string.IsNullOrWhiteSpace(s.SiteId)).Select(s => s.SiteId.Trim()).Distinct().ToArray();
                ICollection<SiteProductModel> siteProducts = new List<SiteProductModel>();

                if (siteIds != null && siteIds.Any())
                {
                    siteProducts = (await _mppaapiclient.SiteProductAsync(siteIds))?.Data ?? new List<SiteProductModel>();
                }

                foreach (var store in result)
                {
                    store.PumpProducts = string.IsNullOrWhiteSpace(store.SiteId) ? new List<SiteProductModel>() : siteProducts.Where(t => t.SiteId == store.SiteId.Trim()).ToList();
                }
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return new PaginatedList<StoreSearchModel>
            {
                Data = result.ToList(),
                PageIndex = query.PageIndex,
                PageSize = query.PageSize,
                TotalCount = totalrecord
            };
        }
    }
}
