﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetCompanyByStoreId
{
    public class GetCompanyByStoreIdHandler : IRequestHandler<GetCompanyByStoreIdQuery, ResponseList<StoreSearchResult>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetCompanyByStoreIdHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetCompanyByStoreIdHandler(IUnitOfWork context,
                                   ILogger<GetCompanyByStoreIdHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<ResponseList<StoreSearchResult>> Handle(GetCompanyByStoreIdQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            ResponseList<StoreSearchResult> company = new();

            var companyFromDB = await _context.Stores.GetCompaniesByStoreId(query.StoreIds);

            if (companyFromDB != null)
            {
                company.Data = companyFromDB;
            }

            _logger.TraceExitMethod(nameof(Handle), company);
            return company;
        }


    }
}
