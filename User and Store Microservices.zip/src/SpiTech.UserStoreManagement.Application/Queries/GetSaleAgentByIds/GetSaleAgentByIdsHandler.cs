﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetSaleAgentByIds
{
    public class GetSaleAgentByIdsHandler : IRequestHandler<GetSaleAgentByIdsQuery, List<SaleAgentModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetSaleAgentByIdsHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetSaleAgentByIdsHandler(IUnitOfWork context,
                                    ILogger<GetSaleAgentByIdsHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<List<SaleAgentModel>> Handle(GetSaleAgentByIdsQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            List<SaleAgentModel> result = await _context.SaleAgents.GetSaleAgents(query.SaleAgentIds);

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;

        }
    }
}
