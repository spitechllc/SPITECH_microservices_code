﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Entities;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Application.Queries.GetSaleAgentByIds
{
    public class GetSaleAgentByIdsQuery : IRequest<List<SaleAgentModel>>
    {
        public int[] SaleAgentIds { get; set; }
    }
}
