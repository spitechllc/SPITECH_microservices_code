﻿using FluentValidation;

namespace SpiTech.UserStoreManagement.Application.Queries.GetSaleAgentByIds
{
    public class GetSaleAgentByIdsValidator : AbstractValidator<GetSaleAgentByIdsQuery>
    {
        public GetSaleAgentByIdsValidator()
        {
            RuleFor(s => s.SaleAgentIds).NotNull().NotEmpty().WithMessage("SaleAgentId is required").DependentRules(() => {
                RuleForEach(s => s.SaleAgentIds).NotNull().NotEmpty().GreaterThan(0).WithMessage("SaleAgentId is Invalid");
            });
        }
    }
}
