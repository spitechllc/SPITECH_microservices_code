﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentValidation;

namespace SpiTech.UserStoreManagement.Application.Queries.GetResellerByCompanyId
{
    public class GetResellerByCompanyIdValidator : AbstractValidator<GetResellerByCompanyIdQuery>
    {
        public GetResellerByCompanyIdValidator()
        {
            RuleFor(s => s.ComapnyId).GreaterThan(0).WithMessage("CompanyId is required");
        }
    }
}
