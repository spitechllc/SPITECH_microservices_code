﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;


namespace SpiTech.UserStoreManagement.Application.Queries.GetResellerByCompanyId
{
    public class GetResellerByCompanyIdHandler : IRequestHandler<GetResellerByCompanyIdQuery, ResellerModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetResellerByCompanyIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetResellerByCompanyIdHandler(IUnitOfWork context,
                                    ILogger<GetResellerByCompanyIdHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<ResellerModel> Handle(GetResellerByCompanyIdQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            ResellerModel result = _mapper.Map<ResellerModel>(await _context.Resellers.Get(query.ComapnyId));
            if (result != null)
            {
                result.Addresses = _context.Addresses.Get(result.ResellerId,EntityCategoryType.Reseller);
                result.Emails = _mapper.Map<List<EmailModel>>(_context.Emails.Get(result.ResellerId, EntityCategoryType.SaleAgent));
                result.Phones = _mapper.Map<List<PhoneModel>>(_context.Phones.Get(result.ResellerId, EntityCategoryType.SaleAgent));
                var resellerCompanies = await _context.Companies.GetByResellerId(result.ResellerId);
                if(resellerCompanies != null && resellerCompanies.Count>0)
                {
                    result.Companies = resellerCompanies;
                    result.CompanyIds = resellerCompanies.Select(t => t.Id).ToArray();
                }
                
            }
                _logger.TraceExitMethod(nameof(Handle), result);

            return await Task.FromResult(result);

        }
    }
}
