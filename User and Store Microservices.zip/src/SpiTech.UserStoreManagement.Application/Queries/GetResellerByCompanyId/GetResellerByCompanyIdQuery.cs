﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Entities;

namespace SpiTech.UserStoreManagement.Application.Queries.GetResellerByCompanyId
{
    public class GetResellerByCompanyIdQuery : IRequest<ResellerModel>
    {
        public int ComapnyId { get; set; }
    }
}
