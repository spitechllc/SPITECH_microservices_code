﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetCompanyOwners
{
    public class GetCompanyOwnersHandler : IRequestHandler<GetCompanyOwnersQuery, PaginatedList<CompanyOwnerModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetCompanyOwnersHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IIdentityServiceClient _identityapiclient;

        public GetCompanyOwnersHandler(IUnitOfWork context,
                                    ILogger<GetCompanyOwnersHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper,
                                    IIdentityServiceClient identityapiclient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _identityapiclient = identityapiclient;
        }
        public async Task<PaginatedList<CompanyOwnerModel>> Handle(GetCompanyOwnersQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            List<UserModel> userList = new();
            List<CompanyOwnerModel> result = new();
            int totalRecord = 0;
            try
            {
                IEnumerable<Service.Clients.Identity.UserModel> users = await _identityapiclient.GetUsersByRoleAsync("StoreOwner");
                if (users != null && users.Count() > 0)
                {
                    userList = await _context.Users.GetOwnersWithPaging(query.FirstName, query.LastName, null, null, query.Email, query.Phone, null, query.PageIndex, query.PageSize, query.SortBy, query.SortOrder, "", "", "", users.Select(t => t.UserId).Distinct().ToArray());
                    if (userList != null && userList.Count() > 0)
                    {
                        var ownerCompanies = await _context.Companies.GetByOwnerIds(userList.Select(t => t.UserId).ToArray());
                        foreach (UserModel item in userList)
                        {
                            CompanyOwnerModel  companyOwnerModel = new CompanyOwnerModel();
                            item.Roles = _mapper.Map<IEnumerable<Domain.Models.RoleModel>>(users.FirstOrDefault(t => t.UserId == item.UserId).Roles);

                            totalRecord = totalRecord + 1;
                            companyOwnerModel.Owner = item;
                            companyOwnerModel.Companies = ownerCompanies.Where(t => t.OwnerId == item.UserId).ToList();
                            companyOwnerModel.CompanyIds = ownerCompanies.Where(t => t.OwnerId == item.UserId).Select(t => t.Id).ToArray();
                            result.Add(companyOwnerModel);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw;
            }
            _logger.TraceExitMethod(nameof(Handle), result);

            return await Task.FromResult(new PaginatedList<CompanyOwnerModel>
            {
                Data = result,
                PageIndex = query.PageIndex ?? 0,
                PageSize = query.PageSize ?? 0,
                TotalCount = totalRecord,
            });

        }
    }
}
