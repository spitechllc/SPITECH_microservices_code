﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetCompanyByUserId
{
    public class GetCompanyByUserIdHandler : IRequestHandler<GetCompanyByUserIdQuery, ResponseList<CompanyModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetCompanyByUserIdHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetCompanyByUserIdHandler(IUnitOfWork context,
                                   ILogger<GetCompanyByUserIdHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<ResponseList<CompanyModel>> Handle(GetCompanyByUserIdQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            this.userAuthenticationProvider.ValidateUserAccess(query.UserId);
            IEnumerable<CompanyModel> companylist = _mapper.Map<IEnumerable<CompanyModel>>(await _context.Companies.GetCompanyByUserId(query.UserId));

            foreach (CompanyModel comp in companylist)
            {
                comp.Addresses = _context.Addresses.Get(comp.Id, EntityCategoryType.Company);
                comp.Emails = _mapper.Map<List<EmailModel>>(_context.Emails.Get(comp.Id, EntityCategoryType.Company));
                comp.Phones = _mapper.Map<List<PhoneModel>>(_context.Phones.Get(comp.Id, EntityCategoryType.Company));
                //comp.Owners = _mapper.Map<List<UserModel>>(_context.Users.Get(comp.Id, EntityCategoryType.Company)).FirstOrDefault();
                //if (comp.Owners != null)
                //{
                //    comp.Owners.Addresses = _context.Addresses.Get(comp.Owners.UserId, EntityCategoryType.User);
                //    comp.Owners.Emails = _mapper.Map<List<EmailModel>>(_context.Emails.Get(comp.Owners.UserId, EntityCategoryType.User));
                //    comp.Owners.Phones = _mapper.Map<List<PhoneModel>>(_context.Phones.Get(comp.Owners.UserId, EntityCategoryType.User));
                //}
            }

            _logger.TraceExitMethod(nameof(Handle), query);

            return await Task.FromResult(new ResponseList<CompanyModel> { Data = companylist.ToList() });
        }
    }
}
