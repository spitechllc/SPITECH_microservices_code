﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetCompanyByUserId
{
    public class GetCompanyByUserIdQuery : IRequest<ResponseList<CompanyModel>>
    {
        public int UserId { get; set; }
    }
}
