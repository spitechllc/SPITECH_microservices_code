﻿using FluentValidation;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoresPrimaryDetailsBySiteIds
{
    public class GetStoresPrimaryDetailsBySiteIdsValidator : AbstractValidator<GetStoresPrimaryDetailsBySiteIdsQuery>
    {

        public GetStoresPrimaryDetailsBySiteIdsValidator()
        {
            RuleFor(s => s.SiteIds).NotNull().NotEmpty().WithMessage("StoreId is reuired.");
        }
    }
}
