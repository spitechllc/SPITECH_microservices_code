﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoresPrimaryDetailsBySiteIds
{
    public class GetStoresPrimaryDetailsBySiteIdsHandler : IRequestHandler<GetStoresPrimaryDetailsBySiteIdsQuery, List<StoreSearchResult>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetStoresPrimaryDetailsBySiteIdsHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetStoresPrimaryDetailsBySiteIdsHandler(IUnitOfWork context,
                                 ILogger<GetStoresPrimaryDetailsBySiteIdsHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<List<StoreSearchResult>> Handle(GetStoresPrimaryDetailsBySiteIdsQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            var siteids = request.SiteIds.Distinct().ToArray();

            List<StoreSearchResult> storesearchresult = _mapper.Map<List<StoreSearchResult>>(await _context.Stores.GetStoreBySiteIds(siteids));

            var storeIds = storesearchresult.Select(s => s.StoreId.ToString()).Distinct().ToArray();

            List<AddressModel> addresses = await _context.Addresses.GetPrimaryAddressStoreByIds(storeIds, EntityCategoryType.Store);

            foreach (StoreSearchResult store in storesearchresult)
            {
                store.Addresses = addresses.Where(s => s.StoreId == store.StoreId);
            }

            _logger.TraceExitMethod(nameof(Handle), storesearchresult);

            return storesearchresult;
        }
    }
}