﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreHoursByStoreId
{
    public class GetStoreHoursByStoreIdHandler : IRequestHandler<GetStoreHoursByStoreIdQuery, ResponseList<StoreHoursModel>>
    {


        private readonly IUnitOfWork _context;
        private readonly ILogger<GetStoreHoursByStoreIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetStoreHoursByStoreIdHandler(IUnitOfWork context,
                                    ILogger<GetStoreHoursByStoreIdHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<ResponseList<StoreHoursModel>> Handle(GetStoreHoursByStoreIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<StoreHoursModel> StoreHoursList = _mapper.Map<IEnumerable<StoreHoursModel>>(await _context.StoreHours.GetStoreHoursByStoreId(request.StoreId));

            _logger.TraceExitMethod(nameof(Handle), StoreHoursList);
            return new ResponseList<StoreHoursModel>() { Data = StoreHoursList };
        }
    }
}
