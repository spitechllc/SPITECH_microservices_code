﻿using FluentValidation;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreBySiteId
{
    public class GetStoreBySiteIdQueryValidator : AbstractValidator<GetStoreBySiteIdQuery>
    {
        public GetStoreBySiteIdQueryValidator()
        {
            RuleFor(s => s.SiteId).NotNull().WithMessage("Please Enter SiteId");
        }
    }
}
