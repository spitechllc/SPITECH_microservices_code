﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreBySiteId
{
    public class GetStoreBySiteIdQueryHandler : IRequestHandler<GetStoreBySiteIdQuery, StoreSearchResult>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetStoreBySiteIdQueryHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IMppaServiceClient _mppaapiclient;

        public GetStoreBySiteIdQueryHandler(IUnitOfWork context,
                                    ILogger<GetStoreBySiteIdQueryHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper,
                                    IMppaServiceClient mppaapiclient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _mppaapiclient = mppaapiclient;
        }
        public async Task<StoreSearchResult> Handle(GetStoreBySiteIdQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            StoreSearchResult result = _mapper.Map<StoreSearchResult>(await _context.Stores.GetStore(query.SiteId, null));

            if (result == null)
            {
                return null;
            }
            Domain.Entities.Company comp = await _context.Companies.GetCompanyById(result.CompanyId);
            if (comp != null)
            {
                result.Company = comp.Name;
            }

            if (result != null)
            {
                result.Addresses = _context.Addresses.Get(result.StoreId, EntityCategoryType.Store);
                result.Emails = _mapper.Map<List<EmailModel>>(_context.Emails.Get(result.StoreId, EntityCategoryType.Store));
                result.Phones = _mapper.Map<List<PhoneModel>>(_context.Phones.Get(result.StoreId, EntityCategoryType.Store));
                result.Amenities = await _context.StoreAmenities.GetAmenityByStoreId(result.StoreId);
                result.StoreHours = await _context.StoreHours.GetHoursByStoreId(result.StoreId);
                result.PumpProducts = string.IsNullOrWhiteSpace(result.SiteId) ? null : (await _mppaapiclient.SiteProductAsync(new[] { result.SiteId }))?.Data;
                result.CarWashTypes = await _context.CarWashTypes.GetByStoreId(result.StoreId);
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return await Task.FromResult(result);
        }
    }
}
