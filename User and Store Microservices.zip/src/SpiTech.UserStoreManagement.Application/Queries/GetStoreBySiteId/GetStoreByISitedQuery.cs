﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreBySiteId
{
    public class GetStoreBySiteIdQuery : IRequest<StoreSearchResult>
    {
        public string SiteId { get; set; }
    }
}
