﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetCarWashTypeByStoreId
{
    public class GetCarWashTypeByStoreIdHandler : IRequestHandler<GetCarWashTypeByStoreIdQuery, ResponseList<CarWashTypeModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetCarWashTypeByStoreIdHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetCarWashTypeByStoreIdHandler(IUnitOfWork context,
                                   ILogger<GetCarWashTypeByStoreIdHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<ResponseList<CarWashTypeModel>> Handle(GetCarWashTypeByStoreIdQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            IEnumerable<CarWashTypeModel> carwashtypeList = _mapper.Map<IEnumerable<CarWashTypeModel>>(await _context.CarWashTypes.GetByStoreId(query.StoreId));

            _logger.TraceExitMethod(nameof(Handle), query);

            return await Task.FromResult(new ResponseList<CarWashTypeModel> { Data = carwashtypeList.ToList() });
        }


    }
}
