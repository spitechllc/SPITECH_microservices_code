﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetCarWashTypeByStoreId
{
    public class GetCarWashTypeByStoreIdQuery : IRequest<ResponseList<CarWashTypeModel>>
    {
        public int StoreId { get; set; }
    }
}
