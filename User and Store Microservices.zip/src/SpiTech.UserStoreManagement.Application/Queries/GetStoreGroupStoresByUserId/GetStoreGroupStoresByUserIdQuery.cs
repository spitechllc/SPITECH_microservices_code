﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreGroupStoresByUserId
{
    public class GetStoreGroupStoresByUserIdQuery : IRequest<ResponseList<StoreGroupUsersModel>>
    {
      public int UserId { get; set; }
    }
}
