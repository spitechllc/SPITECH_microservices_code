﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreGroupStoresByUserId
{
    public class GetStoreGroupStoresByUserIdHandler : IRequestHandler<GetStoreGroupStoresByUserIdQuery, ResponseList<StoreGroupUsersModel>>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetStoreGroupStoresByUserIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        public GetStoreGroupStoresByUserIdHandler(IUnitOfWork context,
                                 ILogger<GetStoreGroupStoresByUserIdHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<ResponseList<StoreGroupUsersModel>> Handle(GetStoreGroupStoresByUserIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<StoreGroupUsersModel> result;
            try
            {

                result = await _context.StoreGroupUsers.GetByUserId(request.UserId);
               

                _logger.TraceExitMethod(nameof(Handle), result);
            }
            catch (Exception ex)
            {
                throw;
            }
            return new ResponseList<StoreGroupUsersModel>() { Data = result };
        }
    }
}