﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStateAutoComplete
{
    public class GetStateAutoCompleteQuery : IRequest<ResponseList<StateAutoCompleteModel>>
    {
        public int StateId { get; set; }
        public string StateName { get; set; }
    }
}
