﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetCompanyWithPaging
{
    public class GetCompanyWithPagingHandler : IRequestHandler<GetCompanyWithPagingQuery, PaginatedList<CompanyModel>>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetCompanyWithPagingHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetCompanyWithPagingHandler(IUnitOfWork context,
                                 ILogger<GetCompanyWithPagingHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper
                                  )
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<PaginatedList<CompanyModel>> Handle(GetCompanyWithPagingQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            int totalRecord = 0;

            List<CompanyModel> companylist = _mapper.Map<List<CompanyModel>>(await _context.Companies.GetCompanyWithPaging
                (request.CompanyName,request.City,request.StateId,request.ZipCode ,request.PageIndex, request.PageSize,
                request.sortable?.SortBy, request.sortable?.SortOrder));

            if (companylist != null && companylist.Count() > 0)
            {
                totalRecord = companylist.Select(x => x.TotalRecord).FirstOrDefault();
            }

            foreach (CompanyModel comp in companylist)
            {
                comp.Addresses = _context.Addresses.Get(comp.Id, EntityCategoryType.Company);
                comp.Emails = _mapper.Map<List<EmailModel>>(_context.Emails.Get(comp.Id, EntityCategoryType.Company));
                comp.Phones = _mapper.Map<List<PhoneModel>>(_context.Phones.Get(comp.Id, EntityCategoryType.Company));
                //comp.Owners = _mapper.Map<List<UserModel>>(_context.Users.Get(comp.Id, EntityCategoryType.Company)).FirstOrDefault();
                //if (comp.Owners != null)
                //{
                //    comp.Owners.Addresses = _context.Addresses.Get(comp.Owners.UserId, EntityCategoryType.User);
                //    comp.Owners.Emails = _mapper.Map<List<EmailModel>>(_context.Emails.Get(comp.Owners.UserId, EntityCategoryType.User));
                //    comp.Owners.Phones = _mapper.Map<List<PhoneModel>>(_context.Phones.Get(comp.Owners.UserId, EntityCategoryType.User));
                //}
            }

            _logger.TraceExitMethod(nameof(Handle), companylist);

            return new PaginatedList<CompanyModel>
            {
                Data = companylist,
                PageIndex = request.PageIndex ?? 0,
                PageSize = request.PageSize ?? 0,
                TotalCount = totalRecord,
            };
        }
    }
}
