﻿using FluentValidation;

namespace SpiTech.UserStoreManagement.Application.Queries.GetCompanyOwnerById
{
    public class GetCompanyOwnerByIdValidator : AbstractValidator<GetCompanyOwnerByIdQuery>
    {
        public GetCompanyOwnerByIdValidator()
        {
            RuleFor(s => s.OwnerId).GreaterThan(0).WithMessage("OwnerId is required");
        }
    }
}
