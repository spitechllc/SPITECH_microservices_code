﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;


namespace SpiTech.UserStoreManagement.Application.Queries.GetCompanyOwnerById
{
    public class GetCompanyOwnerByIdHandler : IRequestHandler<GetCompanyOwnerByIdQuery, CompanyOwnerModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetCompanyOwnerByIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetCompanyOwnerByIdHandler(IUnitOfWork context,
                                    ILogger<GetCompanyOwnerByIdHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<CompanyOwnerModel> Handle(GetCompanyOwnerByIdQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            UserModel user = _mapper.Map<UserModel>(await _context.Users.Get(query.OwnerId));
            CompanyOwnerModel result = new();
            
            if (user != null)
            {
                result.Owner = user; 
                user.Addresses = _mapper.Map<List<AddressModel>>(_context.Addresses.Get(user.UserId, EntityCategoryType.User));
                user.Emails = _mapper.Map<List<EmailModel>>(_context.Emails.Get(user.UserId, EntityCategoryType.User));
                user.Phones = _mapper.Map<List<PhoneModel>>(_context.Phones.Get(user.UserId, EntityCategoryType.User));
                var ownerCompanies = await _context.Companies.GetByOwnerId(user.UserId);
                if(ownerCompanies != null && ownerCompanies.Count>0)
                {
                    result.Companies = ownerCompanies;
                    result.CompanyIds = ownerCompanies.Select(t => t.Id).ToArray();
                }
                
            }
                _logger.TraceExitMethod(nameof(Handle), result);

            return await Task.FromResult(result);

        }
    }
}
