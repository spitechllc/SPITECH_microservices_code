﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetCompanyOwnerById
{
    public class GetCompanyOwnerByIdQuery : IRequest<CompanyOwnerModel>
    {
        public int OwnerId { get; set; }
    }
}
