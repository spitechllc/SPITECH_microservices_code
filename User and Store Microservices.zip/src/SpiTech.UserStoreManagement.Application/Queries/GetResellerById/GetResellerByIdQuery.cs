﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Entities;

namespace SpiTech.UserStoreManagement.Application.Queries.GetResellerById
{
    public class GetResellerByIdQuery : IRequest<ResellerModel>
    {
        public int ResellerId { get; set; }
    }
}
