﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;


namespace SpiTech.UserStoreManagement.Application.Queries.GetResellerById
{
    public class GetResellerByIdHandler : IRequestHandler<GetResellerByIdQuery, ResellerModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetResellerByIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetResellerByIdHandler(IUnitOfWork context,
                                    ILogger<GetResellerByIdHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<ResellerModel> Handle(GetResellerByIdQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            ResellerModel result = _mapper.Map<ResellerModel>(await _context.Resellers.Get(query.ResellerId));
            if (result != null)
            {
                result.Addresses = _context.Addresses.Get(result.ResellerId,EntityCategoryType.Reseller);
                result.Emails = _mapper.Map<List<EmailModel>>(_context.Emails.Get(result.ResellerId, EntityCategoryType.Reseller));
                result.Phones = _mapper.Map<List<PhoneModel>>(_context.Phones.Get(result.ResellerId, EntityCategoryType.Reseller));
                var resellerCompanies = await _context.Companies.GetByResellerId(result.ResellerId);
                if(resellerCompanies != null && resellerCompanies.Count>0)
                {
                    result.Companies = resellerCompanies;
                    result.CompanyIds = resellerCompanies.Select(t => t.Id).ToArray();
                }
                
            }
                _logger.TraceExitMethod(nameof(Handle), result);

            return await Task.FromResult(result);

        }
    }
}
