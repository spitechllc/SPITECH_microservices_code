﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentValidation;

namespace SpiTech.UserStoreManagement.Application.Queries.GetResellerById
{
    public class GetResellerByIdValidator : AbstractValidator<GetResellerByIdQuery>
    {
        public GetResellerByIdValidator()
        {
            RuleFor(s => s.ResellerId).GreaterThan(0).WithMessage("ResellerId is required");
        }
    }
}
