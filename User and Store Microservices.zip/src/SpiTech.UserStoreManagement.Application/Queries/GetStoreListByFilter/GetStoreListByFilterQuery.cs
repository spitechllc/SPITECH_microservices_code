﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.UserStoreManagement.Domain.FilterOptions;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreListByFilter
{
    public class GetStoreListByFilterQuery : IRequest<PaginatedList<StoreSearchResult>>
    {
        public StoreFilter filter { get; set; }
        //public Paginable paginable { get; set; }
        public int? PageSize { get; set; }
        public int? PageIndex { get; set; }
        public Sortable sortable { get; set; }
    }
}
