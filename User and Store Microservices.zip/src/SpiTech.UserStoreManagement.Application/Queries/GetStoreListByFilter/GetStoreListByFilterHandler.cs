﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Service.Clients.Mppa;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreListByFilter
{
    public class GetStoreListByFilterHandler : IRequestHandler<GetStoreListByFilterQuery, PaginatedList<StoreSearchResult>>
    {
        private readonly IMediator _mediater;
        private readonly ILogger<GetStoreListByFilterHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly IMppaServiceClient _mppaapiclient;

        public GetStoreListByFilterHandler(IMediator mediater,
                                       ILogger<GetStoreListByFilterHandler> logger,
                                       IUnitOfWork context,
                                       IMapper mapper,
                                       IMppaServiceClient mppaapiclient)
        {
            _mediater = mediater;
            _logger = logger;
            _context = context;
            _mapper = mapper;
            _mppaapiclient = mppaapiclient;
        }

        public async Task<PaginatedList<StoreSearchResult>> Handle(GetStoreListByFilterQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            int totalRecord = 0;
            IEnumerable<StoreSearchResult> storeList = await _context.Stores.GetStoreByFilter(query.filter, query.PageIndex, query.PageSize, query.sortable);

            var ids = storeList.Select(s => s.StoreId.ToString()).Distinct().ToArray();

            List<AddressModel> addresses = await _context.Addresses.GetPrimaryAddressStoreByIds(ids, EntityCategoryType.Store);
            List<Domain.Entities.Email> emaillist = _context.Emails.GetEmailList(ids, EntityCategoryType.Store);
            List<Domain.Entities.Phone> phonelist = _context.Phones.GetPhoneList(ids, EntityCategoryType.Store);
            List<StoreAmenityResultModel> amenities = await _context.StoreAmenities.GetAmenityListByStoreIds(ids);
            List<StoreHoursResultModel> storeHours = await _context.StoreHours.GetStoreHoursListByStoreIds(ids);
            List<CarWashTypeModel> carwashtype = await _context.CarWashTypes.GetListByStoreIds(storeList.Select(s => s.StoreId.ToString()).Distinct().ToArray());

            string[] siteIds = storeList.Where(s => !string.IsNullOrWhiteSpace(s.SiteId)).Select(s => s.SiteId.Trim()).Distinct().ToArray();
            ICollection<SiteProductModel> siteProducts = new List<SiteProductModel>();

            if (siteIds != null && siteIds.Any())
            {
                siteProducts = (await _mppaapiclient.SiteProductAsync(siteIds))?.Data ?? new List<SiteProductModel>();
            }

            foreach (StoreSearchResult store in storeList)
            {
                totalRecord = store.TotalRecord;
                store.Addresses = addresses.Where(s => s.StoreId == store.StoreId);
                store.Emails = _mapper.Map<List<EmailModel>>(emaillist.Where(s => s.StoreId == store.StoreId));
                store.Phones = _mapper.Map<List<PhoneModel>>(phonelist.Where(s => s.StoreId == store.StoreId));
                store.StoreHours = _mapper.Map<List<StoreHoursResult>>(storeHours.Where(s => s.StoreId == store.StoreId));
                store.Amenities = _mapper.Map<List<StoreAmenitySearchResult>>(amenities.Where(s => s.StoreId == store.StoreId));

                store.PumpProducts = string.IsNullOrWhiteSpace(store.SiteId) ? new List<SiteProductModel>() : siteProducts.Where(t => t.SiteId == store.SiteId.Trim()).ToList();
                store.CarWashTypes = carwashtype.Where(s => s.StoreId == store.StoreId);
            }

            _logger.TraceExitMethod(nameof(Handle), query);
            int skiprow = 0;
            if (query.PageIndex.HasValue && query.PageSize.HasValue)
            {
                skiprow = (query.PageIndex.Value - 1) * query.PageSize.Value;
                storeList.Skip(skiprow).Take(query.PageSize ?? 1000);
            }
            return await Task.FromResult(new PaginatedList<StoreSearchResult> { Data = storeList.ToList(), TotalCount = totalRecord, PageSize = query.PageSize ?? 0, });
        }
    }
}
