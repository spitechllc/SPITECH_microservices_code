﻿using FluentValidation;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreListByFilter
{
    public class GetStoreListByFilterValidator : AbstractValidator<GetStoreListByFilterQuery>
    {

        public GetStoreListByFilterValidator()
        {
            RuleFor(s => s.filter.Latitude).NotNull().WithMessage("Latitude is requried");

            RuleFor(s => s.filter.Longitude).NotNull().WithMessage("Longitude is requried");

            RuleFor(s => s.filter.Distance).GreaterThan(0).WithMessage("Distance must be greater than 0.");
        }
    }
}
