﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetUserWithPrimaryDetails
{
    public class GetUserWithPrimaryDetailsQuery : IRequest<UserUpdateModel>
    {
        public int entityId { get; set; }
        public EntityCategoryType entityType { get; set; }
    }
}
