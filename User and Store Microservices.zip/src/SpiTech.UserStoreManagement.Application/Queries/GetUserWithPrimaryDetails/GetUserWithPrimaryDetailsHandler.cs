﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetUserWithPrimaryDetails
{
    public class GetUserWithPrimaryDetailsHandler : IRequestHandler<GetUserWithPrimaryDetailsQuery, UserUpdateModel>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetUserWithPrimaryDetailsHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetUserWithPrimaryDetailsHandler(IUnitOfWork context,
                                 ILogger<GetUserWithPrimaryDetailsHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<UserUpdateModel> Handle(GetUserWithPrimaryDetailsQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            if (request.entityType == EntityCategoryType.User)
            {
                this.userAuthenticationProvider.ValidateUserAccess(request.entityId);
            }
            UserUpdateModel userlist = new();

            if (request.entityType == EntityCategoryType.Company)
            {
                userlist = _mapper.Map<UserUpdateModel>(await _context.Users.GetUser(request.entityId, EntityCategoryType.Company));
            }
            else if (request.entityType == EntityCategoryType.Store)
            {
                userlist = _mapper.Map<UserUpdateModel>(await _context.Users.GetUser(request.entityId, EntityCategoryType.Store));
            }
            else if (request.entityType == EntityCategoryType.User)
            {
                userlist = _mapper.Map<UserUpdateModel>(await _context.Users.GetUser(request.entityId, EntityCategoryType.User));
            }

            if (userlist != null)
            {
                userlist.Addresses = new List<AddressModel> { await _context.Addresses.GetPrimaryAddress(userlist.UserId, EntityCategoryType.User) };
                userlist.Emails = _mapper.Map<IEnumerable<EmailModel>>(await _context.Emails.GetPrimaryEmail(userlist.UserId, EntityCategoryType.User));
                userlist.Phones = _mapper.Map<IEnumerable<PhoneModel>>(await _context.Phones.GetPrimaryPhone(userlist.UserId, EntityCategoryType.User));
            }

            _logger.TraceExitMethod(nameof(Handle), request);

            return await Task.FromResult(userlist);
        }
    }
}
