﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Entities;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Application.Queries.GetResellerByIds
{
    public class GetResellerByIdsQuery : IRequest<List<ResellerModel>>
    {
        public int[] ResellerIds { get; set; }
    }
}
