﻿using FluentValidation;

namespace SpiTech.UserStoreManagement.Application.Queries.GetResellerByIds
{
    public class GetResellerByIdsValidator : AbstractValidator<GetResellerByIdsQuery>
    {
        public GetResellerByIdsValidator()
        {
            RuleFor(s => s.ResellerIds).NotNull().NotEmpty().WithMessage("ResellerId is required").DependentRules(() => {
                RuleForEach(s => s.ResellerIds).NotNull().NotEmpty().GreaterThan(0).WithMessage("ResellerId is Invalid");
            });
        }
    }
}
