﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetResellerByIds
{
    public class GetResellerByIdsHandler : IRequestHandler<GetResellerByIdsQuery, List<ResellerModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetResellerByIdsHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetResellerByIdsHandler(IUnitOfWork context,
                                    ILogger<GetResellerByIdsHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<List<ResellerModel>> Handle(GetResellerByIdsQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            List<ResellerModel> result = await _context.Resellers.GetResellers(query.ResellerIds);

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;

        }
    }
}
