﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetTitle
{
    public class GetTitleHandler : IRequestHandler<GetTitleQuery, ResponseList<TitleModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetTitleHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetTitleHandler(IUnitOfWork context,
                                   ILogger<GetTitleHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<ResponseList<TitleModel>> Handle(GetTitleQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            IEnumerable<TitleModel> list = _mapper.Map<IEnumerable<TitleModel>>(await _context.Titles.GetTitle());

            return await Task.FromResult(new ResponseList<TitleModel> { Data = list.ToList() });
        }

    }
}
