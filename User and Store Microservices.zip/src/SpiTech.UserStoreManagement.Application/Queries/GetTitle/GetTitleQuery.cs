﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetTitle
{
    public class GetTitleQuery : IRequest<ResponseList<TitleModel>>
    {
        public int Id { get; set; }
    }
}
