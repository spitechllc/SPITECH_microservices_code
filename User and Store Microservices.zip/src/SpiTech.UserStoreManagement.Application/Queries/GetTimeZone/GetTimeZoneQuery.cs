﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetTimeZone
{
    public class GetTimeZoneQuery : IRequest<ResponseList<TimeZoneModel>>
    {
    }
}
