﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Entities;

namespace SpiTech.UserStoreManagement.Application.Queries.GetPosSystem
{
    public class GetPosSystemQuery : IRequest<ResponseList<PosSystem>>
    {
    }
}
