﻿using FluentValidation;

namespace SpiTech.UserStoreManagement.Application.Queries.GetCategoryTypeLevel
{
    public class GetCategoryTypeLevelValidator : AbstractValidator<GetCategoryTypeLevelQuery>
    {
        public GetCategoryTypeLevelValidator()
        {
            RuleFor(s => s.CategoryType).NotNull().WithMessage("Category Type is requried");
        }
    }
}
