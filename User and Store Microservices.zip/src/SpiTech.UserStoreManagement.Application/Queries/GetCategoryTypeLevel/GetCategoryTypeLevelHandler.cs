﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetCategoryTypeLevel
{
    public class GetCategoryTypeLevelHandler : IRequestHandler<GetCategoryTypeLevelQuery, ResponseList<CategoryTypeLevelModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetCategoryTypeLevelHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetCategoryTypeLevelHandler(IUnitOfWork context,
                                   ILogger<GetCategoryTypeLevelHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<ResponseList<CategoryTypeLevelModel>> Handle(GetCategoryTypeLevelQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            IEnumerable<CategoryTypeLevelModel> list = _mapper.Map<IEnumerable<CategoryTypeLevelModel>>(await _context.CategoryTypeLevels.GetCategoryTypeLevel(query.CategoryType));

            return await Task.FromResult(new ResponseList<CategoryTypeLevelModel> { Data = list.ToList() });
        }

    }
}
