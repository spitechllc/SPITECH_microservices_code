﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetSaleAgents
{
    public class GetSaleAgentsHandler : IRequestHandler<GetSaleAgentsQuery, PaginatedList<SaleAgentModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetSaleAgentsHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetSaleAgentsHandler(IUnitOfWork context,
                                    ILogger<GetSaleAgentsHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<PaginatedList<SaleAgentModel>> Handle(GetSaleAgentsQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            int totalRecord = 0;

            List<SaleAgentModel> result = await _context.SaleAgents.GetSaleAgentByFilters(query.Name, query.Mobile, query.Email, query.StoreName, query.PageIndex, query.PageSize, query.SortBy, query.SortOrder);

            if (result != null)
            {
                string[] ids = result.Select(s => s.SaleAgentId.ToString()).Distinct().ToArray();
                var emails = _context.Emails.GetEmailList(ids, EntityCategoryType.SaleAgent);
                var phones = _context.Phones.GetPhoneList(ids, EntityCategoryType.SaleAgent);
                var addresses = await _context.Addresses.GetPrimaryAddressStoreByIds(ids, EntityCategoryType.SaleAgent);
                //var saleAgentStores = await _context.Stores.GetBySaleAgentIds(ids);

                foreach (SaleAgentModel saleAgent in result)
                {
                    totalRecord = saleAgent.TotalRecord;
                    saleAgent.Addresses = addresses.Where(t => t.SaleAgentId == saleAgent.SaleAgentId).ToList();
                    saleAgent.Emails = _mapper.Map<List<EmailModel>>(emails.Where(t => t.SaleAgentId == saleAgent.SaleAgentId).ToList());
                    saleAgent.Phones = _mapper.Map<List<PhoneModel>>(phones.Where(t => t.SaleAgentId == saleAgent.SaleAgentId).ToList());
                    //saleAgent.Stores = saleAgentStores.Where(t => t.SaleAgentId == saleAgent.SaleAgentId).ToList();
                }
            }
            _logger.TraceExitMethod(nameof(Handle), result);

            return new PaginatedList<SaleAgentModel>
            {
                Data = result,
                PageIndex = query.PageIndex ?? 0,
                PageSize = query.PageSize ?? 0,
                TotalCount = totalRecord,
            };

        }
    }
}
