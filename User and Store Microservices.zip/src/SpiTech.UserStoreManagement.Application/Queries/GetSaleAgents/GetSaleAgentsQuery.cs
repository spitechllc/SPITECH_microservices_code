﻿using MediatR;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;

namespace SpiTech.UserStoreManagement.Application.Queries.GetSaleAgents
{
    public class GetSaleAgentsQuery : IRequest<PaginatedList<SaleAgentModel>>
    {
        public string Name { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string StoreName { get; set; }
        public int? PageIndex { get; set; }
        public int? PageSize { get; set; }
        public SaleAgentSortBy? SortBy { get; set; }
        public SortOrderEnum? SortOrder { get; set; }
    }
}
