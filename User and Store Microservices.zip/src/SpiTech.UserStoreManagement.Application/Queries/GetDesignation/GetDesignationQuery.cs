﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetDesignation
{
    public class GetDesignationQuery : IRequest<ResponseList<DesignationModel>>
    {
        public int Id { get; set; }
    }
}
