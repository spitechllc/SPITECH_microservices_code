﻿using FluentValidation;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStateByCountryId
{
    public class GetStateByCountryIdValidator : AbstractValidator<GetStateByCountryIdQuery>
    {

        public GetStateByCountryIdValidator()
        {
            RuleFor(s => s.CountryId).GreaterThan(0);
        }
    }
}
