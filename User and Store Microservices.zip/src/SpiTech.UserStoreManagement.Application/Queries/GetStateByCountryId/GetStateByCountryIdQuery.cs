﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStateByCountryId
{
    public class GetStateByCountryIdQuery : IRequest<ResponseList<StateModel>>
    {
        public int CountryId { get; set; }
    }
}
