﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UserModel = SpiTech.UserStoreManagement.Domain.Models.UserModel;

namespace SpiTech.UserStoreManagement.Application.Queries.GetUserById
{
    public class GetUserByIdHandler : IRequestHandler<GetUserByIdQuery, UserModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetUserByIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IIdentityServiceClient identityapiclient;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetUserByIdHandler(IUnitOfWork context,
                                   ILogger<GetUserByIdHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper,
                                   IIdentityServiceClient identityclient, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            identityapiclient = identityclient;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<UserModel> Handle(GetUserByIdQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            // this.userAuthenticationProvider.ValidateUserAccess(query.UserId);
            UserModel usermodel = null;
            var userFromDb = await _context.Users.Get(query.UserId);

            if (userFromDb != null)
            {
                usermodel = _mapper.Map<UserModel>(userFromDb);
                if (usermodel != null)
                {
                    Service.Clients.Identity.UserModelResponseModel userIdentity = await identityapiclient.GetUserByIdAsync(query.UserId);

                    if (userIdentity != null)
                    {
                        usermodel.UserName = userIdentity?.Data?.UserName;
                        usermodel.Roles = _mapper.Map<IEnumerable<SpiTech.UserStoreManagement.Domain.Models.RoleModel>>(userIdentity?.Data?.Roles);
                    }

                    usermodel.Addresses = _context.Addresses.Get(query.UserId, EntityCategoryType.User);
                    usermodel.Emails = _mapper.Map<List<EmailModel>>(_context.Emails.Get(query.UserId, EntityCategoryType.User));
                    usermodel.Phones = _mapper.Map<List<PhoneModel>>(_context.Phones.Get(query.UserId, EntityCategoryType.User));
                    usermodel.PhotoUrl = userIdentity?.Data?.UserProfile?.PhotoUrl;
                }
            }

            _logger.TraceExitMethod(nameof(Handle), usermodel);
            return usermodel;
        }
    }
}
