﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetUserById
{
    public class GetUserByIdQuery : IRequest<UserModel>
    {
        public int UserId { get; set; }
    }
}
