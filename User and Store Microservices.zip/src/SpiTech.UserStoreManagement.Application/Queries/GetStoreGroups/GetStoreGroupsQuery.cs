﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreGroups
{
    public class GetStoreGroupsQuery : IRequest<ResponseList<StoreGroupModel>>
    {
        public int? StotreGroupId { get; set; }
    }
}
