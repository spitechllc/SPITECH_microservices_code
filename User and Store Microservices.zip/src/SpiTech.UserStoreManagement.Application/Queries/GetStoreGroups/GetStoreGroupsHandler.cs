﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Http;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreGroups
{
    public class GetStoreGroupsHandler : IRequestHandler<GetStoreGroupsQuery, ResponseList<StoreGroupModel>>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetStoreGroupsHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        public GetStoreGroupsHandler(IUnitOfWork context,
                                 ILogger<GetStoreGroupsHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<ResponseList<StoreGroupModel>> Handle(GetStoreGroupsQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<StoreGroupModel> result;
            result = await _context.StoreGroups.GetStoreGroup(request.StotreGroupId);
            if (result != null)
            {
                foreach (var item in result)
                {
                    item.Stores = await _context.StoreGroupStores.GetByStoreGroupId(item.StoreGroupId);
                    item.Users = _mapper.Map<IEnumerable<StoreGroupUsersModel>>(await _context.StoreGroupUsers.GetByStoreGroupId(item.StoreGroupId));
                }
            }
            _logger.TraceExitMethod(nameof(Handle), result);

            return new ResponseList<StoreGroupModel>() { Data = result };
        }
    }
}