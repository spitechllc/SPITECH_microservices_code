﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Service.Clients.Mppa;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Service.Clients.Transactions;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;
using static Slapper.AutoMapper;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreWithPaging
{
    public class GetStoreWithPagingHandler : IRequestHandler<GetStoreWithPagingQuery, PaginatedList<StoresSearchModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetStoreWithPagingHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IMppaServiceClient _mppaapiclient;
        private readonly ITransactionServiceClient _transactionapiclient;
        private readonly IIdentityServiceClient _identityServiceClient;

        public GetStoreWithPagingHandler(IUnitOfWork context,
                                 ILogger<GetStoreWithPagingHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper,
                                 IMppaServiceClient mppaapiclient,
                                 ITransactionServiceClient transactionapiclient,
                                 IIdentityServiceClient identityServiceClient
                                  )
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _mppaapiclient = mppaapiclient;
            _transactionapiclient = transactionapiclient;
            _identityServiceClient = identityServiceClient;
        }

        public async Task<PaginatedList<StoresSearchModel>> Handle(GetStoreWithPagingQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            int totalRecord = 0;
            List<Domain.Entities.Email> emails = new();
            List<Domain.Entities.Phone> phones = new();
            List<AddressModel> addresses = new();
            List<StoresSearchModel> storeList = new();
            List<SiteModel> siteStauses = new();
            ICollection<TransactionModel> lastTransactionDetails = new List<TransactionModel>();
            List<StoreTenantViewModel> storeTenantMasters = new();
            GetLastTransactionByFilterQuery query = new GetLastTransactionByFilterQuery();
            _logger.Warn($"Started system status");
            if (request.IsOnline.HasValue)
            {
                _logger.Warn($"Started system status "+request.IsOnline.HasValue);
                List<string> siteIds = new List<string>();

                siteStauses = await _mppaapiclient.SiteStatusesAsync(request.HeartBeatInterval, request.IsOnline, cancellationToken);
                _logger.Warn($"Stestautuses");
                if (siteStauses != null)
                {
                    siteIds = siteStauses.Select(t => t.SiteId).ToList();
                }

                if (siteIds != null && siteIds.Any())
                {
                    _logger.Warn($"Stestautuses1");
                    storeList = await _context.Stores.GetStoreWithPaging(request.StoreId, request.StoreName,
                                                                        request.SiteId, request.CompanyName,
                                                                        request.PageIndex, request.PageSize,
                                                                        siteIds.ToArray(), null, request.SortBy,
                                                                        request.SortOrder, request.StateName, request.City, request.Zipcode);
                }
            }
            else
            {
                _logger.Warn($"Stestautuses2");
                storeList = await _context.Stores.GetStoreWithPaging(request.StoreId, request.StoreName, request.SiteId,
                                                                      request.CompanyName, request.PageIndex, request.PageSize,
                                                                      null, null, request.SortBy, request.SortOrder, request.StateName, request.City, request.Zipcode);
            }
            try
            {
                if (storeList != null && storeList.Any())
                {
_logger.Warn($"Stestautuses4");

                    emails = _context.Emails.GetEmailList(storeList.Select(t => t.StoreId.ToString()).Distinct().ToArray(), EntityCategoryType.Store);
                    phones = _context.Phones.GetPhoneList(storeList.Select(t => t.StoreId.ToString()).Distinct().ToArray(), EntityCategoryType.Store);
                    _logger.Warn($"Stestautuses42");
                    addresses = await _context.Addresses.GetPrimaryAddressStoreByIds(storeList.Select(t => t.StoreId.ToString()).Distinct().ToArray(), EntityCategoryType.Store);
                    _logger.Warn($"Stestautuses43");
                    totalRecord = storeList.Select(x => x.TotalRecord).FirstOrDefault();
                    //Get Last Transaction
                    List<int> userIds = new List<int>();
                    query.StoreIds = storeList.Select(t => t.StoreId).Distinct().ToArray();
                    query.UserIds = userIds.Distinct().ToArray();
                    _logger.Warn($"Stestautuses41");
                    lastTransactionDetails = (await _transactionapiclient.GetLastTransactionByFilterAsync(query, cancellationToken))?.Data ?? new List<TransactionModel>();

_logger.Warn($"Stestautuses44");

                    if (!request.IsOnline.HasValue)
                    {_logger.Warn($"request.IsOnline.HasValue");
                        siteStauses = await _mppaapiclient.StatusesAsync(request.HeartBeatInterval, storeList.Select(t => t.SiteId).ToArray(), cancellationToken);

                        foreach (StoresSearchModel store in storeList)
                        {
                            List<TenantMasterList> tenantMasterdata = new List<TenantMasterList>();
                            var tenantdata = await _context.Stores.GetStoreTenantMasterByStoreId(store.StoreId);
                            
                            //foreach (var stores in tenantdata)
                            //{
                            //    var res = await _identityServiceClient.GetTenantMasterListAsync();
                            //    var tenants = res.Where(x => x.Id == stores.TenantId).ToList();
                            //    foreach (var obj in tenants)
                            //    {
                            //        TenantMasterList tenantMasterList = new TenantMasterList();
                            //        tenantMasterList.TenantId = obj.Id;
                            //        tenantMasterList.TenantName = obj.TenantName;
                            //        tenantMasterdata.Add(tenantMasterList);
                            //    }
                            //}
                            store.TenantMasterLists = tenantMasterdata;
                            store.Emails = _mapper.Map<List<EmailModel>>(emails.Where(t => t.StoreId == store.StoreId));
                            store.Phones = _mapper.Map<List<PhoneModel>>(phones.Where(t => t.StoreId == store.StoreId));
                            store.Addresses = addresses.Where(t => t.StoreId == store.StoreId);

                            var siteStatus = store.SiteId == null ? null : (siteStauses?.FirstOrDefault(t => t.SiteId == store.SiteId));
                            store.Status = siteStatus != null && siteStatus.IsOnline;

                            if (siteStatus?.CurrentHeartBeatTime != null && (siteStatus?.CurrentHeartBeatTime.HasValue ?? false))
                            {
                                store.CurrentHeartBeatTime = siteStatus?.CurrentHeartBeatTime.Value.UtcDateTime;
                            }

                            if (siteStatus?.LastHeartBeatTime != null && (siteStatus?.LastHeartBeatTime.HasValue ?? false))
                            {
                                store.LastHeartBeatTime = siteStatus?.LastHeartBeatTime.Value.UtcDateTime;
                            }
                            if (lastTransactionDetails != null && lastTransactionDetails.Count > 0)
                            {
                                store.LastTransactionDate = lastTransactionDetails?.Where(t => t.StoreId == store.StoreId).FirstOrDefault()?.TransactionDate.DateTime;
                            }

                        }
                    }
                    else
                    {
                        _logger.Warn($"else request isonline");
                        foreach (StoresSearchModel store in storeList)
                        {
                            List<TenantMasterList> tenantMasterdata = new List<TenantMasterList>();
                            var tenantdata = await _context.Stores.GetStoreTenantMasterByStoreId(store.StoreId);
                            /*foreach (var stores in tenantdata)
                            {
                                var res = await _identityServiceClient.GetTenantMasterListAsync();
                                var tenants = res.Where(x => x.Id == stores.TenantId).ToList();
                                foreach (var obj in tenants)
                                {
                                    TenantMasterList tenantMasterList = new TenantMasterList();
                                    tenantMasterList.TenantId = obj.Id;
                                    tenantMasterList.TenantName = obj.TenantName;
                                    tenantMasterdata.Add(tenantMasterList);
                                }
                            }*/
                            store.TenantMasterLists = tenantMasterdata;
                            store.Emails = _mapper.Map<List<EmailModel>>(emails.Where(t => t.StoreId == store.StoreId));
                            store.Phones = _mapper.Map<List<PhoneModel>>(phones.Where(t => t.StoreId == store.StoreId));
                            store.Addresses = addresses.Where(t => t.StoreId == store.StoreId);

                            var siteStatus = store.SiteId == null ? null : (siteStauses?.FirstOrDefault(t => t.SiteId == store.SiteId));
                            store.Status = siteStatus != null && siteStatus.IsOnline;

                            if (siteStatus?.CurrentHeartBeatTime != null && (siteStatus?.CurrentHeartBeatTime.HasValue ?? false))
                            {
                                store.CurrentHeartBeatTime = siteStatus?.CurrentHeartBeatTime.Value.UtcDateTime;
                            }

                            if (siteStatus?.LastHeartBeatTime != null && (siteStatus?.LastHeartBeatTime.HasValue ?? false))
                            {
                                store.LastHeartBeatTime = siteStatus?.LastHeartBeatTime.Value.UtcDateTime;
                            }

                            //if (lastTransactionDetails != null && lastTransactionDetails.Count > 0)
                            //{
                            //    store.LastTransactionDate = lastTransactionDetails.Where(t => t.StoreId == store.StoreId).FirstOrDefault().TransactionDate.UtcDateTime;
                            //}
                        }
                    }
                }

                var converted = storeList.Select(t => t.StoreId).Distinct().ToArray();
                if (request.AppName != null && request.AppName != "" && request.TenantId != null)
                {
                    _logger.Warn($"alert 1");
                    List<StoresSearchModel> storeLists = new List<StoresSearchModel>();
                    List<StoreTenantMappingUpdateModel> storeTenantMasterslist = new List<StoreTenantMappingUpdateModel>();
                    for (int i = 0; i < request.TenantId.Length; i++)
                    {
                        int id = request.TenantId[i];
                        var storesId = await _context.Stores.GetStoreIdsByTenantId(id);
                        foreach (var item in storesId)
                        {
                            request.StoreId = item.StoreId;
                            _logger.Warn($"alert 2");
                            storeList = await _context.Stores.GetStoreWithPaging(request.StoreId, request.StoreName, request.SiteId,
                                                                   request.CompanyName, request.PageIndex, request.PageSize,
                                                                   null, null, request.SortBy, request.SortOrder, request.StateName, request.City, request.Zipcode);

_logger.Warn($"alert 4");
                            StoreTenantViewModel tenantMasterModel = new StoreTenantViewModel();
                            List<TenantMasterList> tenantMasterdata = new List<TenantMasterList>();
                            var tenantdata = await _context.Stores.GetStoreIdAndIdByTenantId(item.StoreId, id);
                            //foreach (var stores in tenantdata)
                            //{
                            //    var res = await _identityServiceClient.GetTenantMasterListAsync();
                            //    var tenants = res.Where(x => x.Id == stores.TenantId).ToList();
                            //    foreach (var obj in tenants)
                            //    {
                            //        TenantMasterList tenantMasterList = new TenantMasterList();
                            //        tenantMasterList.TenantId = obj.Id;
                            //        tenantMasterList.TenantName = obj.TenantName;
                            //        tenantMasterdata.Add(tenantMasterList);
                            //    }
                            //}
                            foreach (var stores in storeList)
                            {
                                stores.TenantMasterLists = tenantMasterdata;
                                storeLists.Add(stores);
                            }
                        }
                    }
                    storeList = storeLists;
                    if (storeList != null && storeList.Any())
                    {
_logger.Warn($"In System status 5");
                        emails = _context.Emails.GetEmailList(storeList.Select(t => t.StoreId.ToString()).Distinct().ToArray(), EntityCategoryType.Store);
                        phones = _context.Phones.GetPhoneList(storeList.Select(t => t.StoreId.ToString()).Distinct().ToArray(), EntityCategoryType.Store);
                        addresses = await _context.Addresses.GetPrimaryAddressStoreByIds(storeList.Select(t => t.StoreId.ToString()).Distinct().ToArray(), EntityCategoryType.Store);
                        totalRecord = storeList.Select(x => x.TotalRecord).FirstOrDefault();
                        //Get Last Transaction
                        List<int> userIds = new List<int>();
                        query.StoreIds = storeList.Select(t => t.StoreId).Distinct().ToArray();
                        query.UserIds = userIds.Distinct().ToArray();
                        lastTransactionDetails = (await _transactionapiclient.GetLastTransactionByFilterAsync(query, cancellationToken))?.Data ?? new List<TransactionModel>();

_logger.Warn($"In System status 6");

                        if (!request.IsOnline.HasValue)
                        {
                            siteStauses = await _mppaapiclient.StatusesAsync(request.HeartBeatInterval, storeList.Select(t => t.SiteId).ToArray(), cancellationToken);
_logger.Warn($"In System status 7");
                            foreach (StoresSearchModel store in storeList)
                            {
                                store.Emails = _mapper.Map<List<EmailModel>>(emails.Where(t => t.StoreId == store.StoreId));
                                store.Phones = _mapper.Map<List<PhoneModel>>(phones.Where(t => t.StoreId == store.StoreId));
                                store.Addresses = addresses.Where(t => t.StoreId == store.StoreId);

                                var siteStatus = store.SiteId == null ? null : (siteStauses?.FirstOrDefault(t => t.SiteId == store.SiteId));
                                store.Status = siteStatus != null && siteStatus.IsOnline;

                                if (siteStatus?.CurrentHeartBeatTime != null && (siteStatus?.CurrentHeartBeatTime.HasValue ?? false))
                                {
                                    store.CurrentHeartBeatTime = siteStatus?.CurrentHeartBeatTime.Value.UtcDateTime;
                                }

                                if (siteStatus?.LastHeartBeatTime != null && (siteStatus?.LastHeartBeatTime.HasValue ?? false))
                                {
                                    store.LastHeartBeatTime = siteStatus?.LastHeartBeatTime.Value.UtcDateTime;
                                }
                                if (lastTransactionDetails != null && lastTransactionDetails.Count > 0)
                                {
                                    store.LastTransactionDate = lastTransactionDetails?.Where(t => t.StoreId == store.StoreId).FirstOrDefault()?.TransactionDate.DateTime;
                                }

                            }
                        }
                        else
                        {_logger.Warn($"In System status 8");
                            foreach (StoresSearchModel store in storeList)
                            {
                                store.Emails = _mapper.Map<List<EmailModel>>(emails.Where(t => t.StoreId == store.StoreId));
                                store.Phones = _mapper.Map<List<PhoneModel>>(phones.Where(t => t.StoreId == store.StoreId));
                                store.Addresses = addresses.Where(t => t.StoreId == store.StoreId);

                                var siteStatus = store.SiteId == null ? null : (siteStauses?.FirstOrDefault(t => t.SiteId == store.SiteId));
                                store.Status = siteStatus != null && siteStatus.IsOnline;

                                if (siteStatus?.CurrentHeartBeatTime != null && (siteStatus?.CurrentHeartBeatTime.HasValue ?? false))
                                {
                                    store.CurrentHeartBeatTime = siteStatus?.CurrentHeartBeatTime.Value.UtcDateTime;
                                }

                                if (siteStatus?.LastHeartBeatTime != null && (siteStatus?.LastHeartBeatTime.HasValue ?? false))
                                {
                                    store.LastHeartBeatTime = siteStatus?.LastHeartBeatTime.Value.UtcDateTime;
                                }

                                //if (lastTransactionDetails != null && lastTransactionDetails.Count > 0)
                                //{
                                //    store.LastTransactionDate = lastTransactionDetails.Where(t => t.StoreId == store.StoreId).FirstOrDefault().TransactionDate.UtcDateTime;
                                //}
                            }
                        }
                    }
                }
                else if (request.StoreId == 0 && string.IsNullOrWhiteSpace(request.StoreName) && string.IsNullOrWhiteSpace(request.SiteId) && string.IsNullOrWhiteSpace(request.CompanyName) && string.IsNullOrWhiteSpace(request.StateName) && string.IsNullOrWhiteSpace(request.City) && string.IsNullOrWhiteSpace(request.Zipcode) && request.IsOnline == null)
                {_logger.Warn($"In System status 9");
                    var storesId = await _context.Stores.GetStoreIdsByTenantId(1);
                    List<StoresSearchModel> storeLists = new List<StoresSearchModel>();
                    foreach (var item in storesId)
                    {
                        request.StoreId = item.StoreId;
                        storeList = await _context.Stores.GetStoreWithPaging(request.StoreId, request.StoreName, request.SiteId,
                                                               request.CompanyName, request.PageIndex, request.PageSize,
                                                               null, null, request.SortBy, request.SortOrder, request.StateName, request.City, request.Zipcode);

                        StoreTenantViewModel tenantMasterModel = new StoreTenantViewModel();
                        var tenantdata = await _context.Stores.GetStoreIdAndIdByTenantId(item.StoreId, (int)TenantEnum.SpiTech);
                        List<TenantMasterList> tenantMasterdata = new List<TenantMasterList>();
                        foreach (var stores in tenantdata)
                        {
                            var res = await _identityServiceClient.GetTenantMasterListAsync();
                            var tenants = res.Where(x => x.Id == stores.TenantId).ToList();
                            foreach (var obj in tenants)
                            {
                                TenantMasterList tenantMasterList = new TenantMasterList();
                                tenantMasterList.TenantId = obj.Id;
                                tenantMasterList.TenantName = obj.TenantName;
                                tenantMasterdata.Add(tenantMasterList);
                            }
                        }
                        foreach (var stores in storeList)
                        {
                            stores.TenantMasterLists = tenantMasterdata;
                            storeLists.Add(stores);
                        }
                    }
                    storeList = storeLists;
                    if (storeList != null && storeList.Any())
                    {
_logger.Warn($"In System status 11");
                        emails = _context.Emails.GetEmailList(storeList.Select(t => t.StoreId.ToString()).Distinct().ToArray(), EntityCategoryType.Store);
                        phones = _context.Phones.GetPhoneList(storeList.Select(t => t.StoreId.ToString()).Distinct().ToArray(), EntityCategoryType.Store);
                        addresses = await _context.Addresses.GetPrimaryAddressStoreByIds(storeList.Select(t => t.StoreId.ToString()).Distinct().ToArray(), EntityCategoryType.Store);
                        totalRecord = storeList.Select(x => x.TotalRecord).FirstOrDefault();
                        //Get Last Transaction
                        List<int> userIds = new List<int>();
                        query.StoreIds = storeList.Select(t => t.StoreId).Distinct().ToArray();
                        query.UserIds = userIds.Distinct().ToArray();
                        lastTransactionDetails = (await _transactionapiclient.GetLastTransactionByFilterAsync(query, cancellationToken))?.Data ?? new List<TransactionModel>();

_logger.Warn($"In System status 12");

                        if (!request.IsOnline.HasValue)
                        {
                            siteStauses = await _mppaapiclient.StatusesAsync(request.HeartBeatInterval, storeList.Select(t => t.SiteId).ToArray(), cancellationToken);

                            foreach (StoresSearchModel store in storeList)
                            {
                                store.Emails = _mapper.Map<List<EmailModel>>(emails.Where(t => t.StoreId == store.StoreId));
                                store.Phones = _mapper.Map<List<PhoneModel>>(phones.Where(t => t.StoreId == store.StoreId));
                                store.Addresses = addresses.Where(t => t.StoreId == store.StoreId);

                                var siteStatus = store.SiteId == null ? null : (siteStauses?.FirstOrDefault(t => t.SiteId == store.SiteId));
                                store.Status = siteStatus != null && siteStatus.IsOnline;

                                if (siteStatus?.CurrentHeartBeatTime != null && (siteStatus?.CurrentHeartBeatTime.HasValue ?? false))
                                {
                                    store.CurrentHeartBeatTime = siteStatus?.CurrentHeartBeatTime.Value.UtcDateTime;
                                }

                                if (siteStatus?.LastHeartBeatTime != null && (siteStatus?.LastHeartBeatTime.HasValue ?? false))
                                {
                                    store.LastHeartBeatTime = siteStatus?.LastHeartBeatTime.Value.UtcDateTime;
                                }
                                if (lastTransactionDetails != null && lastTransactionDetails.Count > 0)
                                {
                                    store.LastTransactionDate = lastTransactionDetails?.Where(t => t.StoreId == store.StoreId).FirstOrDefault()?.TransactionDate.DateTime;
                                }

                            }
                        }
                        else
                        {_logger.Warn($"In System status 13");
                            foreach (StoresSearchModel store in storeList)
                            {
                                store.Emails = _mapper.Map<List<EmailModel>>(emails.Where(t => t.StoreId == store.StoreId));
                                store.Phones = _mapper.Map<List<PhoneModel>>(phones.Where(t => t.StoreId == store.StoreId));
                                store.Addresses = addresses.Where(t => t.StoreId == store.StoreId);

                                var siteStatus = store.SiteId == null ? null : (siteStauses?.FirstOrDefault(t => t.SiteId == store.SiteId));
                                store.Status = siteStatus != null && siteStatus.IsOnline;

                                if (siteStatus?.CurrentHeartBeatTime != null && (siteStatus?.CurrentHeartBeatTime.HasValue ?? false))
                                {
                                    store.CurrentHeartBeatTime = siteStatus?.CurrentHeartBeatTime.Value.UtcDateTime;
                                }

                                if (siteStatus?.LastHeartBeatTime != null && (siteStatus?.LastHeartBeatTime.HasValue ?? false))
                                {
                                    store.LastHeartBeatTime = siteStatus?.LastHeartBeatTime.Value.UtcDateTime;
                                }

                                //if (lastTransactionDetails != null && lastTransactionDetails.Count > 0)
                                //{
                                //    store.LastTransactionDate = lastTransactionDetails.Where(t => t.StoreId == store.StoreId).FirstOrDefault().TransactionDate.UtcDateTime;
                                //}
                            }
                        }
                    }
                }
                totalRecord = storeList.Count;
            }
            catch (Exception ex)
            {
                throw;
            }

            if (request.SortOrder != null && request.SortBy != null)
            {
                if (request.SortBy == StoreSortBy.LastHeartBeatTime || request.SortBy == StoreSortBy.LastTransactionDate || request.SortBy == StoreSortBy.CompanyName
                    || request.SortBy == StoreSortBy.StoreName
                    || request.SortBy == StoreSortBy.SiteId
                    || request.SortBy == StoreSortBy.CreatedOn)
                {
                    if (request.SortOrder == EventBus.DomainEvents.Enums.SortOrderEnum.Asc)
                    {
                        switch (request.SortBy.Value)
                        {
                            case StoreSortBy.LastHeartBeatTime:
                                storeList = storeList.OrderBy(t => t.LastHeartBeatTime).ToList();
                                break;
                            case StoreSortBy.LastTransactionDate:
                                storeList = storeList.OrderBy(t => t.LastTransactionDate).ToList();
                                break;
                            case StoreSortBy.CompanyName:
                                storeList = storeList.OrderBy(t => t.Company).ToList();
                                break;
                            case StoreSortBy.StoreName:
                                storeList = storeList.OrderBy(t => t.StoreName).ToList();
                                break;
                            case StoreSortBy.SiteId:
                                storeList = storeList.OrderBy(t => t.SiteId).ToList();
                                break;
                            case StoreSortBy.CreatedOn:
                                storeList = storeList.OrderBy(t => t.CreatedOn).ToList();
                                break;
                        }
                    }
                    else
                    {
                        switch (request.SortBy.Value)
                        {
                            case StoreSortBy.LastHeartBeatTime:
                                storeList = storeList.OrderByDescending(t => t.LastHeartBeatTime).ToList();
                                break;
                            case StoreSortBy.LastTransactionDate:
                                storeList = storeList.OrderByDescending(t => t.LastTransactionDate).ToList();
                                break;
                            case StoreSortBy.CompanyName:
                                storeList = storeList.OrderByDescending(t => t.Company).ToList();
                                break;
                            case StoreSortBy.StoreName:
                                storeList = storeList.OrderByDescending(t => t.StoreName).ToList();
                                break;
                            case StoreSortBy.SiteId:
                                storeList = storeList.OrderByDescending(t => t.SiteId).ToList();
                                break;
                            case StoreSortBy.CreatedOn:
                                storeList = storeList.OrderByDescending(t => t.CreatedOn).ToList();
                                break;
                        }
                    }
                }
            }
            var result = new PaginatedList<StoresSearchModel>
            {
                Data = storeList,
                PageIndex = request.PageIndex ?? 0,
                PageSize = request.PageSize ?? 0,
                TotalCount = totalRecord,
            };

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}