﻿using MediatR;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreWithPaging
{
    public class GetStoreWithPagingQuery : IRequest<PaginatedList<StoresSearchModel>>
    {
        public int HeartBeatInterval { get; set; }
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public string SiteId { get; set; }
        public string CompanyName { get; set; }
        public DateTime? CreatedOn { get; set; }
        public bool? IsOnline { get; set; }
        public DateTime? LastHeartbeat { get; set; }
        public string StateName { get; set; }
        public string City { get; set; }
        public string Zipcode { get; set; }
        public int? PageIndex { get; set; }
        public int? PageSize { get; set; }
        public StoreSortBy? SortBy { get; set; }
        public SortOrderEnum? SortOrder { get; set; }
        public string AppName { get; set; }
        public int[] TenantId { get; set; }
    }
}