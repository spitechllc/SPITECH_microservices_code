﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetWeekDays
{
    public class GetWeekDaysHandler : IRequestHandler<GetWeekDaysQuery, ResponseList<WeekDaysModel>>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetWeekDaysHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        public GetWeekDaysHandler(IUnitOfWork context,
                                 ILogger<GetWeekDaysHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<ResponseList<WeekDaysModel>> Handle(GetWeekDaysQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<WeekDaysModel> result = _mapper.Map<IEnumerable<WeekDaysModel>>(await _context.WeekDays.GetAll());
            _logger.TraceExitMethod(nameof(Handle), result);
            return new ResponseList<WeekDaysModel>() { Data = result };
        }
    }
}
