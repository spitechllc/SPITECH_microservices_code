﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using UserModel = SpiTech.UserStoreManagement.Domain.Models.UserModel;

namespace SpiTech.UserStoreManagement.Application.Queries.GetUserWithPaging
{
    public class GetUserWithPagingHandler : IRequestHandler<GetUserWithPagingQuery, PaginatedList<UserModel>>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetUserWithPagingHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IIdentityServiceClient _identityapiclient;

        public GetUserWithPagingHandler(IUnitOfWork context,
                                 ILogger<GetUserWithPagingHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper,
                                 IIdentityServiceClient identityapiclient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _identityapiclient = identityapiclient;
        }
        public async Task<PaginatedList<UserModel>> Handle(GetUserWithPagingQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            int totalRecord = 0;
            List<int> ids = null;
            List<UserModel> userlist = new();
            List<Domain.Entities.Email> emails = new();
            List<Domain.Entities.Phone> phones = new();
            List<AddressModel> addresses = new();
            IEnumerable<Service.Clients.Identity.UserModel> users = null;

            userlist = await _context.Users.GetUserWithPaging(request.FirstName, request.LastName, request.RoleId, request.StoreId, request.Email, request.Phone, request.StoreName, request.PageIndex, request.PageSize,
           request.SortBy, request.SortOrder,null,null,null);

            if (userlist != null && userlist.Count() > 0)
            {
                users = await _identityapiclient.GetUserListAsync(userlist.Select(t => t.UserId).ToArray());
                emails = _context.Emails.GetEmailList(userlist.Select(t => t.UserId.ToString()).Distinct().ToArray(), EntityCategoryType.User);
                phones = _context.Phones.GetPhoneList(userlist.Select(t => t.UserId.ToString()).Distinct().ToArray(), EntityCategoryType.User);
                addresses = await _context.Addresses.GetPrimaryAddressStoreByIds(userlist.Select(t => t.UserId.ToString()).Distinct().ToArray(), EntityCategoryType.User);
            }


            if (userlist != null && userlist.Count() > 0)
            {
                totalRecord = userlist.Select(x => x.TotalRecord).FirstOrDefault();

                foreach (UserModel user in userlist)
                {
                    user.Emails = _mapper.Map<List<EmailModel>>(emails.Where(t => t.UserId == user.UserId));
                    user.Phones = _mapper.Map<List<PhoneModel>>(phones.Where(t => t.UserId == user.UserId));
                    user.Addresses = addresses.Where(t => t.UserId == user.UserId);
                    var res = users.FirstOrDefault(t => t.UserId == user.UserId);
                    if (res != null)
                    {
                        user.Roles = _mapper.Map<IEnumerable<Domain.Models.RoleModel>>(users.FirstOrDefault(t => t.UserId == user.UserId).Roles);
                    }
                    else
                    {
                        user.Roles = null;
                    }
                    System.DateTimeOffset? lastTimeAccess = users?.Where(t => t.UserId == user.UserId).FirstOrDefault()?.LastTimeAccess;
                    if (lastTimeAccess.HasValue)
                    {
                        user.LastAccess =Convert.ToDateTime(lastTimeAccess);
                    }
                }
            }
            //if (request.SortOrder != null && request.SortBy != null)
            //{
            //    if (request.SortBy == StoreUserSortBy.Role)
            //    {
            //        if (request.SortOrder == EventBus.DomainEvents.Enums.SortOrderEnum.Asc)
            //        {
            //            userlist = userlist.OrderBy(t => t.Roles?.OrderByDescending(d => d.RoleId).FirstOrDefault().RoleId).ToList();

            //        }
            //        else
            //        {
            //            userlist = userlist.OrderByDescending(t => t.Roles.OrderByDescending(d => d.RoleId).FirstOrDefault().RoleId).ToList();
            //        }
            //    }
            //}

            _logger.TraceExitMethod(nameof(Handle), userlist);

            return new PaginatedList<UserModel>
            {
                Data = userlist,
                PageIndex = request.PageIndex ?? 0,
                PageSize = request.PageSize ?? 0,
                TotalCount = totalRecord,
            };
        }
    }
}
