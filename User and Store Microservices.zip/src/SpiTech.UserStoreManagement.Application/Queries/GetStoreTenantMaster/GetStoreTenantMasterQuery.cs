﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreTenantMaster
{
    public class GetStoreTenantMasterQuery : IRequest<ResponseList<StoreTenantMasterModel>>
    {
    }
}
