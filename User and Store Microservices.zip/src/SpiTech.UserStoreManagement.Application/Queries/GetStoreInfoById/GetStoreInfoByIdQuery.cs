﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreInfoById
{
    public class GetStoreInfoByIdQuery : IRequest<ResponseModel<StoreInfoModel>>
    {
        public int? StoreId { get; set; }
        public string SiteId { get; set; }
    }
}
