﻿using FluentValidation;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreInfoById
{
    public class GetStoreInfoByIdQueryValidator : AbstractValidator<GetStoreInfoByIdQuery>
    {
        public GetStoreInfoByIdQueryValidator()
        {
            When(t => string.IsNullOrWhiteSpace(t.SiteId), () =>
            {
                RuleFor(s => s.StoreId).NotNull().GreaterThan(0);
            });

            When(t => !t.StoreId.HasValue, () =>
            {
                RuleFor(s => s.SiteId).NotNull().NotEmpty();
            });
        }
    }
}
