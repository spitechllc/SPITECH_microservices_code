﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetResellers
{
    public class GetResellersHandler : IRequestHandler<GetResellersQuery, PaginatedList<ResellerModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetResellersHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetResellersHandler(IUnitOfWork context,
                                    ILogger<GetResellersHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<PaginatedList<ResellerModel>> Handle(GetResellersQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            int totalRecord = 0;

            List<ResellerModel> result = await _context.Resellers.GetResellerByFilters(query.CompanyName,query.Name, query.Mobile, query.Email, query.Company, query.PageIndex, query.PageSize, query.SortBy, query.SortOrder);

            if (result != null)
            {
                var ids = result.Select(s => s.ResellerId.ToString()).Distinct().ToArray();
                var emails = _context.Emails.GetEmailList(ids, EntityCategoryType.Reseller);
                var phones = _context.Phones.GetPhoneList(ids, EntityCategoryType.Reseller);
                var addresses = await _context.Addresses.GetPrimaryAddressStoreByIds(ids, EntityCategoryType.Reseller);

                foreach (ResellerModel reseller in result)
                {
                    totalRecord = reseller.TotalRecord;
                    reseller.Addresses = addresses.Where(t => t.ResellerId == reseller.ResellerId).ToList();
                    reseller.Emails = _mapper.Map<List<EmailModel>>(emails.Where(t => t.ResellerId == reseller.ResellerId).ToList());
                    reseller.Phones = _mapper.Map<List<PhoneModel>>(phones.Where(t => t.ResellerId == reseller.ResellerId).ToList());
                }
            }
            _logger.TraceExitMethod(nameof(Handle), result);

            return new PaginatedList<ResellerModel>
            {
                Data = result,
                PageIndex = query.PageIndex ?? 0,
                PageSize = query.PageSize ?? 0,
                TotalCount = totalRecord,
            };

        }
    }
}
