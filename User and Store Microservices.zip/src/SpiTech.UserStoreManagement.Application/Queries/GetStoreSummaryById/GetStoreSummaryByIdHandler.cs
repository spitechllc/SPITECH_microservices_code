﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Http.Features;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Service.Clients.Mppa;
using SpiTech.Service.Clients.Payments;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreSummaryById
{
    public class GetStoreSummaryByIdHandler : IRequestHandler<GetStoreSummaryByIdQuery, PaginatedList<StoreModelForSummaryWithTenant>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetStoreSummaryByIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IMppaServiceClient _mppaapiclient;
        private readonly IPaymentServiceClient _paymentapiclient;


        public GetStoreSummaryByIdHandler(IUnitOfWork context,
                                    ILogger<GetStoreSummaryByIdHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper,
                                    IMppaServiceClient mppaapiclient, IPaymentServiceClient paymentapiclient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _mppaapiclient = mppaapiclient;
            _paymentapiclient = paymentapiclient;

        }

        public async Task<PaginatedList<StoreModelForSummaryWithTenant>> Handle(GetStoreSummaryByIdQuery query, CancellationToken cancellationToken)
        {

            _logger.TraceEnterMethod(nameof(Handle), query);
            int totalRecord = 0;
            List<StoreModelForSummaryWithTenant> resultlists = new List<StoreModelForSummaryWithTenant>();
            IEnumerable<StoreModelForSummary> result = await _context.Stores.GetStoreSummaryByFilter(query.filter, query.PageIndex, query.PageSize, query.sortable);

            var ids = result.Select(s => s.StoreId.ToString()).Distinct().ToArray();

            List<AddressModelSummary> addresses = _mapper.Map<List<AddressModelSummary>>(await _context.Addresses.GetPrimaryAddressStoreByIds(ids, EntityCategoryType.Store));

            string[] siteIds = result.Where(s => !string.IsNullOrWhiteSpace(s.SiteId)).Select(s => s.SiteId.Trim()).Distinct().ToArray();
            ICollection<SiteProductModel> siteProducts = new List<SiteProductModel>();

            if (siteIds != null && siteIds.Any())
            {
                siteProducts = (await _mppaapiclient.SiteProductAsync(siteIds))?.Data ?? new List<SiteProductModel>();
            }

            int[] storeIds = result.Select(s => s.StoreId).Distinct().ToArray();

            ICollection<StoreConfigModel> storeConfigs = new List<StoreConfigModel>();
            if (storeIds != null && storeIds.Any())
            {
                GetStoreConfigsQuery model = new GetStoreConfigsQuery();
                model.StoreIds = storeIds;
                storeConfigs = (await _paymentapiclient.AllStoreConfigsAsync(model))?.Data ?? new List<StoreConfigModel>();
            }

            foreach (StoreModelForSummary store in result)
            {
                totalRecord = store.TotalRecord;
                store.Addresses = addresses.Where(s => s.StoreId == store.StoreId);
                store.PumpProducts = string.IsNullOrWhiteSpace(store.SiteId) ? new List<SiteProductModel>() : siteProducts.Where(t => t.SiteId == store.SiteId.Trim()).ToList();
                store.IsAchEnabled = storeConfigs.Where(t => t.StoreId == store.StoreId).FirstOrDefault()?.IsAchEnabled ?? false;
            }
            if (query.filter.CountryId != 0 || query.filter.StateId != 0 || query.filter.StateId != 0 || query.filter.City != null || query.filter.ZipCode != null || query.filter.AmenitiesId != null)
            {
                List<StoreModelForSummaryWithTenant> storeLists = new List<StoreModelForSummaryWithTenant>();
                List<StoreModelForSummaryWithTenant> dataLists = new List<StoreModelForSummaryWithTenant>();
                foreach (var stores in result)
                {
                    StoreModelForSummaryWithTenant obj = new StoreModelForSummaryWithTenant();
                    obj.StoreId = stores.StoreId;
                    obj.StoreName = stores.StoreName;
                    obj.SiteId = stores.SiteId;
                    obj.MaxAuthorizeAmount = stores.MaxAuthorizeAmount;
                    obj.ConsentCashReward = stores.ConsentCashReward;
                    obj.DisableEod = stores.DisableEod;
                    obj.DisableBilling = stores.DisableBilling;
                    obj.Distance = stores.Distance;
                    obj.StoreCategoryId = stores.StoreCategoryId;
                    obj.IsAchEnabled = stores.IsAchEnabled;
                    obj.EnableACHLoyalty = stores.EnableACHLoyalty;
                    obj.EnableCardLoyalty = stores.EnableCardLoyalty;
                    obj.LoyaltyProgramId = stores.LoyaltyProgramId;
                    obj.Addresses = stores.Addresses;
                    obj.PumpProducts = stores.PumpProducts;
                    obj.TotalRecord = stores.TotalRecord;
                    storeLists.Add(obj);
                }
                foreach (var res in storeLists)
                {
                    List<int> number = new List<int>();
                    var storesId = await _context.Stores.GetStoreTenantMasterByStoreIds(res.StoreId);
                    foreach (var Items in storesId)
                    {
                        var data = storeLists.Where(x => x.StoreId == res.StoreId);
                        foreach (var item in data)
                        {
                            var tenantdata = await _context.Stores.GetStoreIdAndIdByTenantId(item.StoreId, Items.TenantId);
                            foreach (var tenant in tenantdata)
                            {
                                number.Add(tenant.TenantId);
                            }
                            StoreTenantViewModel tenantMasterModel = new StoreTenantViewModel();
                            item.TenantId = number.ToArray();
                            dataLists.Add(item);
                        }
                    }
                }
                resultlists = dataLists;
                totalRecord = resultlists.Count;
            }
            if (query.filter.TenantId != null)
            {
                List<StoreModelForSummaryWithTenant> storeLists = new List<StoreModelForSummaryWithTenant>();
                List<StoreModelForSummaryWithTenant> dataLists = new List<StoreModelForSummaryWithTenant>();
                foreach (var store in result)
                {
                    StoreModelForSummaryWithTenant obj = new StoreModelForSummaryWithTenant();
                    obj.StoreId = store.StoreId;
                    obj.StoreName = store.StoreName;
                    obj.SiteId = store.SiteId;
                    obj.MaxAuthorizeAmount = store.MaxAuthorizeAmount;
                    obj.ConsentCashReward = store.ConsentCashReward;
                    obj.DisableEod = store.DisableEod;
                    obj.DisableBilling = store.DisableBilling;
                    obj.Distance = store.Distance;
                    obj.StoreCategoryId = store.StoreCategoryId;
                    obj.IsAchEnabled = store.IsAchEnabled;
                    obj.EnableACHLoyalty = store.EnableACHLoyalty;
                    obj.EnableCardLoyalty = store.EnableCardLoyalty;
                    obj.LoyaltyProgramId = store.LoyaltyProgramId;
                    obj.Addresses = store.Addresses;
                    obj.PumpProducts = store.PumpProducts;
                    obj.TotalRecord = store.TotalRecord;
                    storeLists.Add(obj);
                }
                for (int i = 0; i < query.filter.TenantId.Length; i++)
                {
                    int TenantIds = query.filter.TenantId[i];
                    var storesId = await _context.Stores.GetStoreIdsByTenantId(TenantIds);
                    foreach (var item in storesId)
                    {
                        var data = storeLists.Where(x => x.StoreId == item.StoreId);
                        List<int> number = new List<int>();
                        foreach (var items in data)
                        {
                            var tenantdata = await _context.Stores.GetStoreIdAndIdByTenantId(items.StoreId, TenantIds);
                            foreach (var stores in tenantdata)
                            {
                                number.Add(stores.TenantId);
                            }
                            StoreTenantViewModel tenantMasterModel = new StoreTenantViewModel();
                            items.TenantId = number.ToArray();
                            dataLists.Add(items);
                        }

                    }
                    resultlists = dataLists;
                    totalRecord = resultlists.Count;
                }
            }

            else if (query.filter.TenantId == null && query.filter.CountryId == 0 && query.filter.StateId == 0 && query.filter.StateId == 0 && query.filter.City == null && query.filter.ZipCode == null && query.filter.AmenitiesId == null)
            {
                List<StoreModelForSummaryWithTenant> storeLists = new List<StoreModelForSummaryWithTenant>();
                List<StoreModelForSummaryWithTenant> dataLists = new List<StoreModelForSummaryWithTenant>();
                foreach (var store in result)
                {
                    StoreModelForSummaryWithTenant obj = new StoreModelForSummaryWithTenant();
                    obj.StoreId = store.StoreId;
                    obj.StoreName = store.StoreName;
                    obj.SiteId = store.SiteId;
                    obj.MaxAuthorizeAmount = store.MaxAuthorizeAmount;
                    obj.ConsentCashReward = store.ConsentCashReward;
                    obj.DisableEod = store.DisableEod;
                    obj.DisableBilling = store.DisableBilling;
                    obj.Distance = store.Distance;
                    obj.StoreCategoryId = store.StoreCategoryId;
                    obj.IsAchEnabled = store.IsAchEnabled;
                    obj.EnableACHLoyalty = store.EnableACHLoyalty;
                    obj.EnableCardLoyalty = store.EnableCardLoyalty;
                    obj.LoyaltyProgramId = store.LoyaltyProgramId;
                    obj.Addresses = store.Addresses;
                    obj.PumpProducts = store.PumpProducts;
                    obj.TotalRecord = store.TotalRecord;
                    storeLists.Add(obj);
                }
                var storesId = await _context.Stores.GetStoreIdsByTenantId(1);
                foreach (var item in storesId)
                {
                    var data = storeLists.Where(x => x.StoreId == item.StoreId);
                    List<int> number = new List<int>();
                    foreach (var items in data)
                    {
                        StoreTenantViewModel tenantMasterModel = new StoreTenantViewModel();
                        var tenantdata = await _context.Stores.GetStoreIdAndIdByTenantId(items.StoreId, 1);
                        foreach (var stores in tenantdata)
                        {
                            number.Add(stores.TenantId);
                        }
                        items.TenantId = number.ToArray();
                        dataLists.Add(items);
                    }
                }
                resultlists = dataLists;
                totalRecord = resultlists.Count;
            }

            _logger.TraceExitMethod(nameof(Handle), resultlists);
            int skiprow = 0;
            if (query.PageIndex.HasValue && query.PageSize.HasValue)
            {
                skiprow = (query.PageIndex.Value - 1) * query.PageSize.Value;
                result.Skip(skiprow).Take(query.PageSize ?? 1000);
            }
            return new PaginatedList<StoreModelForSummaryWithTenant>
            { Data = resultlists.ToList(), TotalCount = totalRecord, PageSize = query.PageSize ?? 0, };

        }
    }
}
