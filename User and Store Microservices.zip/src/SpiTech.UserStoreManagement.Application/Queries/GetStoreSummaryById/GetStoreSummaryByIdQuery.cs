﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.UserStoreManagement.Domain.FilterOptions;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreSummaryById
{
    public class GetStoreSummaryByIdQuery : IRequest<PaginatedList<StoreModelForSummaryWithTenant>>
    {
        public StoreFilter filter { get; set; }
        public int? PageSize { get; set; }
        public int? PageIndex { get; set; }
        public Sortable sortable { get; set; }
    }
}