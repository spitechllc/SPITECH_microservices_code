﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetRegion
{
    public class GetRegionQuery : IRequest<ResponseList<RegionModel>>
    {
        public int Id { get; set; }
    }
}
