﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetRegion
{
    public class GetRegionHandler : IRequestHandler<GetRegionQuery, ResponseList<RegionModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetRegionHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetRegionHandler(IUnitOfWork context,
                                   ILogger<GetRegionHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<ResponseList<RegionModel>> Handle(GetRegionQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            IEnumerable<RegionModel> list = _mapper.Map<IEnumerable<RegionModel>>(await _context.Regions.GetRegion());

            return await Task.FromResult(new ResponseList<RegionModel> { Data = list.ToList() });
        }

    }
}
