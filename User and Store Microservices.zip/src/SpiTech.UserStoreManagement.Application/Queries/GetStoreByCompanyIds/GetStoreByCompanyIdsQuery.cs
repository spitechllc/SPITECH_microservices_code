﻿using MediatR;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.UserStoreManagement.Domain.Enums;
using StoreSearchResult = SpiTech.UserStoreManagement.Domain.Models.StoreSearchResult;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreByCompanyIds
{
    public class GetStoreByCompanyIdsQuery : IRequest<PaginatedList<StoreSearchResult>>
    {
        public int[] CompanyIds { get; set; }
        public int? PageIndex { get; set; }
        public int? PageSize { get; set; }
        public StoreSortBy? SortBy { get; set; }
        public SortOrderEnum? SortOrder { get; set; }
    }
}
