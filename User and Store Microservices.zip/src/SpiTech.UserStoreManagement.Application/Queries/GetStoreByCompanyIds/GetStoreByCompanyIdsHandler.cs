﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Service.Clients.Mppa;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreByCompanyIds
{
    public class GetStoreByCompanyIdsHandler : IRequestHandler<GetStoreByCompanyIdsQuery, PaginatedList<StoreSearchResult>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetStoreByCompanyIdsHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        private readonly IMppaServiceClient _mppaapiclient;

        public GetStoreByCompanyIdsHandler(IUnitOfWork context,
                                   ILogger<GetStoreByCompanyIdsHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper,
                                   IMppaServiceClient mppaapiclient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _mppaapiclient = mppaapiclient;

        }

        public async Task<PaginatedList<StoreSearchResult>> Handle(GetStoreByCompanyIdsQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            int totalRecord = 0;
            List<StoreSearchResult> storeList = _mapper.Map<List<StoreSearchResult>>(await _context.Stores.GetByCompanyIds(query.CompanyIds,query.PageIndex,query.PageSize,query.SortBy,query.SortOrder));
            if (storeList != null && storeList.Count>0)
            {
                totalRecord = storeList.Select(x => x.TotalRecord).FirstOrDefault();
                var ids = storeList.Select(s => s.StoreId.ToString()).Distinct().ToArray();

            List<AddressModel> addresses = await _context.Addresses.GetPrimaryAddressStoreByIds(ids, EntityCategoryType.Store);
            List<Domain.Entities.Email> emaillist = _context.Emails.GetEmailList(ids, EntityCategoryType.Store);
            List<Domain.Entities.Phone> phonelist = _context.Phones.GetPhoneList(ids, EntityCategoryType.Store);
            List<StoreAmenityResultModel> amenities = await _context.StoreAmenities.GetAmenityListByStoreIds(ids);
            List<StoreHoursResultModel> storeHours = await _context.StoreHours.GetStoreHoursListByStoreIds(ids);
            List<CarWashTypeModel> carwashtype = await _context.CarWashTypes.GetListByStoreIds(storeList.Select(s => s.StoreId.ToString()).Distinct().ToArray());

            string[] siteIds = storeList.Where(s => !string.IsNullOrWhiteSpace(s.SiteId)).Select(s => s.SiteId.Trim()).Distinct().ToArray();
            ICollection<SiteProductModel> siteProducts = new List<SiteProductModel>();

            if (siteIds != null && siteIds.Any())
            {
                siteProducts = (await _mppaapiclient.SiteProductAsync(siteIds))?.Data ?? new List<SiteProductModel>();
            }

           
                foreach (StoreSearchResult store in storeList)
                {

                    store.Addresses = addresses.Where(s => s.StoreId == store.StoreId);
                    store.Emails = _mapper.Map<List<EmailModel>>(emaillist.Where(s => s.StoreId == store.StoreId));
                    store.Phones = _mapper.Map<List<PhoneModel>>(phonelist.Where(s => s.StoreId == store.StoreId));
                    store.StoreHours = _mapper.Map<List<StoreHoursResult>>(storeHours.Where(s => s.StoreId == store.StoreId));
                    store.Amenities = _mapper.Map<List<StoreAmenitySearchResult>>(amenities.Where(s => s.StoreId == store.StoreId));

                    store.PumpProducts = string.IsNullOrWhiteSpace(store.SiteId) ? new List<SiteProductModel>() : siteProducts.Where(t => t.SiteId == store.SiteId.Trim()).ToList();
                    store.CarWashTypes = carwashtype.Where(s => s.StoreId == store.StoreId);
                    SiteModel stts = store.SiteId == null ? null : await _mppaapiclient.StatusAsync(store.SiteId);
                    store.Status = stts != null && stts.IsOnline;
                }
            }

            return new PaginatedList<StoreSearchResult>() { Data = storeList,
                PageIndex = query.PageIndex ?? 0,
                PageSize = query.PageSize ?? 0,
                TotalCount = totalRecord,
            };
        }
    }
}
