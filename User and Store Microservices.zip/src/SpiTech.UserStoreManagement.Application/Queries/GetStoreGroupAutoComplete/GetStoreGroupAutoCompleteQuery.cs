﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Entities;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreGroupAutoComplete
{
    public class GetStoreGroupAutoCompleteQuery : IRequest<ResponseList<StoreGroup>>
    {
        public int StoreGroupId { get; set; }
        public string StoreGroupName { get; set; }
    }
}
