﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreGroupAutoComplete
{
    public class GetStoreGroupAutoCompleteHandler : IRequestHandler<GetStoreGroupAutoCompleteQuery, ResponseList<StoreGroup>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetStoreGroupAutoCompleteHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetStoreGroupAutoCompleteHandler(IUnitOfWork context,
                                   ILogger<GetStoreGroupAutoCompleteHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<ResponseList<StoreGroup>> Handle(GetStoreGroupAutoCompleteQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request); 

            IEnumerable<StoreGroup> list = await _context.StoreGroups.GetStoreGroupAutoComplete(request.StoreGroupId, request.StoreGroupName);

            return await Task.FromResult(new ResponseList<StoreGroup> { Data = list.ToList() });
        }
    }
}
