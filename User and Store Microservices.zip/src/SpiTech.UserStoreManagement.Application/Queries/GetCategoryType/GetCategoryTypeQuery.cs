﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetCategoryType
{
    public class GetCategoryTypeQuery : IRequest<ResponseList<CategoryTypeModel>>
    {
        public int Id { get; set; }
    }
}
