﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetCountry
{
    public class GetCountryQuery : IRequest<ResponseList<CountryModel>>
    {
        public int Id { get; set; }
    }
}
