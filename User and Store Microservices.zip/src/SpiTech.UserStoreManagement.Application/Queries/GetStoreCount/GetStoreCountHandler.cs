﻿using AutoMapper;
using MediatR;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.Service.Clients.Identity;
using SpiTech.Service.Clients.Mppa;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Mappers;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreCount
{

    public class GetStoreCountHandler : IRequestHandler<GetStoreCountQuery, int>
    {
        private readonly IUnitOfWork _context;
        private readonly IMppaServiceClient _mppaapiclient;
        private readonly IIdentityServiceClient _identityServiceClient;
        private readonly IUserAuthenticationProvider _userAuthenticationProvider;
        private readonly ILogger<GetStoreCountHandler> _logger;

        private readonly IMapper _mapper;
        public GetStoreCountHandler(IUnitOfWork context, IMppaServiceClient mppaapiclient, IMapper mapper, IIdentityServiceClient identityServiceClient, IUserAuthenticationProvider userAuthenticationProvider,
            ILogger<GetStoreCountHandler> logger)
        {
            _context = context;
            _mppaapiclient = mppaapiclient;
            _mapper = mapper;
            _identityServiceClient = identityServiceClient;
            _userAuthenticationProvider = userAuthenticationProvider;
            _logger = logger;
        }

        public async Task<int> Handle(GetStoreCountQuery request, CancellationToken cancellationToken)
        {
            List<StoresSearchModel> storeList = new();

            try
            {                
            _logger.Warn($"Get Store Count UserId init");

                var userId = _userAuthenticationProvider.GetUserAuthentication().UserId;

                _logger.Warn($"Get Store Count UserId:" + userId);
 
                UserModelResponseModel user = await _identityServiceClient.GetUserByIdAsync(userId);

                _logger.Warn($"Get user detail log");
 
                var RoleId = user.Data.Roles.FirstOrDefault()?.RoleId;
 
                _logger.Warn($"Get user RoleId :" + RoleId);

                storeList = await _context.Stores.GetStoresForDashboard(null, null, null, userId, RoleId, null, null);
                _logger.Warn($"GetStoresForDashboard");
                List<SiteModel> storeCountData = _mapper.Map<List<SiteModel>>
            (await _mppaapiclient.SiteStatusesAsync(300, true)); 
                int storeCount = 0;
                _logger.Warn($"Get OnlineStore SiteStatuses");
                foreach (var item in storeList)
                {
                    if (storeCountData.Count > 0)
                    {
                        if (storeCountData.Where(x => x.StoreId == item.StoreId).Count() > 0)
                        {
                            storeCount = storeCount + 1;
                        }
                    }
                }
                return await Task.FromResult(storeCount);
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
