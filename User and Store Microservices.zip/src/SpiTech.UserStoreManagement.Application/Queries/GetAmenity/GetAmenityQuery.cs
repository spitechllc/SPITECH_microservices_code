﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetAmenity
{
    public class GetAmenityQuery : IRequest<ResponseList<AmenityModel>>
    {
    }
}
