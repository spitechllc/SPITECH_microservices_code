﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetAmenity
{
    public class GetAmenityHandler : IRequestHandler<GetAmenityQuery, ResponseList<AmenityModel>>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetAmenityHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        public GetAmenityHandler(IUnitOfWork context,
                                 ILogger<GetAmenityHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<ResponseList<AmenityModel>> Handle(GetAmenityQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<AmenityModel> result = _mapper.Map<IEnumerable<AmenityModel>>(await _context.Amenities.GetAllActive());

            _logger.TraceExitMethod(nameof(Handle), result);

            return new ResponseList<AmenityModel>() { Data = result };
        }
    }
}
