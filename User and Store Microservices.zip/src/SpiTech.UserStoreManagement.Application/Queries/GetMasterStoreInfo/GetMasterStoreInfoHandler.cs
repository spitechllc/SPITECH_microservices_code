﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetMasterStoreInfo
{
    public class GetMasterStoreInfoQueryHandler : IRequestHandler<GetMasterStoreInfoQuery, ResponseModel<StoreInfoModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetMasterStoreInfoQueryHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetMasterStoreInfoQueryHandler(IUnitOfWork context,
                                    ILogger<GetMasterStoreInfoQueryHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<ResponseModel<StoreInfoModel>> Handle(GetMasterStoreInfoQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            ResponseModel<StoreInfoModel> result = new()
            {
                Data = await _context.Stores.GetMasterStoreInfo()
            };

            if (result.Data != null)
            {
                result.Data.Addresses = _context.Addresses.Get(result.Data.StoreId, EntityCategoryType.Store);
                result.Data.Emails = _mapper.Map<List<EmailModel>>(_context.Emails.Get(result.Data.StoreId, EntityCategoryType.Store));
                result.Data.Phones = _mapper.Map<List<PhoneModel>>(_context.Phones.Get(result.Data.StoreId, EntityCategoryType.Store));
                result.Success = true;
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return await Task.FromResult(result);
        }
    }
}
