﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetMasterStoreInfo
{
    public class GetMasterStoreInfoQuery : IRequest<ResponseModel<StoreInfoModel>>
    {
    }
}
