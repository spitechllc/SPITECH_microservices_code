﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetCompanyAutoComplete
{
    public class GetCompanyAutoCompleteQuery : IRequest<ResponseList<CompanyAutoCompleteModel>>
    {
        public int ComapnyId { get; set; }
        public string CompanyName { get; set; }
    }
}
