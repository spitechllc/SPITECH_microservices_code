﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetCategoryTypeById
{
    public class GetCategoryTypeByIdHandler : IRequestHandler<GetCategoryTypeByIdQuery, ResponseList<CategoryTypeModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetCategoryTypeByIdHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetCategoryTypeByIdHandler(IUnitOfWork context,
                                   ILogger<GetCategoryTypeByIdHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<ResponseList<CategoryTypeModel>> Handle(GetCategoryTypeByIdQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            IEnumerable<CategoryTypeModel> list = _mapper.Map<IEnumerable<CategoryTypeModel>>(await _context.Categories.GetCategoryById(query.Id));

            return await Task.FromResult(new ResponseList<CategoryTypeModel> { Data = list.ToList() });

        }

    }
}
