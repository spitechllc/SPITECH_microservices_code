﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreAutoComplete
{
    public class StoreAutoCompleteHandler : IRequestHandler<StoreAutoCompleteQuery, ResponseList<StoreAutoCompleteModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<StoreAutoCompleteHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public StoreAutoCompleteHandler(IUnitOfWork context,
                                   ILogger<StoreAutoCompleteHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<ResponseList<StoreAutoCompleteModel>> Handle(StoreAutoCompleteQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<StoreAutoCompleteModel> list = _mapper.Map<IEnumerable<StoreAutoCompleteModel>>(await _context.Stores.GetStoreAutoComplete(request.SiteId, request.StoreName,request.StoreId));

            return await Task.FromResult(new ResponseList<StoreAutoCompleteModel> { Data = list.ToList() });
        }
    }
}
