﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreAutoComplete
{
    public class StoreAutoCompleteQuery : IRequest<ResponseList<StoreAutoCompleteModel>>
    {
        public string SiteId { get; set; }
        public string StoreName { get; set; }
        public int StoreId { get; set; }
    }
}
