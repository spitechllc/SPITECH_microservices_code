﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetSaleAgentById
{
    public class GetSaleAgentByIdHandler : IRequestHandler<GetSaleAgentByIdQuery, SaleAgentSearchModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetSaleAgentByIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetSaleAgentByIdHandler(IUnitOfWork context,
                                    ILogger<GetSaleAgentByIdHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<SaleAgentSearchModel> Handle(GetSaleAgentByIdQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            SaleAgentSearchModel result = _mapper.Map<SaleAgentSearchModel>(await _context.SaleAgents.Get(query.SaleAgentId));
            if (result != null)
            {
                result.Addresses = _context.Addresses.Get(result.SaleAgentId,EntityCategoryType.SaleAgent);
                result.Emails = _mapper.Map<List<EmailModel>>(_context.Emails.Get(result.SaleAgentId,EntityCategoryType.SaleAgent));
                result.Phones = _mapper.Map<List<PhoneModel>>(_context.Phones.Get(result.SaleAgentId,EntityCategoryType.SaleAgent));
                var saleAgentStores = await _context.Stores.GetBySaleAgentId(result.SaleAgentId);
                if(saleAgentStores!=null && saleAgentStores.Count>0)
                {
                    result.Stores = saleAgentStores;
                    result.StoreIds = saleAgentStores.Select(t => t.StoreId).ToArray();
                }
                
            }
                _logger.TraceExitMethod(nameof(Handle), result);

            return await Task.FromResult(result);

        }
    }
}
