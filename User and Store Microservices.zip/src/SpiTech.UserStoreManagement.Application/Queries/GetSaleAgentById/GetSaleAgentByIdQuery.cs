﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Entities;

namespace SpiTech.UserStoreManagement.Application.Queries.GetSaleAgentById
{
    public class GetSaleAgentByIdQuery : IRequest<SaleAgentSearchModel>
    {
        public int SaleAgentId { get; set; }
    }
}
