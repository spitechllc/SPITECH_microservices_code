﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentValidation;

namespace SpiTech.UserStoreManagement.Application.Queries.GetSaleAgentById
{
    public class GetSaleAgentByIdValidator : AbstractValidator<GetSaleAgentByIdQuery>
    {
        public GetSaleAgentByIdValidator()
        {
            RuleFor(s => s.SaleAgentId).GreaterThan(0).WithMessage("SaleAgentId is required");
        }
    }
}
