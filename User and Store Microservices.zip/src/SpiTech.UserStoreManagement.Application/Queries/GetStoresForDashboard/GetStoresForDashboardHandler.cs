﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Service.Clients.Identity;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using Polly;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using static Slapper.AutoMapper;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoresForDashboard
{
    public class GetStoresForDashboardHandler : IRequestHandler<GetStoresForDashboardQuery, ResponseList<StoresSearchModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetStoresForDashboardHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IIdentityServiceClient _identityServiceClient;

        public GetStoresForDashboardHandler(IUnitOfWork context,
                                 ILogger<GetStoresForDashboardHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper,
                                 IIdentityServiceClient identityServiceClient
                                  )
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _identityServiceClient = identityServiceClient;
        }

        public async Task<ResponseList<StoresSearchModel>> Handle(GetStoresForDashboardQuery request, CancellationToken cancellationToken)
        {
            _logger.Warn("GetStoresForDashboardQueryHandler start");
            _logger.TraceEnterMethod(nameof(Handle), request);
            List<StoresSearchModel> storeList = new();

            try
            {
                if (string.IsNullOrEmpty(request.RoleId))
                {
                    UserModelResponseModel user = await _identityServiceClient.GetUserByIdAsync(request.UserId);
                    if (user.Data.Roles == null)
                    {
                        _logger.Warn("UserRole", user.Data.UserId);
                        request.RoleId = "";
                    }
                    else
                    {
                        request.RoleId = user.Data.Roles.FirstOrDefault()?.RoleId;
                    }
                }

                storeList = await _context.Stores.GetStoresForDashboard(request.StateId, request.City, request.Zipcode, request.UserId, request.RoleId, request.CompanyId, request.StoreGroupIds);
                _logger.Warn("GetStoresForDashboardQueryHandler start storelist");
                if (request.AppIds != null && request.AppIds.Length > 0)
                {
                    _logger.Warn("GetStoresForDashboardQueryHandler start storelist id");
                    List<StoresSearchModel> storeLists = new List<StoresSearchModel>();
                    List<StoreTenantMappingUpdateModel> storeTenantMasterslist = new List<StoreTenantMappingUpdateModel>();
                    for (int i = 0; i < request.AppIds.Length; i++)
                    {
                        int id = request.AppIds[i];
                        foreach (var item in storeList)
                        {
                            StoreTenantViewModel tenantMasterModel = new StoreTenantViewModel();
                            List<Domain.Models.TenantMasterList> tenantMasterdata = new List<Domain.Models.TenantMasterList>();
                            var tenantdata = await _context.Stores.GetStoreIdAndIdByTenantId(item.StoreId, id);
                            foreach (var stores in tenantdata)
                            {
                                var res = await _identityServiceClient.GetTenantMasterListAsync();
                                var tenants = res.Where(x => x.Id == stores.TenantId).ToList();
                                foreach (var obj in tenants)
                                {
                                    Domain.Models.TenantMasterList tenantMasterList = new Domain.Models.TenantMasterList();
                                    tenantMasterList.TenantId = obj.Id;
                                    tenantMasterList.TenantName = obj.TenantName;
                                    tenantMasterdata.Add(tenantMasterList);
                                }
                                item.TenantMasterLists = tenantMasterdata;
                                storeLists.Add(item);
                            }
                        }
                    }
                    storeList = storeLists;
                }
                else
                {
                    List<StoresSearchModel> storeLists = new List<StoresSearchModel>();
                    StoreTenantViewModel tenantMasterModel = new StoreTenantViewModel();
                    foreach (var item in storeList)
                    {
                        var storesId = await _context.Stores.GetStoreTenantMasterByStoreIds(item.StoreId);
                        List<Domain.Models.TenantMasterList> tenantMasterdata = new List<Domain.Models.TenantMasterList>();
                        foreach (var store in storesId)
                        {
                            var tenantdata = await _context.Stores.GetStoreIdAndIdByTenantId(item.StoreId, store.TenantId);
                            foreach (var stores in tenantdata)
                            {
                                var res = await _identityServiceClient.GetTenantMasterListAsync();
                                var tenants = res.Where(x => x.Id == stores.TenantId).ToList();
                                foreach (var obj in tenants)
                                {
                                    Domain.Models.TenantMasterList tenantMasterList = new Domain.Models.TenantMasterList();
                                    tenantMasterList.TenantId = obj.Id;
                                    tenantMasterList.TenantName = obj.TenantName;
                                    tenantMasterdata.Add(tenantMasterList);
                                }
                            }
                        }
                        item.TenantMasterLists = tenantMasterdata;
                        storeLists.Add(item);
                    }
                    storeList = storeLists;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            var result = new ResponseList<StoresSearchModel>
            {
                Data = storeList,
            };

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}