﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoresForDashboard
{
    public class GetStoresForDashboardQuery:IRequest<ResponseList<StoresSearchModel>>
    {
      
        public int? StateId { get; set; }
        public string City { get; set; }
        public string Zipcode { get; set; }
        public int? UserId { get; set; }
        public string RoleId { get; set; }
        public int? CompanyId { get; set; }
        public int[] StoreGroupIds { get; set; }
        public int[] AppIds { get; set; }

    }
}
