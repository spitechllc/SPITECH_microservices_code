﻿using AutoMapper;
using MediatR;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Service.Clients.Payments;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreById
{
    public class GetStoreByIdQueryHandler : IRequestHandler<GetStoreByIdQuery, StoreSearchResult>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetStoreByIdQueryHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IMppaServiceClient _mppaapiclient;
        private readonly IPaymentServiceClient _paymentapiclient;

        public GetStoreByIdQueryHandler(IUnitOfWork context,
                                    ILogger<GetStoreByIdQueryHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper,
                                    IMppaServiceClient mppaapiclient, IPaymentServiceClient paymentapiclient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _mppaapiclient = mppaapiclient;
            _paymentapiclient = paymentapiclient;
        }

        public async Task<StoreSearchResult> Handle(GetStoreByIdQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            var storeFromDb = await _context.Stores.Get(query.StoreId);
            StoreSearchResult result = null;

            if (storeFromDb != null)
            {
                result = _mapper.Map<StoreSearchResult>(storeFromDb);
                Domain.Entities.Company comp = await _context.Companies.GetCompanyById(result.CompanyId);
                if (comp != null)
                {
                    result.Company = comp.Name;
                }

                if (result != null)
                {
                    var storeConfig = (await _paymentapiclient.StoreConfigGETAsync(result.StoreId))?.Data;

                    result.Addresses = _context.Addresses.Get(query.StoreId, EntityCategoryType.Store);
                    result.Emails = _mapper.Map<List<EmailModel>>(_context.Emails.Get(query.StoreId, EntityCategoryType.Store));
                    result.Phones = _mapper.Map<List<PhoneModel>>(_context.Phones.Get(query.StoreId, EntityCategoryType.Store));
                    result.Amenities = await _context.StoreAmenities.GetAmenityByStoreId(result.StoreId);
                    result.StoreHours = await _context.StoreHours.GetHoursByStoreId(result.StoreId);

                    result.PumpProducts = string.IsNullOrWhiteSpace(result.SiteId) ? null : (await _mppaapiclient.SiteProductAsync(new[] { result.SiteId }))?.Data;

                    result.CarWashTypes = await _context.CarWashTypes.GetByStoreId(result.StoreId);
                    result.IsAchEnabled = storeConfig?.IsAchEnabled ?? false;
                    int storeid = query.StoreId;
                    IEnumerable<StoreTenantMappingUpdateModel> mappingUpdateModels = _mapper.Map<IEnumerable<StoreTenantMappingUpdateModel>>(await _context.Stores.GetStoreTenantMasterByStoreId(storeid));
                    if (mappingUpdateModels != null)
                    {
                        List<int> number = new List<int>();
                        foreach (StoreTenantMappingUpdateModel mappingModel in mappingUpdateModels)
                        {
                            number.Add(mappingModel.TenantId);
                        }
                        result.AppIds = number.ToArray();
                    }
                }
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return await Task.FromResult(result);
        }
    }
}
