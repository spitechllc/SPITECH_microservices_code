﻿using MediatR;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreById
{
    public class GetStoreByIdQuery : IRequest<StoreSearchResult>
    {
        public int StoreId { get; set; }
    }
}
