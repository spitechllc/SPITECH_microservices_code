﻿using FluentValidation;

namespace SpiTech.UserStoreManagement.Application.Queries.GetStoreById
{
    public class GetStoreByIdQueryValidator : AbstractValidator<GetStoreByIdQuery>
    {
        public GetStoreByIdQueryValidator()
        {
            RuleFor(s => s.StoreId).GreaterThan(0);
        }
    }
}
