﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Application.Queries.GetUserByFilter
{
    public class GetUserByFilterQuery : IRequest<ResponseList<UserModel>>
    {
        public int EntityId { get; set; }
        public EntityCategoryType EntityType { get; set; }
    }
}
