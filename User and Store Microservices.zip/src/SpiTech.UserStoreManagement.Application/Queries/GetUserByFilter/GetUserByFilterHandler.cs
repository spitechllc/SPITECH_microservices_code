﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.UserStoreManagement.Application.UnitOfWorks;
using SpiTech.UserStoreManagement.Domain.Enums;
using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UserModel = SpiTech.UserStoreManagement.Domain.Models.UserModel;

namespace SpiTech.UserStoreManagement.Application.Queries.GetUserByFilter
{
    public class GetUserByFilterHandler : IRequestHandler<GetUserByFilterQuery, ResponseList<UserModel>>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetUserByFilterHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IIdentityServiceClient identityapiclient;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetUserByFilterHandler(IUnitOfWork context,
                                 ILogger<GetUserByFilterHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper,
                                 IIdentityServiceClient identityclient, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            identityapiclient = identityclient;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<ResponseList<UserModel>> Handle(GetUserByFilterQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            if (request.EntityType == EntityCategoryType.User)
            {
                this.userAuthenticationProvider.ValidateUserAccess(request.EntityId);
            }
            List<UserModel> userlist = new();

            if (request.EntityType == EntityCategoryType.Company)
            {
                userlist = _mapper.Map<List<UserModel>>(_context.Users.Get(request.EntityId, EntityCategoryType.Company));
            }
            else if (request.EntityType == EntityCategoryType.Store)
            {
                userlist = _mapper.Map<List<UserModel>>(_context.Users.Get(request.EntityId, EntityCategoryType.Store));
            }
            else if (request.EntityType == EntityCategoryType.User)
            {
                userlist = _mapper.Map<List<UserModel>>(_context.Users.Get(request.EntityId, EntityCategoryType.User));
            }

            foreach (UserModel item in userlist)
            {
                Service.Clients.Identity.UserModelResponseModel users = await identityapiclient.GetUserByIdAsync(item.UserId);
                item.UserName = users?.Data?.UserName;

                item.Roles = _mapper.Map<IEnumerable<Domain.Models.RoleModel>>(users?.Data?.Roles);

                item.Addresses = _context.Addresses.Get(item.UserId, EntityCategoryType.User);
                item.Emails = _mapper.Map<List<EmailModel>>(_context.Emails.Get(item.UserId, EntityCategoryType.User));
                item.Phones = _mapper.Map<List<PhoneModel>>(_context.Phones.Get(item.UserId, EntityCategoryType.User));
            }

            _logger.TraceExitMethod(nameof(Handle), request);

            return await Task.FromResult(new ResponseList<UserModel>() { Data = userlist });
        }
    }
}
