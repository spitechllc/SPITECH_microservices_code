﻿using FluentValidation;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents.Events.Store;
using SpiTech.EventBus.DomainEvents.ServiceCollection;
using SpiTech.UserStoreManagement.Domain.Mappers;
using System.Reflection;

namespace SpiTech.UserStoreManagement.Application
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services, IConfiguration configuration)
        {
            services
                .AddMediatR(Assembly.GetExecutingAssembly()).AddAutoMapper(typeof(AddressProfile))
                .AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());

            services.RegisterMessageQueue(configuration, null, (ctx, cfg) =>
            {
                cfg.ConfigurePublishEvent<StoreBillingFeeEvent>();
                cfg.ConfigurePublishEvent<StoreEvent>();
                cfg.ConfigurePublishEvent<StoreUserEvent>();
                cfg.ConfigurePublishEvent<UserActivityLogEvent>();
            });

            return services;
        }
    }
}