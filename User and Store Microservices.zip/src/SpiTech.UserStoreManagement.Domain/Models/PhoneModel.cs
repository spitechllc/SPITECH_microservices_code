﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class PhoneModel
    {
        public int PhoneId { get; set; }
        public int CategoryTypeLevelId { get; set; }
        public string CountryCode { get; set; }
        public string AreaCode { get; set; }
        public string Number { get; set; }
        public bool IsActive { get; set; } = true;
    }
}
