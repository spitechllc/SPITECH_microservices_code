﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class TimeZoneModel
    {
        public int TimeZoneId { get; set; }
        public string TimeZoneName { get; set; }
    }
}
