﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class StoreAmenityResultModel
    {
        public int StoreId { get; set; }
        public int StoreAmenityId { get; set; }

        public int AmenityId { get; set; }

        public string AmenityName { get; set; }
    }
}
