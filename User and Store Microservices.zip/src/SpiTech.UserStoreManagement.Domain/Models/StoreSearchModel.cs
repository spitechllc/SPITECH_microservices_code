﻿using SpiTech.Service.Clients.Mppa;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class StoreSearchModel
    {
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public string SiteId { get; set; }
        public decimal MaxAuthorizeAmount { get; set; }
        public bool ConsentCashReward { get; set; }
        public decimal Distance { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public double? Longitude { get; set; }
        public double? Latitude { get; set; }
        public string ZipCode { get; set; }
        public bool DisableEod { get; set; }
        public bool DisableBilling { get; set; }
        public int? StoreCategoryId { get; set; }
        public bool EnableACHLoyalty { get; set; }
        public bool EnableCardLoyalty { get; set; }
        public string LoyaltyProgramId { get; set; }
        public IEnumerable<SiteProductModel> PumpProducts { get; set; }

        [Newtonsoft.Json.JsonIgnore]
        [System.Text.Json.Serialization.JsonIgnore]
        public int TotalRecord { get; set; }
    }
}

