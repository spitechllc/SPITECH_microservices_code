﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class CategoryTypeLevelModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int CategoryTypeId { get; set; }
    }
}
