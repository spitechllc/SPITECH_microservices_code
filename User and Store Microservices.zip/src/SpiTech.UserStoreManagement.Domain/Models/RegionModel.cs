﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class RegionModel
    {
        public int RegionId { get; set; }
        public string RegionName { get; set; }
        public string Zipcode { get; set; }
    }
}
