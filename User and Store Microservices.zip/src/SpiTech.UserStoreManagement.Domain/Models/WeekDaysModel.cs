﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class WeekDaysModel
    {
        public int WeekDayId { get; set; }
        public string Name { get; set; }
    }
}
