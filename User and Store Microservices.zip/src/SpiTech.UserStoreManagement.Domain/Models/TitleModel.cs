﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class TitleModel
    {
        public int TitleId { get; set; }
        public string TitleName { get; set; }
    }
}
