﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class RoleModel
    {
        public string RoleId { get; set; }
        public string RoleName { get; set; }
        public int RoleTypeId { get; set; }
        public string RoleType { get; set; }
        // public virtual IEnumerable<ClaimModel> Claims { get; set; }
    }
}
