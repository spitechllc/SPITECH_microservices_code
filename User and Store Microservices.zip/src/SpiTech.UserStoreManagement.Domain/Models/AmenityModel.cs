﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class AmenityModel
    {
        public int AmenityId { get; set; }
        public string AmenityName { get; set; }
        public string ImageUrl { get; set; }
    }
}
