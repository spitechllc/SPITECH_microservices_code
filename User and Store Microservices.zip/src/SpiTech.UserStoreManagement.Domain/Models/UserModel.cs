﻿using System;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class UserModel
    {
        public int UserId { get; set; }
        public int Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int? DesignationId { get; set; }
        public int CompanyId { get; set; }
        public int StoreId { get; set; }
        public int ManagerId { get; set; }
        public int RegionId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public bool IsActive { get; set; }
        public string PhotoUrl { get; set; }

        public IEnumerable<AddressModel> Addresses { get; set; }
        public IEnumerable<PhoneModel> Phones { get; set; }
        public IEnumerable<EmailModel> Emails { get; set; }
        public IEnumerable<RoleModel> Roles { get; set; }
        public DateTime? LastAccess { get; set; }

        [Newtonsoft.Json.JsonIgnore]
        [System.Text.Json.Serialization.JsonIgnore]
        public int TotalRecord { get; set; }

    }
}

