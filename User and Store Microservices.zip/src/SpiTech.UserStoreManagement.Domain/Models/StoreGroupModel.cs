﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Domain.Models
{
   
    public class StoreGroupModel
    {
       
        public int StoreGroupId { get; set; }
        public string StoreGroupName { get; set; }
        public IEnumerable<StoreGroupStoresModel> Stores { get; set; }
        public IEnumerable<StoreGroupUsersModel> Users { get; set; }
    }
}