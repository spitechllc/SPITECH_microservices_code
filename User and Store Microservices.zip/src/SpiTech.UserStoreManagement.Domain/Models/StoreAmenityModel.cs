﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class StoreAmenityModel
    {
        public int StoreAmenityId { get; set; }

        public int AmenityId { get; set; }
    }
}
