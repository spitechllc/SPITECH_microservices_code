﻿using SpiTech.Service.Clients.Mppa;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class StoreModelForSummary
    {
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public string SiteId { get; set; }
        public decimal MaxAuthorizeAmount { get; set; }
        public bool? ConsentCashReward { get; set; }
        public bool DisableEod { get; set; }
        public bool DisableBilling { get; set; }
        public decimal Distance { get; set; }
        public int? StoreCategoryId { get; set; }
        public bool? IsAchEnabled { get; set; }
        public bool EnableACHLoyalty { get; set; }
        public bool EnableCardLoyalty { get; set; }
        public string LoyaltyProgramId { get; set; }
        public IEnumerable<AddressModelSummary> Addresses { get; set; }
        public IEnumerable<SiteProductModel> PumpProducts { get; set; }


        [Newtonsoft.Json.JsonIgnore]
        [System.Text.Json.Serialization.JsonIgnore]
        public int TotalRecord { get; set; }

    }
    public class StoreModelForSummaryWithTenant
    {
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public string SiteId { get; set; }
        public decimal MaxAuthorizeAmount { get; set; }
        public bool? ConsentCashReward { get; set; }
        public bool DisableEod { get; set; }
        public bool DisableBilling { get; set; }
        public decimal Distance { get; set; }
        public int? StoreCategoryId { get; set; }
        public bool? IsAchEnabled { get; set; }
        public bool EnableACHLoyalty { get; set; }
        public bool EnableCardLoyalty { get; set; }
        public string LoyaltyProgramId { get; set; }
        public IEnumerable<AddressModelSummary> Addresses { get; set; }
        public IEnumerable<SiteProductModel> PumpProducts { get; set; }


        [Newtonsoft.Json.JsonIgnore]
        [System.Text.Json.Serialization.JsonIgnore]
        public int TotalRecord { get; set; }

        public int[] TenantId { get; set; } 
    }
}

