﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class StoreTenantMappingModel
    {
        public int Id { get; set; }
        public int StoreId { get; set; }
        public int[] TenantId { get; set; }
    }
    public class StoreTenantMappingUpdateModel
    {
        public int Id { get; set; }
        public int StoreId { get; set; }
        public int TenantId { get; set; }
        public string TenantName { get; set; }
    }
    public class StoreTenantMappingListModel
    {
        public int[] Id { get; set; }
        public int StoreId { get; set; }
        public int[] TenantId { get; set; }
    }
    public class StoreTenantMappingResponseModel
    {
        public int[] TenantId { get; set; }
    }
    public class StoreTenantMappingSearchModel
    {
        public int StoreId { get; set; }
    }
    public class StoreTenantViewModel
    {
        public int Id { get; set; }
        public int TenantId { get; set; }
        public int StoreId { get; set; }
    }
}
