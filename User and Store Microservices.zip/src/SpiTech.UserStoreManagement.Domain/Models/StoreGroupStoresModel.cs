﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.UserStoreManagement.Domain.Models
{
   
    public class StoreGroupStoresModel
    {
       public int StoreGroupStoresId { get; set; }
        public int StoreGroupId { get; set; }
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public bool IsActive { get; set; } = true;
    }
}