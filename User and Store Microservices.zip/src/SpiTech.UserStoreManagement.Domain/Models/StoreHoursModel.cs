﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class StoreHoursModel
    {
        public int StoreHoursId { get; set; }
        public int WeekDayId { get; set; }
        public string OpenTime { get; set; }
        public string CloseTime { get; set; }
        public bool Is24Hours { get; set; }

    }
}
