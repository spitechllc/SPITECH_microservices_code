﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class EmailModel
    {
        public int EmailId { get; set; }
        public int CategoryTypeLevelId { get; set; }
        public string Email { get; set; }
        public bool IsActive { get; set; } = true;
    }
}
