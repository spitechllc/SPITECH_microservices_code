﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class CompanyAutoCompleteModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
