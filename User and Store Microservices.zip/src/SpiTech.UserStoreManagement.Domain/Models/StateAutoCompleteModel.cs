﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class StateAutoCompleteModel
    {
        public int StateId { get; set; }
        public string StateName { get; set; }
    }
}
