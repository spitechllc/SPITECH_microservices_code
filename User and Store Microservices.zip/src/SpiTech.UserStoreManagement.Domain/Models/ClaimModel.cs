﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class ClaimModel
    {
        public int ClaimId { get; set; }
        public string ClaimName { get; set; }
    }
}
