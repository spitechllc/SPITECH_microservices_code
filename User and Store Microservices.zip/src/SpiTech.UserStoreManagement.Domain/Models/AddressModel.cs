﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class AddressModel
    {
        public int AddressId { get; set; }
        public int CategoryTypeLevelId { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public int CountryId { get; set; }
        public string Country { get; set; }
        public int StateId { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public double? Longitude { get; set; }
        public double? Latitude { get; set; }
        public string ZipCode { get; set; }
        public bool IsActive { get; set; } = true;
        public int? CompanyId { get; set; }
        public int? StoreId { get; set; }
        public int? UserId { get; set; }
        public int? SaleAgentId { get; set; }
        public int? ResellerId { get; set; }
    }
}
