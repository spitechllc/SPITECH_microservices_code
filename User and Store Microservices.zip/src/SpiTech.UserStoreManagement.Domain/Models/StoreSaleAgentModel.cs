﻿using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class StoreSaleAgentModel
    {
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public string SiteId { get; set; }
        public int? SaleAgentId { get; set; }
    }
}
