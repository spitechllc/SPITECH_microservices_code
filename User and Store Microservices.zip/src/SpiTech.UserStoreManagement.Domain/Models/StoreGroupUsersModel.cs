﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.UserStoreManagement.Domain.Models
{
   
    public class StoreGroupUsersModel
    {
       public int StoreGroupUsersId { get; set; }
        public int StoreGroupId { get; set; }
        public int UserId { get; set; }
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public bool IsActive { get; set; } = true;
    }
}