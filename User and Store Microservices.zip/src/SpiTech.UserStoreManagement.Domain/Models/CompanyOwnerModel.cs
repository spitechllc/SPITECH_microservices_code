﻿using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class CompanyOwnerModel           
    {
        public UserModel Owner { get; set; }
        public int[] CompanyIds { get; set; }
        public IEnumerable<CompanySearchModel> Companies { get; set; }
    }
}
