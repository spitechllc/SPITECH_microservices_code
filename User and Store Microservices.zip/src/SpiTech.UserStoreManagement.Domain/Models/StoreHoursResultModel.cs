﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class StoreHoursResultModel
    {
        public string Name { get; set; }
        public string OpenTime { get; set; }
        public string CloseTime { get; set; }
        public bool Is24Hours { get; set; }
        public int StoreId { get; set; }
    }
}
