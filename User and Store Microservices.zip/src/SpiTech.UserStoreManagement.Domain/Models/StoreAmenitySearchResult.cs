﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class StoreAmenitySearchResult
    {
        public int StoreAmenityId { get; set; }

        public int AmenityId { get; set; }

        public string AmenityName { get; set; }
    }
}
