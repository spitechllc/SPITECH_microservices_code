﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class StateModel
    {
        public int StateId { get; set; }
        public int CountryId { get; set; }
        public string StateName { get; set; }
        public string StateCode { get; set; }
    }
}
