﻿using System;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class StoresSearchModel
    {
        public int StoreId { get; set; }
        public int TenantId { get; set; }
        public string StoreName { get; set; }
        public string SiteId { get; set; }
        public string StoreUrl { get; set; }
        public int MangerId { get; set; }
        public string MangerName { get; set; }
        public int RegionId { get; set; }
        public int RegionalManagerId { get; set; }
        public string RegionalManagerName { get; set; }
        public int POSId { get; set; }
        public string PosName { get; set; }
        public string Description { get; set; }
        public string Note { get; set; }
        public int TimeZoneId { get; set; }
        public string StoreImage { get; set; }
        public bool IsActive { get; set; } = true;
        public int CompanyId { get; set; }
        public string Company { get; set; }
        public decimal MaxAuthorizeAmount { get; set; }
        public bool? Status { get; set; }
        public bool? EnableBilling { get; set; }
        public bool? ConsentCashReward { get; set; }
        public bool IsMasterStore { get; set; }
        public bool DisableEod { get; set; }
        public bool DisableBilling { get; set; }
        public int? SaleAgentId { get; set; }   
        public string SaleAgentName { get; set; }
        public int? ResellerId { get; set; }
        public string ResellerName { get; set; }
        public string ResellerCompanyName { get; set; }
        public DateTime? LastTransactionDate { get; set; }
        public bool IsTestStore { get; set; }
        public bool EnableACHLoyalty { get; set; }
        public bool EnableCardLoyalty { get; set; }
        public string LoyaltyProgramId { get; set; }
        public DateTime? CreatedOn { get; set; }
        public IEnumerable<AddressModel> Addresses { get; set; }
        public IEnumerable<PhoneModel> Phones { get; set; }
        public IEnumerable<EmailModel> Emails { get; set; }

        public DateTime? CurrentHeartBeatTime { get; set; }
        public DateTime? LastHeartBeatTime { get; set; }
        public int? StoreCategoryId { get; set; }
        public string StoreCategory { get; set; }

        [Newtonsoft.Json.JsonIgnore]
        [System.Text.Json.Serialization.JsonIgnore]
        public int TotalRecord { get; set; }
        public List<TenantMasterList> TenantMasterLists { get; set; }
    }
    public class TenantMasterList
    {
        public int TenantId { get; set; }
        public string TenantName { get; set; }
    }
}
