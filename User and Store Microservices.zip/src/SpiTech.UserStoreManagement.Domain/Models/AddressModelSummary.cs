﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class AddressModelSummary
    {
        public int AddressId { get; set; }
        public int CategoryTypeLevelId { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public double? Longitude { get; set; }
        public double? Latitude { get; set; }
        public string ZipCode { get; set; }
        public int? StoreId { get; set; }
    }
}
