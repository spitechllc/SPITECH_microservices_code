﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class DashBoardSiteModel
    {
        public string SiteId { get; set; }
        public string SiteName { get; set; }
        public string SiteMPPAIdentifier { get; set; }
        public string MerchantId { get; set; }
        public string LocationId { get; set; }
        public bool? SiteMobileActive { get; set; }
        public string SiteAddress { get; set; }
        public string WelcomeMsg { get; set; }
        public string SettlementEmployee { get; set; }
        public bool? PartialAuthAllowed { get; set; }
        public int? PumpTimeout { get; set; }
        public int? StoreId { get; set; }
        public string HeartBeatUMTI { get; set; }
        public string HeartBeatTimeDateStamp { get; set; }
        public DateTime? CurrentHeartBeatTime { get; set; }
        public DateTime? LastHeartBeatTime { get; set; }
        public bool IsOnline { get; set; }

    }
}
