﻿using SpiTech.UserStoreManagement.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Domain.Entities
{

    public class ResellerModel
    {
        public int ResellerId { get; set; }
        public string CompanyName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Name { get { return FirstName + " " + LastName; } }
        public bool IsActive { get; set; }
        public IEnumerable<AddressModel> Addresses { get; set; }
        public IEnumerable<PhoneModel> Phones { get; set; }
        public IEnumerable<EmailModel> Emails { get; set; }
        public IEnumerable<CompanySearchModel> Companies { get; set; }
        public int[] CompanyIds { get; set; }

        [Newtonsoft.Json.JsonIgnore]
        [System.Text.Json.Serialization.JsonIgnore]
        public int TotalRecord { get; set; }
    }
}
