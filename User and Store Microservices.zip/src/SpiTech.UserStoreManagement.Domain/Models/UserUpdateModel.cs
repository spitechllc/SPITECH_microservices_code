﻿using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class UserUpdateModel
    {
        public int UserId { get; set; }
        public int Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int? DesignationId { get; set; }
        public int CompanyId { get; set; }
        public int StoreId { get; set; }
        public int ManagerId { get; set; }
        public int RegionId { get; set; }

        public IEnumerable<AddressModel> Addresses { get; set; }
        public IEnumerable<PhoneModel> Phones { get; set; }
        public IEnumerable<EmailModel> Emails { get; set; }
    }
}
