﻿using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class CompanySearchModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int? ResellerId { get; set; }
        public int? OwnerId { get; set; }
    }
}
