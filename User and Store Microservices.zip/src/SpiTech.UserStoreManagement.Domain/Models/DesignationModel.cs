﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class DesignationModel
    {
        public int DesignationId { get; set; }
        public string Name { get; set; }
    }
}