﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class CarWashTypeModel
    {
        public string CarWashName { get; set; }
        public decimal Price { get; set; }
        public int StoreId { get; set; }
    }
}