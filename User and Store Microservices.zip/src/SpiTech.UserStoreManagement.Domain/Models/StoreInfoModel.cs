﻿using System;
using System.Collections.Generic;

namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class StoreInfoModel
    {
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public string SiteId { get; set; }
        public string StoreUrl { get; set; }
        public int? MangerId { get; set; }
        public int RegionId { get; set; }
        public int? RegionalManagerId { get; set; }
        public int PosId { get; set; }
        public string PosName { get; set; }
        public string Description { get; set; }
        public string Note { get; set; }
        public string StoreImage { get; set; }
        public int TimeZoneId { get; set; }
        public bool? EnableBilling { get; set; }
        public bool? ConsentCashReward { get; set; }
        public bool IsMasterStore { get; set; }
        public int CompanyId { get; set; }
        public decimal MaxAuthorizeAmount { get; set; }
        public int? SaleAgentId { get; set; }
        public bool IsTestStore { get; set; }
        public int? ResellerId { get; set; }
        public bool DisableEod { get; set; }
        public bool DisableBilling { get; set; }

        public string SaleAgentName { get; set; }
        public bool? IsSaleAgentActive { get; set; }

        public string ResellerName { get; set; }
        public string ResellerCompanyName { get; set; }
        public bool? IsResellerActive { get; set; }

        public bool IsActive { get; set; }
        public string TimeZoneName { get; set; }
        public int? StoreCategoryId { get; set; }
        public bool EnableACHLoyalty { get; set; }
        public bool EnableCardLoyalty { get; set; }
        public string LoyaltyProgramId { get; set; }
        public IEnumerable<AddressModel> Addresses { get; set; }
        public IEnumerable<PhoneModel> Phones { get; set; }
        public IEnumerable<EmailModel> Emails { get; set; }
    }
}
