﻿namespace SpiTech.UserStoreManagement.Domain.Models
{
    public class StoreAutoCompleteModel
    {
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public string SiteId { get; set; }
    }
}
