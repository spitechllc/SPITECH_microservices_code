﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("WeekDays")]
    public class WeekDays : BaseEntity
    {
        [Key]
        public int WeekDayId { get; set; }
        public string Name { get; set; }
    }
}
