﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("PosSystem")]
    public class PosSystem : BaseEntity
    {
        [Key]
        public int PosId { get; set; }
        public string PosName { get; set; }
    }
}
