﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("SaleAgent")]
    public class SaleAgent : BaseEntity
    {
        [Key]
        public int SaleAgentId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
