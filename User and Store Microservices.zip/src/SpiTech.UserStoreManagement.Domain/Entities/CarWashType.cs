﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("CarWashType")]
    public class CarWashType : BaseEntity
    {
        [Key]
        public int CarWashTypeId { get; set; }
        public string CarWashName { get; set; }
        public decimal Price { get; set; }
        public int StoreId { get; set; }
    }
}
