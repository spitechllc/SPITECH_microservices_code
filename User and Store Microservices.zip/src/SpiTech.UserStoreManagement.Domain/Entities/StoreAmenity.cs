﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("StoreAmenity")]
    public class StoreAmenity : BaseEntity
    {
        [Key]
        public int StoreAmenityId { get; set; }

        public int StoreId { get; set; }

        public int AmenityId { get; set; }
    }
}
