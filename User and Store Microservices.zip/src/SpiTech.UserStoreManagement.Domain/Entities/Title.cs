﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("Title")]
    public class Title : BaseEntity
    {
        [Key]
        public int TitleId { get; set; }
        public string TitleName { get; set; }
    }
}
