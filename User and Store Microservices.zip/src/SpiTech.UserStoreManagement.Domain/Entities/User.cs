﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("Users")]
    public class User : BaseEntity
    {
        [ExplicitKey]
        public int UserId { get; set; }
        public int Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int? DesignationId { get; set; }
        public int CompanyId { get; set; }
        public int StoreId { get; set; }
        public int ManagerId { get; set; }
        public int RegionId { get; set; }
    }
}
