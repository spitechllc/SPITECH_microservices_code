﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("[Designation]")]
    public class Designation : BaseEntity
    {
        [Key]
        public int DesignationId { get; set; }
        public string Name { get; set; }
    }
}
