﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{

    [Table("Email")]
    public class Email : BaseEntity
    {
        [Key]
        public int EmailId { get; set; }
        public int CategoryTypeLevelId { get; set; }
        public string EmailAddress { get; set; }
        public int? CompanyId { get; set; }
        public int? StoreId { get; set; }
        public int? UserId { get; set; }
        public int? SaleAgentId { get; set; }
        public int? ResellerId { get; set; }
    }
}
