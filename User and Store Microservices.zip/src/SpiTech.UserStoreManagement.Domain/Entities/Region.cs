﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("[Region]")]
    public class Region : BaseEntity
    {
        [Key]
        public int RegionId { get; set; }
        public string RegionName { get; set; }
        public string Zipcode { get; set; }
    }
}
