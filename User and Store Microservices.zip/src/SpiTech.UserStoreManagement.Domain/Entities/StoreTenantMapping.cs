﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("StoreTenantMapping")]
    internal class StoreTenantMapping : BaseEntity
    {
        [Key]
        public int Id { get; set; }
        public int StoreId { get; set; }
        public int TenantId { get; set; }
    }
}
