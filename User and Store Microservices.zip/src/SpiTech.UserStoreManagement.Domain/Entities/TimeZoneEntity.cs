﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("TimeZone")]
    public class TimeZoneEntity : BaseEntity
    {
        [Key]
        public int TimeZoneId { get; set; }
        public string TimeZoneName { get; set; }
    }
}
