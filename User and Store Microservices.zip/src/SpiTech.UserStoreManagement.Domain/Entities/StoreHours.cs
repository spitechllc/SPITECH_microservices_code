﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("StoreHours")]
    public class StoreHours : BaseEntity
    {

        [Key]
        public int StoreHoursId { get; set; }
        public int StoreId { get; set; }
        public int WeekDayId { get; set; }
        public string OpenTime { get; set; }

        public string CloseTime { get; set; }

        public bool Is24Hours { get; set; }

    }
}
