﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("Amenity")]
    public class Amenity : BaseEntity
    {
        [Key]
        public int AmenityId { get; set; }
        public string AmenityName { get; set; }
        public string ImageUrl { get; set; }
    }
}
