﻿using SpiTech.ApplicationCore.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("State")]
    public class State : BaseEntity
    {
        [Key]
        public int StateId { get; set; }
        public int CountryId { get; set; }
        public string StateName { get; set; }
        public string StateCode { get; set; }
    }
}
