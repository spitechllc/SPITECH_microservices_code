﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("StoreGroup")]
    public class StoreGroup : BaseEntity
    {
        [Key]
        public int StoreGroupId { get; set; }
        public string StoreGroupName { get; set; }
    }
}
