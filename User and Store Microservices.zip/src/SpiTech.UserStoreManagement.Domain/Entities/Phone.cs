﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("phone")]
    public class Phone : BaseEntity
    {
        [Key]
        public int PhoneId { get; set; }
        public int CategoryTypeLevelId { get; set; }
        public string CountryCode { get; set; }
        public string PhoneNumber { get; set; }
        public string AreaCode { get; set; }
        public int? CompanyId { get; set; }
        public int? StoreId { get; set; }
        public int? UserId { get; set; }
        public int? SaleAgentId { get; set; }
        public int? ResellerId { get; set; }
    }
}
