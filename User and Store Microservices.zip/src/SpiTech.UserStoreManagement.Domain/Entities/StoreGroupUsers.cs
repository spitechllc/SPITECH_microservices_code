﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("StoreGroupUsers")]
    public class StoreGroupUsers : BaseEntity
    {
        [Key]
        public int StoreGroupUsersId { get; set; }
        public int StoreGroupId { get; set; }
        public int UserId { get; set; }
    }
}
