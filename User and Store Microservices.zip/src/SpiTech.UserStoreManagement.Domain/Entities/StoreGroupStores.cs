﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("StoreGroupStores")]
    public class StoreGroupStores : BaseEntity
    {
        [Key]
        public int StoreGroupStoresId { get; set; }
        public int StoreGroupId { get; set; }
        public int StoreId { get; set; }
    }
}
