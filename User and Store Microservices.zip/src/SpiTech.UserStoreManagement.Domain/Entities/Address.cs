﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("Address")]
    public class Address : BaseEntity
    {
        [Key]
        public int AddressId { get; set; }
        public int CategoryTypeLevelId { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public int CountryId { get; set; }
        public int StateId { get; set; }
        public string City { get; set; }
        public double? Longitude { get; set; }
        public double? Latitude { get; set; }
        public string ZipCode { get; set; }
        public int? CompanyId { get; set; }
        public int? StoreId { get; set; }
        public int? UserId { get; set; }
        public int? SaleAgentId { get; set; }
        public int? ResellerId { get; set; }
    }
}
