﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.UserStoreManagement.Domain.Entities
{
    [Table("TenantMaster")]
    public class StoreTenantMaster : BaseEntity
    {
        [Key]
        public int ID { get; set; }
        public string TenantName { get; set; }
    }
}
