﻿namespace SpiTech.UserStoreManagement.Domain.Enums
{
    public enum EntityCategoryType
    {
        Company = 1,
        Store = 2,
        User = 3,
        SaleAgent = 4,
        Reseller = 5
    }
}
