﻿namespace SpiTech.UserStoreManagement.Domain.Enums
{
    public enum PrimaryCategoryTypeLevel
    {
        UserAddressMain = 1,
        StoreAddressMain = 3,
        CompanyAddressMain = 5,
        UserEmailMain = 7,
        CompanyEmailMain = 9,
        StoreEmailMain = 11,
        UserPhoneMain = 18,
        CompanyPhoneMain = 20,
        StorePhoneMain = 22,
        SaleAgentAddressMain = 24,
        SaleAgentEmailMain = 26,
        SaleAgentPhoneMain = 28
    }
}
