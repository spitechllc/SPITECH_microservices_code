﻿namespace SpiTech.UserStoreManagement.Domain.Enums
{
    public enum EntityStoreCategory
    {
        Test1 = 1,
        Test2 = 2
    }
}
