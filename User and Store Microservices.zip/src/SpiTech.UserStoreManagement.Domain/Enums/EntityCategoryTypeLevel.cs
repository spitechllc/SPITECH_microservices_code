﻿namespace SpiTech.UserStoreManagement.Domain.Enums
{
    public enum EntityCategoryTypeLevel
    {
        UserAddress = 1,
        StoreAddress = 2,
        CompanyAddress = 3,
        UserEmail = 4,
        CompanyEmail = 5,
        StoreEmail = 6,
        UserPhone = 7,
        CompanyPhone = 8,
        StorePhone = 9,
        SaleAgentAddress = 10,
        SaleAgentEmail = 11,
        SaleAgentPhone = 12,
        ResellerAddress = 13,
        ResellerEmail = 14,
        ResellerPhone = 15
    }
}
