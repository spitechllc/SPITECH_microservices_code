﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Domain.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum StoreSortBy
    {
        None = 0,
        StoreId = 1,
        StoreName = 2,
        SiteId = 3,
        CompanyName = 4,
        IsActive = 5,
        LastTransactionDate=6,
        LastHeartBeatTime = 7,
        CreatedOn = 8,
    }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum SaleAgentSortBy
    {
        None = 0,
        SaleAgentId = 1,
        FirstName = 2,
        LastName = 3,
        PhoneNumber = 4,
        EmailAddress = 5,
        IsActive = 6
    }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum StoreUserSortBy
    {
        None = 0,
        UserId = 1,
        FirstName = 2,
        LastName = 3,
        PhoneNumber = 4,
        EmailAddress = 5,
        IsActive = 6,
        Role = 7,
        CompanyId = 8,
        CompanyName = 9
    }
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum ResellerSortBy
    {
        None = 0,
        ResellerId = 1,
        CompanyName = 2,
        FirstName = 3,
        LastName = 4,
        PhoneNumber = 5,
        EmailAddress = 6,
        IsActive =7
    }
}
