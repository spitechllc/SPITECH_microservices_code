﻿namespace SpiTech.UserStoreManagement.Domain.FilterOptions
{
    public class StoreFilter
    {
        public int CountryId { get; set; }
        public int StateId { get; set; }
        public string City { get; set; }
        public string Longitude { get; set; }
        public string Latitude { get; set; }
        public int Distance { get; set; }
        public string ZipCode { get; set; } = string.Empty;
        public int[] AmenitiesId { get; set; }
        public int[] TenantId { get; set; }
    }
}
