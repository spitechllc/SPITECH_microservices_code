﻿using AutoMapper;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
namespace SpiTech.UserStoreManagement.Domain.Mappers
{
    public class StoreCategoryProfile : Profile
    {

        public StoreCategoryProfile()
        {
            CreateMap<StoreCategory, StoreCategoryModel>().ReverseMap();
        }

    }
}
