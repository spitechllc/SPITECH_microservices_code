﻿using AutoMapper;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Domain.Mappers
{
    public class PhoneProfile : Profile
    {
        public PhoneProfile()
        {
            CreateMap<Phone, PhoneModel>().
                ForMember(src => src.Number, opt => opt.MapFrom(dest => dest.PhoneNumber)).ReverseMap();
        }
    }
}
