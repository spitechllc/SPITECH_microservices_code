﻿using AutoMapper;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Domain.Mappers
{
    public class DesignationProfile : Profile
    {
        public DesignationProfile()
        {
            CreateMap<Designation, DesignationModel>().ReverseMap();
        }
    }

}
