﻿using AutoMapper;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Domain.Mappers
{
    public class StateProfile : Profile
    {
        public StateProfile()
        {
            CreateMap<State, StateModel>().ReverseMap();

            CreateMap<State, StateAutoCompleteModel>().ReverseMap();
        }
    }
}
