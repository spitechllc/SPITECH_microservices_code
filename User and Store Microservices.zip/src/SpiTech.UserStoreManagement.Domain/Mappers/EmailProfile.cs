﻿using AutoMapper;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Domain.Mappers
{
    public class EmailProfile : Profile
    {
        public EmailProfile()
        {
            CreateMap<Email, EmailModel>().ForMember(src => src.Email, opt =>
            opt.MapFrom(dest => dest.EmailAddress)).ReverseMap();
        }
    }
}
