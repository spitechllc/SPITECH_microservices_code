﻿using AutoMapper;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Domain.Mappers
{
    public class RoleProfile : Profile
    {
        public RoleProfile()
        {
            CreateMap<RoleModel, SpiTech.Service.Clients.Identity.RoleModel>().ReverseMap();
        }
    }
}
