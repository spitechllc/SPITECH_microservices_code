﻿using AutoMapper;
using SpiTech.Service.Clients.Mppa;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Domain.Mappers
{
    public class StoreProfile : Profile
    {
        public StoreProfile()
        {
            CreateMap<Store, StoreInfoModel>().ReverseMap();
            CreateMap<Store, StoreSearchResult>().ReverseMap();
            CreateMap<Store, StoreAutoCompleteModel>().ReverseMap();
            CreateMap<Store, StoreModelForSummary>().ReverseMap();
            CreateMap<Store, StoreSaleAgentModel>().ReverseMap();
            CreateMap<DashBoardSiteModel, SiteModel>().ReverseMap();
            
        }
    }
}
