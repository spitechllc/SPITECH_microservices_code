﻿using AutoMapper;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Domain.Mappers
{
    public class StoreGroupProfile : Profile
    {
        public StoreGroupProfile()
        {
            CreateMap<StoreGroup, StoreGroupModel>().ReverseMap();
            CreateMap<StoreGroupStores, StoreGroupStoresModel>().ReverseMap();
            CreateMap<StoreGroupUsers, StoreGroupUsersModel>().ReverseMap();
        }
    }
}
