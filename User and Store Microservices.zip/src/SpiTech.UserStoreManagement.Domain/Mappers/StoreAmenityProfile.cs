﻿using AutoMapper;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Domain.Mappers
{
    public class StoreAmenityProfile : Profile
    {
        public StoreAmenityProfile()
        {
            CreateMap<StoreAmenity, StoreAmenityModel>().ReverseMap();
            CreateMap<StoreAmenitySearchResult, StoreAmenityResultModel>().ReverseMap();
            CreateMap<StoreAmenitySearchResult, StoreAmenity>().ReverseMap();
        }
    }
}
