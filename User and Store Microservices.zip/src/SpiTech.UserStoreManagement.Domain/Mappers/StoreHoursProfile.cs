﻿using AutoMapper;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;

namespace SpiTech.UserStoreManagement.Domain.Mappers
{
    public class StoreHoursProfile : Profile
    {
        public StoreHoursProfile()
        {
            CreateMap<StoreHours, StoreHoursModel>().ReverseMap();
            CreateMap<StoreHoursResultModel, StoreHoursResult>().ReverseMap();

        }
    }
}
