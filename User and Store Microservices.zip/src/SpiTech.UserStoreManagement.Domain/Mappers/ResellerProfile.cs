﻿using AutoMapper;
using SpiTech.UserStoreManagement.Domain.Entities;
using SpiTech.UserStoreManagement.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.UserStoreManagement.Domain.Mappers
{
    public class ResellerProfile : Profile
    {
        public ResellerProfile()
        {
            CreateMap<Reseller, ResellerModel>().ReverseMap();
          
        }
    }
}
