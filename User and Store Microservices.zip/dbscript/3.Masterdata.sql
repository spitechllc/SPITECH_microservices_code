SET IDENTITY_INSERT [Amenity] ON 
GO
INSERT [Amenity] ([AmenityId], [AmenityName], [IsActive], [CreatedOn])
VALUES 
(1, N'Mobile Pay', 1, GetUTCDate()),
(2, N'Charging Point', 1, GetUTCDate()),
(3, N'Truck Stop', 1, GetUTCDate());
GO
SET IDENTITY_INSERT [Amenity] OFF
GO


SET IDENTITY_INSERT [CategoryType] ON 
GO
INSERT [CategoryType] ([Id], [Name], [IsActive], [CreatedOn])
VALUES
(1, N'UserAddress', 1, GetUTCDate()),
(2, N'StoreAddress', 1, GetUTCDate()),
(3, N'CompanyAddress', 1, GetUTCDate()),
(4, N'UserEmail', 1, GetUTCDate()),
(5, N'CompanyEmail', 1, GetUTCDate()),
(6, N'StoreEmail', 1, GetUTCDate()),
(7, N'UserPhone', 1, GetUTCDate()),
(8, N'CompanyPhone', 1, GetUTCDate()),
(9, N'StorePhone', 1, GetUTCDate()),
(10, N'SaleAgentAddress', 1, GetUTCDate()),
(11, N'SaleAgentEmail', 1, GetUTCDate()),
(12, N'SaleAgentPhone', 1, GetUTCDate());
GO
SET IDENTITY_INSERT [CategoryType] OFF
GO


SET IDENTITY_INSERT [CategoryTypeLevel] ON 
GO
INSERT [CategoryTypeLevel] ([Id],[Name], [CategoryTypeId], [IsPrimary], [IsActive], [CreatedOn])
VALUES
(1, N'Main', 1, 1, 1, GetUTCDate()),
(2, N'Others', 1, 0, 1, GetUTCDate()),
(3, N'Main', 2, 1, 1, GetUTCDate()),
(4, N'Others', 2, 0, 1, GetUTCDate()),
(5, N'Main', 3, 1, 1, GetUTCDate()),
(6, N'Others', 3, 0, 1, GetUTCDate()),
(7, N'Main', 4, 1, 1, GetUTCDate()),
(8, N'Others', 4, 0, 1, GetUTCDate()),
(9, N'Main', 5, 1, 1, GetUTCDate()),
(10, N'Others', 5, 0, 1, GetUTCDate()),
(11, N'Main', 6, 1, 1, GetUTCDate()),
(12, N'Invoice', 6, 0, 1, GetUTCDate()),
(13, N'EODSettlementSuccess', 6, 0, 1, GetUTCDate()),
(14, N'EODSettlementFail', 6, 0, 1, GetUTCDate()),
(15, N'DailySettlement', 6, 0, 1, GetUTCDate()),
(16, N'MonthlySettlement', 6, 0, 1, GetUTCDate()),
(17, N'SupportTeam', 6, 0, 1, GetUTCDate()),
(18, N'Main', 7, 1, 1, GetUTCDate()),
(19, N'Others', 7, 0, 1, GetUTCDate()),
(20, N'Main', 8, 1, 1, GetUTCDate()),
(21, N'Others', 8, 0, 1, GetUTCDate()),
(22, N'Main', 9, 1, 1, GetUTCDate()),
(23, N'Others', 9, 0, 1, GetUTCDate()),
(24, N'Main', 10, 1, 1, GetUTCDate()),
(25, N'Others', 10, 0, 1, GetUTCDate()),
(26, N'Main', 11, 1, 1, GetUTCDate()),
(27, N'Others', 11, 0, 1, GetUTCDate()),
(28, N'Main', 12, 1, 1, GetUTCDate()),
(29, N'Others', 12, 0, 1, GetUTCDate()),
(30, N'EODSettlementNachaNotification', 6, 1, 1, GetUTCDate()),
(31, N'ACHReturnNachaNotification', 6, 1, 1, GetUTCDate());
GO
SET IDENTITY_INSERT [CategoryTypeLevel] OFF
GO


SET IDENTITY_INSERT [Country] ON 
GO
INSERT [Country] ([CountryId], [CountryName], [CountryCode], [IsActive], [CreatedOn])
VALUES
(1, N'India', N'+91', 1, GetUTCDate()),
(2, N'United States', N'+1', 1, GetUTCDate());
GO
SET IDENTITY_INSERT [Country] OFF
GO


SET IDENTITY_INSERT [Designation] ON 
GO
INSERT [Designation] ([DesignationId], [Name], [IsActive], [CreatedOn])
VALUES
(1, N'Team Lead', 1, GetUTCDate());
GO
SET IDENTITY_INSERT [Designation] OFF
GO


SET IDENTITY_INSERT [Region] ON 
GO
INSERT [Region] ([RegionId], [RegionName], [Zipcode], [IsActive], [CreatedOn])
VALUES
(1, N'Eastern Region', N'324354635', 1, GetUTCDate()),
(2, N'Western Region', N'676575643', 1, GetUTCDate()),
(3, N'Northern Region', N'26767657', 1, GetUTCDate()),
(4, N'Southern Region', N'76475678', 1, GetUTCDate());
GO
SET IDENTITY_INSERT [Region] OFF
GO


SET IDENTITY_INSERT [State] ON 
GO
INSERT [State] ([StateId], [CountryId], [StateName], [StateCode], [IsActive], [CreatedOn])
VALUES
(1, 1, N'Delhi', N'DEL', 1, GetUTCDate()),
(2, 1, N'Uttar Pradesh', N'UP', 1, GetUTCDate()),
(3, 1, N'Haryana', N'HRY', 1, GetUTCDate()),
(4, 2, N'Alabama', N'AL', 1, GetUTCDate()),
(5, 2, N'Alaska', N'AK', 1, GetUTCDate()),
(6, 2, N'Arizona', N'AZ', 1, GetUTCDate()),
(7, 2, N'Arkansas', N'AR', 1, GetUTCDate()),
(8, 2, N'California', N'CA', 1, GetUTCDate()),
(9, 2, N'Colorado', N'CO', 1, GetUTCDate()),
(10, 2, N'Connecticut', N'CT', 1, GetUTCDate()),
(11, 2, N'Delaware', N'DE', 1, GetUTCDate()),
(12, 2, N'Florida', N'FL', 1, GetUTCDate()),
(13, 2, N'Georgia', N'GA', 1, GetUTCDate()),
(14, 2, N'Hawaii', N'HI', 1, GetUTCDate()),
(15, 2, N'Idaho', N'ID', 1, GetUTCDate()),
(16, 2, N'Illinois', N'IL', 1, GetUTCDate()),
(17, 2, N'Indiana', N'IN', 1, GetUTCDate()),
(18, 2, N'Iowa', N'IA', 1, GetUTCDate()),
(19, 2, N'Kansas', N'KS', 1, GetUTCDate()),
(20, 2, N'Kentucky', N'KY', 1, GetUTCDate()),
(21, 2, N'Louisiana', N'LA', 1, GetUTCDate()),
(22, 2, N'Maine', N'ME', 1, GetUTCDate()),
(23, 2, N'Maryland', N'MD', 1, GetUTCDate()),
(24, 2, N'Massachusetts', N'MA', 1, GetUTCDate()),
(25, 2, N'Michigan', N'MI', 1, GetUTCDate()),
(26, 2, N'Minnesota', N'MN', 1, GetUTCDate()),
(27, 2, N'Mississippi', N'MS', 1, GetUTCDate()),
(28, 2, N'Missouri', N'MO', 1, GetUTCDate()),
(29, 2, N'Montana', N'MT', 1, GetUTCDate()),
(30, 2, N'Nebraska', N'NE', 1, GetUTCDate()),
(31, 2, N'Nevada', N'NV', 1, GetUTCDate()),
(32, 2, N'New Hampshire', N'NH', 1, GetUTCDate()),
(33, 2, N'New Jersey', N'NJ', 1, GetUTCDate()),
(34, 2, N'New Mexico', N'NM', 1, GetUTCDate()),
(35, 2, N'New York', N'NY', 1, GetUTCDate()),
(36, 2, N'North Carolina', N'NC', 1, GetUTCDate()),
(37, 2, N'North Dakota', N'ND', 1, GetUTCDate()),
(38, 2, N'Ohio', N'OH', 1, GetUTCDate()),
(39, 2, N'Oklahoma', N'OK', 1, GetUTCDate()),
(40, 2, N'Oregon', N'OR', 1, GetUTCDate()),
(41, 2, N'Pennsylvania', N'PA', 1, GetUTCDate()),
(42, 2, N'Rhode Island', N'RI', 1, GetUTCDate()),
(43, 2, N'South Carolina', N'SC', 1, GetUTCDate()),
(44, 2, N'South Dakota', N'SD', 1, GetUTCDate()),
(45, 2, N'Tennessee', N'TN', 1, GetUTCDate()),
(46, 2, N'Texas', N'TX', 1, GetUTCDate()),
(47, 2, N'Utah', N'UT', 1, GetUTCDate()),
(48, 2, N'Vermont', N'VT', 1, GetUTCDate()),
(49, 2, N'Virginia', N'VA', 1, GetUTCDate()),
(50, 2, N'Washington', N'WA', 1, GetUTCDate()),
(51, 2, N'West Virginia', N'WV', 1, GetUTCDate()),
(52, 2, N'Wisconsin', N'WI', 1, GetUTCDate()),
(53, 2, N'Wyoming', N'WY', 1, GetUTCDate());
GO
SET IDENTITY_INSERT [State] OFF
GO


SET IDENTITY_INSERT [Title] ON 
GO
INSERT [Title] ([TitleId], [TitleName], [IsActive], [CreatedOn])
VALUES 
(1, N'Mr.', 1, GetUTCDate()),
(2, N'Mrs.', 1, GetUTCDate()),
(3, N'Ms.', 1, GetUTCDate());
GO
SET IDENTITY_INSERT [Title] OFF
GO


SET IDENTITY_INSERT [WeekDays] ON 
GO
INSERT [WeekDays] ([WeekDayId], [Name])
VALUES
(1, N'Monday'),
(2, N'Tuesday'),
(3, N'Wednesday'),
(4, N'Thursday'),
(5, N'Friday'),
(6, N'Saturday'),
(7, N'Sunday');
GO
SET IDENTITY_INSERT [WeekDays] OFF
GO


SET IDENTITY_INSERT [dbo].[TimeZone] ON 
GO
INSERT [dbo].[TimeZone] ([TimeZoneId], [TimeZoneName], [IsActive], [CreatedOn])
VALUES
(1, N'Central Standard Time', 1, GetUTCDate()),
(2, N'Mountain Standard Time', 1, GetUTCDate()),
(3, N'Eastern Standard Time', 1, GetUTCDate()),
(4, N'Pacific Standard Time', 1, GetUTCDate()),
(5, N'Alaska Standard Time', 1, GetUTCDate()),
(6, N'Hawaii-Aleutian Standard Time', 1, GetUTCDate()),
(7, N'Newfoundland Standard Time', 1, GetUTCDate()),
(8, N'Atlantic Standard Time', 1, GetUTCDate());
GO
SET IDENTITY_INSERT [dbo].[TimeZone] OFF
GO


SET IDENTITY_INSERT[dbo].[PosSystem] ON 
GO
INSERT [dbo].[PosSystem] ([PosId], [PosName], [IsActive], [CreatedOn])
VALUES 
(1, N'Gilbarco-Passport', 1, GetUTCDate()),
(2, N'Verifone-Commander', 1, GetUTCDate()),
(3, N'Radiant', 1, GetUTCDate());
GO
SET IDENTITY_INSERT [PosSystem] OFF
GO

SET IDENTITY_INSERT [StoreCategory] ON 
GO
INSERT [StoreCategory] ([Id], [Name], [IsActive], [CreatedOn])
VALUES 
(1, N'Marina', 1, GetUTCDate()),
(2, N'Gas Station', 1, GetUTCDate());
GO
SET IDENTITY_INSERT [StoreCategory] OFF
GO