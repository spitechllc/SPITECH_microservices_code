GO

CREATE proc [dbo].[InsertDummyAddressData]
(
@StoreId int=0,
@MaxStoreId int=0
)
as
Declare 
@MaxAddressId int=0,
@AddressId int=0, 
@CategoryTypeLevelId int=0, 
@AddressLine1 varchar(4000)='', 
@AddressLine2 varchar(4000)='',
@CountryId int=0, 
@Stateid int=0, 
@City varchar(500)='',
@ZipCode varchar(500)='', 
@Longitude varchar(500)='', 
@Latitude varchar(500)='', 
@Userid int=0, 
@CompanyId int=0,
@IsActive bit=1, 
@CreatedOn datetime =null,
@CreatedBy int=0,
@UpdatedOn datetime =null,
@UpdatedBy int=0

DECLARE db_cursor_Address CURSOR static  FOR 

select [AddressId], [CategoryTypeLevelId], [AddressLine1], [AddressLine2], [CountryId], [Stateid], [City], [ZipCode], ([Longitude]-0.0100000), ([Latitude]+0.0100000), [Userid], [CompanyId], [StoreId], [IsActive],GetDate() as  [CreatedOn], [CreatedBy], GetDate() as [UpdatedOn], [UpdatedBy] from [Address] where StoreId=@StoreId

OPEN db_cursor_Address  
FETCH NEXT FROM db_cursor_Address INTO @AddressId, @CategoryTypeLevelId, @AddressLine1, @AddressLine2, @CountryId, @Stateid, @City, @ZipCode, @Longitude, @Latitude, @Userid, @CompanyId, @StoreId, @IsActive, @CreatedOn, @CreatedBy, @UpdatedOn, @UpdatedBy

WHILE @@FETCH_STATUS = 0  
BEGIN  

 set @MaxAddressId=(select Max([AddressId])+1 from [Address])
	 SET IDENTITY_INSERT dbo.[Address] ON 

	 insert into [dbo].[Address] ([AddressId], [CategoryTypeLevelId], [AddressLine1], [AddressLine2], [CountryId], [Stateid], [City], [ZipCode], [Longitude], [Latitude], [Userid], [CompanyId], [StoreId], [IsActive], [CreatedOn], [CreatedBy], [UpdatedOn], [UpdatedBy])
	 values(@MaxAddressId, @CategoryTypeLevelId, @AddressLine1, @AddressLine2, @CountryId, @Stateid, @City, @ZipCode, @Longitude, @Latitude, @Userid, @CompanyId, @MaxStoreId, @IsActive, @CreatedOn, @CreatedBy, @UpdatedOn, @UpdatedBy)
	 SET IDENTITY_INSERT dbo.[Address] OFF 

FETCH NEXT FROM db_cursor_Address INTO @AddressId, @CategoryTypeLevelId, @AddressLine1, @AddressLine2, @CountryId, @Stateid, @City, @ZipCode, @Longitude, @Latitude, @Userid, @CompanyId, @StoreId, @IsActive, @CreatedOn, @CreatedBy, @UpdatedOn, @UpdatedBy   
END 
CLOSE db_cursor_Address  
DEALLOCATE db_cursor_Address 
GO

CREATE proc [dbo].[InsertDummyEmailData]
(
@StoreId int=0,
@MaxStoreId int=0
)
as
Declare 
@MaxEmailId int=0,
@EmailId int=0,
@CategoryTypeLevelId int=0,
@EmailAddress varchar(100)='',
@Userid int=0,
@CompanyId int=0,
@IsActive bit = 0,
@CreatedOn datetime = null,
@CreatedBy int=0,
@UpdatedOn datetime = null,
@UpdatedBy int=0

DECLARE db_cursor_Email CURSOR static  FOR 

select [EmailId], [CategoryTypeLevelId], [EmailAddress], [Userid], [CompanyId], [StoreId], [IsActive], GetDate() as  [CreatedOn], [CreatedBy], GetDate() as [UpdatedOn], [UpdatedBy] from [Email] where StoreId=@StoreId

OPEN db_cursor_Email  
FETCH NEXT FROM db_cursor_Email INTO @EmailId, @CategoryTypeLevelId, @EmailAddress, @Userid, @CompanyId, @StoreId, @IsActive, @CreatedOn, @CreatedBy, @UpdatedOn, @UpdatedBy

WHILE @@FETCH_STATUS = 0  
BEGIN  

  set @MaxEmailId=(select Max([EmailId])+1 from [Email])
	 SET IDENTITY_INSERT dbo.[Email] ON 

	 insert into [dbo].[Email]([EmailId], [CategoryTypeLevelId], [EmailAddress], [Userid], [CompanyId], [StoreId], [IsActive], [CreatedOn], [CreatedBy], [UpdatedOn], [UpdatedBy]) values(@MaxEmailId, @CategoryTypeLevelId, @EmailAddress, @Userid, @CompanyId, @MaxStoreId, @IsActive, @CreatedOn, @CreatedBy, @UpdatedOn, @UpdatedBy)

	 SET IDENTITY_INSERT dbo.[Email] OFF

FETCH NEXT FROM db_cursor_Email INTO @EmailId, @CategoryTypeLevelId, @EmailAddress, @Userid, @CompanyId, @StoreId, @IsActive, @CreatedOn, @CreatedBy, @UpdatedOn, @UpdatedBy
END 
CLOSE db_cursor_Email  
DEALLOCATE db_cursor_Email 
GO

CREATE proc [dbo].[InsertDummyPhoneData]
(
@StoreId int=0,
@MaxStoreId int=0
)
as
Declare 
@MaxPhoneId int=0,
@PhoneId int=0,
@CategoryTypeLevelId int=0,
@CountryCode varchar(20)='',
@PhoneNumber varchar(20)='',
@AreaCode varchar(50)='',
@Userid int=0,
@CompanyId int=0,
@IsActive bit=1,
@CreatedOn datetime =null,
@CreatedBy int=0,
@UpdatedOn datetime =null,
@UpdatedBy int=0

DECLARE db_cursor_Phone CURSOR static  FOR 

select [PhoneId], [CategoryTypeLevelId], [CountryCode], [PhoneNumber], [AreaCode], [Userid], [CompanyId], [StoreId], [IsActive], GetDate() as  [CreatedOn], [CreatedBy], GetDate() as [UpdatedOn], [UpdatedBy] from [Phone] where StoreId=@StoreId

OPEN db_cursor_Phone  
FETCH NEXT FROM db_cursor_Phone INTO @PhoneId, @CategoryTypeLevelId, @CountryCode, @PhoneNumber, @AreaCode, @Userid, @CompanyId, @StoreId, @IsActive, @CreatedOn, @CreatedBy, @UpdatedOn, @UpdatedBy

WHILE @@FETCH_STATUS = 0  
BEGIN  

 set @MaxPhoneId=(select Max([PhoneId])+1 from [Phone])
	 SET IDENTITY_INSERT dbo.[Phone] ON 

	 insert into [Phone]([PhoneId], [CategoryTypeLevelId], [CountryCode], [PhoneNumber], [AreaCode], [Userid], [CompanyId], [StoreId], [IsActive], [CreatedOn], [CreatedBy], [UpdatedOn], [UpdatedBy]) values(@MaxPhoneId, @CategoryTypeLevelId, @CountryCode, @PhoneNumber, @AreaCode, @Userid, @CompanyId, @MaxStoreId, @IsActive, @CreatedOn, @CreatedBy, @UpdatedOn, @UpdatedBy)

	 SET IDENTITY_INSERT dbo.[Phone] OFF

FETCH NEXT FROM db_cursor_Phone INTO @PhoneId, @CategoryTypeLevelId, @CountryCode, @PhoneNumber, @AreaCode, @Userid, @CompanyId, @StoreId, @IsActive, @CreatedOn, @CreatedBy, @UpdatedOn, @UpdatedBy 
END 
CLOSE db_cursor_Phone  
DEALLOCATE db_cursor_Phone 
GO

CREATE proc [dbo].[InsertDummyStoreData]
as

declare @totalcount int=0,@StoreId int=0,
@StoreName varchar(200)='',
@SiteId varchar(50)='',
@StoreUrl varchar(1000)='',
@MangerId int=0,
@RegionId int=0,
@RegionalManagerId int=0,
@PosId int=0,
@PosName varchar(50)='',
@Description varchar(1000)='',
@Note varchar(1000)='',
@StoreImage varchar(500)='',
@TimeZoneId int=0,
@CompanyId int=0,
@EnableBilling bit=0,
@ConsentCashReward bit=0,
@IsMasterStore bit=0,
@IsActive bit=0,
@CreatedOn datetime =null,
@CreatedBy int=0,
@UpdatedOn datetime =null,
@UpdatedBy int=0, 
@MaxStoreId int=0,
@MaxAddressId int=0,
@MaxPhoneId int=0,
@MaxEmailId int=0,
@MaxAuthorizeAmount decimal=0
DECLARE db_cursor_Store CURSOR static  FOR 

select Top 30  [StoreId], [StoreName], [SiteId], [StoreUrl], [MangerId], [RegionId], [RegionalManagerId], [PosId], [PosName], [Description], [Note], [StoreImage], [TimeZoneId], [CompanyId], [MaxAuthorizeAmount], [EnableBilling], [ConsentCashReward], [IsMasterStore], [IsActive], GetDate() as [CreatedOn], [CreatedBy], GetDate() as [UpdatedOn], [UpdatedBy] from Store where CompanyId<>5 order by StoreId Desc

OPEN db_cursor_Store  
FETCH NEXT FROM db_cursor_Store INTO @StoreId, @StoreName, @SiteId, @StoreUrl, @MangerId, @RegionId, @RegionalManagerId, @PosId, @PosName, @Description, @Note, @StoreImage, @TimeZoneId, @CompanyId, @MaxAuthorizeAmount, @EnableBilling, @ConsentCashReward, @IsMasterStore, @IsActive, @CreatedOn, @CreatedBy, @UpdatedOn, @UpdatedBy  

WHILE @@FETCH_STATUS = 0  
BEGIN  
		

     set @MaxStoreId=(select Max(StoreId)+1 from Store)
	 SET IDENTITY_INSERT dbo.Store ON 
	 insert into Store([StoreId], [StoreName], [SiteId], [StoreUrl], [MangerId], [RegionId], [RegionalManagerId], [PosId], [PosName], [Description], [Note], [StoreImage], [TimeZoneId], [CompanyId], [MaxAuthorizeAmount], [EnableBilling], [ConsentCashReward], [IsMasterStore], [IsActive], [CreatedOn], [CreatedBy], [UpdatedOn], [UpdatedBy])values(@MaxStoreId, @StoreName, @SiteId, @StoreUrl, @MangerId, @RegionId, @RegionalManagerId, @PosId, @PosName, @Description, @Note, @StoreImage, @TimeZoneId, @CompanyId, @MaxAuthorizeAmount, @EnableBilling, @ConsentCashReward, @IsMasterStore, @IsActive, @CreatedOn, @CreatedBy, @UpdatedOn, @UpdatedBy )
	   SET IDENTITY_INSERT dbo.[Store] OFF 

	Exec [dbo].[InsertDummyAddressData] @StoreId,@MaxStoreId

	Exec [dbo].InsertDummyPhoneData @StoreId,@MaxStoreId

	Exec [dbo].InsertDummyEmailData @StoreId,@MaxStoreId
	
      FETCH NEXT FROM db_cursor_Store INTO @StoreId, @StoreName, @SiteId, @StoreUrl, @MangerId, @RegionId, @RegionalManagerId, @PosId, @PosName, @Description, @Note, @StoreImage, @TimeZoneId, @CompanyId, @MaxAuthorizeAmount, @EnableBilling, @ConsentCashReward, @IsMasterStore, @IsActive, @CreatedOn, @CreatedBy, @UpdatedOn, @UpdatedBy   
END 
CLOSE db_cursor_Store  
DEALLOCATE db_cursor_Store 

GO
