USE [master]
IF NOT EXISTS(SELECT * FROM sys.databases WHERE name = 'SpiTech_Store')
  BEGIN
    CREATE DATABASE [SpiTech_Store]
 END
GO
       
 USE [SpiTech_Store]
    
GO

