/*IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Address_CompanyId')   
    DROP INDEX IX_Address_CompanyId ON [dbo].[Address];   
GO  
  
CREATE NONCLUSTERED INDEX IX_Address_CompanyId   
    ON [dbo].[Address] (CompanyId);   
GO  

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Address_StoreId')   
    DROP INDEX IX_Address_StoreId ON [dbo].[Address];   
GO  
  
CREATE NONCLUSTERED INDEX IX_Address_StoreId   
    ON [dbo].[Address] (StoreId);   
GO 

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Address_UserId')   
    DROP INDEX IX_Address_UserId ON [dbo].[Address];   
GO  
  
CREATE NONCLUSTERED INDEX IX_Address_UserId   
    ON [dbo].[Address] (Userid);   
GO 

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Email_CompanyId')   
    DROP INDEX IX_Email_CompanyId ON [dbo].[Email];   
GO  
  
CREATE NONCLUSTERED INDEX IX_Email_CompanyId   
    ON [dbo].[Email] (CompanyId);   
GO  

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Email_StoreId')   
    DROP INDEX IX_Email_StoreId ON [dbo].[Email];   
GO  
  
CREATE NONCLUSTERED INDEX IX_Email_StoreId   
    ON [dbo].[Email] (StoreId);   
GO 

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Email_UserId')   
    DROP INDEX IX_Email_UserId ON [dbo].[Email];   
GO  
  
CREATE NONCLUSTERED INDEX IX_Email_UserId   
    ON [dbo].[Email] (Userid);   
GO 

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Phone_CompanyId')   
    DROP INDEX IX_Phone_CompanyId ON [dbo].[Phone];   
GO  
  
CREATE NONCLUSTERED INDEX IX_Phone_CompanyId   
    ON [dbo].[Phone] (CompanyId);   
GO  

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Phone_StoreId')   
    DROP INDEX IX_Phone_StoreId ON [dbo].[Phone];   
GO  
  
CREATE NONCLUSTERED INDEX IX_Phone_StoreId   
    ON [dbo].[Phone] (StoreId);   
GO 

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Phone_UserId')   
    DROP INDEX IX_Phone_UserId ON [dbo].[Phone];   
GO  
  
CREATE NONCLUSTERED INDEX IX_Phone_UserId   
    ON [dbo].[Phone] (Userid);   
GO 


IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Store_CompanyId')   
    DROP INDEX IX_Store_CompanyId ON [dbo].[Store];   
GO  
  
CREATE NONCLUSTERED INDEX IX_Store_CompanyId   
    ON [dbo].[Store] (CompanyId);   
GO  

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Store_SiteId')   
    DROP INDEX IX_Store_SiteId ON [dbo].[Store];   
GO  
  
CREATE NONCLUSTERED INDEX IX_Store_SiteId   
    ON [dbo].[Store] (SiteId);   
GO 


IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_StoreAmenity_StoreId')   
    DROP INDEX IX_StoreAmenity_StoreId ON [dbo].[StoreAmenity];   
GO  
  
CREATE NONCLUSTERED INDEX IX_StoreAmenity_StoreId   
    ON [dbo].[StoreAmenity] (StoreId);   
GO 


IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_StoreBillingFee_StoreId')   
    DROP INDEX IX_StoreBillingFee_StoreId ON [dbo].[StoreBillingFee];   
GO  
  
CREATE NONCLUSTERED INDEX IX_StoreBillingFee_StoreId   
    ON [dbo].[StoreBillingFee] (StoreId);   
GO  

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_StoreHours_StoreId')   
    DROP INDEX IX_StoreHours_StoreId ON [dbo].[StoreHours];   
GO  
  
CREATE NONCLUSTERED INDEX IX_StoreHours_StoreId   
    ON [dbo].[StoreHours] (StoreId);   
GO 


IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Users_StoreId')   
    DROP INDEX IX_Users_StoreId ON [dbo].[Users];   
GO  
  
CREATE NONCLUSTERED INDEX IX_Users_StoreId   
    ON [dbo].[Users] (StoreId);   
GO  

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Users_CompanyId')   
    DROP INDEX IX_Users_CompanyId ON [dbo].[Users];   
GO  
  
CREATE NONCLUSTERED INDEX IX_Users_Company   
    ON [dbo].[Users] (CompanyId);   
GO 
*/