
CREATE FUNCTION [dbo].[fn_split_string] (
@InputString VARCHAR(MAX),
@Delimiter VARCHAR(50)
)
RETURNS @Items TABLE (
Item VARCHAR(200)
)
AS
BEGIN
	IF @Delimiter = ' '
	BEGIN
		SET @Delimiter = ','
		SET @InputString = REPLACE(@InputString, ' ', @Delimiter)
	END

	IF (@Delimiter IS NULL OR @Delimiter = '')
	SET @Delimiter = ','

	DECLARE @Item VARCHAR(8000)
	DECLARE @ItemList VARCHAR(8000)
	DECLARE @DelimIndex INT

	SET @ItemList = @InputString
	SET @DelimIndex = CHARINDEX(@Delimiter, @ItemList, 0)

	WHILE (@DelimIndex != 0)
		BEGIN
			SET @Item = SUBSTRING(@ItemList, 0, @DelimIndex)
			INSERT INTO @Items VALUES (@Item)


			SET @ItemList = SUBSTRING(@ItemList, @DelimIndex+1, LEN(@ItemList)-@DelimIndex)
			SET @DelimIndex = CHARINDEX(@Delimiter, @ItemList, 0)
		END

	IF @Item IS NOT NULL
	BEGIN
		SET @Item = @ItemList
		INSERT INTO @Items VALUES (@Item)
	END

	ELSE INSERT INTO @Items VALUES (@InputString)

	RETURN

END

GO


/*
Exec GetStore 
  @Latitude=N'35.4675602'
 ,@Longitude=N'-97.5164276'
 ,@Distance=250
 ,@City='' 
 ,@StateId=0 
 ,@CountryId=0
 ,@Zipcode='' 
 ,@SkipRow=0 
 ,@PageSize=1000
 ,@AmenitiesId='2'
*/


Create Procedure [dbo].[GetStore]
(
  @Latitude varchar(25) 
 ,@Longitude varchar(25) 
 ,@Distance int =250
 ,@City varchar(50) =''
 ,@StateId int =0
 ,@CountryId int =0
 ,@Zipcode varchar(6)  =''
 ,@SkipRow int = 0
 ,@PageSize int  =10
 ,@AmenitiesId varchar(50)=''
)
AS
BEGIN


DECLARE  @GEO GEOGRAPHY
SET @GEO= geography::Point(@Latitude, @Longitude, 4326)

if(@AmenitiesId is null or @AmenitiesId ='')
begin
 SELECT 
  S.*
 ,LEFT(CONVERT(VARCHAR,(@GEO.STDistance(geography::Point(ISNULL(a.Latitude,0), ISNULL(a.Longitude,0), 4326)))/1000),5) As Distance
 ,Count (1) over() as TotalRecord
FROM store S
inner join [Address] a on a.StoreId = s.StoreId
inner join [CategoryTypeLevel] L on L.Id =a.CategoryTypeLevelId 
and L.IsPrimary =1  ---main address

WHERE S.IsActive=1 and (@GEO.STDistance(geography::Point(ISNULL(a.Latitude,0), ISNULL(a.Longitude,0), 4326)))/1000 < @Distance
AND  (a.City = @City OR isnull(@City,'') ='' )
AND (a.Stateid = @StateId OR @StateId = 0)
AND (a.CountryId = @CountryId OR @CountryId =0)
AND (a.isActive=1)
--AND ( a.ZipCode =@Zipcode OR @Zipcode='')
ORDER BY Distance ASC 
--OFFSET @SkipRow ROWS FETCH  NEXT @PageSize ROWS ONLY

end
else
begin
declare @AmenityCount int=0
 select @AmenityCount=count(*) from fn_split_string( @AmenitiesId,',')
 SELECT 
  S.*
 ,LEFT(CONVERT(VARCHAR,(@GEO.STDistance(geography::Point(ISNULL(a.Latitude,0), ISNULL(a.Longitude,0), 4326)))/1000),5) As Distance
 ,Count (1) over() as TotalRecord
FROM store S
inner join [Address] a on a.StoreId = s.StoreId
inner join [CategoryTypeLevel] L on L.Id =a.CategoryTypeLevelId 
and L.IsPrimary =1  ---main address

WHERE S.IsActive=1 and (@GEO.STDistance(geography::Point(ISNULL(a.Latitude,0), ISNULL(a.Longitude,0), 4326)))/1000 < @Distance
AND  (a.City = @City OR isnull(@City,'') ='' )
AND (a.Stateid = @StateId OR @StateId = 0)
AND (a.CountryId = @CountryId OR @CountryId =0)
AND (a.isActive=1)
--AND ( a.ZipCode =@Zipcode OR @Zipcode='')
AND (S.storeid in(select storeid from [StoreAmenity] m   join  (select * from fn_split_string( @AmenitiesId,',')) t on m.AmenityId=t.Item where m.IsActive=1 group by storeid having count(1)>=@AmenityCount) )

ORDER BY Distance ASC 
--OFFSET @SkipRow ROWS FETCH  NEXT @PageSize ROWS ONLY
end
END


GO

CREATE Procedure [dbo].[StoreSearch]
(
  @Latitude varchar(25) 
 ,@Longitude varchar(25) 
 ,@Distance int
 ,@AmenityIds varchar(50)
 ,@SkipRow int
 ,@PageSize int
)
AS
BEGIN

IF(@PageSize > 0)
	BEGIN
		DECLARE  @GEO GEOGRAPHY;
		
		SET @GEO= geography::Point(@Latitude, @Longitude, 4326);
		
		SELECT 
		  S.StoreId, S.StoreName, S.SiteId, S.MaxAuthorizeAmount, ISNULL(S.ConsentCashReward,0) As ConsentCashReward, a.AddressLine1, a.AddressLine2,a.Longitude,a.Latitude, a.ZipCode 	
		, LEFT(CONVERT(VARCHAR,(@GEO.STDistance(geography::Point(ISNULL(a.Latitude,0), ISNULL(a.Longitude,0), 4326)))/1000),5) As Distance
		, Count (1) over() as TotalRecord, S.DisableEod, S.DisableBilling, S.EnableACHLoyalty, S.EnableCardLoyalty, S.LoyaltyProgramId
		FROM STORE S
		inner join [Address] a on a.StoreId = s.StoreId
		inner join [CategoryTypeLevel] L on L.Id = a.CategoryTypeLevelId 
		AND L.IsPrimary =1  ---main address
		WHERE S.IsActive=1 
		--AND (@GEO.STDistance(geography::Point(ISNULL(a.Latitude,0), ISNULL(a.Longitude,0), 4326)))/1000 < @Distance
		AND (a.isActive=1)
		AND (@AmenityIds IS NULL OR @AmenityIds ='' OR (S.storeid IN(SELECT storeid FROM [StoreAmenity] m  WHERE m.AmenityId IN (SELECT * FROM fn_split_string(@AmenityIds,',')))))
		ORDER BY Distance DESC 
		OFFSET @SkipRow ROWS FETCH  NEXT @PageSize ROWS ONLY;
	END
ELSE
	BEGIN
		SELECT 
		  S.StoreId, S.StoreName, S.SiteId, S.MaxAuthorizeAmount, ISNULL(S.ConsentCashReward,0) As ConsentCashReward, a.AddressLine1, a.AddressLine2,a.Longitude,a.Latitude, a.ZipCode 	
		, 0 As Distance
		, 0 as TotalRecord, S.DisableEod, S.DisableBilling, S.EnableACHLoyalty, S.EnableCardLoyalty, S.LoyaltyProgramId
		FROM STORE S
		inner join [Address] a on a.StoreId = s.StoreId
		inner join [CategoryTypeLevel] L on L.Id = a.CategoryTypeLevelId 
		AND L.IsPrimary =1  ---main address
		WHERE S.IsActive=1 
		--AND (@GEO.STDistance(geography::Point(ISNULL(a.Latitude,0), ISNULL(a.Longitude,0), 4326)))/1000 < @Distance
		AND (a.isActive=1)
		AND (@AmenityIds IS NULL OR @AmenityIds ='' OR (S.storeid IN(SELECT storeid FROM [StoreAmenity] m  WHERE m.AmenityId IN (SELECT * FROM fn_split_string(@AmenityIds,',')))));
	END
END

GO
CREATE TYPE [dbo].[UdtIntKeys] AS TABLE(
	[KeyValue] int NOT NULL,
	PRIMARY KEY CLUSTERED 
(
	[KeyValue] ASC
)WITH (IGNORE_DUP_KEY = OFF)
)
GO



