---------------------------------02/11/2022-Begin-------------------------------------------------


CREATE TABLE [dbo].[Reseller]
(
	  [ResellerId] INT NOT NULL IDENTITY(1,1)
	, [CompanyName] VARCHAR(100) NULL
	, [FirstName] VARCHAR(100) NULL
	, [LastName] VARCHAR(100) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Reseller] PRIMARY KEY ([ResellerId] ASC)
)

alter table [dbo].[Address] add [ResellerId] INT NULL
alter table [dbo].[Email] add [ResellerId] INT NULL
alter table [dbo].[Phone] add [ResellerId] INT NULL
alter table [dbo].[Company] add [ResellerId] INT NULL
alter table [dbo].[Company] add [OwnerId] INT NULL
alter table [dbo].[Store] add [ResellerId] INT NULL

GO
update company set ownerid=userid from [Users] U
INNER JOIN  Company C ON U.CompanyId= C.Id;


----------------------------------02/11/2022-End---------------------------------------------

----------------------------------14/11/2022-Begin---------------------------------------------

Alter table [dbo].[Store] add [EnableACHLoyalty] BIT NOT NULL DEFAULT((0))
GO
Alter table [dbo].[Store] add [EnableCardLoyalty] BIT NOT NULL DEFAULT((0))

GO
Alter table [dbo].[Store] add [LoyaltyProgramId] VARCHAR(100) NULL

GO

Alter Procedure [dbo].[StoreSearch]
(
  @Latitude varchar(25) 
 ,@Longitude varchar(25) 
 ,@Distance int
 ,@AmenityIds varchar(50)
 ,@SkipRow int
 ,@PageSize int
)
AS
BEGIN

IF(@PageSize > 0)
	BEGIN
		DECLARE  @GEO GEOGRAPHY;
		
		SET @GEO= geography::Point(@Latitude, @Longitude, 4326);
		
		SELECT 
		  S.StoreId, S.StoreName, S.SiteId, S.MaxAuthorizeAmount, ISNULL(S.ConsentCashReward,0) As ConsentCashReward, a.AddressLine1, a.AddressLine2,a.Longitude,a.Latitude, a.ZipCode 	
		, LEFT(CONVERT(VARCHAR,(@GEO.STDistance(geography::Point(ISNULL(a.Latitude,0), ISNULL(a.Longitude,0), 4326)))/1000),5) As Distance
		, Count (1) over() as TotalRecord, S.DisableEod, S.DisableBilling, S.EnableACHLoyalty, S.EnableCardLoyalty, S.LoyaltyProgramId
		FROM STORE S
		inner join [Address] a on a.StoreId = s.StoreId
		inner join [CategoryTypeLevel] L on L.Id = a.CategoryTypeLevelId 
		AND L.IsPrimary =1  ---main address
		WHERE S.IsActive=1 
		--AND (@GEO.STDistance(geography::Point(ISNULL(a.Latitude,0), ISNULL(a.Longitude,0), 4326)))/1000 < @Distance
		AND (a.isActive=1)
		AND (@AmenityIds IS NULL OR @AmenityIds ='' OR (S.storeid IN(SELECT storeid FROM [StoreAmenity] m  WHERE m.AmenityId IN (SELECT * FROM fn_split_string(@AmenityIds,',')))))
		ORDER BY Distance DESC 
		OFFSET @SkipRow ROWS FETCH  NEXT @PageSize ROWS ONLY;
	END
ELSE
	BEGIN
		SELECT 
		  S.StoreId, S.StoreName, S.SiteId, S.MaxAuthorizeAmount, ISNULL(S.ConsentCashReward,0) As ConsentCashReward, a.AddressLine1, a.AddressLine2,a.Longitude,a.Latitude, a.ZipCode 	
		, 0 As Distance
		, 0 as TotalRecord, S.DisableEod, S.DisableBilling, S.EnableACHLoyalty, S.EnableCardLoyalty, S.LoyaltyProgramId
		FROM STORE S
		inner join [Address] a on a.StoreId = s.StoreId
		inner join [CategoryTypeLevel] L on L.Id = a.CategoryTypeLevelId 
		AND L.IsPrimary =1  ---main address
		WHERE S.IsActive=1 
		--AND (@GEO.STDistance(geography::Point(ISNULL(a.Latitude,0), ISNULL(a.Longitude,0), 4326)))/1000 < @Distance
		AND (a.isActive=1)
		AND (@AmenityIds IS NULL OR @AmenityIds ='' OR (S.storeid IN(SELECT storeid FROM [StoreAmenity] m  WHERE m.AmenityId IN (SELECT * FROM fn_split_string(@AmenityIds,',')))));
	END
END



----------------------------------14/11/2022-End---------------------------------------------
------------start script 03-feb-2023---------------------------
CREATE TABLE [dbo].[StoreCategory]
(
	  [Id] INT NOT NULL IDENTITY(1,1)
	, [Name] VARCHAR(100) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_StoreCategory] PRIMARY KEY ([Id] ASC)
)

alter table [dbo].[STORE] add StoreCategoryId INT NULL

SET IDENTITY_INSERT [StoreCategory] ON 
GO
INSERT [StoreCategory] ([Id], [Name], [IsActive], [CreatedOn])
VALUES 
(1, N'Marina', 1, GetUTCDate()),
(2, N'Gas Station', 1, GetUTCDate());
GO
SET IDENTITY_INSERT [StoreCategory] OFF
GO


------------end script 03-feb-2023------------



----------------start script 24 apr 23--------------------------
alter table [dbo].[Amenity] add AmenityNameSpanish VARCHAR(150) NULL
----------------end script 24 apr 23--------------------------

----------------start script 26 june 23--------------------------
CREATE TABLE [dbo].[StoreGroup]
(
	  [StoreGroupId] INT NOT NULL IDENTITY(1,1)
	, [StoreGroupName] VARCHAR(200) NULL
	, [IsActive] BIT NOT NULL CONSTRAINT DF_StoreGroup_IsActive DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL CONSTRAINT DF_StoreGroup_CreatedOn DEFAULT(getutcdate())
	, [CreatedBy] NVARCHAR(256) NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] NVARCHAR(256) NULL
	, [TenantId] [int] NOT NULL CONSTRAINT DF_StoreGroup_TenantId DEFAULT(0)
	, [ClientId] [varchar](50) NULL
	, CONSTRAINT [PK_StoreGroup] PRIMARY KEY ([StoreGroupId] ASC)
)

GO

CREATE TABLE [dbo].[StoreGroupStores](
	  [StoreGroupStoresId] INT NOT NULL IDENTITY(1,1)
	, [StoreGroupId] INT NOT NULL 
	, [StoreGroupName] VARCHAR(200) NULL
	, [StoreId] INT NULL
	, [IsActive] BIT NOT NULL CONSTRAINT DF_StoreGroupStores_IsActive DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL CONSTRAINT DF_StoreGroupStores_CreatedOn DEFAULT(getutcdate())
	, [CreatedBy] NVARCHAR(256) NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] NVARCHAR(256) NULL
	, [TenantId] [int] NOT NULL CONSTRAINT DF_StoreGroupStores_TenantId DEFAULT(0)
	, [ClientId] [varchar](50) NULL
    , CONSTRAINT [PK_StoreGroupStores] PRIMARY KEY ([StoreGroupStoresId] ASC)
	)

	GO

CREATE TYPE [dbo].[UdtIntKeys] AS TABLE(
	[KeyValue] int NOT NULL,
	PRIMARY KEY CLUSTERED 
(
	[KeyValue] ASC
)WITH (IGNORE_DUP_KEY = OFF)
)
GO
----------------end script 26 june 23--------------------------


/****** Object:  Table [dbo].[StoreTenantMapping]    Script Date: 29-01-2024 11:32:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[StoreTenantMapping](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[StoreId] [int] NULL,
	[TenantId] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO