CREATE TABLE [dbo].[Amenity]
(
	  [AmenityId] INT NOT NULL IDENTITY(1,1)
	, [AmenityName] VARCHAR(100) NULL
	, [ImageUrl] NVARCHAR(1000) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Amenity] PRIMARY KEY ([AmenityId] ASC)
)

GO
CREATE TABLE [dbo].[CarWashType]
(
	  [CarWashTypeId] INT NOT NULL IDENTITY(1,1)
	, [CarWashName] NVARCHAR(100) NULL
	, [Price] DECIMAL(18,2) NULL
	, [StoreId] INT NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_CarWashType] PRIMARY KEY ([CarWashTypeId] ASC)
)

GO
CREATE TABLE [dbo].[CategoryType]
(
	  [Id] INT NOT NULL IDENTITY(1,1)
	, [Name] VARCHAR(100) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_CategoryType] PRIMARY KEY ([Id] ASC)
)

GO
GO
CREATE TABLE [dbo].[Company]
(
	  [Id] INT NOT NULL IDENTITY(1,1)
	, [Name] VARCHAR(200) NULL
	, [Url] VARCHAR(500) NULL
	, [Note] VARCHAR(1000) NULL
	, [MCC_SICNumber] VARCHAR(20) NULL
	, [ResellerId] INT NULL
	, [OwnerId] INT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Company] PRIMARY KEY ([Id] ASC)
)

GO
CREATE TABLE [dbo].[Country]
(
	  [CountryId] INT NOT NULL IDENTITY(1,1)
	, [CountryName] VARCHAR(100) NULL
	, [CountryCode] VARCHAR(10) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Country] PRIMARY KEY ([CountryId] ASC)
)

GO
CREATE TABLE [dbo].[Designation]
(
	  [DesignationId] INT NOT NULL IDENTITY(1,1)
	, [Name] VARCHAR(50) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Designation] PRIMARY KEY ([DesignationId] ASC)
)

GO
GO
CREATE TABLE [dbo].[Region]
(
	  [RegionId] INT NOT NULL IDENTITY(1,1)
	, [RegionName] VARCHAR(50) NULL
	, [Zipcode] VARCHAR(10) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Region] PRIMARY KEY ([RegionId] ASC)
)

GO
CREATE TABLE [dbo].[StoreAmenity]
(
	  [StoreAmenityId] INT NOT NULL IDENTITY(1,1)
	, [StoreId] INT NOT NULL
	, [AmenityId] INT NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_StoreAmenity] PRIMARY KEY ([StoreAmenityId] ASC)
)

GO
CREATE TABLE [dbo].[TimeZone]
(
	  [TimeZoneId] INT NOT NULL IDENTITY(1,1)
	, [TimeZoneName] VARCHAR(50) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_TimeZone] PRIMARY KEY ([TimeZoneId] ASC)
)

GO
CREATE TABLE [dbo].[Title]
(
	  [TitleId] INT NOT NULL IDENTITY(1,1)
	, [TitleName] VARCHAR(100) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, CONSTRAINT [PK_Title] PRIMARY KEY ([TitleId] ASC)
)

GO
CREATE TABLE [dbo].[WeekDays]
(
	  [WeekDayId] INT NOT NULL IDENTITY(1,1)
	, [Name] VARCHAR(25) NOT NULL
	, CONSTRAINT [PK_WeekDays] PRIMARY KEY ([WeekDayId] ASC)
)

GO
CREATE TABLE [dbo].[CategoryTypeLevel]
(
	  [Id] INT NOT NULL IDENTITY(1,1)
	, [Name] VARCHAR(100) NULL
	, [CategoryTypeId] INT NULL
	, [IsPrimary] BIT NOT NULL DEFAULT((0))
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_CategoryTypeLevel] PRIMARY KEY ([Id] ASC)
)

ALTER TABLE [dbo].[CategoryTypeLevel] WITH CHECK ADD CONSTRAINT [FK_CategoryTypeLevel_CategoryType] FOREIGN KEY([CategoryTypeId]) REFERENCES [dbo].[CategoryType] ([Id])
ALTER TABLE [dbo].[CategoryTypeLevel] CHECK CONSTRAINT [FK_CategoryTypeLevel_CategoryType]

GO
CREATE TABLE [dbo].[State]
(
	  [StateId] INT NOT NULL IDENTITY(1,1)
	, [CountryId] INT NULL
	, [StateName] VARCHAR(100) NULL
	, [StateCode] VARCHAR(10) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_State] PRIMARY KEY ([StateId] ASC)
)

ALTER TABLE [dbo].[State] WITH CHECK ADD CONSTRAINT [FK_State_Country] FOREIGN KEY([CountryId]) REFERENCES [dbo].[Country] ([CountryId])
ALTER TABLE [dbo].[State] CHECK CONSTRAINT [FK_State_Country]

GO
CREATE TABLE [dbo].[Store]
(
	  [StoreId] INT NOT NULL IDENTITY(1,1)
	, [StoreName] VARCHAR(200) NULL
	, [SiteId] VARCHAR(50) NULL
	, [StoreUrl] VARCHAR(1000) NULL
	, [MangerId] INT NULL
	, [RegionId] INT NULL
	, [RegionalManagerId] INT NULL
	, [PosId] INT NULL
	, [PosName] VARCHAR(50) NULL
	, [Description] VARCHAR(1000) NULL
	, [Note] VARCHAR(1000) NULL
	, [StoreImage] VARCHAR(500) NULL
	, [TimeZoneId] INT NULL
	, [CompanyId] INT NULL
	, [MaxAuthorizeAmount] DECIMAL(18,2) NULL
	, [EnableBilling] BIT NULL
	, [ConsentCashReward] BIT NULL
	, [IsMasterStore] BIT NOT NULL DEFAULT((0))
	, [IsTestStore] BIT NOT NULL DEFAULT((0))
	, [SaleAgentId] INT NULL
	, [ResellerId] INT NULL
	, [DisableEod] BIT NOT NULL DEFAULT((0))
	, [DisableBilling] BIT NOT NULL DEFAULT((0))
	, [EnableACHLoyalty] BIT NOT NULL DEFAULT((0))
	, [EnableCardLoyalty] BIT NOT NULL DEFAULT((0))
	, [LoyaltyProgramId] VARCHAR(100) NULL
	, [StoreCategoryId] INT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Store] PRIMARY KEY ([StoreId] ASC)
)

ALTER TABLE [dbo].[Store] WITH CHECK ADD CONSTRAINT [FK_Store_Company] FOREIGN KEY([CompanyId]) REFERENCES [dbo].[Company] ([Id])
ALTER TABLE [dbo].[Store] CHECK CONSTRAINT [FK_Store_Company]

GO
CREATE TABLE [dbo].[Users]
(
	  [UserId] INT NOT NULL 
	, [Title] INT NULL
	, [FirstName] VARCHAR(50) NULL
	, [LastName] VARCHAR(50) NULL
	, [DesignationId] INT NULL
	, [CompanyId] INT NULL
	, [StoreId] INT NULL
	, [ManagerId] INT NULL
	, [RegionId] INT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Users] PRIMARY KEY ([UserId] ASC)
)

ALTER TABLE [dbo].[Users] WITH CHECK ADD CONSTRAINT [FK_Users_Designation] FOREIGN KEY([DesignationId]) REFERENCES [dbo].[Designation] ([DesignationId])
ALTER TABLE [dbo].[Users] CHECK CONSTRAINT [FK_Users_Designation]

ALTER TABLE [dbo].[Users] WITH CHECK ADD CONSTRAINT [FK_Users_Title] FOREIGN KEY([Title]) REFERENCES [dbo].[Title] ([TitleId])
ALTER TABLE [dbo].[Users] CHECK CONSTRAINT [FK_Users_Title]

GO
CREATE TABLE [dbo].[Address]
(
	  [AddressId] INT NOT NULL IDENTITY(1,1)
	, [CategoryTypeLevelId] INT NULL
	, [AddressLine1] VARCHAR(500) NULL
	, [AddressLine2] VARCHAR(500) NULL
	, [CountryId] INT NULL
	, [Stateid] INT NULL
	, [City] VARCHAR(50) NULL
	, [ZipCode] VARCHAR(6) NULL
	, [Longitude] DECIMAL(18,7) NULL
	, [Latitude] DECIMAL(18,7) NULL
	, [Userid] INT NULL
	, [CompanyId] INT NULL
	, [StoreId] INT NULL
	, [SaleAgentId] INT NULL
	, [ResellerId] INT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Address] PRIMARY KEY ([AddressId] ASC)
)

ALTER TABLE [dbo].[Address] WITH CHECK ADD CONSTRAINT [FK_Address_CategoryTypeLevel] FOREIGN KEY([CategoryTypeLevelId]) REFERENCES [dbo].[CategoryTypeLevel] ([Id])
ALTER TABLE [dbo].[Address] CHECK CONSTRAINT [FK_Address_CategoryTypeLevel]

ALTER TABLE [dbo].[Address] WITH CHECK ADD CONSTRAINT [FK_Address_Country] FOREIGN KEY([CountryId]) REFERENCES [dbo].[Country] ([CountryId])
ALTER TABLE [dbo].[Address] CHECK CONSTRAINT [FK_Address_Country]

ALTER TABLE [dbo].[Address] WITH CHECK ADD CONSTRAINT [FK_Address_State] FOREIGN KEY([Stateid]) REFERENCES [dbo].[State] ([StateId])
ALTER TABLE [dbo].[Address] CHECK CONSTRAINT [FK_Address_State]

GO
CREATE TABLE [dbo].[Email]
(
	  [EmailId] INT NOT NULL IDENTITY(1,1)
	, [CategoryTypeLevelId] INT NULL
	, [EmailAddress] VARCHAR(100) NULL
	, [Userid] INT NULL
	, [CompanyId] INT NULL
	, [StoreId] INT NULL
	, [SaleAgentId] INT NULL
	, [ResellerId] INT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Email] PRIMARY KEY ([EmailId] ASC)
)

ALTER TABLE [dbo].[Email] WITH CHECK ADD CONSTRAINT [FK_Email_CategoryTypeLevel] FOREIGN KEY([CategoryTypeLevelId]) REFERENCES [dbo].[CategoryTypeLevel] ([Id])
ALTER TABLE [dbo].[Email] CHECK CONSTRAINT [FK_Email_CategoryTypeLevel]

GO
CREATE TABLE [dbo].[Phone]
(
	  [PhoneId] INT NOT NULL IDENTITY(1,1)
	, [CategoryTypeLevelId] INT NULL
	, [CountryCode] VARCHAR(20) NULL
	, [PhoneNumber] VARCHAR(20) NULL
	, [AreaCode] VARCHAR(50) NULL
	, [Userid] INT NULL
	, [CompanyId] INT NULL
	, [StoreId] INT NULL
	, [SaleAgentId] INT NULL
	, [ResellerId] INT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Phone] PRIMARY KEY ([PhoneId] ASC)
)

ALTER TABLE [dbo].[Phone] WITH CHECK ADD CONSTRAINT [FK_Phone_CategoryTypeLevel] FOREIGN KEY([CategoryTypeLevelId]) REFERENCES [dbo].[CategoryTypeLevel] ([Id])
ALTER TABLE [dbo].[Phone] CHECK CONSTRAINT [FK_Phone_CategoryTypeLevel]

GO
CREATE TABLE [dbo].[StoreHours]
(
	  [StoreHoursId] INT NOT NULL IDENTITY(1,1)
	, [StoreId] INT NOT NULL
	, [WeekDayId] INT NOT NULL
	, [OpenTime] VARCHAR(25) NULL
	, [CloseTime] VARCHAR(25) NULL
	, [Is24Hours] BIT NOT NULL DEFAULT((0))
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_StoreHours] PRIMARY KEY ([StoreHoursId] ASC)
)

ALTER TABLE [dbo].[StoreHours] WITH CHECK ADD CONSTRAINT [FK_StoreHours_Store] FOREIGN KEY([StoreId]) REFERENCES [dbo].[Store] ([StoreId])
ALTER TABLE [dbo].[StoreHours] CHECK CONSTRAINT [FK_StoreHours_Store]

ALTER TABLE [dbo].[StoreHours] WITH CHECK ADD CONSTRAINT [FK_StoreHours_WeekDays] FOREIGN KEY([WeekDayId]) REFERENCES [dbo].[WeekDays] ([WeekDayId])
ALTER TABLE [dbo].[StoreHours] CHECK CONSTRAINT [FK_StoreHours_WeekDays]

GO
CREATE TABLE [dbo].[PosSystem]
(
	  [PosId] INT NOT NULL IDENTITY(1,1)
	, [PosName] VARCHAR(100) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_PosSystem] PRIMARY KEY ([PosId] ASC)
)

GO
CREATE TABLE [dbo].[SaleAgent]
(
	  [SaleAgentId] INT NOT NULL IDENTITY(1,1)
	, [FirstName] VARCHAR(100) NULL
	, [LastName] VARCHAR(100) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_SaleAgent] PRIMARY KEY ([SaleAgentId] ASC)
)
GO
CREATE TYPE [dbo].[UdtStringKeys] AS TABLE
(
    [KeyValue] varchar(20) NOT NULL,
    PRIMARY KEY CLUSTERED 
    (
        [KeyValue] ASC
    )WITH (IGNORE_DUP_KEY = OFF)
)
GO
CREATE TABLE [dbo].[Reseller]
(
	  [ResellerId] INT NOT NULL IDENTITY(1,1)
	, [CompanyName] VARCHAR(100) NULL
	, [FirstName] VARCHAR(100) NULL
	, [LastName] VARCHAR(100) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Reseller] PRIMARY KEY ([ResellerId] ASC)
)
GO

CREATE TABLE [dbo].[StoreCategory]
(
	  [Id] INT NOT NULL IDENTITY(1,1)
	, [Name] VARCHAR(100) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_StoreCategory] PRIMARY KEY ([Id] ASC)
)
GO

CREATE TABLE [dbo].[StoreGroup]
(
	  [StoreGroupId] INT NOT NULL IDENTITY(1,1)
	, [StoreGroupName] VARCHAR(200) NULL
	, [StoreId] INT NULL
	, [IsActive] BIT NOT NULL CONSTRAINT DF_StoreGroup_IsActive DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL CONSTRAINT DF_StoreGroup_CreatedOn DEFAULT(getutcdate())
	, [CreatedBy] NVARCHAR(256) NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] NVARCHAR(256) NULL
	, CONSTRAINT [PK_StoreGroup] PRIMARY KEY ([StoreGroupId] ASC)
)
GO