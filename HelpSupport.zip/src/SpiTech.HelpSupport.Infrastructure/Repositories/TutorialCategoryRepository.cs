﻿using AutoMapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.HelpSupport.Application.Repositories;
using SpiTech.HelpSupport.Domain.Entities;

namespace SpiTech.HelpSupport.Infrastructure.Repositories
{
    public class TutorialCategoryRepository : Repository<TutorialCategory>, ITutorialCategoryRepository
    {
        public TutorialCategoryRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
    }
}
