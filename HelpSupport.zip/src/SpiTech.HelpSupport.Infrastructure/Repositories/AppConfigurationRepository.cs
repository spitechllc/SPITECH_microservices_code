﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.HelpSupport.Application.Repositories;
using SpiTech.HelpSupport.Domain.Entities;
using System.Threading.Tasks;

namespace SpiTech.HelpSupport.Infrastructure.Repositories
{
    public class AppConfigurationRepository : Repository<AppConfiguration>, IAppConfigurationRepository
    {
        public AppConfigurationRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<int> UpdateFile(string emailBanner)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("EmailBanner", emailBanner);
            dynamicParams.Add("UpdatedBy", GetActionUserId());

            return await DbConnection.ExecuteAsync($"Update dbo.AppConfiguration set EmailBanner=@EmailBanner, UpdatedOn=getutcdate(), UpdatedBy=@UpdatedBy ", dynamicParams, DbTransaction);
        }
    }
}
