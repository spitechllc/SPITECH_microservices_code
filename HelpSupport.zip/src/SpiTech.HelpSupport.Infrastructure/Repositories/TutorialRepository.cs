﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.HelpSupport.Application.Repositories;
using SpiTech.HelpSupport.Domain.Entities;
using SpiTech.HelpSupport.Domain.Enums;
using SpiTech.HelpSupport.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.HelpSupport.Infrastructure.Repositories
{
    public class TutorialRepository : Repository<Tutorial>, ITutorialRepository
    {
        public TutorialRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<int> UpdateThumbnail(string thumbnail, int tutorialId)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("Thumbnail", thumbnail);
            dynamicParams.Add("TutorialId", tutorialId);
            dynamicParams.Add("UpdatedBy", GetActionUserId());

            return await DbConnection.ExecuteAsync($"Update dbo.Tutorial set Thumbnail=@Thumbnail, UpdatedOn=getutcdate(), UpdatedBy=@UpdatedBy where TutorialId=@TutorialId", dynamicParams, DbTransaction);
        }

        public async Task<int> UpdateFile(string fileUrl, int tutorialId)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("FileUrl", fileUrl);
            dynamicParams.Add("TutorialId", tutorialId);
            dynamicParams.Add("UpdatedBy", GetActionUserId());

            return await DbConnection.ExecuteAsync($"Update dbo.Tutorial set FileUrl=@FileUrl, UpdatedOn=getutcdate(), UpdatedBy=@UpdatedBy where TutorialId=@TutorialId", dynamicParams, DbTransaction);
        }

        public async Task<List<TutorialModel>> GetTutorialById(int tutorialId)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("TutorialId", tutorialId);

            return (await DbConnection.QueryAsync<TutorialModel>($"Select * from Tutorial where TutorialId=@TutorialId", dynamicParams, DbTransaction)).ToList();
        }

        public async Task<List<TutorialModel>> GetTutorial(string tenantCompany, string tutorialName, int? categoryId, int? pageIndex, int? pageSize, TutorialSortBy? sortBy, SortOrderEnum? sortOrder)
        {
            StringBuilder sbquery = new();
            DynamicParameters dynamicParams = new();
            if (!string.IsNullOrEmpty(tenantCompany))
            {
                sbquery.Append($"select count(1) over() as TotalRecord, T.* from [Tutorial] T inner join [TutorialCategory] C on T.TutorialCategoryId=C.TutorialCategoryId where 1=1 and TenantName is not null  ");
            }
            else
            {
                sbquery.Append($"select count(1) over() as TotalRecord, T.* from [Tutorial] T inner join [TutorialCategory] C on T.TutorialCategoryId=C.TutorialCategoryId where 1=1 and TenantName is null   ");
            }
            if (!string.IsNullOrEmpty(tutorialName))
            {
                sbquery.Append($" and T.TutorialName like @TutorialName");
                dynamicParams.Add("TutorialName", $"%{tutorialName}%");
            }

            if (categoryId.HasValue && categoryId > 0)
            {
                sbquery.Append($" and T.TutorialCategoryId = @TutorialCategoryId");
                dynamicParams.Add("TutorialCategoryId", categoryId);
            }

            if (sortBy != null && sortOrder != null && sortBy.Value != TutorialSortBy.None && sortOrder.Value != SortOrderEnum.None)
            {
                if(sortBy.Value == TutorialSortBy.TutorialCategoryName)
                {
                    sbquery.Append($" Order by C.{sortBy} {sortOrder}");
                }
                else
                {
                    sbquery.Append($" Order by T.{sortBy} {sortOrder}");
                }
            }
            else
            {
                sbquery.Append($" Order by T.TutorialId desc");
            }

            if (pageIndex.HasValue && pageSize.HasValue)
            {
                int skiprow = (pageIndex.Value - 1) * pageSize.Value;
                sbquery.Append($" OFFSET {skiprow} rows fetch next {pageSize.Value} rows only");
            }

            return (await DbConnection.QueryAsync<TutorialModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }
    }
}
