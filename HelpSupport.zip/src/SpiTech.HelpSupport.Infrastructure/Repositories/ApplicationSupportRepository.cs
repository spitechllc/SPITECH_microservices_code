﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.HelpSupport.Application.Repositories;
using SpiTech.HelpSupport.Domain.Entities;
using SpiTech.HelpSupport.Domain.Enums;
using SpiTech.HelpSupport.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.HelpSupport.Infrastructure.Repositories
{
    public class ApplicationSupportRepository : Repository<ApplicationSupport>, IApplicationSupportRepository
    {
        public ApplicationSupportRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<ApplicationSupport> GetVersionByFilter(int appType, string version, int? userId)
        {
            StringBuilder sbquery = new();
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("ApplicationType", appType);

            sbquery.Append($"select top(1) * from [ApplicationSupport] where ApplicationType=@ApplicationType ");

            if (!string.IsNullOrWhiteSpace(version))
            {
                sbquery.Append($" and VersionNo like '%@VersionNo%' ");
                dynamicParams.Add("VersionNo", version);
            }

            sbquery.Append(" Order by ApplicationSupportId desc");

            return (await DbConnection.QueryAsync<ApplicationSupport>(sbquery.ToString(), dynamicParams, DbTransaction)).FirstOrDefault();
        }

        public async Task<List<ApplicationSupportModel>> GetApplicationSupports(int pageIndex, int pageSize, ApplicationSupportSortBy? sortBy, SortOrderEnum? sortOrder)
        {
            StringBuilder sbquery = new();
            DynamicParameters dynamicParams = new();

            sbquery.Append($"select count(1) over() as TotalRecord, * from ApplicationSupport ");



            if (sortBy != null && sortOrder != null && sortBy.Value != ApplicationSupportSortBy.None && sortOrder.Value != SortOrderEnum.None)
            {
                sbquery.Append($" Order by {sortBy.Value} {sortOrder.Value}");
            }
            else
            {
                sbquery.Append(" Order by ApplicationSupportId desc");
            }


            if (pageSize > 0 && pageIndex > 0)
            {
                int skiprow = (pageIndex - 1) * pageSize;
                sbquery.Append($" OFFSET {skiprow} rows fetch next {pageSize} rows only");
            }

            return (await DbConnection.QueryAsync<ApplicationSupportModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }
    }
}
