﻿using AutoMapper;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.HelpSupport.Application.Repositories;
using SpiTech.HelpSupport.Application.UnitOfWorks;
using SpiTech.HelpSupport.Infrastructure.Repositories;
using System.Data;

namespace SpiTech.HelpSupport.Infrastructure.UnitOfWorks
{
    public sealed class UnitOfWork : BaseUnitOfWork, IUnitOfWork
    {
        public UnitOfWork(string connectionString,
                         System.IServiceProvider serviceProvider,
                        IsolationLevel isolationLevel = IsolationLevel.ReadCommitted)
                        : base(connectionString, serviceProvider, isolationLevel)
        {
        }

        private ITutorialRepository _tutorials = null;
        private IAppConfigurationRepository _appConfigurations = null;
        private ITutorialCategoryRepository _tutorialCategories = null;
        private IApplicationSupportRepository _applicationSupports = null;

        public ITutorialRepository Tutorials => _tutorials ??= new TutorialRepository(this, serviceProvider);

        public IAppConfigurationRepository AppConfigurations => _appConfigurations ??= new AppConfigurationRepository(this, serviceProvider);

        public ITutorialCategoryRepository TutorialCategories => _tutorialCategories ??= new TutorialCategoryRepository(this, serviceProvider);

        public IApplicationSupportRepository ApplicationSupports => _applicationSupports ??= new ApplicationSupportRepository(this, serviceProvider);

        public override void ResetRepositories()
        {
            _tutorials = null;
            _appConfigurations = null;
            _tutorialCategories = null;
            _applicationSupports = null;
        }
    }
}
