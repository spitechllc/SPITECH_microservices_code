﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.HelpSupport.Application.Commands.CreateTutorial;
using SpiTech.HelpSupport.Application.Commands.UpdateTutorial;
using SpiTech.HelpSupport.Application.Queries.GetTutorial;
using SpiTech.HelpSupport.Application.Queries.GetTutorialById;
using SpiTech.HelpSupport.Application.Queries.GetTutorialCategory;
using SpiTech.HelpSupport.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.HelpSupport.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class TutorialController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<TutorialController> _logger;

        public TutorialController(IMediator mediator, ILogger<TutorialController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        /// <summary>
        /// Method will return Tutorial data availble under the entities.
        /// </summary>
        /// <param name="query">object of GetTutorialQuery</param>
        /// <returns>It will return PaginatedList in the form of TutorialModel</returns
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet]
        public async Task<ActionResult<PaginatedList<TutorialModel>>> Get([FromQuery] GetTutorialQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will return list of Tutorial Category data.
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of TutorialCategoryModel</returns>
        [ApiPermissionAuthorize(Permissions = "HelpSupportapi_Tutorial_GetTutorialCategory")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetTutorialCategory")]
        public async Task<ActionResult<ResponseList<TutorialCategoryModel>>> GetTutorialCategory()
        {
            return Ok(await _mediator.Send(new GetTutorialCategoryQuery()).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will return list of Tutorial Category data by Tutorial Id.
        /// </summary>
        /// <param name="TutorialId">Varriable of TutorialId</param>
        /// <returns>It will return in the form of TutorialModel</returns>
        [ApiPermissionAuthorize(Permissions = "HelpSupportapi_Tutorial_GetTutorialById")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetTutorialById/{TutorialId}")]
        public async Task<ActionResult<TutorialModel>> GetTutorialById(int TutorialId)
        {
            return Ok(await _mediator.Send(new GetTutorialByIdQuery() { TutorialId = TutorialId }).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will create new Tutorial.
        /// </summary>
        /// <param name="command">Object of CreateTutorialCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "HelpSupportapi_Tutorial_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost]
        public async Task<ActionResult<ResponseModel>> Post([FromForm] CreateTutorialCommand command)
        {

            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will update existing Tutorial.
        /// </summary>
        /// <param name="command">Object of UpdateTutorialCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "HelpSupportapi_Tutorial_Patch")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch]
        public async Task<ActionResult<ResponseModel>> Update([FromForm] UpdateTutorialCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }
    }
}
