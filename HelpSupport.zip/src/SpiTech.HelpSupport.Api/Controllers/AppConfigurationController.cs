﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.HelpSupport.Application.Commands.CreateAppConfiguration;
using SpiTech.HelpSupport.Application.Commands.UpdateAppConfiguration;
using SpiTech.HelpSupport.Application.Queries.GetAppConfiguration;
using SpiTech.HelpSupport.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.HelpSupport.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class AppConfigurationController : ControllerBase
    {
        private readonly IMediator _mediator;

        public AppConfigurationController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Method will return App Configuration data( i.e. support no email etc...)
        /// </summary>
        /// <param></param>
        /// <returns>It will return in the form of AppConfigurationModel</returns>
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet]
        public async Task<ActionResult<AppConfigurationModel>> Get()
        {
            return Ok(await _mediator.Send(new GetAppConfigurationQuery()).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will create new App Configuration.
        /// </summary>
        /// <param name="command">Object of CreateAppConfigurationCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "HelpSupportapi_AppConfiguration_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost]
        public async Task<ActionResult<ResponseModel>> Post([FromBody] CreateAppConfigurationCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will update existing App Configuration.
        /// </summary>
        /// <param name="command">Object of UpdateAppConfigurationCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "HelpSupportapi_AppConfiguration_Patch")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch]
        public async Task<ActionResult<ResponseModel>> Update([FromBody] UpdateAppConfigurationCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }
    }
}
