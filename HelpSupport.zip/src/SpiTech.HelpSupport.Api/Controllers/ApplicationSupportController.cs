﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.HelpSupport.Application.Commands.SaveApplicationSupport;
using SpiTech.HelpSupport.Application.Queries.GetApplicationSupport;
using SpiTech.HelpSupport.Application.Queries.GetApplicationSupportByFilter;
using SpiTech.HelpSupport.Domain.Entities;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.HelpSupport.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class ApplicationSupportController : ControllerBase
    {
        private readonly IMediator _mediator;

        public ApplicationSupportController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Method will return app Version no,app features etc..
        /// </summary>
        /// <param name="model">object of GetApplicationSupportByFilterQuery</param>
        /// <returns>It will return in the form of ApplicationSupport</returns>
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetByFilter")]
        public async Task<ActionResult<ApplicationSupport>> Get([FromQuery] GetApplicationSupportByFilterQuery model)
        {
            return Ok(await _mediator.Send(model).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will return list of Application Support data availble under the entities 
        /// </summary>
        /// <param name="query">object of GetApplicationSupportQuery</param>
        /// <returns>It will return PaginatedList in the form of ApplicationSupport</returns>
        [ApiPermissionAuthorize(Permissions = "HelpSupportapi_ApplicationSupport_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet]
        public async Task<ActionResult<PaginatedList<ApplicationSupport>>> Get([FromQuery] GetApplicationSupportQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will create new Application Support.
        /// </summary>
        /// <param name="command">Object of SaveApplicationSupportCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "HelpSupportapi_ApplicationSupport_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost]
        public async Task<ActionResult<ResponseModel>> Save([FromBody] SaveApplicationSupportCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }
    }
}
