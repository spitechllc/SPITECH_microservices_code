﻿using AutoMapper;
using SpiTech.HelpSupport.Domain.Entities;
using SpiTech.HelpSupport.Domain.Models;

namespace SpiTech.HelpSupport.Domain.Mappers
{
    public class AppConfigurationProfile : Profile
    {
        public AppConfigurationProfile()
        {
            CreateMap<AppConfiguration, AppConfigurationModel>().ReverseMap();
        }
    }
}
