﻿using AutoMapper;
using SpiTech.HelpSupport.Domain.Entities;
using SpiTech.HelpSupport.Domain.Models;

namespace SpiTech.HelpSupport.Domain.Mappers
{
    public class TutorialProfile : Profile
    {
        public TutorialProfile()
        {
            CreateMap<Tutorial, TutorialModel>().ReverseMap();
        }
    }
}
