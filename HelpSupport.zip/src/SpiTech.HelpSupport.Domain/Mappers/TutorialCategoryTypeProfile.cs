﻿using AutoMapper;
using SpiTech.HelpSupport.Domain.Entities;
using SpiTech.HelpSupport.Domain.Models;

namespace SpiTech.HelpSupport.Domain.Mappers
{
    public class TutorialCategoryTypeProfile : Profile
    {
        public TutorialCategoryTypeProfile()
        {
            CreateMap<TutorialCategory, TutorialCategoryModel>().ReverseMap();
        }
    }
}
