﻿using System;

namespace SpiTech.HelpSupport.Domain.Models
{
    public class ApplicationSupportModel
    {
        public int ApplicationSupportId { get; set; }
        public string VersionNo { get; set; }
        public DateTime VersionUpdateDate { get; set; }
        public string ApplicationFeatures { get; set; }
        public int ApplicationType { get; set; }
        public bool ForcefullyUpdate { get; set; }
        public bool IsActive { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        [Newtonsoft.Json.JsonIgnore]
        public int TotalRecord { get; set; }
    }
}
