﻿namespace SpiTech.HelpSupport.Domain.Models
{
    public class TutorialCategoryModel
    {
        public int TutorialCategoryId { get; set; }
        public string TutorialCategoryName { get; set; }
    }
}
