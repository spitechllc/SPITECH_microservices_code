﻿namespace SpiTech.HelpSupport.Domain.Models
{
    public class TutorialModel
    {
        public int TutorialId { get; set; }
        public string TutorialName { get; set; }
        public string ShortDescription { get; set; }
        public int TutorialCategoryId { get; set; }
        public string Category { get; set; }
        public string Thumbnail { get; set; }
        public string FileUrl { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        [Newtonsoft.Json.JsonIgnore]
        public int TotalRecord { get; set; }
    }
}
