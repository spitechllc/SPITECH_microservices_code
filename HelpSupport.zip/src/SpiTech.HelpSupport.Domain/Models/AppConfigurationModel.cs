﻿namespace SpiTech.HelpSupport.Domain.Models
{
    public class AppConfigurationModel
    {
        public int AppConfigId { get; set; }
        public string SupportNo { get; set; }
        public string SupportEmail { get; set; }

        public string EmailBanner { get; set; }
    }
}
