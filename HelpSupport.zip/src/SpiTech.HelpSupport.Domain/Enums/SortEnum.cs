﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SpiTech.HelpSupport.Domain.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum ApplicationSupportSortBy
    {
        None = 0,
        ApplicationSupportId = 1,
        VersionNo = 2,
        VersionUpdateDate = 3,
        ApplicationFeatures = 4,
        ApplicationType = 5,
        ForcefullyUpdate = 6
    }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum TutorialSortBy
    {
        None = 0,
        TutorialId = 1,
        TutorialName = 2,
        ShortDescription = 3,
        TutorialCategoryId = 4,
        Thumbnail = 5,
        FileUrl = 6,
        TutorialCategoryName = 7
    }
}
