﻿namespace SpiTech.HelpSupport.Domain.Enums
{
    public enum EntityTutorialCategory
    {
        None = 0,
        UserSignup = 1,
        UserProfile = 2,
        PaymentMethod = 3,
        PayatPump = 4,
        PayinStore = 5,
        Loyalty = 6,
    }
}
