﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.HelpSupport.Domain.Entities
{
    [Table("dbo.TutorialCategory")]
    public class TutorialCategory : BaseEntity
    {
        [Key]
        public int TutorialCategoryId { get; set; }
        public string TutorialCategoryName { get; set; }
    }
}
