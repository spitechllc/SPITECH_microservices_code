﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.HelpSupport.Domain.Entities
{
    [Table("dbo.AppConfiguration")]
    public class AppConfiguration : BaseEntity
    {
        [Key]
        public int AppConfigId { get; set; }
        public string SupportNo { get; set; }

        public string SupportEmail { get; set; }

        public string EmailBanner { get; set; }
    }
}
