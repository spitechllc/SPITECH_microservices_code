﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.HelpSupport.Domain.Entities
{
    [Table("dbo.ApplicationSupport")]
    public class ApplicationSupport : BaseEntity
    {
        [Key]
        public int ApplicationSupportId { get; set; }
        public string VersionNo { get; set; }
        public DateTime VersionUpdateDate { get; set; }
        public string ApplicationFeatures { get; set; }
        public int ApplicationType { get; set; }
        public bool ForcefullyUpdate { get; set; }
    }
}
