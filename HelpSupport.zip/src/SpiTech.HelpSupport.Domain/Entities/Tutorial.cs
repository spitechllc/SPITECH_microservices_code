﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.HelpSupport.Domain.Entities
{
    [Table("dbo.Tutorial")]
    public class Tutorial : BaseEntity
    {
        [Key]
        public int TutorialId { get; set; }
        public string TutorialName { get; set; }

        public string ShortDescription { get; set; }
        public int TutorialCategoryId { get; set; }
        public string Thumbnail { get; set; }
        public string FileUrl { get; set; }
        public string TenantName { get; set; }
    }
}
