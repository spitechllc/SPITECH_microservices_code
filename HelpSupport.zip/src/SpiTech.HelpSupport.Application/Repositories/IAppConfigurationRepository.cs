﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.HelpSupport.Domain.Entities;
using System.Threading.Tasks;

namespace SpiTech.HelpSupport.Application.Repositories
{
    public interface IAppConfigurationRepository : IRepository<AppConfiguration>
    {
        Task<int> UpdateFile(string emailBanner);
    }

}
