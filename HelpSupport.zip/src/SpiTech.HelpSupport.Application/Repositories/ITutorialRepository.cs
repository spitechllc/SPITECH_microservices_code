﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.HelpSupport.Domain.Entities;
using SpiTech.HelpSupport.Domain.Enums;
using SpiTech.HelpSupport.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.HelpSupport.Application.Repositories
{
    public interface ITutorialRepository : IRepository<Tutorial>
    {
        Task<int> UpdateThumbnail(string thumbnail, int tutorialId);
        Task<int> UpdateFile(string fileUrl, int tutorialId);
        Task<List<TutorialModel>> GetTutorialById(int tutorialId);
        Task<List<TutorialModel>> GetTutorial(string tenantCompany, string tutorialName, int? categoryId, int? pageIndex, int? pageSize, TutorialSortBy? sortBy, SortOrderEnum? sortOrder);
    }
}
