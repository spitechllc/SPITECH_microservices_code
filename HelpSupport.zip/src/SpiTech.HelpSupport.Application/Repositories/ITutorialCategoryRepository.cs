﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.HelpSupport.Domain.Entities;

namespace SpiTech.HelpSupport.Application.Repositories
{
    public interface ITutorialCategoryRepository : IRepository<TutorialCategory>
    {
    }
}
