﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.HelpSupport.Domain.Entities;
using SpiTech.HelpSupport.Domain.Enums;
using SpiTech.HelpSupport.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.HelpSupport.Application.Repositories
{
    public interface IApplicationSupportRepository : IRepository<ApplicationSupport>
    {
        Task<ApplicationSupport> GetVersionByFilter(int appType, string version, int? userId);
        Task<List<ApplicationSupportModel>> GetApplicationSupports(int pageIndex, int pageSize, ApplicationSupportSortBy? sortBy, SortOrderEnum? sortOrder);
    }

}
