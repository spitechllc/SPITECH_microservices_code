﻿using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.HelpSupport.Application.Repositories;

namespace SpiTech.HelpSupport.Application.UnitOfWorks
{
    public interface IUnitOfWork : IBaseUnitOfWork
    {
        ITutorialRepository Tutorials { get; }
        IAppConfigurationRepository AppConfigurations { get; }
        ITutorialCategoryRepository TutorialCategories { get; }
        IApplicationSupportRepository ApplicationSupports { get; }
    }
}
