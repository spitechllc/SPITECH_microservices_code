﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.HelpSupport.Application.UnitOfWorks;
using SpiTech.HelpSupport.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.HelpSupport.Application.Queries.GetAppConfiguration
{
    public class GetAppConfigurationHandler : IRequestHandler<GetAppConfigurationQuery, AppConfigurationModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetAppConfigurationHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetAppConfigurationHandler(IUnitOfWork context,
                                   ILogger<GetAppConfigurationHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<AppConfigurationModel> Handle(GetAppConfigurationQuery query, CancellationToken cancel)
        {
            _logger.Warn($"AppConfiguration Start");
            _logger.TraceEnterMethod(nameof(Handle), query);
            AppConfigurationModel result = _mapper.Map<IEnumerable<AppConfigurationModel>>(await _context.AppConfigurations.GetAll()).FirstOrDefault();

            _logger.TraceExitMethod(nameof(Handle), query);
            _logger.Warn($"AppConfiguration End");
            return await Task.FromResult(result);
        }
    }
}
