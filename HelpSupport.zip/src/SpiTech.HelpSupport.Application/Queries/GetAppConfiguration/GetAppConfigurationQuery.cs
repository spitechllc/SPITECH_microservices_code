﻿using MediatR;
using SpiTech.HelpSupport.Domain.Models;

namespace SpiTech.HelpSupport.Application.Queries.GetAppConfiguration
{
    public class GetAppConfigurationQuery : IRequest<AppConfigurationModel>
    {
    }
}
