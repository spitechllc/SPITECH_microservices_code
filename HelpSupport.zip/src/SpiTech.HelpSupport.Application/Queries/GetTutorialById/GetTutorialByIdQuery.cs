﻿using MediatR;
using SpiTech.HelpSupport.Domain.Models;

namespace SpiTech.HelpSupport.Application.Queries.GetTutorialById
{
    public class GetTutorialByIdQuery : IRequest<TutorialModel>
    {
        public int TutorialId { get; set; }
    }
}
