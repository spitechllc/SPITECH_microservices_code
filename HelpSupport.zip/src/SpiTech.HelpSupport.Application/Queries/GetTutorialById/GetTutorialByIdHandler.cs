﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.HelpSupport.Application.UnitOfWorks;
using SpiTech.HelpSupport.Domain.Enums;
using SpiTech.HelpSupport.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.HelpSupport.Application.Queries.GetTutorialById
{
    public class GetTutorialByIdHandler : IRequestHandler<GetTutorialByIdQuery, TutorialModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetTutorialByIdHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetTutorialByIdHandler(IUnitOfWork context,
                                   ILogger<GetTutorialByIdHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<TutorialModel> Handle(GetTutorialByIdQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            TutorialModel tutoriallist = _mapper.Map<IEnumerable<TutorialModel>>(await _context.Tutorials.GetTutorialById(query.TutorialId)).FirstOrDefault();
            tutoriallist.Category = ((EntityTutorialCategory)tutoriallist.TutorialCategoryId).ToString();
            _logger.TraceExitMethod(nameof(Handle), query);
            return await Task.FromResult(tutoriallist);
        }


    }
}
