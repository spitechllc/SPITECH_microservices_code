﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.HelpSupport.Application.UnitOfWorks;
using SpiTech.HelpSupport.Domain.Enums;
using SpiTech.HelpSupport.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.HelpSupport.Application.Queries.GetTutorial
{
    public class GetTutorialHandler : IRequestHandler<GetTutorialQuery, PaginatedList<TutorialModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetTutorialHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetTutorialHandler(IUnitOfWork context,
                                   ILogger<GetTutorialHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<PaginatedList<TutorialModel>> Handle(GetTutorialQuery query, CancellationToken cancel)
        {
            _logger.Warn($"GetTutorial Start");
            _logger.TraceEnterMethod(nameof(Handle), query);
            try
            {
                List<TutorialModel> tutoriallist = await _context.Tutorials.GetTutorial(query.TenantCompany,query.TutorialName, query.CategoryId, query.PageIndex, query.PageSize, query.SortBy, query.SortOrder);
                foreach (TutorialModel item in tutoriallist)
                {
                    item.Category = ((EntityTutorialCategory)item.TutorialCategoryId).ToString();
                }
                _logger.TraceExitMethod(nameof(Handle), tutoriallist);
                _logger.Warn($"GetTutorial End count : {tutoriallist.Count()}");
                return new PaginatedList<TutorialModel>
                {
                    Data = tutoriallist,
                    PageIndex = query.PageIndex ?? 0,
                    PageSize = query.PageSize ?? 0,
                    TotalCount = tutoriallist.Select(s => s.TotalRecord).FirstOrDefault(),
                };
            }
            catch (Exception) { return null; };
        }
    }
}
