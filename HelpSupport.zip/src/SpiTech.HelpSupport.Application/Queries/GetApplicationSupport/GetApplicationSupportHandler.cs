﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.HelpSupport.Application.UnitOfWorks;
using SpiTech.HelpSupport.Domain.Models;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.HelpSupport.Application.Queries.GetApplicationSupport
{
    public class GetApplicationSupportHandler : IRequestHandler<GetApplicationSupportQuery, PaginatedList<ApplicationSupportModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetApplicationSupportHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetApplicationSupportHandler(IUnitOfWork context,
                                   ILogger<GetApplicationSupportHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<PaginatedList<ApplicationSupportModel>> Handle(GetApplicationSupportQuery query, CancellationToken cancel)
        {
            _logger.Warn($"GetApplicationSupport Start");
            _logger.TraceEnterMethod(nameof(Handle), query);

            var applicationSupports = await _context.ApplicationSupports.GetApplicationSupports(query.PageIndex, query.PageSize, query.SortBy, query.SortOrder);

            _logger.TraceExitMethod(nameof(Handle), applicationSupports);
            _logger.Warn($"GetApplicationSupport End");
            return new PaginatedList<ApplicationSupportModel>
            {
                Data = applicationSupports,
                PageIndex = query.PageIndex,
                PageSize = query.PageSize,
                TotalCount = applicationSupports?.FirstOrDefault()?.TotalRecord ?? 0
            };
        }
    }
}
