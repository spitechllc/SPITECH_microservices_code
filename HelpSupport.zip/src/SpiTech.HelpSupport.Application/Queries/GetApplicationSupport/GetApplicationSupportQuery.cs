﻿using MediatR;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.HelpSupport.Domain.Enums;
using SpiTech.HelpSupport.Domain.Models;

namespace SpiTech.HelpSupport.Application.Queries.GetApplicationSupport
{
    public class GetApplicationSupportQuery : IRequest<PaginatedList<ApplicationSupportModel>>
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }

        public ApplicationSupportSortBy? SortBy { get; set; }
        public SortOrderEnum? SortOrder { get; set; }
    }
}
