﻿using MediatR;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.HelpSupport.Domain.Entities;
using SpiTech.HelpSupport.Domain.Enums;

namespace SpiTech.HelpSupport.Application.Queries.GetApplicationSupportByFilter
{
    public class GetApplicationSupportByFilterQuery : IRequest<ApplicationSupport>
    {
        public DeviceType ApplicationType { get; set; }
        public string VersionNo { get; set; }
        public int? UserId { get; set; }
    }
}
