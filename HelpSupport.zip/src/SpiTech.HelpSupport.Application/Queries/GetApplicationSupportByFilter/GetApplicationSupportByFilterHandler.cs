﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.HelpSupport.Application.UnitOfWorks;
using SpiTech.HelpSupport.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.HelpSupport.Application.Queries.GetApplicationSupportByFilter
{
    public class GetApplicationSupportByFilterHandler : IRequestHandler<GetApplicationSupportByFilterQuery, ApplicationSupport>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetApplicationSupportByFilterHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetApplicationSupportByFilterHandler(IUnitOfWork context,
                                   ILogger<GetApplicationSupportByFilterHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<ApplicationSupport> Handle(GetApplicationSupportByFilterQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            ApplicationSupport result = await _context.ApplicationSupports.GetVersionByFilter((int)query.ApplicationType, query.VersionNo, query.UserId);

            _logger.TraceExitMethod(nameof(Handle), query);
            return await Task.FromResult(result);
        }
    }
}
