﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.HelpSupport.Domain.Models;

namespace SpiTech.HelpSupport.Application.Queries.GetTutorialCategory
{
    public class GetTutorialCategoryQuery : IRequest<ResponseList<TutorialCategoryModel>>
    {
    }
}
