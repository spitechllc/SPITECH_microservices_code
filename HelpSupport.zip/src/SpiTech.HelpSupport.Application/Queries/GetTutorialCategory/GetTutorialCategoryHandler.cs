﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.HelpSupport.Application.UnitOfWorks;
using SpiTech.HelpSupport.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.HelpSupport.Application.Queries.GetTutorialCategory
{
    public class GetTutorialCategoryHandler : IRequestHandler<GetTutorialCategoryQuery, ResponseList<TutorialCategoryModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetTutorialCategoryHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetTutorialCategoryHandler(IUnitOfWork context,
                                   ILogger<GetTutorialCategoryHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<ResponseList<TutorialCategoryModel>> Handle(GetTutorialCategoryQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            IEnumerable<TutorialCategoryModel> tutorialcategorylist = _mapper.Map<IEnumerable<TutorialCategoryModel>>(await _context.TutorialCategories.GetAll());


            _logger.TraceExitMethod(nameof(Handle), query);
            return new ResponseList<TutorialCategoryModel> { Data = tutorialcategorylist.ToList() };
        }


    }
}
