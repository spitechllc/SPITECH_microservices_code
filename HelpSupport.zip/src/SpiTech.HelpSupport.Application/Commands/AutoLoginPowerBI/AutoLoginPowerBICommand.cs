﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.HelpSupport.Application.Commands.AutoLoginPowerBI
{
  public class AutoLoginPowerBICommand:IRequest<ResponseModel>
    {
    }
}
