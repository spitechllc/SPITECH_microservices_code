﻿using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.HelpSupport.Application.Commands.AutoLoginPowerBI
{
    public class AutoLoginPowerBIHandler : IRequestHandler<AutoLoginPowerBICommand, ResponseModel>
    {
        private readonly ILogger<AutoLoginPowerBIHandler> _logger;
        private readonly IMediator _mediator = null;

        public AutoLoginPowerBIHandler(ILogger<AutoLoginPowerBIHandler> logger,
                                   IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;

        }
        public async Task<ResponseModel> Handle(AutoLoginPowerBICommand request, CancellationToken cancellationToken)
        {
            try
            {
                ResponseModel res = new ResponseModel() { Success = false };
                string tenantId = string.Empty;
                string clientId = string.Empty;
                string userId = "bi@SpiTech.com";
                string password = "SpiTech2022$";
                var url = $"https://login.windows.net/{tenantId}/oauth2/token";

                var webRequest = (HttpWebRequest)WebRequest.Create(url);
                webRequest.KeepAlive = true;
                webRequest.Method = "POST";
                webRequest.ContentType = "application/x-www-form-urlencoded";
                var dataToPost = new Dictionary<string, string>
    {
        {"client_id", clientId},
        {"grant_type", "password"},
        {"resource", ""},
        {"username", userId},
        {"password", password},
        {"redirect_uri", "https://dev.powerbi.com/Apps/SignInRedirect" }
    };

                var postData = string.Empty;
                foreach (var item in dataToPost)
                {
                    if (!string.IsNullOrEmpty(postData))
                        postData += "&";
                    postData += $"{item.Key}={item.Value}";
                }

                var dataByteArray = System.Text.Encoding.ASCII.GetBytes(postData);
                webRequest.ContentLength = dataByteArray.Length;

                using (var writer = webRequest.GetRequestStream())
                {
                    writer.Write(dataByteArray, 0, dataByteArray.Length);
                }

                var response = (HttpWebResponse)webRequest.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                var responseJson = JsonConvert.DeserializeObject<dynamic>(responseString);
                if(responseJson!=null)
                {
                    res.Success = true;
                    res.Message = responseJson["access_token"];
                }
                return await Task.FromResult(res);
            }
            catch(Exception ex)
            {
                throw;
            }

        }
    }
}
