﻿using MediatR;
using Microsoft.AspNetCore.Http;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.HelpSupport.Domain.Enums;
using System.ComponentModel.DataAnnotations;

namespace SpiTech.HelpSupport.Application.Commands.CreateTutorial
{
    public class CreateTutorialCommand : IRequest<ResponseModel>
    {
        [Required]
        public string TutorialName { get; set; }
        public string ShortDescription { get; set; }
        [Required]
        public EntityTutorialCategory Category { get; set; }
        public string Thumbnailbase64 { get; set; }
        [Required]
        public IFormFile FileUrl { get; set; }
    }
}
