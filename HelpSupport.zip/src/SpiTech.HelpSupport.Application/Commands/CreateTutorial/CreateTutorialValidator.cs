﻿using FluentValidation;

namespace SpiTech.HelpSupport.Application.Commands.CreateTutorial
{
    public class CreateTutorialValidator : AbstractValidator<CreateTutorialCommand>
    {
        public CreateTutorialValidator()
        {
            RuleFor(x => x.TutorialName).NotNull().NotEmpty().WithMessage("TutorialName is required").Length(1, 50);
            RuleFor(x => x.Category).NotNull().NotEmpty().WithMessage("Category is required");
            RuleFor(x => x.FileUrl).NotNull().NotEmpty().WithMessage("FileUrl is required");
            RuleFor(s => s.ShortDescription).NotNull().NotEmpty().MaximumLength(200);
        }
    }
}
