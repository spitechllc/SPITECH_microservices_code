﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.HelpSupport.Application.UnitOfWorks;
using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.HelpSupport.Application.Commands.CreateTutorial
{
    public class CreateTutorialHandler : IRequestHandler<CreateTutorialCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateTutorialHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IStorageService storageService;

        public CreateTutorialHandler(IUnitOfWork context,
                                   ILogger<CreateTutorialHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper,
                                   IStorageServiceFactory storageServiceFactory)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            storageService = storageServiceFactory.Get(ContainerType.AccountSupport);
        }

        public async Task<ResponseModel> Handle(CreateTutorialCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            int TutorialId = 0;

            
            if (!string.IsNullOrEmpty(command.Thumbnailbase64))
            {
                if (!((command.Thumbnailbase64.Length % 4 == 0) && Regex.IsMatch(command.Thumbnailbase64, @"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.None)))
                {
                    throw new ValidationException(new ValidationFailure("Thumbnail", $"Invalid base64"));
                }
            }

            if (command.FileUrl != null)
            {
                if (command.FileUrl.Length > 0)
                {
                    if (!(command.FileUrl.ContentType == "application/pdf" || command.FileUrl.ContentType == "video/mp4"))
                    {
                        throw new ValidationException(new ValidationFailure("FileUrl", $"Invalid FileUrl! Please select .pdf or .mp4 file"));
                    }
                }
                else
                {
                    throw new ValidationException(new ValidationFailure("FileUrl", $"FileUrl is required"));
                }
            }

            try
            {
                TutorialId = await _context.Tutorials.Add(new Domain.Entities.Tutorial
                {
                    TutorialName = command.TutorialName,
                    ShortDescription = command.ShortDescription,
                    TutorialCategoryId = (int)command.Category
                });
                string filename = "";
                string Azurefileurl = "";
                #region upload thumbnail over Azure

                if (!string.IsNullOrEmpty(command.Thumbnailbase64))
                {
                     filename = TutorialId + "_tutorialthumbnail" + "_" + UniqueIdGenerator.Generate() + "_Thumbnail.jpeg";
                     Azurefileurl = await SaveImage(command.Thumbnailbase64, filename);
                    if (!string.IsNullOrEmpty(Azurefileurl))
                    {
                        await _context.Tutorials.UpdateThumbnail(Azurefileurl, TutorialId);
                    }
                }
                
                #endregion
                #region upload file over Azure

                if (command.FileUrl != null)
                {
                    if (command.FileUrl.Length > 0)
                    {
                        if (command.FileUrl.ContentType == "application/pdf" || command.FileUrl.ContentType == "video/mp4")
                        {
                            filename = TutorialId + "_tutorialfile" + "_" + UniqueIdGenerator.Generate() + Path.GetExtension(command.FileUrl.FileName);

                            using (MemoryStream ms = new())
                            {
                                command.FileUrl.CopyTo(ms);
                                byte[] fileBytes = ms.ToArray();
                                string s = Convert.ToBase64String(fileBytes);

                                Azurefileurl = await SaveFile(s, filename, command.FileUrl.ContentType);

                            }

                            if (!string.IsNullOrEmpty(Azurefileurl))
                            {
                                await _context.Tutorials.UpdateFile(Azurefileurl, TutorialId);
                            }
                        }
                    }
                }
                #endregion
                _context.Commit();
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                _context.Rollback();
                throw;
            }

            _logger.TraceExitMethod(nameof(Handle), TutorialId);

            int tutorial = await Task.FromResult(TutorialId);
            return new ResponseModel() { Success = true, Message = "Success" };
        }

        private async Task<string> SaveFile(string base64file, string filename, string contenttype)
        {
            await storageService.UploadBlobBase64(base64file, filename, contenttype);
            Blob res = await storageService.GetFile(filename);
            return res != null ? res.StorageUri : string.Empty;
        }
        private async Task<string> SaveImage(string base64image, string filename)
        {
            await storageService.UploadBlob(base64image, filename);
            Blob res = await storageService.GetFile(filename);
            return res != null ? res.StorageUri : string.Empty;
        }
    }
}
