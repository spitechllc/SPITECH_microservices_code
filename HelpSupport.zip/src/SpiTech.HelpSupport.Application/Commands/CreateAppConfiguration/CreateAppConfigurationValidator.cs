﻿using FluentValidation;

namespace SpiTech.HelpSupport.Application.Commands.CreateAppConfiguration
{
    public class CreateAppConfigurationValidator : AbstractValidator<CreateAppConfigurationCommand>
    {
        public CreateAppConfigurationValidator()
        {
            //RuleFor(x => x.SupportNo).NotNull().WithMessage("SupportNo is required").Length(1, 20);
            //RuleFor(x => x.SupportEmail).NotNull().WithMessage("SupportEmail is required").Length(1, 50);
            RuleFor(s => s.SupportNo).NotNull().NotEmpty().MaximumLength(20).WithMessage("SupportNo is required");
            RuleFor(s => s.SupportEmail).NotNull().NotEmpty().MaximumLength(100).WithMessage("SupportEmail is required");
        }
    }
}
