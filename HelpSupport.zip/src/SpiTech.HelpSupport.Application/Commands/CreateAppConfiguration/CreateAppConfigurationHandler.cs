﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.HelpSupport.Application.UnitOfWorks;
using SpiTech.Service.Clients.Notifications;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using ResponseModel = SpiTech.ApplicationCore.Domain.Models.ResponseModel;

namespace SpiTech.HelpSupport.Application.Commands.CreateAppConfiguration
{
    public class CreateAppConfigurationHandler : IRequestHandler<CreateAppConfigurationCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateAppConfigurationHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IStorageService storageService;
        private readonly INotificationServiceClient _notificationApiClient;

        public CreateAppConfigurationHandler(IUnitOfWork context,
                                   ILogger<CreateAppConfigurationHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper,
                                   IStorageServiceFactory storageServiceFactory,
                                   INotificationServiceClient notificationApiClient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            storageService = storageServiceFactory.Get(ContainerType.AccountSupport);
            _notificationApiClient = notificationApiClient;
        }

        public async Task<ResponseModel> Handle(CreateAppConfigurationCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            System.Collections.Generic.IEnumerable<Domain.Entities.AppConfiguration> appconfiguration = await _context.AppConfigurations.GetAll();
            if (appconfiguration.Count() > 0)
            {

                throw new ValidationException(new ValidationFailure("SupportDetails", $"SupportDetails already exist! New details can not be inserted!"));
            }

            if (!string.IsNullOrEmpty(command.EmailBannerbase64))
            {
                if (!((command.EmailBannerbase64.Length % 4 == 0) && Regex.IsMatch(command.EmailBannerbase64, @"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.None)))
                {
                    throw new ValidationException(new ValidationFailure("EmailBanner", $"Invalid base64"));
                }
            }

            int AppConfigId = 0;

            try
            {
                AppConfigId = await _context.AppConfigurations.Add(new Domain.Entities.AppConfiguration
                {
                    SupportNo = command.SupportNo,
                    SupportEmail = command.SupportEmail
                });

                #region upload image over Azure        

                if (!string.IsNullOrEmpty(command.EmailBannerbase64))
                {
                    string filename = AppConfigId.ToString() + "_" + UniqueIdGenerator.Generate() + "_emailbanner.jpeg";

                    string azurefileurl = await SaveImage(command.EmailBannerbase64, filename);

                    if (!string.IsNullOrEmpty(azurefileurl))
                    {
                        await _context.AppConfigurations.UpdateFile(azurefileurl);
                    }

                    //Save Email Banner in Notification
                    UpdateEmailBannerCommand updateEmailBanner = new()
                    {
                        EmailBannerPath = azurefileurl
                    };

                    await _notificationApiClient.UpdateEmailBannerAsync(updateEmailBanner);
                }
                #endregion
                _context.Commit();
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                _context.Rollback();
                throw;
            }

            _logger.TraceExitMethod(nameof(Handle), AppConfigId);
            int tutorial = await Task.FromResult(AppConfigId);

            return new ResponseModel() { Success = true, Message = "Success" };
        }

        private async Task<string> SaveImage(string base64image, string filename)
        {
            await storageService.UploadBlob(base64image, filename);
            Blob res = await storageService.GetFile(filename);
            return res != null ? res.StorageUri : string.Empty;
        }
    }
}
