﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.HelpSupport.Application.Commands.CreateAppConfiguration
{
    public class CreateAppConfigurationCommand : IRequest<ResponseModel>
    {
        public string SupportNo { get; set; }
        public string SupportEmail { get; set; }
        public string EmailBannerbase64 { get; set; }
    }
}
