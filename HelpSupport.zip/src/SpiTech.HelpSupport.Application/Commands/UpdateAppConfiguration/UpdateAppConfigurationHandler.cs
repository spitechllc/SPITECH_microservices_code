﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.HelpSupport.Application.UnitOfWorks;
using SpiTech.HelpSupport.Domain.Models;
using SpiTech.Service.Clients.Notifications;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using ResponseModel = SpiTech.ApplicationCore.Domain.Models.ResponseModel;

namespace SpiTech.HelpSupport.Application.Commands.UpdateAppConfiguration
{
    public class UpdateAppConfigurationHandler : IRequestHandler<UpdateAppConfigurationCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateAppConfigurationHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IStorageService storageService;
        private readonly INotificationServiceClient _notificationApiClient;

        public UpdateAppConfigurationHandler(IUnitOfWork context,
                                   ILogger<UpdateAppConfigurationHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper,
                                   IStorageServiceFactory storageServiceFactory,
                                   INotificationServiceClient notificationApiClient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            storageService = storageServiceFactory.Get(ContainerType.AccountSupport);
            _notificationApiClient = notificationApiClient;
        }
        public async Task<ResponseModel> Handle(UpdateAppConfigurationCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            if (command.ChangeEmailBanner)
            {
                if (!string.IsNullOrEmpty(command.EmailBannerbase64))
                {
                    if (!((command.EmailBannerbase64.Length % 4 == 0) && Regex.IsMatch(command.EmailBannerbase64, @"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.None)))
                    {
                        throw new ValidationException(new ValidationFailure("EmailBanner", $"Invalid base64"));
                    }
                }
            }

            try
            {
                AppConfigurationModel appConfigDetails = _mapper.Map<IEnumerable<AppConfigurationModel>>(await _context.AppConfigurations.GetAll()).FirstOrDefault();

                bool model = await _context.AppConfigurations.Update(new Domain.Entities.AppConfiguration
                {
                    AppConfigId = command.AppConfigId,
                    SupportNo = command.SupportNo,
                    SupportEmail = command.SupportEmail
                });
                #region upload image over Azure        
                if (command.ChangeEmailBanner)
                {
                    if (!string.IsNullOrEmpty(command.EmailBannerbase64))
                    {
                        string filename = command.AppConfigId.ToString() + "_" + UniqueIdGenerator.Generate() + "_emailbanner.jpeg";
                        string Azurefileurl = await SaveImage(command.EmailBannerbase64, filename);
                        if (!string.IsNullOrEmpty(Azurefileurl))
                        {
                            await _context.AppConfigurations.UpdateFile(Azurefileurl);                        

                        //Save Email Banner in Notification
                        UpdateEmailBannerCommand updateEmailBanner = new()
                        {
                            EmailBannerPath = Azurefileurl
                        };
                        await _notificationApiClient.UpdateEmailBannerAsync(updateEmailBanner);
                        }
                    }
                    else
                    {
                        await _context.AppConfigurations.UpdateFile("");
                    }
                }
                else
                {
                    if (appConfigDetails != null)
                    {
                        await _context.AppConfigurations.UpdateFile(appConfigDetails.EmailBanner);
                    }

                }
                #endregion

                _context.Commit();
                _logger.TraceExitMethod(nameof(Handle), model);

                return new ResponseModel() { Success = true, Message = "Success" };
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                _context.Rollback();
                throw;
            }
        }
        private async Task<string> SaveImage(string base64image, string filename)
        {
            await storageService.UploadBlob(base64image, filename);
            Blob res = await storageService.GetFile(filename);
            return res != null ? res.StorageUri : string.Empty;
        }
    }
}
