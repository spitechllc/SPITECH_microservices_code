﻿using FluentValidation;

namespace SpiTech.HelpSupport.Application.Commands.UpdateAppConfiguration
{
    public class UpdateAppConfigurationValidator : AbstractValidator<UpdateAppConfigurationCommand>
    {
        public UpdateAppConfigurationValidator()
        {
            RuleFor(x => x.AppConfigId).NotNull().WithMessage("AppConfigId is required");
            RuleFor(s => s.SupportNo).NotNull().NotEmpty().MaximumLength(20).WithMessage("SupportNo is required");
            RuleFor(s => s.SupportEmail).NotNull().NotEmpty().MaximumLength(100).WithMessage("SupportEmail is required");
        }
    }
}
