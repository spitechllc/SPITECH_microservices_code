﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.HelpSupport.Application.Commands.UpdateAppConfiguration
{
    public class UpdateAppConfigurationCommand : IRequest<ResponseModel>
    {
        public int AppConfigId { get; set; }
        public string SupportNo { get; set; }
        public string SupportEmail { get; set; }
        public string EmailBannerbase64 { get; set; }
        public bool ChangeEmailBanner { get; set; }
    }
}
