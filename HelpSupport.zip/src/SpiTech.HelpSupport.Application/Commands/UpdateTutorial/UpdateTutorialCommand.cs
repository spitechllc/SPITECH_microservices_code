﻿using MediatR;
using Microsoft.AspNetCore.Http;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.HelpSupport.Domain.Enums;

namespace SpiTech.HelpSupport.Application.Commands.UpdateTutorial
{
    public class UpdateTutorialCommand : IRequest<ResponseModel>
    {
        public int TutorialId { get; set; }
        public string TutorialName { get; set; }
        public string ShortDescription { get; set; }
        public EntityTutorialCategory Category { get; set; }
        public string Thumbnailbase64 { get; set; }
        public IFormFile FileUrl { get; set; }
        public bool IsActive { get; set; } = true;
        public bool ChangeThumbnail { get; set; }
    }
}
