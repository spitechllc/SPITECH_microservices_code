﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.HelpSupport.Application.UnitOfWorks;
using SpiTech.HelpSupport.Domain.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.HelpSupport.Application.Commands.UpdateTutorial
{
    public class UpdateTutorialHandler : IRequestHandler<UpdateTutorialCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateTutorialHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IStorageService storageService;

        public UpdateTutorialHandler(IUnitOfWork context,
                                   ILogger<UpdateTutorialHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper,
                                   IStorageServiceFactory storageServiceFactory)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            storageService = storageServiceFactory.Get(ContainerType.AccountSupport);
        }

        public async Task<ResponseModel> Handle(UpdateTutorialCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            IEnumerable<TutorialModel> tutorialList = _mapper.Map<IEnumerable<TutorialModel>>(await _context.Tutorials.GetTutorialById(command.TutorialId));

            if (tutorialList == null)
            {
                throw new ValidationException(new ValidationFailure("TutorialId", $"Invalid TutorialId"));
            }
           
            if (command.ChangeThumbnail)
            {
                if (!string.IsNullOrEmpty(command.Thumbnailbase64))
                {
                    if (!((command.Thumbnailbase64.Length % 4 == 0) && Regex.IsMatch(command.Thumbnailbase64, @"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.None)))
                    {
                        throw new ValidationException(new ValidationFailure("Thumbnail", $"Invalid base64"));
                    }
                }
            }

            if (command.FileUrl != null)
            {
                if (command.FileUrl.Length > 0)
                {
                    if (!(command.FileUrl.ContentType == "application/pdf" || command.FileUrl.ContentType == "video/mp4"))
                    {
                        throw new ValidationException(new ValidationFailure("FileUrl", $"Invalid FileUrl! Please select .pdf or .mp4 file"));
                    }
                }
            }

            try
            {
                bool model = await _context.Tutorials.Update(new Domain.Entities.Tutorial
                {
                    TutorialId = command.TutorialId,
                    TutorialName = command.TutorialName,
                    ShortDescription = command.ShortDescription,
                    TutorialCategoryId = (int)command.Category,
                    IsActive = command.IsActive
                });

                string filename = "";
                string Azurefileurl = "";
                #region upload thumbnail over Azure
                if (command.ChangeThumbnail)
                {
                    if (!string.IsNullOrEmpty(command.Thumbnailbase64))
                    {
                        filename = command.TutorialId + "_tutorialthumbnail" + "_" + UniqueIdGenerator.Generate() + "_Thumbnail.jpeg";
                        Azurefileurl = await SaveImage(command.Thumbnailbase64, filename);
                        if (!string.IsNullOrEmpty(Azurefileurl))
                        {
                            await _context.Tutorials.UpdateThumbnail(Azurefileurl, command.TutorialId);
                        }
                    }
                    else
                    {
                        await _context.Tutorials.UpdateThumbnail("", command.TutorialId);
                    }
                }
                else
                {
                    await _context.Tutorials.UpdateThumbnail(tutorialList.FirstOrDefault().Thumbnail, command.TutorialId);
                }
                #endregion
                #region upload file over Azure
                if (command.FileUrl != null)
                {
                    if (command.FileUrl.Length > 0)
                    {
                        if (command.FileUrl.ContentType == "application/pdf" || command.FileUrl.ContentType == "video/mp4")
                        {
                            filename = command.TutorialId + "_tutorialfile" + "_" + UniqueIdGenerator.Generate() + Path.GetExtension(command.FileUrl.FileName);
                            using (MemoryStream ms = new())
                            {
                                command.FileUrl.CopyTo(ms);
                                byte[] fileBytes = ms.ToArray();
                                string s = Convert.ToBase64String(fileBytes);

                                Azurefileurl = await SaveFile(s, filename, command.FileUrl.ContentType);

                            }

                            if (!string.IsNullOrEmpty(Azurefileurl))
                            {
                                await _context.Tutorials.UpdateFile(Azurefileurl, command.TutorialId);
                            }
                        }
                    }

                }
                else
                {
                    await _context.Tutorials.UpdateFile(tutorialList.FirstOrDefault().FileUrl, command.TutorialId);
                }
                #endregion

                _context.Commit();

                _logger.TraceExitMethod(nameof(Handle), model);
                return new ResponseModel() { Success = true, Message = "Success" };
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                _context.Rollback();
                throw;
            }
        }
        private async Task<string> SaveFile(string content, string filename, string contenttype)
        {
            await storageService.UploadBlobBase64(content, filename, contenttype);
            Blob res = await storageService.GetFile(filename);
            return res != null ? res.StorageUri : string.Empty;
        }
        private async Task<string> SaveImage(string base64image, string filename)
        {
            await storageService.UploadBlob(base64image, filename);
            Blob res = await storageService.GetFile(filename);
            return res != null ? res.StorageUri : string.Empty;
        }

    }
}
