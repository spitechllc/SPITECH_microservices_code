﻿using FluentValidation;

namespace SpiTech.HelpSupport.Application.Commands.UpdateTutorial
{
    public class UpdateTutorialValidator : AbstractValidator<UpdateTutorialCommand>
    {
        public UpdateTutorialValidator()
        {
            RuleFor(x => x.TutorialId).NotNull().WithMessage("TutorialID is required");
            RuleFor(x => x.TutorialName).NotNull().WithMessage("TutorialName is required").Length(1, 50);
            //  RuleFor(x => x.FileUrl).NotNull().WithMessage("FileUrl is required");
        }

    }
}
