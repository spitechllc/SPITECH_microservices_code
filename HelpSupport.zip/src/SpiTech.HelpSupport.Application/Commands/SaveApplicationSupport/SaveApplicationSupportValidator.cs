﻿using FluentValidation;

namespace SpiTech.HelpSupport.Application.Commands.SaveApplicationSupport
{
    public class SaveApplicationSupportValidator : AbstractValidator<SaveApplicationSupportCommand>
    {
        public SaveApplicationSupportValidator()
        {
            RuleFor(x => x.VersionNo).NotNull().NotEmpty().WithMessage("VersionNo is required").MaximumLength(10);
            RuleFor(x => x.ApplicationFeatures).NotNull().NotEmpty().WithMessage("ApplicationFeatures is required").MaximumLength(500);
            RuleFor(x => x.ApplicationType).IsInEnum();
        }
    }
}
