﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.HelpSupport.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.HelpSupport.Application.Commands.SaveApplicationSupport
{
    public class SaveApplicationSupportHandler : IRequestHandler<SaveApplicationSupportCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<SaveApplicationSupportHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IStorageService storageService;

        public SaveApplicationSupportHandler(IUnitOfWork context,
                                   ILogger<SaveApplicationSupportHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper,
                                   IStorageServiceFactory storageServiceFactory)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            storageService = storageServiceFactory.Get(ContainerType.AccountSupport);
        }

        public async Task<ResponseModel> Handle(SaveApplicationSupportCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            var result = new ResponseModel() { };

            if (command.ApplicationSupportId > 0)
            {
                var dbValue = await _context.ApplicationSupports.Get(command.ApplicationSupportId);

                if (dbValue == null)
                {
                    throw new ValidationException(new ValidationFailure("ApplicationSupportId", $"Invalid ApplicationSupportId"));
                }

                dbValue.ApplicationFeatures = command.ApplicationFeatures;
                dbValue.VersionNo = command.VersionNo;
                dbValue.ForcefullyUpdate = command.ForcefullyUpdate;
                dbValue.ApplicationType = (int)command.ApplicationType;

                await _context.ApplicationSupports.Update(dbValue);

                _context.Commit();
                result.Success = true;
            }
            else
            {
                await _context.ApplicationSupports.Add(new Domain.Entities.ApplicationSupport
                {
                    ApplicationFeatures = command.ApplicationFeatures,
                    ApplicationType = (int)command.ApplicationType,
                    VersionNo = command.VersionNo,
                    VersionUpdateDate = System.DateTime.UtcNow,
                    ForcefullyUpdate = command.ForcefullyUpdate,
                    IsActive = true
                });

                _context.Commit();
                result.Success = true;
            }

            _logger.TraceExitMethod(nameof(Handle), command);

            return result;
        }
    }
}
