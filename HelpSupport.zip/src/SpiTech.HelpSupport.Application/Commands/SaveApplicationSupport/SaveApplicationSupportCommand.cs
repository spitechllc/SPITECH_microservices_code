﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents.Enums;

namespace SpiTech.HelpSupport.Application.Commands.SaveApplicationSupport
{
    public class SaveApplicationSupportCommand : IRequest<ResponseModel>
    {
        public int ApplicationSupportId { get; set; }
        public string VersionNo { get; set; }
        public string ApplicationFeatures { get; set; }
        public DeviceType ApplicationType { get; set; }
        public bool ForcefullyUpdate { get; set; }
    }
}
