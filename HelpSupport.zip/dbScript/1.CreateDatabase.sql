IF NOT EXISTS(SELECT * FROM sys.databases WHERE name = 'SpiTech_HelpSupport')
  BEGIN
    CREATE DATABASE [SpiTech_HelpSupport]
 END
GO

USE [SpiTech_HelpSupport]