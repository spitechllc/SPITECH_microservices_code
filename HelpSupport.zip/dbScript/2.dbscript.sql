CREATE TABLE [dbo].[AppConfiguration]
(
	  [AppConfigId] INT NOT NULL IDENTITY(1,1)
	, [SupportNo] VARCHAR(20) NOT NULL
	, [SupportEmail] VARCHAR(100) NOT NULL
	, [EmailBanner] NVARCHAR(500) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_AppConfiguration] PRIMARY KEY ([AppConfigId] ASC)
)

GO
CREATE TABLE [dbo].[TutorialCategory]
(
	  [TutorialCategoryId] INT NOT NULL IDENTITY(1,1)
	, [TutorialCategoryName] VARCHAR(100) NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_TutorialCategory] PRIMARY KEY ([TutorialCategoryId] ASC)
)

GO
CREATE TABLE [dbo].[Tutorial]
(
	  [TutorialId] INT NOT NULL IDENTITY(1,1)
	, [TutorialName] VARCHAR(50) NOT NULL
	, [ShortDescription] VARCHAR(200) NULL
	, [TutorialCategoryId] INT NULL
	, [Thumbnail] NVARCHAR(500) NULL
	, [FileUrl] NVARCHAR(500) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Tutorial] PRIMARY KEY ([TutorialId] ASC)
)

ALTER TABLE [dbo].[Tutorial] WITH CHECK ADD CONSTRAINT [FK_Tutorial_TutorialCategory] FOREIGN KEY([TutorialCategoryId]) REFERENCES [dbo].[TutorialCategory] ([TutorialCategoryId])
ALTER TABLE [dbo].[Tutorial] CHECK CONSTRAINT [FK_Tutorial_TutorialCategory]


GO
CREATE TABLE [dbo].[ApplicationSupport]
(
	  [ApplicationSupportId] INT NOT NULL IDENTITY(1,1)
	, [VersionNo] [VARCHAR](10) NULL
	, [VersionUpdateDate] [DATETIME] NULL
	, [ApplicationFeatures] [VARCHAR](500) NULL
	, [ApplicationType] [INT] NULL
	, [ForcefullyUpdate] [BIT] NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL	
	, CONSTRAINT [PK_ApplicationSupport] PRIMARY KEY ([ApplicationSupportId] ASC)
)
GO