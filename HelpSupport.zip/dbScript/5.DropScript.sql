Drop TABLE [dbo].[Tutorial]
Drop TABLE [dbo].[TutorialCategory]
Drop TABLE [dbo].[AppConfiguration]
Drop Table [dbo].[ApplicationSupport]