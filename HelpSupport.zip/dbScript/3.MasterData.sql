GO
SET IDENTITY_INSERT [dbo].[TutorialCategory] ON 
GO
INSERT INTO [dbo].[TutorialCategory] ([TutorialCategoryId], [TutorialCategoryName], [IsActive], [CreatedOn])
VALUES
(1, N'User Sign Up', 1, Getutcdate()),
(2, N'User Profile', 1, Getutcdate()),
(3, N'Payment Method', 1, Getutcdate()),
(4, N'Pay at Pump', 1, Getutcdate()),
(5, N'Pay in Store', 1, Getutcdate()),
(6, N'Loyalty', 1, Getutcdate());
GO
SET IDENTITY_INSERT [dbo].[TutorialCategory] OFF
GO

GO
SET IDENTITY_INSERT [dbo].[ApplicationSupport] ON 
GO
INSERT INTO [dbo].[ApplicationSupport]
           (ApplicationSupportId
		   ,[VersionNo]
           ,[VersionUpdateDate]
           ,[ApplicationFeatures]
           ,[ApplicationType]
           ,[ForcefullyUpdate]
           ,[IsActive]
           ,[CreatedOn])
VALUES
(1, N'1.5', Getutcdate(),N'Notification release', 1,0,1, Getutcdate()),
(2, N'1.5', Getutcdate(),N'Notification release', 2,0,1, Getutcdate());
GO
SET IDENTITY_INSERT [dbo].[ApplicationSupport] OFF
GO

