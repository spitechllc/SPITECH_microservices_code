
-------3 Nov 2023
alter table [Tutorial]
add TenantName varchar(100)