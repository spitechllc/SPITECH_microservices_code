﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Finance.Application.Commands.AcceptAmountTransferRequest;
using SpiTech.Finance.Application.Commands.DeclineAmountTransferRequest;
using SpiTech.Finance.Application.Commands.RequestAmountTransfer;
using SpiTech.Finance.Application.Commands.WalletCredits;
using SpiTech.Finance.Application.Commands.WalletLinkUserTransfer;
using SpiTech.Finance.Application.Commands.WalletPreauthPayment;
using SpiTech.Finance.Application.Commands.WalletProcessPayment;
using SpiTech.Finance.Application.Commands.WalletVoidPayment;
using SpiTech.Finance.Application.Queries.GetCashRewardDetailsByFilter;
using SpiTech.Finance.Application.Queries.GetCashRewardDetailsByTransactionIds;
using SpiTech.Finance.Application.Queries.GetConsumersRewardDetailsDashboard;
using SpiTech.Finance.Application.Queries.GetConsumerWalletDetail;
using SpiTech.Finance.Application.Queries.GetExpiredWalletCredits;
using SpiTech.Finance.Application.Queries.GetExpiringWalletCredits;
using SpiTech.Finance.Application.Queries.GetLinkUserTransfer;
using SpiTech.Finance.Application.Queries.GetPendingAmountTransferRequestsByUserId;
using SpiTech.Finance.Application.Queries.GetReceivedWalletCredit;
using SpiTech.Finance.Application.Queries.GetRequestedAmountsByUserId;
using SpiTech.Finance.Application.Queries.GetRewardDetailsDashboard;
using SpiTech.Finance.Application.Queries.GetTransferedWalletCredits;
using SpiTech.Finance.Application.Queries.GetUserWallet;
using SpiTech.Finance.Application.Queries.GetUserWalletByIds;
using SpiTech.Finance.Application.Queries.GetWalletCreditByTransactionId;
using SpiTech.Finance.Application.Queries.GetWalletCreditByTransactionIds;
using SpiTech.Finance.Application.Queries.GetWalletCreditDetail;
using SpiTech.Finance.Application.Queries.GetWalletCreditsByStoreId;
using SpiTech.Finance.Application.Queries.GetWalletDetail;
using SpiTech.Finance.Application.Queries.GetWalletDetailsByUserId;
using SpiTech.Finance.Application.Queries.GetWalletDetailsList;
using SpiTech.Finance.Application.Queries.GetWalletHistory;
using SpiTech.Finance.Domain.Entities;
using SpiTech.Finance.Domain.Models;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace SpiTech.Finance.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class WalletController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IUserAuthenticationProvider _authenticationProvider;
        private readonly ILogger<WalletController> _logger;
        private readonly IStringLocalizer<WalletController> _localizer;

        public WalletController(IMediator mediator,
            IUserAuthenticationProvider authenticationProvider,
        ILogger<WalletController> logger, IStringLocalizer<WalletController> localizer)
        {
            _mediator = mediator;
            _authenticationProvider = authenticationProvider;
            _logger = logger;
            _localizer = localizer;
        }

        /// <summary>
        /// Api used to credit user wallet by admin
        /// </summary>
        /// <param name="command">Object of WalletCreditCommand</param>
        /// <returns>It will return ResponseModel in the form of List of WalletCreditModel</returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_AdminCredit")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("AdminCredit")]
        public async Task<ActionResult<ResponseModel<List<WalletCreditModel>>>> AdminCredit([FromBody] WalletCreditCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Api used for transfer wallet amount to link user
        /// </summary>
        /// <param name="command">Object of WalletLinkUserTransferCommand</param>
        /// <returns>It will return ResponseModel in the form of WalletDebitModel</returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_Transfer")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("Transfer")]
        public async Task<ActionResult<ResponseModel<WalletDebitModel>>> Transfer([FromBody] WalletLinkUserTransferCommand command)
        {
            ResponseModel res = await _mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// Returns user wallet details by user id
        /// </summary>
        /// <param name="query">object of GetUserWalletQuery</param>   
        /// <returns>It will return ResponseModel in the form of UserWalletModel</returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_GetUserWallet")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetUserWallet")]
        public async Task<ActionResult<ResponseModel<UserWalletModel>>> GetUserWallet([FromQuery] GetUserWalletQuery query)
        {
            UserWalletModel result = await _mediator.Send(query).ConfigureAwait(false);
            return Ok(new ResponseModel<UserWalletModel> { Data = result, Success = result != null });
        }

        /// <summary>
        /// Returns list of link user transfer details
        /// </summary>
        /// <param name="query">object of GetLinkUserTransferQuery</param>
        /// <returns>It will return ResponseList in the form of LinkMemberTransfer</returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_GetLinkUserTransfer")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetLinkUserTransfer")]
        public async Task<ActionResult<ResponseList<LinkMemberTransfer>>> GetLinkUserTransfer([FromQuery] GetLinkUserTransferQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns list of wallet credit amount which expires within given days
        /// </summary>
        /// <param name="query">object of GetExpiringWalletCreditsQuery</param>
        /// <returns>It will return ResponseList in the form of WalletCredit</returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_GetExpiringWalletCredits")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetExpiringWalletCredits")]
        public async Task<ActionResult<ResponseList<WalletCredit>>> GetExpiringWalletCredits([FromQuery] GetExpiringWalletCreditsQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns list of wallet amount that expired
        /// </summary>
        /// <param name="query">Object of GetExpiredWalletCreditsQuery</param>
        /// <returns>It will return ResponseList in the form of WalletCredit</returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_GetExpiredWalletCredits")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetExpiredWalletCredits")]
        public async Task<ActionResult<ResponseList<WalletCredit>>> GetExpiredWalletCredits([FromQuery] GetExpiredWalletCreditsQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Return List of wallet credit details by transaction id
        /// </summary>
        /// <param name="query">Object of GetWalletCreditByTransactionIdQuery</param>
        /// <returns>It will return ResponseList in the form of WalletCreditSearchModel</returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_GetWalletCreditByTransactionId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetWalletCreditByTransactionId")]
        public async Task<ActionResult<ResponseList<WalletCreditSearchModel>>> GetWalletCreditByTransactionId([FromQuery] GetWalletCreditByTransactionIdQuery query)
        {
            IEnumerable<WalletCreditSearchModel> result = await _mediator.Send(query).ConfigureAwait(false);

            return Ok(new ResponseList<WalletCreditSearchModel> { Data = result });
        }

        /// <summary>
        /// Returns Collection of wallet credit debit details of consumer by id
        /// </summary>
        /// <param name="model">object of GetWalletHistoryQueryModel</param>
        /// <returns>It will return PaginatedList in the form of WalletHistoryModel</returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_GetWalletHistory")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetWalletHistory")]
        public async Task<ActionResult<PaginatedList<WalletHistoryModel>>> GetWalletHistory([FromQuery] GetWalletHistoryQueryModel model)
        {
            GetWalletHistoryQuery query = new GetWalletHistoryQuery();
            query.UserId = model.UserId;
            query.PageIndex = model.PageIndex;
            query.PageSize = model.PageSize;

            if (!string.IsNullOrWhiteSpace(Request.Headers["accept-language"]))
            {
                query.culture = Request.Headers["accept-language"].ToString();
            }
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns details of wallet credit debit at any store
        /// </summary>
        /// <param name="query">object of GetWalletCreditsByStoreIdQuery</param>
        /// <returns>It will return ResponseModel in the form of WalletCredit</returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_GetWalletCreditsByStoreId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetWalletCreditsByStoreId")]
        public async Task<ActionResult<ResponseModel<WalletCredit>>> GetWalletCreditsByStoreId([FromQuery] GetWalletCreditsByStoreIdQuery query)
        {
            WalletCredit result = await _mediator.Send(query).ConfigureAwait(false);

            return Ok(new ResponseModel<WalletCredit> { Data = result, Success = result != null });
        }

        /// <summary>
        /// Returns list of wallet credit transfered by user id
        /// </summary>
        /// <param name="query">object of GetTransferedWalletCreditsQuery</param>
        /// <returns>It will return ResponseList in the form of WalletTransferCreditModel</returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_GetTransferWalletCreditsByUserId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetTransferWalletCreditsByUserId")]
        public async Task<ActionResult<ResponseList<WalletTransferCreditModel>>> GetTransferWalletCreditsByUserId([FromQuery] GetTransferedWalletCreditsQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns List of wallet credit received by user id
        /// </summary>
        /// <param name="query">object of GetReceivedWalletCreditQuery</param>
        /// <returns>It will return ResponseList in the form of WalletTransferCreditModel</returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_GetReceivedWalletCreditsByUserId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetReceivedWalletCreditsByUserId")]
        public async Task<ActionResult<ResponseList<WalletTransferCreditModel>>> GetReceivedWalletCreditsByUserId([FromQuery] GetReceivedWalletCreditQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to request amount transfer from link user
        /// </summary>
        /// <param name="command">object of RequestAmountTransferCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_RequestAmountTransfer")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("RequestAmountTransfer")]
        public async Task<ActionResult<ResponseModel>> RequestAmountTransfer([FromBody] RequestAmountTransferCommand command)
        {
            ResponseModel res = await _mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// Api to decline amount transfer request by link userr
        /// </summary>
        /// <param name="command">object of DeclineAmountTransferRequestCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_DeclineAmountTransfer")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("DeclineAmountTransfer")]
        public async Task<ActionResult<ResponseModel>> DeclineAmountTransfer([FromBody] DeclineAmountTransferRequestCommand command)
        {
            ResponseModel res = await _mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// Api to accept amount transfer request from link user
        /// </summary>
        /// <param name="command">object of AcceptAmountTransferRequestCommand</param>
        /// <returns>It will return ResponseModel in the form of WalletDebitModel</returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_AcceptAmountTransferRequest")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("AcceptAmountTransferRequest")]
        public async Task<ActionResult<ResponseModel<WalletDebitModel>>> AcceptAmountTransfer([FromBody] AcceptAmountTransferRequestCommand command)
        {
            ResponseModel res = await _mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// Returns List of amount transfer requests by linked users
        /// </summary>
        /// <param name="query">object of GetRequestedAmountsByUserIdQuery</param>
        /// <returns>It will return ResponseList in the form of LinkMemberTransferModel</returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_GetRequestedAmountListByUserId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetRequestedAmountListByUserId")]
        public async Task<ActionResult<ResponseList<LinkMemberTransferModel>>> GetRequestedAmountListByUserId([FromQuery] GetRequestedAmountsByUserIdQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns list of amount transfer request pending to perform an action (i.e. accept or decline)
        /// </summary>
        /// <param name="query">object of GetPendingAmountTransferRequestsByUserIdQuery</param>
        /// <returns>It will return ResponseList in the form of LinkMemberTransferModel</returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_GetPendingAmountTransferRequestsByUserId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetPendingAmountTransferRequestsByUserId")]
        public async Task<ActionResult<ResponseList<LinkMemberTransferModel>>> GetPendingAmountTransferRequestsByUserId([FromQuery] GetPendingAmountTransferRequestsByUserIdQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns List of Users wallet
        /// </summary>
        /// <param name="query">object of GetUserWalletByIdsQuery</param>
        /// <returns>It will return ResponseList in the form of UserWalletModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_GetUserWalletList")]
        [HttpGet("GetUserWalletList")]
        public async Task<ActionResult<ResponseList<UserWalletModel>>> GetUserWalletList([FromQuery] GetUserWalletByIdsQuery query)
        {
            return Ok(new ResponseList<UserWalletModel> { Data = await _mediator.Send(query).ConfigureAwait(false) });
        }

        /// <summary>
        /// Returns List of cashreward given by a store
        /// </summary>
        /// <param name="query">object of GetCashRewardDetailsByFilterQuery</param>
        /// <returns>It will return List in the form of CashRewardModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_GetCashRewardDetailsByStoreId")]
        [HttpPost("GetCashRewardDetailsByStoreId")]
        public async Task<ActionResult<List<CashRewardModel>>> GetCashRewardDetailsByStoreId([FromBody] GetCashRewardDetailsByFilterQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns list of cash reward by transaction ids
        /// </summary>
        /// <param name="query">object of GetCashRewardDetailsByTransacionIdsQuery</param>
        /// <returns>It will return List in the form of TransactionCashRewardModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_GetCashRewardDetailsByTransactionIds")]
        [HttpPost("GetCashRewardDetailsByTransactionIds")]
        public async Task<ActionResult<List<TransactionCashRewardModel>>> GetCashRewardDetailsByTransactionIds([FromBody] GetCashRewardDetailsByTransacionIdsQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to do pre auth for payment from wallet
        /// </summary>
        /// <param name="command">object of WalletPreauthPaymentCommand</param>
        /// <returns>It will return ResponseModel in the form of WalletPreauthDebitModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_PreAuthPayment")]
        [HttpPost("PreAuthPayment")]
        public async Task<ActionResult<ResponseModel<WalletPreauthDebitModel>>> PreAuthPayment([FromBody] WalletPreauthPaymentCommand command)
        {
            ResponseModel res = await _mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// Api to do final payment from wallet
        /// </summary>
        /// <param name="command">object of WalletProcessPaymentCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_ProcessPayment")]
        [HttpPost("ProcessPayment")]
        public async Task<ActionResult<ResponseModel>> ProcessPayment([FromBody] WalletProcessPaymentCommand command)
        {
            ResponseModel res = await _mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// Returns list of wallet amount credit by transaction ids
        /// </summary>
        /// <param name="query">object of GetWalletCreditByTransactionIdsQuery</param>
        /// <returns>It will return ResponseList in the form of WalletCreditSearchModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_GetWalletCreditByTransactionIds")]
        [HttpPost("GetWalletCreditByTransactionIds")]
        public async Task<ActionResult<ResponseList<WalletCreditSearchModel>>> GetWalletCreditByTransactionIds([FromBody] GetWalletCreditByTransactionIdsQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to void wallet payment
        /// </summary>
        /// <param name="command">object of WalletVoidPaymentModel</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_VoidPayment")]
        [HttpPost("VoidPayment")]
        public async Task<ActionResult<ResponseModel>> VoidPayment([FromBody] WalletVoidPaymentModel command)
        {
            ResponseModel res = await _mediator.Send(new WalletVoidPaymentCommand { AuthNumber = command.AuthNumber }).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }
        /// <summary>
        /// Api to get cashreward details for dashboard
        /// </summary>
        /// <param name="model">Object of DeclineAmountTransferRequestModel</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_CashRewardDetailsForDashBoard")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("CashRewardDetailsForDashBoard")]
        public async Task<ActionResult<ResponseModel<RewardDetailsDashboardModel>>> GetCashRewardDetailsForDashBoard([FromBody] GetRewardDetailsDashboardQuery query)
        {
            ResponseModel<RewardDetailsDashboardModel> res = await _mediator.Send(query).ConfigureAwait(false);
            return Ok(res);
        }
        /// <summary>
        /// Api to get consumers reward details for dashboard
        /// </summary>
        /// <param name="model">Object of GetConsumersRewardDetailsDashboardQuery</param>
        /// <returns>It will return in the form of List</returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_ConsumersRewardDetailsForDashBoard")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("ConsumersRewardDetailsForDashBoard")]
        public async Task<ActionResult<ResponseList<UserRewardDetailsModel>>> GetConsumersRewardDetailsForDashBoard([FromBody] GetConsumersRewardDetailsDashboardQuery query)
        {
            ResponseList<UserRewardDetailsModel> res = await _mediator.Send(query).ConfigureAwait(false);
            return Ok(res);
        }
        /// <summary>
        /// Api to get user wallet details with expiry reward details
        /// </summary>
        /// <param name="model">Object of GetWalletDetailsByUserIdQuery</param>
        /// <returns>It will return in the form of Responsemodel<UserWalletDetailModel></returns>
        //[ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_WalletDetailsByUserId")]
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("WalletDetailsByUserId")]
        public async Task<ActionResult<ResponseModel<UserWalletDetailModel>>> GetWalletDetailsByUserId([FromQuery] GetWalletDetailsByUserIdQuery query)
        {
            ResponseModel<UserWalletDetailModel> res = await _mediator.Send(query).ConfigureAwait(false);
            return Ok(res);
        }

        /// <summary>
        /// Get Wallet user list with walet detail
        /// </summary>
        /// <param name="userIds"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Financeapi_Wallet_GetWalletDetailsListByIds")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetWalletDetailsListByIds")]
        public async Task<ActionResult<IEnumerable<UserWalletDetailModel>>> GetWalletDetailsListByIds([FromQuery] GetWalletDetailsListByUserIdQuery query)
        {
            IEnumerable<UserWalletDetailModel> res = await _mediator.Send(query).ConfigureAwait(false);
            return Ok(res);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("WalletCreditDetail")]
        public async Task<ActionResult<PaginatedList<WalletCreditDetailModel>>> WalletCreditDetail([FromQuery] GetWalletCreditDetailQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("ConsumerWalletDetail")]
        public async Task<ActionResult<PaginatedList<ConsumerWalletDetailModel>>> ConsumerWalletDetail([FromQuery] GetConsumerWalletDetailQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }


        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("WalletDetails")]
        public async Task<ActionResult<IEnumerable<UserWalletDetailModel>>> WalletDetails()
        {
            GetWalletDetailsQuery query= new GetWalletDetailsQuery ();
            IEnumerable<UserWalletDetailModel> res = await _mediator.Send(query).ConfigureAwait(false);
            return Ok(res);
        }
    }
} 
