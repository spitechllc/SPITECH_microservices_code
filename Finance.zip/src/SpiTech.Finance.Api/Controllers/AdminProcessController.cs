﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Application.Commands.AdminCredit;
using SpiTech.Finance.Application.Commands.AdminDebit;
using SpiTech.Finance.Application.Queries.GetAdminCredits;
using SpiTech.Finance.Application.Queries.GetAdminDebits;
using SpiTech.Finance.Domain.Entities;
using SpiTech.Finance.Domain.Models;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Finance.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class AdminProcessController : ControllerBase
    {
        private readonly IMediator _mediator;

        public AdminProcessController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Api used to credit user wallet by admin
        /// </summary>
        /// <param name="command">object of AdminCreditCommand</param>
        /// <returns>It will return ResponseModel in the form of List of WalletCredit</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "Financeapi_AdminProcess_Credit")]
        [HttpPost("Credit")]
        public async Task<ActionResult<ResponseModel<List<WalletCredit>>>> AdminCredit([FromBody] AdminCreditCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Api used to debit user wallet by admin
        /// </summary>
        /// <param name="command">Object of AdminDebitCommand</param>
        /// <returns>It will return ResponseModel in the form of WalletDebitModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "Financeapi_AdminProcess_Debit")]
        [HttpPost("Debit")]
        public async Task<ActionResult<ResponseModel<WalletDebitModel>>> AdminDebit([FromBody] AdminDebitCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns collection of wallet credits by admin
        /// </summary>
        /// <param name="query">Object of GetAdminCreditsQuery</param>
        /// <returns>It will return ResponseList in the form of WalletCredit</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "Financeapi_AdminProcess_GetAdminCredit")]
        [HttpGet("GetAdminCredit")]
        public async Task<ActionResult<ResponseList<WalletCredit>>> GetAdminCredit([FromQuery] GetAdminCreditsQuery query)
        {
            ResponseList<WalletCredit> result = await _mediator.Send(query).ConfigureAwait(false);

            return Ok(result);
        }

        /// <summary>
        /// Returns collection of wallet debits by admin
        /// </summary>
        /// <param name="query">Object of GetAdminDebitsQuery</param>
        /// <returns>It will return ResponseList in the form of WalletDebit</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "Financeapi_AdminProcess_GetAdminDebit")]
        [HttpGet("GetAdminDebit")]
        public async Task<ActionResult<ResponseList<WalletDebit>>> GetAdminDebit([FromQuery] GetAdminDebitsQuery query)
        {
            ResponseList<WalletDebit> result = await _mediator.Send(query).ConfigureAwait(false);

            return Ok(result);
        }
    }
}
