using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using SpiTech.Application.Logging.Extensions;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.ApplicationCore.Security;
using SpiTech.ApplicationCore.ServiceCollection;
using SpiTech.Finance.Application;
using SpiTech.Finance.Application.Services;
using SpiTech.Finance.Infrastructure;
using SpiTech.Service.Clients;

namespace SpiTech.Finance.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddLocalization(options => options.ResourcesPath = "Resources");
            services.AddHostedService<ExpiringWalletCreditBackgroundService>();

            services.AddIdentityClient(Configuration);
            services.AddStoreClient(Configuration);
            services.AddNotificationClient(Configuration);

            services.AddApplicationCore(Configuration)
                .AddInfrastructure(Configuration)
                .AddApplication(Configuration);

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "Finance Api",
                    Version = "v1",
                    Description = "The Finance Microservice HTTP API.",
                });
                SwaggerGenSetup.Setup(options);
            });

            services.AddAPIAuthentication(Configuration, "financeapi");
            services.AddAPIAuthorization();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseMiddleware(typeof(CustomResponseHeaderMiddleware));
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            var supportedCultures = new[] { "en", "es" };

            var requestLocalizationOptions = new RequestLocalizationOptions().SetDefaultCulture(supportedCultures[0]).AddSupportedCultures(supportedCultures).AddSupportedUICultures(supportedCultures);

            app.UseRequestLocalization(requestLocalizationOptions);

            app.UseSwagger().UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "SpiTech.Finance.Api V1");
            });

            app.UseLogger();
            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();
            
            app.UseMiniProfiler();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
