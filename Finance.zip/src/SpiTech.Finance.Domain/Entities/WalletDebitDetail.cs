﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Finance.Domain.Entities
{
    [Table("[WalletDebitDetail]")]
    public class WalletDebitDetail : BaseEntity
    {
        [Key]
        public long WalletDebitDetailId { get; set; }
        public long FromWalletCreditId { get; set; }
        public long WalletDebitId { get; set; }
        public decimal Amount { get; set; }
    }
}
