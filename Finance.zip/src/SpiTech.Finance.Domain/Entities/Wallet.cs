﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.Finance.Domain.Entities
{
    [Table("[Wallet]")]
    public class Wallet : BaseEntity
    {
        [Key]
        public int WalletId { get; set; }
        public int UserId { get; set; }
        public bool IsTransactionLock { get; set; }
        public DateTime? TransactionLockOn { get; set; }
        public string TransactionLockId { get; set; }
    }
}
