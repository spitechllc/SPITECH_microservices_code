﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.Finance.Domain.Entities
{
    [Table("[LinkMemberTransfer]")]
    public class LinkMemberTransfer : BaseEntity
    {
        [Key]
        public int LinkMemberTransferId { get; set; }
        public int FromUserId { get; set; }
        public int ToUserId { get; set; }
        public decimal TransferAmount { get; set; }
        public int TransferStatusId { get; set; }
        public DateTime? RequestedDate { get; set; }
        public DateTime? ActionDate { get; set; }
    }
}
