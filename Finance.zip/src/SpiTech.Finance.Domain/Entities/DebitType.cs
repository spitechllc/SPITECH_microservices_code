﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Finance.Domain.Entities
{
    [Table("[DebitType]")]
    public class DebitType : BaseEntity
    {
        [Key]
        public int DebitTypeId { get; set; }
        public string Name { get; set; }
    }
}
