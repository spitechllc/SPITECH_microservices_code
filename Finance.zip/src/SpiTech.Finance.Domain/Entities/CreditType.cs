﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Finance.Domain.Entities
{
    [Table("[CreditType]")]
    public class CreditType : BaseEntity
    {
        [Key]
        public int CreditTypeId { get; set; }
        public string Name { get; set; }
    }
}
