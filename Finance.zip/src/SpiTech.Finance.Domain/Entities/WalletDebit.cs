﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.Finance.Domain.Entities
{
    [Table("[WalletDebit]")]
    public class WalletDebit : BaseEntity
    {
        [Key]
        public long WalletDebitId { get; set; }
        public int WalletId { get; set; }
        public string AuthNumber { get; set; }
        public decimal Amount { get; set; }
        public decimal WalletBalanceAmount { get; set; }
        public int? StoreId { get; set; }
        public string StoreName { get; set; }
        public long? TransactionId { get; set; }
        public string TransactionDesc { get; set; }
        public int? LinkMemberTransferId { get; set; }
        public DateTime DebitDate { get; set; }
        public bool IsRefunded { get; set; }
        public DateTime? RefundDate { get; set; }
        public int DebitTypeId { get; set; }
        public int DebitStateId { get; set; }
        public string Error { get; set; }
        public string TransactionLockId { get; set; }
        public string NotificationTypeIdentifier { get; set; }
    }
}
