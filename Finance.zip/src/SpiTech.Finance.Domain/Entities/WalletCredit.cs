﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.Finance.Domain.Entities
{
    [Table("[WalletCredit]")]
    public class WalletCredit : BaseEntity
    {
        [Key]
        public long WalletCreditId { get; set; }
        public int WalletId { get; set; }
        public decimal CreditAmount { get; set; }
        public decimal CurrentAmount { get; set; }
        public decimal? TransactionAmount { get; set; }
        public int? StoreId { get; set; }
        public string StoreName { get; set; }
        public long? TransactionId { get; set; }
        public string TransactionDesc { get; set; }
        public int? TransactionTypeId { get; set; }
        public int? UserPaymentMethodId { get; set; }
        public int? PaymentMethodId { get; set; }
        public int? LinkMemberTransferId { get; set; }
        public long? FromWalletCreditId { get; set; }
        public int CreditTypeId { get; set; }
        public int? CreditIdentifier { get; set; }
        public DateTime CreditDate { get; set; }
        public DateTime? ExpireDate { get; set; }
        public bool IsRefunded { get; set; }
        public DateTime? RefundDate { get; set; }
        public DateTime? LastNotificationSentDate { get; set; }
        public string NotificationTypeIdentifier { get; set; }
        public int? TransactionCount { get; set; }
    }
}
