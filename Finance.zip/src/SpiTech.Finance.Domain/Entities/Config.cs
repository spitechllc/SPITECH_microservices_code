﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.Finance.Domain.Entities
{
    [Table("[Config]")]
    public class Config : BaseEntity
    {
        [Key]
        public int ConfigId { get; set; }
        public DateTime LastExecutionTime { get; set; }
    }
}
