﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Finance.Domain.Entities
{
    [Table("[TransferStatus]")]
    public class TransferStatus : BaseEntity
    {
        [Key]
        public int TransferStatusId { get; set; }
        public int Name { get; set; }
    }
}
