﻿using SpiTech.Service.Clients.Identity;
using System;

namespace SpiTech.Finance.Domain.Models
{

    public class LinkMemberTransferModel
    {

        public int LinkMemberTransferId { get; set; }
        public int FromUserId { get; set; }
        public int ToUserId { get; set; }
        public decimal TransferAmount { get; set; }
        public int TransferStatus { get; set; }
        public DateTime? RequestedDate { get; set; }
        public DateTime? ActionDate { get; set; }
        public string TransferStatusName { get; set; }
        public UserModel UserDetails { get; set; }

    }
}
