﻿using MediatR;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Finance.Domain.Models;

namespace SpiTech.Finance.Domain.Models
{
    public class GetWalletHistoryQueryModel 
    {
        public int UserId { get; set; }
        public int? PageIndex { get; set; }
        public int? PageSize { get; set; }
        
    }
}
