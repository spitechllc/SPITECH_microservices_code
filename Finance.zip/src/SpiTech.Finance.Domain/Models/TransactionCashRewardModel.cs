﻿namespace SpiTech.Finance.Domain.Models
{
    public class TransactionCashRewardModel
    {
        public int StoreId { get; set; }
        public decimal TotalEarned { get; set; }
        public decimal TotalRedeemed { get; set; }
        public long TransactionId { get; set; }
        public decimal CashRewardBalance { get; set; }
    }
}
