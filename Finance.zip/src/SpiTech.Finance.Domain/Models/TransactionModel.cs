﻿using Newtonsoft.Json;
using System;

namespace SpiTech.Finance.Domain.Models
{
    public class TransactionModel
    {
        public long TransactionId { get; set; }
        public string UMTI { get; set; }
        public string SiteId { get; set; }
        public string MerchantId { get; set; }
        public int UserId { get; set; }
        public string DeviceToken { get; set; }
        public string AppType { get; set; }
        public int? FuelingPositionId { get; set; }
        public string HostMPPAIdentifier { get; set; }
        public string SiteMPPAIdentifier { get; set; }
        public string POSTransNumber { get; set; }
        public string SettlementPeriodId { get; set; }
        public int? UserPaymentMethodId { get; set; }
        public string PreauthConfirmationNo { get; set; }
        public decimal PreauthAmount { get; set; }
        public decimal FinalAmount { get; set; }
        public bool IsPaymentSuccess { get; set; }
        public int StatusId { get; set; }
        public int TransactionTypeId { get; set; }
        public string ReceiptNo { get; set; }
        public string PaymentUniqueIdentityfier { get; set; }
        public string TransactionInfo { get; set; }
        public string CardType { get; set; }
        public string PaymentMethod { get; set; }
        public string CardPrint { get; set; }
        public string WorkstationId { get; set; }
        public string CommanderTimeDateStamp { get; set; }
        public DateTime TransactionDate { get; set; }
        public bool IsReconciled { get; set; }
        public DateTime? ReconciledDate { get; set; }
        public DateTime? PumpReserveDate { get; set; }
        public DateTime? BeginFuelingDate { get; set; }
        public DateTime? PreAuthDate { get; set; }
        public DateTime? FinalizeDate { get; set; }
        public DateTime? ReceiptDate { get; set; }
        public DateTime? CancelDate { get; set; }
        public string PaymentErrorMessage { get; set; }
        public string MppaErrorMessage { get; set; }
        public string HostAuthNumber { get; set; }
        public int? SettlementRequestId { get; set; }
        public int? StoreBillingId { get; set; }

        [JsonIgnore]
        public int TotalRecord { get; set; }
    }
}
