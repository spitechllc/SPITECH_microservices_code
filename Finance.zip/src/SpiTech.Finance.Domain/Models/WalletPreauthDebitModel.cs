﻿namespace SpiTech.Finance.Domain.Models
{
    public class WalletPreauthDebitModel
    {
        public string AuthNumber { get; set; }
        public decimal DebitAmount { get; set; }
        public decimal BalanceAmount { get; set; }
    }
}
