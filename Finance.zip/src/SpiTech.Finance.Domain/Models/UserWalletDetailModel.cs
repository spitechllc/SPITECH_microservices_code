﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Finance.Domain.Models
{
    public class UserWalletDetailModel : RedeemAmount
    {
        public int WalletId { get; set; }
        public int UserId { get; set; }
        public decimal TotalCreditAmount { get; set; }
        public decimal TotalRedeemAmount { get; set; }
        public decimal TotalAvailableAmount { get; set; }
        public decimal TotalTransferAmount { get; set; }
        public decimal TotalReceivedAmount { get; set; }
        public decimal TotalExpiredAmount { get; set; }
        public decimal TotalPromotionalAmount { get; set; }
        public IEnumerable<UserExpiryRewardDetailsModel> ExpiryRewardDetails { get; set; }
    }
    public class UserExpiryRewardDetailsModel
    {
        public decimal CreditAmount { get; set; }
        public decimal CurrentAmount { get; set; }
        public DateTime CreditDate { get; set; }
        public DateTime? ExpireDate { get; set; }
    }
    public class RedeemAmount
    {
        public decimal TotalRedeemedAmount { get; set; }
    }
        
}
