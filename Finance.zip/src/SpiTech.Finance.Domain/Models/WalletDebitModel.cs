﻿using SpiTech.EventBus.DomainEvents.Enums;

namespace SpiTech.Finance.Domain.Models
{
    public class WalletDebitModel
    {
        public long WalletDebitId { get; set; }
        public string AuthNumber { get; set; }
        public decimal DebitAmount { get; set; }
        public decimal BalanceAmount { get; set; }
        public TransferStatus TransferStatus { get; set; }
    }
}
