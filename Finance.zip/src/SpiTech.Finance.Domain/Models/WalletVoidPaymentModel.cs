﻿namespace SpiTech.Finance.Domain.Models
{
    public class WalletVoidPaymentModel
    {
        public string AuthNumber { get; set; }
    }
}
