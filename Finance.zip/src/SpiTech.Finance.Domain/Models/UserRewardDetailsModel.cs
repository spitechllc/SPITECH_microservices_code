﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Finance.Domain.Models
{
    public class UserRewardDetailsModel
    {
        public int UserId { get; set; }
        public decimal Amount { get; set; }
        public decimal Earned { get; set; }
        public decimal Redeemed { get; set; }
        public decimal Balance { get; set; }
    }
}

