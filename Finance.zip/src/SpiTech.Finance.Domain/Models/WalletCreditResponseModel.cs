﻿namespace SpiTech.Finance.Domain.Models
{
    public class WalletCreditResponseModel
    {
        public int FromUserId { get; set; }
        public int ToUserId { get; set; }
        public decimal TransferAmount { get; set; }
        public decimal BalanceAmount { get; set; }
        public string AuthNumber { get; set; }
    }
}
