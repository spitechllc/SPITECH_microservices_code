﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Finance.Domain.Models
{
    public class RewardDetailsDashboardModel
    {
        public decimal TotalEarned { get; set; }
        public decimal TotalRedeemed { get; set; }
        public int TotalTransactions { get; set; }
        public int TotalConsumers { get; set; }
        public decimal MonthlyTotalEarned { get; set; }
        public decimal MonthlyTotalRedeemed { get; set; }
        public int MonthlyTotalTransactions { get; set; }
        public int MonthlyTotalConsumers { get; set; }
        public decimal YearlyTotalEarned { get; set; }
        public decimal YearlyTotalRedeemed { get; set; }
        public int YearlyTotalTransactions { get; set; }
        public int YearlyTotalConsumers { get; set; }
        public decimal Liability { get; set; }
        public decimal ExpiredCredit { get; set; }
        public decimal TotalEarnedPreviousMonth { get; set; }
        public decimal TotalEarnedFuel { get; set; }
        public decimal TotalEarnedStoreItemPurchase { get; set; }
        public IEnumerable<StoreRewardDetails> storeRewardDetails { get; set; }

        public decimal TotalStoreAmount { get; set; }
        public decimal TotalStoreEarned { get; set; }
        public decimal TotalStoreRedeemed { get; set; }
        public IEnumerable<MonthWiseRewardDetails> monthWiseRewardDetails { get; set; }


        public decimal MonthWiseTotalEarned { get; set; }
        public decimal MonthWiseTotalRedeemed { get; set; }

    }

    public class StoreRewardDetails
    {
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public decimal Amount { get; set; }
        public decimal Earned { get; set; }
        public decimal Redeemed { get; set; }
    }
    public class MonthWiseRewardDetails
    {
        public int Month { get; set; }
        public string MonthName { get; set; }
        public decimal Earned { get; set; }
        public decimal Redeemed { get; set; }
    }
}