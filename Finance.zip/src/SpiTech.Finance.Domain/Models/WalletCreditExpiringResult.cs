﻿using System;
using System.Text.Json.Serialization;

namespace SpiTech.Finance.Domain.Models
{
    public class WalletCreditExpiringResult
    {
        public long WalletCreditId { get; set; }
        public int WalletId { get; set; }
        public decimal CreditAmount { get; set; }
        public decimal CurrentAmount { get; set; }
        public decimal TransactionAmount { get; set; }
        public int? StoreId { get; set; }
        public long? TransactionId { get; set; }
        public string TransactionDesc { get; set; }
        public int UserPaymentMethodId { get; set; }
        public int PaymentMethodId { get; set; }
        public int CreditTypeId { get; set; }
        public DateTime CreditDate { get; set; }
        public DateTime? ExpireDate { get; set; }
        public DateTime? LastNotificationSentDate { get; set; }
        public int CreditStatusId { get; set; }
        public int UserId { get; set; }
        [JsonIgnore]
        public int TotalRecord { get; set; }
    }
}
