﻿namespace SpiTech.Finance.Domain.Models
{
    public class CashRewardModel
    {
        public int StoreId { get; set; }
        public decimal TotalEarned { get; set; }
        public decimal TotalRedeemed { get; set; }
    }
}
