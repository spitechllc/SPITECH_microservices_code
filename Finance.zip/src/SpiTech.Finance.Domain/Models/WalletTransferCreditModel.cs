﻿using SpiTech.Service.Clients.Identity;
using System;
using System.Collections.Generic;

namespace SpiTech.Finance.Domain.Models
{
    public class WalletTransferCreditModel
    {
        public int? LinkMemberTransferId { get; set; }
        public long? FromUserId { get; set; }
        public long? ToUserId { get; set; }
        public decimal CreditAmount { get; set; }
        public decimal TransferAmount { get; set; }
        public long? FromWalletCreditId { get; set; }
        public DateTime? ExpireDate { get; set; }
        public IEnumerable<UserModel> UserDetails { get; set; }
    }
}
