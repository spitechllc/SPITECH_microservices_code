﻿using System;
using System.Text.Json.Serialization;

namespace SpiTech.Finance.Domain.Models
{
    public class WalletHistoryModel
    {
        public decimal Amount { get; set; }
        public int? StoreId { get; set; }
        public string StoreName { get; set; }
        public long? TransactionId { get; set; }
        public string TransactionDesc { get; set; }
        public int? TransactionTypeId { get; set; }
        public DateTime? Date { get; set; }
        public DateTime? ExpireDate { get; set; }
        public int? UserId { get; set; }
        public string UserName { get; set; }
        public bool IsCredit { get; set; }
        public string TypeName { get; set; }
        public int TypeId { get; set; }
        public int? CreditIdentifier { get; set; }
        public bool IsRefunded { get; set; }
        public DateTime? RefundDate { get; set; }
        public string Message { get; set; }
        public int? TransactionCount { get; set; }
        public string NotificationTypeIdentifier { get; set; }
        [JsonIgnore]
        public int TotalRecord { get; set; }
    }
}
