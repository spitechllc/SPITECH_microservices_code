﻿using System;

namespace SpiTech.Finance.Domain.Models
{
    public class UserWalletModel
    {
        public int WalletId { get; set; }
        public int UserId { get; set; }
        public bool IsTransactionLock { get; set; }
        public DateTime? TransactionLockOn { get; set; }
        public string TransactionLockId { get; set; }
        public decimal TotalCreditAmount { get; set; }
        public decimal TotalRedeemAmount { get; set; }
        public decimal TotalAvailableAmount { get; set; }
        public decimal TotalTransferAmount { get; set; }
        public decimal TotalRecentExpiredAmount { get; set; }
    }
}
