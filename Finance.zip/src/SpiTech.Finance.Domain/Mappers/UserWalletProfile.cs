﻿using AutoMapper;
using SpiTech.Finance.Domain.Models;

namespace SpiTech.Finance.Domain.Mappers
{
    public class UserWalletProfile : Profile
    {
        public UserWalletProfile()
        {
            CreateMap<Entities.Wallet, UserWalletModel>().ReverseMap();
        }
    }
}
