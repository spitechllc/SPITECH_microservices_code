﻿using AutoMapper;
using SpiTech.EventBus.DomainEvents.Models.Finance;
using SpiTech.EventBus.DomainEvents.Models.Marketings;
using SpiTech.Finance.Domain.Models;
using SpiTech.Service.Clients.Identity;
using SpiTech.Service.Clients.Transactions;

namespace SpiTech.Finance.Domain.Mappers
{
    public class WalletCreditProfile : Profile
    {
        public WalletCreditProfile()
        {
            CreateMap<WalletCredit, WalletCreditExpiringResult>().ReverseMap();
            CreateMap<WalletCredit, Entities.WalletCredit>().ReverseMap();
            CreateMap<WalletCreditModel, PromotionLoyaltyModel>().ReverseMap();
            CreateMap<WalletCreditModel, Entities.WalletCredit>().ReverseMap();
            CreateMap<WalletCreditModel, WalletCredit>().ReverseMap();
            CreateMap<Entities.WalletCredit, UserExpiryRewardDetailsModel>().ReverseMap();
            CreateMap<ConsumerWalletDetailModel, UserConsumerModel>().ReverseMap();
        }
    }
}
