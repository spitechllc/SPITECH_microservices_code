﻿using AutoMapper;
using SpiTech.Finance.Domain.Entities;
using SpiTech.Finance.Domain.Models;

namespace SpiTech.Finance.Domain.Mappers
{
    public class LinkMemberTransferProfile : Profile
    {
        public LinkMemberTransferProfile()
        {
            CreateMap<LinkMemberTransfer, LinkMemberTransferModel>().ReverseMap();
        }
    }
}
