﻿namespace SpiTech.Finance.Domain
{
    public static class Constants
    {
        public static class TransactionDesc
        {
            public const string LinkUserTransfer = "LinkUserTransfer";
        }
    }
}
