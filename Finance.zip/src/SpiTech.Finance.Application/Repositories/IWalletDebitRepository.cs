﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Finance.Domain.Entities;
using SpiTech.Finance.Domain.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Repositories
{
    public interface IWalletDebitRepository : IRepository<WalletDebit>
    {
        Task<WalletDebit> GetByAuthNumber(string authNumber);
        Task<List<CashRewardModel>> GetByStoreIds(int[] storeIds, DateTime? fromDate, DateTime? toDate);
        Task<List<WalletDebit>> GetDebitByTransactionId(long[] transactionIds);
        Task<List<WalletDebit>> GetAdminDebit(int? userId, DateTime? fromDate, DateTime? toDate);
    }
}
