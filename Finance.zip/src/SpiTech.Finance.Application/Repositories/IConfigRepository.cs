﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Finance.Domain.Entities;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Repositories
{
    public interface IConfigRepository : IRepository<Config>
    {
        Task<Config> GetIsNotificationSent();

    }
}
