﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Finance.Domain.Entities;

namespace SpiTech.Finance.Application.Repositories
{
    public interface IDebitTypeRepository : IRepository<DebitType>
    {
    }
}
