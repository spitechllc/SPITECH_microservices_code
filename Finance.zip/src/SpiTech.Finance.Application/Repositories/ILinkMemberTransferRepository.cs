﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Finance.Domain.Entities;
using SpiTech.Finance.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Repositories
{
    public interface ILinkMemberTransferRepository : IRepository<LinkMemberTransfer>
    {
        Task<IEnumerable<LinkMemberTransfer>> GetLinkMemberTransfers(int fromUserId, int toUserId);
        Task<IEnumerable<LinkMemberTransferModel>> GetRequestedAmountList(int userId);
        Task<IEnumerable<LinkMemberTransferModel>> GetPendingAmountTransferRequests(int userId);
    }
}
