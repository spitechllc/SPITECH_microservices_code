﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Finance.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Repositories
{
    public interface IWalletDebitDetailRepository : IRepository<WalletDebitDetail>
    {
        Task<IEnumerable<WalletDebitDetail>> GetByWalletDebitId(long walletDebitId);
    }
}
