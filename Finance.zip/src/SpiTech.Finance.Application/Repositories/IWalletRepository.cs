﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Finance.Domain.Entities;
using SpiTech.Finance.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Repositories
{
    public interface IWalletRepository : IRepository<Wallet>
    {
        Task<Wallet> GetByUserId(int userId);
        Task<List<UserWalletModel>> GetByUserIds(params int[] userIds);
    }
}
