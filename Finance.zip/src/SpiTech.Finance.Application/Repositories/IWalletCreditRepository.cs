﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Finance.Domain.Entities;
using SpiTech.Finance.Domain.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Repositories
{
    public interface IWalletCreditRepository : IRepository<WalletCredit>
    {
        Task<IEnumerable<WalletCredit>> GetAllByUserId(int userId);
        Task<List<WalletCredit>> GetAdminCredit(int? userId, DateTime? fromDate, DateTime? toDate);
        Task<IEnumerable<WalletCredit>> GetAllByWalletCreditIds(long[] walletCreditIds);
        Task<IEnumerable<WalletCreditExpiringResult>> GetAllExpiringWalletCredit(int days);
        Task<IEnumerable<WalletCredit>> GetAllExpiringWalletCredit(int days, int userId);
        Task<IEnumerable<WalletCredit>> GetAllExpiredWalletCredit(int userId);
        Task<IEnumerable<WalletCreditSearchModel>> GetWalletCreditByTransactionId(long TransactionId);
        Task<List<WalletCreditSearchModel>> GetWalletCreditByTransactionIds(long[] transactionIds);
        Task<List<WalletHistoryModel>> GetWalletHistory(int UserId, int? PageIndex, int? PageSize);
        Task<WalletCredit> GetAllByStoreId(int? storeId, int? month, int? year, DateTime? CreditDate);
        Task<IEnumerable<WalletTransferCreditModel>> GetTransferAmountByUserId(int? fromUserId, int? toUserId);
        Task<WalletCredit> CheckDuplicateCredit(int transactionId, int creditTypeId, int userid);
        Task<List<CashRewardModel>> GetByStoreIds(int[] storeIds, DateTime? fromDate, DateTime? toDate);
        Task<List<WalletCreditSearchModel>> GetAllByTransactionIds(long[] TransactionIds);
        Task Update(int storeId, string siteId, string storeName);

        Task<RewardDetailsDashboardModel> GetRewardDetailsForDashboard(DateTime? startDate, DateTime? endDate, int[] storeIds, int? userId, int? month, int? year);
        Task<List<StoreRewardDetails>> GetStoreWiseRewardDetailsForDashboard(DateTime? startDate, DateTime? endDate, int[] storeIds, int? userId, int? month, int? year);
        Task<List<MonthWiseRewardDetails>> GetMonthwiseRewardDetailsForDashboard(int Year, int[] storeIds, int? userId);
        Task<List<UserRewardDetailsModel>> GetUserWiseRewardDetailsForDashboard(DateTime? startDate, DateTime? endDate, int[] storeIds, int[] userIds, int? month, int? year);
        Task<UserWalletDetailModel> GetUserWalletDetailsByUserId(int userId);
        Task<IEnumerable<WalletCredit>> GetExpiringWalletCreditByUserId(int userId);
        Task<List<UserWalletDetailModel>> GetUserWalletDetailsListByUserId(IEnumerable<int> userId);
        Task<List<WalletCreditDetailModel>> GetAllUserWalletCredit();
        Task<List<UserWalletDetailModel>> GetWalletDetails();
    }
}

