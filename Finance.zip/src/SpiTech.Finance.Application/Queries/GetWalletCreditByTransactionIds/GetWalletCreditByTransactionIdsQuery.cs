﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Domain.Models;

namespace SpiTech.Finance.Application.Queries.GetWalletCreditByTransactionIds
{
    public class GetWalletCreditByTransactionIdsQuery : IRequest<ResponseList<WalletCreditSearchModel>>
    {
        public long[] TransactionIds { get; set; }

    }
}
