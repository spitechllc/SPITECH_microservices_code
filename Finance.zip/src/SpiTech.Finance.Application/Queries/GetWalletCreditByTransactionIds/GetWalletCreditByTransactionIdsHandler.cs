﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetWalletCreditByTransactionIds
{
    public class GetWalletCreditByTransactionIdsHandler : IRequestHandler<GetWalletCreditByTransactionIdsQuery, ResponseList<WalletCreditSearchModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetWalletCreditByTransactionIdsHandler> _logger;
        private readonly IMapper _mapper;
        public GetWalletCreditByTransactionIdsHandler(IUnitOfWork context,
                                    ILogger<GetWalletCreditByTransactionIdsHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<ResponseList<WalletCreditSearchModel>> Handle(GetWalletCreditByTransactionIdsQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            ResponseList<WalletCreditSearchModel> result = new();
            if (request.TransactionIds != null)
            {
                result.Data = await _context.WalletCredits.GetWalletCreditByTransactionIds(request.TransactionIds);
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
