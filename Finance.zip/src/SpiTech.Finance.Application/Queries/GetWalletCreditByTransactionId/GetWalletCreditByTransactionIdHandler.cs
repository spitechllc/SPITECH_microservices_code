﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetWalletCreditByTransactionId
{
    public class GetWalletCreditByTransactionIdHandler : IRequestHandler<GetWalletCreditByTransactionIdQuery, IEnumerable<WalletCreditSearchModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetWalletCreditByTransactionIdHandler> _logger;
        private readonly IMapper _mapper;
        public GetWalletCreditByTransactionIdHandler(IUnitOfWork context,
                                    ILogger<GetWalletCreditByTransactionIdHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<IEnumerable<WalletCreditSearchModel>> Handle(GetWalletCreditByTransactionIdQuery request, CancellationToken cancellationToken)
        {

            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<WalletCreditSearchModel> walletCredits = await _context.WalletCredits.GetWalletCreditByTransactionId(request.TransactionId);


            _logger.TraceExitMethod(nameof(Handle), walletCredits);

            return walletCredits;
        }
    }
}
