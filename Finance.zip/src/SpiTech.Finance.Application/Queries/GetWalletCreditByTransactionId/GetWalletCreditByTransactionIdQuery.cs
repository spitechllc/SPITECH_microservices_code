﻿using MediatR;
using SpiTech.Finance.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.Finance.Application.Queries.GetWalletCreditByTransactionId
{
    public class GetWalletCreditByTransactionIdQuery : IRequest<IEnumerable<WalletCreditSearchModel>>
    {
        public long TransactionId { get; set; }
    }
}
