﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Domain.Models;

namespace SpiTech.Finance.Application.Queries.GetRequestedAmountsByUserId
{
    public class GetRequestedAmountsByUserIdQuery : IRequest<ResponseList<LinkMemberTransferModel>>
    {
        public int RequestedUserId { get; set; }
    }
}
