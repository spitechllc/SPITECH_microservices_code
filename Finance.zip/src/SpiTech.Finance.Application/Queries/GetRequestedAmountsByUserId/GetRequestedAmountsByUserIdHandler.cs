﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetRequestedAmountsByUserId
{
    public class GetRequestedAmountsByUserIdHandler : IRequestHandler<GetRequestedAmountsByUserIdQuery, ResponseList<LinkMemberTransferModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetRequestedAmountsByUserIdHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IIdentityServiceClient identityapiclient;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        public GetRequestedAmountsByUserIdHandler(IUnitOfWork context,
                                                ILogger<GetRequestedAmountsByUserIdHandler> logger,
                                                IMapper mapper,
                                                IIdentityServiceClient identityclient, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            identityapiclient = identityclient;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<ResponseList<LinkMemberTransferModel>> Handle(GetRequestedAmountsByUserIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            this.userAuthenticationProvider.ValidateUserAccess(request.RequestedUserId);
            System.Collections.Generic.IEnumerable<LinkMemberTransferModel> result = await _context.LinkMemberTransfers.GetRequestedAmountList(request.RequestedUserId);

            if (result != null)
            {
                System.Collections.Generic.IEnumerable<int> fromUserIds = result.Select(t => t.FromUserId).Distinct();
                System.Collections.Generic.ICollection<Service.Clients.Identity.UserModel> userList = await identityapiclient.GetUserListAsync(fromUserIds);

                if (userList != null)
                {
                    foreach (LinkMemberTransferModel item in result)
                    {
                        item.UserDetails = userList.FirstOrDefault(t => t.UserId == item.FromUserId);
                    }
                }
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return new ResponseList<LinkMemberTransferModel> { Data = result };
        }
    }
}
