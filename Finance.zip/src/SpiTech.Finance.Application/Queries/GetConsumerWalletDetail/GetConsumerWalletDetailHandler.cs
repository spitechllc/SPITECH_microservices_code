﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Finance.Application.Queries.GetWalletCreditDetail;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using SpiTech.Service.Clients.Identity;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Service.Clients.Transactions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetConsumerWalletDetail
{
    public class GetConsumerWalletDetailHandler : IRequestHandler<GetConsumerWalletDetailQuery, PaginatedList<ConsumerWalletDetailModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetConsumerWalletDetailHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IIdentityServiceClient _identityServiceClient;

        public GetConsumerWalletDetailHandler(IUnitOfWork context, ILogger<GetConsumerWalletDetailHandler> logger, IMediator mediator, IMapper mapper, IIdentityServiceClient identityServiceClient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _identityServiceClient = identityServiceClient;
        }
        public async Task<PaginatedList<ConsumerWalletDetailModel>> Handle(GetConsumerWalletDetailQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            var userResult = await _identityServiceClient.GetAllUserAsync(0,0);
            var userModels = _mapper.Map<List<ConsumerWalletDetailModel>>(userResult.Data.ToList());

            ResponseModel<UserWalletDetailModel> result = new() { Success = false };

            foreach (var item in userModels)
            {
                var resultData = await _context.WalletCredits.GetUserWalletDetailsByUserId(item.UserId);
                if (resultData != null)
                {
                    item.TotalCreditAmount = resultData.TotalCreditAmount;
                    item.TotalRedeemedAmount = resultData.TotalRedeemedAmount;
                    item.TotalExpiredAmount = resultData.TotalExpiredAmount;
                    item.TotalPromotionalAmount = resultData.TotalPromotionalAmount;
                    item.TotalAvailableAmount = resultData.TotalAvailableAmount;
                }
            }

            return await Task.FromResult(new PaginatedList<ConsumerWalletDetailModel>
            {
                Data = userModels,
                PageIndex = request.PageIndex,
                PageSize = request.PageSize,
                TotalCount = 1,
            });
        }
    }
}
