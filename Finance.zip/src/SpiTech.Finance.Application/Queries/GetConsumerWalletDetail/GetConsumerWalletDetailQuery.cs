﻿using MediatR;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Finance.Domain.Models;
using SpiTech.Service.Clients.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetConsumerWalletDetail
{
    public class GetConsumerWalletDetailQuery : IRequest<PaginatedList<ConsumerWalletDetailModel>>
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
    }

}
