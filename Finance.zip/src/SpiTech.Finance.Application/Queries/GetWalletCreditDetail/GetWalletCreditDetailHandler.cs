﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetWalletCreditDetail
{
    public class GetWalletCreditDetailHandler : IRequestHandler<GetWalletCreditDetailQuery, PaginatedList<WalletCreditDetailModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetWalletCreditDetailHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly ITransactionServiceClient _transactionapiclient;

        public GetWalletCreditDetailHandler(IUnitOfWork context, ILogger<GetWalletCreditDetailHandler> logger, IMediator mediator, IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<PaginatedList<WalletCreditDetailModel>> Handle(GetWalletCreditDetailQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            List<WalletCreditDetailModel> userWalletCreditDetailModel = _mapper.Map<List<WalletCreditDetailModel>>(
                                                    await _context.WalletCredits.GetAllUserWalletCredit());

            return await Task.FromResult(new PaginatedList<WalletCreditDetailModel>
            {
                Data = userWalletCreditDetailModel,
                PageIndex = request.PageIndex,
                PageSize = request.PageSize,
                TotalCount = 1,
            });
        }
    }
}
