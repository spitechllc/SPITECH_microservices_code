﻿using MediatR;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Finance.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetWalletCreditDetail
{
    public class GetWalletCreditDetailQuery : IRequest<PaginatedList<WalletCreditDetailModel>>
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
    }
}
