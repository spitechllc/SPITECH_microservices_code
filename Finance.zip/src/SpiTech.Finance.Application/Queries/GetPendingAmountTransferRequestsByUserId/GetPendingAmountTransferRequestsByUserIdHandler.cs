﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetPendingAmountTransferRequestsByUserId
{
    public class GetPendingAmountTransferRequestsByUserIdHandler : IRequestHandler<GetPendingAmountTransferRequestsByUserIdQuery, ResponseList<LinkMemberTransferModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetPendingAmountTransferRequestsByUserIdHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IIdentityServiceClient identityapiclient;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetPendingAmountTransferRequestsByUserIdHandler(IUnitOfWork context,
                                    ILogger<GetPendingAmountTransferRequestsByUserIdHandler> logger,
                                    IMapper mapper, IIdentityServiceClient identityclient, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            identityapiclient = identityclient;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<ResponseList<LinkMemberTransferModel>> Handle(GetPendingAmountTransferRequestsByUserIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            this.userAuthenticationProvider.ValidateUserAccess(request.UserId);

            System.Collections.Generic.IEnumerable<LinkMemberTransferModel> result = await _context.LinkMemberTransfers.GetPendingAmountTransferRequests(request.UserId);

            foreach (LinkMemberTransferModel item in result)
            {
                Service.Clients.Identity.UserModelResponseModel userList = await identityapiclient.GetUserByIdAsync(item.ToUserId);
                item.UserDetails = userList?.Data;
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return new ResponseList<LinkMemberTransferModel> { Data = result };
        }
    }
}
