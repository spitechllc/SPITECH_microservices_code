﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Domain.Models;

namespace SpiTech.Finance.Application.Queries.GetPendingAmountTransferRequestsByUserId
{
    public class GetPendingAmountTransferRequestsByUserIdQuery : IRequest<ResponseList<LinkMemberTransferModel>>
    {
        public int UserId { get; set; }
    }
}
