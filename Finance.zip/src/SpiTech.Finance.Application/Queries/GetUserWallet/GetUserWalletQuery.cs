﻿using MediatR;
using SpiTech.Finance.Domain.Models;

namespace SpiTech.Finance.Application.Queries.GetUserWallet
{
    public class GetUserWalletQuery : IRequest<UserWalletModel>
    {
        public int UserId { get; set; }
        public int? ExpiredDays { get; set; }
    }
}
