﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.Finance.Application.Queries.GetActiveWalletCredits;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetUserWallet
{
    public class GetUserWalletHandler : IRequestHandler<GetUserWalletQuery, UserWalletModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetUserWalletHandler> _logger;
        private readonly IMediator mediator;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetUserWalletHandler(IUnitOfWork context,
                                    ILogger<GetUserWalletHandler> logger,
                                             IMediator mediator,
                                    IMapper mapper, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            this.mediator = mediator;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<UserWalletModel> Handle(GetUserWalletQuery request, CancellationToken cancellationToken)
        {
            UserWalletModel result = null;
            _logger.TraceEnterMethod(nameof(Handle), request);
            this.userAuthenticationProvider.ValidateUserAccess(request.UserId);
            Domain.Entities.Wallet userWallet = await _context.Wallets.GetByUserId(request.UserId);
            if (userWallet != null)
            {
                result = _mapper.Map<UserWalletModel>(userWallet);
                System.Collections.Generic.IEnumerable<Domain.Entities.WalletCredit> activeCredits = await mediator.Send(new GetActiveWalletCreditsQuery { UserId = request.UserId });
                System.Collections.Generic.IEnumerable<WalletTransferCreditModel> transferamount = await _context.WalletCredits.GetTransferAmountByUserId(request.UserId, 0);

                if (request.ExpiredDays.HasValue && request.ExpiredDays.Value > 0)
                {
                    System.Collections.Generic.IEnumerable<Domain.Entities.WalletCredit> expiringWalletCredits = await _context.WalletCredits.GetAllExpiringWalletCredit(request.ExpiredDays.Value, request.UserId);

                    if (expiringWalletCredits != null && expiringWalletCredits.Any())
                    {
                        result.TotalRecentExpiredAmount = expiringWalletCredits.Sum(t => t.CurrentAmount);
                    }
                }

                if (activeCredits != null)
                {
                    result.TotalAvailableAmount = activeCredits.Sum(t => t.CurrentAmount);
                    result.TotalCreditAmount = activeCredits.Sum(t => t.CreditAmount);
                }

                if (transferamount != null)
                {
                    result.TotalTransferAmount = transferamount.Sum(t => t.TransferAmount);
                }
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}