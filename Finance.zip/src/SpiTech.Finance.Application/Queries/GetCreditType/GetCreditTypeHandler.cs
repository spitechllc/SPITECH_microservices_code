﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetCreditType
{
    public class GetCreditTypeHandler : IRequestHandler<GetCreditTypeQuery, CreditType>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetCreditTypeHandler> _logger;
        private readonly IMapper _mapper;
        public GetCreditTypeHandler(IUnitOfWork context,
                                    ILogger<GetCreditTypeHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<CreditType> Handle(GetCreditTypeQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            CreditType result = await _context.CreditTypes.Get(request.CreditTypeId);

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
