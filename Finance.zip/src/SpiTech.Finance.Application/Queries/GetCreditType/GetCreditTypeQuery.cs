﻿using MediatR;
using SpiTech.Finance.Domain.Entities;

namespace SpiTech.Finance.Application.Queries.GetCreditType
{
    public class GetCreditTypeQuery : IRequest<CreditType>
    {
        public int CreditTypeId { get; set; }
    }
}
