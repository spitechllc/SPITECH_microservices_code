﻿using MediatR;
using SpiTech.Finance.Domain.Models;
using System;
using System.Collections.Generic;

namespace SpiTech.Finance.Application.Queries.GetCashRewardDetailsByFilter
{
    public class GetCashRewardDetailsByFilterQuery : IRequest<List<CashRewardModel>>
    {
        public int[] StoreIds { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
