﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetCashRewardDetailsByFilter
{
    public class GetCashRewardDetailsByFilterHandler : IRequestHandler<GetCashRewardDetailsByFilterQuery, List<CashRewardModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetCashRewardDetailsByFilterHandler> _logger;
        private readonly IMapper _mapper;
        public GetCashRewardDetailsByFilterHandler(IUnitOfWork context,
                                    ILogger<GetCashRewardDetailsByFilterHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<List<CashRewardModel>> Handle(GetCashRewardDetailsByFilterQuery request, CancellationToken cancellationToken)
        {

            _logger.TraceEnterMethod(nameof(Handle), request);
            List<CashRewardModel> cashRewardDetails = new();

            var debitDetails = await _context.WalletDebits.GetByStoreIds(request.StoreIds.ToArray(), request.StartDate, request.EndDate);
            var creditDetails = await _context.WalletCredits.GetByStoreIds(request.StoreIds.ToArray(), request.StartDate, request.EndDate);

            foreach (int store in request.StoreIds)
            {
                CashRewardModel cashRewardModel = new()
                {
                    TotalEarned = creditDetails.FirstOrDefault(s => s.StoreId == store)?.TotalEarned ?? 0,
                    TotalRedeemed = debitDetails.FirstOrDefault(s => s.StoreId == store)?.TotalRedeemed ?? 0,
                    StoreId = store
                };
                cashRewardDetails.Add(cashRewardModel);
            }

            _logger.TraceExitMethod(nameof(Handle), cashRewardDetails);

            return cashRewardDetails;
        }
    }
}
