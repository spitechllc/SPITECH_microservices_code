﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Entities;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetWalletCreditsByStoreId
{
    public class GetWalletCreditsByStoreIdHandler : IRequestHandler<GetWalletCreditsByStoreIdQuery, WalletCredit>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetWalletCreditsByStoreIdHandler> _logger;
        private readonly IMapper _mapper;
        public GetWalletCreditsByStoreIdHandler(IUnitOfWork context,
                                    ILogger<GetWalletCreditsByStoreIdHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<WalletCredit> Handle(GetWalletCreditsByStoreIdQuery request, CancellationToken cancellationToken)
        {
            IEnumerable<WalletCredit> result = null;
            _logger.TraceEnterMethod(nameof(Handle), request);

            WalletCredit walletCredits = await _context.WalletCredits.GetAllByStoreId(request.StoreId, request.month, request.year, request.CreditDate);

            _logger.TraceExitMethod(nameof(Handle), result);

            return walletCredits;
        }
    }
}
