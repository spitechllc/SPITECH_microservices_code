﻿using MediatR;
using SpiTech.Finance.Domain.Entities;
using System;

namespace SpiTech.Finance.Application.Queries.GetWalletCreditsByStoreId
{
    public class GetWalletCreditsByStoreIdQuery : IRequest<WalletCredit>
    {
        public int StoreId { get; set; }
        public DateTime? CreditDate { get; set; }
        public int? month { get; set; }
        public int? year { get; set; }

    }
}
