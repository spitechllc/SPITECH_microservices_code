﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Domain.Models;
using System;

namespace SpiTech.Finance.Application.Queries.GetRewardDetailsDashboard
{
    public class GetRewardDetailsDashboardQuery : IRequest<ResponseModel<RewardDetailsDashboardModel>>
    {
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int[] StoreIds { get; set; }
        public int? UserId { get; set; }
        public int? Month { get; set; }
        public int? Year { get; set; }

    }
}
