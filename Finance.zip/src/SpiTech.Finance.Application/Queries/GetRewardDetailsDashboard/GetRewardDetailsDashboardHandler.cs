﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetRewardDetailsDashboard
{
    public class GetRewardDetailsDashboardHandler : IRequestHandler<GetRewardDetailsDashboardQuery, ResponseModel<RewardDetailsDashboardModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetRewardDetailsDashboardHandler> _logger;
        private readonly IMapper _mapper;
        public GetRewardDetailsDashboardHandler(IUnitOfWork context,
                                    ILogger<GetRewardDetailsDashboardHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<ResponseModel<RewardDetailsDashboardModel>> Handle(GetRewardDetailsDashboardQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            ResponseModel<RewardDetailsDashboardModel> result = new() { Success=false};


                result.Data = await _context.WalletCredits.GetRewardDetailsForDashboard(request.StartDate,request.EndDate,request.StoreIds,request.UserId,request.Month,request.Year);
            if(result.Data!=null)
            {
                result.Data.storeRewardDetails= await _context.WalletCredits.GetStoreWiseRewardDetailsForDashboard(request.StartDate, request.EndDate, request.StoreIds, request.UserId, request.Month, request.Year);
                if(result.Data.storeRewardDetails!=null)
                {
                    result.Data.TotalStoreAmount = result.Data.storeRewardDetails.Sum(t=>t.Amount);
                    result.Data.TotalStoreEarned = result.Data.storeRewardDetails.Sum(t => t.Earned);
                    result.Data.TotalStoreRedeemed = result.Data.storeRewardDetails.Sum(t => t.Redeemed);
                }
                result.Data.monthWiseRewardDetails = await _context.WalletCredits.GetMonthwiseRewardDetailsForDashboard(DateTime.UtcNow.Year, request.StoreIds, request.UserId);
                if (result.Data.monthWiseRewardDetails != null)
                {
                    result.Data.MonthWiseTotalEarned = result.Data.monthWiseRewardDetails.Sum(t => t.Earned);
                    result.Data.MonthWiseTotalRedeemed = result.Data.monthWiseRewardDetails.Sum(t => t.Redeemed);
                }
                result.Success = true;
                result.Message = "Success";
            }
            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
