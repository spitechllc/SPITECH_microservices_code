﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Domain.Models;

namespace SpiTech.Finance.Application.Queries.GetTransferedWalletCredits
{
    public class GetTransferedWalletCreditsQuery : IRequest<ResponseList<WalletTransferCreditModel>>
    {
        public int UserId { get; set; }
    }
}
