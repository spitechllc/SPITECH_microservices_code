﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetTransferedWalletCredits
{
    public class GetTransferedWalletCreditsHandler : IRequestHandler<GetTransferedWalletCreditsQuery, ResponseList<WalletTransferCreditModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetTransferedWalletCreditsHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IIdentityServiceClient identityApiClient;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetTransferedWalletCreditsHandler(IUnitOfWork context,
                                    ILogger<GetTransferedWalletCreditsHandler> logger,
                                    IMapper mapper,
                                    IIdentityServiceClient identityClient, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            identityApiClient = identityClient;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<ResponseList<WalletTransferCreditModel>> Handle(GetTransferedWalletCreditsQuery request, CancellationToken cancellationToken)
        {

            _logger.TraceEnterMethod(nameof(Handle), request);
            this.userAuthenticationProvider.ValidateUserAccess(request.UserId);
            IEnumerable<WalletTransferCreditModel> walletCredits = await _context.WalletCredits.GetTransferAmountByUserId(request.UserId, 0);
            if (walletCredits != null)
            {
                IEnumerable<int> userids = (List<int>)walletCredits.Select(x => x.ToUserId);
                ICollection<Service.Clients.Identity.UserModel> userdetails = await identityApiClient.GetUserListAsync(userids);
                if (userdetails != null)
                {
                    walletCredits.Select(x => x.UserDetails == userdetails);
                }
            }

            _logger.TraceExitMethod(nameof(Handle), walletCredits);

            return new ResponseList<WalletTransferCreditModel> { Data = walletCredits };
        }
    }
}
