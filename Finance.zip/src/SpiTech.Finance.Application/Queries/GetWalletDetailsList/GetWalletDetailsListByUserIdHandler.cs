﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetWalletDetailsList
{
    public class GetWalletDetailsListByUserIdHandler : IRequestHandler<GetWalletDetailsListByUserIdQuery, IEnumerable<UserWalletDetailModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetWalletDetailsListByUserIdHandler> _logger;
        private readonly IMapper _mapper;
        public GetWalletDetailsListByUserIdHandler(IUnitOfWork context,
                                    ILogger<GetWalletDetailsListByUserIdHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<IEnumerable<UserWalletDetailModel>> Handle(GetWalletDetailsListByUserIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<UserWalletDetailModel> result = new List<UserWalletDetailModel>();
            try
            {
                IEnumerable<int> userIds = request.UserIds.Distinct();
                result = await _context.WalletCredits.GetUserWalletDetailsListByUserId(userIds);
                _logger.TraceExitMethod(nameof(Handle), result);
            }
            catch (Exception ex)
            { throw; }
            return result;
        }
    }
}
