﻿using MediatR;
using SpiTech.Finance.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetWalletDetailsList
{
    public class GetWalletDetailsListByUserIdModel
    {
        public List<int> UserIds { get; set; }
    }
    public class GetWalletDetailsListByUserIdQuery : GetWalletDetailsListByUserIdModel, IRequest<IEnumerable<UserWalletDetailModel>>
    {
    }
}
