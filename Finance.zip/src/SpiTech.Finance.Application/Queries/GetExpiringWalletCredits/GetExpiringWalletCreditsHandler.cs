﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetExpiringWalletCredits
{
    public class GetExpiringWalletCreditsHandler : IRequestHandler<GetExpiringWalletCreditsQuery, ResponseList<WalletCredit>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetExpiringWalletCreditsHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetExpiringWalletCreditsHandler(IUnitOfWork context,
                                    ILogger<GetExpiringWalletCreditsHandler> logger,
                                    IMapper mapper, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<ResponseList<WalletCredit>> Handle(GetExpiringWalletCreditsQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            this.userAuthenticationProvider.ValidateUserAccess(request.UserId);
            System.Collections.Generic.IEnumerable<WalletCredit> result = await _context.WalletCredits.GetAllExpiringWalletCredit(request.Days, request.UserId);

            _logger.TraceExitMethod(nameof(Handle), result);

            return new ResponseList<WalletCredit> { Data = result };
        }
    }
}
