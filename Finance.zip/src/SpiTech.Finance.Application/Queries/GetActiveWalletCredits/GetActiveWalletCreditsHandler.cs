﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetActiveWalletCredits
{
    public class GetActiveWalletCreditsHandler : IRequestHandler<GetActiveWalletCreditsQuery, IEnumerable<WalletCredit>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetActiveWalletCreditsHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetActiveWalletCreditsHandler(IUnitOfWork context,
                                    ILogger<GetActiveWalletCreditsHandler> logger,
                                    IMapper mapper, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<IEnumerable<WalletCredit>> Handle(GetActiveWalletCreditsQuery request, CancellationToken cancellationToken)
        {
            IEnumerable<WalletCredit> result = null;
            _logger.TraceEnterMethod(nameof(Handle), request);
            this.userAuthenticationProvider.ValidateUserAccess(request.UserId);
            IEnumerable<WalletCredit> walletCredits = await _context.WalletCredits.GetAllByUserId(request.UserId);

            if (walletCredits != null)
            {
                result = walletCredits.Where(t => t.ExpireDate > System.DateTime.UtcNow && t.CurrentAmount > 0).OrderBy(t => t.ExpireDate);
            }
            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
