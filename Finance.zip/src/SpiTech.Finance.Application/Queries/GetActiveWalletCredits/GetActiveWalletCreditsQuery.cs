﻿using MediatR;
using SpiTech.Finance.Domain.Entities;
using System.Collections.Generic;

namespace SpiTech.Finance.Application.Queries.GetActiveWalletCredits
{
    public class GetActiveWalletCreditsQuery : IRequest<IEnumerable<WalletCredit>>
    {
        public int UserId { get; set; }
    }
}
