﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetAdminDebits
{
    public class GetAdminDebitsHandler : IRequestHandler<GetAdminDebitsQuery, ResponseList<WalletDebit>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetAdminDebitsHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetAdminDebitsHandler(IUnitOfWork context,
                                    ILogger<GetAdminDebitsHandler> logger,
                                    IMapper mapper, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<ResponseList<WalletDebit>> Handle(GetAdminDebitsQuery request, CancellationToken cancellationToken)
        {
            IEnumerable<WalletDebit> result = null;
            _logger.TraceEnterMethod(nameof(Handle), request);
            if(request.UserId>0)
            {
                this.userAuthenticationProvider.ValidateUserAccess((int)request.UserId);
            }
            List<WalletDebit> walletDebits = (await _context.WalletDebits.GetAdminDebit(request.UserId, request.FromDate, request.ToDate)).ToList();


            if (walletDebits != null)
            {
                result = walletDebits.ToList();
            }
            _logger.TraceExitMethod(nameof(Handle), result);

            return new ResponseList<WalletDebit> { Data = result };
        }
    }
}
