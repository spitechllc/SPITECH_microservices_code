﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Domain.Entities;
using System;

namespace SpiTech.Finance.Application.Queries.GetAdminDebits
{
    public class GetAdminDebitsQuery : IRequest<ResponseList<WalletDebit>>
    {
        public int? UserId { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
    }
}
