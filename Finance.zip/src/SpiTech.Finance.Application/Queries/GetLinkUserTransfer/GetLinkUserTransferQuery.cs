﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Domain.Entities;

namespace SpiTech.Finance.Application.Queries.GetLinkUserTransfer
{
    public class GetLinkUserTransferQuery : IRequest<ResponseList<LinkMemberTransfer>>
    {
        public int FromUserId { get; set; }
        public int ToUserId { get; set; }
    }
}
