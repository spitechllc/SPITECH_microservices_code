﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Domain.Entities;

namespace SpiTech.Finance.Application.Queries.GetCreditTypes
{
    public class GetCreditTypesQuery : IRequest<ResponseList<CreditType>>
    {
    }
}
