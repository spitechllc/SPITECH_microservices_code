﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetCreditTypes
{
    public class GetCreditTypesHandler : IRequestHandler<GetCreditTypesQuery, ResponseList<CreditType>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetCreditTypesHandler> _logger;
        private readonly IMapper _mapper;
        public GetCreditTypesHandler(IUnitOfWork context,
                                    ILogger<GetCreditTypesHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<ResponseList<CreditType>> Handle(GetCreditTypesQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            System.Collections.Generic.IEnumerable<CreditType> result = await _context.CreditTypes.GetAll();

            _logger.TraceExitMethod(nameof(Handle), result);

            return new ResponseList<CreditType> { Data = result };
        }
    }
}
