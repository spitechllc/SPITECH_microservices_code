﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetWalletDetailsByUserId
{
    public class GetWalletDetailsByUserIdHandler : IRequestHandler<GetWalletDetailsByUserIdQuery, ResponseModel<UserWalletDetailModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetWalletDetailsByUserIdHandler> _logger;
        private readonly IMapper _mapper;
        public GetWalletDetailsByUserIdHandler(IUnitOfWork context,
                                    ILogger<GetWalletDetailsByUserIdHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<ResponseModel<UserWalletDetailModel>> Handle(GetWalletDetailsByUserIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            ResponseModel<UserWalletDetailModel> result = new() { Success=false};
            try
            {

                result.Data = await _context.WalletCredits.GetUserWalletDetailsByUserId(request.UserId);
                if (result.Data != null)
                {
                    var expiryRewardDetails = _mapper.Map<List<UserExpiryRewardDetailsModel>>(await _context.WalletCredits.GetExpiringWalletCreditByUserId(request.UserId));
                    result.Data.ExpiryRewardDetails = expiryRewardDetails;
                    result.Success = true;
                    result.Message = "Success";
                }
                _logger.TraceExitMethod(nameof(Handle), result);
            }
            catch (Exception ex)
            { throw; }
            return result;
        }
    }
}
