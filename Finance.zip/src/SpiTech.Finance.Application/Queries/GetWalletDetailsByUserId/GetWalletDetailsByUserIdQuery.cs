﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Domain.Models;
using System;

namespace SpiTech.Finance.Application.Queries.GetWalletDetailsByUserId
{
    public class GetWalletDetailsByUserIdQuery : IRequest<ResponseModel<UserWalletDetailModel>>
    {        
        public int UserId { get; set; }

    }
}
