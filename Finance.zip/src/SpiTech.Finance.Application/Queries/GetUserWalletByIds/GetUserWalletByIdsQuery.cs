﻿using MediatR;
using SpiTech.Finance.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.Finance.Application.Queries.GetUserWalletByIds
{
    public class GetUserWalletByIdsQuery : IRequest<IEnumerable<UserWalletModel>>
    {
        public List<int> UserIds { get; set; }
    }
}
