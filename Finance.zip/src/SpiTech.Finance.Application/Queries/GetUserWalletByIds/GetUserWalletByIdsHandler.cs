﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetUserWalletByIds
{
    public class GetUserWalletByIdsHandler : IRequestHandler<GetUserWalletByIdsQuery, IEnumerable<UserWalletModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetUserWalletByIdsHandler> _logger;
        private readonly IMediator mediator;
        private readonly IMapper _mapper;
        public GetUserWalletByIdsHandler(IUnitOfWork context,
                                    ILogger<GetUserWalletByIdsHandler> logger,
                                             IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            this.mediator = mediator;
            _mapper = mapper;
        }
        public async Task<IEnumerable<UserWalletModel>> Handle(GetUserWalletByIdsQuery request, CancellationToken cancellationToken)
        {

            _logger.TraceEnterMethod(nameof(Handle), request);

            List<UserWalletModel> userWallet = await _context.Wallets.GetByUserIds(request.UserIds.ToArray());

            _logger.TraceExitMethod(nameof(Handle), userWallet);

            return userWallet;
        }
    }
}