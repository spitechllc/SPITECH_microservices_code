﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Domain.Entities;

namespace SpiTech.Finance.Application.Queries.GetExpiredWalletCredits
{
    public class GetExpiredWalletCreditsQuery : IRequest<ResponseList<WalletCredit>>
    {
        public int UserId { get; set; }
    }
}
