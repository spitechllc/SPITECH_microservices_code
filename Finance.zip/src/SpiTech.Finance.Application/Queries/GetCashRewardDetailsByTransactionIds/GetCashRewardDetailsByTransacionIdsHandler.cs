﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetCashRewardDetailsByTransactionIds
{
    public class GetCashRewardDetailsByTransacionIdsHandler : IRequestHandler<GetCashRewardDetailsByTransacionIdsQuery, List<TransactionCashRewardModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetCashRewardDetailsByTransacionIdsHandler> _logger;
        private readonly IMapper _mapper;
        public GetCashRewardDetailsByTransacionIdsHandler(IUnitOfWork context,
                                    ILogger<GetCashRewardDetailsByTransacionIdsHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<List<TransactionCashRewardModel>> Handle(GetCashRewardDetailsByTransacionIdsQuery request, CancellationToken cancellationToken)
        {

            _logger.TraceEnterMethod(nameof(Handle), request);
            List<TransactionCashRewardModel> cashRewardDetails = new();

            List<Domain.Entities.WalletDebit> debitDetails = await _context.WalletDebits.GetDebitByTransactionId(request.TransactionIds.ToArray());
            List<Domain.Models.WalletCreditSearchModel> creditDetails = await _context.WalletCredits.GetAllByTransactionIds(request.TransactionIds.ToArray());

            foreach (long TransactionId in request.TransactionIds)
            {
                decimal balancecredit = 0;
                decimal balancedebit = 0;
                decimal balance = 0;
                if (creditDetails.Where(s => s.TransactionId == TransactionId).Count() > 0 && debitDetails.Where(s => s.TransactionId == TransactionId).Count() == 0)
                {
                    balancecredit = creditDetails.Where(s => s.TransactionId == TransactionId).FirstOrDefault().BalanceAmount;
                    balance = balancecredit;
                }
                else if (debitDetails.Where(s => s.TransactionId == TransactionId).Count() > 0 && creditDetails.Where(s => s.TransactionId == TransactionId).Count() == 0)
                {
                    balancedebit = debitDetails.Where(s => s.TransactionId == TransactionId).FirstOrDefault().WalletBalanceAmount;
                    balance = balancedebit;
                }
                else
                {
                    if (creditDetails.Where(s => s.TransactionId == TransactionId).Count() > 0 && debitDetails.Where(s => s.TransactionId == TransactionId).Count() > 0)
                    {
                        if (debitDetails.Where(s => s.TransactionId == TransactionId).FirstOrDefault().DebitDate > creditDetails.Where(s => s.TransactionId == TransactionId).FirstOrDefault().Date)
                        {
                            balance = debitDetails.Where(s => s.TransactionId == TransactionId).FirstOrDefault().WalletBalanceAmount;
                        }
                        if (creditDetails.Where(s => s.TransactionId == TransactionId).FirstOrDefault().Date > debitDetails.Where(s => s.TransactionId == TransactionId).FirstOrDefault().DebitDate)
                        {
                            balance = creditDetails.Where(s => s.TransactionId == TransactionId).FirstOrDefault().BalanceAmount;
                        }
                    }
                }
                TransactionCashRewardModel cashRewardModel = new()
                {
                    TotalEarned = creditDetails.Where(s => s.TransactionId == TransactionId).Sum(a => a.CreditAmount),
                    TotalRedeemed = debitDetails.Where(s => s.TransactionId == TransactionId).Sum(a => a.Amount),
                    TransactionId = TransactionId,
                    CashRewardBalance = balance
                };
                cashRewardDetails.Add(cashRewardModel);
            }

            _logger.TraceExitMethod(nameof(Handle), cashRewardDetails);

            return cashRewardDetails;
        }
    }
}
