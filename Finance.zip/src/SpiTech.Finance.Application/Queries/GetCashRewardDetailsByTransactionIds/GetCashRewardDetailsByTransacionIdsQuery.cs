﻿using MediatR;
using SpiTech.Finance.Domain.Models;
using System;
using System.Collections.Generic;


namespace SpiTech.Finance.Application.Queries.GetCashRewardDetailsByTransactionIds
{
    public class GetCashRewardDetailsByTransacionIdsQuery : IRequest<List<TransactionCashRewardModel>>
    {
        public long[] TransactionIds { get; set; }
    }
}
