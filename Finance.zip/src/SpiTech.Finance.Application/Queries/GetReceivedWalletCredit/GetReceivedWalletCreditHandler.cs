﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using SpiTech.Service.Clients.Identity;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetReceivedWalletCredit
{
    public class GetReceivedWalletCreditHandler : IRequestHandler<GetReceivedWalletCreditQuery, ResponseList<WalletTransferCreditModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetReceivedWalletCreditHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IIdentityServiceClient identityApiClient;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetReceivedWalletCreditHandler(IUnitOfWork context,
                                    ILogger<GetReceivedWalletCreditHandler> logger,
                                    IMapper mapper,
                                    IIdentityServiceClient identityClient, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            identityApiClient = identityClient;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<ResponseList<WalletTransferCreditModel>> Handle(GetReceivedWalletCreditQuery request, CancellationToken cancellationToken)
        {

            _logger.TraceEnterMethod(nameof(Handle), request);
            this.userAuthenticationProvider.ValidateUserAccess(request.UserId);
            IEnumerable<WalletTransferCreditModel> walletCredits = await _context.WalletCredits.GetTransferAmountByUserId(0, request.UserId);
            if (walletCredits != null)
            {
                IEnumerable<int> userids = (IEnumerable<int>)walletCredits.Select(x => x.FromUserId);
                ICollection<UserModel> userdetails = await identityApiClient.GetUserListAsync(userids);
                if (userdetails != null)
                {
                    walletCredits.Select(x => x.UserDetails == userdetails);
                }
            }

            _logger.TraceExitMethod(nameof(Handle), walletCredits);

            return new ResponseList<WalletTransferCreditModel> { Data = walletCredits };
        }
    }
}
