﻿using MediatR;
using SpiTech.Finance.Application.Queries.GetWalletDetailsList;
using SpiTech.Finance.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetWalletDetail
{
    public class GetWalletDetailsQuery : IRequest<IEnumerable<UserWalletDetailModel>>
    {
    }
}
