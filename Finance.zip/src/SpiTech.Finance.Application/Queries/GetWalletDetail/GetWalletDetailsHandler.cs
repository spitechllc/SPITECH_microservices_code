﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Application.Queries.GetWalletDetailsByUserId;
using SpiTech.Finance.Application.Queries.GetWalletDetailsList;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetWalletDetail
{
    public class GetWalletDetailsHandler : IRequestHandler<GetWalletDetailsQuery, IEnumerable<UserWalletDetailModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetWalletDetailsHandler> _logger;
        private readonly IMapper _mapper;
        public GetWalletDetailsHandler(IUnitOfWork context,
                                    ILogger<GetWalletDetailsHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<IEnumerable<UserWalletDetailModel>> Handle(GetWalletDetailsQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<UserWalletDetailModel> result = new List<UserWalletDetailModel>();
            try
            {

                result = await _context.WalletCredits.GetWalletDetails();

                _logger.TraceExitMethod(nameof(Handle), result);
            }
            catch (Exception ex)
            { throw; }
            return result;
        }
    }
}
