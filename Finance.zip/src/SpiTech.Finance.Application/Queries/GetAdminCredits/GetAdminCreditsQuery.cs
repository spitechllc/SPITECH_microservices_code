﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Domain.Entities;
using System;

namespace SpiTech.Finance.Application.Queries.GetAdminCredits
{
    public class GetAdminCreditsQuery : IRequest<ResponseList<WalletCredit>>
    {
        public int? UserId { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
    }
}
