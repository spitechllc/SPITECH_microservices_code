﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetConsumersRewardDetailsDashboard
{
    public class GetConsumersRewardDetailsDashboardHandler : IRequestHandler<GetConsumersRewardDetailsDashboardQuery, ResponseList<UserRewardDetailsModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetConsumersRewardDetailsDashboardHandler> _logger;
        private readonly IMapper _mapper;
        public GetConsumersRewardDetailsDashboardHandler(IUnitOfWork context,
                                    ILogger<GetConsumersRewardDetailsDashboardHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<ResponseList<UserRewardDetailsModel>> Handle(GetConsumersRewardDetailsDashboardQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            try
            {
                ResponseList<UserRewardDetailsModel> result = new();

                var res=await _context.WalletCredits.GetUserWiseRewardDetailsForDashboard(request.StartDate, request.EndDate, request.StoreIds, request.UserIds, request.Month, request.Year);
                result.Data = res;

                _logger.TraceExitMethod(nameof(Handle), result);

                return result;
            }
            catch(Exception ex)
            {
                throw;
            }
        }
    }
}
