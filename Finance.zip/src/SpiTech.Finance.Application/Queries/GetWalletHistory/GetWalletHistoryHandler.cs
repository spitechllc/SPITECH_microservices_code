﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Localization;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.ApplicationCore.Processors;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using SpiTech.Service.Clients.Identity;
using SpiTech.Service.Clients.Notifications;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetWalletHistory
{
    public class GetWalletHistoryHandler : IRequestHandler<GetWalletHistoryQuery, PaginatedList<WalletHistoryModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetWalletHistoryHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IIdentityServiceClient _identityApiClient;
        private readonly INotificationServiceClient _notificationServiceClient;
        private readonly IStringLocalizer<GetWalletHistoryHandler> _localizer;

        public GetWalletHistoryHandler(IUnitOfWork context,
                                    ILogger<GetWalletHistoryHandler> logger,
                                    IMapper mapper,
                                    IIdentityServiceClient identityClient, INotificationServiceClient notificationServiceClient, IStringLocalizer<GetWalletHistoryHandler> localizer)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _identityApiClient = identityClient;
            _notificationServiceClient = notificationServiceClient;
            _localizer = localizer;
        }

        public async Task<PaginatedList<WalletHistoryModel>> Handle(GetWalletHistoryQuery request, CancellationToken cancellationToken)
        {
            PaginatedList<WalletHistoryModel> result = new()
            {
                PageIndex = request.PageIndex ?? 0,
                PageSize = request.PageSize ?? 0,
            };

            _logger.TraceEnterMethod(nameof(Handle), request);

            result.Data = await _context.WalletCredits.GetWalletHistory(request.UserId, request.PageIndex, request.PageSize);

            if (result.Data != null && result.Data.Any())
            {
                result.TotalCount = result.Data.FirstOrDefault()?.TotalRecord ?? 0;
            }

            if (result.Data != null && result.Data.Any())
            {
                IEnumerable<int> userIds = result.Data.Select(t => t.UserId ?? 0).Where(t => t != 0).ToArray().Distinct();

                ICollection<UserModel> users = new List<UserModel>();

                if (userIds != null && userIds.Any())
                {
                    users = await _identityApiClient.GetUserListAsync(userIds);
                }
                NotificationTypeModelResponseList notificationTypeModelResponseList = await _notificationServiceClient.GetNotificationTypeAsync(cancellationToken);
               
                foreach (WalletHistoryModel item in result.Data)
                {
                    string message = string.Empty;
                    if (item.UserId != null && users != null)
                    {
                        UserModel user = users.FirstOrDefault(t => t.UserId == item.UserId);
                        item.UserName = user?.FirstName + " " + user?.LastName;
                    }
                    string msg = string.Empty;
                    if (item.IsCredit)
                    {
                       
                        if (request.culture == "es")
                        {
                            msg= notificationTypeModelResponseList.Data.Where(w => w.NotificationTypeId == (int)EventType.WalletCreditEvent && w.NotificationTypeIdentifier == item.NotificationTypeIdentifier).Select(a => a.DisplayTemplateES).FirstOrDefault();
                        }
                        else
                        {
                            msg = notificationTypeModelResponseList.Data.Where(w => w.NotificationTypeId == (int)EventType.WalletCreditEvent && w.NotificationTypeIdentifier == item.NotificationTypeIdentifier).Select(a => a.DisplayTemplate).FirstOrDefault();
                        }
                       
                        message = TextTemplateMacroProcessor.Process(msg, new
                        {
                            CreditAmount = item.Amount,
                            Name = item.UserName,
                            TransactionDesc = item.TransactionDesc,
                            UserName = item.UserName,
                            StoreName = item.StoreName,
                            TransactionCount = item.TransactionCount

                        }, item);

                        //    if ((CreditType)item.TypeId == (CreditType.LinkUserTransfer))
                        //    {
                        //        var msg = notificationTypeModelResponseList.Data.Where(w => w.NotificationTypeId == (int)EventType.WalletCreditEvent && w.NotificationTypeIdentifier == NotificationTypeIdentifierConstants.WalletLinkUserTransferCreditEvent).Select(a => a.DisplayTemplate).FirstOrDefault();
                        //        message = TextTemplateMacroProcessor.Process(msg, new
                        //        {
                        //            CreditAmount = item.Amount,
                        //            TransferAmount = item.Amount,
                        //            Name= item.UserName,
                        //            item.UserName
                        //        }, item);
                        //    }
                        //    if ((CreditType)item.TypeId == (CreditType.Loyalty))
                        //    {
                        //        if ((LoyaltyCreditIdentifier)item.CreditIdentifier == (LoyaltyCreditIdentifier.Credit))
                        //        {
                        //            var msg = notificationTypeModelResponseList.Data.Where(w => w.NotificationTypeId == (int)EventType.WalletCreditEvent && w.NotificationTypeIdentifier == NotificationTypeIdentifierConstants.CreditCardTransaction).Select(a => a.DisplayTemplate).FirstOrDefault();
                        //            message = TextTemplateMacroProcessor.Process(msg, new
                        //            {
                        //                CreditAmount = item.Amount,
                        //                item.StoreName
                        //            }, item);
                        //        }
                        //        if ((LoyaltyCreditIdentifier)item.CreditIdentifier == (LoyaltyCreditIdentifier.ACH))
                        //        {
                        //            var msg = notificationTypeModelResponseList.Data.Where(w => w.NotificationTypeId == (int)EventType.WalletCreditEvent && w.NotificationTypeIdentifier == NotificationTypeIdentifierConstants.ACHTransaction).Select(a => a.DisplayTemplate).FirstOrDefault();
                        //            message = TextTemplateMacroProcessor.Process(msg, new
                        //            {
                        //                CreditAmount = item.Amount,
                        //                item.StoreName
                        //            }, item);
                        //        }
                        //    }
                        //    if ((CreditType)item.TypeId == (CreditType.Promotion))
                        //    {
                        //        if ((PromotionCreditIdentifier)item.CreditIdentifier == (PromotionCreditIdentifier.AddCard))
                        //        {
                        //            var msg = notificationTypeModelResponseList.Data.Where(w => w.NotificationTypeId == (int)EventType.WalletCreditEvent && w.NotificationTypeIdentifier == NotificationTypeIdentifierConstants.AddCardEvent).Select(a => a.DisplayTemplate).FirstOrDefault();
                        //            message = TextTemplateMacroProcessor.Process(msg, new
                        //            {
                        //                CreditAmount = item.Amount,
                        //                TransferAmount = item.Amount,
                        //                item.UserName
                        //            }, item);
                        //        }
                        //        if ((PromotionCreditIdentifier)item.CreditIdentifier == (PromotionCreditIdentifier.TransactionSequenceNo))
                        //        {
                        //            var msg = notificationTypeModelResponseList.Data.Where(w => w.NotificationTypeId == (int)EventType.WalletCreditEvent && w.NotificationTypeIdentifier == NotificationTypeIdentifierConstants.TransactionSequenceNo).Select(a => a.DisplayTemplate).FirstOrDefault();
                        //            message = TextTemplateMacroProcessor.Process(msg, new
                        //            {
                        //                CreditAmount = item.Amount,
                        //                TransactionCount = item.TransactionCount,
                        //                item.UserName,
                        //                item
                        //            }, item) ;
                        //        }
                        //    }
                        //    if ((CreditType)item.TypeId == (CreditType.AdminCredit))
                        //    {
                        //        var msg = notificationTypeModelResponseList.Data.Where(w => w.NotificationTypeId == (int)EventType.WalletCreditEvent && w.NotificationTypeIdentifier == NotificationTypeIdentifierConstants.AdminCreditEvent).Select(a => a.DisplayTemplate).FirstOrDefault();
                        //        message = TextTemplateMacroProcessor.Process(msg, new
                        //        {
                        //            CreditAmount = item.Amount,
                        //            item.TransactionDesc
                        //        }, item);
                        //    }
                    }
                    else
                    {

                        if (request.culture == "es")
                        {
                            msg = notificationTypeModelResponseList.Data.Where(w => w.NotificationTypeId == (int)EventType.WalletDebitEvent && w.NotificationTypeIdentifier == item.NotificationTypeIdentifier).Select(a => a.DisplayTemplateES).FirstOrDefault();
                        }
                        else
                        {
                            msg = notificationTypeModelResponseList.Data.Where(w => w.NotificationTypeId == (int)EventType.WalletDebitEvent && w.NotificationTypeIdentifier == item.NotificationTypeIdentifier).Select(a => a.DisplayTemplate).FirstOrDefault();
                        }
                        message = TextTemplateMacroProcessor.Process(msg, new
                        {
                            CreditAmount = item.Amount,
                            Amount = item.Amount,
                            Name = item.UserName,
                            TransactionDesc = item.TransactionDesc,
                            UserName = item.UserName,
                            StoreName = item.StoreName,
                            TransactionCount = item.TransactionCount

                        }, item);
                        //    if ((DebitType)item.TypeId == (DebitType.LinkUserTransfer))
                        //    {
                        //        var msg = notificationTypeModelResponseList.Data.Where(w => w.NotificationTypeId == (int)EventType.WalletDebitEvent && w.NotificationTypeIdentifier == NotificationTypeIdentifierConstants.WalletLinkUserTransferDebitEvent).Select(a => a.DisplayTemplate).FirstOrDefault();
                        //        message = TextTemplateMacroProcessor.Process(msg, new
                        //        {
                        //            Amount = item.Amount,
                        //            TransferAmount = item.Amount,
                        //            Name= item.UserName,
                        //            item.UserName
                        //        }, item);
                        //    }
                        //    if ((DebitType)item.TypeId == (DebitType.AdminDebit))
                        //    {
                        //        var msg = notificationTypeModelResponseList.Data.Where(w => w.NotificationTypeId == (int)EventType.WalletDebitEvent && w.NotificationTypeIdentifier == NotificationTypeIdentifierConstants.AdminDebitEvent).Select(a => a.DisplayTemplate).FirstOrDefault();
                        //        message = TextTemplateMacroProcessor.Process(msg, new
                        //        {
                        //            CreditAmount = item.Amount,
                        //            Amount = item.Amount,
                        //            item.TransactionDesc
                        //        }, item);
                        //    }
                        //    if ((DebitType)item.TypeId == (DebitType.StorePumpReserve))
                        //    {
                        //        var msg = notificationTypeModelResponseList.Data.Where(w => w.NotificationTypeId == (int)EventType.WalletDebitEvent && w.NotificationTypeIdentifier == NotificationTypeIdentifierConstants.StoreWalletDebit).Select(a => a.DisplayTemplate).FirstOrDefault();
                        //        message = TextTemplateMacroProcessor.Process(msg, new
                        //        {
                        //            CreditAmount = item.Amount,
                        //            Amount = item.Amount,
                        //            item.TransactionDesc
                        //        }, item);
                        //    }
                        //    if ((DebitType)item.TypeId == (DebitType.StorePos))
                        //    {
                        //        var msg = notificationTypeModelResponseList.Data.Where(w => w.NotificationTypeId == (int)EventType.WalletDebitEvent && w.NotificationTypeIdentifier == NotificationTypeIdentifierConstants.StoreWalletDebit).Select(a => a.DisplayTemplate).FirstOrDefault();
                        //        message = TextTemplateMacroProcessor.Process(msg, new
                        //        {
                        //            CreditAmount = item.Amount,
                        //            Amount = item.Amount,
                        //            item.TransactionDesc
                        //        }, item);
                        //    }
                    }
                        item.Message = message;
                }
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }

        public string GetIdentifier(int id)
        {
            switch (id)
            {
                case 1:
                    return "";
                case 2:
                    return "";
                case 3:
                    return "";
                case 4:
                    return "";
                case 5:
                    return "";
                default:
                    return "";

            }
        }
    }
}
