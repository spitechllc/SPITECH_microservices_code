﻿using MediatR;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Finance.Domain.Models;

namespace SpiTech.Finance.Application.Queries.GetWalletHistory
{
    public class GetWalletHistoryQuery : IRequest<PaginatedList<WalletHistoryModel>>
    {
        public int UserId { get; set; }
        public int? PageIndex { get; set; }
        public int? PageSize { get; set; }
        public string culture { get; set; }
        
    }
}
