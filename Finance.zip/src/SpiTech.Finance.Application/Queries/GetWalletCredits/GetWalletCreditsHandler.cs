﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Queries.GetWalletCredits
{
    public class GetWalletCreditsHandler : IRequestHandler<GetWalletCreditsQuery, ResponseList<WalletCredit>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetWalletCreditsHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetWalletCreditsHandler(IUnitOfWork context,
                                    ILogger<GetWalletCreditsHandler> logger,
                                    IMapper mapper, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<ResponseList<WalletCredit>> Handle(GetWalletCreditsQuery request, CancellationToken cancellationToken)
        {
            IEnumerable<WalletCredit> result = null;
            _logger.TraceEnterMethod(nameof(Handle), request);
            this.userAuthenticationProvider.ValidateUserAccess(request.UserId);
            IEnumerable<WalletCredit> walletCredits = await _context.WalletCredits.GetAllByUserId(request.UserId);

            if (walletCredits != null)
            {
                result = walletCredits.Where(t => t.ExpireDate > System.DateTime.UtcNow && t.CurrentAmount > 0);
            }
            _logger.TraceExitMethod(nameof(Handle), result);

            return new ResponseList<WalletCredit> { Data = result };
        }
    }
}
