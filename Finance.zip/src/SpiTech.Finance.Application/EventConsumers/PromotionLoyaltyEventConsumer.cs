﻿using AutoMapper;
using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Marketings;
using SpiTech.Finance.Application.Commands.WalletCredits;
using SpiTech.Finance.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.EventConsumers
{
    public class PromotionLoyaltyEventConsumer : IConsumer<PromotionLoyaltyEvent>
    {
        private readonly IMediator mediator;
        private readonly ILogger<PromotionLoyaltyEventConsumer> logger;
        private readonly IMapper mapper;

        public PromotionLoyaltyEventConsumer(IMediator mediator, ILogger<PromotionLoyaltyEventConsumer> logger, IMapper mapper)
        {
            this.mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.mapper = mapper ?? throw new ArgumentNullException(nameof(mapper)); ;
        }

        public async Task Consume(ConsumeContext<PromotionLoyaltyEvent> context)
        {
            logger.TraceEnterMethod(nameof(Consume), context);
            try
            {
                logger.Warn($"PromotionLoyaltyEventConsumer with datetime : {DateTimeOffset.Now} " + context.Message.UserId);

                WalletCreditCommand command = new()
                {
                    Credits = mapper.Map<List<WalletCreditModel>>(context.Message.PromotionLoyalties),
                    UserId = context.Message.UserId,
                };

                if (command != null && command.Credits != null && command.Credits.Any())
                {
                    foreach (WalletCreditModel credit in command.Credits)
                    {
                        credit.CreditAmount = Math.Round(credit.CreditAmount, 2);
                    }
                }

                await mediator.Send(command);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            logger.Info($"PromotionLoyaltyEvent consumed successfully. UserId : {context.Message.UserId}");
        }
    }
}
