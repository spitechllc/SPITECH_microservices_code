﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Store;
using SpiTech.PaymentGateWay.Application.Commands.UpdateGetSite;
using System;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.EventConsumers
{
    public class StoreEventConsumer : IConsumer<StoreEvent>
    {
        private readonly IMediator mediator;
        private readonly ILogger<StoreEventConsumer> logger;

        public StoreEventConsumer(IMediator mediator, ILogger<StoreEventConsumer> logger)
        {
            this.mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task Consume(ConsumeContext<StoreEvent> context)
        {
            logger.TraceEnterMethod(nameof(Consume), context);

            if (string.IsNullOrWhiteSpace(context.Message.SiteId))
            {
                return;
            }

            await mediator.Send(new UpdateGetSiteCommand
            {
                SiteId = context.Message.SiteId,
                StoreId = context.Message.StoreId,
                StoreName = context.Message.StoreName,
                Update = true
            });

            logger.Info($"StoreEvent consumed successfully. StoreId : {context.Message.StoreId}");
        }

    }
}
