﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Identity;
using SpiTech.Finance.Application.Commands.Events.CreateUserWallet;
using System;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.EventConsumers
{
    public class IdentityUserCreatedEventConsumer : IConsumer<IdentityUserCreatedEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<IdentityUserCreatedEventConsumer> _logger;

        public IdentityUserCreatedEventConsumer(IMediator mediator, ILogger<IdentityUserCreatedEventConsumer> logger)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task Consume(ConsumeContext<IdentityUserCreatedEvent> context)
        {
            _logger.TraceEnterMethod(nameof(Consume), context);
            int userid = context.Message.UserId;
            int result = await CreateUserWallet(userid);

            _logger.Info($"IdentityUserCreatedEvent consumed successfully. UserId : {context.Message.UserId} - result:{result}");
        }

        private async Task<int> CreateUserWallet(int UserId)
        {
            int res = await _mediator.Send(new CreateUserWalletCommand
            {
                userId = UserId
            });

            return res;
        }
    }
}
