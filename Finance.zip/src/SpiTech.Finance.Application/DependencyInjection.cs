﻿using FluentValidation;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Finance;
using SpiTech.EventBus.DomainEvents.Events.Identity;
using SpiTech.EventBus.DomainEvents.Events.Marketings;
using SpiTech.EventBus.DomainEvents.Events.Store;
using SpiTech.EventBus.DomainEvents.ServiceCollection;
using SpiTech.Finance.Application.EventConsumers;
using SpiTech.Finance.Application.Processors;
using SpiTech.Finance.Application.Services;
using SpiTech.Finance.Domain.Mappers;
using System.Reflection;

namespace SpiTech.Finance.Application
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services, IConfiguration configuration)
        {
            services
                .AddMediatR(Assembly.GetExecutingAssembly()).AddAutoMapper(typeof(UserWalletProfile))
                .AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());

            services.AddTransient<IExpiringWalletCreditProcessor, ExpiringWalletCreditProcessor>();
            services.AddTransient<IPaymentProcessor, PaymentProcessor>();

            // MassTransit-RabbitMQ Configuration
            services.RegisterMessageQueue(configuration, config =>
            {
                config.AddConsumer<PromotionLoyaltyEventConsumer>();
                config.AddConsumer<IdentityUserCreatedEventConsumer>();
                config.AddConsumer<StoreEventConsumer>();
            }, (ctx, cfg) =>
            {
                cfg.ConfigurePublishEvent<ExpiringWalletCreditEvent>();
                cfg.ConfigurePublishEvent<TransferRequestDeclinedEvent>();
                cfg.ConfigurePublishEvent<TransferRequestEvent>();
                cfg.ConfigurePublishEvent<WalletCreditEvent>();
                cfg.ConfigurePublishEvent<WalletVoidPaymentEvent>();
                cfg.ConfigurePublishEvent<WalletDebitEvent>();

                cfg.BindConsumer<PromotionLoyaltyEvent, PromotionLoyaltyEventConsumer>(ctx, EventBusConstants.FinanceService);
                cfg.BindConsumer<IdentityUserCreatedEvent, IdentityUserCreatedEventConsumer>(ctx, EventBusConstants.FinanceService);
                cfg.BindConsumer<StoreEvent, StoreEventConsumer>(ctx, EventBusConstants.FinanceService);
            });
            return services;
        }
    }
}