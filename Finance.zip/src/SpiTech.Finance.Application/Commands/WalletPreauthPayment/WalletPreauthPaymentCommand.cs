﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Finance.Domain.Models;

namespace SpiTech.Finance.Application.Commands.WalletPreauthPayment
{
    public class WalletPreauthPaymentCommand : IRequest<ResponseModel<WalletPreauthDebitModel>>
    {
        public int UserId { get; set; }
        public decimal Amount { get; set; }
        public string TransactionDesc { get; set; }
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public DebitType DebitType { get; set; }
    }
}
