﻿using FluentValidation;

namespace SpiTech.Finance.Application.Commands.WalletPreauthPayment
{
    public class WalletPreauthPaymentValidator : AbstractValidator<WalletPreauthPaymentCommand>
    {
        public WalletPreauthPaymentValidator()
        {
            RuleFor(x => x.UserId).GreaterThan(0).WithMessage("UserId must be greater than 0");
            RuleFor(x => x.Amount).GreaterThan(0).WithMessage("Amount must be greater than 0");
            RuleFor(x => x.TransactionDesc).NotNull().NotEmpty().WithMessage("TransactionDesc is required").MaximumLength(100);
            RuleFor(x => x.DebitType).IsInEnum().WithMessage("CreditType is not valid");
            RuleFor(s => s.StoreName).MaximumLength(200);
        }
    }
}
