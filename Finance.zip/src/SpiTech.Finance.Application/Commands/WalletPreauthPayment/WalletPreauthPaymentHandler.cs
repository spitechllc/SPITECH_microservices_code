﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events;
using SpiTech.Finance.Application.Processors;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Commands.WalletPreauthPayment
{
    public class WalletPreauthPaymentHandler : IRequestHandler<WalletPreauthPaymentCommand, ResponseModel<WalletPreauthDebitModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<WalletPreauthPaymentHandler> _logger;
        private readonly IMediator mediator;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IPaymentProcessor paymentProcessor;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public WalletPreauthPaymentHandler(IUnitOfWork context,
                                             ILogger<WalletPreauthPaymentHandler> logger,
                                             IMediator mediator,
                                             IMapper mapper,
                                             IEventDispatcher eventDispatcher,
                                             IPaymentProcessor paymentProcessor, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            this.mediator = mediator;
            _mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.paymentProcessor = paymentProcessor;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<ResponseModel<WalletPreauthDebitModel>> Handle(WalletPreauthPaymentCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            this.userAuthenticationProvider.ValidateUserAccess(command.UserId);
            ResponseModel<WalletPreauthDebitModel> responseModel = new() { Success = false };

            await _context.Execute(async () =>
            {
                responseModel = await paymentProcessor.PreAuthWallet(command.UserId,
                command.Amount,
                command.TransactionDesc,
                command.DebitType,
                command.StoreId,
                command.StoreName, NotificationTypeIdentifierConstants.StoreWalletDebit);
            });

            _logger.TraceExitMethod(nameof(Handle), responseModel);
            return responseModel;
        }
    }
}
