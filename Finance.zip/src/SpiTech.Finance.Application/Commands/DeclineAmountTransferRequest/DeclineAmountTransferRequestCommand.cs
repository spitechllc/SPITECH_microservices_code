﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Finance.Application.Commands.DeclineAmountTransferRequest
{
    public class DeclineAmountTransferRequestCommand : IRequest<ResponseModel>
    {
        public int LinkMemberTransferId { get; set; }
    }
}
