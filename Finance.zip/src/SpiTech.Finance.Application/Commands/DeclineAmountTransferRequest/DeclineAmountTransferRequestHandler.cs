﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Finance;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Entities;
using System;
using System.Threading;
using System.Threading.Tasks;
using TransferStatus = SpiTech.EventBus.DomainEvents.Enums.TransferStatus;

namespace SpiTech.Finance.Application.Commands.DeclineAmountTransferRequest
{
    public class DeclineAmountTransferRequestHandler : IRequestHandler<DeclineAmountTransferRequestCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<DeclineAmountTransferRequestHandler> _logger;
        private readonly IMediator mediator;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public DeclineAmountTransferRequestHandler(IUnitOfWork context,
                                             ILogger<DeclineAmountTransferRequestHandler> logger,
                                             IMediator mediator,
                                             IEventDispatcher eventDispatcher,
                                             IMapper mapper, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            this.mediator = mediator;
            this.eventDispatcher = eventDispatcher;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        /// <summary>
        /// Decline Amount Transfer Request operation will perform that use dispatch 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ResponseModel> Handle(DeclineAmountTransferRequestCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel responseModel = new() { Success = false };
            bool status = false;
            LinkMemberTransfer linkMemberTransfer = await _context.LinkMemberTransfers.Get(command.LinkMemberTransferId);

            this.userAuthenticationProvider.ValidateUserAccess(linkMemberTransfer.FromUserId);

            if (linkMemberTransfer == null)
            {
                responseModel.Message = "Invalid LinkMemberTransferId";
                return responseModel;
            }

            if (linkMemberTransfer.TransferStatusId != 1)
            {
                responseModel.Message = "Invalid LinkMemberTransferId";
                return responseModel;
            }

            await _context.Execute(async () =>
            {
                if (linkMemberTransfer.TransferStatusId == (int)TransferStatus.New)
                {
                    status = await _context.LinkMemberTransfers.Update(new Domain.Entities.LinkMemberTransfer
                    {
                        LinkMemberTransferId = command.LinkMemberTransferId,
                        FromUserId = linkMemberTransfer.FromUserId,
                        ToUserId = linkMemberTransfer.ToUserId,
                        TransferAmount = linkMemberTransfer.TransferAmount,
                        RequestedDate = linkMemberTransfer.RequestedDate,
                        TransferStatusId = 4,
                        ActionDate = DateTime.UtcNow,
                    });
                }

                else if (linkMemberTransfer.TransferStatusId == (int)TransferStatus.Transfered)
                {
                    responseModel.Message = "Amount already transferred!";
                }
                else if (linkMemberTransfer.TransferStatusId == (int)TransferStatus.Rejected)
                {
                    responseModel.Message = "Amount transfer already declined!";
                }
            });

            if (status)
            {
                responseModel.Message = "Amount Transfer Declined";
                responseModel.Success = true;
                await eventDispatcher.Dispatch(new TransferRequestDeclinedEvent
                {
                    LinkMemberTransferId = command.LinkMemberTransferId,
                    FromUserId = linkMemberTransfer.FromUserId,
                    ToUserId = linkMemberTransfer.ToUserId,
                    TransferAmount = linkMemberTransfer.TransferAmount,
                    RequestedDate = linkMemberTransfer.RequestedDate ?? DateTime.UtcNow,
                    TransferStatusId = 4,
                    ActionDate = DateTime.UtcNow,
                });
            }

            _logger.TraceExitMethod(nameof(Handle), responseModel);
            return responseModel;
        }
    }
}
