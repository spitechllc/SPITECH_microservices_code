﻿using FluentValidation;

namespace SpiTech.Finance.Application.Commands.DeclineAmountTransferRequest
{
    public class DeclineAmountTransferRequestValidator : AbstractValidator<DeclineAmountTransferRequestCommand>
    {
        public DeclineAmountTransferRequestValidator()
        {
            RuleFor(x => x.LinkMemberTransferId).GreaterThan(0).WithMessage("RequestAmountTransferId must be greater than 0");
        }
    }
}
