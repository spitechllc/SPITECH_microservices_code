﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Finance.Application.Commands.UnLockUserWallet
{
    public class UnLockUserWalletCommand : IRequest<ResponseModel>
    {
        public int UserId { get; set; }
    }
}
