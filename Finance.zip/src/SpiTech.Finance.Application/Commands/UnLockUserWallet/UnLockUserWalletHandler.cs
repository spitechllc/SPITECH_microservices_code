﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Finance.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Commands.UnLockUserWallet
{
    public class UnLockUserWalletHandler : IRequestHandler<UnLockUserWalletCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UnLockUserWalletHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher eventDispatcher;

        public UnLockUserWalletHandler(IUnitOfWork context,
                                        ILogger<UnLockUserWalletHandler> logger,
                                        IMapper mapper,
                                        IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.eventDispatcher = eventDispatcher;
        }

        /// <summary>
        /// UnLock User Wallet and also use dispatch method which will cancel after 10 second
        /// </summary>
        /// <param name="command"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ResponseModel> Handle(UnLockUserWalletCommand command, CancellationToken cancellationToken)
        {
            ResponseModel result = new() { Success = false };
            _logger.TraceEnterMethod(nameof(Handle), command);
            Domain.Entities.Wallet userWallet = await _context.Wallets.GetByUserId(command.UserId);
            if (userWallet != null)
            {
                if (userWallet.IsTransactionLock)
                {
                    userWallet.IsTransactionLock = false;
                    userWallet.TransactionLockOn = null;
                    userWallet.TransactionLockId = null;
                    await _context.Wallets.Update(userWallet);
                }

                result = new ResponseModel { Success = true };
            }
            else
            {
                result = new ResponseModel { Success = false, Message = "Wallet not exist" };
            }

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
