﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events;
using SpiTech.EventBus.DomainEvents.Events.Finance;
using SpiTech.Finance.Application.Processors;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Entities;
using SpiTech.Finance.Domain.Models;
using System;
using System.Threading;
using System.Threading.Tasks;

using DebitType=SpiTech.EventBus.DomainEvents.Enums.DebitType;
using CreditType = SpiTech.EventBus.DomainEvents.Enums.CreditType;
using SpiTech.ApplicationCore.Authentication;

namespace SpiTech.Finance.Application.Commands.AcceptAmountTransferRequest
{
    public class AcceptAmountTransferRequestHandler : IRequestHandler<AcceptAmountTransferRequestCommand, ResponseModel<WalletDebitModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<AcceptAmountTransferRequestHandler> _logger;
        private readonly IMediator mediator;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IPaymentProcessor paymentProcessor;

        public AcceptAmountTransferRequestHandler(IUnitOfWork context,
                                             ILogger<AcceptAmountTransferRequestHandler> logger,
                                             IMediator mediator,
                                             IMapper mapper, IPaymentProcessor paymentProcessor,
                                             IEventDispatcher eventDispatcher, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            this.mediator = mediator;
            _mapper = mapper;
            this.paymentProcessor = paymentProcessor;
            _eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        /// <summary>
        /// Using this handler LinkMemberTransfer table update amount and other and also 
        /// perform dispatch operation
        /// </summary>
        /// <param name="command"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ResponseModel<WalletDebitModel>> Handle(AcceptAmountTransferRequestCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            ResponseModel<WalletDebitModel> responseModel = new() { Success = false };
            LinkMemberTransfer memberTransfer = new();
            memberTransfer = await _context.LinkMemberTransfers.Get(command.LinkMemberTransferId);

            this.userAuthenticationProvider.ValidateUserAccess(memberTransfer.FromUserId);

            await _context.Execute(async () =>
            {
                

                if (memberTransfer.TransferStatusId == (int)EventBus.DomainEvents.Enums.TransferStatus.New)
                {
                    responseModel = await paymentProcessor.Transfer(memberTransfer.FromUserId, memberTransfer.TransferAmount, memberTransfer.ToUserId, memberTransfer.LinkMemberTransferId,NotificationTypeIdentifierConstants.WalletLinkUserTransferDebitEvent);

                    memberTransfer.TransferStatusId = (int)responseModel.Data.TransferStatus;
                    memberTransfer.ActionDate = DateTime.UtcNow;
                    await _context.LinkMemberTransfers.Update(memberTransfer);
                }
                else
                {
                    responseModel.Message = "Invalid Transfer Request";
                }
            });


            EventBus.DomainEvents.Models.Finance.WalletCredit walletCreditEventModel = new()
            {
                CreditAmount = memberTransfer?.TransferAmount ?? 0,
                CreditDate = DateTime.UtcNow,
                CreditTypeId = (int)CreditType.LinkUserTransfer,
                LinkMemberTransferId = memberTransfer.LinkMemberTransferId,
                NotificationTypeIdentifier = NotificationTypeIdentifierConstants.WalletLinkUserTransferCreditEvent
            };
            WalletCreditEvent walletcreditevent = new()
            {
                UserId = memberTransfer?.ToUserId ?? 0,
                ToUserId = memberTransfer?.FromUserId ?? 0,
                WalletCredit = walletCreditEventModel,
                NotificationTypeIdentifier = NotificationTypeIdentifierConstants.WalletLinkUserTransferCreditEvent
            };
            await _eventDispatcher.Dispatch(walletcreditevent);

            EventBus.DomainEvents.Models.Finance.WalletDebit walletDebitEventModel = new()
            {
                Amount = memberTransfer?.TransferAmount ?? 0,
                DebitTypeId = (int)DebitType.LinkUserTransfer,
                DebitDate = DateTime.UtcNow,
                WalletDebitId = responseModel.Data?.WalletDebitId ?? 0,
                LinkMemberTransferId = memberTransfer.LinkMemberTransferId
            };
            WalletDebitEvent walletdebitevent = new()
            {
                UserId = memberTransfer?.FromUserId ?? 0,
                ToUserId = memberTransfer?.ToUserId ?? 0,
                WalletDebit = walletDebitEventModel,
                NotificationTypeIdentifier = NotificationTypeIdentifierConstants.WalletLinkUserTransferDebitEvent
            };
            await _eventDispatcher.Dispatch(walletdebitevent);

            _logger.TraceExitMethod(nameof(Handle), responseModel);
            return responseModel;
        }
    }
}
