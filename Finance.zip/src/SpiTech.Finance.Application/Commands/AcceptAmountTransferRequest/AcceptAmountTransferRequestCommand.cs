﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Domain.Models;

namespace SpiTech.Finance.Application.Commands.AcceptAmountTransferRequest
{
    public class AcceptAmountTransferRequestCommand : IRequest<ResponseModel<WalletDebitModel>>
    {
        public int LinkMemberTransferId { get; set; }
    }
}
