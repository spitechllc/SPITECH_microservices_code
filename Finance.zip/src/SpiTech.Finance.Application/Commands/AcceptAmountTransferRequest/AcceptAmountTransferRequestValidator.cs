﻿using FluentValidation;

namespace SpiTech.Finance.Application.Commands.AcceptAmountTransferRequest
{
    public class AcceptAmountTransferRequestValidator : AbstractValidator<AcceptAmountTransferRequestCommand>
    {
        public AcceptAmountTransferRequestValidator()
        {
            RuleFor(x => x.LinkMemberTransferId).GreaterThan(0).WithMessage("RequestAmountTransferId must be greater than 0");
        }
    }
}
