﻿using FluentValidation;

namespace SpiTech.Finance.Application.Commands.RequestAmountTransfer
{
    public class RequestAmountTransferValidator : AbstractValidator<RequestAmountTransferCommand>
    {
        public RequestAmountTransferValidator()
        {
            RuleFor(x => x.RequestedUserId).GreaterThan(0).WithMessage("RequestedUserId must be greater than 0");
            RuleFor(x => x.RequestedAmount).GreaterThan(0).WithMessage("Amount must be greater than 0");
            RuleFor(x => x.FromUserId).GreaterThan(0).WithMessage("FromUserId must be greater than 0");
        }
    }
}
