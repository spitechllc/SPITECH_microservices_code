﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Finance;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Commands.RequestAmountTransfer
{
    public class RequestAmountTransferHandler : IRequestHandler<RequestAmountTransferCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<RequestAmountTransferHandler> _logger;
        private readonly IMediator mediator;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IIdentityServiceClient identityClient;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public RequestAmountTransferHandler(IUnitOfWork context,
                                             ILogger<RequestAmountTransferHandler> logger,
                                             IMediator mediator,
                                             IMapper mapper,
                                             IEventDispatcher eventDispatcher,
                                             IIdentityServiceClient identityClient, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            this.mediator = mediator;
            _mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.identityClient = identityClient;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        /// <summary>
        /// Handler use for request amount transfer 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ResponseModel> Handle(RequestAmountTransferCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel responseModel = new() { Success = false };
            try
            {
                System.Collections.Generic.ICollection<Service.Clients.Identity.LinkUserModel> apiResponse = await identityClient.VerifyAsync(command.FromUserId, command.RequestedUserId);

                this.userAuthenticationProvider.ValidateUserAccess(command.RequestedUserId);

                if (apiResponse == null || !apiResponse.Any())
                {
                    responseModel.Message = "Users are not linked";
                    return responseModel;
                }

                int requestAmountTransferId = await _context.LinkMemberTransfers.Add(new Domain.Entities.LinkMemberTransfer
                {
                    ToUserId = command.RequestedUserId,
                    TransferAmount = command.RequestedAmount,
                    FromUserId = command.FromUserId,
                    TransferStatusId = 1,
                    RequestedDate = DateTime.UtcNow,
                });

                if (requestAmountTransferId > 0)
                {
                    responseModel.Success = true;
                    responseModel.Message = "Amount Transfer Requested!";
                    await eventDispatcher.Dispatch(new TransferRequestEvent
                    {
                        ToUserId = command.RequestedUserId,
                        TransferAmount = command.RequestedAmount,
                        FromUserId = command.FromUserId,
                        TransferStatusId = 1,
                        RequestedDate = DateTime.UtcNow,
                        LinkMemberTransferId = requestAmountTransferId
                    });
                }
                _context.Commit();
            }
            catch
            {
                _context.Rollback();
                throw;
            }

            _logger.TraceExitMethod(nameof(Handle), responseModel);
            return responseModel;
        }
    }
}
