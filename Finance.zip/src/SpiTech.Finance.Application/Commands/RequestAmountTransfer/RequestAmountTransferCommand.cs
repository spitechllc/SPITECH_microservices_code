﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Finance.Application.Commands.RequestAmountTransfer
{
    public class RequestAmountTransferCommand : IRequest<ResponseModel>
    {
        public int RequestedUserId { get; set; }
        public decimal RequestedAmount { get; set; }
        public int FromUserId { get; set; }
    }
}
