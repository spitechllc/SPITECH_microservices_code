﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Finance.Application.Commands.WalletVoidPayment
{
    public class WalletVoidPaymentCommand : IRequest<ResponseModel>
    {
        public string AuthNumber { get; set; }
    }
}
