﻿using FluentValidation;

namespace SpiTech.Finance.Application.Commands.WalletVoidPayment
{
    public class WalletVoidPaymentValidator : AbstractValidator<WalletVoidPaymentCommand>
    {
        public WalletVoidPaymentValidator()
        {
            RuleFor(x => x.AuthNumber).NotNull().NotEmpty().WithMessage("AuthNumber is required");
        }
    }
}
