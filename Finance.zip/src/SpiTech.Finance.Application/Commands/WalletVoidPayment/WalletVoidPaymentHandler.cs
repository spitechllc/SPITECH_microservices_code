﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Finance.Application.Processors;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Commands.WalletVoidPayment
{
    public class WalletVoidPaymentHandler : IRequestHandler<WalletVoidPaymentCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<WalletVoidPaymentHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IPaymentProcessor paymentProcessor;

        public WalletVoidPaymentHandler(IUnitOfWork context,
                                             ILogger<WalletVoidPaymentHandler> logger,
                                             IMapper mapper,
                                             IEventDispatcher eventDispatcher,
                                             IPaymentProcessor paymentProcessor
            )
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.paymentProcessor = paymentProcessor;
        }

        public async Task<ResponseModel> Handle(WalletVoidPaymentCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            ResponseModel<WalletDebit> responseModel = null;
            await _context.Execute(async () =>
            {
                responseModel = await paymentProcessor.Void(command.AuthNumber, true);
            });

            _logger.TraceExitMethod(nameof(Handle), responseModel);
            return responseModel.GetResponse();
        }
    }
}
