﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events;
using SpiTech.Finance.Application.Processors;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Entities;
using SpiTech.Finance.Domain.Models;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Commands.AdminCredit
{
    public class AdminCreditHandler : IRequestHandler<AdminCreditCommand, ResponseModel<List<WalletCreditModel>>>
    {
        private readonly IUnitOfWork context;
        private readonly IPaymentProcessor paymentProcessor;
        private readonly ILogger<AdminCreditHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IIdentityServiceClient identityClient;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public AdminCreditHandler(IUnitOfWork context,
                                    IPaymentProcessor paymentProcessor,
                                    ILogger<AdminCreditHandler> logger,
                                    IMapper mapper,
                                    IEventDispatcher eventDispatcher,
                                    IIdentityServiceClient identityClient,
                                    IUserAuthenticationProvider userAuthenticationProvider)
        {
            this.context = context;
            this.paymentProcessor = paymentProcessor;
            _logger = logger;
            _mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.identityClient = identityClient;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        /// <summary>
        /// Credit Operation perform and use table WalletCredit to add 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ResponseModel<List<WalletCreditModel>>> Handle(AdminCreditCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            ResponseModel<List<WalletCreditModel>> responseModel = new()
            {
                Success = false
            };

            Service.Clients.Identity.UserModelResponseModel userModel = await identityClient.GetUserByIdAsync(command.UserId);

            if (userModel == null || !userModel.Success)
            {
                responseModel.Message = "Invalid User";
            }
            else
            {
                await context.Execute(async () =>
                {
                    responseModel = await paymentProcessor.Credit(command.UserId,
                        userAuthenticationProvider.GetUserAuthentication().UserId,
                        new[] {
                            new WalletCreditModel {
                                CreditAmount = command.CreditAmount,
                                CreditIdentifier = null,
                                CreditType = EventBus.DomainEvents.Enums.CreditType.AdminCredit,
                                ExpireDate = System.DateTime.UtcNow.AddYears(1),
                                TransactionDesc = command.CreditReason,
                                NotificationTypeIdentifier=NotificationTypeIdentifierConstants.AdminCreditEvent,
                            }
                        });
                });
            }

            _logger.TraceExitMethod(nameof(Handle), responseModel);
            return responseModel;
        }
    }
}
