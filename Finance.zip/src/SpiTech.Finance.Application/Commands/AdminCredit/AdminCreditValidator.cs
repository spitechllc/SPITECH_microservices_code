﻿using FluentValidation;

namespace SpiTech.Finance.Application.Commands.AdminCredit
{
    public class AdminCreditValidator : AbstractValidator<AdminCreditCommand>
    {
        public AdminCreditValidator()
        {
            RuleFor(x => x.UserId).GreaterThan(0).WithMessage("UserId must be greater than 0");
            RuleFor(x => x.CreditAmount).GreaterThan(0);
            RuleFor(x => x.CreditReason).NotNull().NotEmpty().MinimumLength(10).MaximumLength(100);
        }
    }
}
