﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.Finance.Application.Commands.AdminCredit
{
    public class AdminCreditCommand : IRequest<ResponseModel<List<WalletCreditModel>>>
    {
        public int UserId { get; set; }
        public decimal CreditAmount { get; set; }
        public string CreditReason { get; set; }
    }
}
