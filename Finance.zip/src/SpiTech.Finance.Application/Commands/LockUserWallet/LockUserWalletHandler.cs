﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Entities;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Commands.LockUserWallet
{
    public class LockUserWalletHandler : IRequestHandler<LockUserWalletCommand, ResponseModel<Wallet>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<LockUserWalletHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher eventDispatcher;

        public LockUserWalletHandler(IUnitOfWork context,
                                        ILogger<LockUserWalletHandler> logger,
                                        IMapper mapper,
                                        IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.eventDispatcher = eventDispatcher;
        }

        public async Task<ResponseModel<Wallet>> Handle(LockUserWalletCommand command, CancellationToken cancellationToken)
        {
            ResponseModel<Wallet> result = new() { Success = false };

            _logger.TraceEnterMethod(nameof(Handle), command);
            Wallet userWallet = await _context.Wallets.GetByUserId(command.UserId);
            if (userWallet != null)
            {
                if (!userWallet.IsTransactionLock)
                {
                    userWallet.IsTransactionLock = true;
                    userWallet.TransactionLockOn = DateTime.UtcNow;
                    userWallet.TransactionLockId = Guid.NewGuid().ToString();
                    await _context.Wallets.Update(userWallet);
                    result.Success = true;
                    result.Data = userWallet;
                }
                else
                {
                    result.Message = "Wallet is locked. Please try later.";
                }
            }
            else
            {
                result.Message = "Wallet not exist";
            }

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
