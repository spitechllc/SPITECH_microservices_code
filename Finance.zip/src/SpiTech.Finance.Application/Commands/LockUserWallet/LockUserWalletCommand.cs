﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Domain.Entities;

namespace SpiTech.Finance.Application.Commands.LockUserWallet
{
    public class LockUserWalletCommand : IRequest<ResponseModel<Wallet>>
    {
        public int UserId { get; set; }
    }
}
