﻿using MediatR;

namespace SpiTech.Finance.Application.Commands.Events.CreateUserWallet
{
    public class CreateUserWalletCommand : IRequest<int>
    {
        public int userId { get; set; }
    }
}
