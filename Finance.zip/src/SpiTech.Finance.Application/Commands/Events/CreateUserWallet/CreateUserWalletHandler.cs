﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Commands.Events.CreateUserWallet
{
    public class CreateUserWalletHandler : IRequestHandler<CreateUserWalletCommand, int>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateUserWalletHandler> _logger;
        private readonly IMediator mediator;
        private readonly IMapper _mapper;

        public CreateUserWalletHandler(IUnitOfWork context,
                                             ILogger<CreateUserWalletHandler> logger,
                                             IMediator mediator,
                                             IMapper mapper)
        {
            _context = context;
            _logger = logger;
            this.mediator = mediator;
            _mapper = mapper;
        }

        public async Task<int> Handle(CreateUserWalletCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            Wallet userWallet = null;

            await _context.Execute(async () =>
            {
                userWallet = await _context.Wallets.GetByUserId(command.userId);

                if (userWallet == null)
                {
                    userWallet = new Wallet
                    {
                        UserId = command.userId,
                        IsActive = true,
                    };

                    userWallet.WalletId = await _context.Wallets.Add(userWallet);
                }
            });


            _logger.TraceExitMethod(nameof(Handle), userWallet);
            return userWallet?.WalletId ?? 0;
        }
    }
}
