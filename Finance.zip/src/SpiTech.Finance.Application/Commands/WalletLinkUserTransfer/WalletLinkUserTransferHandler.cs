﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events;
using SpiTech.EventBus.DomainEvents.Events.Finance;
using SpiTech.Finance.Application.Processors;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Commands.WalletLinkUserTransfer
{
    public class WalletLinkUserTransferHandler : IRequestHandler<WalletLinkUserTransferCommand, ResponseModel<WalletDebitModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<WalletLinkUserTransferHandler> _logger;
        private readonly IMediator mediator;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IPaymentProcessor paymentProcessor;
        private readonly IIdentityServiceClient identityapiclient;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public WalletLinkUserTransferHandler(IUnitOfWork context,
                                             ILogger<WalletLinkUserTransferHandler> logger,
                                             IMediator mediator,
                                             IMapper mapper,
                                             IEventDispatcher eventDispatcher,
                                             IPaymentProcessor paymentProcessor,
                                             IIdentityServiceClient identityclient, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            this.mediator = mediator;
            _mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.paymentProcessor = paymentProcessor;
            identityapiclient = identityclient;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        /// <summary>
        /// Wallet Link User Transfer
        /// </summary>
        /// <param name="command"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ResponseModel<WalletDebitModel>> Handle(WalletLinkUserTransferCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            ResponseModel<WalletDebitModel> responseModel = new() { Success = false };
            this.userAuthenticationProvider.ValidateUserAccess(command.FromUserId);

            System.Collections.Generic.ICollection<Service.Clients.Identity.LinkUserModel> apiResponse = await identityapiclient.VerifyAsync(command.FromUserId, command.ToUserId);

            if (apiResponse == null || !apiResponse.Any())
            {
                responseModel.Message = "Users are not linked";
                return responseModel;
            }

            Domain.Entities.LinkMemberTransfer memberTransfer = new()
            {
                ToUserId = command.ToUserId,
                TransferAmount = command.Amount,
                FromUserId = command.FromUserId,
                TransferStatusId = 1,
                RequestedDate = DateTime.UtcNow,
            };

            await _context.Execute(async () =>
            {
                memberTransfer.LinkMemberTransferId = await _context.LinkMemberTransfers.Add(memberTransfer);

                responseModel = await paymentProcessor.Transfer(command.FromUserId, command.Amount, command.ToUserId, memberTransfer.LinkMemberTransferId,NotificationTypeIdentifierConstants.WalletLinkUserTransferDebitEvent);

                memberTransfer.TransferStatusId = (int)responseModel.Data.TransferStatus;
                memberTransfer.ActionDate = DateTime.UtcNow;
                await _context.LinkMemberTransfers.Update(memberTransfer);
            });


            EventBus.DomainEvents.Models.Finance.WalletCredit walletCreditEventModel = new()
            {
                CreditAmount = command.Amount,
                CreditDate = DateTime.UtcNow,
                CreditTypeId = (int)CreditType.LinkUserTransfer,
                LinkMemberTransferId = memberTransfer.LinkMemberTransferId,
                NotificationTypeIdentifier = NotificationTypeIdentifierConstants.WalletLinkUserTransferCreditEvent
            };
            WalletCreditEvent walletcreditevent = new()
            {
                UserId = command.ToUserId,
                ToUserId=command.FromUserId,
                WalletCredit = walletCreditEventModel,
                NotificationTypeIdentifier = NotificationTypeIdentifierConstants.WalletLinkUserTransferCreditEvent
            };
            await eventDispatcher.Dispatch(walletcreditevent);


            EventBus.DomainEvents.Models.Finance.WalletDebit walletDebitEventModel = new()
            {
                Amount = command.Amount,
                DebitTypeId = (int)DebitType.LinkUserTransfer,
                DebitDate = DateTime.UtcNow,
                WalletDebitId= responseModel.Data?.WalletDebitId ?? 0, 
                LinkMemberTransferId= memberTransfer.LinkMemberTransferId
            };
            WalletDebitEvent walletdebitevent = new()
            {
                UserId = command.FromUserId,
                ToUserId=command.ToUserId,
                WalletDebit = walletDebitEventModel,
                NotificationTypeIdentifier = NotificationTypeIdentifierConstants.WalletLinkUserTransferDebitEvent
            };
            await eventDispatcher.Dispatch(walletdebitevent);

            _logger.TraceExitMethod(nameof(Handle), responseModel);
            return responseModel;
        }
    }
}
