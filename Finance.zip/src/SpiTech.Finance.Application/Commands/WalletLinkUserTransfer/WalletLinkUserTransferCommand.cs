﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Domain.Models;

namespace SpiTech.Finance.Application.Commands.WalletLinkUserTransfer
{
    public class WalletLinkUserTransferCommand : IRequest<ResponseModel<WalletDebitModel>>
    {
        public int FromUserId { get; set; }
        public decimal Amount { get; set; }
        public int ToUserId { get; set; }
    }
}
