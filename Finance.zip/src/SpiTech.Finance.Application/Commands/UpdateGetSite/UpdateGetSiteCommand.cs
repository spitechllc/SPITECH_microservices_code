﻿using MediatR;

namespace SpiTech.PaymentGateWay.Application.Commands.UpdateGetSite
{
    public class UpdateGetSiteCommand : IRequest<bool>
    {
        public string StoreName { get; set; }
        public string SiteId { get; set; }
        public int StoreId { get; set; }
        public bool Update { get; set; }
    }
}
