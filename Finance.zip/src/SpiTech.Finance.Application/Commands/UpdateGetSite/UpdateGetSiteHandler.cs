﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.UpdateGetSite
{
    public class UpdateGetSiteHandler : IRequestHandler<UpdateGetSiteCommand, bool>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateGetSiteHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IStoreServiceClient storeApiClient;

        public UpdateGetSiteHandler(IUnitOfWork context,
                                   ILogger<UpdateGetSiteHandler> logger,
                                   IMapper mapper,
                                   IStoreServiceClient storeApiClient)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.storeApiClient = storeApiClient;
        }

        public async Task<bool> Handle(UpdateGetSiteCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            bool result = true;

            try
            {
                await _context.Execute(async () =>
                {
                    await _context.WalletCredits.Update(command.StoreId, command.SiteId, command.StoreName);
                });
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
