﻿using FluentValidation;

namespace SpiTech.Finance.Application.Commands.WalletCredits
{
    public class WalletCreditValidator : AbstractValidator<WalletCreditCommand>
    {
        public WalletCreditValidator()
        {
            RuleFor(x => x.UserId).GreaterThan(0).WithMessage("UserId must be greater than 0");
            RuleFor(x => x.Credits).NotNull().WithMessage("Credits is null");

        }
    }
}
