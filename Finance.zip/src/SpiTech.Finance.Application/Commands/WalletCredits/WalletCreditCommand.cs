﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Domain.Entities;
using SpiTech.Finance.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.Finance.Application.Commands.WalletCredits
{
    public class WalletCreditCommand : IRequest<ResponseModel<List<WalletCreditModel>>>
    {
        public int UserId { get; set; }
        public List<WalletCreditModel> Credits { get; set; }
    }
}
