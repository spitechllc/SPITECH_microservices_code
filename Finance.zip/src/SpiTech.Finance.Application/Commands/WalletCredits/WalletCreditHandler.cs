﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Finance.Application.Processors;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Entities;
using SpiTech.Finance.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Commands.WalletCredits
{
    public class WalletCreditHandler : IRequestHandler<WalletCreditCommand, ResponseModel<List<WalletCreditModel>>>
    {
        private readonly IUnitOfWork context;
        private readonly IPaymentProcessor paymentProcessor;
        private readonly ILogger<WalletCreditHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public WalletCreditHandler(IUnitOfWork context,
                                    IPaymentProcessor paymentProcessor,
                                    ILogger<WalletCreditHandler> logger,
                                    IMapper mapper,
                                    IEventDispatcher eventDispatcher, IUserAuthenticationProvider userAuthenticationProvider)
        {
            this.context = context;
            this.paymentProcessor = paymentProcessor;
            _logger = logger;
            _mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<ResponseModel<List<WalletCreditModel>>> Handle(WalletCreditCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            this.userAuthenticationProvider.ValidateUserAccess(command.UserId);
            _logger.Warn($"Step2 Finance Service WalletCreditHandler with datetime : {DateTimeOffset.Now} " + command.UserId);
            ResponseModel<List<WalletCreditModel>> responseModel = new()
            {
                Success = false,
                Data = new List<WalletCreditModel>()
            };

            if (command.Credits == null || !command.Credits.Any() || command.Credits.Any(t => t == null))
            {
                responseModel.Message = "WalletCredit is null";
                return responseModel;
            }

            await context.Execute(async () =>
            {
                responseModel = await paymentProcessor.Credit(command.UserId, command.UserId, command.Credits.ToArray());
            });

            _logger.TraceExitMethod(nameof(Handle), responseModel);
            return responseModel;
        }
    }
}
