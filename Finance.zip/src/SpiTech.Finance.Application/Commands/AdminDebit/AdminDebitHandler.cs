﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events;
using SpiTech.EventBus.DomainEvents.Events.Finance;
using SpiTech.Finance.Application.Processors;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Commands.AdminDebit
{
    public class AdminDebitHandler : IRequestHandler<AdminDebitCommand, ResponseModel<WalletDebitModel>>
    {
        private readonly IUnitOfWork context;
        private readonly IPaymentProcessor paymentProcessor;
        private readonly ILogger<AdminDebitHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public AdminDebitHandler(IUnitOfWork context,
                                    IPaymentProcessor paymentProcessor,
                                    ILogger<AdminDebitHandler> logger,
                                    IMapper mapper,
                                    IEventDispatcher eventDispatcher,
                                    IUserAuthenticationProvider userAuthenticationProvider)
        {
            this.context = context;
            this.paymentProcessor = paymentProcessor;
            _logger = logger;
            _mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        /// <summary>
        /// Admin perform Debit amount in which check user authenticate after that 
        /// use table WalletDebits
        /// </summary>
        /// <param name="command"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ResponseModel<WalletDebitModel>> Handle(AdminDebitCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            ResponseModel<WalletDebitModel> responseModel = new()
            {
                Success = false,
                Message = "Unable to debit amount"
            };

            await context.Execute(async () =>
            {
                responseModel = await paymentProcessor.AdminDebit(command.UserId, command.DebitAmount, command.DebitReason, userAuthenticationProvider.GetUserAuthentication().UserId,NotificationTypeIdentifierConstants.AdminDebitEvent);
            });

            EventBus.DomainEvents.Models.Finance.WalletDebit walletDebitEventModel = new()
            {
                Amount = command.DebitAmount,
                DebitTypeId = (int)DebitType.AdminDebit,
                DebitDate = DateTime.UtcNow,
                WalletDebitId = responseModel.Data?.WalletDebitId ?? 0,
                TransactionDesc= command.DebitReason,
            };

            WalletDebitEvent walletdebitevent = new()
            {
                UserId = userAuthenticationProvider.GetUserAuthentication().UserId,
                WalletDebit = walletDebitEventModel,
                NotificationTypeIdentifier = NotificationTypeIdentifierConstants.AdminDebitEvent
            };
            await eventDispatcher.Dispatch(walletdebitevent);
            _logger.TraceExitMethod(nameof(Handle), responseModel);
            return responseModel;
        }
    }
}
