﻿using FluentValidation;

namespace SpiTech.Finance.Application.Commands.AdminDebit
{
    public class AdminDebitValidator : AbstractValidator<AdminDebitCommand>
    {
        public AdminDebitValidator()
        {
            RuleFor(x => x.UserId).GreaterThan(0).WithMessage("UserId must be greater than 0");
            RuleFor(x => x.DebitAmount).GreaterThan(0);
            RuleFor(x => x.DebitReason).NotNull().NotEmpty().MinimumLength(10).MaximumLength(100);
        }
    }
}
