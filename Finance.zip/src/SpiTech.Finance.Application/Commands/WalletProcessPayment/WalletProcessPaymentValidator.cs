﻿using FluentValidation;

namespace SpiTech.Finance.Application.Commands.WalletProcessPayment
{
    public class WalletProcessPaymentValidator : AbstractValidator<WalletProcessPaymentCommand>
    {
        public WalletProcessPaymentValidator()
        {
            RuleFor(x => x.TransactionId).GreaterThan(0).WithMessage("TransactionId must be greater than 0");
            RuleFor(x => x.Amount).GreaterThan(0).WithMessage("Amount must be greater than 0");
            RuleFor(x => x.AuthNumber).NotNull().NotEmpty().WithMessage("AuthNumber is required");
        }
    }
}
