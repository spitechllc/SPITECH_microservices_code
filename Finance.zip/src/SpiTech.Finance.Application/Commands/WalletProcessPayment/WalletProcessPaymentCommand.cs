﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Finance.Application.Commands.WalletProcessPayment
{
    public class WalletProcessPaymentCommand : IRequest<ResponseModel>
    {
        public long TransactionId { get; set; }
        public decimal Amount { get; set; }
        public string AuthNumber { get; set; }
    }
}