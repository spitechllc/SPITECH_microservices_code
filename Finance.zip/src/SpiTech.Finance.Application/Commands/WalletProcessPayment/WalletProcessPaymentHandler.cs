﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events;
using SpiTech.EventBus.DomainEvents.Events.Finance;
using SpiTech.Finance.Application.Processors;
using SpiTech.Finance.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Commands.WalletProcessPayment
{
    public class WalletProcessPaymentHandler : IRequestHandler<WalletProcessPaymentCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<WalletProcessPaymentHandler> _logger;
        private readonly IMediator mediator;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IPaymentProcessor paymentProcessor;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public WalletProcessPaymentHandler(IUnitOfWork context,
                                           ILogger<WalletProcessPaymentHandler> logger,
                                           IMediator mediator,
                                           IMapper mapper,
                                           IEventDispatcher eventDispatcher,
                                           IPaymentProcessor paymentProcessor, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            this.mediator = mediator;
            _mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.paymentProcessor = paymentProcessor;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<ResponseModel> Handle(WalletProcessPaymentCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            ResponseModel responseModel = new() { Success = false };

            try
            {
                long walletDebitId = 0;
                Domain.Entities.WalletDebit walletDebit = await _context.WalletDebits.GetByAuthNumber(command.AuthNumber);
               
                if (walletDebit != null)
                {
                    Domain.Entities.Wallet wallet = await _context.Wallets.Get(walletDebit.WalletId);

                    this.userAuthenticationProvider.ValidateUserAccess(wallet.UserId);

                    walletDebitId = walletDebit.WalletDebitId;

                    if (command.Amount > walletDebit.Amount)
                    {
                        responseModel.Message = "Amount should not be greater than preauth amount";
                        return responseModel;
                    }

                    if (walletDebit.Amount == command.Amount)
                    {
                        walletDebit.TransactionId = command.TransactionId;
                        walletDebit.DebitStateId = (int)DebitState.Completed;
                        walletDebit.NotificationTypeIdentifier = NotificationTypeIdentifierConstants.StoreWalletDebit;
                        await _context.WalletDebits.Update(walletDebit);
                        responseModel.Success = true;
                    }
                    else
                    {
                        responseModel = await paymentProcessor.Void(command.AuthNumber, command.Amount == 0);

                        if (responseModel.Success)
                        {
                            if (command.Amount > 0)
                            {
                                ResponseModel<Domain.Models.WalletDebitModel> finalResponseModel = await paymentProcessor.FinalPayment(wallet.UserId,
                                                                                    command.Amount,
                                                                                    walletDebit.TransactionDesc,
                                                                                    (DebitType)walletDebit.DebitTypeId,
                                                                                    walletDebit.AuthNumber,
                                                                                    walletDebit.StoreId,
                                                                                    walletDebit.StoreName,
                                                                                    command.TransactionId,NotificationTypeIdentifierConstants.StoreWalletDebit);

                                responseModel.Success = finalResponseModel.Success;
                                responseModel.Message = finalResponseModel.Message;
                            }
                        }
                    }

                    EventBus.DomainEvents.Models.Finance.WalletDebit walletDebitEventModel = new()
                    {
                        WalletDebitId = walletDebitId,
                        TransactionId = command.TransactionId,
                        Amount = command.Amount,
                        AuthNumber = command.AuthNumber,
                        StoreId = walletDebit.StoreId,
                        StoreName = walletDebit.StoreName,
                        TransactionDesc=walletDebit.TransactionDesc,
                    };

                    WalletDebitEvent walletDebitEvent = new()
                    {
                        WalletDebit = walletDebitEventModel,
                        UserId = wallet.UserId,
                        NotificationTypeIdentifier = NotificationTypeIdentifierConstants.StoreWalletDebit
                    };

                    await eventDispatcher.Dispatch(walletDebitEvent);
                }
                else
                {
                    responseModel.Success = false;
                    responseModel.Message = "Invalid AuthNumber";
                }
                _context.Commit();
            }
            catch
            {
                _context.Rollback();
                throw;
            }

            _logger.TraceExitMethod(nameof(Handle), responseModel);
            return responseModel;
        }
    }
}
