﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Finance;
using SpiTech.EventBus.DomainEvents.Models.Finance;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Services
{
    public class ExpiringWalletCreditProcessor : IExpiringWalletCreditProcessor
    {
        private readonly ILogger<ExpiringWalletCreditProcessor> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        public IServiceScope ServiceScope { get; set; }

        public ExpiringWalletCreditProcessor(ILogger<ExpiringWalletCreditProcessor> logger, IUnitOfWork context,
                                   IMediator mediator,
                                   IMapper mapper, IServiceScopeFactory scopeFactory, IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            ServiceScope = scopeFactory.CreateScope();
            _eventDispatcher = eventDispatcher;
        }

        public async Task<IEnumerable<WalletCreditExpiringResult>> NotifyExpiringCredits(CancellationToken stoppingToken)
        {
            Domain.Entities.Config executiondate = await _context.Configs.GetIsNotificationSent();
            if (executiondate == null)
            {
                while (!stoppingToken.IsCancellationRequested)
                {
                    List<WalletCreditExpiringResult> expirycreditdetails;

                    IEnumerable<WalletCreditExpiringResult> expiringwalletcredits = await _context.WalletCredits.GetAllExpiringWalletCredit(5);

                    if (expiringwalletcredits != null && expiringwalletcredits.Count() > 0)
                    {
                        IEnumerable<IGrouping<int, WalletCreditExpiringResult>> walletcredit = expiringwalletcredits.GroupBy(expiringwalletcredits => expiringwalletcredits.UserId);

                        foreach (IGrouping<int, WalletCreditExpiringResult> creditdetails in walletcredit)
                        {
                            expirycreditdetails = new List<WalletCreditExpiringResult>();

                            ExpiringWalletCreditEvent expiringWalletCreditEvent = new()
                            {
                                UserId = creditdetails.Key
                            };

                            foreach (WalletCreditExpiringResult items in creditdetails)
                            {
                                expirycreditdetails.Add(items);
                            }

                            expiringWalletCreditEvent.WalletCredits = _mapper.Map<List<WalletCredit>>(expirycreditdetails);

                            await _eventDispatcher.Dispatch(expiringWalletCreditEvent);

                            foreach (WalletCreditExpiringResult items in creditdetails)
                            {
                                bool status = await _context.WalletCredits.Update(new Domain.Entities.WalletCredit()
                                {
                                    WalletCreditId = items.WalletCreditId,
                                    LastNotificationSentDate = DateTime.UtcNow,
                                });
                            }
                        }

                        await NotifyExpiringCredits(stoppingToken);
                    }
                    else
                    {
                        int configid = await _context.Configs.Add(new Domain.Entities.Config()
                        {
                            LastExecutionTime = DateTime.UtcNow,
                        });
                    }
                    await Task.Delay(3600000, stoppingToken);
                }
            }

            return null;
        }
    }
}
