﻿
using SpiTech.Finance.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Services
{
    public interface IExpiringWalletCreditProcessor
    {
        Task<IEnumerable<WalletCreditExpiringResult>> NotifyExpiringCredits(CancellationToken stoppingToken);
    }
}
