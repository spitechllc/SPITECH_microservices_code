﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Services
{
    public class ExpiringWalletCreditBackgroundService : BackgroundService
    {
        private readonly ILogger<ExpiringWalletCreditBackgroundService> _logger;
        private readonly IServiceScope serviceScope;
        private readonly IExpiringWalletCreditProcessor _walletCreditExpiringRetry;

        public ExpiringWalletCreditBackgroundService(
                                             ILogger<ExpiringWalletCreditBackgroundService> logger,
                                             IServiceScopeFactory scopeFactory
                                             )
        {
            _logger = logger;
            serviceScope = scopeFactory.CreateScope();
            _walletCreditExpiringRetry = serviceScope.ServiceProvider.GetService<IExpiringWalletCreditProcessor>();
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation($"ExpiringWalletCreditBackgroundService starting");
            await WalletCreditExpiring(stoppingToken);
        }

        private async Task WalletCreditExpiring(CancellationToken stoppingToken)
        {
            await _walletCreditExpiringRetry.NotifyExpiringCredits(stoppingToken);
        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            return base.StopAsync(cancellationToken);
        }
    }
}
