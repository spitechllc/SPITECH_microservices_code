﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events;
using SpiTech.EventBus.DomainEvents.Events.Finance;
using SpiTech.Finance.Application.Commands.LockUserWallet;
using SpiTech.Finance.Application.Commands.UnLockUserWallet;
using SpiTech.Finance.Application.Queries.GetActiveWalletCredits;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Domain;
using SpiTech.Finance.Domain.Entities;
using SpiTech.Finance.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Processors
{
    public class PaymentProcessor : IPaymentProcessor
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<PaymentProcessor> _logger;
        private readonly IMediator mediator;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher eventDispatcher;

        public PaymentProcessor(IUnitOfWork context,
                                ILogger<PaymentProcessor> logger,
                                IMediator mediator,
                                IMapper mapper,
                                IEventDispatcher eventDispatcher)
        {
            this.context = context;
            _logger = logger;
            this.mediator = mediator;
            _mapper = mapper;
            this.eventDispatcher = eventDispatcher;
        }

        public async Task<ResponseModel<List<WalletCreditModel>>> Credit(int userId, int creditedBy, params WalletCreditModel[] walletCredits)
        {
            _logger.TraceEnterMethod(nameof(Credit), walletCredits);
            ResponseModel<List<WalletCreditModel>> responseModel = new()
            {
                Success = false,
                Data = new List<WalletCreditModel>()
            };

            if (walletCredits == null || !walletCredits.Any() || walletCredits.Any(t => t == null))
            {
                responseModel.Message = "WalletCredit is null";
                return responseModel;
            }

            Wallet wallet = await GetOrCreateUserWallet(userId);
            _logger.Warn($"Step3 walletCredits with datetime : {DateTimeOffset.Now} " + userId);
            foreach (WalletCreditModel walletCredit in walletCredits)
            {
                if (walletCredit.TransactionId != null)
                {
                    WalletCredit duplicatedata = await context.WalletCredits.CheckDuplicateCredit((int)walletCredit.TransactionId, (int)walletCredit.CreditType, userId);

                    if (duplicatedata != null)
                    {
                        continue;
                    }
                }

                WalletCredit credit = new()
                {
                    WalletId = wallet.WalletId,
                    CreditAmount =  walletCredit.CreditAmount,
                    CurrentAmount = walletCredit.CreditAmount,
                    TransactionAmount = walletCredit.TransactionAmount,
                    StoreId = walletCredit.StoreId,
                    StoreName = walletCredit.StoreName,
                    TransactionId = walletCredit.TransactionId,
                    TransactionDesc = walletCredit.TransactionDesc,
                    TransactionTypeId = walletCredit.TransactionTypeId,
                    LinkMemberTransferId = walletCredit.LinkMemberTransferId,
                    FromWalletCreditId = walletCredit.FromWalletCreditId,
                    LastNotificationSentDate = DateTime.UtcNow,
                    CreditTypeId = (int)walletCredit.CreditType,
                    CreditDate = DateTime.UtcNow,
                    ExpireDate = walletCredit.ExpireDate,
                    PaymentMethodId = walletCredit.PaymentMethodId,
                    UserPaymentMethodId = walletCredit.UserPaymentMethodId,
                    IsActive = true,
                    CreatedBy = creditedBy,
                    CreditIdentifier = walletCredit.CreditIdentifier,
                    CreatedOn = DateTime.UtcNow,
                    TransactionCount=walletCredit.TransactionCount,
                    NotificationTypeIdentifier=walletCredit.NotificationTypeIdentifier,
                };

                credit.WalletCreditId = await context.WalletCredits.Add(credit);

                _logger.Warn($"Step3 done wallet credit : {DateTimeOffset.Now} ");

                WalletCreditModel creditModel = null;
                creditModel = _mapper.Map<WalletCreditModel>(credit);
                creditModel.NotificationTypeIdentifier = walletCredit.NotificationTypeIdentifier;
                creditModel.TransactionCount = walletCredit.TransactionCount;


                responseModel.Data.Add(creditModel);
            }

            List<EventBus.DomainEvents.Models.Finance.WalletCredit> walletCreditEventModels = _mapper.Map<List<EventBus.DomainEvents.Models.Finance.WalletCredit>>(responseModel.Data);
            if (walletCreditEventModels != null)
            {
                foreach (EventBus.DomainEvents.Models.Finance.WalletCredit walletCreditEventModel in walletCreditEventModels)
                {
                    WalletCreditEvent walletcreditevent = new()
                    {
                        UserId = userId,
                        WalletCredit = walletCreditEventModel,
                        NotificationTypeIdentifier = walletCreditEventModel.NotificationTypeIdentifier
                    };
                    await eventDispatcher.Dispatch(walletcreditevent);
                }
            }

            responseModel.Success = true;
            _logger.Warn($"Done wallet Process : {DateTimeOffset.Now} ");

            _logger.TraceExitMethod(nameof(Credit), responseModel);
            return responseModel;
        }

        public async Task<ResponseModel<WalletPreauthDebitModel>> PreAuthWallet(int userId,
                                                                           decimal amount,
                                                                           string transactionDesc,
                                                                           EventBus.DomainEvents.Enums.DebitType debitType,
                                                                           int storeId,
                                                                           string storeName,string notificationTypeIdentifier)
        {
            string authNumber = Guid.NewGuid().ToString("N");
            ResponseModel<WalletDebitModel> response = await Process(userId, amount, transactionDesc, debitType, authNumber, null, null, storeId, storeName, null, DebitState.PreAuth, userId, notificationTypeIdentifier);

            ResponseModel<WalletPreauthDebitModel> preauthResponse = new()
            {
                Message = response.Message,
                Success = response.Success
            };
            if (response.Data != null)
            {
                preauthResponse.Data = new WalletPreauthDebitModel
                {
                    AuthNumber = response.Data.AuthNumber,
                    BalanceAmount = response.Data.BalanceAmount,
                    DebitAmount = response.Data.DebitAmount,
                };
            }
            return preauthResponse;
        }

        public async Task<ResponseModel<WalletDebitModel>> AdminDebit(int userId, decimal amount, string debitReason, int debitedBy,string notificationTypeIdentifier)
        {
            string authNumber = Guid.NewGuid().ToString("N");
            return await Process(userId, amount, debitReason, EventBus.DomainEvents.Enums.DebitType.AdminDebit, authNumber, null, null, null, null, null, DebitState.Completed, debitedBy,notificationTypeIdentifier);
        }

        public async Task<ResponseModel<WalletDebitModel>> FinalPayment(int userId,
                                                                           decimal amount,
                                                                           string transactionDesc,
                                                                           EventBus.DomainEvents.Enums.DebitType debitType,
                                                                           string authNumber,
                                                                           int? storeId,
                                                                           string storeName,
                                                                           long transactionId,string notificationTypeIdentifier)
        {
            return await Process(userId, amount, transactionDesc, debitType, authNumber, null, null, storeId, storeName, transactionId, DebitState.Completed, userId,notificationTypeIdentifier);
        }

        public Task<ResponseModel<WalletDebitModel>> Transfer(int userId,
                                            decimal amount,
                                            int toUserId,
                                            int? linkMemberTransferId,string notificationTypeIdentifier)
        {
            string authNumber = Guid.NewGuid().ToString("N");

            return Process(userId, amount, null, EventBus.DomainEvents.Enums.DebitType.LinkUserTransfer, authNumber, toUserId,
                                                linkMemberTransferId, null, null, null, DebitState.Completed, userId,notificationTypeIdentifier);
        }

        public async Task<ResponseModel<WalletDebit>> Void(string authNumber, bool notifyUser)
        {
            ResponseModel<WalletDebit> responseModel = new() { Success = false };
            WalletDebit walletDebit = await context.WalletDebits.GetByAuthNumber(authNumber);

            if (walletDebit != null)
            {
                responseModel.Data = walletDebit;
                walletDebit.RefundDate = DateTime.UtcNow;
                walletDebit.IsRefunded = true;
                walletDebit.DebitStateId = (int)DebitState.Completed;

                IEnumerable<WalletDebitDetail> walletDebitDetails = await context.WalletDebitDetails.GetByWalletDebitId(walletDebit.WalletDebitId);
                IEnumerable<WalletCredit> walletCredits = await context.WalletCredits.GetAllByWalletCreditIds(walletDebitDetails.Select(t => t.FromWalletCreditId).ToArray());

                foreach (WalletDebitDetail walletDebitDetail in walletDebitDetails)
                {
                    WalletCredit walletCredit = walletCredits.FirstOrDefault(t => t.WalletCreditId == walletDebitDetail.FromWalletCreditId);
                    walletCredit.CurrentAmount = 0; //walletDebitDetail.Amount;
                    walletCredit.CreditAmount = 0; //walletDebitDetail.Amount;
                    walletCredit.IsRefunded = true;
                    walletCredit.RefundDate = DateTime.UtcNow;
                }

                await context.WalletDebits.Update(walletDebit);

                foreach (WalletCredit walletCredit in walletCredits)
                {
                    await context.WalletCredits.Add(walletCredit);
                }

                responseModel.Success = true;
            }
            else
            {
                responseModel.Message = "Invalid AuthNumber";
            }

            if (walletDebit != null && notifyUser && responseModel.Success)
            {
                Wallet user = await context.Wallets.Get(walletDebit.WalletId);

                WalletVoidPaymentEvent walletVoidPaymentEvent = new()
                {
                    UserId = user.UserId,
                    AuthNumber = authNumber,
                    RefundDate = DateTime.UtcNow,
                    IsRefunded = true,
                    WalletDebitId = walletDebit.WalletDebitId,
                    Amount = walletDebit.Amount,
                    WalletId = walletDebit.WalletId
                };

                await eventDispatcher.Dispatch(walletVoidPaymentEvent);
            }
            return responseModel;
        }

        private async Task<ResponseModel<WalletDebitModel>> Process(int userId,
                                                                    decimal amount,
                                                                    string transactionDesc,
                                                                    EventBus.DomainEvents.Enums.DebitType debitType,
                                                                    string authNumber,
                                                                    int? toUserId,
                                                                    int? linkMemberTransferId,
                                                                    int? storeId,
                                                                    string storeName,
                                                                    long? transactionId,
                                                                    DebitState debitState,
                                                                    int debitedBy,string notificationTypeIdentifier)
        {
            _logger.TraceEnterMethod(nameof(Process), userId, amount, transactionDesc, debitType, toUserId, linkMemberTransferId);

            ResponseModel<WalletDebitModel> responseModel = new()
            {
                Success = false,
                Data = new WalletDebitModel
                {
                    TransferStatus = EventBus.DomainEvents.Enums.TransferStatus.Error,
                }
            };

            ResponseModel<Wallet> lockUserWalletResponseModel = await mediator.Send(new LockUserWalletCommand { UserId = userId });
            responseModel.Message = lockUserWalletResponseModel.Message;
            responseModel.Data.TransferStatus = EventBus.DomainEvents.Enums.TransferStatus.Error;
            decimal totalAmountAvailable = 0;

            if (lockUserWalletResponseModel.Success)
            {
                try
                {
                    List<WalletCredit> activeCredits = (await mediator.Send(new GetActiveWalletCreditsQuery { UserId = userId })).ToList();

                    totalAmountAvailable = activeCredits.Sum(t => t.CurrentAmount);

                    if (totalAmountAvailable < amount)
                    {
                        responseModel.Data.TransferStatus = EventBus.DomainEvents.Enums.TransferStatus.InsufficientBalance;
                        responseModel.Data.DebitAmount = 0;
                        responseModel.Data.BalanceAmount = totalAmountAvailable;
                        responseModel.Message = "Insufficient Wallet Amount";
                        return responseModel;
                    }

                    WalletDebit walletDebit = new()
                    {
                        Amount = amount,
                        WalletBalanceAmount=totalAmountAvailable,
                        AuthNumber = authNumber,
                        DebitDate = DateTime.UtcNow,
                        DebitTypeId = (int)debitType,
                        IsRefunded = false,
                        TransactionDesc = transactionDesc,
                        TransactionId = transactionId,
                        TransactionLockId = lockUserWalletResponseModel.Data.TransactionLockId,
                        WalletId = lockUserWalletResponseModel.Data.WalletId,
                        LinkMemberTransferId = linkMemberTransferId,
                        IsActive = true,
                        StoreId = storeId,
                        StoreName = storeName,
                        RefundDate = null,
                        DebitStateId = (int)debitState,
                        CreatedBy = debitedBy,
                        NotificationTypeIdentifier=notificationTypeIdentifier,
                    };

                    walletDebit.WalletDebitId = await context.WalletDebits.Add(walletDebit);

                    await ProcessDebit(activeCredits, amount, walletDebit, linkMemberTransferId, toUserId);

                    responseModel.Success = true;
                    responseModel.Data.TransferStatus = EventBus.DomainEvents.Enums.TransferStatus.Transfered;
                    responseModel.Data.DebitAmount = amount;
                    responseModel.Data.BalanceAmount = totalAmountAvailable - amount;
                    responseModel.Data.AuthNumber = authNumber;
                    responseModel.Data.WalletDebitId = walletDebit.WalletDebitId;
                    responseModel.Message = "";

                    _logger.TraceExitMethod(nameof(Process), responseModel);
                }
                finally
                {
                    await mediator.Send(new UnLockUserWalletCommand { UserId = userId });
                }
            }

            return responseModel;
        }

        private async Task<bool> ProcessDebit(List<WalletCredit> activeCredits,
                                                decimal totalAmountDebit,
                                                WalletDebit walletDebit,
                                                int? linkMemberTransferId,
                                                int? toUserId)
        {
            List<WalletCredit> newCredits = new();
            List<WalletCredit> deductCredits = new();
            List<WalletDebitDetail> newWalletDebitDetails = new();

            foreach (WalletCredit activeCredit in activeCredits)
            {
                decimal creditAmount = 0;

                if (activeCredit.CurrentAmount >= totalAmountDebit)
                {
                    creditAmount = totalAmountDebit;
                    activeCredit.CurrentAmount -= totalAmountDebit;
                    totalAmountDebit = 0;
                }
                else
                {
                    creditAmount = activeCredit.CurrentAmount;
                    totalAmountDebit -= activeCredit.CurrentAmount;
                    activeCredit.CurrentAmount = 0;
                }

                deductCredits.Add(activeCredit);

                if (walletDebit.DebitTypeId == (int)EventBus.DomainEvents.Enums.DebitType.LinkUserTransfer)
                {
                    Wallet wallet = await GetOrCreateUserWallet(toUserId.Value);

                    WalletCredit newCredit = new()
                    {
                        WalletId = wallet.WalletId,
                        CreditAmount = 0, //creditAmount,
                        CurrentAmount = 0, //creditAmount,
                        TransactionAmount = null,
                        StoreId = null,
                        StoreName = null,
                        TransactionTypeId = null,
                        TransactionId = null,
                        TransactionDesc = Constants.TransactionDesc.LinkUserTransfer,
                        LinkMemberTransferId = linkMemberTransferId,
                        FromWalletCreditId = activeCredit.WalletCreditId,
                        LastNotificationSentDate = DateTime.UtcNow,
                        CreditTypeId = (int)EventBus.DomainEvents.Enums.CreditType.LinkUserTransfer,
                        CreditDate = DateTime.UtcNow,
                        ExpireDate = activeCredit.ExpireDate,
                        PaymentMethodId = null,
                        UserPaymentMethodId = null,
                        IsActive = true,
                        CreditIdentifier = null,
                        CreatedOn = DateTime.UtcNow,
                        NotificationTypeIdentifier=NotificationTypeIdentifierConstants.WalletLinkUserTransferCreditEvent,
                    };

                    newCredits.Add(newCredit);
                }

                newWalletDebitDetails.Add(new WalletDebitDetail
                {
                    WalletDebitId = walletDebit.WalletDebitId,
                    FromWalletCreditId = activeCredit.WalletCreditId,
                    Amount = creditAmount,
                });

                if (totalAmountDebit == 0)
                {
                    break;
                }
            }

            foreach (WalletCredit deductCredit in deductCredits)
            {
                await context.WalletCredits.Update(deductCredit);
            }

            foreach (WalletDebitDetail newWalletDebitDetail in newWalletDebitDetails)
            {
                await context.WalletDebitDetails.Add(newWalletDebitDetail);
            }

            foreach (WalletCredit newCredit in newCredits)
            {
                newCredit.WalletCreditId = await context.WalletCredits.Add(newCredit);
            }

            return true;
        }

        private async Task<Wallet> GetOrCreateUserWallet(int userId)
        {
            Wallet userWallet = await context.Wallets.GetByUserId(userId);

            if (userWallet == null)
            {
                userWallet = new Wallet
                {
                    UserId = userId,
                    IsActive = true,
                };

                userWallet.WalletId = await context.Wallets.Add(userWallet);
            }

            return userWallet;
        }
    }
}
