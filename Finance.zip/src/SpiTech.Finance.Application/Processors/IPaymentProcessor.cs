﻿using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Finance.Domain.Entities;
using SpiTech.Finance.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Finance.Application.Processors
{
    public interface IPaymentProcessor
    {
        Task<ResponseModel<List<WalletCreditModel>>> Credit(int userId, int creditedBy, params WalletCreditModel[] walletCredits);

        Task<ResponseModel<WalletDebitModel>> Transfer(int userId,
                                                decimal amount,
                                                int toUserId,
                                                int? linkMemberTransferId,string notificationTypeIdentifier);

        Task<ResponseModel<WalletPreauthDebitModel>> PreAuthWallet(int userId,
                                                                    decimal amount,
                                                                    string transactionDesc,
                                                                    EventBus.DomainEvents.Enums.DebitType debitType,
                                                                    int storeId,
                                                                    string storeName, string notificationTypeIdentifier);
        Task<ResponseModel<WalletDebitModel>> FinalPayment(int userId,
                                                        decimal amount,
                                                        string transactionDesc,
                                                        EventBus.DomainEvents.Enums.DebitType debitType,
                                                        string authNumber,
                                                        int? storeId,
                                                        string storeName,
                                                        long transactionId,string notificationTypeIdentifier);

        Task<ResponseModel<WalletDebit>> Void(string authNumber, bool notifyUser);
        Task<ResponseModel<WalletDebitModel>> AdminDebit(int userId, decimal amount, string debitReason, int debitedBy,string notificationTypeIdentifier);
    }
}
