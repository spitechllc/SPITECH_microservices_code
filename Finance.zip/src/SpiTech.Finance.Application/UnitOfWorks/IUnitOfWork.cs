﻿using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Finance.Application.Repositories;

namespace SpiTech.Finance.Application.UnitOfWorks
{
    public interface IUnitOfWork : IBaseUnitOfWork
    {
        ILinkMemberTransferRepository LinkMemberTransfers { get; }
        IDebitTypeRepository DebitTypes { get; }
        ICreditTypeRepository CreditTypes { get; }
        IWalletCreditRepository WalletCredits { get; }
        IWalletDebitDetailRepository WalletDebitDetails { get; }
        IWalletDebitRepository WalletDebits { get; }
        IWalletRepository Wallets { get; }
        IConfigRepository Configs { get; }
        ITransferStatusRepository TransferStatuses { get; }
    }
}
