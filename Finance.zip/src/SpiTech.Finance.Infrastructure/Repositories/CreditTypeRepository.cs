﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Finance.Application.Repositories;

namespace SpiTech.Finance.Infrastructure.Repositories
{
    public class CreditTypeRepository : Repository<Domain.Entities.CreditType>, ICreditTypeRepository
    {
        public CreditTypeRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
    }
}
