﻿using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Finance.Application.Repositories;
using SpiTech.Finance.Domain.Entities;
using SpiTech.Finance.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.Finance.Infrastructure.Repositories
{
    public class LinkMemberTransferRepository : Repository<Domain.Entities.LinkMemberTransfer>, ILinkMemberTransferRepository
    {
        public LinkMemberTransferRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<IEnumerable<LinkMemberTransfer>> GetLinkMemberTransfers(int fromUserId, int toUserId)
        {
            string query = @$"select * from [LinkMemberTransfer] where FromUserId =@fromUserId and ToUserId=@toUserId";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("fromUserId", fromUserId);
            dynamicParams.Add("toUserId", toUserId);

            query += " order by LinkMemberTransferId desc";

            return (await DbConnection.QueryAsync<LinkMemberTransfer>(query, dynamicParams, DbTransaction)).ToList();
        }
        public async Task<IEnumerable<LinkMemberTransferModel>> GetRequestedAmountList(int userId)
        {
            string query = @$"select LM.*,Name as TransferStatusName from [LinkMemberTransfer] LM inner join [TransferStatus] TS on LM.TransferStatusId=TS.TransferStatusId  where ToUserId =@UserId ";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("UserId", userId);

            query += " order by LM.LinkMemberTransferId desc";

            return (await DbConnection.QueryAsync<LinkMemberTransferModel>(query, dynamicParams, DbTransaction)).ToList();
        }
        public async Task<IEnumerable<LinkMemberTransferModel>> GetPendingAmountTransferRequests(int userId)
        {
            string query = @$"select * from [LinkMemberTransfer] where FromUserId =@UserId and TransferStatusId=1";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("UserId", userId);
            query += " order by LinkMemberTransferId desc";

            return (await DbConnection.QueryAsync<LinkMemberTransferModel>(query, dynamicParams, DbTransaction)).ToList();
        }
    }
}
