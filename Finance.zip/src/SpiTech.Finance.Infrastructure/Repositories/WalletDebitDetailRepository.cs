﻿using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Finance.Application.Repositories;
using SpiTech.Finance.Domain.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.Finance.Infrastructure.Repositories
{
    public class WalletDebitDetailRepository : Repository<Domain.Entities.WalletDebitDetail>, IWalletDebitDetailRepository
    {
        public WalletDebitDetailRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<IEnumerable<WalletDebitDetail>> GetByWalletDebitId(long walletDebitId)
        {
            string query = @$"select * from [WalletDebitDetail] where WalletDebitId =@walletDebitId ";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("walletDebitId", walletDebitId);

            query += " order by WalletDebitDetailId desc";

            return (await DbConnection.QueryAsync<WalletDebitDetail>(query, dynamicParams, DbTransaction)).ToList();
        }
    }
}
