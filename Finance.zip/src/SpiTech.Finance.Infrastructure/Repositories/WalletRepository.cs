﻿using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Finance.Application.Repositories;
using SpiTech.Finance.Domain.Entities;
using SpiTech.Finance.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.Finance.Infrastructure.Repositories
{
    public class WalletRepository : Repository<Domain.Entities.Wallet>, IWalletRepository
    {
        public WalletRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<Wallet> GetByUserId(int userId)
        {
            string query = @$"select * from [Wallet] where UserId =@userId ";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("userId", userId);

            return await DbConnection.QueryFirstOrDefaultAsync<Wallet>(query, dynamicParams, DbTransaction);
        }
        public async Task<List<UserWalletModel>> GetByUserIds(params int[] userIds)
        {
            string query = @$"select *,(select convert(decimal(9,2),isnull(sum(currentamount),0)) from walletcredit where walletid=w.walletid and expiredate>=getdate() and currentamount>0) TotalAvailableAmount from wallet w where UserId in @userIds";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("userIds", userIds);

            return (await DbConnection.QueryAsync<UserWalletModel>(query, dynamicParams, DbTransaction)).ToList();
        }
    }
}
