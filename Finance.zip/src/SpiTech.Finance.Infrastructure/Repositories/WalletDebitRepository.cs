﻿using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Finance.Application.Repositories;
using SpiTech.Finance.Domain.Entities;
using SpiTech.Finance.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Finance.Infrastructure.Repositories
{
    public class WalletDebitRepository : Repository<Domain.Entities.WalletDebit>, IWalletDebitRepository
    {
        public WalletDebitRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<List<WalletDebit>> GetAdminDebit(int? userId, DateTime? fromDate, DateTime? toDate)
        {
            StringBuilder query = new();
            query.Append($"select wc.* from [WalletDebit] wc Inner Join [Wallet] w on wc.WalletId=w.WalletId where wc.DebitTypeId={(int)SpiTech.EventBus.DomainEvents.Enums.DebitType.AdminDebit}");

            DynamicParameters dynamicParams = new();

            if (userId != null && userId > 0)
            {
                query.Append(" and w.UserId = @userid ");
                dynamicParams.Add("userId", userId);
            }

            if (fromDate != null)
            {
                query.Append(" and wc.DebitDate>=@fromDate");
                dynamicParams.Add("fromDate", fromDate);
            }

            if (toDate != null)
            {
                query.Append(" and wc.DebitDate<=@toDate");
                dynamicParams.Add("toDate", toDate);
            }

            query.Append(" order by wc.WalletDebitId desc");

            return (await DbConnection.QueryAsync<WalletDebit>(query.ToString(), dynamicParams, DbTransaction)).ToList();
        }

        public async Task<WalletDebit> GetByAuthNumber(string authNumber)
        {
            string query = @$"select * from [WalletDebit] where AuthNumber = @authNumber and DebitStateId != 2 ";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("authNumber", authNumber);

            return await DbConnection.QueryFirstAsync<WalletDebit>(query, dynamicParams, DbTransaction);
        }

        public async Task<List<CashRewardModel>> GetByStoreIds(int[] storeIds, DateTime? fromDate, DateTime? toDate)
        {
            string query = @$"select sum(amount) TotalRedeemed, StoreId from walletdebit where  IsRefunded = 0 and DebitStateId = 2 and DebitTypeId != 3 ";

            DynamicParameters dynamicParams = new();

            if (storeIds != null && storeIds.Count() > 0)
            {
                dynamicParams.Add("storeId", storeIds);
                query += " and storeid in @storeId";
            }

            if (fromDate != null && toDate != null)
            {
                dynamicParams.Add("startDate", fromDate);
                dynamicParams.Add("endDate", toDate);

                query += "  and [DebitDate] >= @startDate and [DebitDate] <= @endDate";
            }

            query += " group by StoreId";

            query+= " order by StoreId desc";

            return (await DbConnection.QueryAsync<CashRewardModel>(query, dynamicParams, DbTransaction)).ToList();
        }

        public async Task<List<WalletDebit>> GetDebitByTransactionId(long[] transactionIds)
        {

            string query = @$"select sum(amount) Amount,TransactionId,WalletBalanceAmount,DebitDate from walletdebit where  IsRefunded = 0 and DebitStateId = 2 and DebitTypeId != 3  ";

            DynamicParameters dynamicParams = new();

            if (transactionIds != null && transactionIds.Count() > 0)
            {
                dynamicParams.Add("TransactionId", transactionIds);
                query += " and TransactionId in @TransactionId";

            }

            query += " group by TransactionId,WalletBalanceAmount,DebitDate";

            query+= " order by TransactionId desc";

            return (await DbConnection.QueryAsync<WalletDebit>(query, dynamicParams, DbTransaction)).ToList();
        }
    }
}
