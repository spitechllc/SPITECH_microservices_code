﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Finance.Application.Repositories;
using SpiTech.Finance.Domain.Entities;

namespace SpiTech.Finance.Infrastructure.Repositories
{
    public class TransferStatusRepository : Repository<TransferStatus>, ITransferStatusRepository
    {
        public TransferStatusRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
    }
}
