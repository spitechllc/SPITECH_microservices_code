﻿using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Finance.Application.Repositories;
using SpiTech.Finance.Domain.Entities;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.Finance.Infrastructure.Repositories
{
    public class ConfigRepository : Repository<Domain.Entities.Config>, IConfigRepository
    {
        public ConfigRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<Config> GetIsNotificationSent()
        {
            string query = @$"select * from BackgroundServiceConfig where convert(datetime,convert(varchar,LastExecutionTime,103),103) =convert(datetime,convert(varchar,getutcdate(),103),103) ";

            return (await DbConnection.QueryAsync<Config>(query, null, DbTransaction)).FirstOrDefault();
        }
    }
}
