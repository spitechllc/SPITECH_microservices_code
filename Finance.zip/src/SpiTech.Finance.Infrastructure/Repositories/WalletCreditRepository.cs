﻿using Dapper;
using SpiTech.ApplicationCore.Database;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Finance.Application.Repositories;
using SpiTech.Finance.Domain.Entities;
using SpiTech.Finance.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Finance.Infrastructure.Repositories
{
    public class WalletCreditRepository : Repository<Domain.Entities.WalletCredit>, IWalletCreditRepository
    {
        public WalletCreditRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<IEnumerable<WalletCredit>> GetAllByUserId(int userId)
        {
            string query = @$"select wc.* from [WalletCredit] wc Inner Join [Wallet] w on wc.WalletId=w.WalletId where w.UserId =@userId ";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("userId", userId);
            query += " order by wc.walletcreditid desc";

            return (await DbConnection.QueryAsync<WalletCredit>(query, dynamicParams, DbTransaction)).ToList();
        }
        public async Task<List<WalletCredit>> GetAdminCredit(int? userId, DateTime? fromDate, DateTime? toDate)
        {
            StringBuilder query = new();

            query.Append($"select wc.* from [WalletCredit] wc Inner Join [Wallet] w on wc.WalletId=w.WalletId where wc.CreditTypeId={(int)EventBus.DomainEvents.Enums.CreditType.AdminCredit}  ");

            DynamicParameters dynamicParams = new();
            if (userId != null && userId > 0)
            {
                query.Append(" and w.UserId =@userid ");
                dynamicParams.Add("userId", userId);
            }
            if (fromDate != null)
            {
                query.Append(" and wc.CreditDate>=@fromDate");
                dynamicParams.Add("fromDate", fromDate);
            }
            if (toDate != null)
            {
                query.Append(" and wc.CreditDate<=@toDate");
                dynamicParams.Add("toDate", toDate);
            }

            query.Append(" order by wc.walletcreditid desc");

            return (await DbConnection.QueryAsync<WalletCredit>(query.ToString(), dynamicParams, DbTransaction)).ToList();
        }

        public async Task<IEnumerable<WalletCredit>> GetAllByWalletCreditIds(long[] walletCreditIds)
        {
            string query = @$"select * from [WalletCredit] where WalletCreditId in @walletCreditIds ";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("walletCreditIds", walletCreditIds);

            query += " order by walletcreditid desc";

            return (await DbConnection.QueryAsync<WalletCredit>(query, dynamicParams, DbTransaction)).ToList();
        }
        public async Task<IEnumerable<WalletCreditExpiringResult>> GetAllExpiringWalletCredit(int days)
        {

            string query = @$"select top 1000 convert(decimal(9,2),wc.CreditAmount) CreditAmount,convert(varchar,CreditDate,103) CreditDate, convert(varchar,ExpireDate,103) ExpireDate,UserId from [WalletCredit] wc Inner Join [Wallet] w on wc.WalletId=w.WalletId where  ExpireDate between getutcdate() and dateadd(dd,{days},getutcdate()) and currentAmount>0 and LastNotificationSentDate is null ";

            return (await DbConnection.QueryAsync<WalletCreditExpiringResult>(query, null, DbTransaction)).ToList();
        }

        public async Task<IEnumerable<WalletCredit>> GetAllExpiringWalletCredit(int days, int userId)
        {
            string query = @$"select wc.* from [WalletCredit] wc Inner Join [Wallet] w on wc.WalletId=w.WalletId where  ExpireDate between getutcdate() and dateadd(dd,{days},getutcdate()) and currentAmount>0 and w.[UserId] =@userId order by expiredate";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("userId", userId);

            return (await DbConnection.QueryAsync<WalletCredit>(query, dynamicParams, DbTransaction)).ToList();
        }

        public async Task<IEnumerable<WalletCredit>> GetAllExpiredWalletCredit(int userId)
        {
            string query = @$"select wc.* from [WalletCredit] wc Inner Join [Wallet] w on wc.WalletId=w.WalletId where  ExpireDate <= Convert(DateTime, DATEDIFF(DAY, 0, GETUTCDATE())) and currentAmount>0 and w.[UserId] =@userId";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("userId", userId);

            return (await DbConnection.QueryAsync<WalletCredit>(query, dynamicParams, DbTransaction)).ToList();
        }

        public async Task<IEnumerable<WalletCreditSearchModel>> GetWalletCreditByTransactionId(long transactionId)
        {
            string query = @$"select CreditAmount as Amount,TransactionAmount,StoreId,StoreName,TransactionId,TransactionDesc,UserPaymentMethodId,PaymentMethodId,CreditDate as Date,ExpireDate,CT.Name,UserId,1 as IsCredit from [WalletCredit] WC inner join CreditType CT on WC.CreditTypeId=CT.CreditTypeId inner join wallet W on wc.walletid=W.walletid  where  WC.CreditTypeID in(1,2) and TransactionId=@transactionId ";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("transactionId", transactionId);

            query += " order by TransactionId desc";

            return (await DbConnection.QueryAsync<WalletCreditSearchModel>(query, dynamicParams, DbTransaction)).ToList();
        }

        public async Task<List<WalletCreditSearchModel>> GetWalletCreditByTransactionIds(long[] transactionIds)
        {
            string query = @$"select CreditAmount as Amount,TransactionAmount,StoreId,StoreName,TransactionId,TransactionDesc,UserPaymentMethodId,PaymentMethodId,CreditDate as Date,ExpireDate,CT.Name,UserId,1 as IsCredit from [WalletCredit] WC inner join CreditType CT on WC.CreditTypeId=CT.CreditTypeId inner join wallet W on wc.walletid=W.walletid where TransactionId in @transactionIds";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("transactionIds", transactionIds);

            query += " order by TransactionId desc";

            return (await DbConnection.QueryAsync<WalletCreditSearchModel>(query, dynamicParams, DbTransaction)).ToList();
        }

        public async Task<List<WalletHistoryModel>> GetWalletHistory(int userId, int? pageIndex, int? pageSize)
        {

            string query = $@"select *, Count(1) over() as TotalRecord from (
                            select TransactionId,CreditAmount as Amount,CreditDate as Date,ExpireDate,StoreId,StoreName,TransactionDesc,
                            CT.Name TypeName,CT.CreditTypeId TypeId,0 UserId,1 as IsCredit, WC.CreditIdentifier, 
                            WC.TransactionTypeId,  WC.IsRefunded,  WC.RefundDate,WC.TransactionCount,WC.NotificationTypeIdentifier 
                            from [WalletCredit] WC inner join CreditType CT on WC.CreditTypeId=CT.CreditTypeId 
                            inner join wallet W on W.WalletId=Wc.WalletId
                            where W.UserId=@userId and WC.IsRefunded=0 and wc.LinkMemberTransferId is null
                            
                            union 
                            
                            select null TransactionId,sum(CreditAmount) as Amount,MAX(CreditDate) as Date,MAX(ExpireDate) ExpireDate,
                            null StoreId, null StoreName, max(TransactionDesc) TransactionDesc,MAX(CT.Name) TypeName,MAX(CT.CreditTypeId) TypeId,
                            MAX(LT.FromUserId) as UserId,1 as IsCredit, null CreditIdentifier, null TransactionTypeId, 0 IsRefunded,  
                            null RefundDate,null TransactionCount,MAX(WC.NotificationTypeIdentifier) NotificationTypeIdentifier
                            from [WalletCredit] WC inner join CreditType CT on WC.CreditTypeId=CT.CreditTypeId 
                            inner join wallet W on W.WalletId=Wc.WalletId 
                            inner join [dbo].[LinkMemberTransfer] LT on WC.LinkMemberTransferId=LT.LinkMemberTransferId 
                            where W.UserId=@userId and WC.IsRefunded=0 and wc.LinkMemberTransferId>0
                            group by WC.LinkMemberTransferId

                            union 

                            select TransactionId,Amount ,DebitDate as Date,null as ExpireDate,StoreId,StoreName,TransactionDesc,
                            DT.Name TypeName, DT.DebitTypeId TypeId,0 UserId,0 as IsCredit ,null CreditIdentifier, 
                            null TransactionTypeId,  WD.IsRefunded,  WD.RefundDate,0 as TransactionCount,WD.NotificationTypeIdentifier 
                            from [WalletDebit] WD inner join DebitType DT on WD.DebitTypeId=DT.DebitTypeId 
                            inner join wallet W on W.WalletId=WD.WalletId 
                            where  W.UserId=@userId and WD.IsRefunded=0 and WD.LinkMemberTransferId is null
                            
                            union 

                            select null TransactionId,sum(Amount) Amount,MAX(DebitDate) as Date,null as ExpireDate,null StoreId,
                            null StoreName, null TransactionDesc, MAX(DT.Name) TypeName, MAX(DT.DebitTypeId) TypeId,MAX(LT.ToUserId) as UserId,
                            0 as IsCredit ,null CreditIdentifier, null TransactionTypeId,0 IsRefunded, null RefundDate, 0 as TransactionCount,
                            MAX(WD.NotificationTypeIdentifier) NotificationTypeIdentifier
                            from [WalletDebit] WD inner join DebitType DT on WD.DebitTypeId=DT.DebitTypeId 
                            inner join wallet W on W.WalletId=WD.WalletId  
                            inner join [dbo].[LinkMemberTransfer] LT on WD.LinkMemberTransferId=LT.LinkMemberTransferId 
                            where  W.UserId=@userId and WD.IsRefunded=0 and wd.LinkMemberTransferId>0
                            group by wd.LinkMemberTransferId
                            )t order by [Date] desc";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("userId", userId);

            if (pageIndex.HasValue && pageSize.HasValue)
            {
                int skiprow = (pageIndex.Value - 1) * pageSize.Value;

                query += $" OFFSET {skiprow} rows fetch next {pageSize.Value} rows only";

            }

            return (await DbConnection.QueryAsync<WalletHistoryModel>(query, dynamicParams, DbTransaction)).ToList();
        }

        public async Task<WalletCredit> GetAllByStoreId(int? storeId, int? month, int? year, DateTime? creditDate)
        {
            string query = @$"select Convert(decimal(9,2),sum(creditamount))CreditAmount,Convert(decimal(9,2),sum(creditamount)-sum(currentamount))TransactionAmount,StoreId from walletcredit where  1=1";

            DynamicParameters dynamicParams = new();

            if (storeId > 0)
            {
                dynamicParams.Add("storeId", storeId);
                query += " and storeid=@storeId";
            }

            if (month > 0 && year > 0)
            {
                int daysInMonth = DateTime.DaysInMonth((int)year, (int)month);
                DateTime startDate = new((int)year, (int)month, 1);
                DateTime endDate = new((int)year, (int)month, daysInMonth, 23, 59, 59);
                dynamicParams.Add("startDate", startDate.ToUniversalTime());
                dynamicParams.Add("endDate", endDate.ToUniversalTime());

                query += "  and [CreditDate] >= @startDate and [CreditDate] <= @endDate";
            }

            if (creditDate != null)
            {
                dynamicParams.Add("creditdate", creditDate);
                query += " and CreditDate=@creditdate";
            }

            query += " group by StoreId";

            return (await DbConnection.QueryAsync<WalletCredit>(query, dynamicParams, DbTransaction)).FirstOrDefault();
        }

        public async Task<IEnumerable<WalletTransferCreditModel>> GetTransferAmountByUserId(int? fromUserId, int? toUserId)
        {
            string query = @$"select * from walletcredit wc inner join [LinkMemberTransfer] LM on wc.LinkMemberTransferID=LM.LinkMemberTransferID where wc.IsActive=1 ";

            DynamicParameters dynamicParams = new();
            if (fromUserId > 0)
            {
                query += " and FromUserId =@fromUserId";
                dynamicParams.Add("fromUserId", fromUserId);
            }
            if (toUserId > 0)
            {
                query += " and ToUserId = @toUserId";
                dynamicParams.Add("toUserId", toUserId);
            }

            query += " order by LM.LinkMemberTransferID desc";

            return (await DbConnection.QueryAsync<WalletTransferCreditModel>(query, dynamicParams, DbTransaction)).ToList();
        }

        public async Task<WalletCredit> CheckDuplicateCredit(int transactionId, int creditTypeId, int userid)
        {
            string query = @$"select wc.* from walletcredit WC inner join wallet W on W.WalletId=Wc.WalletId where TransactionId=@transactionId and CreditTypeId=@creditTypeId and  userid=@userid";

            DynamicParameters dynamicParams = new();


            dynamicParams.Add("transactionId", transactionId);

            dynamicParams.Add("creditTypeId", creditTypeId);
            dynamicParams.Add("userid", userid);

            query += " order by WC.WalletCreditId desc";

            return (await DbConnection.QueryAsync<WalletCredit>(query, dynamicParams, DbTransaction)).FirstOrDefault();
        }

        public async Task<List<CashRewardModel>> GetByStoreIds(int[] storeIds, DateTime? fromDate, DateTime? toDate)
        {
            string query = @$"select sum(creditamount) TotalEarned, StoreId from walletcredit where  CreditTypeId != 3 and IsRefunded = 0 ";

            DynamicParameters dynamicParams = new();

            if (storeIds != null && storeIds.Count() > 0)
            {
                dynamicParams.Add("storeId", storeIds);
                query += " and storeid in @storeId";

            }

            if (fromDate != null && toDate != null)
            {
                dynamicParams.Add("startDate", fromDate);
                dynamicParams.Add("endDate", toDate);

                query += "  and [CreditDate] >= @startDate and [CreditDate] <= @endDate";
            }

            query += " group by StoreId";

            return (await DbConnection.QueryAsync<CashRewardModel>(query, dynamicParams, DbTransaction)).ToList();
        }

        public async Task<List<WalletCreditSearchModel>> GetAllByTransactionIds(long[] TransactionIds)
        {
            string query = @$"select Convert(decimal(9,2),sum(wc.creditamount))CreditAmount,Convert(decimal(9,2),sum(wc.creditamount)-sum(wc.currentamount))TransactionAmount,wc.TransactionId,(select sum(currentamount) from walletcredit where walletcreditid<=(select max(walletcreditid) from walletcredit where transactionid=wc.transactionid) and walletid=wc.walletid)BalanceAmount,CreditDate as Date from walletcredit wc where  CreditTypeId != 3 and IsRefunded = 0 ";

            DynamicParameters dynamicParams = new();

            if (TransactionIds != null && TransactionIds.Count() > 0)
            {
                dynamicParams.Add("TransactionId", TransactionIds);
                query += " and TransactionId in @TransactionId";

            }

            query += " group by TransactionId,walletid,CreditDate";

            return (await DbConnection.QueryAsync<WalletCreditSearchModel>(query, dynamicParams, DbTransaction)).ToList();
        }

        public async Task Update(int storeId, string siteId, string storeName)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("StoreId", storeId);
            dynamicParams.Add("SiteId", siteId);
            dynamicParams.Add("StoreName", storeName);

            await DbConnection.ExecuteAsync($"UpdateSite", dynamicParams, DbTransaction, commandType: System.Data.CommandType.StoredProcedure);
        }
        public async Task<RewardDetailsDashboardModel> GetRewardDetailsForDashboard(DateTime? startDate, DateTime? endDate, int[] storeIds, int? userId, int? month, int? year)
        {
            string query = @$"select sum(CreditAmount)TotalEarned,(select sum(amount) from walletdebit where TransactionId is not null and IsRefunded = 0 and DebitStateId = 2 and DebitTypeId not in(3,4) and debitdate>=@start and debitdate<=@end and storeid not in (4,5) and (StoreId in (select KeyValue from @StoreIds)) and (@UserId is null or walletId=(select walletId from Wallet where UserId=@UserId)))TotalRedeemed,count(transactionid)TotalTransactions,count(distinct walletid)TotalConsumers,
(select sum(creditamount) from WalletCredit where CreditTypeId not in(3,4) and month(CreditDate)=month(@end) and year(CreditDate)=year(@end) and storeid not in (4,5) and (StoreId in (select KeyValue from @StoreIds)) and (@UserId is null or walletId=(select walletId from Wallet where UserId=@UserId)))MonthlyTotalEarned,
(select sum(amount) from walletdebit where TransactionId is not null and IsRefunded = 0 and DebitStateId = 2 and DebitTypeId not in(3,4) and month(DebitDate)=month(@end) and year(DebitDate)=year(@end) and storeid not in (4,5) and (StoreId in (select KeyValue from @StoreIds)) and (@UserId is null or walletId=(select walletId from Wallet where UserId=@UserId)))MonthlyTotalRedeemed,
(select count(transactionid) from WalletCredit where CreditTypeId not in(3,4) and month(CreditDate)=month(@end) and year(CreditDate)=year(@end) and storeid not in (4,5) and (StoreId in (select KeyValue from @StoreIds)) and (@UserId is null or walletId=(select walletId from Wallet where UserId=@UserId)))MonthlyTotalTransactions,
(select count(distinct walletid) from WalletCredit where CreditTypeId not in(3,4) and month(CreditDate)=month(@end) and year(CreditDate)=year(@end) and storeid not in (4,5) and (StoreId in (select KeyValue from @StoreIds)) and (@UserId is null or walletId=(select walletId from Wallet where UserId=@UserId)))MonthlyTotalConsumers,
(select sum(creditamount) from WalletCredit where CreditTypeId not in(3,4) and year(CreditDate)=year(@end) and storeid not in (4,5) and (StoreId in (select KeyValue from @StoreIds)) and (@UserId is null or walletId=(select walletId from Wallet where UserId=@UserId)))YearlyTotalEarned,
(select sum(amount) from walletdebit where TransactionId is not null and IsRefunded = 0 and DebitStateId = 2 and DebitTypeId not in(3,4) and year(debitdate)=year(@end) and storeid not in (4,5) and (StoreId in (select KeyValue from @StoreIds)) and (@UserId is null or walletId=(select walletId from Wallet where UserId=@UserId)))YearlyTotalRedeemed,
(select count(transactionid) from WalletCredit where CreditTypeId not in(3,4) and year(CreditDate)=year(@end) and storeid not in (4,5) and (StoreId in (select KeyValue from @StoreIds)) and (@UserId is null or walletId=(select walletId from Wallet where UserId=@UserId)))YearlyTotalTransactions,
(select count(distinct walletid) from WalletCredit where CreditTypeId not in(3,4) and year(CreditDate)=year(@end) and storeid not in (4,5) and (StoreId in (select KeyValue from @StoreIds)) and (@UserId is null or walletId=(select walletId from Wallet where UserId=@UserId)))YearlyTotalConsumers,
(select sum(creditamount) from WalletCredit where CreditTypeId not in(3,4) and month(CreditDate)=month(@end) and year(CreditDate)=year(@end) and storeid not in (4,5) and (StoreId in (select KeyValue from @StoreIds)) and (@UserId is null or walletId=(select walletId from Wallet where UserId=@UserId)))Liability,
(select sum(creditamount) from WalletCredit where CreditTypeId not in(3,4) and ExpireDate<=@end and storeid not in (4,5) and (StoreId in (select KeyValue from @StoreIds)) and (@UserId is null or walletId=(select walletId from Wallet where UserId=@UserId)))ExpiredCredit,
(select sum(creditamount) from WalletCredit where CreditTypeId not in(3,4) and month(CreditDate)=month(@preDate) and year(CreditDate)=year(@preDate) and storeid not in (4,5) and (StoreId in (select KeyValue from @StoreIds)) and (@UserId is null or walletId=(select walletId from Wallet where UserId=@UserId)))TotalEarnedPreviousMonth,
(select sum(creditamount) from WalletCredit where CreditTypeId not in(3,4) and TransactionTypeId = 1 and month(CreditDate)=month(@end) and year(CreditDate)=year(@end) and storeid not in (4,5) and (StoreId in (select KeyValue from @StoreIds)) and (@UserId is null or walletId=(select walletId from Wallet where UserId=@UserId)))TotalEarnedFuel,
(select sum(creditamount) from WalletCredit where CreditTypeId not in(3,4) and TransactionTypeId = 3 and month(CreditDate)=month(@end) and year(CreditDate)=year(@end) and storeid not in (4,5) and (StoreId in (select KeyValue from @StoreIds)) and (@UserId is null or walletId=(select walletId from Wallet where UserId=@UserId)))TotalEarnedStoreItemPurchase
  from walletcredit where CreditTypeId not in(3,4) and CreditDate >=@start and CreditDate<=@end and storeid not in (4,5)";

            DynamicParameters dynamicParams = new();

            if (startDate.HasValue)
            {
                string datetime = startDate.ToString();          //converts the datetime value to string
                string[] stDate = datetime.Split(' ');
                dynamicParams.Add("start", DateTime.Parse(stDate[0]));
            }
            if (endDate.HasValue)
            {
                string datetime = endDate.ToString();          //converts the datetime value to string
                string[] edDate = datetime.Split(' ');
                dynamicParams.Add("end", DateTime.Parse(edDate[0]).AddHours(23).AddMinutes(59).AddSeconds(59).AddMilliseconds(59));
                dynamicParams.Add("preDate", endDate.Value.AddMonths(-1));
            }
            if (month.HasValue && month.Value > 0 && year.HasValue && year.Value > 0)
            {
                startDate = new(year.Value, month.Value, 1);
                endDate = new DateTime(year.Value, month.Value, DateTime.DaysInMonth(year.Value, month.Value));
                
                dynamicParams.Add("start", startDate);
                dynamicParams.Add("end", endDate.Value.AddHours(23).AddMinutes(59).AddSeconds(59).AddMilliseconds(59));
                dynamicParams.Add("preDate", endDate.Value.AddMonths(-1));
            }
            if (storeIds !=null && storeIds.Any())
            {
                dynamicParams.Add("StoreIds", storeIds.Cast<int>().ToArray().GetTableValuedParameter("[dbo].[UdtIntKeys]", "KeyValue"));
                query += " and (StoreId in (select KeyValue from @StoreIds))";
            }
            else
            {
                dynamicParams.Add("StoreIds", null);
            }
            if (userId.HasValue && userId.Value > 0)
            {
                dynamicParams.Add("UserId", userId);
                query += "  and walletId=(select walletId from Wallet where UserId=@UserId)";
            }
            else
            {
                dynamicParams.Add("UserId", null);
            }
            try
            {

            return (await DbConnection.QueryFirstOrDefaultAsync<RewardDetailsDashboardModel>(query, dynamicParams, DbTransaction));
            }
            catch(Exception ex)
            { throw; }
        }
        public async Task<List<StoreRewardDetails>> GetStoreWiseRewardDetailsForDashboard(DateTime? startDate, DateTime? endDate, int[] storeIds, int? userId, int? month, int? year)
        {           

            string query = @$"select StoreId,StoreName,sum(TransactionAmount)Amount,sum(CreditAmount)Earned,isnull((select sum(amount) from walletdebit where TransactionId is not null and IsRefunded=0 and DebitStateId = 2 and DebitTypeId not in(3,4) and StoreId=WalletCredit.StoreId and debitdate>=@start and debitdate<=@end and storeid not in (4,5) and (StoreId in (select KeyValue from @StoreIds)) and (@UserId is null or walletId=(select walletId from Wallet where UserId=@UserId))),0)Redeemed 
from walletcredit where CreditTypeId not in(3,4) and NotificationTypeIdentifier!='AddCardEvent' and CreditDate >=@start and CreditDate<=@end and storeid not in (4,5)";
            //
            DynamicParameters dynamicParams = new();

            if (startDate.HasValue)
            {
                string datetime = startDate.ToString();          //converts the datetime value to string
                string[] stDate = datetime.Split(' ');
                dynamicParams.Add("start", DateTime.Parse(stDate[0]));
            }
            if (endDate.HasValue)
            {
                string datetime = endDate.ToString();          //converts the datetime value to string
                string[] edDate = datetime.Split(' ');
                dynamicParams.Add("end", DateTime.Parse(edDate[0]).AddHours(23).AddMinutes(59).AddSeconds(59).AddMilliseconds(59));
            }
            if (month.HasValue && month.Value > 0 && year.HasValue && year.Value > 0)
            {
                startDate = new(year.Value, month.Value, 1);
                endDate = new DateTime(year.Value, month.Value, DateTime.DaysInMonth(year.Value, month.Value));

                dynamicParams.Add("start", startDate);
                dynamicParams.Add("end", endDate.Value.AddHours(23).AddMinutes(59).AddSeconds(59).AddMilliseconds(59));
            }
            if (storeIds !=null && storeIds.Any())
            {
                dynamicParams.Add("StoreIds", storeIds.Cast<int>().ToArray().GetTableValuedParameter("[dbo].[UdtIntKeys]", "KeyValue"));
                query += " and (StoreId in (select KeyValue from @StoreIds))";
            }

            else
            {
                dynamicParams.Add("StoreIds", null);
            }
            if (userId.HasValue && userId.Value > 0)
            {
                dynamicParams.Add("UserId", userId);
                query += "  and (walletId=(select walletId from Wallet where UserId=@UserId))";
            }

            else
            {
                dynamicParams.Add("UserId", null);
            }

            query += " group by StoreId,StoreName order by StoreId";
            return (await DbConnection.QueryAsync<StoreRewardDetails>(query, dynamicParams, DbTransaction)).ToList();
        }
        public async Task<List<MonthWiseRewardDetails>> GetMonthwiseRewardDetailsForDashboard(int Year, int[] storeIds, int? userId)
        {


            string query = @"select MonthId as Month,[MONTH] as MonthName,isnull(sum(creditamount),0)Earned,
isnull((select sum(amount) from walletdebit where TransactionId is not null and IsRefunded = 0 and DebitStateId = 2 and DebitTypeId not in(3,4) and month(DebitDate)=MonthId and year(DebitDate)=@Year and storeid not in (4,5) and (StoreId in (select KeyValue from @StoreIds)) and (@UserId is null or walletId=(select walletId from Wallet where UserId=@UserId))),0) Redeemed from (select MonthId,[MONTH] from [dbo].[fn_monthlist](@Year))t inner join walletcredit on month(creditdate)=t.monthid where CreditTypeId not in(3,4) and month(CreditDate)=MonthId and year(CreditDate)=@Year and storeid not in (4,5)";
            DynamicParameters dynamicParams = new();


            dynamicParams.Add("Year", Year);

            if (storeIds.Any())
            {
                 dynamicParams.Add("StoreIds", storeIds.Cast<int>().ToArray().GetTableValuedParameter("[dbo].[UdtIntKeys]", "KeyValue"));
                query += " and (StoreId in (select KeyValue from @StoreIds))";
            }
            else
            {
                dynamicParams.Add("StoreIds", null);
            }
            if (userId.HasValue && userId.Value > 0)
            {
                dynamicParams.Add("UserId", userId);
                query += "  and (@UserId is null or walletId=(select walletId from Wallet where UserId=@UserId))";
            }
            else
            {
                dynamicParams.Add("UserId", null);
            }

            query += " group by MonthId,[Month]";
            try
            {

                return (await DbConnection.QueryAsync<MonthWiseRewardDetails>(query, dynamicParams, DbTransaction)).ToList();
            }
            catch (Exception ex)
            { throw; }
        }
         public async Task<List<UserRewardDetailsModel>> GetUserWiseRewardDetailsForDashboard(DateTime? startDate, DateTime? endDate, int[] storeIds, int[] userIds, int? month, int? year)
        {                    

            string query = @$"select UserId,sum(TransactionAmount)Amount,sum(CreditAmount)Earned,isnull((select sum(amount) from walletdebit where IsRefunded=0 and DebitStateId = 2 and WalletId=WalletCredit.WalletId and debitdate>=@start and debitdate<=@end and storeid not in (4,5) and (StoreId in (select KeyValue from @StoreIds))),0)Redeemed,(isnull(sum(CreditAmount),0)-(isnull((select sum(amount) from walletdebit where IsRefunded=0 and WalletId=WalletCredit.WalletId and debitdate>=@start and debitdate<=@end and storeid not in (4,5) and (StoreId in (select KeyValue from @StoreIds))),0)))Balance from walletcredit inner join wallet on walletcredit.walletid=wallet.walletid where CreditDate >=@start and CreditDate<=@end and storeid not in (4,5)";
            
            DynamicParameters dynamicParams = new();

            if (startDate.HasValue)
            {
                string datetime = startDate.ToString();          //converts the datetime value to string
                string[] stDate = datetime.Split(' ');
                dynamicParams.Add("start", DateTime.Parse(stDate[0]));
            }
            if (endDate.HasValue)
            {
                string datetime = endDate.ToString();          //converts the datetime value to string
                string[] edDate = datetime.Split(' ');
                dynamicParams.Add("end", DateTime.Parse(edDate[0]).AddHours(23).AddMinutes(59).AddSeconds(59).AddMilliseconds(59));
            }
            if (month.HasValue && month.Value > 0 && year.HasValue && year.Value > 0)
            {
                startDate = new(year.Value, month.Value, 1);
                endDate = new DateTime(year.Value, month.Value, DateTime.DaysInMonth(year.Value, month.Value));

                dynamicParams.Add("start", startDate);
                dynamicParams.Add("end", endDate.Value.AddHours(23).AddMinutes(59).AddSeconds(59).AddMilliseconds(59));
            }
            if (storeIds.Any())
            {
                dynamicParams.Add("StoreIds", storeIds.Cast<int>().ToArray().GetTableValuedParameter("[dbo].[UdtIntKeys]", "KeyValue"));
                query += " and (StoreId in (select KeyValue from @StoreIds))";
            }
            else
            {
                dynamicParams.Add("StoreIds", null);
            }
            if (userIds.Any())
            {
                dynamicParams.Add("UserIds", userIds.Cast<int>().ToArray().GetTableValuedParameter("[dbo].[UdtIntKeys]", "KeyValue"));
                query += " and userid in(select KeyValue from @UserIds)";
            }

            query += " group by userid,WalletCredit.WalletId";
            try
            {
              return (await DbConnection.QueryAsync<UserRewardDetailsModel>(query, dynamicParams, DbTransaction)).ToList();
        }
            catch(Exception ex)
            {
                throw;
            }
}

        public async Task<UserWalletDetailModel> GetUserWalletDetailsByUserId(int userId)
        {
            string query = @$"Select sum(creditamount)TotalCreditAmount,(select sum(amount) from walletdebit where DebitStateId = 2 and walletdebit.walletid=walletcredit.walletid)TotalRedeemedAmount,(select sum(creditamount) from walletcredit wc where wc.walletid=walletcredit.walletid and credittypeid=3)TotalReceivedAmount,(select sum(Amount) from walletdebit  where walletdebit.walletid=walletcredit.walletid and LinkMemberTransferId is not null)TotalSharedAmount,(select sum(CurrentAmount) from walletcredit wc where wc.walletid=walletcredit.walletid and ExpireDate<getutcdate())TotalExpiredAmount,(select sum(creditamount) from walletcredit wc where wc.walletid=walletcredit.walletid and credittypeid=2)TotalPromotionalAmount,(select convert(decimal(9,2),isnull(sum(currentamount),0)) from walletcredit wc where wc.walletid=WalletCredit.walletid and expiredate>=getutcdate() and currentamount>0) TotalAvailableAmount from walletcredit inner join wallet on walletcredit.walletid=wallet.walletid where 1=1";
            
            DynamicParameters dynamicParams = new();
            if (userId > 0)
            {
                dynamicParams.Add("UserId", userId);
                query += " and (UserId = @UserId)";
            }
            query += "  group by WalletCredit.WalletId";
            try
            {

                return (await DbConnection.QueryFirstOrDefaultAsync<UserWalletDetailModel>(query, dynamicParams, DbTransaction));
            }
            catch (Exception ex)
            { throw; }
        }
        public async Task<IEnumerable<WalletCredit>> GetExpiringWalletCreditByUserId(int userId)
        {
            string query = @$"select wc.* from [WalletCredit] wc Inner Join [Wallet] w on wc.WalletId=w.WalletId where  ExpireDate>=getutcdate() and currentAmount>0 and w.[UserId] =@userId order by expiredate";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("userId", userId);

            return (await DbConnection.QueryAsync<WalletCredit>(query, dynamicParams, DbTransaction)).ToList();
        }

        public async Task<List<UserWalletDetailModel>> GetUserWalletDetailsListByUserId(IEnumerable<int> userId)
        {
            string query = @$"Select wallet.UserId, sum(creditamount)TotalCreditAmount,
(select sum(amount) from walletdebit where DebitStateId = 2 and walletdebit.walletid=walletcredit.walletid)TotalRedeemedAmount,
(select sum(creditamount) from walletcredit wc where wc.walletid=walletcredit.walletid and credittypeid=3)TotalReceivedAmount,
(select sum(Amount) from walletdebit  
where walletdebit.walletid=walletcredit.walletid and LinkMemberTransferId is not null)TotalSharedAmount,
(select sum(CurrentAmount) from walletcredit wc where wc.walletid=walletcredit.walletid and ExpireDate<getutcdate())TotalExpiredAmount,
(select sum(creditamount) from walletcredit wc where wc.walletid=walletcredit.walletid and credittypeid=2)TotalPromotionalAmount,
(select convert(decimal(9,2),isnull(sum(currentamount),0)) 
from walletcredit wc 
where wc.walletid=WalletCredit.walletid 
and expiredate>=getutcdate() and currentamount>0) TotalAvailableAmount 
from walletcredit inner join wallet on walletcredit.walletid=wallet.walletid where 1=1";

            DynamicParameters dynamicParams = new();
            if (userId.Any())
            {
                dynamicParams.Add("userId", userId.Cast<int>().ToArray().GetTableValuedParameter("[dbo].[UdtIntKeys]", "KeyValue"));
                query += " and userid in(select KeyValue from @userId)";
            }
            query += "  group by WalletCredit.WalletId,UserId";
            try
            {
                return (await DbConnection.QueryAsync<UserWalletDetailModel>(query, dynamicParams, DbTransaction)).ToList();
            }
            catch (Exception ex)
            { throw; }
        }

        public async Task<List<WalletCreditDetailModel>> GetAllUserWalletCredit()
        {
            StringBuilder sbquery = new();
            DynamicParameters para = new();

            sbquery.Append(@$"SELECT W.UserId, WC.WalletId,WC.CurrentAmount,                                                CreditAmount,
                              StoreName,TransactionId,PaymentMethodId,TransactionId
                              FROM WalletCredit WC 
                              INNER JOIN  Wallet W on WC.WalletId=W.WalletId 
                              WHERE NotificationTypeIdentifier = 'AddCardEvent' ");

            return (await DbConnection.QueryAsync<WalletCreditDetailModel>(sbquery.ToString(), para, DbTransaction)).ToList();
        }

        public async Task<List<UserWalletDetailModel>> GetWalletDetails()
        {
            string query = @$"Select UserId, sum(creditamount)TotalCreditAmount,(select sum(amount) from walletdebit where DebitStateId = 2 and walletdebit.walletid=walletcredit.walletid)TotalRedeemedAmount,(select sum(creditamount) from walletcredit wc where wc.walletid=walletcredit.walletid and credittypeid=3)TotalReceivedAmount,(select sum(Amount) from walletdebit  where walletdebit.walletid=walletcredit.walletid and LinkMemberTransferId is not null)TotalSharedAmount,(select sum(CurrentAmount) from walletcredit wc where wc.walletid=walletcredit.walletid and ExpireDate<getutcdate())TotalExpiredAmount,(select sum(creditamount) from walletcredit wc where wc.walletid=walletcredit.walletid and credittypeid=2)TotalPromotionalAmount,(select convert(decimal(9,2),isnull(sum(currentamount),0)) from walletcredit wc where wc.walletid=WalletCredit.walletid and expiredate>=getutcdate() and currentamount>0) TotalAvailableAmount from walletcredit inner join wallet on walletcredit.walletid=wallet.walletid where 1=1";

            DynamicParameters dynamicParams = new();
            query += "  group by WalletCredit.WalletId, UserId";
            try
            {

                return (await DbConnection.QueryAsync<UserWalletDetailModel>(query, dynamicParams, DbTransaction)).ToList();
            }
            catch (Exception ex)
            { throw; }
        }
    }
}
