﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Finance.Application.Repositories;

namespace SpiTech.Finance.Infrastructure.Repositories
{
    public class DebitTypeRepository : Repository<Domain.Entities.DebitType>, IDebitTypeRepository
    {
        public DebitTypeRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
    }
}
