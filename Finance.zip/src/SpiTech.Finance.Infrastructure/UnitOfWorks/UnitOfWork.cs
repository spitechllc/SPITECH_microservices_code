﻿using AutoMapper;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Finance.Application.Repositories;
using SpiTech.Finance.Application.UnitOfWorks;
using SpiTech.Finance.Infrastructure.Repositories;
using System.Data;

namespace SpiTech.Finance.Infrastructure.UnitOfWorks
{
    public sealed class UnitOfWork : BaseUnitOfWork, IUnitOfWork
    {
        public UnitOfWork(string connectionString,
                          System.IServiceProvider serviceProvider,
                         IsolationLevel isolationLevel = IsolationLevel.ReadCommitted)
                         : base(connectionString, serviceProvider, isolationLevel)
        {
        }

        private IWalletRepository _wallets = null;
        private ILinkMemberTransferRepository _linkMemberTransfers = null;
        private IDebitTypeRepository _debitTypes = null;
        private ICreditTypeRepository _creditTypes = null;
        private IWalletCreditRepository _walletCredits = null;
        private IWalletDebitDetailRepository _walletDebitDetails = null;
        private IWalletDebitRepository _walletDebits = null;
        private IConfigRepository _configs = null;
        private ITransferStatusRepository _transferStatuses = null;

        public IWalletRepository Wallets => _wallets ??= new WalletRepository(this, serviceProvider);

        public ILinkMemberTransferRepository LinkMemberTransfers => _linkMemberTransfers ??= new LinkMemberTransferRepository(this, serviceProvider);
        public IDebitTypeRepository DebitTypes => _debitTypes ??= new DebitTypeRepository(this, serviceProvider);
        public ICreditTypeRepository CreditTypes => _creditTypes ??= new CreditTypeRepository(this, serviceProvider);
        public IWalletCreditRepository WalletCredits => _walletCredits ??= new WalletCreditRepository(this, serviceProvider);

        public IWalletDebitDetailRepository WalletDebitDetails => _walletDebitDetails ??= new WalletDebitDetailRepository(this, serviceProvider);

        public IWalletDebitRepository WalletDebits => _walletDebits ??= new WalletDebitRepository(this, serviceProvider);

        public IConfigRepository Configs => _configs ??= new ConfigRepository(this, serviceProvider);

        public ITransferStatusRepository TransferStatuses => _transferStatuses ??= new TransferStatusRepository(this, serviceProvider);

        public override void ResetRepositories()
        {
            _wallets = null;
            _linkMemberTransfers = null;
            _debitTypes = null;
            _creditTypes = null;
            _walletCredits = null;
            _walletDebitDetails = null;
            _walletDebits = null;
            _configs = null;
            _transferStatuses = null;
        }
    }
}
