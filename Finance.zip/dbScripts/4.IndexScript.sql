/*
IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Wallet_UserId')   
    DROP INDEX IX_Wallet_UserId ON [dbo].[Wallet];   
GO  
GO
CREATE NONCLUSTERED INDEX IX_Wallet_UserId  
    ON [dbo].[Wallet] (UserId);   
GO

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_WalletCredit_WalletId')   
    DROP INDEX IX_WalletCredit_WalletId ON [dbo].[WalletCredit];   
GO  

CREATE NONCLUSTERED INDEX IX_WalletCredit_WalletId 
    ON [dbo].[WalletCredit] (WalletId);   
GO

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_WalletCredit_StoreId')   
    DROP INDEX IX_WalletCredit_StoreId ON [dbo].[WalletCredit];   
GO  

CREATE NONCLUSTERED INDEX IX_WalletCredit_StoreId 
    ON [dbo].[WalletCredit] (StoreId);   
GO 

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_WalletCredit_TransactionId')   
    DROP INDEX IX_WalletCredit_TransactionId ON [dbo].[WalletCredit];   
GO  

CREATE NONCLUSTERED INDEX IX_WalletCredit_TransactionId 
    ON [dbo].[WalletCredit] (TransactionId);   
GO 


IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_WalletDebit_AuthNumber')   
    DROP INDEX IX_WalletDebit_AuthNumber ON [dbo].[WalletDebit];   
GO  

CREATE NONCLUSTERED INDEX IX_WalletDebit_AuthNumber 
    ON [dbo].[WalletDebit] (AuthNumber);   
GO 


IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_LinkMemberTransfer_FromUserId')   
    DROP INDEX IX_WalletDebit_FromUserId ON [dbo].[LinkMemberTransfer];   
GO  

CREATE NONCLUSTERED INDEX IX_LinkMemberTransfer_FromUserId 
    ON [dbo].[LinkMemberTransfer] (FromUserId);   
GO 


IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_LinkMemberTransfer_ToUserId')   
    DROP INDEX IX_LinkMemberTransfer_ToUserId ON [dbo].[LinkMemberTransfer];   
GO  

CREATE NONCLUSTERED INDEX IX_LinkMemberTransfer_ToUserId
    ON [dbo].[LinkMemberTransfer] (ToUserId);   
GO 
GO
*/