Alter table [dbo].[WalletDebit] add WalletBalanceAmount numeric(18,2)

-------------------start script 05 july 2023------------------------
CREATE FUNCTION [dbo].[fn_monthlist] (
@year varchar(5)
)
RETURNS @Items TABLE (
MonthId int,[Month] VARCHAR(50)
)
AS
BEGIN


;with months (date)
AS
(
    SELECT cast(@year+'-01-01' as date)
    UNION ALL
    SELECT DATEADD(month,1,date)
    from months
    where  DATEADD(month,1,date)<= case when @year=YEAR(getdate()) THEN CAST(getdate() as date) ELSE cast(@year+'-12-31' as date) END
)
INSERT INTO @Items select month(date)MonthId,Datename(month,date) [Month] from months

RETURN

END

GO
-------------------------end script 05 july 2023--------------------
---------------------start script 19 july 2023------------------------


CREATE TYPE [dbo].[UdtIntKeys] AS TABLE(
	[KeyValue] int NOT NULL,
	PRIMARY KEY CLUSTERED 
(
	[KeyValue] ASC
)WITH (IGNORE_DUP_KEY = OFF)
)
GO


---------------end script 19july 2023---------------------