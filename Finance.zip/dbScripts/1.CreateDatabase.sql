 IF NOT EXISTS(SELECT * FROM sys.databases WHERE name = 'SpiTech_Finance')
  BEGIN
    CREATE DATABASE [SpiTech_Finance]
 END
GO
       
 USE [SpiTech_Finance]
    
GO

