Create Procedure [dbo].[UpdateSite]
@StoreId Int,
@SiteId nvarchar(20),
@StoreName nvarchar(200)
As
Begin
	DECLARE @OriginalSiteId nvarchar(20);
	DECLARE @OriginalStoreName nvarchar(20);	
		
	If(@StoreId=0)
	BEGIN
		return;
	END
	
	update [WalletCredit] set StoreName = @StoreName  Where storeId = @storeId;
	update [WalletDebit] set StoreName = @StoreName  Where storeId = @storeId;
END
GO

CREATE FUNCTION [dbo].[fn_monthlist] (
@year varchar(5)
)
RETURNS @Items TABLE (
MonthId int,[Month] VARCHAR(50)
)
AS
BEGIN


;with months (date)
AS
(
    SELECT cast(@year+'-01-01' as date)
    UNION ALL
    SELECT DATEADD(month,1,date)
    from months
    where  DATEADD(month,1,date)<= case when @year=YEAR(getdate()) THEN CAST(getdate() as date) ELSE cast(@year+'-12-31' as date) END
)
INSERT INTO @Items select month(date)MonthId,Datename(month,date) [Month] from months

RETURN

END

GO


CREATE TYPE [dbo].[UdtIntKeys] AS TABLE(
	[KeyValue] int NOT NULL,
	PRIMARY KEY CLUSTERED 
(
	[KeyValue] ASC
)WITH (IGNORE_DUP_KEY = OFF)
)
GO
