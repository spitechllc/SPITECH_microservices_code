CREATE TABLE [dbo].[Config]
(
	  [ConfigId] INT NOT NULL IDENTITY(1,1)
	, [LastExecutionTime] DATETIME NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Config] PRIMARY KEY ([ConfigId] ASC)
)

GO
CREATE TABLE [dbo].[CreditType]
(
	  [CreditTypeId] INT NOT NULL
	, [Name] VARCHAR(100) NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_CreditType] PRIMARY KEY ([CreditTypeId] ASC)
)
GO
CREATE TABLE [dbo].[DebitState]
(
	  [DebitStateId] INT NOT NULL
	, [Name] VARCHAR(100) NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_DebitState] PRIMARY KEY ([DebitStateId] ASC)
)

GO
CREATE TABLE [dbo].[DebitType]
(
	  [DebitTypeId] INT NOT NULL
	, [Name] VARCHAR(100) NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_DebitType] PRIMARY KEY ([DebitTypeId] ASC)
)

GO

CREATE TABLE [dbo].[TransferStatus](
	  [TransferStatusId] INT NOT NULL
	, [Name] VARCHAR(50) NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	,CONSTRAINT [PK_TransferStatus] PRIMARY KEY ([TransferStatusId] ASC)
) 
GO
CREATE TABLE [dbo].[LinkMemberTransfer]
(
	  [LinkMemberTransferId] INT NOT NULL IDENTITY(1,1)
	, [FromUserId] INT NOT NULL
	, [ToUserId] INT NOT NULL
	, [TransferAmount] DECIMAL(18,2) NULL
	, [TransferStatusId] INT NULL
	, [RequestedDate] DATETIME  NULL
	, [ActionDate] DATETIME  NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_LinkMemberTransfer] PRIMARY KEY ([LinkMemberTransferId] ASC)
)
ALTER TABLE [dbo].[LinkMemberTransfer] WITH CHECK ADD CONSTRAINT [FK_LinkMemberTransfer_TransferStatus] FOREIGN KEY([TransferStatusId]) REFERENCES [dbo].[TransferStatus] ([TransferStatusId])
ALTER TABLE [dbo].[LinkMemberTransfer] CHECK CONSTRAINT [FK_LinkMemberTransfer_TransferStatus]

GO
CREATE TABLE [dbo].[Wallet]
(
	  [WalletId] INT NOT NULL IDENTITY(1,1)
	, [UserId] INT NOT NULL
	, [IsTransactionLock] BIT NOT NULL DEFAULT((0))
	, [TransactionLockOn] DATETIME NULL
	, [TransactionLockId] VARCHAR(50) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Wallet] PRIMARY KEY ([WalletId] ASC)
)

CREATE UNIQUE NONCLUSTERED INDEX [UQ_Wallet] ON [dbo].[Wallet] ([UserId] ASC)

GO
CREATE TABLE [dbo].[WalletCredit]
(
	  [WalletCreditId] BIGINT NOT NULL IDENTITY(1,1)
	, [WalletId] INT NOT NULL
	, [CreditAmount] DECIMAL(18,2) NULL
	, [CurrentAmount] DECIMAL(18,2) NULL
	, [TransactionAmount] DECIMAL(18,2) NULL
	, [StoreId] BIGINT NULL
	, [StoreName] VARCHAR(200) NULL
	, [TransactionId] BIGINT NULL
	, [TransactionDesc] VARCHAR(100) NULL
	, [TransactionTypeId] INT NULL
	, [UserPaymentMethodId] INT NULL
	, [PaymentMethodId] INT NULL
	, [LinkMemberTransferId] INT NULL
	, [FromWalletCreditId] BIGINT NULL
	, [CreditIdentifier] INT NULL
	, [CreditTypeId] INT NOT NULL
	, [CreditDate] DATETIME NOT NULL DEFAULT(getutcdate())
	, [ExpireDate] DATETIME NULL
	, [IsRefunded] BIT NOT NULL DEFAULT((0))
	, [RefundDate] DATETIME NULL
	, [LastNotificationSentDate] DATETIME NULL
	, [TransactionCount] INT NULL
	, [NotificationTypeIdentifier] varchar(100) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_WalletCredit] PRIMARY KEY ([WalletCreditId] ASC)
)

ALTER TABLE [dbo].[WalletCredit] WITH CHECK ADD CONSTRAINT [FK_WalletCredit_CreditType] FOREIGN KEY([CreditTypeId]) REFERENCES [dbo].[CreditType] ([CreditTypeId])
ALTER TABLE [dbo].[WalletCredit] CHECK CONSTRAINT [FK_WalletCredit_CreditType]

ALTER TABLE [dbo].[WalletCredit] WITH CHECK ADD CONSTRAINT [FK_WalletCredit_LinkMemberTransfer] FOREIGN KEY([LinkMemberTransferId]) REFERENCES [dbo].[LinkMemberTransfer] ([LinkMemberTransferId])
ALTER TABLE [dbo].[WalletCredit] CHECK CONSTRAINT [FK_WalletCredit_LinkMemberTransfer]

ALTER TABLE [dbo].[WalletCredit] WITH CHECK ADD CONSTRAINT [FK_WalletCredit_Wallet] FOREIGN KEY([WalletId]) REFERENCES [dbo].[Wallet] ([WalletId])
ALTER TABLE [dbo].[WalletCredit] CHECK CONSTRAINT [FK_WalletCredit_Wallet]

GO
CREATE TABLE [dbo].[WalletDebit]
(
	  [WalletDebitId] BIGINT NOT NULL IDENTITY(1,1)
	, [WalletId] INT NOT NULL
	, [AuthNumber] VARCHAR(50) NOT NULL
	, [Amount] DECIMAL(18,2) NULL	
	, [WalletBalanceAmount] DECIMAL(18,2) NULL
	, [StoreId] INT NULL
	, [StoreName] VARCHAR(200) NULL
	, [LinkMemberTransferId] INT NULL
	, [TransactionId] BIGINT NULL
	, [TransactionDesc] VARCHAR(1000) NULL
	, [DebitDate] DATETIME NOT NULL DEFAULT(getutcdate())
	, [IsRefunded] BIT NOT NULL DEFAULT((0))
	, [RefundDate] DATETIME NULL
	, [DebitTypeId] INT NOT NULL
	, [DebitStateId] INT NOT NULL
	, [Error] VARCHAR(500) NULL
	, [TransactionLockId] VARCHAR(50) NULL
	, [NotificationTypeIdentifier] varchar(100) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_WalletDebit] PRIMARY KEY ([WalletDebitId] ASC)
)

ALTER TABLE [dbo].[WalletDebit] WITH CHECK ADD CONSTRAINT [FK_WalletDebit_DebitState] FOREIGN KEY([DebitStateId]) REFERENCES [dbo].[DebitState] ([DebitStateId])
ALTER TABLE [dbo].[WalletDebit] CHECK CONSTRAINT [FK_WalletDebit_DebitState]

ALTER TABLE [dbo].[WalletDebit] WITH CHECK ADD CONSTRAINT [FK_WalletDebit_DebitType] FOREIGN KEY([DebitTypeId]) REFERENCES [dbo].[DebitType] ([DebitTypeId])
ALTER TABLE [dbo].[WalletDebit] CHECK CONSTRAINT [FK_WalletDebit_DebitType]

ALTER TABLE [dbo].[WalletDebit] WITH CHECK ADD CONSTRAINT [FK_WalletDebit_LinkMemberTransfer] FOREIGN KEY([LinkMemberTransferId]) REFERENCES [dbo].[LinkMemberTransfer] ([LinkMemberTransferId])
ALTER TABLE [dbo].[WalletDebit] CHECK CONSTRAINT [FK_WalletDebit_LinkMemberTransfer]

ALTER TABLE [dbo].[WalletDebit] WITH CHECK ADD CONSTRAINT [FK_WalletDebit_Wallet] FOREIGN KEY([WalletId]) REFERENCES [dbo].[Wallet] ([WalletId])
ALTER TABLE [dbo].[WalletDebit] CHECK CONSTRAINT [FK_WalletDebit_Wallet]

GO
CREATE TABLE [dbo].[WalletDebitDetail]
(
	  [WalletDebitDetailId] BIGINT NOT NULL IDENTITY(1,1)
	, [FromWalletCreditId] BIGINT NOT NULL
	, [WalletDebitId] BIGINT NOT NULL
	, [Amount] DECIMAL(18,2) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_WalletDebitDetail] PRIMARY KEY ([WalletDebitDetailId] ASC)
)

ALTER TABLE [dbo].[WalletDebitDetail] WITH CHECK ADD CONSTRAINT [FK_WalletDebitDetail_WalletCredit] FOREIGN KEY([FromWalletCreditId]) REFERENCES [dbo].[WalletCredit] ([WalletCreditId])
ALTER TABLE [dbo].[WalletDebitDetail] CHECK CONSTRAINT [FK_WalletDebitDetail_WalletCredit]

ALTER TABLE [dbo].[WalletDebitDetail] WITH CHECK ADD CONSTRAINT [FK_WalletDebitDetail_WalletDebit] FOREIGN KEY([WalletDebitId]) REFERENCES [dbo].[WalletDebit] ([WalletDebitId])
ALTER TABLE [dbo].[WalletDebitDetail] CHECK CONSTRAINT [FK_WalletDebitDetail_WalletDebit]

GO