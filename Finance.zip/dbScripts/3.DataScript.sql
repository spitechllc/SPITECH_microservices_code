INSERT INTO [CreditType](CreditTypeId, Name)
VALUES 
(1, 'Loyalty'),
(2, 'Promotion'),
(3, 'LinkUserTransfer'),
(4, 'AdminCredit');
GO

INSERT INTO [DebitState](DebitStateId, Name)
VALUES 
(1, 'PreAuth'),
(2, 'Completed'),
(3, 'Error');
GO


INSERT INTO [DebitType](DebitTypeId, Name)
VALUES 
(1, 'StorePumpReserve'),
(2, 'StorePos'),
(3, 'LinkUserTransfer'),
(4, 'AdminDebit');
GO

INSERT INTO [dbo].[TransferStatus](TransferStatusId, Name)VALUES 
(1, 'New'),
(2, 'Accepted'),
(3, 'Transferred'),
(4, 'Rejected'),
(5, 'InsufficientBalance'),
(6, 'Error');
GO