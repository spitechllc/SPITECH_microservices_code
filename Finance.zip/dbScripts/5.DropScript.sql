Drop TABLE [dbo].[WalletDebitDetail]
GO
Drop TABLE [dbo].[WalletDebit]
GO
Drop TABLE [dbo].[WalletCredit]
GO
GO
Drop TABLE [dbo].[Wallet]
GO
Drop TABLE [dbo].[LinkMemberTransfer]
GO

Drop TABLE [dbo].[TransferStatus]
GO
Drop TABLE [dbo].[DebitType]
GO
Drop TABLE [dbo].[DebitState]
GO
Drop TABLE [dbo].[CreditType]
GO
Drop TABLE [dbo].[Config]

