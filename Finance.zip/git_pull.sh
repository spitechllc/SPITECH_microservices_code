#!/bin/bash
cd Accounts
echo "################################################Pull Accounts########################################################"

git.exe pull --progress -v --no-rebase "origin" SPITECH

echo "##############################################Completed Pull Accounts########################################################"
cd ..

cd Finance
echo "################################################Pull Finance########################################################"

git.exe pull --progress -v --no-rebase "origin" SPITECH

echo "##############################################Completed Pull Finance########################################################"
cd ..

cd HelpSupport
echo "################################################Pull HelpSupport########################################################"

git.exe pull --progress -v --no-rebase "origin" SPITECH

echo "##############################################Completed Pull HelpSupport########################################################"
cd ..


cd IdentityMicroservices
echo "################################################Pull IdentityMicroservices########################################################"

git.exe pull --progress -v --no-rebase "origin" SPITECH

echo "##############################################Completed Pull IdentityMicroservices########################################################"
cd ..

cd Marketing
echo "################################################Pull Marketing########################################################"

git.exe pull --progress -v --no-rebase "origin" SPITECH

echo "##############################################Completed Pull Marketing########################################################"
cd ..


cd MPPAMicroservices
echo "################################################Pull MPPAMicroservices########################################################"

git.exe pull --progress -v --no-rebase "origin" SPITECH

echo "##############################################Completed Pull MPPAMicroservices########################################################"
cd ..


cd Notifications
echo "################################################Pull Notifications########################################################"

git.exe pull --progress -v --no-rebase "origin" SPITECH

echo "##############################################Completed Pull Notifications########################################################"
cd ..


cd SpiTech.ApiGateway
echo "################################################Pull SpiTech.ApiGateway########################################################"

git.exe pull --progress -v --no-rebase "origin" SPITECH

echo "##############################################Completed Pull SpiTech.ApiGateway########################################################"
cd ..


cd Payment_Gateway
echo "################################################Pull Payment_Gateway########################################################"

git.exe pull --progress -v --no-rebase "origin" SPITECH

echo "##############################################Completed Pull Payment_Gateway########################################################"
cd ..

cd Report_Aggregator
echo "################################################Pull Report_Aggregator########################################################"

git.exe pull --progress -v --no-rebase "origin" SPITECH

echo "##############################################Completed Pull Report_Aggregator########################################################"
cd ..

cd Transaction
echo "################################################Pull Transaction########################################################"

git.exe pull --progress -v --no-rebase "origin" SPITECH

echo "##############################################Completed Pull Transaction########################################################"
cd ..


cd UserAndStoreMicroservices
echo "################################################Pull UserAndStoreMicroservices########################################################"

git.exe pull --progress -v --no-rebase "origin" SPITECH

echo "##############################################Completed Pull UserAndStoreMicroservices########################################################"
cd ..

read -p "Press enter to close"