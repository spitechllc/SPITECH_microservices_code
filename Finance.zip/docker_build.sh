#!/bin/bash
cd ..
echo "################################################DotNet Build########################################################"

dotnet build

echo "##############################################DotNet Publish########################################################"

dotnet publish

echo "################################################Docker Build########################################################"

docker build -f Deployment/dockerfile -t prod/finance .

echo "##################################################Docker Tag########################################################"

docker tag prod/finance prodregistry00.azurecr.io/prod/finance
echo "successfully tagged the image "

echo "#################################################Docker Push########################################################"
az acr login -n prodregistry00.azurecr.io
docker push prodregistry00.azurecr.io/prod/finance

