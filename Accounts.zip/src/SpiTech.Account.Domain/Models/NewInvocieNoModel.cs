﻿namespace SpiTech.Account.Domain.Models
{
    public class NewInvocieNoModel
    {
        public string NewInvoiceNo { get; set; }
    }
}
