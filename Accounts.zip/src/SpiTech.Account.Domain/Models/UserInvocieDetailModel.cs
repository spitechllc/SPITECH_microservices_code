﻿namespace SpiTech.Account.Domain.Models
{
    public class UserInvoiceDetailModel
    {
        public int TotalInvoices { get; set; }
        public decimal TotalAmount { get; set; }
        public int TotalQuantity { get; set; }
        public int TotalPendingInvoices { get; set; }
        public decimal TotalPendingAmount { get; set; }
        public int TotalPendingQuantity { get; set; }
        public int TotalPaidInvoices { get; set; }
        public decimal TotalPaidAmount { get; set; }
        public int TotalPaidQuantity { get; set; }
        public int TotalDeclinedInvoices { get; set; }
        public decimal TotalDeclinedAmount { get; set; }
        public int TotalDeclinedQuantity { get; set; }
        public int TotalCanceledInvoices { get; set; }
        public decimal TotalCanceledAmount { get; set; }
        public int TotalCanceledQuantity { get; set; }
    }
    //public class UserInvocieDetail
    //{
    //    public int TotalInvoices { get; set; }
    //    public int TotalAmount { get; set; }
    //    public int TotalQuantity { get; set; }
    //    public int TotalPending { get; set; }
    //    public int TotalPaid { get; set; }
    //    public int TotalDeclined { get; set; }
    //    public int TotalCanceled { get; set; }
    //}

}
