﻿using System.Collections.Generic;

namespace SpiTech.Account.Domain.Models
{
    public class FinalResultModel<T>
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }
        public T Data { get; set; }

    }


    public class FinalResultListModel<T>
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }
        public IEnumerable<T> Data { get; set; }

    }
}
