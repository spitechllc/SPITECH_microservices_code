﻿namespace SpiTech.Account.Domain.Models
{
    public class PaymentStatusModel
    {
        public int StatusId { get; set; }
        public string Status { get; set; }
    }
}
