﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace SpiTech.Account.Domain.Models
{
    public class InvoiceModel
    {
        public int InvoiceId { get; set; }
        public string InvoiceNo { get; set; }
        public DateTime InvoiceDate { get; set; }
        public DateTime InvoiceDueDate { get; set; }
        public decimal Quantity { get; set; }
        public decimal NetAmount { get; set; }
        public string TaxType { get; set; }
        public string TaxCaption { get; set; }
        public decimal TaxValue { get; set; }
        public decimal TaxAmount { get; set; }
        public decimal TotalAmount { get; set; }
        public int ReceiverId { get; set; }
        public int SenderId { get; set; }
        public bool IsActive { get; set; }
        public int StatusId { get; set; }
        public int TemplateType { get; set; }
        public string Remarks { get; set; }
        public string InteralRemarks { get; set; }
        public string ExternalRemarks { get; set; }
        [JsonIgnore]
        public int TotalRecord { get; set; }
        public PaymentStatusModel Status { get; set; }
        public IEnumerable<InvoiceDetailModel> InvoiceItem { get; set; }
        public UsersModel SenderData { get; set; }
        public UsersModel ReceiverData { get; set; }

    }
}
