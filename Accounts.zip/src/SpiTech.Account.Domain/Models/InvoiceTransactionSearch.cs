﻿using System;
using System.Text.Json.Serialization;

namespace SpiTech.Account.Domain.Models
{
    public class InvoiceTransactionSearch
    {

        public int UserId { get; set; }
        public int UserTypeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string BusinessName { get; set; }
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
        public string PhotoUrl { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string Country { get; set; }
        public string CountryCode { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public int InvoiceId { get; set; }
        public string InvoiceNo { get; set; }
        public DateTime InvoiceDate { get; set; }
        public DateTime InvoiceDueDate { get; set; }
        public decimal Quantity { get; set; }
        public decimal NetAmount { get; set; }
        public string TaxType { get; set; }
        public decimal TaxValue { get; set; }
        public decimal TaxAmount { get; set; }
        public decimal TotalAmount { get; set; }
        public int ReceiverId { get; set; }
        public int SenderId { get; set; }
        public int StatusId { get; set; }
        public string Remarks { get; set; }
        public int TransactionId { get; set; }
        public string TransactionKey { get; set; }
        public DateTime TransactionDate { get; set; }
        public int TransferedBy { get; set; }
        public string SendOrReceive { get; set; }
        public int Status { get; set; }
        public bool IsActive { get; set; }
        public bool IsTransfered { get; set; }
        public DateTime CreatedOn { get; set; }
        public int CreatedBy { get; set; }


        [JsonIgnore]
        public int TotalRecord { get; set; }
    }
}

