﻿using SpiTech.EventBus.DomainEvents.Models.Identity;
using System;

namespace SpiTech.Account.Domain.Models
{
    public class TransactionModel
    {
        public int TransactionId { get; set; }
        public string TransactionKey { get; set; }
        public DateTime TransactionDate { get; set; }
        public int InvoiceId { get; set; }
        public int TransferedBy { get; set; }
        public int Status { get; set; }
        public string StatusValue { get; set; }
        public bool IsTransfered { get; set; }
        public UserModel UserDetails { get; set; }
        public InvoiceModel Invoice { get; set; }
    }
}
