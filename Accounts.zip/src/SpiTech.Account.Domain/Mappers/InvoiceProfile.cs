﻿using AutoMapper;
using SpiTech.Account.Domain.Entities;
using SpiTech.Account.Domain.Models;

namespace SpiTech.Account.Domain.Mappers
{
    public class InvoiceProfile : Profile
    {
        public InvoiceProfile()
        {
            CreateMap<Invoice, InvoiceModel>().ReverseMap();
            CreateMap<InvoiceDetail, InvoiceDetailModel>().ReverseMap();
            CreateMap<PaymentStatus, PaymentStatusModel>().ReverseMap();
        }
    }
}
