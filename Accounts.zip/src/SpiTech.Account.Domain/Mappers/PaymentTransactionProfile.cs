﻿using AutoMapper;
using SpiTech.Account.Domain.Entities;
using SpiTech.Account.Domain.Models;

namespace SpiTech.Account.Domain.Mappers
{
    public class PaymentTransactionProfile : Profile
    {
        public PaymentTransactionProfile()
        {
            CreateMap<Transaction, TransactionModel>().ReverseMap();
        }
    }
}
