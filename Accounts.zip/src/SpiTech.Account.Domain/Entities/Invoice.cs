﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.Account.Domain.Entities
{
    [Table("[Invoice]")]
    public class Invoice : BaseEntity
    {
        [Key]
        public int InvoiceId { get; set; }
        public string InvoiceNo { get; set; }
        public DateTime InvoiceDate { get; set; }
        public DateTime InvoiceDueDate { get; set; }
        public decimal Quantity { get; set; }
        public decimal NetAmount { get; set; }
        public string TaxType { get; set; }
        public string TaxCaption { get; set; }
        public decimal TaxValue { get; set; }
        public decimal TaxAmount { get; set; }
        public decimal TotalAmount { get; set; }
        public int ReceiverId { get; set; }
        public int SenderId { get; set; }
        public int StatusId { get; set; }
        public int TemplateType { get; set; }
        public string Remarks { get; set; }
        public string InteralRemarks { get; set; }
        public string ExternalRemarks { get; set; }
    }
}
