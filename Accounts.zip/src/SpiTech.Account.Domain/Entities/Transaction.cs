﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.Account.Domain.Entities
{
    [Table("[Transaction]")]
    public class Transaction : BaseEntity
    {
        [Key]
        public int TransactionId { get; set; }
        public string TransactionKey { get; set; }
        public DateTime TransactionDate { get; set; }
        public int InvoiceId { get; set; }
        public int TransferedBy { get; set; }
        public int Status { get; set; }
        public bool IsTransfered { get; set; }
    }
}
