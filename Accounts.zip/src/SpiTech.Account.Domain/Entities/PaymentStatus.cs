﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Account.Domain.Entities
{
    [Table("[PaymentStatus]")]
    public class PaymentStatus : BaseEntity
    {
        [Key]
        public int StatusId { get; set; }
        public string Status { get; set; }
    }
}
