﻿namespace SpiTech.Account.Domain.Enums
{
    public enum PaymentStatusEnum
    {
        None = 0,
        Pending = 1,
        Paid = 2,
        Rejected = 3,
        Canceled = 4,
        Failed = 5,
    }
}
