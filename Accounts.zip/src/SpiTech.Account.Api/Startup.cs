using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using SpiTech.Account.Application;
using SpiTech.Account.Infrastructure;
using SpiTech.Application.Logging.Extensions;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.ApplicationCore.Security;
using SpiTech.ApplicationCore.ServiceCollection;
using SpiTech.Service.Clients;
using System;
using System.IO;
using System.Reflection;

namespace SpiTech.Account.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddIdentityClient(Configuration).AddPaymentClient(Configuration);

            services.AddApplicationCore(Configuration)
                .AddInfrastructure(Configuration)
                .AddApplication(Configuration);

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "Account Api",
                    Version = "v1",
                    Description = "The Account Microservice HTTP API.",
                });
                SwaggerGenSetup.Setup(options);
                string xmlfile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                string xmlpath = Path.Combine(AppContext.BaseDirectory, xmlfile);
                options.IncludeXmlComments(xmlpath);
            });

            services.AddAPIAuthentication(Configuration, "accountapi");
            services.AddAPIAuthorization();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseMiddleware(typeof(CustomResponseHeaderMiddleware));
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger().UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "SpiTech.Account.Api V1");
            });

            app.UseLogger();
            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();
            
            app.UseMiniProfiler();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
