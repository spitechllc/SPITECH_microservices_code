﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.Account.Application.Commands.AddNewInvoice;
using SpiTech.Account.Application.Commands.CancelInvocie;
using SpiTech.Account.Application.Commands.DeclineInvoice;
using SpiTech.Account.Application.Commands.InvoicePayment;
using SpiTech.Account.Application.Commands.UpdateInvoice;
using SpiTech.Account.Application.Queries.GenerateInvoiceNo;
using SpiTech.Account.Application.Queries.GetInvoice;
using SpiTech.Account.Application.Queries.GetInvoiceWithPaging;
using SpiTech.Account.Application.Queries.GetRecentInvoicesById;
using SpiTech.Account.Application.Queries.GetTodaysInvoiceWithPaging;
using SpiTech.Account.Application.Queries.GetUserInvoiceSummary;
using SpiTech.Account.Domain.Models;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Account.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class InvoiceController : ControllerBase
    {
        private readonly IMediator _mediator;

        public InvoiceController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Returns Newly Generate Invoice Number For Given UserId.
        /// </summary>
        /// <param name="query">Object of GenerateInvoiceNoQuery</param>
        /// <returns>It will return FinalResultModel in the form NewInvocieNoModel</returns>
        [ApiPermissionAuthorize(Permissions = "Accountapi_Invoice_GetInvoiceNo")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetInvoiceNo")]
        public async Task<ActionResult<FinalResultModel<NewInvocieNoModel>>> GenerateInvoiceNo([FromQuery] GenerateInvoiceNoQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Return A Invoice Record Of A User By Passing UserId And Invoice Number.
        /// </summary>
        /// <param name="query">Object of GetInvoiceQuery</param>
        /// <returns>It wiil return FinalResultModel in the form of InvoiceModel</returns>
        [ApiPermissionAuthorize(Permissions = "Accountapi_Invoice_GetInvoice")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetInvoice")]
        public async Task<ActionResult<FinalResultModel<InvoiceModel>>> GetInvoiceByNo([FromQuery] GetInvoiceQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Create/Send New Invoice 
        /// </summary>
        /// <param name="command">Object of AddNewInvoiceCommand</param>
        /// <returns>It wiil return FinalResultModel in the form of int</returns>
        [ApiPermissionAuthorize(Permissions = "Accountapi_Invoice_AddInvoice")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("AddInvoice")]
        public async Task<ActionResult<FinalResultModel<int>>> AddNewInvoice([FromBody] AddNewInvoiceCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Update Existing Invoice Record 
        /// </summary>
        /// <param name="command">Object of UpdateInvoiceCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Accountapi_Invoice_UpdateInvoice")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("UpdateInvoice")]
        public async Task<ActionResult<ResponseModel>> UpdateInvoice([FromBody] UpdateInvoiceCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Return A Collection of Invoices With Pagination
        /// </summary>
        /// <param name="query">Object of GetInvoiceWithPagingQuery</param>
        /// <returns>It will return PaginatedList in the form of InvoiceModel</returns>
        [ApiPermissionAuthorize(Permissions = "Accountapi_Invoice_InvoiceList")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("InvoiceList")]
        public async Task<ActionResult<PaginatedList<InvoiceModel>>> GetInvoiceWithPaging([FromQuery] GetInvoiceWithPagingQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Reject/Decline Received Invoice
        /// </summary>
        /// <param name="command">Object Of DeclineInvoiceCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Accountapi_Invoice_Decline")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("Decline")]
        public async Task<ActionResult<ResponseModel>> DeclineInvoice([FromBody] DeclineInvoiceCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Return A Collection of Recent 10 Invoices
        /// </summary>
        /// <param name="query">Object of GetRecentInvoicesByIdQuery</param>
        /// <returns>It will return FinalResultListModel in the form of InvoiceModel</returns>
        [ApiPermissionAuthorize(Permissions = "Accountapi_Invoice_RecentInvoiceList")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("RecentInvoiceList")]
        public async Task<ActionResult<FinalResultListModel<InvoiceModel>>> RecentInvoiceList([FromQuery] GetRecentInvoicesByIdQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Return Summary of Invoices Sent/Received By User
        /// </summary>
        /// <param name="query">Object of GetUserInvoiceSummaryQuery</param>
        /// <returns>It will return ResponseModel in the form of UserInvoiceDetailModel</returns>
        [ApiPermissionAuthorize(Permissions = "Accountapi_Invoice_InvoiceSummary")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("InvoiceSummary")]
        public async Task<ActionResult<ResponseModel<UserInvoiceDetailModel>>> UserInvoiceSummary([FromQuery] GetUserInvoiceSummaryQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Cancel Sent Invoice
        /// </summary>
        /// <param name="command">Object of CancelInvoiceCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Accountapi_Invoice_Cancel")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("Cancel")]
        public async Task<ActionResult<ResponseModel>> CancelInvoice([FromBody] CancelInvoiceCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Return A Collection of Today's Invoices
        /// </summary>
        /// <param name="query">Object of GetTodaysInvoiceWithPagingQuery</param>
        /// <returns>It will return PaginatedList in the form of InvoiceModel</returns>
        [ApiPermissionAuthorize(Permissions = "Accountapi_Invoice_TodaysInvoiceList")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("TodaysInvoiceList")]
        public async Task<ActionResult<PaginatedList<InvoiceModel>>> GetTodaysInvoiceWithPaging([FromQuery] GetTodaysInvoiceWithPagingQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Paid Received Invoice.
        /// </summary>
        /// <param name="command">Object of InvoicePaymentCommand</param>
        /// <returns>It will return ResponseModel in the form of TransactionModel</returns>
        [ApiPermissionAuthorize(Permissions = "Accountapi_Invoice_InvoicePayment")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("InvoicePayment")]
        public async Task<ActionResult<ResponseModel<TransactionModel>>> InvoicePayment([FromBody] InvoicePaymentCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }
    }
}
