﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.Account.Application.Queries.InvoiceTransactionList;
using SpiTech.Account.Domain.Models;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Pagination;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Account.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class InvoiceTransactionController : ControllerBase
    {
        private readonly IMediator _mediator;

        public InvoiceTransactionController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Return A Collection of Invoices Transactions Done By User
        /// </summary>
        /// <param name="query">Object of InvoiceTransactionQuery</param>
        /// <returns>It will return PaginatedList in the form of InvoiceTransactionSearch</returns>
        [ApiPermissionAuthorize(Permissions = "Accountapi_InvoiceTransaction_InvoiceTransactionList")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("InvoiceTransactionList")]
        public async Task<ActionResult<PaginatedList<InvoiceTransactionSearch>>> InvoiceTransactionList([FromQuery] InvoiceTransactionQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }
    }
}
