﻿using AutoMapper;
using MediatR;
using SpiTech.Account.Application.UnitOfWorks;
using SpiTech.Application.Logging.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Commands.CreateUser
{
    public class CreateUserHandler : IRequestHandler<CreateUserCommand, int>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateUserHandler> _logger;
        private readonly IMapper _mapper;
        public CreateUserHandler(IUnitOfWork context,
                                             ILogger<CreateUserHandler> logger,
                                             IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<int> Handle(CreateUserCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            int userId = 0;

            await _context.Execute(async () =>
            {
                userId = await _context.Users.Add(new Domain.Entities.User()
                {
                    UserId = command.UserId,
                    UserTypeId = command.UserTypeId,
                    FirstName = command.FirstName,
                    LastName = command.LastName,
                    Email = command.Email,
                    MobileCountryCode = command.MobileCountryCode,
                    MobileNumber = command.MobileNumber,
                    PhotoUrl = command.PhotoUrl,
                    AddressLine1 = command.AddressLine1,
                    AddressLine2 = command.AddressLine2,
                    Country = command.Country,
                    CountryCode = command.CountryCode,
                    State = command.State,
                    City = command.City,
                    CreatedOn = DateTime.UtcNow,
                    CreatedBy = 1,
                    IsActive = command.IsActive
                });
            });

            _logger.TraceExitMethod(nameof(Handle), userId);
            return userId;
        }
    }
}
