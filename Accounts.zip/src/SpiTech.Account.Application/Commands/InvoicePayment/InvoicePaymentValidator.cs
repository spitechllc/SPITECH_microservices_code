﻿using FluentValidation;

namespace SpiTech.Account.Application.Commands.InvoicePayment
{
    public class InvoicePaymentValidator : AbstractValidator<InvoicePaymentCommand>
    {
        public InvoicePaymentValidator()
        {
            RuleFor(s => s.UserPaymentMethodId).GreaterThan(0).WithMessage("UserPaymentMethodId Required");
            RuleFor(s => s.InvoiceId).GreaterThan(0).WithMessage("Invoice Id Required");
            //RuleFor(s => s.Description).NotNull().NotEmpty().WithMessage("Description Required");

        }
    }
}
