﻿using AutoMapper;
using MediatR;
using Newtonsoft.Json;
using SpiTech.Account.Application.UnitOfWorks;
using SpiTech.Account.Domain.Enums;
using SpiTech.Account.Domain.Models;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Account;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Commands.InvoicePayment
{
    public class InvoicePaymentHandler : IRequestHandler<InvoicePaymentCommand, ResponseModel<TransactionModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<InvoicePaymentHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IPaymentServiceClient paymentApiClient;
        private readonly IUserAuthenticationProvider _userAuthenticationProvider;

        public InvoicePaymentHandler(IMediator mediator,
                                   IMapper mapper,
                                   IUnitOfWork context,
                                   ILogger<InvoicePaymentHandler> logger,
                                   IEventDispatcher eventDispatcher,
                                   IPaymentServiceClient _paymentApiClient,
                                   IUserAuthenticationProvider userAuthenticationProvider
                                   )
        {
            _mediator = mediator;
            _mapper = mapper;
            _context = context;
            _logger = logger;
            _eventDispatcher = eventDispatcher;
            paymentApiClient = _paymentApiClient;
            _userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<ResponseModel<TransactionModel>> Handle(InvoicePaymentCommand command, CancellationToken cancellationToken)
        {
            TransactionModel result = null;
            ResponseModel<TransactionModel> response = new();
            try
            {
                _logger.TraceEnterMethod(nameof(Handle), command);
                Domain.Entities.Invoice invoiceRec = await _context.Invoices.GetByInvoiceById(command.InvoiceId);
                _userAuthenticationProvider.ValidateUserAccess(invoiceRec.ReceiverId);
                if (invoiceRec.StatusId == (int)PaymentStatusEnum.Pending)
                {
                    string hostName = Dns.GetHostName();
                    string IpAddress = Dns.GetHostByName(hostName).AddressList[0].ToString();
                    Service.Clients.Payments.PaymentCommand request = new()
                    {
                        UserId = invoiceRec.ReceiverId,
                        CardAmount = Convert.ToDouble(invoiceRec.TotalAmount),
                        PaymentType = Service.Clients.Payments.PaymentType.AccountInvoice,
                        UserPaymentMethodId = command.UserPaymentMethodId,
                        ConsumerIP = IpAddress,
                        TransactionId = invoiceRec.InvoiceId,
                        IsPaymentRequired = true,
                        Description = command.Description,
                    };
                    string jsondata = JsonConvert.SerializeObject(request);
                    Service.Clients.Payments.PaymentResponseModelResponseModel paymentResult = await paymentApiClient.PaymentAsync(request);


                    int trnc = await _context.paymentTransaction.Add(new Domain.Entities.Transaction
                    {
                        TransactionKey = paymentResult.Data.TransactionId.ToString(),
                        TransferedBy = invoiceRec.ReceiverId,
                        InvoiceId = command.InvoiceId,
                        TransactionDate = DateTime.UtcNow,
                        Status = paymentResult.Success == true ? (int)PaymentStatusEnum.Paid : (int)PaymentStatusEnum.Failed,
                        //IsActive=true,
                        IsTransfered = paymentResult.Success
                    });
                    if (paymentResult.Success)
                    {
                        ResponseModel payment = await _context.Invoices.PaymentInvoice(command.InvoiceId, "");
                        _context.Commit();
                        Domain.Entities.Invoice invoice = await _context.Invoices.GetByInvoiceById(command.InvoiceId);

                        InvoicePaidEvent invoicePaidEvent = new()
                        {
                            Invoice = new SpiTech.EventBus.DomainEvents.Models.Account.Invoice
                            {
                                InvoiceId = invoice.InvoiceId,
                                InvoiceNo = invoice.InvoiceNo,
                                InvoiceDate = invoice.InvoiceDate,
                                InvoiceDueDate = invoice.InvoiceDueDate,
                                Quantity = invoice.Quantity,
                                IsActive = invoice.IsActive,
                                NetAmount = invoice.NetAmount,
                                TaxType = invoice.TaxType,
                                TaxCaption = invoice.TaxCaption,
                                TaxValue = invoice.TaxValue,
                                TaxAmount = invoice.TaxAmount,
                                TotalAmount = invoice.TotalAmount,
                                ReceiverId = invoice.ReceiverId,
                                SenderId = invoice.SenderId,
                                StatusId = invoice.StatusId,
                                Remarks = invoice.Remarks,
                                InteralRemarks = invoice.InteralRemarks,
                                ExternalRemarks = invoice.ExternalRemarks,
                                invoiceItems = null
                            }
                        };

                        await _eventDispatcher.Dispatch(invoicePaidEvent);

                        Domain.Entities.Transaction transaction = await _context.paymentTransaction.GetByTransactionById(trnc);


                        if (transaction != null)
                        {
                            Domain.Entities.Invoice invoiceUpdated = await _context.Invoices.GetByInvoiceById(command.InvoiceId);
                            result = _mapper.Map<TransactionModel>(transaction);
                            InvoiceModel inv = _mapper.Map<InvoiceModel>(invoiceUpdated);
                            inv.Status = _mapper.Map<PaymentStatusModel>(await _context.Invoices.GetInvoicePaymentStatus(inv.StatusId));
                            result.Invoice = _mapper.Map<InvoiceModel>(inv);
                            result.StatusValue = Enum.GetName(typeof(Status), transaction.Status);

                            response.Success = true;
                            response.Message = "Payment Done Successfully";
                            response.Data = result;
                        }

                        _logger.TraceExitMethod(nameof(Handle), trnc);
                    }
                }
                else
                {

                    response.Success = false;
                    response.Message = "Invoice Already " + Enum.GetName(typeof(PaymentStatusEnum), invoiceRec.StatusId);
                    response.Data = result;
                }

                return response;
            }
            catch (Exception ex)
            {
                _context.Rollback();
                response.Success = false;
                response.Message = ex.Message;
                return response;
            };
        }
    }
}
