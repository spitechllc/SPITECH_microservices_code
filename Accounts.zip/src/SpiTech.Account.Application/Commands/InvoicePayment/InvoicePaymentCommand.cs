﻿using MediatR;
using SpiTech.Account.Domain.Models;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Account.Application.Commands.InvoicePayment
{
    public class InvoicePaymentCommand : IRequest<ResponseModel<TransactionModel>>
    {
        public int InvoiceId { get; set; }
        public int UserPaymentMethodId { get; set; }
        public string Description { get; set; }


    }
}
