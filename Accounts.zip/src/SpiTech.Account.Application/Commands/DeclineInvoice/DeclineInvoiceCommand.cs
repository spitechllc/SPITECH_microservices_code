﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Account.Application.Commands.DeclineInvoice
{
    public class DeclineInvoiceCommand : IRequest<ResponseModel>
    {
        public int InvoiceId { get; set; }
        public string Remarks { get; set; }
    }
}
