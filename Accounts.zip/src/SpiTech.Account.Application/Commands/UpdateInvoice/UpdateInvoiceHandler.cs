﻿using AutoMapper;
using MediatR;
using SpiTech.Account.Application.UnitOfWorks;
using SpiTech.Account.Domain.Entities;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Commands.UpdateInvoice
{
    public class UpdateInvoiceHandler : IRequestHandler<UpdateInvoiceCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateInvoiceHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider _userAuthenticationProvider;
        public UpdateInvoiceHandler(IMediator mediator,
                                   IMapper mapper,
                                   IUnitOfWork context,
                                   ILogger<UpdateInvoiceHandler> logger,
                                   IEventDispatcher eventDispatcher,
                                   IUserAuthenticationProvider userAuthenticationProvider
            )
        {
            _mediator = mediator;
            _mapper = mapper;
            _context = context;
            _logger = logger;
            _eventDispatcher = eventDispatcher;
            _userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<ResponseModel> Handle(UpdateInvoiceCommand command, CancellationToken cancellationToken)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Handle), command);
                _userAuthenticationProvider.ValidateUserAccess(command.SenderId);
                if (command != null)
                {
                    bool IsUpdated = await _context.Invoices.Update(new Invoice
                    {
                        InvoiceId = command.InvoiceId,
                        InvoiceNo = command.InvoiceNo,
                        InvoiceDate = command.InvoiceDate,
                        InvoiceDueDate = command.InvoiceDueDate,
                        Quantity = command.Quantity,
                        NetAmount = command.NetAmount,
                        TaxType = command.TaxType,
                        TaxCaption = command.TaxCaption,
                        TaxValue = command.TaxValue,
                        TaxAmount = command.TaxAmount,
                        TotalAmount = command.TotalAmount,
                        ReceiverId = command.ReceiverId,
                        SenderId = command.SenderId,
                        Remarks = command.Remarks,
                        InteralRemarks = command.InteralRemarks,
                        ExternalRemarks = command.ExternalRemarks,
                        StatusId = command.StatusId,
                        TemplateType = command.TemplateType,
                        IsActive = command.IsActive,
                        UpdatedBy = command.SenderId,
                        UpdatedOn = DateTime.UtcNow


                    });
                    foreach (Domain.Models.InvoiceDetailModel item in command.InvoiceItem)
                    {
                        await _context.InvoiceItems.Update(new InvoiceDetail
                        {
                            InvoiceDetailId = item.InvoiceDetailId,
                            InvoiceId = command.InvoiceId,
                            SerialNo = item.SerialNo,
                            Description = item.Description,
                            Quantity = item.Quantity,
                            Amount = item.Amount,
                        });
                    }

                    _logger.TraceExitMethod(nameof(Handle), IsUpdated);
                    _context.Commit();
                    return new ResponseModel { Message = "Invoice Updated Successfully", Success = true };
                    //return await Task.FromResult(IsUpdated);
                }
                return new ResponseModel { Message = "Invoice Updation Failed", Success = true };
            }
            catch (Exception ex)
            {
                _context.Rollback();
                return new ResponseModel { Message = ex.Message, Success = false };
            };

        }
    }
}
