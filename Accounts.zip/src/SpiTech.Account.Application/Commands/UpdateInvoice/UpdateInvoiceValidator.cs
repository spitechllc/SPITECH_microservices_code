﻿using FluentValidation;
using SpiTech.Account.Domain.Models;

namespace SpiTech.Account.Application.Commands.UpdateInvoice
{
    public class UpdateInvoiceValidator : AbstractValidator<UpdateInvoiceCommand>
    {
        public UpdateInvoiceValidator()
        {
            RuleFor(s => s.InvoiceNo).NotNull().NotEmpty().MaximumLength(50);
            RuleFor(s => s.SenderId).GreaterThan(0);
            RuleFor(s => s.ReceiverId).GreaterThan(0);
            RuleFor(s => s.Quantity).GreaterThan(0);
            RuleFor(s => s.NetAmount).GreaterThan(0);
            RuleFor(s => s.TotalAmount).GreaterThan(0);
            RuleFor(s => s.InvoiceDate).NotNull().NotEmpty();
            RuleFor(s => s.StatusId).GreaterThan(0);
            RuleFor(s => s.InvoiceDueDate).NotNull().NotEmpty();
            RuleFor(s => s.TaxType).NotNull().NotEmpty().MaximumLength(50);
            RuleFor(s => s.TaxCaption).NotNull().NotEmpty().MaximumLength(50);
            RuleFor(s => s.Remarks).MaximumLength(500);
            RuleFor(s => s.InteralRemarks).MaximumLength(500);
            RuleFor(s => s.ExternalRemarks).MaximumLength(500);
            RuleForEach(x => x.InvoiceItem).SetValidator(new InvoiceDetailModelValidator());
        }
    }
    public class InvoiceDetailModelValidator : AbstractValidator<InvoiceDetailModel>
    {
        public InvoiceDetailModelValidator()
        {
            RuleFor(x => x.SerialNo).GreaterThan(0).WithMessage("Serial No should be greater than 0");
            RuleFor(x => x.Description).NotEmpty().NotNull().MaximumLength(500);
            RuleFor(s => s.Quantity).GreaterThan(0);
            RuleFor(s => s.Amount).GreaterThan(0);

        }
    }
}
