﻿using AutoMapper;
using MediatR;
using SpiTech.Account.Application.UnitOfWorks;
using SpiTech.Account.Domain.Entities;
using SpiTech.Account.Domain.Enums;
using SpiTech.Account.Domain.Models;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Account;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Commands.AddNewInvoice
{
    public class AddNewInvoiceHandler : IRequestHandler<AddNewInvoiceCommand, FinalResultModel<int>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<AddNewInvoiceHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider _userAuthenticationProvider;
        public AddNewInvoiceHandler(IMediator mediator,
                                   IMapper mapper,
                                   IUnitOfWork context,
                                   ILogger<AddNewInvoiceHandler> logger,
                                   IEventDispatcher eventDispatcher,
                                   IUserAuthenticationProvider userAuthenticationProvider
            )
        {
            _mediator = mediator;
            _mapper = mapper;
            _context = context;
            _logger = logger;
            _eventDispatcher = eventDispatcher;
            _userAuthenticationProvider = userAuthenticationProvider;   

        }

        public async Task<FinalResultModel<int>> Handle(AddNewInvoiceCommand command, CancellationToken cancellationToken)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Handle), command);
                _userAuthenticationProvider.ValidateUserAccess(command.SenderId);
                FinalResultModel<int> finalresult = new();
                if (command != null)
                {
                    int invoiceId = await _context.Invoices.Add(new Invoice
                    {
                        InvoiceNo = command.InvoiceNo,
                        InvoiceDate = command.InvoiceDate,
                        InvoiceDueDate = command.InvoiceDueDate,
                        Quantity = command.Quantity,
                        NetAmount = command.NetAmount,
                        TaxType = command.TaxType,
                        TaxCaption = command.TaxCaption,
                        TaxValue = command.TaxValue,
                        TaxAmount = command.TaxAmount,
                        TotalAmount = command.TotalAmount,
                        ReceiverId = command.ReceiverId,
                        SenderId = command.SenderId,
                        Remarks = command.Remarks,
                        InteralRemarks = command.InteralRemarks,
                        ExternalRemarks = command.ExternalRemarks,
                        //StatusId = command.StatusId,
                        StatusId = (int)PaymentStatusEnum.Pending,
                        TemplateType = command.TemplateType,
                        IsActive = command.IsActive,
                        CreatedBy = command.SenderId,
                        CreatedOn = DateTime.UtcNow

                    });

                    List<SpiTech.EventBus.DomainEvents.Models.Account.InvoiceItems> items = new();

                    foreach (InvoiceDetailModel item in command.InvoiceItem)
                    {
                        await _context.InvoiceItems.Add(new InvoiceDetail
                        {
                            InvoiceId = invoiceId,
                            SerialNo = item.SerialNo,
                            Description = item.Description,
                            Quantity = item.Quantity,
                            Amount = item.Amount,
                        });

                        EventBus.DomainEvents.Models.Account.InvoiceItems list = new()
                        {
                            InvoiceId = invoiceId,
                            SerialNo = item.SerialNo,
                            Description = item.Description,
                            Quantity = item.Quantity,
                            Amount = item.Amount
                        };
                        items.Add(list);
                    }

                    InvoiceReceiveEvent invoceReceiveEvent = new()
                    {
                        Invoice = new SpiTech.EventBus.DomainEvents.Models.Account.Invoice
                        {
                            InvoiceId = invoiceId,
                            InvoiceNo = command.InvoiceNo,
                            InvoiceDate = command.InvoiceDate,
                            InvoiceDueDate = command.InvoiceDueDate,
                            Quantity = command.Quantity,
                            IsActive = command.IsActive,
                            NetAmount = command.NetAmount,
                            TaxType = command.TaxType,
                            TaxCaption = command.TaxCaption,
                            TaxValue = command.TaxValue,
                            TaxAmount = command.TaxAmount,
                            TotalAmount = command.TotalAmount,
                            ReceiverId = command.ReceiverId,
                            SenderId = command.SenderId,
                            StatusId = command.StatusId,
                            TemplateType = command.TemplateType,
                            invoiceItems = items,
                        }
                    };

                    _logger.TraceExitMethod(nameof(Handle), invoiceId);
                    _context.Commit();
                    await _eventDispatcher.Dispatch(invoceReceiveEvent);

                    finalresult = new FinalResultModel<int>
                    {
                        StatusCode = 200,
                        Message = "Record Saved Successfully",
                        Data = invoiceId
                    };

                    return finalresult;
                }

                finalresult.StatusCode = 500;
                finalresult.Message = "Invalid Data Please Enter Valid Data";
                finalresult.Data = 0;

                return finalresult;
            }
            catch (Exception ex)
            {
                _context.Rollback();
                FinalResultModel<int> finalresult = new()
                {
                    StatusCode = 500,
                    Message = ex.Message,
                    Data = 0
                };

                return finalresult;
            };
        }
    }
}
