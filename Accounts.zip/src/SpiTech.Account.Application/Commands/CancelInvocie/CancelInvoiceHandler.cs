﻿using AutoMapper;
using MediatR;
using SpiTech.Account.Application.Queries.GetInvoiceById;
using SpiTech.Account.Application.UnitOfWorks;
using SpiTech.Account.Domain.Enums;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Account;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Commands.CancelInvocie
{
    public class CancelInvoiceHandler : IRequestHandler<CancelInvoiceCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CancelInvoiceHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider _userAuthenticationProvider;
        public CancelInvoiceHandler(IMediator mediator,
                                   IMapper mapper,
                                   IUnitOfWork context,
                                   ILogger<CancelInvoiceHandler> logger,
                                   IEventDispatcher eventDispatcher,
                                   IUserAuthenticationProvider userAuthenticationProvider
            )
        {
            _mediator = mediator;
            _mapper = mapper;
            _context = context;
            _logger = logger;
            _eventDispatcher = eventDispatcher;
            _userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<ResponseModel> Handle(CancelInvoiceCommand command, CancellationToken cancellationToken)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Handle), command);
                ResponseModel result = new();
                Domain.Models.InvoiceModel invoicerec = await _mediator.Send(new GetInvoiceByIdQuery { InvoiceId = command.InvoiceId });
                _userAuthenticationProvider.ValidateUserAccess(invoicerec.SenderId);
                if (invoicerec.StatusId == (int)PaymentStatusEnum.Pending)
                {
                    result = await _context.Invoices.CancelInvoice(command.InvoiceId, command.Remarks);
                    _context.Commit();
                    List<SpiTech.EventBus.DomainEvents.Models.Account.InvoiceItems> items = new();
                    Domain.Models.InvoiceModel invoice = await _mediator.Send(new GetInvoiceByIdQuery { InvoiceId = command.InvoiceId });

                    foreach (Domain.Models.InvoiceDetailModel item in invoice.InvoiceItem)
                    {
                        EventBus.DomainEvents.Models.Account.InvoiceItems list = new()
                        {
                            InvoiceId = invoice.InvoiceId,
                            SerialNo = item.SerialNo,
                            Description = item.Description,
                            Quantity = item.Quantity,
                            Amount = item.Amount
                        };
                        items.Add(list);
                    }

                    InvoiceCancelledEvent invoiceCancelledEvent = new()
                    {
                        Invoice = new SpiTech.EventBus.DomainEvents.Models.Account.Invoice
                        {
                            InvoiceId = invoice.InvoiceId,
                            InvoiceNo = invoice.InvoiceNo,
                            InvoiceDate = invoice.InvoiceDate,
                            InvoiceDueDate = invoice.InvoiceDueDate,
                            Quantity = invoice.Quantity,
                            IsActive = invoice.IsActive,
                            NetAmount = invoice.NetAmount,
                            TaxType = invoice.TaxType,
                            TaxCaption = invoice.TaxCaption,
                            TaxValue = invoice.TaxValue,
                            TaxAmount = invoice.TaxAmount,
                            TotalAmount = invoice.TotalAmount,
                            ReceiverId = invoice.ReceiverId,
                            SenderId = invoice.SenderId,
                            StatusId = invoice.StatusId,
                            Remarks = invoice.Remarks,
                            InteralRemarks = invoice.InteralRemarks,
                            ExternalRemarks = invoice.ExternalRemarks,
                            invoiceItems = items
                        }
                    };

                    await _eventDispatcher.Dispatch(invoiceCancelledEvent);
                    _logger.TraceExitMethod(nameof(Handle), result);
                    return result;
                }
                else
                {
                    return new ResponseModel { Success = false, Message = "Invoice Already " + invoicerec.Status.Status + "" };
                }
            }
            catch (Exception)
            {
                _context.Rollback(); throw;
            }
        }
    }
}
