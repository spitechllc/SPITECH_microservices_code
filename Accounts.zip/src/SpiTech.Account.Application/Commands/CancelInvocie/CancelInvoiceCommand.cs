﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Account.Application.Commands.CancelInvocie
{
    public class CancelInvoiceCommand : IRequest<ResponseModel>
    {
        public int InvoiceId { get; set; }
        public string Remarks { get; set; }
    }
}
