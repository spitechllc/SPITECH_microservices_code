﻿using AutoMapper;
using MediatR;
using SpiTech.Account.Application.UnitOfWorks;
using SpiTech.Application.Logging.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Commands.UpdateUser
{
    public class UpdateUserHandler : IRequestHandler<UpdateUserCommand, bool>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateUserHandler> _logger;
        private readonly IMapper _mapper;
        public UpdateUserHandler(IUnitOfWork context,
                                             ILogger<UpdateUserHandler> logger,
                                             IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<bool> Handle(UpdateUserCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            bool result = false;

            await _context.Execute(async () =>
            {
                result = await _context.Users.Update(new Domain.Entities.User()
                {
                    UserId = command.UserId,
                    UserTypeId = command.UserTypeId,
                    FirstName = command.FirstName,
                    LastName = command.LastName,
                    Email = command.Email,
                    MobileCountryCode = command.MobileCountryCode,
                    MobileNumber = command.MobileNumber,
                    PhotoUrl = command.PhotoUrl,
                    AddressLine1 = command.AddressLine1,
                    AddressLine2 = command.AddressLine2,
                    EnrolledBusinessUser = command.EnrolledBusinessUser,
                    BusinessName = command.BusinessName,
                    BusinessAccountNumber = command.BusinessAccountNumber,
                    Country = command.Country,
                    CountryCode = command.CountryCode,
                    State = command.State,
                    City = command.City,
                    ZipCode = command.ZipCode,
                    UpdatedOn = DateTime.UtcNow,
                    UpdatedBy = 1,
                    IsActive = command.IsActive
                });
            });

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
