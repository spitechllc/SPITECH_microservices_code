﻿using FluentValidation;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.Account.Application.EventConsumers;
using SpiTech.Account.Domain.Mappers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Account;
using SpiTech.EventBus.DomainEvents.Events.Identity;
using SpiTech.EventBus.DomainEvents.ServiceCollection;
using System.Reflection;

namespace SpiTech.Account.Application
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services, IConfiguration configuration)
        {
            services
                .AddMediatR(Assembly.GetExecutingAssembly()).AddAutoMapper(typeof(InvoiceProfile))
                .AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());

            services.RegisterMessageQueue(configuration, config =>
            {
                config.AddConsumer<IdentityConsumer>();

            }, (ctx, cfg) =>
            {
                cfg.ConfigurePublishEvent<InvoiceReceiveEvent>();
                cfg.ConfigurePublishEvent<InvoiceCancelledEvent>();
                cfg.ConfigurePublishEvent<InvoiceRejectedEvent>();
                cfg.ConfigurePublishEvent<InvoicePaidEvent>();

                cfg.BindConsumer<IdentityUserCreatedEvent, IdentityConsumer>(ctx, EventBusConstants.AccountService);
                cfg.BindConsumer<IdentityUserUpdatedEvent, IdentityConsumer>(ctx, EventBusConstants.AccountService);

            });
            return services;
        }
    }
}