﻿using AutoMapper;
using MediatR;
using SpiTech.Account.Application.UnitOfWorks;
using SpiTech.Account.Domain.Models;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Queries.GetRecentInvoicesById
{
    public class GetRecentInvoicesByIdHandler : IRequestHandler<GetRecentInvoicesByIdQuery, FinalResultListModel<InvoiceModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetRecentInvoicesByIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider _userAuthenticationProvider;
        public GetRecentInvoicesByIdHandler(IUnitOfWork context,
                                 ILogger<GetRecentInvoicesByIdHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper,
                                 IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _userAuthenticationProvider=userAuthenticationProvider;
        }

        public async Task<FinalResultListModel<InvoiceModel>> Handle(GetRecentInvoicesByIdQuery request, CancellationToken cancellationToken)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Handle), request);
                _userAuthenticationProvider.ValidateUserAccess(request.UserId);
                int totalRecord = 0;

                IEnumerable<InvoiceModel> invoiceList = _mapper.Map<IEnumerable<InvoiceModel>>(await _context.Invoices.GetRecentInvoices_ById
                    (request.UserId, request.IsReceiver));
                if (invoiceList != null && invoiceList.Count() > 0)
                {
                    IEnumerable<int> senderlist = invoiceList.Select(x => x.SenderId).Distinct();
                    IEnumerable<int> Recvlist = invoiceList.Select(x => x.ReceiverId).Distinct();
                    IEnumerable<int> newlist = senderlist.Concat(Recvlist).Distinct();
                    List<UsersModel> UserDetails = await _context.Users.GetUserIds(newlist.ToList());

                    IEnumerable<Domain.Entities.InvoiceDetail> itemsresult = await _context.InvoiceItems.GetByInvoiceItemsListByIds(invoiceList.Select(x => x.InvoiceId));
                    IEnumerable<Domain.Entities.PaymentStatus> Inv_status = await _context.Invoices.GetPaymentStatusList();

                    foreach (InvoiceModel Invoice in invoiceList)
                    {
                        totalRecord = Invoice.TotalRecord;

                        IEnumerable<Domain.Entities.InvoiceDetail> items = itemsresult.Where(x => x.InvoiceId == Invoice.InvoiceId);
                        IEnumerable<InvoiceDetailModel> itemModel = _mapper.Map<IEnumerable<InvoiceDetailModel>>(items);
                        Invoice.InvoiceItem = itemModel;
                        Invoice.Status = _mapper.Map<PaymentStatusModel>(Inv_status.Where(x => x.StatusId == Invoice.StatusId).FirstOrDefault());
                        UsersModel sender = UserDetails.Where(x => x.UserId == Invoice.SenderId).FirstOrDefault();
                        if (sender != null)
                        {
                            Invoice.SenderData = _mapper.Map<UsersModel>(sender);

                        }
                        UsersModel receiver = UserDetails.Where(x => x.UserId == Invoice.ReceiverId).FirstOrDefault();

                        if (receiver != null)
                        {
                            Invoice.ReceiverData = _mapper.Map<UsersModel>(receiver);
                        }
                    }

                }
                FinalResultListModel<InvoiceModel> finalresult = new()
                {
                    StatusCode = 200,
                    Message = "Success",
                    Data = invoiceList
                };


                _logger.TraceExitMethod(nameof(Handle), finalresult);
                return finalresult;
            }
            catch (Exception ex)
            {
                FinalResultListModel<InvoiceModel> finalresult = new()
                {
                    StatusCode = 500,
                    Message = ex.Message,
                    Data = null
                };
                return finalresult;
            };
        }
    }
}
