﻿using MediatR;
using SpiTech.Account.Domain.Models;

namespace SpiTech.Account.Application.Queries.GetRecentInvoicesById
{
    public class GetRecentInvoicesByIdQuery : IRequest<FinalResultListModel<InvoiceModel>>
    {
        public int UserId { get; set; }
        public bool IsReceiver { get; set; }
    }
}
