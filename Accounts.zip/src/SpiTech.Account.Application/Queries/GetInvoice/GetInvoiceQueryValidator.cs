﻿using FluentValidation;

namespace SpiTech.Account.Application.Queries.GetInvoice
{
    public class GetInvoiceQueryValidator : AbstractValidator<GetInvoiceQuery>
    {
        public GetInvoiceQueryValidator()
        {
            RuleFor(s => s.InvoiceNo).NotEmpty();
            RuleFor(s => s.UserId).GreaterThan(0);

        }
    }
}
