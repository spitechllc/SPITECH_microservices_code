﻿using MediatR;
using SpiTech.Account.Domain.Models;

namespace SpiTech.Account.Application.Queries.GetInvoice
{

    public class GetInvoiceQuery : IRequest<FinalResultModel<InvoiceModel>>
    {
        public string InvoiceNo { get; set; }
        public int UserId { get; set; }
        public bool IsReceiver { get; set; }
    }
}
