﻿using AutoMapper;
using MediatR;
using SpiTech.Account.Application.UnitOfWorks;
using SpiTech.Account.Domain.Models;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.Service.Clients.Execeptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Queries.GetInvoice
{
    public class GetInvoiceHandler : IRequestHandler<GetInvoiceQuery, FinalResultModel<InvoiceModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetInvoiceHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider _userAuthenticationProvider;

        public GetInvoiceHandler(IUnitOfWork context,
                                    ILogger<GetInvoiceHandler> logger,
                                    IMapper mapper,
                                    IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _userAuthenticationProvider=userAuthenticationProvider;
        }

        public async Task<FinalResultModel<InvoiceModel>> Handle(GetInvoiceQuery request, CancellationToken cancellationToken)
        {
            FinalResultModel<InvoiceModel> finalresult = new();

            try
            {
                _logger.TraceEnterMethod(nameof(Handle), request);
                //_userAuthenticationProvider.ValidateUserAccess(request.UserId);
                Domain.Entities.Invoice result = await _context.Invoices.GetByInvoiceNo(request.InvoiceNo, request.UserId, request.IsReceiver);

                if (result != null)
                {
                    IEnumerable<Domain.Entities.InvoiceDetail> itemsresult = await _context.InvoiceItems.GetByInvoiceItemsById(result.InvoiceId);
                    IEnumerable<InvoiceDetailModel> itemModel = _mapper.Map<IEnumerable<InvoiceDetailModel>>(itemsresult);
                    _logger.TraceExitMethod(nameof(Handle), result);
                    InvoiceModel fresult = _mapper.Map<InvoiceModel>(result);
                    Domain.Entities.PaymentStatus Inv_status = await _context.Invoices.GetInvoicePaymentStatus(result.StatusId);
                    fresult.Status = _mapper.Map<PaymentStatusModel>(Inv_status);
                    fresult.InvoiceItem = itemModel;

                    List<int> users = new()
                    {
                        result.SenderId,
                        result.ReceiverId
                    };

                    List<UsersModel> UserDetails = await _context.Users.GetUserIds(users);

                    UsersModel senderDtails = UserDetails.Where(x => x.UserId == result.SenderId).FirstOrDefault();
                    if (senderDtails != null)
                    {
                        fresult.SenderData = _mapper.Map<UsersModel>(senderDtails);

                    }
                    UsersModel receiverDetails = UserDetails.Where(x => x.UserId == result.ReceiverId).FirstOrDefault();
                    if (receiverDetails != null)
                    {
                        fresult.ReceiverData = _mapper.Map<UsersModel>(receiverDetails);

                    }



                    finalresult.StatusCode = 200;
                    finalresult.Message = "Record Found";
                    finalresult.Data = fresult;

                    return finalresult;
                }
                finalresult.StatusCode = 200;
                finalresult.Message = "Record Not Found";
                finalresult.Data = null;

                return finalresult;
            }
            catch (ApiException ex)
            {
                finalresult.StatusCode = ex.StatusCode;
                finalresult.Message = ex.Message;
                finalresult.Data = null;

                return finalresult;
            }
            catch (Exception ex)
            {
                finalresult.StatusCode = 500;
                finalresult.Message = ex.Message;
                finalresult.Data = null;

                return finalresult;
            };
        }


    }
}
