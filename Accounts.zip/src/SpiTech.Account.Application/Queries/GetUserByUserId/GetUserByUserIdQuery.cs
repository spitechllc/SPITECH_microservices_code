﻿using MediatR;
using SpiTech.Account.Domain.Entities;

namespace SpiTech.Account.Application.Queries.GetUserByUserId
{
    public class GetUserByUserIdQuery : IRequest<User>
    {
        public int UserId { get; set; }
    }
}
