﻿using AutoMapper;
using MediatR;
using SpiTech.Account.Application.UnitOfWorks;
using SpiTech.Application.Logging.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Queries.GetUserByUserId
{
    public class GetUserByUserIdHandler : IRequestHandler<GetUserByUserIdQuery, Domain.Entities.User>
    {

        private readonly IMediator _mediater;
        private readonly ILogger<GetUserByUserIdHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        public GetUserByUserIdHandler(IMediator mediater,
                                    ILogger<GetUserByUserIdHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper)
        {
            _mediater = mediater;
            _logger = logger;
            _context = context;
            _mapper = mapper;
        }

        public async Task<Domain.Entities.User> Handle(GetUserByUserIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            Domain.Entities.User result = await _context.Users.Get(request.UserId);

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
