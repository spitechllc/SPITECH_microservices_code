﻿using AutoMapper;
using MediatR;
using SpiTech.Account.Application.UnitOfWorks;
using SpiTech.Account.Domain.Models;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.Service.Clients.Execeptions;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Queries.GenerateInvoiceNo
{
    public class GenerateInvoiceNoHandler : IRequestHandler<GenerateInvoiceNoQuery, FinalResultModel<NewInvocieNoModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GenerateInvoiceNoHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider _userAuthenticationProvider;
        public GenerateInvoiceNoHandler(IUnitOfWork context,
                                    ILogger<GenerateInvoiceNoHandler> logger,
                                    IMapper mapper,
                                    IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<FinalResultModel<NewInvocieNoModel>> Handle(GenerateInvoiceNoQuery request, CancellationToken cancellationToken)
        {
            FinalResultModel<NewInvocieNoModel> finalresult = new();

            try
            {
                _logger.TraceEnterMethod(nameof(Handle), request);
                _userAuthenticationProvider.ValidateUserAccess(request.userid);
                NewInvocieNoModel result = await _context.Invoices.GenerateInvoiceNo(request.userid);
                finalresult.StatusCode = 200;
                finalresult.Message = "Success";
                finalresult.Data = result;

                return finalresult;
            }
            catch (ApiException ex)
            {
                finalresult.StatusCode = ex.StatusCode;
                finalresult.Message = ex.Message;
                finalresult.Data = null;

                return finalresult;
            }
            catch (Exception ex)
            {
                finalresult.StatusCode = 500;
                finalresult.Message = ex.Message;
                finalresult.Data = null;

                return finalresult;
            };
        }
    }
}
