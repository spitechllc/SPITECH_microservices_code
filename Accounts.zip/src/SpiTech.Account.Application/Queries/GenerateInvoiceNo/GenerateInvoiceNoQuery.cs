﻿using MediatR;
using SpiTech.Account.Domain.Models;

namespace SpiTech.Account.Application.Queries.GenerateInvoiceNo
{
    public class GenerateInvoiceNoQuery : IRequest<FinalResultModel<NewInvocieNoModel>>
    {
        public int userid { get; set; }

    }
}
