﻿using MediatR;
using SpiTech.Account.Domain.Models;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;

namespace SpiTech.Account.Application.Queries.GetTodaysInvoiceWithPaging
{
    public class GetTodaysInvoiceWithPagingQuery : IRequest<PaginatedList<InvoiceModel>>
    {
        public int UserId { get; set; }
        public bool IsReceiver { get; set; }
        public int Status { get; set; }
        public int? PageIndex { get; set; }
        public int? PageSize { get; set; }
        public Sortable sortable { get; set; }
    }
}
