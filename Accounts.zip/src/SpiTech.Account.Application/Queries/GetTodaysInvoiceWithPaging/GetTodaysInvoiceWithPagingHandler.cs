﻿using AutoMapper;
using MediatR;
using SpiTech.Account.Application.UnitOfWorks;
using SpiTech.Account.Domain.Models;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Pagination;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Queries.GetTodaysInvoiceWithPaging
{
    public class GetTodaysInvoiceWithPagingHandler : IRequestHandler<GetTodaysInvoiceWithPagingQuery, PaginatedList<InvoiceModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetTodaysInvoiceWithPagingHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider _userAuthenticationProvider;

        public GetTodaysInvoiceWithPagingHandler(IUnitOfWork context,
                                 ILogger<GetTodaysInvoiceWithPagingHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper,
                                 IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<PaginatedList<InvoiceModel>> Handle(GetTodaysInvoiceWithPagingQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            _userAuthenticationProvider.ValidateUserAccess(request.UserId);
            int totalRecord = 0;

            List<InvoiceModel> invoiceList = _mapper.Map<List<InvoiceModel>>(await _context.Invoices.GetTodaysInvoiceListWithPaging
                (request.UserId, request.IsReceiver, request.Status, request.PageIndex, request.PageSize,
                request.sortable?.SortBy, request.sortable?.SortOrder));

            if (invoiceList != null && invoiceList.Count() > 0)
            {
                totalRecord = invoiceList.Select(x => x.TotalRecord).FirstOrDefault();

                IEnumerable<int> senderlist = invoiceList.Select(x => x.SenderId).Distinct();
                IEnumerable<int> Recvlist = invoiceList.Select(x => x.ReceiverId).Distinct();
                IEnumerable<int> newlist = senderlist.Concat(Recvlist).Distinct();
                List<UsersModel> UserDetails = await _context.Users.GetUserIds(newlist.ToList());
                IEnumerable<Domain.Entities.InvoiceDetail> itemsresult = await _context.InvoiceItems.GetByInvoiceItemsListByIds(invoiceList.Select(x => x.InvoiceId));
                IEnumerable<Domain.Entities.PaymentStatus> Inv_status = await _context.Invoices.GetPaymentStatusList();

                foreach (InvoiceModel Invoice in invoiceList)
                {
                    totalRecord = Invoice.TotalRecord;

                    IEnumerable<Domain.Entities.InvoiceDetail> items = itemsresult.Where(x => x.InvoiceId == Invoice.InvoiceId);
                    IEnumerable<InvoiceDetailModel> itemModel = _mapper.Map<IEnumerable<InvoiceDetailModel>>(items);
                    Invoice.InvoiceItem = itemModel;
                    Invoice.Status = _mapper.Map<PaymentStatusModel>(Inv_status.Where(x => x.StatusId == Invoice.StatusId).FirstOrDefault());
                    UsersModel sender = UserDetails.Where(x => x.UserId == Invoice.SenderId).FirstOrDefault();
                    if (sender != null)
                    {
                        Invoice.SenderData = _mapper.Map<UsersModel>(sender);

                    }
                    UsersModel receiver = UserDetails.Where(x => x.UserId == Invoice.ReceiverId).FirstOrDefault();

                    if (receiver != null)
                    {
                        Invoice.ReceiverData = _mapper.Map<UsersModel>(receiver);
                    }
                }
            }
            _logger.TraceExitMethod(nameof(Handle), invoiceList);


            return new PaginatedList<InvoiceModel>
            {
                Data = invoiceList,
                PageIndex = request.PageIndex ?? 0,
                PageSize = request.PageSize ?? 0,
                TotalCount = totalRecord
            };
        }
    }
}
