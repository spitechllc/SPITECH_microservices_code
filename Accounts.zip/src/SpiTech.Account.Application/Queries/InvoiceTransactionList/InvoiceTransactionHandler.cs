﻿using AutoMapper;
using MediatR;
using SpiTech.Account.Application.UnitOfWorks;
using SpiTech.Account.Domain.Models;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Pagination;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Queries.InvoiceTransactionList
{
    public class InvoiceTransactionHandler : IRequestHandler<InvoiceTransactionQuery, PaginatedList<InvoiceTransactionSearch>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<InvoiceTransactionHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider _userAuthenticationProvider;
        public InvoiceTransactionHandler(IUnitOfWork context,
                                 ILogger<InvoiceTransactionHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper,
                                 IUserAuthenticationProvider userAuthenticationProvider

                                  )
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<PaginatedList<InvoiceTransactionSearch>> Handle(InvoiceTransactionQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            _userAuthenticationProvider.ValidateUserAccess(request.UserId);
            List<InvoiceTransactionSearch> result = await _context.TransactionRepository.GetInvoiceTransactionByFilter(request.UserId, request.NameEmailMobile, request.IsPaymentSuccess, request.PageIndex, request.PageSize, request.sortable);
            int totalRecord = result.Select(x => x.TotalRecord).FirstOrDefault();
            _logger.TraceExitMethod(nameof(Handle), result);
            return new PaginatedList<InvoiceTransactionSearch>
            {
                Data = result,
                PageIndex = request.PageIndex ?? 0,
                PageSize = request.PageSize ?? 0,
                TotalCount = totalRecord
            };
        }
    }
}
