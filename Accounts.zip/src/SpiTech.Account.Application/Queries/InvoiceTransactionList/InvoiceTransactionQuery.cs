﻿using MediatR;
using SpiTech.Account.Domain.Models;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;

namespace SpiTech.Account.Application.Queries.InvoiceTransactionList
{
    public class InvoiceTransactionQuery : IRequest<PaginatedList<InvoiceTransactionSearch>>
    {
        public int UserId { get; set; }
        public string NameEmailMobile { get; set; }
        // public int TranasactionId { get; set; }
        public int IsPaymentSuccess { get; set; }
        public int? PageIndex { get; set; }
        public int? PageSize { get; set; }
        public Sortable sortable { get; set; }

    }
}
