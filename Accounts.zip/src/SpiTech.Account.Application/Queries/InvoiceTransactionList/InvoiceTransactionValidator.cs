﻿using FluentValidation;

namespace SpiTech.Account.Application.Queries.InvoiceTransactionList
{
    public class InvoiceTransactionValidator : AbstractValidator<InvoiceTransactionQuery>
    {
        public InvoiceTransactionValidator()
        {
            RuleFor(s => s.UserId).GreaterThan(0);

        }
    }
}
