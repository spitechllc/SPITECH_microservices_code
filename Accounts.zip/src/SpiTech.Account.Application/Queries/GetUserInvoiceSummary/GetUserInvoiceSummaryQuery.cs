﻿using MediatR;
using SpiTech.Account.Domain.Models;
using SpiTech.ApplicationCore.Domain.Models;
using System;

namespace SpiTech.Account.Application.Queries.GetUserInvoiceSummary
{
    public class GetUserInvoiceSummaryQuery : IRequest<ResponseModel<UserInvoiceDetailModel>>
    {
        public int UserId { get; set; }
        public bool IsReceiver { get; set; }
        public DateTime FromDate { get; set; } = DateTime.UtcNow.Date.AddDays(-7);
        public DateTime ToDate { get; set; } = DateTime.UtcNow.Date;
    }
}
