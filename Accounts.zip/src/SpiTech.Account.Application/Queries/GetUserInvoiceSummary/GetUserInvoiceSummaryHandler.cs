﻿using AutoMapper;
using MediatR;
using SpiTech.Account.Application.UnitOfWorks;
using SpiTech.Account.Domain.Models;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Queries.GetUserInvoiceSummary
{
    public class GetUserInvoiceSummaryHandler : IRequestHandler<GetUserInvoiceSummaryQuery, ResponseModel<UserInvoiceDetailModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetUserInvoiceSummaryHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider _userAuthenticationProvider;
        public GetUserInvoiceSummaryHandler(IUnitOfWork context,
                                 ILogger<GetUserInvoiceSummaryHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper,
                                 IUserAuthenticationProvider userAuthenticationProvider

                                  )
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<ResponseModel<UserInvoiceDetailModel>> Handle(GetUserInvoiceSummaryQuery request, CancellationToken cancellationToken)
        {
            ResponseModel<UserInvoiceDetailModel> finalresult = new();

            try
            {
                _logger.TraceEnterMethod(nameof(Handle), request);
                _userAuthenticationProvider.ValidateUserAccess(request.UserId);
                UserInvoiceDetailModel SenddrData = await _context.Invoices.UsersInvoiceDetails(request);
                UserInvoiceDetailModel result = _mapper.Map<UserInvoiceDetailModel>(SenddrData);
                finalresult.Success = true;
                finalresult.Message = "Record Found";
                finalresult.Data = result;

                _logger.TraceExitMethod(nameof(Handle), finalresult);
                return finalresult;
            }
            catch (Exception ex)
            {
                finalresult.Success = false;
                finalresult.Message = ex.Message;
                finalresult.Data = null;
                return finalresult;
            };
        }
    }
}
