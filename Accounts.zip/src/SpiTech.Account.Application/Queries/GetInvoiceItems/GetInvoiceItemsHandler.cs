﻿using AutoMapper;
using MediatR;
using SpiTech.Account.Application.UnitOfWorks;
using SpiTech.Account.Domain.Entities;
using SpiTech.Account.Domain.Models;
using SpiTech.Application.Logging.Interfaces;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Queries.GetInvoiceItems
{
    public class GetInvoiceItemsHandler : IRequestHandler<GetInvoiceItemsQuery, InvoiceDetailModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetInvoiceItemsHandler> _logger;
        private readonly IMapper _mapper;
        public GetInvoiceItemsHandler(IUnitOfWork context,
                                    ILogger<GetInvoiceItemsHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<InvoiceDetailModel> Handle(GetInvoiceItemsQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<InvoiceDetail> result = await _context.InvoiceItems.GetByInvoiceItemsById(request.InvoiceId);
            _logger.TraceExitMethod(nameof(Handle), result);
            return _mapper.Map<InvoiceDetailModel>(result);
        }
    }
}
