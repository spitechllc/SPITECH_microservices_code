﻿using MediatR;
using SpiTech.Account.Domain.Models;

namespace SpiTech.Account.Application.Queries.GetInvoiceItems
{
    public class GetInvoiceItemsQuery : IRequest<InvoiceDetailModel>
    {
        public int InvoiceId { get; set; }
    }
}
