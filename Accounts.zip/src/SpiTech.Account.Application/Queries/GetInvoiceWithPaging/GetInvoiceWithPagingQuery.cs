﻿using MediatR;
using SpiTech.Account.Domain.Models;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;

namespace SpiTech.Account.Application.Queries.GetInvoiceWithPaging
{
    public class GetInvoiceWithPagingQuery : IRequest<PaginatedList<InvoiceModel>>
    {
        public int UserId { get; set; }
        public bool IsReceiver { get; set; }
        public int Status { get; set; }
        public string? NameEmailorMobile { get; set; }
        public int? PageIndex { get; set; }
        public int? PageSize { get; set; }
        // public Paginable paginable { get; set; }
        public Sortable sortable { get; set; }
    }
}
