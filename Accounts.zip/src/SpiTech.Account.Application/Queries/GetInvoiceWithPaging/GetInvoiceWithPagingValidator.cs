﻿using FluentValidation;

namespace SpiTech.Account.Application.Queries.GetInvoiceWithPaging
{
    public class GetInvoiceWithPagingValidator : AbstractValidator<GetInvoiceWithPagingQuery>
    {
        public GetInvoiceWithPagingValidator()
        {
            RuleFor(s => s.UserId).GreaterThan(0);
            RuleFor(s => s.IsReceiver).NotNull();
        }
    }
}
