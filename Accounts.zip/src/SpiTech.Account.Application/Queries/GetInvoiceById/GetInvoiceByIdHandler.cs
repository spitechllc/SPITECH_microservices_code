﻿using AutoMapper;
using MediatR;
using SpiTech.Account.Application.UnitOfWorks;
using SpiTech.Account.Domain.Models;
using SpiTech.Application.Logging.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Queries.GetInvoiceById
{
    public class GetInvoiceByIdHandler : IRequestHandler<GetInvoiceByIdQuery, InvoiceModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetInvoiceByIdHandler> _logger;
        private readonly IMapper _mapper;
        public GetInvoiceByIdHandler(IUnitOfWork context,
                                    ILogger<GetInvoiceByIdHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }


        public async Task<InvoiceModel> Handle(GetInvoiceByIdQuery request, CancellationToken cancellationToken)
        {
            Domain.Entities.Invoice result = await _context.Invoices.GetByInvoiceById(request.InvoiceId);
            InvoiceModel fresult = _mapper.Map<InvoiceModel>(result);
            IEnumerable<Domain.Entities.InvoiceDetail> itemsresult = await _context.InvoiceItems.GetByInvoiceItemsById(result.InvoiceId);
            IEnumerable<InvoiceDetailModel> itemModel = _mapper.Map<IEnumerable<InvoiceDetailModel>>(itemsresult);

            Domain.Entities.PaymentStatus Inv_status = await _context.Invoices.GetInvoicePaymentStatus(result.StatusId);
            fresult.Status = _mapper.Map<PaymentStatusModel>(Inv_status);
            fresult.InvoiceItem = itemModel;
            List<int> users = new()
            {
                result.SenderId,
                result.ReceiverId
            };

            List<UsersModel> UserDetails = await _context.Users.GetUserIds(users);

            UsersModel senderDtails = UserDetails.Where(x => x.UserId == result.SenderId).FirstOrDefault();
            if (senderDtails != null)
            {
                fresult.SenderData = _mapper.Map<UsersModel>(senderDtails);

            }
            UsersModel receiverDetails = UserDetails.Where(x => x.UserId == result.ReceiverId).FirstOrDefault();
            if (receiverDetails != null)
            {
                fresult.ReceiverData = _mapper.Map<UsersModel>(receiverDetails);

            }
            return fresult;
        }
    }
}
