﻿using MediatR;
using SpiTech.Account.Domain.Models;

namespace SpiTech.Account.Application.Queries.GetInvoiceById
{

    public class GetInvoiceByIdQuery : IRequest<InvoiceModel>
    {
        public int InvoiceId { get; set; }
    }
}
