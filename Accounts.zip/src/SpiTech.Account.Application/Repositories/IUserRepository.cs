﻿using SpiTech.Account.Domain.Entities;
using SpiTech.Account.Domain.Models;
using SpiTech.ApplicationCore.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Repositories
{
    public interface IUserRepository : IRepository<User>
    {
        Task<List<UsersModel>> GetUserIds(List<int> InvoiceId);

        Task<UsersModel> GetUserByEmailOrPhoneAsync(string NameEmailorMobile);

        Task<List<UsersModel>> GetUsersByNameAsync(string Name);
    }
}
