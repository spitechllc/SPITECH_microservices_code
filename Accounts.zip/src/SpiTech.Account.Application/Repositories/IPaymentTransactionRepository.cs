﻿using SpiTech.Account.Domain.Entities;
using SpiTech.ApplicationCore.Repositories;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Repositories
{
    public interface IPaymentTransactionRepository : IRepository<Transaction>
    {
        Task<Transaction> GetByTransactionById(int TransactionId);
    }

}
