﻿using SpiTech.Account.Application.Queries.GetUserInvoiceSummary;
using SpiTech.Account.Domain.Entities;
using SpiTech.Account.Domain.Models;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Repositories
{
    public interface IInvoiceRepository : IRepository<Invoice>
    {
        Task<IEnumerable<Invoice>> GetRecentInvoices_ById(int userId, bool IsReceiver);
        Task<Invoice> GetByInvoiceNo(string InvoiceNo, int UserId, bool IsReceiver);
        Task<Invoice> GetByInvoiceById(int InvoiceId);
        Task<NewInvocieNoModel> GenerateInvoiceNo(int userId);
        Task<List<InvoiceModel>> GetInvoiceListWithPaging(int UserId, bool IsReceiver, int Status, int[] filter, int? Skip, int? Take, string SortBy, string SortOrder);
        Task<PaymentStatus> GetInvoicePaymentStatus(int StatusId);
        Task<IEnumerable<PaymentStatus>> GetPaymentStatusList();
        Task<ResponseModel> DeclineInvoice(int InvoiceId, string Remarks);
        Task<ResponseModel> CancelInvoice(int InvoiceId, string Remarks);
        Task<ResponseModel> PaymentInvoice(int InvoiceId, string Remarks);
        Task<UserInvoiceDetailModel> UsersInvoiceDetails(GetUserInvoiceSummaryQuery filter);

        Task<List<InvoiceModel>> GetTodaysInvoiceListWithPaging(int UserId, bool IsReceiver, int Status, int? Skip, int? Take, string SortBy, string SortOrder);

        //Task<List<InvoiceMainModel>> GetPaidInvoiceWithPaging(int UserId, bool IsReceiver, int? Skip, int? Take, string SortBy, string SortOrder);
        //Task<List<InvoiceMainModel>> GetRejectedInvoiceWithPaging(int UserId, bool IsReceiver, int? Skip, int? Take, string SortBy, string SortOrder);
    }
}
