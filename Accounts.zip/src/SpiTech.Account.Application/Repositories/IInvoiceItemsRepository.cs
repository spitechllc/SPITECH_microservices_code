﻿using SpiTech.Account.Domain.Entities;
using SpiTech.ApplicationCore.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Repositories
{
    public interface IInvoiceItemsRepository : IRepository<InvoiceDetail>
    {
        Task<IEnumerable<InvoiceDetail>> GetByInvoiceItemsById(int InvoiceNo);
        Task<IEnumerable<InvoiceDetail>> GetByInvoiceItemsListByIds(IEnumerable<int> InvoiceIds);
    }
}
