﻿using SpiTech.Account.Domain.Entities;
using SpiTech.Account.Domain.Models;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.Repositories
{
    public interface ITransactionRepository : IRepository<Transaction>
    {
        Task<List<InvoiceTransactionSearch>> GetInvoiceTransactionByFilter(int userid, string NameEmailMobile, int IsPaymentSuccess, int? PageIndex, int? PageSize, Sortable sortable);
    }
}
