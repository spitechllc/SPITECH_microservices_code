﻿using MassTransit;
using MediatR;
using SpiTech.Account.Application.Commands.CreateUser;
using SpiTech.Account.Application.Commands.UpdateUser;
using SpiTech.Account.Application.Queries.GetUserByUserId;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Identity;
using System;
using System.Threading.Tasks;

namespace SpiTech.Account.Application.EventConsumers
{
    public class IdentityConsumer : IConsumer<IdentityUserCreatedEvent>
                                    , IConsumer<IdentityUserUpdatedEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<IdentityConsumer> _logger;

        public IdentityConsumer(IMediator mediator, ILogger<IdentityConsumer> logger)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task Consume(ConsumeContext<IdentityUserCreatedEvent> context)
        {
            _logger.TraceEnterMethod(nameof(Consume), context);

            await SaveUser(context.Message);

            _logger.Info($"IdentityUserCreatedEvent consumed successfully. UserId : {context.Message.UserId}");
        }

        public async Task Consume(ConsumeContext<IdentityUserUpdatedEvent> context)
        {
            await SaveUser(context.Message);
            _logger.Info($"IdentityUserUpdatedEvent consumed successfully. UserId : {context.Message.UserId}");
        }

        private async Task SaveUser(IdentityBaseEvent identityBaseEvent)
        {
            Domain.Entities.User user = await _mediator.Send(new GetUserByUserIdQuery { UserId = identityBaseEvent.UserId });

            if (user == null)
            {
                await _mediator.Send(new CreateUserCommand
                {
                    Email = identityBaseEvent.Email,
                    FirstName = identityBaseEvent.FirstName,
                    LastName = identityBaseEvent.LastName,
                    MobileCountryCode = identityBaseEvent.MobileCountryCode,
                    MobileNumber = identityBaseEvent.MobileNumber,
                    UserId = identityBaseEvent.UserId,
                    UserTypeId = identityBaseEvent.UserTypeId,
                    AddressLine1 = identityBaseEvent.UserProfile?.AddressLine1,
                    AddressLine2 = identityBaseEvent.UserProfile?.AddressLine2,
                    City = identityBaseEvent.UserProfile?.City,
                    State = identityBaseEvent.UserProfile?.State,
                    Country = identityBaseEvent.UserProfile?.Country,
                    CountryCode = identityBaseEvent.UserProfile?.CountryCode,
                    PhotoUrl = identityBaseEvent.UserProfile?.PhotoUrl,
                    ZipCode = identityBaseEvent.UserProfile?.ZipCode,
                    EnrolledBusinessUser = identityBaseEvent.EnrolledBusinessUser,
                    BusinessName = identityBaseEvent.UserProfile.BusinessName,
                    BusinessAccountNumber = identityBaseEvent.UserProfile.BusinessAccountNumber,
                    IsActive = true,
                });
            }
            else
            {
                await _mediator.Send(new UpdateUserCommand
                {
                    Email = identityBaseEvent.Email,
                    FirstName = identityBaseEvent.FirstName,
                    LastName = identityBaseEvent.LastName,
                    MobileCountryCode = identityBaseEvent.MobileCountryCode,
                    MobileNumber = identityBaseEvent.MobileNumber,
                    UserId = identityBaseEvent.UserId,
                    UserTypeId = identityBaseEvent.UserTypeId,
                    AddressLine1 = identityBaseEvent.UserProfile?.AddressLine1,
                    AddressLine2 = identityBaseEvent.UserProfile?.AddressLine2,
                    City = identityBaseEvent.UserProfile?.City,
                    State = identityBaseEvent.UserProfile?.State,
                    Country = identityBaseEvent.UserProfile?.Country,
                    CountryCode = identityBaseEvent.UserProfile?.CountryCode,
                    PhotoUrl = identityBaseEvent.UserProfile?.PhotoUrl,
                    ZipCode = identityBaseEvent.UserProfile?.ZipCode,
                    EnrolledBusinessUser = identityBaseEvent.EnrolledBusinessUser,
                    BusinessName = identityBaseEvent.UserProfile.BusinessName,
                    BusinessAccountNumber = identityBaseEvent.UserProfile.BusinessAccountNumber,
                    IsActive = true,
                });
            }
        }
    }
}
