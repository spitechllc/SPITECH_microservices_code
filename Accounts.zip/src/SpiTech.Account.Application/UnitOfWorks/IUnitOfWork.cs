﻿using SpiTech.Account.Application.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;

namespace SpiTech.Account.Application.UnitOfWorks
{
    public interface IUnitOfWork : IBaseUnitOfWork
    {
        IInvoiceRepository Invoices { get; }
        IInvoiceItemsRepository InvoiceItems { get; }
        IPaymentTransactionRepository paymentTransaction { get; }
        IUserRepository Users { get; }
        ITransactionRepository TransactionRepository { get; }
    }
}
