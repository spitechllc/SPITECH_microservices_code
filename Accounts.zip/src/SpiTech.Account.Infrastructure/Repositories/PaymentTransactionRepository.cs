﻿using Dapper;
using SpiTech.Account.Application.Repositories;
using SpiTech.Account.Domain.Entities;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Account.Infrastructure.Repositories
{
    public class PaymentTransactionRepository : Repository<Transaction>, IPaymentTransactionRepository
    {
        public PaymentTransactionRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<Transaction> GetByTransactionById(int TransactionId)
        {
            StringBuilder query = new();
            query.Append($"select * from [Transaction] where 1=1");
            DynamicParameters dynamicParams = new();
            if (TransactionId > 0)
            {
                query.Append($" and TransactionId =@TransactionId");
                dynamicParams.Add("TransactionId", TransactionId);
            }
            return await DbConnection.QueryFirstOrDefaultAsync<Transaction>(query.ToString(), dynamicParams, DbTransaction);
        }
    }
}
