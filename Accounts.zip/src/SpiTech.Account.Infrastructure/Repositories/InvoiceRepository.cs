﻿using Dapper;
using SpiTech.Account.Application.Queries.GetUserInvoiceSummary;
using SpiTech.Account.Application.Repositories;
using SpiTech.Account.Domain.Entities;
using SpiTech.Account.Domain.Enums;
using SpiTech.Account.Domain.Models;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Account.Infrastructure.Repositories
{
    public class InvoiceRepository : Repository<Invoice>, IInvoiceRepository
    {
        public InvoiceRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<Invoice> GetByInvoiceNo(string InvoiceNo, int UserId, bool IsReceiver)
        {
            StringBuilder query = new();
            query.Append($"select * from [Invoice] where 1=1");
            DynamicParameters dynamicParams = new();

            if (!string.IsNullOrEmpty(InvoiceNo))
            {
                query.Append($" and InvoiceNo =@InvoiceNo ");
                dynamicParams.Add("InvoiceNo", InvoiceNo);
            }
            if (IsReceiver)
            {
                query.Append($" and ReceiverId =@ReceiverId ");
                dynamicParams.Add("ReceiverId", UserId);
            }
            else
            {
                query.Append($" and SenderId =@SenderId ");
                dynamicParams.Add("SenderId", UserId);
            }
            query.Append($" and IsActive='True'");
            return await DbConnection.QueryFirstOrDefaultAsync<Invoice>(query.ToString(), dynamicParams, DbTransaction);
        }

        public async Task<Invoice> GetByInvoiceById(int InvoiceId)
        {
            StringBuilder query = new();
            DynamicParameters dynamicParams = new();
            query.Append($"select * from [Invoice] where 1=1");
            if (InvoiceId > 0)
            {
                query.Append($" and InvoiceId =@InvoiceId ");
                dynamicParams.Add("InvoiceId", InvoiceId);
            }
            return await DbConnection.QueryFirstOrDefaultAsync<Invoice>(query.ToString(), dynamicParams, DbTransaction);
        }

        public async Task<IEnumerable<Invoice>> GetRecentInvoices_ById(int userId, bool isReceiver)
        {
            StringBuilder query = new();
            DynamicParameters dynamicParams = new();
            query.Append($"select top 10 * from [Invoice] where 1=1  ");
            if (isReceiver)
            {
                query.Append($" and ReceiverId =@userId");
                dynamicParams.Add("userId", userId);
            }
            else
            {
                query.Append($" and SenderId =@userId");
                dynamicParams.Add("userId", userId);
            }
            query.Append($" and IsActive='True'");
            query.Append($" order by Isnull(UpdatedOn,CreatedOn) Desc");
            return (await DbConnection.QueryAsync<Invoice>(query.ToString(), dynamicParams, DbTransaction)).ToList();
        }
        public async Task<NewInvocieNoModel> GenerateInvoiceNo(int userId)
        {
            string query = @$"select isnull(max(cast(InvoiceNo as int)),0)+1 as NewInvoiceNo from [Invoice] where SenderId =@SenderId ";
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("SenderId", userId);
            return await DbConnection.QueryFirstOrDefaultAsync<NewInvocieNoModel>(query, dynamicParams, DbTransaction);
        }
        public async Task<PaymentStatus> GetInvoicePaymentStatus(int StatusId)
        {
            string query = @$"select * from  PaymentStatus where StatusId= @StatusId";
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("StatusId", StatusId);
            return await DbConnection.QueryFirstOrDefaultAsync<PaymentStatus>(query, dynamicParams, DbTransaction);
        }

        public async Task<IEnumerable<PaymentStatus>> GetPaymentStatusList()
        {
            string query = @$"select * from  PaymentStatus ";
            return await DbConnection.QueryAsync<PaymentStatus>(query, null, DbTransaction);
        }

        public async Task<List<InvoiceModel>> GetInvoiceListWithPaging(int UserId, bool IsReceiver, int Status, int[] filter, int? PageIndex, int? PageSize, string SortBy, string SortOrder)
        {
            StringBuilder sbquery = new();
            DynamicParameters dynamicParams = new();
            sbquery.Append($"select count(1) over() as TotalRecord, * from [Invoice] where 1=1  ");
            if (IsReceiver)
            {
                sbquery.Append($" and ReceiverId =@ReceiverId");
                dynamicParams.Add("ReceiverId", UserId);
                if (filter.Count() > 0)
                {
                    sbquery.Append($" and SenderId in @SenderId ");
                    dynamicParams.Add("SenderId", filter);
                }
            }
            else
            {
                sbquery.Append($" and SenderId =@SenderId ");
                dynamicParams.Add("SenderId", UserId);
                if (filter.Count() > 0)
                {
                    sbquery.Append($" and ReceiverId in @ReceiverId ");
                    dynamicParams.Add("ReceiverId", filter);
                }
            }
            sbquery.Append($"  and IsActive='True' ");
            if (Status != 0)
            {
                sbquery.Append($"  and StatusId=@StatusId");
                dynamicParams.Add("StatusId", Status);
            }
            if (!string.IsNullOrEmpty(SortBy) && !string.IsNullOrEmpty(SortOrder))
            {
                sbquery.Append($" Order by {SortBy} {SortOrder}");
            }
            else
            {
                sbquery.Append($" Order by Isnull(UpdatedOn,CreatedOn) desc");
            }
            if (PageIndex.HasValue && PageSize.HasValue)
            {
                int skiprow = (PageIndex.Value - 1) * PageSize.Value;
                sbquery.Append($" OFFSET {skiprow} rows fetch next {PageSize.Value} rows only");
            }
            return (await DbConnection.QueryAsync<InvoiceModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }


        public async Task<ResponseModel> DeclineInvoice(int InvoiceId, string Remarks)
        {
            string query = @$"Update [Invoice] set StatusId=@StatusId , UpdatedBy=@UpdatedBy , UpdatedOn=getutcdate()  , Remarks=@Remarks where InvoiceId= @InvoiceId ";
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("InvoiceId", InvoiceId);
            dynamicParams.Add("UpdatedBy", GetActionUserId());
            dynamicParams.Add("Remarks", Remarks);
            dynamicParams.Add("StatusId", (int)PaymentStatusEnum.Rejected);

            int success = await DbConnection.ExecuteAsync(query, dynamicParams, DbTransaction);
            return success > 0
                ? new ResponseModel { Message = "Invoice Declined Successfully", Success = true }
                : new ResponseModel { Message = "Invoice Declined Failed", Success = false };
        }

        public async Task<ResponseModel> CancelInvoice(int InvoiceId, string Remarks)
        {
            string query = @$"Update [Invoice] set  StatusId=@StatusId , UpdatedBy=@UpdatedBy , UpdatedOn=getutcdate()  , Remarks=@Remarks where InvoiceId= @InvoiceId";
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("InvoiceId", InvoiceId);
            dynamicParams.Add("UpdatedBy", GetActionUserId());
            dynamicParams.Add("Remarks", Remarks);
            dynamicParams.Add("StatusId", (int)PaymentStatusEnum.Canceled);

            int success = await DbConnection.ExecuteAsync(query, dynamicParams, DbTransaction);
            return success > 0
                ? new ResponseModel { Message = "Invoice Canceled Successfully", Success = true }
                : new ResponseModel { Message = "Invoice Cancelation Failed", Success = false };
        }
        public async Task<ResponseModel> PaymentInvoice(int InvoiceId, string Remarks)
        {
            try
            {
                string query = @$"Update [Invoice] set StatusId=@StatusId , UpdatedBy=@UpdatedBy , UpdatedOn=getutcdate()  , Remarks=@Remarks where InvoiceId= @InvoiceId";
                DynamicParameters dynamicParams = new();
                dynamicParams.Add("InvoiceId", InvoiceId);
                dynamicParams.Add("UpdatedBy", GetActionUserId());
                dynamicParams.Add("Remarks", Remarks);
                dynamicParams.Add("StatusId", (int)PaymentStatusEnum.Paid);

                int success = await DbConnection.ExecuteAsync(query, dynamicParams, DbTransaction);
                return success > 0
                    ? new ResponseModel { Message = "Invoice Paid Successfully", Success = true }
                    : new ResponseModel { Message = "Invoice Payment Failed", Success = false };
            }
            catch (Exception ex) { return new ResponseModel { Message = ex.Message, Success = false }; };
        }

        public async Task<UserInvoiceDetailModel> UsersInvoiceDetails(GetUserInvoiceSummaryQuery filter)
        {
            StringBuilder sbquery = new();
            sbquery.Append(@"select 
                                    Count(Invoiceid) as TotalInvoices,
                                    Round(sum(TotalAmount), 3) as TotalAmount,
                                    sum(Quantity) as TotalQuantity,
                                    
                                    Count(case StatusId when 1 then Invoiceid  end) as TotalPendingInvoices,
                                    Round(sum(case StatusId when 1 then TotalAmount else 0 end),3) as TotalPendingAmount,
		                            sum(case StatusId when 1 then Quantity else 0 end) as TotalPendingQuantity, 
                                    
		                            Count(case StatusId when 2 then Invoiceid end) as TotalPaidInvoices,
		                            Round(sum(case StatusId when 2 then TotalAmount else 0 end),3) as TotalPaidAmount,
		                            sum(case StatusId when 2 then Quantity else 0 end) as TotalPaidQuantity, 
                                    
		                            Count(case StatusId when 3 then Invoiceid end) as TotalDeclinedInvoices,
		                            Round(sum(case StatusId when 3 then TotalAmount else 0 end),3) as TotalDeclinedAmount,
		                            sum(case StatusId when 3 then Quantity else 0 end) as TotalDeclinedQuantity, 
                                    
		                            Count(case StatusId when 4 then Invoiceid end) as TotalCanceledInvoices,
		                            Round(sum(case StatusId when 4 then TotalAmount else 0 end),3) as TotalCanceledAmount,
		                            sum(case StatusId when 4 then Quantity else 0 end) as TotalCanceledQuantity from Invoice where 1=1 ");
            DynamicParameters dynamicParams = new();
            if (filter.IsReceiver)
            {
                sbquery.Append($" and ReceiverId =@ReceiverId ");
                dynamicParams.Add("ReceiverId", filter.UserId);
            }
            else
            {
                sbquery.Append($" and SenderId =@SenderId ");
                dynamicParams.Add("SenderId", filter.UserId);
            }

            dynamicParams.Add("fromDate", filter.FromDate.ToString("yyyy-MM-dd"));
            dynamicParams.Add("toDate", filter.ToDate.ToString("yyyy-MM-dd"));
            sbquery.Append($" and InvoiceDate >=@fromDate ");
            sbquery.Append($" and InvoiceDate <=@toDate ");

            return await DbConnection.QueryFirstOrDefaultAsync<UserInvoiceDetailModel>(sbquery.ToString(), dynamicParams, DbTransaction);
        }

        public async Task<List<InvoiceModel>> GetTodaysInvoiceListWithPaging(int UserId, bool IsReceiver, int Status, int? PageIndex, int? PageSize, string SortBy, string SortOrder)
        {
            StringBuilder sbquery = new();
            DynamicParameters dynamicParams = new();

            sbquery.Append($"select count(1) over() as TotalRecord, * from [Invoice] ");
            if (IsReceiver)
            {
                sbquery.Append($" where ReceiverId =@ReceiverId ");
                dynamicParams.Add("ReceiverId", UserId);
            }
            else
            {
                sbquery.Append($" where SenderId =@SenderId ");
                dynamicParams.Add("SenderId", UserId);
            }
            sbquery.Append($"  and IsActive=@IsActive ");
            dynamicParams.Add("IsActive", true);
            string CurrentDate = System.DateTime.UtcNow.ToString("yyyy-MM-dd");
            sbquery.Append($" and Cast(InvoiceDate as Date)=@CurrentDate");
            dynamicParams.Add("CurrentDate", CurrentDate);
            if (Status != 0)
            {
                sbquery.Append($"  and StatusId=@StatusId");
                dynamicParams.Add("StatusId", Status);
            }
            else
            {
                sbquery.Append($"  and StatusId=@StatusId");
                dynamicParams.Add("StatusId", (int)PaymentStatusEnum.Pending);
            }
            if (!string.IsNullOrEmpty(SortBy) && !string.IsNullOrEmpty(SortOrder))
            {
                sbquery.Append($" Order by {SortBy} {SortOrder}");
            }
            else
            {
                sbquery.Append($" Order by cast(InvoiceNo as int) desc");
            }
            if (PageIndex.HasValue && PageSize.HasValue)
            {
                int skiprow = (PageIndex.Value - 1) * PageSize.Value;
                sbquery.Append($" OFFSET {skiprow} rows fetch next {PageSize.Value} rows only");
            }
            return (await DbConnection.QueryAsync<InvoiceModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }
    }
}
