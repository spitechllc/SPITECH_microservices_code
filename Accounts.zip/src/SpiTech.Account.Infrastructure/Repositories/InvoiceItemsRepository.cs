﻿using Dapper;
using SpiTech.Account.Application.Repositories;
using SpiTech.Account.Domain.Entities;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Account.Infrastructure.Repositories
{
    public class InvoiceItemsRepository : Repository<InvoiceDetail>, IInvoiceItemsRepository
    {
        public InvoiceItemsRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<IEnumerable<InvoiceDetail>> GetByInvoiceItemsById(int InvoiceId)
        {
            string query = @$"select * from [InvoiceDetail] where InvoiceId =@InvoiceId ";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("InvoiceId", InvoiceId);

            return await DbConnection.QueryAsync<InvoiceDetail>(query, dynamicParams, DbTransaction);
        }

        public async Task<IEnumerable<InvoiceDetail>> GetByInvoiceItemsListByIds(IEnumerable<int> InvoiceIds)
        {
            string query = @$"select * from [InvoiceDetail] where InvoiceId in @InvoiceId ";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("InvoiceId", InvoiceIds);

            return await DbConnection.QueryAsync<InvoiceDetail>(query, dynamicParams, DbTransaction);
        }
    }
}
