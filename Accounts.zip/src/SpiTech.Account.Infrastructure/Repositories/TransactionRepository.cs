﻿using Dapper;
using SpiTech.Account.Application.Repositories;
using SpiTech.Account.Domain.Entities;
using SpiTech.Account.Domain.Models;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Account.Infrastructure.Repositories
{
    public class TransactionRepository : Repository<Transaction>, ITransactionRepository
    {
        public TransactionRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
        public async Task<List<InvoiceTransactionSearch>> GetInvoiceTransactionByFilter(int userId, string NameEmailMobile, int IsPaymentSuccess, int? PageIndex, int? PageSize, Sortable sortable)
        {
            StringBuilder sbquery = new();
            DynamicParameters dynamicParams = new();

            sbquery.Append(@" ;WITH
        PaymentHistory AS
        (
               SELECT
                                   SU.UserId
                                 , SU.UserTypeId
                                 , SU.FirstName
                                 , SU.LastName
                                 , SU.Email
                                 , SU.BusinessName
                                 , SU.MobileCountryCode
                                 , SU.MobileNumber
                                 , SU.PhotoUrl
                                 , SU.AddressLine1
                                 , SU.AddressLine2
                                 , SU.Country
                                 , SU.CountryCode
                                 , SU.State
                                 , SU.City
                                 , I.InvoiceId
                                 , I.InvoiceNo
                                 , I.InvoiceDate
                                 , I.InvoiceDueDate
                                 , I.Quantity
                                 , I.NetAmount
                                 , I.TaxType
                                 , I.TaxValue
                                 , I.TaxAmount
                                 , I.TotalAmount
                                 , I.ReceiverId
                                 , I.SenderId
                                 , I.StatusId
                                 , I.Remarks
                                 , T.TransactionId
                                 , T.TransactionKey
                                 , T.TransactionDate
                                 , T.TransferedBy
								 , Case T.TransferedBy when @userId then 'Paid' else 'Received' end as SendOrReceive
                                 , T.Status
                                 , T.IsActive
                                 , T.IsTransfered
                                 , T.CreatedOn
                                 , T.CreatedBy
								 
                            from
                                   [dbo].[Invoice] I
                                   Join
                                          [Transaction] T
                                          on
                                                 I.InvoiceId        = t.InvoiceId 
                                   join
                                          [User] SU
                                          on
                                                 SU.UserId = I.ReceiverId
                            WHERE
                                   I.IsActive = 1  
								   and (I.SenderId=@SenderId )
                UNION ALL
                
				SELECT
                                   SU.UserId
                                 , SU.UserTypeId
                                 , SU.FirstName
                                 , SU.LastName
                                 , SU.Email
                                 , SU.BusinessName
                                 , SU.MobileCountryCode
                                 , SU.MobileNumber
                                 , SU.PhotoUrl
                                 , SU.AddressLine1
                                 , SU.AddressLine2
                                 , SU.Country
                                 , SU.CountryCode
                                 , SU.State
                                 , SU.City
                                 , I.InvoiceId
                                 , I.InvoiceNo
                                 , I.InvoiceDate
                                 , I.InvoiceDueDate
                                 , I.Quantity
                                 , I.NetAmount
                                 , I.TaxType
                                 , I.TaxValue
                                 , I.TaxAmount
                                 , I.TotalAmount
                                 , I.ReceiverId
                                 , I.SenderId
                                 , I.StatusId
                                 , I.Remarks
                                 , T.TransactionId
                                 , T.TransactionKey
                                 , T.TransactionDate
                                 , T.TransferedBy
								 , Case T.TransferedBy when @userId then 'Paid' else 'Received' end as SendOrReceive
                                 , T.Status
                                 , T.IsActive
                                 , T.IsTransfered
                                 , T.CreatedOn
                                 , T.CreatedBy
								 
                            from
                                   [dbo].[Invoice] I
                                   Join
                                          [Transaction] T
                                          on
                                                 I.InvoiceId        = t.InvoiceId 
                                   join
                                          [User] SU
                                          on
                                                 SU.UserId = I.SenderId
                            WHERE
                                   I.IsActive = 1  
								   and (I.ReceiverId=@ReceiverId )
        )
		select Count(1) over() as TotalRecord, * from PaymentHistory where 1=1  ");
            dynamicParams.Add("SenderId", userId);
            dynamicParams.Add("ReceiverId", userId);
            dynamicParams.Add("userId", userId);
           
            if (IsPaymentSuccess > 0)
            {
                sbquery.Append($" AND  Status = @Status");
                dynamicParams.Add("Status", IsPaymentSuccess);
            }

            long.TryParse(NameEmailMobile, out long mobile);
            if (mobile != 0)
            {
                sbquery.Append($" AND MobileNumber = @MobileNumber");
                dynamicParams.Add("MobileNumber", NameEmailMobile);
            }
            else if (mobile == 0 && !string.IsNullOrEmpty(NameEmailMobile) && NameEmailMobile.Contains("@") && NameEmailMobile.Contains("."))
            {
                sbquery.Append($" AND Email = @Email");
                dynamicParams.Add("Email", NameEmailMobile);
            }
            else if (mobile == 0 && !string.IsNullOrEmpty(NameEmailMobile) && !NameEmailMobile.Contains("@") && !NameEmailMobile.Contains("."))
            {
                sbquery.Append($" and ((FirstName +' '+LastName) like @UserName or BusinessName like @UserName)");
                dynamicParams.Add("username", $"%{NameEmailMobile}%");
            }

            if (sortable != null)
            {
                if (!string.IsNullOrEmpty(sortable.SortBy) && !string.IsNullOrEmpty(sortable.SortOrder))
                {

                    if (sortable.SortBy == "CreatedOn")
                    {
                        sbquery.Append($" order by {sortable.SortBy}  {sortable.SortOrder}");
                    }
                    else
                    {
                        sbquery.Append($" order by {sortable.SortBy}  {sortable.SortOrder}");
                    }
                }
            }
            else
            {
                sbquery.Append($" order by Createdon desc ");
            }
            if (PageIndex.HasValue && PageSize.HasValue)
            {
                int skiprow = (PageIndex.Value - 1) * PageSize.Value;

                sbquery.Append($" OFFSET {skiprow} rows fetch next {PageSize.Value} rows only");

            }
            return (await DbConnection.QueryAsync<InvoiceTransactionSearch>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }
    }
}
