﻿using Dapper;
using SpiTech.Account.Application.Repositories;
using SpiTech.Account.Domain.Entities;
using SpiTech.Account.Domain.Models;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Account.Infrastructure.Repositories
{
    public class UserRepository : Repository<User>, IUserRepository
    {
        public UserRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<UsersModel> GetUserByEmailOrPhoneAsync(string NameEmailorMobile)
        {
            StringBuilder query = new();
            query.Append($"select * from [User] where 1=1");
            DynamicParameters dynamicParams = new();
            long.TryParse(NameEmailorMobile, out long mobile);
            if (mobile == 0 || (NameEmailorMobile.Contains("@") && NameEmailorMobile.Contains(".")))
            {
                query.Append($" and Email =@Email ");
                dynamicParams.Add("Email", NameEmailorMobile);
            }
            else if (mobile != 0)
            {
                query.Append($" and MobileNumber =@MobileNumber ");
                dynamicParams.Add("MobileNumber", NameEmailorMobile);
            }

            return await DbConnection.QueryFirstOrDefaultAsync<UsersModel>(query.ToString(), dynamicParams, DbTransaction);
        }

        public async Task<List<UsersModel>> GetUserIds(List<int> InvoiceId)
        {
            StringBuilder query = new();
            DynamicParameters dynamicParams = new();
            query.Append($"select * from [User] where 1=1");
            if (InvoiceId.Count > 0)
            {
                query.Append($" and UserId in @UserId ");
                dynamicParams.Add("UserId", InvoiceId);
            }
            return (await DbConnection.QueryAsync<UsersModel>(query.ToString(), dynamicParams, DbTransaction)).ToList();
        }

        public async Task<List<UsersModel>> GetUsersByNameAsync(string Name)
        {
            StringBuilder query = new();

            DynamicParameters dynamicParams = new();
            query.Append($"select * from [User] where 1=1");

            long.TryParse(Name, out long mobile);
            if (mobile == 0 || !(Name.Contains("@") && Name.Contains(".")))
            {
                query.Append($" and ((FirstName +' '+LastName) like @UserName or BusinessName like @UserName)");
                dynamicParams.Add("UserName", $"%{Name}%");
            }

            return (await DbConnection.QueryAsync<UsersModel>(query.ToString(), dynamicParams, DbTransaction)).ToList();
        }
    }
}
