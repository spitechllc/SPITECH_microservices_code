﻿using AutoMapper;
using SpiTech.Account.Application.Repositories;
using SpiTech.Account.Application.UnitOfWorks;
using SpiTech.Account.Infrastructure.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
//using SpiTech.Account.Infrastructure.Repositories;
using System.Data;

namespace SpiTech.Account.Infrastructure.UnitOfWorks
{
    public sealed class UnitOfWork : BaseUnitOfWork, IUnitOfWork
    {
        public UnitOfWork(string connectionString,
                         System.IServiceProvider serviceProvider,
                        IsolationLevel isolationLevel = IsolationLevel.ReadCommitted)
                        : base(connectionString, serviceProvider, isolationLevel)
        {
        }

        private IInvoiceRepository _invoices = null;
        private IInvoiceItemsRepository _invoiceItems = null;
        private IPaymentTransactionRepository _paymentTransactionRepository = null;
        private IUserRepository _userRepository = null;
        private ITransactionRepository _transactionRepository = null;

        public IInvoiceRepository Invoices => _invoices ??= new InvoiceRepository(this, serviceProvider);

        public IInvoiceItemsRepository InvoiceItems => _invoiceItems ??= new InvoiceItemsRepository(this, serviceProvider);

        public IPaymentTransactionRepository paymentTransaction => _paymentTransactionRepository ??= new PaymentTransactionRepository(this, serviceProvider);

        public IUserRepository Users => _userRepository ??= new UserRepository(this, serviceProvider);

        public ITransactionRepository TransactionRepository => _transactionRepository ??= new TransactionRepository(this, serviceProvider);


        public override void ResetRepositories()
        {
            _invoices = null;
            _invoiceItems = null;
            _paymentTransactionRepository = null;
            _userRepository = null;
            _transactionRepository = null;
        }
    }
}
