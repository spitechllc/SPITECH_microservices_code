ALTER TABLE [User] ALTER COLUMN BusinessName nvarchar(150) NULL
ALTER TABLE [User] ALTER COLUMN BusinessAccountNumber nvarchar(150) NULL