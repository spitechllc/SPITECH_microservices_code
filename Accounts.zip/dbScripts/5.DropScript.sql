
Drop TABLE [dbo].[Transaction]
Drop TABLE [dbo].[InvoiceDetail]
Drop TABLE [dbo].[Invoice]
Drop TABLE [dbo].[User]
Drop TABLE [dbo].[PaymentStatus]