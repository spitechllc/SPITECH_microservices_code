CREATE TABLE [dbo].[PaymentStatus]
(
	  [StatusId] INT NOT NULL IDENTITY(1,1)
	, [Status] NVARCHAR(50) NOT NULL
	, [IsActive] BIT NOT NULL CONSTRAINT DF_PaymentStatus_IsActive Default ((1))
	, [CreatedOn] DATETIME NULL
	, [CreatedBy] NVARCHAR(256) NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] NVARCHAR(256) NULL
	, CONSTRAINT [PK_PaymentStatus] PRIMARY KEY ([StatusId] ASC)
)

GO
CREATE TABLE [dbo].[User]
(
	  [UserId] INT NOT NULL
	, [UserTypeId] INT NOT NULL
	, [FirstName] NVARCHAR(50) NOT NULL
	, [LastName] NVARCHAR(50) NOT NULL
	, [Email] NVARCHAR(100) NULL
	, [MobileCountryCode] NVARCHAR(10) NULL
	, [MobileNumber] NVARCHAR(20) NULL
	, [PhotoUrl] NVARCHAR(500) NULL
	, [AddressLine1] NVARCHAR(500) NULL
	, [AddressLine2] NVARCHAR(500) NULL
	, [EnrolledBusinessUser] bit not null CONSTRAINT DF_User_EnrolledBusinessUser Default ((0))
	, [BusinessName]  NVARCHAR(150)  NULL 
	, [BusinessAccountNumber] NVARCHAR(150) NULL 
	, [Country] NVARCHAR(100) NULL
	, [CountryCode] NVARCHAR(10) NULL
	, [State] NVARCHAR(100) NULL
	, [City] NVARCHAR(100) NULL
	, [ZipCode] NVARCHAR(10) NULL
	, [TenantId] INT Not NULL CONSTRAINT DF_User_TenantId Default ((0))
	, [ClientId] Varchar(50) NULL
	, [IsActive] BIT NOT NULL CONSTRAINT DF_User_IsActive Default ((1))
	, [CreatedOn] DATETIME NOT NULL CONSTRAINT DF_User_CreatedOn Default (getutcdate())
	, [CreatedBy] NVARCHAR(256) NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] NVARCHAR(256) NULL
	, CONSTRAINT [PK_User] PRIMARY KEY ([UserId] ASC)
)

GO
CREATE TABLE [dbo].[Invoice]
(
	  [InvoiceId] INT NOT NULL IDENTITY(1,1)
	, [InvoiceNo] NVARCHAR(50) NOT NULL  CONSTRAINT DF_Invoice_InvoiceNo Default ((0))
	, [InvoiceDate] DATETIME NOT NULL  CONSTRAINT DF_Invoice_InvoiceDate Default (getutcdate())
	, [InvoiceDueDate] DATETIME NULL
	, [Quantity] FLOAT NOT NULL  CONSTRAINT DF_Invoice_Quantity Default ((0))
	, [NetAmount] DECIMAL(18,2) NOT NULL  CONSTRAINT DF_Invoice_NetAmount Default ((0))
	, [TaxType] NVARCHAR(50) NOT NULL  CONSTRAINT DF_Invoice_TaxType Default ('%')
	, [TaxCaption] NVARCHAR(50) NOT NULL  CONSTRAINT DF_Invoice_TaxCaption Default ('')
	, [TaxValue] DECIMAL(18,2) NOT NULL  CONSTRAINT DF_Invoice_TaxValue Default ((0))
	, [TaxAmount] DECIMAL(18,2) NOT NULL  CONSTRAINT DF_Invoice_TaxAmount Default ((0))
	, [TotalAmount] DECIMAL(18,2) NOT NULL  CONSTRAINT DF_Invoice_TotalAmount Default ((0))
	, [ReceiverId] INT NOT NULL  CONSTRAINT DF_Invoice_ReceiverId Default ((0))
	, [SenderId] INT NOT NULL  CONSTRAINT DF_Invoice_SenderId Default ((0))
	, [StatusId] INT NOT NULL  CONSTRAINT DF_Invoice_StatusId Default ((0))
	, [TemplateType] INT NOT NULL  CONSTRAINT DF_Invoice_TemplateType Default ((0))
	, [Remarks] NVARCHAR(500) NOT NULL  CONSTRAINT DF_Invoice_Remarks Default ('')
	, [InteralRemarks] NVARCHAR(500) NOT NULL  CONSTRAINT DF_Invoice_InteralRemarks Default ('')
	, [ExternalRemarks] NVARCHAR(500) NOT NULL  CONSTRAINT DF_Invoice_ExternalRemarks Default ('')
	, [TenantId] INT Not NULL CONSTRAINT DF_Invoice_TenantId  Default((0))
	, [ClientId] Varchar(50) NULL
	, [IsActive] BIT NOT NULL  CONSTRAINT DF_Invoice_IsActive Default ((1))
	, [CreatedOn] DATETIME NULL
	, [CreatedBy] NVARCHAR(256) NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] NVARCHAR(256) NULL
	, CONSTRAINT [PK_Invoice_Main] PRIMARY KEY ([InvoiceId] ASC)
)

ALTER TABLE [dbo].[Invoice] WITH CHECK ADD CONSTRAINT [FK_Invoice_PaymentStatus] FOREIGN KEY([StatusId]) REFERENCES [dbo].[PaymentStatus] ([StatusId])
ALTER TABLE [dbo].[Invoice] CHECK CONSTRAINT [FK_Invoice_PaymentStatus]

GO
CREATE TABLE [dbo].[InvoiceDetail]
(
	  [InvoiceDetailId] INT NOT NULL IDENTITY(1,1)
	, [InvoiceId] INT NOT NULL  CONSTRAINT DF_InvoiceDetail_InvoiceId Default ((0))
	, [SerialNo] INT NOT NULL  CONSTRAINT DF_InvoiceDetail_SerialNo Default ((0))
	, [Description] NVARCHAR(500) NOT NULL  CONSTRAINT DF_InvoiceDetail_Description Default ('')
	, [Quantity] FLOAT NOT NULL  CONSTRAINT DF_InvoiceDetail_Quantity Default ((0))
	, [Amount] FLOAT NOT NULL  CONSTRAINT DF_InvoiceDetail_Amount Default ((0))
	, [TenantId] INT Not NULL CONSTRAINT DF_InvoiceDetail_TenantId Default  ((0))
	, [ClientId] Varchar(50) NULL
	, [IsActive] BIT NOT NULL  CONSTRAINT DF_InvoiceDetail_IsActive Default ((1))
	, [CreatedOn] DATETIME NULL
	, [CreatedBy] NVARCHAR(256) NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] NVARCHAR(256) NULL
	, CONSTRAINT [PK_Invoice_Sub] PRIMARY KEY ([InvoiceDetailId] ASC)
)

ALTER TABLE [dbo].[InvoiceDetail] WITH CHECK ADD CONSTRAINT [FK_InvoiceDetail_Invoice] FOREIGN KEY([InvoiceId]) REFERENCES [dbo].[Invoice] ([InvoiceId])
ALTER TABLE [dbo].[InvoiceDetail] CHECK CONSTRAINT [FK_InvoiceDetail_Invoice]

GO
CREATE TABLE [dbo].[Transaction]
(
	  [TransactionId] INT NOT NULL IDENTITY(1,1)
	, [TransactionKey] NVARCHAR(500) NOT NULL  CONSTRAINT DF_Transaction_TransactionKey Default ('')
	, [TransactionDate] DATETIME NOT NULL  CONSTRAINT DF_Transaction_TransactionDate Default (getutcdate())
	, [InvoiceId] INT NOT NULL  CONSTRAINT DF_Transaction_InvoiceId Default ((0))
	, [TransferedBy] INT NOT NULL  CONSTRAINT DF_Transaction_TransferedBy Default ((0))
	, [Status] INT NOT NULL  CONSTRAINT DF_Transaction_Status Default ((1))
	, [TenantId] INT Not NULL CONSTRAINT DF_Transaction_TenantId Default  ((0))
	, [ClientId] Varchar(50) NULL
	, [IsTransfered] BIT NOT NULL  CONSTRAINT DF_Transaction_IsTransfered Default ((0))
	, [IsActive] BIT NOT NULL  CONSTRAINT DF_Transaction_IsActive Default ((1))
	, [CreatedOn] DATETIME NULL
	, [CreatedBy] NVARCHAR(256) NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] NVARCHAR(256) NULL
	, CONSTRAINT [PK_Transaction] PRIMARY KEY ([TransactionId] ASC)
)

ALTER TABLE [dbo].[Transaction] WITH CHECK ADD CONSTRAINT [FK_Transaction_Invoice] FOREIGN KEY([InvoiceId]) REFERENCES [dbo].[Invoice] ([InvoiceId])
ALTER TABLE [dbo].[Transaction] CHECK CONSTRAINT [FK_Transaction_Invoice]

GO