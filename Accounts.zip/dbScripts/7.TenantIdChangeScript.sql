
------------------------start script 25 jan 2023----------------
Alter Table [dbo].[Invoice] add [TenantId] INT Not NULL CONSTRAINT DF_Invoice_TenantId Default ((0)), [ClientId] NVARCHAR(50) NULL
Alter Table [dbo].[InvoiceDetail] add [TenantId] INT Not NULL CONSTRAINT DF_InvoiceDetail_TenantId Default ((0)), [ClientId] NVARCHAR(50) NULL
Alter Table [dbo].[Transaction] add [TenantId] INT Not NULL CONSTRAINT DF_Transaction_TenantId Default ((0)), [ClientId] NVARCHAR(50) NULL
Alter Table [dbo].[User] add [TenantId] INT Not NULL CONSTRAINT DF_User_TenantId Default ((0)), [ClientId] NVARCHAR(50) NULL

Alter Table [dbo].[Invoice]  alter column [CreatedBy] NVARCHAR(256) NULL
Alter Table [dbo].[Invoice] alter column [UpdatedBy] NVARCHAR(256) NULL
Alter Table [dbo].[InvoiceDetail] alter column [CreatedBy] NVARCHAR(256) NULL
Alter Table [dbo].[InvoiceDetail] alter column  [UpdatedBy] NVARCHAR(256) NULL
Alter Table [dbo].[PaymentStatus] alter column [CreatedBy] NVARCHAR(256) NULL
Alter Table [dbo].[PaymentStatus] alter column  [UpdatedBy] NVARCHAR(256) NULL
Alter Table [dbo].[Transaction] alter column [CreatedBy] NVARCHAR(256) NULL
Alter Table [dbo].[Transaction] alter column [UpdatedBy] NVARCHAR(256) NULL
Alter Table [dbo].[User] alter column [CreatedBy] NVARCHAR(256) NULL
Alter Table [dbo].[User] alter column [UpdatedBy] NVARCHAR(256) NULL

Update [dbo].[Invoice] Set [TenantId]=1
Update [dbo].[InvoiceDetail] Set [TenantId]=1
Update [dbo].[Transaction] Set [TenantId]=1
Update [dbo].[User] Set [TenantId]=1
------------------------end script 25 jan 2023----------------