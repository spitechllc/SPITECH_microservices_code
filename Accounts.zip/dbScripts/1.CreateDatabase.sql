IF NOT EXISTS(SELECT * FROM sys.databases WHERE name = 'SpiTech_Account')
  BEGIN
    CREATE DATABASE [SpiTech_Account]
 END
GO
       
 USE [SpiTech_Account]
    
GO