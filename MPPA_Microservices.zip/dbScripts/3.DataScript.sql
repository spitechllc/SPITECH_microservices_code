INSERT INTO [RequestType](RequestTypeId, Name)
VALUES 
(1, 'MobilePumpReserve'),
(2, 'MobileTransactionData' ),
(3, 'MobileAuth'),
(4, 'MobileCancel'),
(5, 'BeginFueling'), 
(6, 'MobileFinalize'), 
(7, 'MobileReceiptData'),
(8, 'MobileStacCapture'),
(9, 'MobileSettlement'),
(10, 'MobileSiteData'),
(11, 'MobileHeartBeat'),
(12, 'MobileStacGenerate'),
(13, 'MobileLoyaltyAward');
GO



INSERT INTO [Status](StatusId, Name)
VALUES 
(1, 'Inprogress'),
(2, 'Success'),
(3, 'Fail'),
(4, 'Canceled');
GO



SET IDENTITY_INSERT [dbo].[TransactionType] ON 
GO
INSERT [dbo].[TransactionType] ([TransactionTypeId], [Name], [Description])
VALUES
(1, N'FuelReserve', N'Fuel Reserve'),
(2, N'Carwash', N'Car wash'),
(3, N'PayAtPos', N'Pay at POS');
GO
SET IDENTITY_INSERT [dbo].[TransactionType] OFF
GO


INSERT INTO [HostMPPA](HostMPPAIdentifier, HostIP, IsProdEnabled)
VALUES
('01', '20.80.90.3' ,0);