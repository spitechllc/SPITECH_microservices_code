Create Procedure [dbo].[UpdateSite]
@StoreId Int,
@SiteId nvarchar(20),
@StoreName nvarchar(200)
As
Begin
	DECLARE @OriginalSiteId nvarchar(20);
	DECLARE @OriginalStoreName nvarchar(20);
	
	if(@SiteId Is null or len(ltrim(rtrim(@SiteId)))=0)
		BEGIN
			return;
		END
		
	If(@StoreId=0)
	BEGIN
		IF NOT EXISTS(select 1 From [Site] Where SiteId=@SiteId)
			BEGIN
				Insert Into [Site](siteId, storeId,StoreName) Values(@SiteId, @storeId, @StoreName);
				return;
			END
		ELSE
			BEGIN
				return;
			END
	END
	
	
	Select @OriginalSiteId = SiteId, @OriginalStoreName = StoreName From [Site] Where storeId = @storeId;
	
	If(@OriginalSiteId Is null)
		BEGIN
			Insert Into [Site](siteId, storeId,StoreName) Values(@SiteId, @storeId, @StoreName);
			return;
		END
		
	if(@StoreName is not null and len(ltrim(rtrim(@StoreName)))>0 and @OriginalStoreName <> @StoreName)
	BEGIN
		update Site set StoreName = @StoreName Where storeId = @storeId;
		update SettlementRequest set StoreName = @StoreName  Where storeId = @storeId;
		update [Transaction] set StoreName = @StoreName  Where storeId = @storeId;
	END
	
	
	If(@OriginalSiteId = @SiteId)
		BEGIN
			Return;
		END	
	
	update Site set SiteId = @SiteId, StoreName = @StoreName Where storeId = @storeId;
	update CommanderMessage set SiteId = @SiteId Where SiteId = @OriginalSiteId;
	update SettlementRequest set SiteId = @SiteId, StoreName = @StoreName  Where storeId = @storeId;
	update SiteProduct set SiteId = @SiteId  Where SiteId = @OriginalSiteId;
	update StacCaptureRequest set SiteId = @SiteId  Where SiteId = @OriginalSiteId;
	update StacGeneration set SiteId = @SiteId  Where SiteId = @OriginalSiteId;
	update [Transaction] set SiteId = @SiteId, StoreName = @StoreName  Where storeId = @storeId;
	update UserAppMessage set SiteId = @SiteId  Where SiteId = @OriginalSiteId;
END