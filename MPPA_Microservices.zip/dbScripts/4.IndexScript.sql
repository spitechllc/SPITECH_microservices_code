IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Transaction_UMTI')   
    DROP INDEX [IX_Transaction_UMTI] ON [dbo].[Transaction];   
GO 

CREATE NONCLUSTERED INDEX [IX_Transaction_UMTI] ON [dbo].[Transaction] ([UMTI]);
GO
GO
