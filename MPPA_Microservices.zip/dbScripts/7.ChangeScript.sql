alter table [dbo].[HostConfigration] add 
	 [MNSPId] NVARCHAR(50) NULL
	, [MNSP] NVARCHAR(50) NULL
------------------------------------------------14-11-2022-Start---------------------------------
Alter Table [dbo].[StacGeneration] ADD 
	 [QrCodeStac] NVARCHAR(50) NULL
	, [BarCodeStac] NVARCHAR(50) NULL;
	
GO	
Update [dbo].[StacGeneration] set [QrCodeStac]=StacGenerationId, [BarCodeStac]=StacGenerationId

GO	
Alter Table [dbo].[StacGeneration] Alter column  [QrCodeStac] NVARCHAR(50) NOT NULL;
GO	
Alter Table [dbo].[StacGeneration] Alter column   [BarCodeStac] NVARCHAR(50) NOT NULL;
	
GO	

ALTER TABLE StacGeneration DROP CONSTRAINT PK_StacGeneration;
GO

ALTER TABLE StacGeneration
Add CONSTRAINT PK_StacGeneration PRIMARY KEY ([StacGenerationId], [QrCodeStac], [BarCodeStac]);

GO

Alter Table [dbo].[StacCaptureRequest] ADD 
	 [QrCodeStac] NVARCHAR(50) NULL
	, [BarCodeStac] NVARCHAR(50) NULL
	, [StacCaptureType] NVARCHAR(1) NULL;

GO


Alter Table [dbo].[SettlementRequest] ADD 
	 [EodCashRewardAmount] DECIMAL(18,2) NULL
	, [EodAchAmount] DECIMAL(18,2) NULL
	, [EodCardAmount] DECIMAL(18,2) NULL;

GO


Alter Table [dbo].[Transaction] ADD 
	 [DisableEod] BIT NOT NULL DEFAULT((0))
	, [DisableBilling] BIT NOT NULL DEFAULT((0))
	, [StacCaptureType] NVARCHAR(1) NULL;

GO


------------------------------------------------14-11-2022-End---------------------------------