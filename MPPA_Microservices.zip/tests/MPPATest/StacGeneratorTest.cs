using SpiTech.MppaService.Application;
using System;
using Xunit;

namespace MPPATest
{
    public class StacGeneratorTest
    {
        [Fact]
        public void StacWithOutPrefixWithWrong()
        {
            string guid = "67C7C13E40DB483094F9ACD43591DB15";
            string stac = $"RPAP.{guid}";
            var result = StacGenerator.StacWithOutPrefix(stac);
            Assert.Equal(guid, result);
        }

        [Fact]
        public void StacWithOutPrefixWithCorrect()
        {
            string guid = "CC4E1753CD9E4C60965C4D69F5F90564";
            string stac = $"PAP.{guid}";
            var result = StacGenerator.StacWithOutPrefix(stac);
            Assert.Equal(guid, result);
        }
    }
}
