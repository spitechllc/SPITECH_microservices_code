﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using System;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Hubs
{
    [Authorize]
    public class DashBoardHub : Hub<IDashBoardHubClient>
    {
        private readonly ILogger<MppaHub> logger;
        private readonly IUserAuthenticationProvider authenticationProvider;
        private readonly IServiceScopeFactory scopeFactory;

        public DashBoardHub(ILogger<MppaHub> logger,
            IUserAuthenticationProvider authenticationProvider,
            IServiceScopeFactory scopeFactory)
        {
            this.logger = logger;
            this.authenticationProvider = authenticationProvider;
            this.scopeFactory = scopeFactory;
        }

        public override async Task OnConnectedAsync()
        {
            try
            {
                int userId = authenticationProvider.GetUserAuthentication()?.UserId ?? 0;

                logger.Info($"User with userId - {userId}, Connectionid - {this.Context.ConnectionId} connected");

                //await Groups.AddToGroupAsync(Context.ConnectionId, $"user_{userId}");

                await base.OnConnectedAsync();

            }
            catch (Exception ex)
            {
                logger.Error(ex);
                await Clients.Caller.Error("OnConnected: " + ex.Message);
            }
        }

        public override async Task OnDisconnectedAsync(Exception exception)
        {
            try
            {
                int userId = authenticationProvider.GetUserAuthentication()?.UserId ?? 0;
                logger.Info($"User with userId - {userId}, Connectionid - {this.Context.ConnectionId} disconnected");
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                await Clients.Caller.Error("OnDisconnected: " + ex.Message);
            }

            await base.OnDisconnectedAsync(exception);
        }

        private async Task OnError(string errorMessage)
        {
            // create error command in mobileintegration folder
            logger.Warn($"SignalR OnError-ConnectionId-{Context.ConnectionId}={errorMessage}");
            await Clients.Caller.Error(errorMessage);
        }
    }
}
