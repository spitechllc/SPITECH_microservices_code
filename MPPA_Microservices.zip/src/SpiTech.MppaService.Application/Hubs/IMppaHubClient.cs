﻿using SpiTech.MppaService.Application.Commands.MobileIntegrations.FinalizesDataResponses;
using SpiTech.MppaService.Application.Commands.MobileIntegrations.FinalReceiptResponses;
using SpiTech.MppaService.Application.Commands.MobileIntegrations.PosTransactionDataProcessResponses;
using SpiTech.MppaService.Application.Commands.MobileIntegrations.PumpBeginFualResponses;
using SpiTech.MppaService.Application.Commands.MobileIntegrations.PumpReserveResponses;
using SpiTech.MppaService.Application.Commands.MobileIntegrations.StacCaptureResponses;
using SpiTech.MppaService.Application.Commands.MobileIntegrations.StacGenerationResponses;
using SpiTech.MppaService.Domain.Models.Mobile;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Hubs
{
    public interface IMppaHubClient
    {
        Task FinalizesData(MobileFinalizesDataResponseCommand response);
        Task FinalReceipt(MobileFinalReceiptResponseCommand response);

        Task PumpBeginFual(MobilePumpBeginFualResponseCommand response);
        Task PumpReserveResponse(MobilePumpReserveResponseCommand response);

        Task ProcessStatusResponse(ProcessStatusResponse response);

        Task PosTransactionDataProcess(MobilePosTransactionDataProcessResponseCommand response);
        Task StacGenerationResponse(MobileStacGenerationResponseCommand response);
        Task StacCaptureResponse(MobileStacCaptureResponseCommand response);

        Task OnError(string errorMessage);
    }
}