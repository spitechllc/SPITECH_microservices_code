﻿using SpiTech.MppaService.Domain.Models;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Hubs
{
    public interface IDashBoardHubClient
    {
        Task DashBoardMessage(DashBoardEventModel response);

        Task Error(string errorMessage);
    }
}