﻿using System;

namespace SpiTech.MppaService.Application.Hubs
{
    public class MppaHubSession
    {
        public int UserId { get; set; }
        public string ConnectionId { get; set; }
        public DateTime ConnectedTime { get; set; }
    }
}
