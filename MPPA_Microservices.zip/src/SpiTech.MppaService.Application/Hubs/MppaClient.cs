﻿using Microsoft.AspNetCore.SignalR;
using SpiTech.Application.Logging.Interfaces;
using Polly;
using Polly.Retry;
using System;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Hubs
{
    public class MppaClient : IMppaClient
    {
        private readonly ILogger<MppaClient> logger;
        private readonly IHubContext<MppaHub, IMppaHubClient> hubContext;
        private readonly HubLifetimeManager<MppaHub> hubLifetimeManager;

        public MppaClient(ILogger<MppaClient> logger, IHubContext<MppaHub, IMppaHubClient> hubContext, HubLifetimeManager<MppaHub> hubLifetimeManager)
        {
            this.logger = logger;
            this.hubContext = hubContext;
            this.hubLifetimeManager = hubLifetimeManager;
        }

        public async Task<IMppaHubClient> Perform(int userId, Func<IMppaHubClient, Task> action)
        {
            int retry = 1;
            IMppaHubClient client = null;

            AsyncRetryPolicy retryPolicy = Policy
                .Handle<Exception>()
                .WaitAndRetryAsync(3, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));

            await retryPolicy.ExecuteAsync(async () =>
            {
                HubConnectionStore store = new HubConnectionStore();
                //var group = hubContext.Clients.Group($"user_{userId}");
                var connections = (hubLifetimeManager as Rebus.SignalR.IRebusHubLifetimeManager).UserConnections.TryGetValue(userId.ToString(), out store);

                var client = hubContext.Clients.User(userId.ToString());

                if (client == null || store == null || store.Count == 0)
                {
                    logger.Warn($"Retry-{retry}, SignalR Connection not found for User-{userId}");

                    if (retry == 3 && client != null)
                    {
                        await action(client);
                    }

                    retry++;
                    throw new Exception($"SignalR Connection not found for User-{userId}");
                }

                await action(client);

            }).ConfigureAwait(false);


            return client;
        }
    }
}
