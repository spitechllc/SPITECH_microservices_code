﻿using System;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Hubs
{
    public interface IDashBoardClient
    {
        Task<IDashBoardHubClient> Perform(int userId, Func<IDashBoardHubClient, Task> action);
    }
}
