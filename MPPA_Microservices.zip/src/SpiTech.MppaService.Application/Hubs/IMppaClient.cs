﻿using System;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Hubs
{
    public interface IMppaClient
    {
        Task<IMppaHubClient> Perform(int userId, Func<IMppaHubClient, Task> action);
    }
}
