﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.AuthRequestsPos;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.PumpReserveCancelRequests;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.PumpReserveRequests;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.StacGenerationRequests;
using SpiTech.MppaService.Application.Processors;
using SpiTech.MppaService.Application.Validators;
using SpiTech.MppaService.Domain.Models.Mobile;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Hubs
{
    [Authorize]
    public class MppaHub : Hub<IMppaHubClient>
    {
        private readonly ILogger<MppaHub> logger;
        private readonly IUserAuthenticationProvider authenticationProvider;
        private readonly IServiceScopeFactory scopeFactory;

        public MppaHub(ILogger<MppaHub> logger,
            IUserAuthenticationProvider authenticationProvider,
            IServiceScopeFactory scopeFactory)
        {
            this.logger = logger;
            this.authenticationProvider = authenticationProvider;
            this.scopeFactory = scopeFactory;
        }

        public async Task PumpReserveRequest(ReserveRequest reserveRequest)
        {
            logger.TraceEnterMethod(nameof(PumpReserveRequest), reserveRequest);

            int userId = authenticationProvider.GetUserAuthentication()?.UserId ?? 0;

            _ = Task.Run(async () =>
             {
                 var isValidRequest = true;
                 var error = "";

                 using IServiceScope scope = scopeFactory.CreateScope();

                 IUserAppMessageLogProcessor userAppMessageLogProcessor = scope.ServiceProvider.GetRequiredService<IUserAppMessageLogProcessor>();

                 FluentValidation.Results.ValidationResult validationResult = await new ReserveRequestValidator().ValidateAsync(reserveRequest);

                 if (!validationResult.IsValid)
                 {
                     isValidRequest = false;
                     error = string.Join(", ", validationResult.Errors.Select(t => t.ErrorMessage).ToArray());
                     await OnError(error);
                 }

                 await userAppMessageLogProcessor.LogRequest(EventBus.DomainEvents.Enums.RequestType.MobilePumpReserve, reserveRequest.SiteId, userId, null, null, error, reserveRequest);

                 if (isValidRequest)
                 {
                     MppaPumpReserveRequestCommand command = new()
                     {
                         UserId = userId,
                         Request = reserveRequest
                     };

                     try
                     {
                         IMobileMessageProcessor mobileMessageProcessor = scope.ServiceProvider.GetRequiredService<IMobileMessageProcessor>();
                         await mobileMessageProcessor.Process(command);
                     }
                     catch (Exception ex)
                     {
                         logger.Error(ex, reserveRequest);
                         await OnError(ex.ToString());
                     }
                 }
             });

            logger.TraceExitMethod(nameof(PumpReserveRequest));
            await Task.CompletedTask;
        }

        public async Task PumpReserveCancelRequest(ReserveCancelRequest reserveCancelRequest)
        {
            logger.TraceEnterMethod(nameof(PumpReserveCancelRequest), reserveCancelRequest);

            int userId = authenticationProvider.GetUserAuthentication()?.UserId ?? 0;

            _ = Task.Run(async () =>
            {
                string error = "";

                using IServiceScope scope = scopeFactory.CreateScope();

                var userAppMessageLogProcessor = scope.ServiceProvider.GetRequiredService<IUserAppMessageLogProcessor>();

                var isValidRequest = await userAppMessageLogProcessor.IsValidRequest(EventBus.DomainEvents.Enums.RequestType.MobileCancel, reserveCancelRequest.UMTI, userId);

                if (!isValidRequest)
                {
                    error = "Cancel already requested for this transaction";
                }

                await userAppMessageLogProcessor.LogRequest(EventBus.DomainEvents.Enums.RequestType.MobileCancel, null, userId, null, reserveCancelRequest.UMTI, error, reserveCancelRequest);

                if (isValidRequest)
                {
                    MppaPumpReserveCancelRequestCommand command = new()
                    {
                        UMTI = reserveCancelRequest.UMTI,
                        UserId = userId
                    };

                    try
                    {
                        var mobileMessageProcessor = scope.ServiceProvider.GetRequiredService<IMobileMessageProcessor>();
                        await mobileMessageProcessor.Process(command);
                    }
                    catch (Exception ex)
                    {
                        logger.Error(ex, reserveCancelRequest);
                        await OnError(ex.ToString());
                    }
                }
            });

            logger.TraceExitMethod(nameof(PumpReserveRequest));
            await Task.CompletedTask;
        }

        public async Task StacGenerationRequest(StacGenerationRequest request)
        {
            logger.TraceEnterMethod(nameof(StacGenerationRequest), request);

            int userId = authenticationProvider.GetUserAuthentication()?.UserId ?? 0;

            _ = Task.Run(async () =>
            {
                var isValidRequest = true;
                var error = "";

                using IServiceScope scope = scopeFactory.CreateScope();


                IUserAppMessageLogProcessor userAppMessageLogProcessor = scope.ServiceProvider.GetRequiredService<IUserAppMessageLogProcessor>();

                FluentValidation.Results.ValidationResult validationResult = await new StacGenerationRequestValidator().ValidateAsync(request);

                if (!validationResult.IsValid)
                {
                    isValidRequest = false;
                    error = string.Join(", ", validationResult.Errors.Select(t => t.ErrorMessage).ToArray());
                    await OnError(error);
                }

                await userAppMessageLogProcessor.LogRequest(EventBus.DomainEvents.Enums.RequestType.MobileStacGenerate, request.SiteId, userId, null, null, error, request);

                if (isValidRequest)
                {
                    StacGenerationRequestCommand command = new()
                    {
                        Request = request,
                        UserId = userId
                    };

                    try
                    {
                        IMobileMessageProcessor mobileMessageProcessor = scope.ServiceProvider.GetRequiredService<IMobileMessageProcessor>();
                        await mobileMessageProcessor.Process(command);
                    }
                    catch (Exception ex)
                    {
                        logger.Error(ex, request);
                        await OnError(ex.ToString());
                    }
                }
            });

            logger.TraceExitMethod(nameof(PumpReserveRequest));
            await Task.CompletedTask;
        }

        public async Task PosTransactionAuthorize(PosTransactionAuthorize request)
        {
            logger.TraceEnterMethod(nameof(StacGenerationRequest), request);

            int userId = authenticationProvider.GetUserAuthentication()?.UserId ?? 0;

            _ = Task.Run(async () =>
            {
                string error = "";

                using IServiceScope scope = scopeFactory.CreateScope();
                IUserAppMessageLogProcessor userAppMessageLogProcessor = scope.ServiceProvider.GetRequiredService<IUserAppMessageLogProcessor>();

                var isValidRequest = await userAppMessageLogProcessor.IsValidRequest(EventBus.DomainEvents.Enums.RequestType.MobileAuth, request.UMTI, userId);

                if (!isValidRequest)
                {
                    error = "Auth already requested for this transaction";
                }
                else
                {
                    FluentValidation.Results.ValidationResult validationResult = await new PosTransactionAuthorizeValidator().ValidateAsync(request);

                    if (!validationResult.IsValid)
                    {
                        isValidRequest = false;
                        error = string.Join(", ", validationResult.Errors.Select(t => t.ErrorMessage).ToArray());
                        await OnError(error);
                    }
                }

                await userAppMessageLogProcessor.LogRequest(EventBus.DomainEvents.Enums.RequestType.MobileAuth, null, userId, null, request.UMTI, error, request);

                if (isValidRequest)
                {
                    MppaAuthRequestCommand command = new()
                    {
                        UserId = userId,
                        Request = request
                    };

                    try
                    {
                        IMobileMessageProcessor mobileMessageProcessor = scope.ServiceProvider.GetRequiredService<IMobileMessageProcessor>();
                        await mobileMessageProcessor.Process(command);
                    }
                    catch (Exception ex)
                    {
                        logger.Error(ex, request);
                        await OnError(ex.ToString());
                    }
                }
            });

            logger.TraceExitMethod(nameof(PumpReserveRequest));
            await Task.CompletedTask;
        }

        public override async Task OnConnectedAsync()
        {
            try
            {
                int userId = authenticationProvider.GetUserAuthentication()?.UserId ?? 0;

                logger.Info($"User with userId - {userId}, Connectionid - {this.Context.ConnectionId} connected");

                //await Groups.AddToGroupAsync(Context.ConnectionId, $"user_{userId}");

                await base.OnConnectedAsync();

            }
            catch (Exception ex)
            {
                logger.Error(ex);
                await Clients.Caller.OnError("OnConnected: " + ex.Message);
            }
        }

        public override async Task OnDisconnectedAsync(Exception exception)
        {
            try
            {
                int userId = authenticationProvider.GetUserAuthentication()?.UserId ?? 0;
                logger.Info($"User with userId - {userId}, Connectionid - {this.Context.ConnectionId} disconnected");
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                await Clients.Caller.OnError("OnDisconnected: " + ex.Message);
            }

            await base.OnDisconnectedAsync(exception);
        }

        private async Task OnError(string errorMessage)
        {
            // create error command in mobileintegration folder
            logger.Warn($"SignalR OnError-ConnectionId-{Context.ConnectionId}={errorMessage}");
            await Clients.Caller.OnError(errorMessage);
        }
    }
}
