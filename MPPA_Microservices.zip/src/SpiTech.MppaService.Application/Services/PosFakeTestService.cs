﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.AuthResponses;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.FinalizeRequests;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.ReceiptDataRequests;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.StacCaptureRequests;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.StacGenerationRequests;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.TransactionDataResponses;
using SpiTech.MppaService.Application.Commands.UpdateGetSite;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models.Commanders.MobileTransactionData;
using System;
using System.Threading.Tasks;
using SaleItem = SpiTech.MppaService.Domain.Models.Commanders.MobileTransactionData.SaleItem;

namespace SpiTech.MppaService.Application.Services
{
    public interface IPosFakeTestService
    {
        Task GenerateFakeCommanderStacResponse(StacGenerationRequestCommand command, StacGeneration stacGeneration);
        Task GenerateFakeCommanderTransactionResponse(Transaction transaction);
        Task GenerateFakeCommanderAuthPosResponse(Transaction transaction);
    }

    public class PosFakeTestService : IPosFakeTestService
    {
        private readonly ILogger<PosFakeTestService> logger;
        private readonly IMediator mediator;
        private readonly HostConfig hostConfig;

        public PosFakeTestService(
                                    ILogger<PosFakeTestService> logger,
                                    IMediator mediator,
                                    HostConfig hostConfig
                                    )
        {
            this.logger = logger;
            this.mediator = mediator;
            this.hostConfig = hostConfig;
        }

        public async Task GenerateFakeCommanderStacResponse(StacGenerationRequestCommand command, StacGeneration stacGeneration)
        {
            if (hostConfig.IsPosTestingEnabled)
            {
                var siteData = await mediator.Send(new UpdateGetSiteCommand { SiteId = command.Request.SiteId });
                await Task.Run(async () =>
                {
                    await Task.Delay(15000);

                    await mediator.Send(new CommanderStacCaptureRequestCommand
                    {
                        StacCaptureRequest = new Domain.Models.Commanders.MobileStacCapture.StacCaptureCommanderRequest
                        {
                            MobileSTACCaptureRequest = new Domain.Models.Commanders.MobileStacCapture.MobileSTACCaptureRequest
                            {
                                RequestAmount = ApplicationCore.Extensions.MathExtension.ToMoney(new Random(1).Next(1, 10) + 0.51M),
                                Stac = StacGenerator.StacWithPrefix(stacGeneration.StacGenerationId),
                            },
                            MobileTxnInfo = new Domain.Models.Commanders.MobileStacCapture.MobileTxnInfoRequest
                            {
                                MerchantId = siteData.MerchantId,
                                POSTransNumber = UniqueIdGenerator.Generate(),
                                SiteId = command.Request.SiteId,
                                SiteMPPAIdentifier = "1",
                                UMTI = Guid.NewGuid().ToString(),
                                TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                                WorkstationId = "POS001"
                            }
                        }
                    });
                });
            }
        }

        public async Task GenerateFakeCommanderTransactionResponse(Transaction transaction)
        {
            Random rnd = new Random();
            var preAuthAmount = Convert.ToDecimal(rnd.Next(1, 15) + "." + rnd.Next(1, 99));

            if (hostConfig.IsPosTestingEnabled)
            {
                await Task.Run(async () =>
                {
                    await Task.Delay(2000);
                    await mediator.Send(new CommanderTransactionDataResponseCommand
                    {
                        TransactionDataResponse = new MobileTransactionDataCommanderResponse
                        {
                            MobileTransactionDataResponse = new MobileTransactionDataResponse
                            {
                                ItemsPurchased = new ItemsPurchased
                                {
                                    SaleItems = new SaleItem[]
                                    {
                                    new SaleItem
                                    {
                                        POSCode="00010000000078",
                                        POSCodeModifier="0",
                                        POSCodeFormat="plu",
                                        ProductCode="500",
                                        OriginalAmount=new Domain.Models.Commanders.ItemAmount{
                                        Amount=preAuthAmount,
                                        UnitPrice=2.00M,
                                        },
                                        AdjustedAmount=new Domain.Models.Commanders.ItemAmount{
                                        Amount=preAuthAmount,
                                        UnitPrice=2.00M,
                                        },
                                        UnitMeasure="EA",
                                        Quantity=1,
                                        Description="SAUSAGE PATTY",
                                        SellingUnits=1,
                                        ItemId="1",
                                        OutdoorPosition="6",
                                        AdditionalProductInfo="",
                                        ServiceLevel="",
                                        PriceTier="",
                                        ItemStatus=""
                                    }
                                    }
                                },
                                PaymentInfo = new PaymentInfo
                                {
                                    PreAuthAmount = preAuthAmount,
                                    FinalAmount = preAuthAmount,
                                },
                                Response = new Domain.Models.Commanders.Response
                                {
                                    MessageCode = "Success",
                                    OverallResult = "Success",
                                    ResponseCode = "00000"
                                }
                            },
                            MobileTxnInfo = new Domain.Models.Commanders.MobileTransactionData.MobileTxnInfoResponse
                            {
                                MerchantId = transaction.MerchantId,
                                POSTransNumber = transaction.POSTransNumber,
                                SiteId = transaction.SiteId,
                                SiteMPPAIdentifier = transaction.SiteMPPAIdentifier,
                                UMTI = transaction.UMTI,
                                TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                                WorkstationId = transaction.WorkstationId
                            }
                        }
                    });
                });
            }
        }

        public async Task GenerateFakeCommanderAuthPosResponse(Transaction transaction)
        {
            if (hostConfig.IsPosTestingEnabled)
            {
                await Task.Run(async () =>
                {
                    await Task.Delay(10000);

                    await mediator.Send(new CommanderAuthResponseCommand
                    {
                        AuthResponse = new Domain.Models.Commanders.MobileAuths.AuthCommanderResponse
                        {
                            MobileTxnInfo = new SpiTech.MppaService.Domain.Models.Commanders.MobileAuths.MobileTxnInfoResponse
                            {
                                MerchantId = transaction.MerchantId,
                                POSTransNumber = transaction.POSTransNumber,
                                SiteId = transaction.SiteId,
                                UMTI = transaction.UMTI,
                                TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                                SiteMPPAIdentifier = "1"
                            },
                            MobileAuthResponse = new Domain.Models.Commanders.MobileResponse
                            {
                                Response = new Domain.Models.Commanders.Response
                                {
                                    ResponseCode = Constants.SuccessResponseCode,
                                    MessageCode = Constants.SuccessMessageCode,
                                    OverallResult = Constants.SuccessOverallResult,
                                }
                            }
                        },
                    });

                    await Task.Delay(10000);

                    await mediator.Send(new CommanderFinalizeRequestCommand
                    {
                        FinalizeRequest = new Domain.Models.Commanders.MobileFinalizes.FinalizeCommanderRequest
                        {
                            MobileTxnInfo = new Domain.Models.Commanders.MobileFinalizes.MobileTxnInfoRequest
                            {
                                MerchantId = transaction.MerchantId,
                                POSTransNumber = transaction.POSTransNumber,
                                SiteId = transaction.SiteId,
                                UMTI = transaction.UMTI,
                                TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                                SiteMPPAIdentifier = "1"
                            },
                            MobileFinalizeRequest = new Domain.Models.Commanders.MobileFinalizes.MobileFinalizeRequest
                            {
                                ItemsPurchased = new Domain.Models.Commanders.ItemsPurchased
                                {
                                    SaleItems = new SpiTech.MppaService.Domain.Models.Commanders.SaleItem[]
                                    {
                                        new SpiTech.MppaService.Domain.Models.Commanders.SaleItem
                                    {
                                        POSCode="00010000000078",
                                        POSCodeModifier="0",
                                        POSCodeFormat="plu",
                                        ProductCode="500",
                                        OriginalAmount=new Domain.Models.Commanders.ItemAmount{
                                        Amount=2.00M,
                                        UnitPrice=2.00M,
                                        },
                                        AdjustedAmount=new Domain.Models.Commanders.ItemAmount{
                                        Amount=2.00M,
                                        UnitPrice=2.00M,
                                        },
                                        UnitMeasure="EA",
                                        Quantity=1,
                                        Description="SAUSAGE PATTY",
                                        ItemId="1",
                                        OutdoorPosition="6",
                                        AdditionalProductInfo="",
                                        ServiceLevel="",
                                        PriceTier="",
                                        ItemStatus="true",
                                        EvaluateOnly=false,
                                        PriceChangeEligible="false"
                                    }
                                    }
                                },
                                PaymentInfo = new Domain.Models.Commanders.MobileFinalizes.PaymentInfo
                                {
                                    PaymentMethod = "Credit",
                                    FinalAmount = transaction.PreauthAmount,
                                    HostAuthNumber = "01"
                                }
                            }
                        }
                    });

                    await Task.Delay(10000);

                    await mediator.Send(new CommanderReceiptDataRequestCommand
                    {
                        ReceiptDataRequest = new Domain.Models.Commanders.MobileReceiptData.ReceiptDataCommanderRequest
                        {
                            MobileTxnInfo = new Domain.Models.Commanders.MobileReceiptData.MobileTxnInfoRequest
                            {
                                MerchantId = transaction.MerchantId,
                                POSTransNumber = transaction.POSTransNumber,
                                SiteId = transaction.SiteId,
                                UMTI = transaction.UMTI,
                                TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                                SiteMPPAIdentifier = "1"
                            },
                            MobileReceiptDataRequest = new Domain.Models.Commanders.MobileReceiptData.MobileReceiptDataRequest
                            {
                                ItemsPurchased = new Domain.Models.Commanders.ItemsPurchased
                                {
                                    SaleItems = new SpiTech.MppaService.Domain.Models.Commanders.SaleItem[]
                                    {
                                        new SpiTech.MppaService.Domain.Models.Commanders.SaleItem
                                    {
                                        POSCode="00010000000078",
                                        POSCodeModifier="0",
                                        POSCodeFormat="plu",
                                        ProductCode="500",
                                        OriginalAmount=new Domain.Models.Commanders.ItemAmount{
                                        Amount=transaction.PreauthAmount,
                                        UnitPrice=transaction.PreauthAmount,
                                        },
                                        AdjustedAmount=new Domain.Models.Commanders.ItemAmount{
                                        Amount=transaction.PreauthAmount,
                                        UnitPrice=transaction.PreauthAmount,
                                        },
                                        UnitMeasure="EA",
                                        Quantity=1,
                                        Description="Baby Back Ribs",
                                        ItemId="1",
                                        OutdoorPosition="6",
                                        AdditionalProductInfo="",
                                        ServiceLevel="",
                                        PriceTier="",
                                        ItemStatus="true",
                                        EvaluateOnly=false,
                                        PriceChangeEligible="false"
                                    }
                                    }
                                },
                                ReceiptInfo = new Domain.Models.Commanders.MobileReceiptData.ReceiptInfo
                                {
                                    ReceiptLines = new string[] {
                                    $"          {transaction.StoreName}          ",
                                    "",
                                    $"{transaction.StoreName}",
                                    "1408 S FRETZ AVE",
                                    "EDMOND OK  73003",
                                    $"{transaction.SiteId}",
                                    "",
                                    "",
                                    "           11/11/22 3:20:07 AM",
                                    "    Register: 1 Trans #: 405 Op ID: 91",
                                    "            Your cashier: Area",
                                    "",
                                    "Baby Back Ribs                   $4.99  99",
                                    "                            ----------    ",
                                    $"                   Subtotal =    ${transaction.PreauthAmount}    ",
                                    "                       Tax  =    $0.00    ",
                                    "                            ----------    ",
                                    $"                      Total =    ${transaction.PreauthAmount}    ",
                                    "",
                                    "                Change Due  =    $0.00    ",
                                    "",
                                    $"Mobile                           ${transaction.PreauthAmount}    ",
                                    "  --------------------------------------",
                                    "MOBILE",
                                    "SITE ID: UL340820196001",
                                    " Credit",
                                    "411111******1111",
                                    "AUTH: 01",
                                    "INVOICE: 0000009593",
                                    "  --------------------------------------",
                                    "",
                                    "",
                                    "",
                                    "             Boomer Sooner!             ",
                                    "",
                                    "",
                                    "",
                                    "",
                                    "",
                                    "",
                                    "",
                                    }
                                }
                            }
                        }
                    });
                });
            }
        }

    }
}
