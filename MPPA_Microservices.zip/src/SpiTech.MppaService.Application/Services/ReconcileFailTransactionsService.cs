﻿using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.Commands.ReconcileFailTransactions;
using SpiTech.MppaService.Domain;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Services
{
    public class ReconcileFailTransactionsService : BackgroundService
    {
        protected readonly ILogger<ReconcileFailTransactionsService> logger;
        protected readonly IServiceProvider serviceProvider;
        private readonly IServiceScope serviceScope;

        public ReconcileFailTransactionsService(ILogger<ReconcileFailTransactionsService> logger, IServiceProvider serviceProvider)
        {
            this.logger = logger;
            this.serviceProvider = serviceProvider;
            serviceScope = serviceProvider.CreateScope();
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                while (!stoppingToken.IsCancellationRequested)
                {
                    var mediator = serviceScope.ServiceProvider.GetService<IMediator>();
                    var hostConfig = serviceScope.ServiceProvider.GetService<HostConfig>();

                    await mediator.Send(new ReconcileFailTransactionsCommand { TransactionTimeoutInSec = hostConfig.TransactionTimeoutInSec }, stoppingToken);
                    await Task.Delay(TimeSpan.FromSeconds(hostConfig.FailTransReconcileExecInSec));
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex, $"Error at: {DateTimeOffset.Now}");
            }
        }
    }
}
