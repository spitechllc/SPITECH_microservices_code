﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.AuthResponses;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.BeginFuelingRequests;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.FinalizeRequests;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.PumpReserveResponses;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.ReceiptDataRequests;
using SpiTech.MppaService.Application.Processors;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models.Commanders.BeginFueling;
using SpiTech.MppaService.Domain.Models.Commanders.MobilePumpReserves;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Services
{
    public interface IPayAtPumpFakeTestService
    {
        Task GenerateFakeCommanderPumpReserveResponse(Transaction transaction);

        Task GenerateFakeCommanderAuthResponse(Transaction transaction);

        Task GenerateFakeCommanderBeginFueling(Transaction transaction);

        Task GenerateFakeCommanderFinalizeRequest(Transaction transaction);

        Task GenerateFakeCommanderReceiptDataRequest(Transaction transaction);
    }

    public class PayAtPumpFakeTestService : IPayAtPumpFakeTestService
    {
        private readonly ILogger<PayAtPumpFakeTestService> logger;
        private readonly IMediator mediator;
        private readonly HostConfig hostConfig;

        public PayAtPumpFakeTestService(
                                    ILogger<PayAtPumpFakeTestService> logger,
                                    IMediator mediator,
                                    HostConfig hostConfig)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.hostConfig = hostConfig;
        }

        public async Task GenerateFakeCommanderPumpReserveResponse(Transaction transaction)
        {
            if (hostConfig.IsPayAtPumpTestingEnabled)
            {
                await Task.Run(async () =>
                {
                    await Task.Delay(10000);

                    await mediator.Send(new CommanderPumpReserveResponseCommand
                    {
                        PumpReserveCommanderResponse = new PumpReserveCommanderResponse
                        {
                            MobilePumpReserveResponse = new Domain.Models.Commanders.MobileResponse
                            {
                                Response = new Domain.Models.Commanders.Response
                                {
                                    ResponseCode = Constants.SuccessResponseCode,
                                    MessageCode = Constants.SuccessMessageCode,
                                    OverallResult = Constants.SuccessOverallResult,
                                }
                            },
                            MobileTxnInfo = new Domain.Models.Commanders.MobilePumpReserves.MobileTxnInfoResponse
                            {
                                MerchantId = transaction.MerchantId,
                                POSTransNumber = UniqueIdGenerator.Generate(),
                                SiteId = transaction.SiteId,
                                UMTI = transaction.UMTI,
                                TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                                SiteMPPAIdentifier = "1"
                            }
                        }
                    });

                    await Task.Delay(10000);
                });
            }
        }

        public async Task GenerateFakeCommanderAuthResponse(Transaction transaction)
        {
            if (hostConfig.IsPayAtPumpTestingEnabled)
            {
                await Task.Run(async () =>
                {
                    await Task.Delay(10000);

                    await mediator.Send(new CommanderAuthResponseCommand
                    {
                        AuthResponse = new Domain.Models.Commanders.MobileAuths.AuthCommanderResponse
                        {
                            MobileTxnInfo = new Domain.Models.Commanders.MobileAuths.MobileTxnInfoResponse
                            {
                                UMTI = transaction.UMTI,
                                MerchantId = transaction.MerchantId,
                                TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                                SiteId = transaction.SiteId,
                                POSTransNumber = transaction.POSTransNumber,
                                FuelingPositionId = transaction.FuelingPositionId ?? 0,
                                SiteMPPAIdentifier = transaction.SiteMPPAIdentifier
                            },
                            MobileAuthResponse = new Domain.Models.Commanders.MobileResponse
                            {
                                Response = new Domain.Models.Commanders.Response
                                {
                                    ResponseCode = Constants.SuccessResponseCode,
                                    MessageCode = Constants.SuccessMessageCode,
                                    OverallResult = Constants.SuccessOverallResult,
                                }
                            }
                        },
                    });

                    await Task.Delay(10000);
                });

                await this.GenerateFakeCommanderBeginFueling(transaction);
            }
        }

        public async Task GenerateFakeCommanderBeginFueling(Transaction transaction)
        {
            if (hostConfig.IsPayAtPumpTestingEnabled)
            {
                await Task.Run(async () =>
                {
                    await Task.Delay(10000);

                    await mediator.Send(new CommanderBeginFuelingRequestCommand
                    {
                        BeginFuelingRequest = new BeginFuelingCommanderRequest
                        {
                            MobileTxnInfo = new Domain.Models.Commanders.BeginFueling.MobileTxnInfoRequest
                            {
                                UMTI = transaction.UMTI,
                                MerchantId = transaction.MerchantId,
                                TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                                SiteId = transaction.SiteId,
                                POSTransNumber = transaction.POSTransNumber,
                                FuelingPositionId = transaction.FuelingPositionId ?? 0,
                                SiteMPPAIdentifier = transaction.SiteMPPAIdentifier
                            },
                            MobileBeginFuelingRequest = new MobileBeginFuelingRequest
                            {
                                BeginFuelMessage = "Fueling Started",
                            }
                        }
                    });

                    await Task.Delay(10000);
                });
            }
        }

        public async Task GenerateFakeCommanderFinalizeRequest(Transaction transaction)
        {
            if (hostConfig.IsPosTestingEnabled)
            {
                await Task.Run(async () =>
                {
                    await Task.Delay(10000);

                    await mediator.Send(new CommanderFinalizeRequestCommand
                    {
                        FinalizeRequest = new Domain.Models.Commanders.MobileFinalizes.FinalizeCommanderRequest
                        {
                            MobileFinalizeRequest = new Domain.Models.Commanders.MobileFinalizes.MobileFinalizeRequest
                            {
                                ItemsPurchased = new Domain.Models.Commanders.ItemsPurchased
                                {
                                    SaleItems = new Domain.Models.Commanders.SaleItem[]
                                    {
                                        new Domain.Models.Commanders.SaleItem
                                        {
                                            POSCode="00010000000078",
                                            POSCodeModifier="0",
                                            POSCodeFormat="plu",
                                            ProductCode="500",
                                            OriginalAmount=new Domain.Models.Commanders.ItemAmount{
                                            Amount=transaction.PreauthAmount,
                                            UnitPrice=2.00M,
                                            },
                                            AdjustedAmount=new Domain.Models.Commanders.ItemAmount{
                                            Amount=transaction.PreauthAmount,
                                            UnitPrice=2.00M,
                                            },
                                            UnitMeasure="EA",
                                            Quantity=1,
                                            Description="REGULAR",
                                            ItemId="1",
                                            OutdoorPosition="6",
                                            AdditionalProductInfo="",
                                            ServiceLevel="",
                                            PriceTier="",
                                            ItemStatus="true",
                                            EvaluateOnly=false,
                                            PriceChangeEligible="false"
                                        }
                                    }
                                },
                                PaymentInfo = new Domain.Models.Commanders.MobileFinalizes.PaymentInfo
                                {
                                    PaymentMethod = "Credit",
                                    FinalAmount = transaction.PreauthAmount,
                                    HostAuthNumber = "01"
                                }
                            },
                            MobileTxnInfo = new Domain.Models.Commanders.MobileFinalizes.MobileTxnInfoRequest
                            {
                                UMTI = transaction.UMTI,
                                MerchantId = transaction.MerchantId,
                                TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                                SiteId = transaction.SiteId,
                                POSTransNumber = transaction.POSTransNumber,
                                FuelingPositionId = (transaction.FuelingPositionId ?? 0).ToString(),
                                SiteMPPAIdentifier = transaction.SiteMPPAIdentifier
                            }
                        },
                    });
                });

                await Task.Delay(10000);

                await this.GenerateFakeCommanderReceiptDataRequest(transaction);
            }
        }

        public async Task GenerateFakeCommanderReceiptDataRequest(Transaction transaction)
        {
            if (hostConfig.IsPosTestingEnabled)
            {
                await Task.Run(async () =>
                {
                    await Task.Delay(10000);

                    await mediator.Send(new CommanderReceiptDataRequestCommand
                    {
                        ReceiptDataRequest = new Domain.Models.Commanders.MobileReceiptData.ReceiptDataCommanderRequest
                        {
                            MobileTxnInfo = new Domain.Models.Commanders.MobileReceiptData.MobileTxnInfoRequest
                            {
                                UMTI = transaction.UMTI,
                                MerchantId = transaction.MerchantId,
                                TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                                SiteId = transaction.SiteId,
                                POSTransNumber = transaction.POSTransNumber,
                                FuelingPositionId = (transaction.FuelingPositionId ?? 0).ToString(),
                                SiteMPPAIdentifier = transaction.SiteMPPAIdentifier
                            },
                            MobileReceiptDataRequest = new Domain.Models.Commanders.MobileReceiptData.MobileReceiptDataRequest
                            {
                                ItemsPurchased = new Domain.Models.Commanders.ItemsPurchased
                                {
                                    SaleItems = new Domain.Models.Commanders.SaleItem[]
                                    {
                                        new Domain.Models.Commanders.SaleItem
                                        {
                                            POSCode="00010000000078",
                                            POSCodeModifier="0",
                                            POSCodeFormat="plu",
                                            ProductCode="500",
                                            OriginalAmount=new Domain.Models.Commanders.ItemAmount{
                                            Amount=transaction.PreauthAmount,
                                            UnitPrice=2.00M,
                                            },
                                            AdjustedAmount=new Domain.Models.Commanders.ItemAmount{
                                            Amount=transaction.PreauthAmount,
                                            UnitPrice=2.00M,
                                            },
                                            UnitMeasure="EA",
                                            Quantity=1,
                                            Description="REGULAR",
                                            ItemId="1",
                                            OutdoorPosition="6",
                                            AdditionalProductInfo="",
                                            ServiceLevel="",
                                            PriceTier="",
                                            ItemStatus="true",
                                            EvaluateOnly=false,
                                            PriceChangeEligible="false"
                                        }
                                    }
                                },
                                ReceiptInfo = new Domain.Models.Commanders.MobileReceiptData.ReceiptInfo
                                {
                                    ReceiptLines = new string[] {
                                    "      WELCOME       ",
                                    $"  {transaction.StoreName}   ",
                                    "       STORE        ",
                                    "",
                                    "     248 HWY 50     ",
                                    "     ROSEBUD MO     ",
                                    "       63091        ",
                                    "",
                                    "DATE 5/23/23 20:19",
                                    $"TRAN# {transaction.POSTransNumber}",
                                    "PUMP# 01",
                                    "SERVICE LEVEL: SELF ",
                                    "PRODUCT: UNLD      ",
                                    "GALLONS:      10.936",
                                    "PRICE/G:      $3.099",
                                    "FUEL SALE     $"+transaction.PreauthAmount,
                                    "   MOBILE     $"+transaction.PreauthAmount,
                                    "",
                                    "MOBILE",
                                    "mastercard",
                                    "CREDIT",
                                    "************2848",
                                    "AUTH #: 01",
                                    "",
                                    "",
                                    "     THANK YOU      ",
                                    "  HAVE A NICE DAY   "
                                    }
                                }
                            }
                        }
                    });
                });
            }
        }

    }
}
