﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using SpiTech.MppaService.Application.Interfaces.HostServers;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Services
{
    public class MppaHostedService : BackgroundService
    {
        private readonly IConfiguration configuration;
        private readonly ILogger<MppaHostedService> logger;
        private readonly IServiceScope serviceScope;
        private IMppaServer MppaServer;
        public MppaHostedService(IServiceScopeFactory scopeFactory,
                                IConfiguration configuration,
                                ILogger<MppaHostedService> logger)
        {
            serviceScope = scopeFactory.CreateScope();
            this.configuration = configuration;
            this.logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                logger.LogInformation($"Server starting");
                await StartMppaServer();
            }
            catch (Exception ex)
            {
                await StartMppaServer();
                logger.LogError(ex, ex.Message);
                logger.LogWarning($"Some Error occure during Server start please check the log and restart server");
            }
        }

        private async Task StartMppaServer()
        {
            MppaServer = serviceScope.ServiceProvider.GetService<IMppaServer>();
            MppaServer.Start();
            logger.LogInformation($"Server started");

            await Task.CompletedTask;
        }
    }
}
