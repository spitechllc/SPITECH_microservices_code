﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Entities;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetSiteProduct
{
    public class GetSiteProductHandler : IRequestHandler<GetSiteProductQuery, IEnumerable<SiteProduct>>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetSiteProductHandler> _logger;
        private readonly IMapper _mapper;
        public GetSiteProductHandler(IUnitOfWork context,
                                   ILogger<GetSiteProductHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<IEnumerable<SiteProduct>> Handle(GetSiteProductQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            IEnumerable<SiteProduct> result = await _context.SiteProducts.GetAll();
            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
