﻿using MediatR;
using SpiTech.MppaService.Domain.Entities;
using System.Collections.Generic;

namespace SpiTech.MppaService.Application.Queries.GetSiteProduct
{
    public class GetSiteProductQuery : IRequest<IEnumerable<SiteProduct>>
    {
        public int SiteId { get; set; }
    }
}
