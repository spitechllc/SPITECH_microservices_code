﻿using MediatR;
using SpiTech.MppaService.Domain.Entities;

namespace SpiTech.MppaService.Application.Queries.GetTransactionByUmtiMId
{
    public class GetTransactionByUmtiMIdQuery : IRequest<Transaction>
    {
        public string UMTI { get; set; }
        public string MerchantId { get; set; }
    }
}
