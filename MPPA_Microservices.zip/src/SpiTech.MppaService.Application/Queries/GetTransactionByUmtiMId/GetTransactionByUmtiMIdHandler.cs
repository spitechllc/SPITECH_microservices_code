﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetTransactionByUmtiMId
{
    public class GetTransactionByUmtiMIdHandler : IRequestHandler<GetTransactionByUmtiMIdQuery, Transaction>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetTransactionByUmtiMIdHandler> _logger;
        private readonly IMapper _mapper;
        public GetTransactionByUmtiMIdHandler(IUnitOfWork context,
                                   ILogger<GetTransactionByUmtiMIdHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<Transaction> Handle(GetTransactionByUmtiMIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            var result = await _context.Transactions.GetByUMTI(request.UMTI, request.MerchantId);

            _logger.TraceExitMethod(nameof(Handle), request);

            return result;
        }
    }
}
