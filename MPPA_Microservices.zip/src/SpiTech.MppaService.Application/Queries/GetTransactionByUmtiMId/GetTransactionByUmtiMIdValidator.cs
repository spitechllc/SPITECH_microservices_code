﻿using FluentValidation;

namespace SpiTech.MppaService.Application.Queries.GetTransactionByUmtiMId
{
    public class GetTransactionByUmtiMIdValidator : AbstractValidator<GetTransactionByUmtiMIdQuery>
    {
        public GetTransactionByUmtiMIdValidator()
        {
        }
    }
}
