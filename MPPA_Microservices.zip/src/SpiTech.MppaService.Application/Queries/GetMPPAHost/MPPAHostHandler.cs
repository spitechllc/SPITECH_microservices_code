﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Models;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetMPPAHost
{
    public class MPPAHostHandler : IRequestHandler<MPPAHostQuery, HostMPPAModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<MPPAHostHandler> _logger;
        private readonly IMapper _mapper;
        public MPPAHostHandler(IUnitOfWork context,
                                   ILogger<MPPAHostHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<HostMPPAModel> Handle(MPPAHostQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            HostMPPAModel result = _mapper.Map<HostMPPAModel>((await _context.HostMPPAs.GetAll()).FirstOrDefault());

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
