﻿using MediatR;
using SpiTech.MppaService.Domain.Models;

namespace SpiTech.MppaService.Application.Queries.GetMPPAHost
{
    public class MPPAHostQuery : IRequest<HostMPPAModel>
    {
    }
}
