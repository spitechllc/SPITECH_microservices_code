﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetSiteProductBySiteId
{
    public class GetSiteProductBySiteIdHandler : IRequestHandler<GetSiteProductBySiteIdQuery, IEnumerable<SiteProduct>>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetSiteProductBySiteIdHandler> _logger;
        private readonly IMapper _mapper;
        public GetSiteProductBySiteIdHandler(IUnitOfWork context,
                                   ILogger<GetSiteProductBySiteIdHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<IEnumerable<SiteProduct>> Handle(GetSiteProductBySiteIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            IEnumerable<SiteProduct> result = await _context.SiteProducts.GetSiteProducts(request.SiteId);

            if (result != null && result.Any())
            {
                foreach (var item in result)
                {
                    item.OriginalAmountUnitPrice = MathExtension.TruncateTwoDecimal(item.OriginalAmountUnitPrice ?? 0);
                    item.AdjustedAmount = MathExtension.TruncateTwoDecimal(item.AdjustedAmount ?? 0);
                    item.AdjustedAmountUnitPrice = MathExtension.TruncateTwoDecimal(item.AdjustedAmountUnitPrice ?? 0);
                    item.OriginalAmount = MathExtension.TruncateTwoDecimal(item.OriginalAmount ?? 0);
                }
            }
            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
