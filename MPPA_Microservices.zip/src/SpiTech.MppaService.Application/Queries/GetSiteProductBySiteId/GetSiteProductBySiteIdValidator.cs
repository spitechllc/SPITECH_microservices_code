﻿using FluentValidation;

namespace SpiTech.MppaService.Application.Queries.GetSiteProductBySiteId
{
    public class GetSiteProductBySiteIdValidator : AbstractValidator<GetSiteProductBySiteIdQuery>
    {
        public GetSiteProductBySiteIdValidator()
        {
            RuleFor(x => x.SiteId).NotNull().WithMessage("Site Id can not be null");
        }
    }
}
