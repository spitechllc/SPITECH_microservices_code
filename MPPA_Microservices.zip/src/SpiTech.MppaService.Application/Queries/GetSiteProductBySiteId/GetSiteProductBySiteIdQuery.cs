﻿using MediatR;
using SpiTech.MppaService.Domain.Entities;
using System.Collections.Generic;

namespace SpiTech.MppaService.Application.Queries.GetSiteProductBySiteId
{
    public class GetSiteProductBySiteIdQuery : IRequest<IEnumerable<SiteProduct>>
    {
        public string SiteId { get; set; }
    }
}
