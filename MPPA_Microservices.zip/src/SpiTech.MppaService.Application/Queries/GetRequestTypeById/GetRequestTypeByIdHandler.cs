﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetRequestTypeById
{
    public class GetRequestTypeByIdHandler : IRequestHandler<GetRequestTypeByIdQuery, RequestTypeModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetRequestTypeByIdHandler> _logger;
        private readonly IMapper _mapper;
        public GetRequestTypeByIdHandler(IUnitOfWork context,
                                   ILogger<GetRequestTypeByIdHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<RequestTypeModel> Handle(GetRequestTypeByIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            RequestTypeModel result = _mapper.Map<RequestTypeModel>(await _context.RequestTypes.Get(request.TrasactionTypeId));
            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
