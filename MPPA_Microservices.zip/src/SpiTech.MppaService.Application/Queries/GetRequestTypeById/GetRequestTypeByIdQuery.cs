﻿using MediatR;
using SpiTech.MppaService.Domain.Models;

namespace SpiTech.MppaService.Application.Queries.GetRequestTypeById
{
    public class GetRequestTypeByIdQuery : IRequest<RequestTypeModel>
    {
        public int TrasactionTypeId { get; set; }
    }
}
