﻿using FluentValidation;

namespace SpiTech.MppaService.Application.Queries.GetRequestTypeById
{
    public class GetRequestTypeByIdValidator : AbstractValidator<GetRequestTypeByIdQuery>
    {
        public GetRequestTypeByIdValidator()
        {
            RuleFor(x => x.TrasactionTypeId).GreaterThan(0).WithMessage("TrasactionTypeId must be greater than 0");
        }
    }
}
