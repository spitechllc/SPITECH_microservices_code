﻿using MediatR;
using SpiTech.MppaService.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.MppaService.Application.Queries.GetSiteStatuses
{
    public class GetSiteStatusesQuery : IRequest<List<SiteModel>>
    {
        public int HeartBeatInterval { get; set; }
        public bool? OnlineOnly { get; set; }
    }
}
