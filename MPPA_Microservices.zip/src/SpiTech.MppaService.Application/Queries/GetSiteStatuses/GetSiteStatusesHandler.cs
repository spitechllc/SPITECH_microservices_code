﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.Interfaces.HostServers;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetSiteStatuses
{
    public class GetSiteStatusesHandler : IRequestHandler<GetSiteStatusesQuery, List<SiteModel>>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetSiteStatusesHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IMppaServer mppaServer;

        public GetSiteStatusesHandler(IUnitOfWork context,
                                   ILogger<GetSiteStatusesHandler> logger,
                                   IMapper mapper,
                                   IMppaServer mppaServer)
        {
            this.context = context;
            _logger = logger;
            _mapper = mapper;
            this.mppaServer = mppaServer;
        }
        public async Task<List<SiteModel>> Handle(GetSiteStatusesQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            List<SiteModel> sites = await context.Sites.GetSites(null);

            if (sites != null && sites.Any())
            {
                foreach (var site in sites)
                {
                    site.IsOnline = site.CurrentHeartBeatTime.HasValue && (DateTime.UtcNow - site.CurrentHeartBeatTime.Value).TotalSeconds < request.HeartBeatInterval;
                }
            }

            _logger.TraceExitMethod(nameof(Handle), sites);

            if (request.OnlineOnly.HasValue)
            {
                return sites.Where(t => t.IsOnline == request.OnlineOnly.Value).ToList();
            }

            return sites;
        }
    }
}
