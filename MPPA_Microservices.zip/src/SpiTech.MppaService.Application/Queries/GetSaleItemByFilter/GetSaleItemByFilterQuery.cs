﻿using MediatR;
using SpiTech.MppaService.Domain.Entities;
using System.Collections.Generic;

namespace SpiTech.MppaService.Application.Queries.GetSaleItemByFilter
{
    public class GetSaleItemByFilterQuery : IRequest<IEnumerable<SaleItem>>
    {
        public long TransactionId { get; set; }
    }
}
