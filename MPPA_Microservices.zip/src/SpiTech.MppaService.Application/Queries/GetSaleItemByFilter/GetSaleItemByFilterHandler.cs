﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Entities;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetSaleItemByFilter
{
    public class GetSaleItemByFilterHandler : IRequestHandler<GetSaleItemByFilterQuery, IEnumerable<SaleItem>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetSaleItemByFilterHandler> _logger;
        private readonly IMapper _mapper;

        public GetSaleItemByFilterHandler(IUnitOfWork context,
                                             ILogger<GetSaleItemByFilterHandler> logger,
                                             IMapper mapper
                                           )
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<IEnumerable<SaleItem>> Handle(GetSaleItemByFilterQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            List<SaleItem> result = await _context.SaleItems.GetSaleItemByfilter(request.TransactionId);

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}