﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Domain.Models;

namespace SpiTech.MppaService.Application.Queries.GetGasPumpByStoreId
{
    public class GetGasPumpByStoreIdQuery : IRequest<ResponseList<GasPumpModel>>
    {
        public int StoreId { get; set; }
    }
}
