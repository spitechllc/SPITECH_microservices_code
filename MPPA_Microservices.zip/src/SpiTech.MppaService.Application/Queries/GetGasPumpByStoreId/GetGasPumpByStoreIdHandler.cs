﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetGasPumpByStoreId
{
    public class GetGasPumpByStoreIdHandler : IRequestHandler<GetGasPumpByStoreIdQuery, ResponseList<GasPumpModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetGasPumpByStoreIdHandler> _logger;
        private readonly IMapper _mapper;

        public GetGasPumpByStoreIdHandler(IUnitOfWork context,
                                   ILogger<GetGasPumpByStoreIdHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<ResponseList<GasPumpModel>> Handle(GetGasPumpByStoreIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<GasPumpModel> result = _mapper.Map<IEnumerable<GasPumpModel>>(await _context.GasPumps.GetByStoreId(request.StoreId));
            _logger.TraceExitMethod(nameof(Handle), result);

            return new ResponseList<GasPumpModel>() { Data = result };
        }
    }
}
