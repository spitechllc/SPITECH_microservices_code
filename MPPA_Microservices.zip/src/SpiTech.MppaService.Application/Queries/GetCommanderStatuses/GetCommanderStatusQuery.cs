﻿using MediatR;
using SpiTech.MppaService.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.MppaService.Application.Queries.GetCommanderStatuses
{
    public class GetCommanderStatusesQuery : IRequest<List<SiteModel>>
    {
        public int HeartBeatInterval { get; set; }
        public string[] SiteIds { get; set; }
    }
}
