﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.Interfaces.HostServers;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetCommanderStatuses
{
    public class GetCommanderStatusesHandler : IRequestHandler<GetCommanderStatusesQuery, List<SiteModel>>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetCommanderStatusesHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IMppaServer mppaServer;

        public GetCommanderStatusesHandler(IUnitOfWork context,
                                   ILogger<GetCommanderStatusesHandler> logger,
                                   IMapper mapper,
                                   IMppaServer mppaServer)
        {
            this.context = context;
            _logger = logger;
            _mapper = mapper;
            this.mppaServer = mppaServer;
        }
        public async Task<List<SiteModel>> Handle(GetCommanderStatusesQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            _logger.Warn($"MPPA GetCommanderStatusesQuery start");

            List<SiteModel> sites = await context.Sites.GetSites(request.SiteIds);

            if (sites != null && sites.Any())
            {
                _logger.Warn($"MPPA GetCommanderStatusesQuery site comming");

                foreach (var site in sites)
                {
                    site.IsOnline = site.CurrentHeartBeatTime.HasValue && (DateTime.UtcNow - site.CurrentHeartBeatTime.Value).TotalSeconds < request.HeartBeatInterval;
                }
            }

            _logger.TraceExitMethod(nameof(Handle), sites);
            _logger.Warn($"MPPA GetCommanderStatusesQuery end");
            return sites;
        }
    }
}
