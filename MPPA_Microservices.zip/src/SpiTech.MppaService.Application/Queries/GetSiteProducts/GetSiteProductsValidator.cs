﻿using FluentValidation;

namespace SpiTech.MppaService.Application.Queries.GetSiteProducts
{
    public class GetSiteProductsValidator : AbstractValidator<GetSiteProductsQuery>
    {
        public GetSiteProductsValidator()
        {
            RuleFor(x => x.SiteIds).NotNull().NotEmpty().WithMessage("Site Ids can not be null or empty");
        }
    }
}
