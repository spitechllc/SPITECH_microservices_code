﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetSiteProducts
{
    public class GetSiteProductsHandler : IRequestHandler<GetSiteProductsQuery, IEnumerable<SiteProductModel>>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetSiteProductsHandler> _logger;
        private readonly IMapper _mapper;
        public GetSiteProductsHandler(IUnitOfWork context,
                                   ILogger<GetSiteProductsHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<IEnumerable<SiteProductModel>> Handle(GetSiteProductsQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            IEnumerable<SiteProductModel> result = await _context.SiteProducts.GetSiteProducts(request.SiteIds);

            if (result != null && result.Any())
            {
                foreach (var item in result)
                {
                    item.OriginalAmountUnitPrice = MathExtension.TruncateTwoDecimal(item.OriginalAmountUnitPrice ?? 0);
                }
            }

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
