﻿using MediatR;
using SpiTech.MppaService.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.MppaService.Application.Queries.GetSiteProducts
{
    public class GetSiteProductsQuery : IRequest<IEnumerable<SiteProductModel>>
    {
        public string[] SiteIds { get; set; }
    }
}
