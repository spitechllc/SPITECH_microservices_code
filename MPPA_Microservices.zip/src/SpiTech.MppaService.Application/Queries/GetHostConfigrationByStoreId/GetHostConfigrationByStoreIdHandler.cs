﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetHostConfigrationByStoreId
{
    public class GetHostConfigrationByStoreIdHandler : IRequestHandler<GetHostConfigrationByStoreIdQuery, HostConfigrationModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetHostConfigrationByStoreIdHandler> _logger;
        private readonly IMapper _mapper;

        public GetHostConfigrationByStoreIdHandler(IUnitOfWork context,
                                    ILogger<GetHostConfigrationByStoreIdHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }


        public async Task<HostConfigrationModel> Handle(GetHostConfigrationByStoreIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            var result = await _context.HostConfigrations.GetByStoreId(request.StoreId);

            _logger.TraceExitMethod(nameof(Handle), request);

            return result;

        }
    }
}
