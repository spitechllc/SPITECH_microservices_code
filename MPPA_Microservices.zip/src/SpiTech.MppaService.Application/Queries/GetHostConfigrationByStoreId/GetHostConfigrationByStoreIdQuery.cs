﻿using MediatR;
using SpiTech.MppaService.Domain.Models;

namespace SpiTech.MppaService.Application.Queries.GetHostConfigrationByStoreId
{
    public class GetHostConfigrationByStoreIdQuery : IRequest<HostConfigrationModel>
    {
        public int StoreId { get; set; }
    }
}
