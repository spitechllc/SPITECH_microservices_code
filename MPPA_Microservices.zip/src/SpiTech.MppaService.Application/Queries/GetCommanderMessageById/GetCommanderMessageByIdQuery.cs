﻿using MediatR;
using SpiTech.MppaService.Domain.Entities;

namespace SpiTech.MppaService.Application.Queries.GetCommanderMessageById
{
    public class GetCommanderMessageByIdQuery : IRequest<CommanderMessage>
    {
        public int CommanderMessageId { get; set; }
    }
}
