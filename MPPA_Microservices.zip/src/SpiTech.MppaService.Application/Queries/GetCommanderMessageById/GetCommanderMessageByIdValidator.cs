﻿using FluentValidation;

namespace SpiTech.MppaService.Application.Queries.GetCommanderMessageById
{
    public class GetCommanderMessageByIdValidator : AbstractValidator<GetCommanderMessageByIdQuery>
    {
        public GetCommanderMessageByIdValidator()
        {
            RuleFor(x => x.CommanderMessageId).GreaterThan(0).WithMessage("CommanderMessageId must be greater than 0");
        }
    }
}
