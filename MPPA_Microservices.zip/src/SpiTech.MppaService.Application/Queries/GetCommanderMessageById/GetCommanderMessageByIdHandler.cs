﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetCommanderMessageById
{
    public class GetCommanderMessageByIdHandler : IRequestHandler<GetCommanderMessageByIdQuery, CommanderMessage>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetCommanderMessageByIdHandler> _logger;
        private readonly IMapper _mapper;
        public GetCommanderMessageByIdHandler(IUnitOfWork context,
                                   ILogger<GetCommanderMessageByIdHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<CommanderMessage> Handle(GetCommanderMessageByIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            CommanderMessage result = await _context.CommanderMessages.Get(request.CommanderMessageId);

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
