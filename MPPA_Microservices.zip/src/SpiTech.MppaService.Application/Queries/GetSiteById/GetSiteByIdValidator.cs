﻿using FluentValidation;

namespace SpiTech.MppaService.Application.Queries.GetSiteById
{
    public class GetSiteByIdValidator : AbstractValidator<GetSiteByIdQuery>
    {
        public GetSiteByIdValidator()
        {
            RuleFor(x => x.SiteId).NotNull().WithMessage("SiteId is required").NotEmpty().WithMessage("SiteId is required");
        }
    }
}
