﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetSiteById
{
    public class GetSiteByIdHandler : IRequestHandler<GetSiteByIdQuery, Site>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetSiteByIdHandler> _logger;
        private readonly IMapper _mapper;
        public GetSiteByIdHandler(IUnitOfWork context,
                                   ILogger<GetSiteByIdHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<Site> Handle(GetSiteByIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(request), request);
            Site result = await _context.Sites.Get(request.SiteId);
            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
