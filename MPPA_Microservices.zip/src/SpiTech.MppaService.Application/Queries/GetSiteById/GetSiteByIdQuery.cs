﻿using MediatR;
using SpiTech.MppaService.Domain.Entities;

namespace SpiTech.MppaService.Application.Queries.GetSiteById
{
    public class GetSiteByIdQuery : IRequest<Site>
    {
        public string SiteId { get; set; }
    }
}
