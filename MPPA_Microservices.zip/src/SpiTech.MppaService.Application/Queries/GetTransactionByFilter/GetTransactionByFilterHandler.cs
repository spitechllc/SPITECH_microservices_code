﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Entities;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetTransactionByFilter
{
    public class GetTransactionByFilterHandler : IRequestHandler<GetTransactionByFilterQuery, IEnumerable<Transaction>>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetTransactionByFilterHandler> _logger;
        private readonly IMapper _mapper;
        public GetTransactionByFilterHandler(IUnitOfWork context,
                                   ILogger<GetTransactionByFilterHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }


        public async Task<IEnumerable<Transaction>> Handle(GetTransactionByFilterQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<Transaction> result = await _context.Transactions.GetByFilter(request.SiteId, request.SettlementPeriodId);

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
