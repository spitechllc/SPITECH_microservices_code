﻿using MediatR;
using SpiTech.MppaService.Domain.Entities;
using System.Collections.Generic;

namespace SpiTech.MppaService.Application.Queries.GetTransactionByFilter
{
    public class GetTransactionByFilterQuery : IRequest<IEnumerable<Transaction>>
    {
        public string SiteId { get; set; }
        public string SettlementPeriodId { get; set; }
    }
}
