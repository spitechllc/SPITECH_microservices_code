﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Models;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetCommanderMessages
{
    public class GetCommanderMessagesHandler : IRequestHandler<GetCommanderMessagesQuery, PaginatedList<CommanderMessageModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetCommanderMessagesHandler> _logger;
        private readonly IMapper _mapper;
        public GetCommanderMessagesHandler(IUnitOfWork context,
                                   ILogger<GetCommanderMessagesHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<PaginatedList<CommanderMessageModel>> Handle(GetCommanderMessagesQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            System.Collections.Generic.IEnumerable<CommanderMessageModel> result = await _context.CommanderMessages.Get(request.PageIndex, request.PageSize, request.From, request.To, request.RequestType, request.UMTI, request.SiteId, request.MerchantId, request.TransactionId, request.SortBy, request.SortOrder);

            int totalrecord = 0;
            if (result != null && result.Count() > 0)
            {
                totalrecord = result.Select(x => x.TotalRecord).FirstOrDefault();
            }

            PaginatedList<CommanderMessageModel> response = new()
            {
                Data = result.ToList(),
                PageIndex = request.PageIndex,
                PageSize = request.PageSize,
                TotalCount = totalrecord
            };

            _logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
