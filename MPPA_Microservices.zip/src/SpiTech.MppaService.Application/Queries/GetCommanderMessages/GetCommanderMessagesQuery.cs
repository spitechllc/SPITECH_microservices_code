﻿using MediatR;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Domain.Enums;
using SpiTech.MppaService.Domain.Models;
using System;

namespace SpiTech.MppaService.Application.Queries.GetCommanderMessages
{
    public class GetCommanderMessagesQuery : IRequest<PaginatedList<CommanderMessageModel>>
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public DateTime From { get; set; }
        public DateTime To { get; set; }
        public RequestType? RequestType { get; set; }
        public string UMTI { get; set; }
        public string SiteId { get; set; }
        public string MerchantId { get; set; }
        public long? TransactionId { get; set; }
        public CommanderMessageSortBy? SortBy { get; set; }
        public SortOrderEnum? SortOrder { get; set; }
    }
}
