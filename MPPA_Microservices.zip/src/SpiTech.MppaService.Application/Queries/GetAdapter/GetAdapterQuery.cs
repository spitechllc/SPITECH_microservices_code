﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Domain.Models;

namespace SpiTech.MppaService.Application.Queries.GetAdapter
{
    public class GetAdapterQuery : IRequest<ResponseList<AdapterModel>>
    {
    }
}
