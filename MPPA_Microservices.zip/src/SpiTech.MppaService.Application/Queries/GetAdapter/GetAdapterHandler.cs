﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetAdapter
{
    public class GetAdapterHandler : IRequestHandler<GetAdapterQuery, ResponseList<AdapterModel>>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetAdapterHandler> _logger;
        private readonly IMapper _mapper;

        public GetAdapterHandler(IUnitOfWork context,
                                   ILogger<GetAdapterHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<ResponseList<AdapterModel>> Handle(GetAdapterQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<AdapterModel> result = _mapper.Map<IEnumerable<AdapterModel>>(await _context.Adapters.GetAll());
            _logger.TraceExitMethod(nameof(Handle), result);
            return new ResponseList<AdapterModel>() { Data = result };
        }
    }
}
