﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Entities;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetUserInprogressTransaction
{
    public class GetUserInprogressTransactionHandler : IRequestHandler<GetUserInprogressTransactionQuery, Transaction>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetUserInprogressTransactionHandler> _logger;
        private readonly IMapper _mapper;
        public GetUserInprogressTransactionHandler(IUnitOfWork context,
                                   ILogger<GetUserInprogressTransactionHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }


        public async Task<Transaction> Handle(GetUserInprogressTransactionQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            var result = await _context.Transactions.GetUserInprogressTransaction(request.UserId, request.TimeOutInSec, request.TransactionType);

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
