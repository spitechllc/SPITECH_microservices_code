﻿using MediatR;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Domain.Entities;

namespace SpiTech.MppaService.Application.Queries.GetUserInprogressTransaction
{
    public class GetUserInprogressTransactionQuery : IRequest<Transaction>
    {
        public int UserId { get; set; }
        public int TimeOutInSec { get; set; }
        public TransactionType TransactionType { get; set; }
    }
}
