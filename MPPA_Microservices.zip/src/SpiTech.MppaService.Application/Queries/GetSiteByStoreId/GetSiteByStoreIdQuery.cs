﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Domain.Models;

namespace SpiTech.MppaService.Application.Queries.GetSiteByStoreId
{
    public class GetSiteByStoreIdQuery : IRequest<ResponseList<SiteModel>>
    {
        public int StoreId { get; set; }
    }
}
