﻿using FluentValidation;

namespace SpiTech.MppaService.Application.Queries.GetSiteByStoreId
{
    public class GetSiteByStoreIdValidator : AbstractValidator<GetSiteByStoreIdQuery>
    {
        public GetSiteByStoreIdValidator()
        {
            RuleFor(x => x.StoreId).GreaterThan(0).WithMessage("StoreId must be greater than 0");
        }
    }
}
