﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetPosByStoreId
{
    public class GetPosByStoreIdHandler : IRequestHandler<GetPosByStoreIdQuery, ResponseList<POSModel>>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetPosByStoreIdHandler> _logger;
        private readonly IMapper _mapper;

        public GetPosByStoreIdHandler(IUnitOfWork context,
                                   ILogger<GetPosByStoreIdHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<ResponseList<POSModel>> Handle(GetPosByStoreIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<POSModel> result = _mapper.Map<IEnumerable<POSModel>>(await _context.PoseS.GetByStoreId(request.StoreId));
            _logger.TraceExitMethod(nameof(Handle), result);

            return new ResponseList<POSModel>() { Data = result };
        }
    }
}
