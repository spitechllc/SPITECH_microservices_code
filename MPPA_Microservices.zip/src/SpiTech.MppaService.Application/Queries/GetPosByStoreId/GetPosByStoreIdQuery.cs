﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Domain.Models;

namespace SpiTech.MppaService.Application.Queries.GetPosByStoreId
{
    public class GetPosByStoreIdQuery : IRequest<ResponseList<POSModel>>
    {
        public int StoreId { get; set; }
    }
}
