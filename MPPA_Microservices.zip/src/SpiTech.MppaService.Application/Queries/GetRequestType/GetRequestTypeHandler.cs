﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetRequestType
{
    public class GetRequestTypeHandler : IRequestHandler<GetRequestTypeQuery, ResponseList<RequestTypeModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetRequestTypeHandler> _logger;
        private readonly IMapper _mapper;
        public GetRequestTypeHandler(IUnitOfWork context,
                                   ILogger<GetRequestTypeHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<ResponseList<RequestTypeModel>> Handle(GetRequestTypeQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<RequestTypeModel> result = _mapper.Map<IEnumerable<RequestTypeModel>>(await _context.RequestTypes.GetAll());
            _logger.TraceExitMethod(nameof(Handle), result);
            return new ResponseList<RequestTypeModel>() { Data = result };
        }
    }
}
