﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Domain.Models;

namespace SpiTech.MppaService.Application.Queries.GetRequestType
{
    public class GetRequestTypeQuery : IRequest<ResponseList<RequestTypeModel>>
    {

    }
}
