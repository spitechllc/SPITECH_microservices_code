﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.Interfaces.HostServers;
using SpiTech.MppaService.Application.Queries.GetSiteById;
using SpiTech.MppaService.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetCommanderStatus
{
    public class GetCommanderStatusHandler : IRequestHandler<GetCommanderStatusQuery, SiteModel>
    {
        private readonly IMediator mediator;
        private readonly ILogger<GetCommanderStatusHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IMppaSessionManager mppaSessionManager;

        public GetCommanderStatusHandler(IMediator mediator,
                                   ILogger<GetCommanderStatusHandler> logger,
                                   IMapper mapper,
                                   IMppaSessionManager mppaSessionManager)
        {
            this.mediator = mediator;
            _logger = logger;
            _mapper = mapper;
            this.mppaSessionManager = mppaSessionManager;
        }
        public async Task<SiteModel> Handle(GetCommanderStatusQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            SiteModel result = null;
            Domain.Entities.Site site = await mediator.Send(new GetSiteByIdQuery { SiteId = request.SiteId });

            if (site != null)
            {
                result = _mapper.Map<SiteModel>(site);
                result.IsOnline = (await mppaSessionManager.GetMppaSession(request.SiteId)) != null;
            }
            else
            {
                result = new SiteModel
                {
                    IsOnline = false
                };
            }

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
