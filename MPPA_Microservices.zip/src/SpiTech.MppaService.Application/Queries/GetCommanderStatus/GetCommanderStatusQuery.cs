﻿using MediatR;
using SpiTech.MppaService.Domain.Models;

namespace SpiTech.MppaService.Application.Queries.GetCommanderStatus
{
    public class GetCommanderStatusQuery : IRequest<SiteModel>
    {
        public string SiteId { get; set; }
    }
}
