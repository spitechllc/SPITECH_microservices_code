﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetTransactionById
{
    public class GetTransactionByIdHandler : IRequestHandler<GetTransactionByIdQuery, Transaction>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetTransactionByIdHandler> _logger;
        private readonly IMapper _mapper;
        public GetTransactionByIdHandler(IUnitOfWork context,
                                   ILogger<GetTransactionByIdHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<Transaction> Handle(GetTransactionByIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            var result = await _context.Transactions.GetById(request.TransactionId);

            _logger.TraceExitMethod(nameof(Handle), request);

            return result;
        }
    }
}
