﻿using FluentValidation;

namespace SpiTech.MppaService.Application.Queries.GetTransactionById
{
    public class GetTransactionByIdValidator : AbstractValidator<GetTransactionByIdQuery>
    {
        public GetTransactionByIdValidator()
        {
        }
    }
}
