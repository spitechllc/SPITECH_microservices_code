﻿using MediatR;
using SpiTech.MppaService.Domain.Entities;

namespace SpiTech.MppaService.Application.Queries.GetTransactionById
{
    public class GetTransactionByIdQuery : IRequest<Transaction>
    {
        public long TransactionId { get; set; }
    }
}
