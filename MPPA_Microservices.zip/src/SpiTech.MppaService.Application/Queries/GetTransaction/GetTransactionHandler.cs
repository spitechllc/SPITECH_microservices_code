﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetTransaction
{
    public class GetTransactionHandler : IRequestHandler<GetTransactionQuery, ResponseList<Transaction>>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetTransactionHandler> _logger;
        private readonly IMapper _mapper;
        public GetTransactionHandler(IUnitOfWork context,
                                   ILogger<GetTransactionHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }


        public async Task<ResponseList<Transaction>> Handle(GetTransactionQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            System.Collections.Generic.IEnumerable<Transaction> result = await _context.Transactions.GetAll();

            _logger.TraceExitMethod(nameof(Handle), result);

            return new ResponseList<Transaction>() { Data = result };
        }
    }
}
