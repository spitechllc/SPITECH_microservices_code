﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Domain.Entities;

namespace SpiTech.MppaService.Application.Queries.GetTransaction
{
    public class GetTransactionQuery : IRequest<ResponseList<Transaction>>
    {
    }
}
