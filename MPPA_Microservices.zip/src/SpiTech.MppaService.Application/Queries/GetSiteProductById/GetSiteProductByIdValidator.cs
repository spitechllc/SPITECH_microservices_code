﻿using FluentValidation;

namespace SpiTech.MppaService.Application.Queries.GetSiteProductById
{
    public class GetSiteProductByIdValidator : AbstractValidator<GetSiteProductByIdQuery>
    {
        public GetSiteProductByIdValidator()
        {
            RuleFor(x => x.ItemId).GreaterThan(0).WithMessage("SaleItemId must be greater than 0");
        }
    }
}
