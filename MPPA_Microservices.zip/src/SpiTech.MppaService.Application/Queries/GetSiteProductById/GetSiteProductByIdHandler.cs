﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetSiteProductById
{
    public class GetSiteProductByIdHandler : IRequestHandler<GetSiteProductByIdQuery, SiteProduct>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetSiteProductByIdHandler> _logger;
        private readonly IMapper _mapper;
        public GetSiteProductByIdHandler(IUnitOfWork context,
                                   ILogger<GetSiteProductByIdHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<SiteProduct> Handle(GetSiteProductByIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            SiteProduct result = await _context.SiteProducts.Get(request.ItemId);
            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
