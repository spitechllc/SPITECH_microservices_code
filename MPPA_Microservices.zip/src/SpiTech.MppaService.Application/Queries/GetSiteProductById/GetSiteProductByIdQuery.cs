﻿using MediatR;
using SpiTech.MppaService.Domain.Entities;

namespace SpiTech.MppaService.Application.Queries.GetSiteProductById
{
    public class GetSiteProductByIdQuery : IRequest<SiteProduct>
    {
        public int ItemId { get; set; }
    }
}
