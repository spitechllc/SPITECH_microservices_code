﻿using MediatR;
using SpiTech.MppaService.Domain.Models;

namespace SpiTech.MppaService.Application.Queries.GetGasPumpById
{
    public class GetGasPumpByIdQuery : IRequest<GasPumpModel>
    {
        public int GasPumpId { get; set; }
    }
}
