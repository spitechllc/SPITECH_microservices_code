﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetGasPumpById
{
    public class GetGasPumpByIdHandler : IRequestHandler<GetGasPumpByIdQuery, GasPumpModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetGasPumpByIdHandler> _logger;
        private readonly IMapper _mapper;

        public GetGasPumpByIdHandler(IUnitOfWork context,
                                   ILogger<GetGasPumpByIdHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<GasPumpModel> Handle(GetGasPumpByIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            GasPumpModel result = _mapper.Map<GasPumpModel>(await _context.GasPumps.Get(request.GasPumpId));
            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
