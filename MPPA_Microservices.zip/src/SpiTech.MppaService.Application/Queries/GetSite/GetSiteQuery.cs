﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Domain.Models;

namespace SpiTech.MppaService.Application.Queries.GetSite
{
    public class GetSiteQuery : IRequest<ResponseList<SiteModel>>
    {
    }
}
