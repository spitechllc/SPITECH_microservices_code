﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetSite
{
    public class GetSiteHandler : IRequestHandler<GetSiteQuery, ResponseList<SiteModel>>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetSiteHandler> _logger;
        private readonly IMapper _mapper;
        public GetSiteHandler(IUnitOfWork context,
                                   ILogger<GetSiteHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<ResponseList<SiteModel>> Handle(GetSiteQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            IEnumerable<SiteModel> result = _mapper.Map<IEnumerable<SiteModel>>(await _context.Sites.GetAll());
            _logger.TraceExitMethod(nameof(Handle), result);
            return new ResponseList<SiteModel>() { Data = result };
        }
    }
}
