﻿using MediatR;
using SpiTech.MppaService.Domain.Models;

namespace SpiTech.MppaService.Application.Queries.GetPosById
{
    public class GetPosByIdQuery : IRequest<POSModel>
    {
        public int PosId { get; set; }
    }
}
