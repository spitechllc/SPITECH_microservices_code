﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Queries.GetPosById
{
    public class GetPosByIdHandler : IRequestHandler<GetPosByIdQuery, POSModel>
    {


        private readonly IUnitOfWork _context;
        private readonly ILogger<GetPosByIdHandler> _logger;
        private readonly IMapper _mapper;

        public GetPosByIdHandler(IUnitOfWork context,
                                   ILogger<GetPosByIdHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<POSModel> Handle(GetPosByIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            POSModel result = _mapper.Map<POSModel>(await _context.PoseS.Get(request.PosId));
            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
