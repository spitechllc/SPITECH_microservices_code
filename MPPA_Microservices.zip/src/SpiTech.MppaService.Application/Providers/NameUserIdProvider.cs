﻿using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Providers
{
    public class NameUserIdProvider : IUserIdProvider
    {
        public string GetUserId(HubConnectionContext connection)
        {
            string userId = null;

            var subClaim = connection.User?.Claims?.FirstOrDefault(i => i.Type == "sub");

            if (subClaim != null && !string.IsNullOrWhiteSpace(subClaim.Value))
            {
                userId = subClaim.Value;
            }

            return userId;
        }
    }
}
