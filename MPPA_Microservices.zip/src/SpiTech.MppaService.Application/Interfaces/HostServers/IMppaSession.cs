﻿using SpiTech.MppaService.Domain.Models;
using System;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Interfaces.HostServers
{
    public interface IMppaSession
    {
        public Guid Id { get; }
        string SiteId { get; }
        Task SendMessage(string message);
        bool IsActive { get; }
        DateTime ConnectionTime { get; }
        MppaSessionStatus GetMppaSessionStatus();
    }
}
