﻿using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Interfaces.HostServers
{
    public interface IMppaSessionManager
    {
        Task<List<MppaSessionStatus>> GetMppaSessionStatus(string siteId);
        Task<ResponseModel> SendMessage(string siteId, string message);
        Task<IMppaSession> GetMppaSession(string siteId);
        Task<List<string>> GetActiveMppaSessionSiteIds();

        bool AddSiteSession(IMppaSession mppaSession);
        bool RemoveSiteSession(IMppaSession mppaSession);
    }
}
