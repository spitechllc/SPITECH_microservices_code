﻿namespace SpiTech.MppaService.Application.Interfaces.HostServers
{
    public interface IMppaServer
    {
        bool Start();
        bool Stop();
    }
}
