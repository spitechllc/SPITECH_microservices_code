﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.UpdateGetSite
{
    public class UpdateGetSiteHandler : IRequestHandler<UpdateGetSiteCommand, Site>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateGetSiteHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IStoreServiceClient storeApiClient;

        public UpdateGetSiteHandler(IUnitOfWork context,
                                   ILogger<UpdateGetSiteHandler> logger,
                                   IMapper mapper,
                                   IStoreServiceClient storeApiClient)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.storeApiClient = storeApiClient;
        }

        public async Task<Site> Handle(UpdateGetSiteCommand command, CancellationToken cancellationToken)
        {
            _logger.Warn($"MPPA UpdateGetSiteHandler start 1");
            _logger.TraceEnterMethod(nameof(Handle), command);

            Site site = null;

            if (command.StoreId > 0)
            {
                site = await _context.Sites.GetByStoreId(command.StoreId);
            }

            if (site == null)
            {
                site = await _context.Sites.GetByStoreId(command.SiteId);
            }

            if (site == null)
            {
                StoreInfoModel storeInfoModel = await storeApiClient.GetStoreInfoAsync(command.StoreId, command.SiteId).ConfigureAwait(false);

                site = new Site
                {
                    SiteId = storeInfoModel.SiteId,
                    StoreId = storeInfoModel.StoreId,
                    StoreName = storeInfoModel.StoreName,
                    SiteName = storeInfoModel.StoreName,
                    IsActive = storeInfoModel.IsActive
                };

                await _context.Execute(async () =>
                {
                    await _context.Sites.Add(site);
                });
            }
            else
            {
                _logger.Warn($"MPPA UpdateGetSiteHandler start 2 go for update");

                if (command.Update)
                {
                    site = new Site
                    {
                        SiteId = command.SiteId,
                        StoreId = command.StoreId,
                        StoreName = command.StoreName,
                        SiteName = command.StoreName,
                        IsActive = true
                    };

                    await UpdateSite(site);
                    _logger.Warn($"MPPA UpdateGetSiteHandler start 3 isactive: {site.IsActive}");
                }

                else if (!site.StoreId.HasValue || site.StoreId == 0 || string.IsNullOrWhiteSpace(site.StoreName))
                {
                    _logger.Warn($"MPPA UpdateGetSiteHandler start 4");

                    await VerifyAndAssignStoreId(site);
                    await UpdateSite(site);
                }
            }

            _logger.TraceExitMethod(nameof(Handle), site);
            _logger.Warn($"MPPA UpdateGetSiteHandler end");

            return site;
        }

        private async Task UpdateSite(Site site)
        {
            try
            {
                await _context.Execute(async () =>
                {
                    await _context.Sites.Update(site.StoreId ?? 0, site.SiteId, site.StoreName);
                });
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }

        private async Task VerifyAndAssignStoreId(Site site)
        {
            try
            {
                var storeResult = await storeApiClient.GetStoreInfoAsync(site.StoreId, site.SiteId).ConfigureAwait(false);

                if (storeResult != null)
                {
                    site.StoreId = storeResult.StoreId;
                    site.StoreName = storeResult.StoreName;
                    site.SiteName = storeResult.StoreName;
                }
                else
                {
                    _logger.Error(new Exception($"{site.SiteId} is not found in store microservice"), site.SiteId);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
        }
    }
}
