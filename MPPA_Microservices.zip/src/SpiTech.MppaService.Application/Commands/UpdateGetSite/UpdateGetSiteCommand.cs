﻿using MediatR;
using SpiTech.MppaService.Domain.Entities;

namespace SpiTech.MppaService.Application.Commands.UpdateGetSite
{
    public class UpdateGetSiteCommand : IRequest<Site>
    {
        public string StoreName { get; set; }
        public string SiteId { get; set; }
        public int StoreId { get; set; }
        public bool Update { get; set; }
    }
}
