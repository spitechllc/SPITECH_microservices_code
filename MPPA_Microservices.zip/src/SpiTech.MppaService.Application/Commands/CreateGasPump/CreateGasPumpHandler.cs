﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CreateGasPump
{
    public class CreateGasPumpHandler : IRequestHandler<CreateGasPumpCommand, int>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateGasPumpHandler> _logger;
        private readonly IMapper _mapper;

        public CreateGasPumpHandler(IUnitOfWork context,
                                   ILogger<CreateGasPumpHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<int> Handle(CreateGasPumpCommand request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            int gaspumpid = 0;

            await _context.Execute(async () =>
            {
                gaspumpid = await _context.GasPumps.Add(new Domain.Entities.GasPump()
                {
                    PosId = request.PosId,
                    PumpNumber = request.PumpNumber,
                    PumpSystemId = request.PumpSystemId,
                    StoreId = request.StoreId,
                    QRCode = request.QRCode,
                    BarCode = request.BarCode,
                    IsActive = true,
                    CreatedOn = DateTime.UtcNow,
                    CreatedBy = 1 // need to pick from token 
                });
            });

            _logger.TraceExitMethod(nameof(Handle), gaspumpid);
            return await Task.FromResult(gaspumpid);
        }
    }
}
