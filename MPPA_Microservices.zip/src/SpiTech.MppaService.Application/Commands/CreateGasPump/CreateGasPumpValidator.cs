﻿using FluentValidation;

namespace SpiTech.MppaService.Application.Commands.CreateGasPump
{
    public class CreateGasPumpValidator : AbstractValidator<CreateGasPumpCommand>
    {
        public CreateGasPumpValidator()
        {
            RuleFor(x => x.StoreId).GreaterThan(0).WithMessage("StoreId must be greater than 0");
            RuleFor(x => x.PosId).GreaterThan(0).WithMessage("PosId must be greater than 0");
            RuleFor(x => x.PumpNumber).NotNull().WithMessage("Pump Number is required")
                                          .MaximumLength(50).WithMessage("Pump Number be upto 50 characters only");
            RuleFor(x => x.PumpSystemId).NotNull().WithMessage("Pump System Id is required")
                                            .MaximumLength(50).WithMessage("Pump System Id must be upto 50 characters only");
            RuleFor(x => x.BarCode).MaximumLength(250).WithMessage("BarCode must be upto 250 characters only");
            RuleFor(x => x.QRCode).MaximumLength(250).WithMessage("QRCode must be upto 250 characters only");
        }
    }
}
