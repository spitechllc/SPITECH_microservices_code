﻿using MediatR;

namespace SpiTech.MppaService.Application.Commands.CreateGasPump
{
    public class CreateGasPumpCommand : IRequest<int>
    {
        public int StoreId { get; set; }
        public int PosId { get; set; }
        public string PumpNumber { get; set; }
        public string PumpSystemId { get; set; }
        public string QRCode { get; set; }
        public string BarCode { get; set; }
    }
}
