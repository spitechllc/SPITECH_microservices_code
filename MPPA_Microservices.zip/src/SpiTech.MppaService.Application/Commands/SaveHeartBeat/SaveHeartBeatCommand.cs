﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders;

namespace SpiTech.MppaService.Application.Commands.SaveHeartBeat
{
    public class SaveHeartBeatCommand : IRequest<bool>
    {
        public MobileTxnInfoBase MobileTxnInfo { get; set; }
    }
}
