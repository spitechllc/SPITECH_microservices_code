﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.SiteData;
using SpiTech.MppaService.Application.Commands.UpdateGetSite;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.SaveHeartBeat
{
    public class SaveHeartBeatHandler : IRequestHandler<SaveHeartBeatCommand, bool>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<CommanderSiteDataHandler> logger;
        private readonly IMediator mediator;
        private readonly IStoreServiceClient storeApiClient;
        private readonly IEventDispatcher eventDispatcher;

        public SaveHeartBeatHandler(IUnitOfWork context,
                                    ILogger<CommanderSiteDataHandler> logger,
                                    IMediator mediator,
                                    IStoreServiceClient storeApiClient,
                                    IEventDispatcher eventDispatcher)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            this.storeApiClient = storeApiClient;
            this.eventDispatcher = eventDispatcher;
        }

        public async Task<bool> Handle(SaveHeartBeatCommand command, CancellationToken cancellationToken)
        {
            logger.Warn($"MPPA SaveHeartBeatCommand Start");

            logger.TraceEnterMethod(nameof(Handle), command);
            try
            {
                logger.Warn($"MPPA SaveHeartBeatCommand go to UpdateGetSiteCommand");
                Site site = await mediator.Send(new UpdateGetSiteCommand { SiteId = command.MobileTxnInfo.SiteId });

                if (site == null)
                {
                    logger.Warn($"MPPA SaveHeartBeatCommand site null");
                    site = new Site
                    {
                        SiteId = command.MobileTxnInfo.SiteId,
                        SiteName = command.MobileTxnInfo.SiteId,
                        MerchantId = command.MobileTxnInfo.MerchantId,
                        CurrentHeartBeatTime = DateTime.UtcNow,
                        LastHeartBeatTime = DateTime.UtcNow,
                        HeartBeatTimeDateStamp = command.MobileTxnInfo.TimeDateStamp,
                        HeartBeatUMTI = command.MobileTxnInfo.UMTI,
                        IsActive = true
                    };

                    await VerifyAndAssignStoreId(site);

                    await context.Execute(async () =>
                    {
                        await context.Sites.Add(site);
                    });
                }
                else
                {
                    logger.Warn($"MPPA SaveHeartBeatCommand site not null");
                    if (string.IsNullOrWhiteSpace(site.SiteName))
                    {
                        site.SiteName = command.MobileTxnInfo.SiteId;
                    }

                    site.MerchantId = command.MobileTxnInfo.MerchantId;
                    site.CurrentHeartBeatTime = DateTime.UtcNow;
                    site.LastHeartBeatTime = site.CurrentHeartBeatTime;
                    site.HeartBeatTimeDateStamp = command.MobileTxnInfo.TimeDateStamp;
                    site.HeartBeatUMTI = command.MobileTxnInfo.UMTI;

                    await VerifyAndAssignStoreId(site);

                    logger.Warn($"MPPA SaveHeartBeatCommand go for update site");

                    await context.Execute(async () =>
                    {
                        await context.Sites.Update(site);
                    });
                }

                await eventDispatcher.Dispatch(new SiteEvent
                {
                    SiteId = site.SiteId,
                    SiteName = site.SiteName,
                    SiteMPPAIdentifier = site.SiteMPPAIdentifier,
                    MerchantId = site.MerchantId,
                    LocationId = site.LocationId,
                    SiteMobileActive = site.SiteMobileActive,
                    SiteAddress = site.SiteAddress,
                    SettlementEmployee = site.SettlementEmployee,
                    PartialAuthAllowed = site.PartialAuthAllowed,
                    PumpTimeout = site.PumpTimeout,
                    StoreId = site.StoreId,
                    StoreName = site.StoreName,
                });
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return false;
            }

            logger.TraceExitMethod(nameof(Handle), true);
            logger.Warn($"MPPA SaveHeartBeatCommand exit");
            return true;
        }

        private async Task VerifyAndAssignStoreId(Site site)
        {
            if (site != null)
            {
                if (!site.StoreId.HasValue || site.StoreId == 0 || string.IsNullOrEmpty(site.StoreName))
                {
                    try
                    {
                        var storeResult = await storeApiClient.GetStoreInfoAsync(null, site.SiteId).ConfigureAwait(false);

                        if (storeResult != null)
                        {
                            site.StoreId = storeResult.StoreId;
                            site.StoreName = storeResult.StoreName;
                            site.SiteName = storeResult.StoreName;
                        }
                        else
                        {
                            logger.Error(new Exception($"{site.SiteId} is not found in store microservice"), site.SiteId);
                        }
                    }
                    catch (Exception ex)
                    {
                        logger.Error(ex);
                    }
                }
            }
        }
    }
}
