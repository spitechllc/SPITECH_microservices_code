﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.SignalR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.MppaService.Application.Hubs;
using SpiTech.MppaService.Application.Processors;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.MobileIntegrations.FinalReceiptResponses
{
    public class MobileFinalReceiptResponseHandler : IRequestHandler<MobileFinalReceiptResponseCommand, bool>
    {
        private readonly ILogger<MobileFinalReceiptResponseHandler> logger;
        private readonly IMediator mediator;
        private readonly IMppaClient mppaHubClient;
        private readonly IEventDispatcher _eventDispatcher;

        private readonly IMapper _mapper;
        private readonly IUserAppMessageLogProcessor userAppMessageLogProcessor;

        public MobileFinalReceiptResponseHandler(
                                    ILogger<MobileFinalReceiptResponseHandler> logger,
                                    IMediator mediator,
                                    IMppaClient mppaHubClient,
                                    IEventDispatcher eventDispatcher,
                                    IMapper mapper,
                                    IUserAppMessageLogProcessor userAppMessageLogProcessor)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.mppaHubClient = mppaHubClient;
            _eventDispatcher = eventDispatcher;
            _mapper = mapper;
            this.userAppMessageLogProcessor = userAppMessageLogProcessor;
        }

        public async Task<bool> Handle(MobileFinalReceiptResponseCommand command, CancellationToken cancellationToken)
        {
            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);
                string error = "";

                try
                {
                    var umti = command.ReceiptData.Transaction.UMTI;
                    command.ReceiptData.Transaction.UMTI = command.ReceiptData.Transaction.TransactionId.ToString();
                    await mppaHubClient.Perform(command.ReceiptData.Transaction.UserId, async client => await client.FinalReceipt(command));
                    command.ReceiptData.Transaction.UMTI = umti;
                }
                catch (Exception ex)
                {
                    logger.Error(ex, command);
                    error = ExceptionJsonSerializer.Serialize(ex);
                }

                await userAppMessageLogProcessor.LogResponse(EventBus.DomainEvents.Enums.RequestType.MobileReceiptData,
                       command.ReceiptData.Transaction.SiteId,
                       command.ReceiptData.Transaction.UserId,
                       command.ReceiptData.Transaction.TransactionId,
                       command.ReceiptData.Transaction.UMTI,
                       error,
                       command);

                logger.TraceExitMethod(nameof(Handle));
                return await Task.FromResult(true);
            }
            catch (Exception ex)
            {
                logger.Error(ex, command);
            }

            return await Task.FromResult(false);
        }
    }
}
