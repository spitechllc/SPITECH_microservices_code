﻿using MediatR;
using SpiTech.EventBus.DomainEvents.Models.Mppa.Receipts;

namespace SpiTech.MppaService.Application.Commands.MobileIntegrations.FinalReceiptResponses
{
    public class MobileFinalReceiptResponseCommand : IRequest<bool>
    {
        public TransactionReceiptModel ReceiptData { get; set; }
    }
}
