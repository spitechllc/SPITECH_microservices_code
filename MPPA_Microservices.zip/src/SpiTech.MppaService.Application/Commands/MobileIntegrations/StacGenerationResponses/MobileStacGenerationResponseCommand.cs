﻿using MediatR;
using System;

namespace SpiTech.MppaService.Application.Commands.MobileIntegrations.StacGenerationResponses
{
    public class MobileStacGenerationResponseCommand : IRequest<bool>
    {
        public int UserId { get; set; }
        public string SiteId { get; set; }
        public string Stac { get; set; }
        public string QrCodeStac { get; set; }
        public string BarCodeStac { get; set; }
        public DateTime? GenerateDate { get; set; }
        public bool Success { get; set; }
        public string Erorr { get; set; }
    }
}
