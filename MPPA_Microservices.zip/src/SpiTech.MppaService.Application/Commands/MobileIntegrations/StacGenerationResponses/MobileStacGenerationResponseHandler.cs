﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.MppaService.Application.Hubs;
using SpiTech.MppaService.Application.Processors;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.MobileIntegrations.StacGenerationResponses
{
    public class MobileStacGenerationResponseHandler : IRequestHandler<MobileStacGenerationResponseCommand, bool>
    {
        private readonly ILogger<MobileStacGenerationResponseHandler> logger;
        private readonly IMediator mediator;
        private readonly IMppaClient mppaHubClient;

        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAppMessageLogProcessor userAppMessageLogProcessor;

        public MobileStacGenerationResponseHandler(
                                    ILogger<MobileStacGenerationResponseHandler> logger,
                                    IMediator mediator,
                                    IMppaClient mppaHubClient,
                                    IEventDispatcher eventDispatcher,
                                    IUserAppMessageLogProcessor userAppMessageLogProcessor)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.mppaHubClient = mppaHubClient;
            _eventDispatcher = eventDispatcher;
            this.userAppMessageLogProcessor = userAppMessageLogProcessor;
        }

        public async Task<bool> Handle(MobileStacGenerationResponseCommand command, CancellationToken cancellationToken)
        {
            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);
                string error = "";

                try
                {
                    await mppaHubClient.Perform(command.UserId, async client => await client.StacGenerationResponse(command));
                }
                catch (Exception ex)
                {
                    logger.Error(ex, command);
                    error = ExceptionJsonSerializer.Serialize(ex);
                }

                await userAppMessageLogProcessor.LogResponse(EventBus.DomainEvents.Enums.RequestType.MobileStacGenerate,
                       command.SiteId,
                       command.UserId,
                       null,
                       null,
                       error,
                       command);


                logger.TraceExitMethod(nameof(Handle));
                return await Task.FromResult(true);
            }
            catch (Exception ex)
            {
                logger.Error(ex, command);
            }

            return await Task.FromResult(false);

        }
    }
}
