﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Mobiles;
using SpiTech.MppaService.Application.Hubs;
using SpiTech.MppaService.Application.Processors;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.MobileIntegrations.PumpReserveResponses
{
    public class MobilePumpReserveResponseHandler : IRequestHandler<MobilePumpReserveResponseCommand, bool>
    {
        private readonly ILogger<MobilePumpReserveResponseHandler> logger;
        private readonly IMediator mediator;
        private readonly IMppaClient mppaHubClient;

        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAppMessageLogProcessor userAppMessageLogProcessor;

        public MobilePumpReserveResponseHandler(
                                    ILogger<MobilePumpReserveResponseHandler> logger,
                                    IMediator mediator,
                                    IMppaClient mppaHubClient,
                                    IEventDispatcher eventDispatcher,
                                    IUserAppMessageLogProcessor userAppMessageLogProcessor)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.mppaHubClient = mppaHubClient;
            _eventDispatcher = eventDispatcher;
            this.userAppMessageLogProcessor = userAppMessageLogProcessor;
        }

        public async Task<bool> Handle(MobilePumpReserveResponseCommand command, CancellationToken cancellationToken)
        {
            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);
                string error = "";
                string utmi = command.UMTI;

                try
                {
                    command.UMTI = command.TransactionId.ToString();
                    await mppaHubClient.Perform(command.UserId, async client =>
                    {
                        await client.PumpReserveResponse(command);
                    });
                    command.UMTI = utmi;
                }
                catch (Exception ex)
                {
                    logger.Error(ex, command);
                    error = ExceptionJsonSerializer.Serialize(ex);
                }

                await userAppMessageLogProcessor.LogResponse(EventBus.DomainEvents.Enums.RequestType.MobilePumpReserve,
                       command.SiteId,
                       command.UserId,
                       command.TransactionId,
                       command.UMTI,
                       error,
                       command);

                await _eventDispatcher.Dispatch(new MobilePumpReserveResponsesEvent
                {
                    PumpReserveResponse = new EventBus.DomainEvents.Models.Mppa.PumpReserveResponseModel
                    {
                        TransactionId = command.TransactionId,
                        FuelingPositionId = command.FuelingPositionId,
                        SiteId = command.SiteId,
                        UMTI = command.UMTI,
                        UserId = command.UserId,
                        Status = command.Status,
                        Success = command.Success,
                        Erorr = command.Erorr
                    }
                });

                logger.TraceExitMethod(nameof(Handle));
                return await Task.FromResult(true);
            }
            catch (Exception ex)
            {
                logger.Error(ex, command);
            }

            return await Task.FromResult(false);

        }
    }
}
