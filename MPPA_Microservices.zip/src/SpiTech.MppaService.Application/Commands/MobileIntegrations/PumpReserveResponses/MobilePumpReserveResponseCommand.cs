﻿using MediatR;

namespace SpiTech.MppaService.Application.Commands.MobileIntegrations.PumpReserveResponses
{
    public class MobilePumpReserveResponseCommand : IRequest<bool>
    {
        public long TransactionId { get; set; }
        public string UMTI { get; set; }
        public int UserId { get; set; }
        public string SiteId { get; set; }
        public int FuelingPositionId { get; set; }
        public bool Success { get; set; }
        public string Status { get; set; }
        public string Erorr { get; set; }
    }
}
