﻿using MediatR;

namespace SpiTech.MppaService.Application.Commands.MobileIntegrations.PumpBeginFualResponses
{
    public class MobilePumpBeginFualResponseCommand : IRequest<bool>
    {
        public long TransactionId { get; set; }
        public string SiteId { get; set; }
        public string UMTI { get; set; }
        public int UserId { get; set; }
        public bool BeginFuel { get; set; }
        public string BeginFuelMessage { get; set; }
    }
}
