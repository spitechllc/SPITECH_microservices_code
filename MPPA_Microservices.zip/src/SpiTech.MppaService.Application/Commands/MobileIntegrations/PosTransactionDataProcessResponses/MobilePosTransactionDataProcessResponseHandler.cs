﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.MppaService.Application.Hubs;
using SpiTech.MppaService.Application.Processors;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.MobileIntegrations.PosTransactionDataProcessResponses
{
    public class MobilePosTransactionDataProcessResponseHandler : IRequestHandler<MobilePosTransactionDataProcessResponseCommand, bool>
    {
        private readonly ILogger<MobilePosTransactionDataProcessResponseHandler> logger;
        private readonly IMediator mediator;
        private readonly IMppaClient mppaHubClient;

        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAppMessageLogProcessor userAppMessageLogProcessor;

        public MobilePosTransactionDataProcessResponseHandler(
                                    ILogger<MobilePosTransactionDataProcessResponseHandler> logger,
                                    IMediator mediator,
                                    IMppaClient mppaHubClient,
                                    IEventDispatcher eventDispatcher,
                                    IUserAppMessageLogProcessor userAppMessageLogProcessor)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.mppaHubClient = mppaHubClient;
            _eventDispatcher = eventDispatcher;
            this.userAppMessageLogProcessor = userAppMessageLogProcessor;
        }

        public async Task<bool> Handle(MobilePosTransactionDataProcessResponseCommand command, CancellationToken cancellationToken)
        {
            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);
                string error = "";
                string utmi = command.UMTI;

                try
                {
                    command.UMTI = command.TransactionId.ToString();
                    await mppaHubClient.Perform(command.UserId, async client => await client.PosTransactionDataProcess(command));
                    command.UMTI = utmi;
                }
                catch (Exception ex)
                {
                    logger.Error(ex, command);
                    error = ExceptionJsonSerializer.Serialize(ex);
                }

                await userAppMessageLogProcessor.LogResponse(EventBus.DomainEvents.Enums.RequestType.MobileTransactionData,
                       command.SiteId,
                       command.UserId,
                       command.TransactionId,
                       command.UMTI,
                       error,
                       command);

                logger.TraceExitMethod(nameof(Handle));
                return await Task.FromResult(true);
            }
            catch (Exception ex)
            {
                logger.Error(ex, command);
            }

            return await Task.FromResult(false);
        }
    }
}
