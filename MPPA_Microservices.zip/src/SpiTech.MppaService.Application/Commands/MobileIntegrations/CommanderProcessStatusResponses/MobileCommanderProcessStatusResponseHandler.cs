﻿using MediatR;
using Microsoft.AspNetCore.SignalR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.MppaService.Application.Hubs;
using SpiTech.MppaService.Application.Processors;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.MobileIntegrations.CommanderProcessStatusResponses
{
    public class MobileCommanderProcessStatusResponseHandler : IRequestHandler<MobileCommanderProcessStatusResponseCommand, bool>
    {
        private readonly ILogger<MobileCommanderProcessStatusResponseHandler> logger;
        private readonly IMediator mediator;
        private readonly IMppaClient mppaHubClient;

        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAppMessageLogProcessor userAppMessageLogProcessor;

        public MobileCommanderProcessStatusResponseHandler(
                                    ILogger<MobileCommanderProcessStatusResponseHandler> logger,
                                    IMediator mediator,
                                    IMppaClient mppaHubClient,
                                    IEventDispatcher eventDispatcher,
                                    IUserAppMessageLogProcessor userAppMessageLogProcessor)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.mppaHubClient = mppaHubClient;
            _eventDispatcher = eventDispatcher;
            this.userAppMessageLogProcessor = userAppMessageLogProcessor;
        }

        public async Task<bool> Handle(MobileCommanderProcessStatusResponseCommand command, CancellationToken cancellationToken)
        {
            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);

                Domain.Models.Mobile.ProcessStatusResponse response = new()
                {
                    SiteId = command.SiteId,
                    UMTI = command.TransactionId.ToString(),
                    UserId = command.UserId,
                    Status = command.Status,
                    ProcessName = command.ProcessName,
                    Success = command.Success,
                    Erorr = command.Erorr,
                };

                string error = "";

                try
                {
                    logger.Info("ProcessStatusResponse", response);
                    await mppaHubClient.Perform(command.UserId, async client => await client.ProcessStatusResponse(response));
                    response.UMTI = command.UMTI;
                }
                catch (Exception ex)
                {
                    logger.Error(ex, command);
                    error = ExceptionJsonSerializer.Serialize(ex);
                }

                await userAppMessageLogProcessor.LogResponse(command.RequestType,
                       command.SiteId,
                       command.UserId,
                       command.TransactionId,
                       command.UMTI,
                       error,
                       response);

                logger.TraceExitMethod(nameof(Handle));

                return await Task.FromResult(true);
            }
            catch (Exception ex)
            {
                logger.Error(ex, command);
            }

            return await Task.FromResult(false);
        }
    }
}
