﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.SignalR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Mobiles;
using SpiTech.MppaService.Application.Hubs;
using SpiTech.MppaService.Application.Processors;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.MobileIntegrations.FinalizesDataResponses
{
    public class MobileFinalizesDataResponseHandler : IRequestHandler<MobileFinalizesDataResponseCommand, bool>
    {
        private readonly ILogger<MobileFinalizesDataResponseHandler> logger;
        private readonly IMediator mediator;
        private readonly IMppaClient mppaHubClient;
        private readonly IEventDispatcher _eventDispatcher;

        private readonly IMapper _mapper;
        private readonly IUserAppMessageLogProcessor userAppMessageLogProcessor;

        public MobileFinalizesDataResponseHandler(
                                    ILogger<MobileFinalizesDataResponseHandler> logger,
                                    IMediator mediator,
                                    IMppaClient mppaHubClient,
                                    IEventDispatcher eventDispatcher,
                                    IMapper mapper,
                                    IUserAppMessageLogProcessor userAppMessageLogProcessor)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.mppaHubClient = mppaHubClient;
            _eventDispatcher = eventDispatcher;
            _mapper = mapper;
            this.userAppMessageLogProcessor = userAppMessageLogProcessor;
        }

        public async Task<bool> Handle(MobileFinalizesDataResponseCommand command, CancellationToken cancellationToken)
        {
            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);

                string error = "";

                try
                {
                    var umti = command.ReceiptData.Transaction.UMTI;
                    command.ReceiptData.Transaction.UMTI = command.ReceiptData.Transaction.TransactionId.ToString();
                    await mppaHubClient.Perform(command.ReceiptData.Transaction.UserId, async client => await client.FinalizesData(command));
                    command.ReceiptData.Transaction.UMTI = umti;
                }
                catch (Exception ex)
                {
                    logger.Error(ex, command);
                    error = ExceptionJsonSerializer.Serialize(ex);
                }

                await userAppMessageLogProcessor.LogResponse(EventBus.DomainEvents.Enums.RequestType.MobileFinalize,
                        command.ReceiptData.Transaction.SiteId,
                        command.ReceiptData.Transaction.UserId,
                        command.ReceiptData.Transaction.TransactionId,
                        command.ReceiptData.Transaction.UMTI,
                        error,
                        command);

                await _eventDispatcher.Dispatch(new MobileFinalizesDataResponseEvent
                {
                    ReceiptData = command.ReceiptData
                });

                logger.TraceExitMethod(nameof(Handle));
                return await Task.FromResult(true);
            }
            catch (Exception ex)
            {
                logger.Error(ex, command);
            }

            return await Task.FromResult(false);
        }
    }
}
