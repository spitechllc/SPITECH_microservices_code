﻿using MediatR;
using SpiTech.EventBus.DomainEvents.Models.Mppa.Receipts;

namespace SpiTech.MppaService.Application.Commands.MobileIntegrations.FinalizesDataResponses
{
    public class MobileFinalizesDataResponseCommand : IRequest<bool>
    {
        public TransactionReceiptModel ReceiptData { get; set; }
    }
}
