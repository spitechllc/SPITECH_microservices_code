﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Mobiles;
using SpiTech.MppaService.Application.Hubs;
using SpiTech.MppaService.Application.Processors;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.MobileIntegrations.StacCaptureResponses
{
    public class MobileStacCaptureResponseHandler : IRequestHandler<MobileStacCaptureResponseCommand, bool>
    {
        private readonly ILogger<MobileStacCaptureResponseHandler> logger;
        private readonly IMediator mediator;
        private readonly IMppaClient mppaHubClient;

        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAppMessageLogProcessor userAppMessageLogProcessor;

        public MobileStacCaptureResponseHandler(
                                    ILogger<MobileStacCaptureResponseHandler> logger,
                                    IMediator mediator,
                                    IMppaClient mppaHubClient,
                                    IEventDispatcher eventDispatcher,
                                    IUserAppMessageLogProcessor userAppMessageLogProcessor)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.mppaHubClient = mppaHubClient;
            _eventDispatcher = eventDispatcher;
            this.userAppMessageLogProcessor = userAppMessageLogProcessor;
        }

        public async Task<bool> Handle(MobileStacCaptureResponseCommand command, CancellationToken cancellationToken)
        {
            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);
                string error = "";
                string utmi = command.UMTI;

                try
                {
                    command.UMTI = command.TransactionId.ToString();
                    await mppaHubClient.Perform(command.UserId, async client => await client.StacCaptureResponse(command));
                    command.UMTI = utmi;
                }
                catch (Exception ex)
                {
                    logger.Error(ex, command);
                    error = ExceptionJsonSerializer.Serialize(ex);
                }

                await userAppMessageLogProcessor.LogResponse(EventBus.DomainEvents.Enums.RequestType.MobileStacCapture,
                       command.SiteId,
                       command.UserId,
                       command.TransactionId,
                       command.UMTI,
                       error,
                       command);

                await _eventDispatcher.Dispatch(new MobileStacCaptureResponsesEvent
                {
                    TransactionId = command.TransactionId,
                    UMTI = command.UMTI,
                    UserId = command.UserId,
                    SiteId = command.SiteId,
                    Stac = command.Stac,
                    POSTransNumber = command.POSTransNumber,
                    WorkstationId = command.WorkstationId,
                    CaptureDate = command.CaptureDate,
                    IsMatched = command.IsMatched,
                    IsExpired = command.IsExpired,
                    Success = command.Success,
                    Erorr = command.Erorr
                });

                logger.TraceExitMethod(nameof(Handle));
                return await Task.FromResult(true);
            }
            catch (Exception ex)
            {
                logger.Error(ex, command);
            }

            return await Task.FromResult(false);

        }
    }
}
