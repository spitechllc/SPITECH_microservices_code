﻿using MediatR;
using System;

namespace SpiTech.MppaService.Application.Commands.MobileIntegrations.StacCaptureResponses
{
    public class MobileStacCaptureResponseCommand : IRequest<bool>
    {
        public long TransactionId { get; set; }
        public string UMTI { get; set; }
        public int UserId { get; set; }
        public string SiteId { get; set; }
        public string Stac { get; set; }
        public string POSTransNumber { get; set; }
        public string WorkstationId { get; set; }
        public DateTime? CaptureDate { get; set; }
        public bool IsMatched { get; set; }
        public bool IsExpired { get; set; }
        public bool Success { get; set; }
        public string Erorr { get; set; }
    }
}
