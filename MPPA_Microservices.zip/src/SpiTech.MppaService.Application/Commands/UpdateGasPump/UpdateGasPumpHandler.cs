﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.UpdateGasPump
{
    public class UpdateGasPumpHandler : IRequestHandler<UpdateGasPumpCommand, bool>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateGasPumpHandler> _logger;
        private readonly IMapper _mapper;

        public UpdateGasPumpHandler(IUnitOfWork context,
                                   ILogger<UpdateGasPumpHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<bool> Handle(UpdateGasPumpCommand request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            bool status = false;
            await _context.Execute(async () =>
            {
                status = await _context.GasPumps.Update(new Domain.Entities.GasPump()
                {
                    GasPumpId = request.GasPumpId,
                    PosId = request.PosId,
                    PumpNumber = request.PumpNumber,
                    PumpSystemId = request.PumpSystemId,
                    StoreId = request.StoreId,
                    QRCode = request.QRCode,
                    BarCode = request.BarCode,
                    IsActive = request.IsActive
                });
            });
            _logger.TraceExitMethod(nameof(Handle), status);
            return await Task.FromResult(status);
        }
    }
}
