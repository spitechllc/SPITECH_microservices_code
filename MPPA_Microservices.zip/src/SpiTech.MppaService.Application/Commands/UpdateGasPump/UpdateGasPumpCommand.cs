﻿using MediatR;

namespace SpiTech.MppaService.Application.Commands.UpdateGasPump
{
    public class UpdateGasPumpCommand : IRequest<bool>
    {
        public int GasPumpId { get; set; }
        public int StoreId { get; set; }
        public int PosId { get; set; }
        public string PumpNumber { get; set; }
        public string PumpSystemId { get; set; }
        public string QRCode { get; set; }
        public string BarCode { get; set; }
        public bool IsActive { get; set; }
    }
}
