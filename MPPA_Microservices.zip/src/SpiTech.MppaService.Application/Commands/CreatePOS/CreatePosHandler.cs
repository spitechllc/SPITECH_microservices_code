﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CreatePOS
{
    public class CreatePosHandler : IRequestHandler<CreatePosCommand, int>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreatePosHandler> _logger;
        private readonly IMapper _mapper;

        public CreatePosHandler(IUnitOfWork context,
                                   ILogger<CreatePosHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<int> Handle(CreatePosCommand request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            int posid = 0;

            await _context.Execute(async () =>
            {
                posid = await _context.PoseS.Add(new Domain.Entities.POS()
                {
                    StationNumber = request.StationNumber,
                    StationIPAddress = request.StationIPAddress,
                    StoreId = request.StoreId,
                    StationSystemId = request.StationSystemId,
                    QRCode = request.QRCode,
                    BarCode = request.BarCode,
                    NetworkType = request.NetworkType,
                    Port = request.Port,
                    IsActive = true,
                    CreatedOn = DateTime.UtcNow,
                    CreatedBy = 1 // need to pick from token 
                });
            });

            _logger.TraceExitMethod(nameof(Handle), posid);
            return await Task.FromResult(posid);
        }
    }
}
