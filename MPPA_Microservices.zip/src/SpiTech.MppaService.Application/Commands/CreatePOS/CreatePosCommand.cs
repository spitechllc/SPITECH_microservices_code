﻿using MediatR;

namespace SpiTech.MppaService.Application.Commands.CreatePOS
{
    public class CreatePosCommand : IRequest<int>
    {
        public int StoreId { get; set; }
        public string StationNumber { get; set; }
        public string StationSystemId { get; set; }
        public string StationIPAddress { get; set; }
        public string QRCode { get; set; }
        public string BarCode { get; set; }
        public string NetworkType { get; set; }
        public string Port { get; set; }
    }
}
