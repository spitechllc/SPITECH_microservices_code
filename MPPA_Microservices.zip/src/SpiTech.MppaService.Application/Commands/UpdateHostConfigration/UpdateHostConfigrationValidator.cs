﻿using FluentValidation;

namespace SpiTech.MppaService.Application.Commands.UpdateHostConfigration
{
    public class UpdateHostConfigrationValidator : AbstractValidator<UpdateHostConfigrationCommand>
    {
        public UpdateHostConfigrationValidator()
        {

            RuleFor(x => x.ConfigId).GreaterThan(0).WithMessage("ConfigId must be greater than 0");
            RuleFor(x => x.Interface).NotNull().MaximumLength(50).WithMessage("Interface is required");
            RuleFor(x => x.ProgramName).NotNull().MaximumLength(50).WithMessage("ProgramName is required.");
            RuleFor(x => x.MerchantId).GreaterThan(0).WithMessage("MerchantId must be greater than 0");
            RuleFor(x => x.AuthenticationType).NotNull().MaximumLength(50).WithMessage("AuthenticationType is required");
            RuleFor(x => x.SiteTerminalId).NotNull().MaximumLength(50).WithMessage("SiteTerminalId is required");
            RuleFor(x => x.LocationId).NotNull().MaximumLength(50).WithMessage("LocationId is required");

            RuleFor(x => x.StoreId).GreaterThan(0).WithMessage("StoreId must be greater than 0");
            RuleFor(x => x.SettlementEmpNumber).NotNull().MaximumLength(50).WithMessage("SettlementEmpNumber is required");
            RuleFor(x => x.SettlementPasscode).NotNull().MaximumLength(50).WithMessage("SettlementPasscode is required");

            RuleFor(x => x.DomainName).NotNull().MaximumLength(200).WithMessage("DomainName is required");
            RuleFor(x => x.Heartbeatfrequency).NotNull().MaximumLength(100).WithMessage("Heartbeatfrequency is required");
            RuleFor(x => x.HeartbeatTimeUnit).NotNull().MaximumLength(50).WithMessage("HeartbeatTimeUnit is required");

            RuleFor(s => s.PhoneNumber).MaximumLength(14);
            RuleFor(s => s.SiteLoyality).MaximumLength(50);
            RuleFor(s => s.MNSPId).MaximumLength(50);
            RuleFor(s => s.MNSP).MaximumLength(50);
        }
    }
}