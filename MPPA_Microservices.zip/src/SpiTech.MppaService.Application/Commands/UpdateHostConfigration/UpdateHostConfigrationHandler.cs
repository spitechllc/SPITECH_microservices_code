﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.UpdateHostConfigration
{
    public class UpdateHostConfigrationHandler : IRequestHandler<UpdateHostConfigrationCommand, bool>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateHostConfigrationHandler> _logger;
        private readonly IMapper _mapper;

        public UpdateHostConfigrationHandler(IUnitOfWork context,
                                    ILogger<UpdateHostConfigrationHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<bool> Handle(UpdateHostConfigrationCommand command, CancellationToken cancellationToken)
        {

            _logger.TraceEnterMethod(nameof(Handle), command);

            bool result = false;

            await _context.Execute(async () =>
            {
                result = await _context.HostConfigrations.Update(new Domain.Entities.HostConfigration()
                {
                    ConfigId = command.ConfigId,
                    Interface = command.Interface,
                    ProgramName = command.ProgramName,
                    MerchantId = command.MerchantId,
                    AuthenticationType = command.AuthenticationType,
                    SiteTerminalId = command.SiteTerminalId,
                    LocationId = command.LocationId,
                    StoreId = command.StoreId,
                    SettlementEmpNumber = command.SettlementEmpNumber,
                    SettlementPasscode = command.SettlementPasscode,
                    PhoneNumber = command.PhoneNumber,
                    DomainName = command.DomainName,
                    Heartbeatfrequency = command.Heartbeatfrequency,
                    HeartbeatTimeUnit = command.HeartbeatTimeUnit,
                    SSLAllow = command.SSLAllow,
                    OutdoorAuthenticationTimeout = command.OutdoorAuthenticationTimeout,
                    SiteLoyality = command.SiteLoyality,
                    IsActive = command.IsActive,
                    MNSP= command.MNSP,
                    MNSPId=command.MNSPId

                });
            });

            _logger.TraceExitMethod(nameof(Handle), result);
            return await Task.FromResult(result);

        }
    }
}
