﻿using MediatR;
using SpiTech.MppaService.Domain.Entities;

namespace SpiTech.MppaService.Application.Commands.UpdateSettlementRequest
{
    public class UpdateSettlementRequestCommand : IRequest<bool>
    {
        public SettlementRequest SettlementRequest { get; set; }
    }
}
