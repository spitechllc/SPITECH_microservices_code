﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.UpdateSettlementRequest
{
    public class UpdateSettlementRequestHandler : IRequestHandler<UpdateSettlementRequestCommand, bool>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<UpdateSettlementRequestHandler> logger;
        private readonly IMediator mediator;

        public UpdateSettlementRequestHandler(IUnitOfWork context,
                                    ILogger<UpdateSettlementRequestHandler> logger,
                                    IMediator mediator)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
        }

        public async Task<bool> Handle(UpdateSettlementRequestCommand command, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), command);
            bool status = false;
            try
            {
                status = await context.SettlementRequests.UpdateSettlement(command.SettlementRequest);
                context.Commit();
            }
            catch (Exception)
            {
                context.Rollback();
                throw;
            }

            logger.TraceExitMethod(nameof(Handle), status);
            return status;
        }
    }
}
