﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.MppaService.Application.UnitOfWorks;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.ReconcileFailTransactions
{
    public class ReconcileFailTransactionsHandler : IRequestHandler<ReconcileFailTransactionsCommand, bool>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<ReconcileFailTransactionsHandler> _logger;
        private readonly IEventDispatcher eventDispatcher;

        public ReconcileFailTransactionsHandler(IUnitOfWork context,
                                                ILogger<ReconcileFailTransactionsHandler> logger,
                                                IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            this.eventDispatcher = eventDispatcher;
        }

        public async Task<bool> Handle(ReconcileFailTransactionsCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            bool result = false;

            var inprogressTransactionIds = new List<long>();

            await _context.Execute(async () =>
            {
                inprogressTransactionIds = await _context.Transactions.ReconcileFailTransactions(command.TransactionTimeoutInSec);
            });

            if (inprogressTransactionIds != null && inprogressTransactionIds.Any())
            {
                await eventDispatcher.Dispatch(new ReconcileFailTransactionEvent
                {
                   TransactionIds= inprogressTransactionIds.ToArray()
                });
            }

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
