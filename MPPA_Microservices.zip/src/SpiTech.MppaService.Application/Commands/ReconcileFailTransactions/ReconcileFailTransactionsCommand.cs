﻿using MediatR;

namespace SpiTech.MppaService.Application.Commands.ReconcileFailTransactions
{
    public class ReconcileFailTransactionsCommand : IRequest<bool>
    {
        public int TransactionTimeoutInSec { get; set; }
    }
}
