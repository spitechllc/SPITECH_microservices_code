﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Entities;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.SaveSettlementRequest
{
    public class SaveSettlementRequestHandler : IRequestHandler<SaveSettlementRequestCommand, bool>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<SaveSettlementRequestHandler> logger;
        private readonly IMediator mediator;

        public SaveSettlementRequestHandler(IUnitOfWork context,
                                    ILogger<SaveSettlementRequestHandler> logger,
                                    IMediator mediator)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
        }

        public async Task<bool> Handle(SaveSettlementRequestCommand command, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), command);
            logger.Warn($"settlement data: {command.SettlementRequest}");
            SettlementRequest settlement = null;

            try
            {
                settlement = await context.SettlementRequests.InsertSettlement(command.SettlementRequest);
                context.Commit();
            }
            catch (Exception)
            {
                context.Rollback();
                throw;
            }

            logger.TraceExitMethod(nameof(Handle), settlement != null);
            return settlement != null;
        }
    }
}
