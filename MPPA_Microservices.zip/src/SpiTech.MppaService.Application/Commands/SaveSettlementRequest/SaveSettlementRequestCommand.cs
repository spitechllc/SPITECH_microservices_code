﻿using MediatR;
using SpiTech.MppaService.Domain.Entities;

namespace SpiTech.MppaService.Application.Commands.SaveSettlementRequest
{
    public class SaveSettlementRequestCommand : IRequest<bool>
    {
        public SettlementRequest SettlementRequest { get; set; }
    }
}
