﻿using MediatR;
using SpiTech.MppaService.Domain.Entities;

namespace SpiTech.MppaService.Application.Commands.CreateTransaction
{
    public class CreateTransactionCommand : IRequest<long>
    {
        public Transaction Transaction { get; set; }
    }
}
