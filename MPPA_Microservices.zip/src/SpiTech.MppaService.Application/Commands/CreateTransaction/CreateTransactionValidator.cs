﻿using FluentValidation;

namespace SpiTech.MppaService.Application.Commands.CreateTransaction
{
    public class CreateTransactionValidator : AbstractValidator<CreateTransactionCommand>
    {
        public CreateTransactionValidator()
        {
            RuleFor(x => x.Transaction).NotNull().WithMessage("Transaction is required");
            //RuleFor(x => x.Transaction.SiteId).NotNull().WithMessage("SiteId is required").NotEmpty().WithMessage("SiteId is required");
        }
    }
}
