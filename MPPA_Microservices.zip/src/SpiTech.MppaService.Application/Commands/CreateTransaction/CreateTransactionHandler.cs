﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CreateTransaction
{
    public class CreateTransactionHandler : IRequestHandler<CreateTransactionCommand, long>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateTransactionHandler> _logger;
        private readonly IMapper _mapper;
        public CreateTransactionHandler(IUnitOfWork context,
                                   ILogger<CreateTransactionHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<long> Handle(CreateTransactionCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            long transactionId = 0;
            _logger.Warn($"MPPA_R Transaction Card Amt:" + command.Transaction.CardAmount 
                                  +": Store Name : "+ command.Transaction.StoreName
                                  + ": UserId : " + command.Transaction.UserId
                                  + ": StoreId : " + command.Transaction.StoreId
                                  + ": SiteId : " + command.Transaction.SiteId
                                  + ": IsPaymentSuccess : " + command.Transaction.IsPaymentSuccess
                                  + ": PaymentErrorMessage : " + command.Transaction.PaymentErrorMessage
                                  + ": MppaErrorMessage : " + command.Transaction.MppaErrorMessage
                                  + ": PreauthAmount : " + command.Transaction.PreauthAmount
                                  + ": SettlementRequestId : " + command.Transaction.SettlementRequestId);

            await _context.Execute(async () =>
            {
                transactionId = await _context.Transactions.Insert(command.Transaction);
            });
            _logger.TraceExitMethod(nameof(Handle), transactionId);
            _logger.Warn($"MPPA_R Transaction Data check transactionId : " + transactionId);
            return await Task.FromResult(transactionId);
        }
    }
}
