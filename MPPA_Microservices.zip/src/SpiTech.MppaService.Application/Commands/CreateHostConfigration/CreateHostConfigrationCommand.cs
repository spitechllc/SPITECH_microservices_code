﻿using MediatR;

namespace SpiTech.MppaService.Application.Commands.CreateHostConfigration
{
    public class CreateHostConfigrationCommand : IRequest<int>
    {
        public string Interface { get; set; }
        public string ProgramName { get; set; }
        public int MerchantId { get; set; }
        public string AuthenticationType { get; set; }
        public string SiteTerminalId { get; set; }
        public string LocationId { get; set; }
        public int StoreId { get; set; }
        public string SettlementEmpNumber { get; set; }
        public string SettlementPasscode { get; set; }
        public string PhoneNumber { get; set; }
        public string DomainName { get; set; }
        public string Heartbeatfrequency { get; set; }
        public string HeartbeatTimeUnit { get; set; }
        public bool SSLAllow { get; set; }
        public int OutdoorAuthenticationTimeout { get; set; }
        public string SiteLoyality { get; set; }
        public string MNSPId { get; set; }
        public string MNSP { get; set; }
    }
}
