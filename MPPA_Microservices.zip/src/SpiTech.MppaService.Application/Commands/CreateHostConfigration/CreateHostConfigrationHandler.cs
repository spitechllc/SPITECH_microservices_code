﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CreateHostConfigration
{
    public class CreateHostConfigrationHandler : IRequestHandler<CreateHostConfigrationCommand, int>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateHostConfigrationHandler> _logger;
        private readonly IMapper _mapper;

        public CreateHostConfigrationHandler(IUnitOfWork context,
                                    ILogger<CreateHostConfigrationHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<int> Handle(CreateHostConfigrationCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            int configid = 0;

            await _context.Execute(async () =>
            {
                configid = await _context.HostConfigrations.Add(new Domain.Entities.HostConfigration()
                {
                    Interface = command.Interface,
                    ProgramName = command.ProgramName,
                    MerchantId = command.MerchantId,
                    AuthenticationType = command.AuthenticationType,
                    SiteTerminalId = command.SiteTerminalId,
                    LocationId = command.LocationId,
                    StoreId = command.StoreId,
                    SettlementEmpNumber = command.SettlementEmpNumber,
                    SettlementPasscode = command.SettlementPasscode,
                    PhoneNumber = command.PhoneNumber,
                    DomainName = command.DomainName,
                    Heartbeatfrequency = command.Heartbeatfrequency,
                    HeartbeatTimeUnit = command.HeartbeatTimeUnit,
                    SSLAllow = command.SSLAllow,
                    OutdoorAuthenticationTimeout = command.OutdoorAuthenticationTimeout,
                    SiteLoyality = command.SiteLoyality,
                    MNSPId=command.MNSPId,
                    MNSP=command.MNSP,
                    IsActive = true,
                    CreatedOn = DateTime.UtcNow,
                    CreatedBy = 1 /// need to pick from token

                });
            });
            _logger.TraceExitMethod(nameof(Handle), configid);
            return await Task.FromResult(configid);

        }
    }
}
