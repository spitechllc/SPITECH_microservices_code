﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using Microsoft.AspNetCore.SignalR;
using SpiTech.Application.Logging.Extensions;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.MppaService.Application.Commands.MobileIntegrations.FinalizesDataResponses;
using SpiTech.MppaService.Application.Commands.UpdateTransaction;
using SpiTech.MppaService.Application.Hubs;
using SpiTech.MppaService.Application.Queries.GetMPPAHost;
using SpiTech.MppaService.Application.Queries.GetSiteById;
using SpiTech.MppaService.Application.Queries.GetTransactionById;
using SpiTech.MppaService.Application.Queries.GetTransactionByUmtiMId;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Models.Commanders.MobileFinalizes;
using SpiTech.Service.Clients.Payments;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;
using static SpiTech.MppaService.Domain.Constants;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.FinalizeRequests
{
    public class CommanderFinalizeRequestHandler : IRequestHandler<CommanderFinalizeRequestCommand, bool>
    {
        private readonly ILogger<CommanderFinalizeRequestHandler> logger;
        private readonly IMediator mediator;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IPaymentServiceClient paymentApiClient;
        private readonly IMapper mapper;
        private readonly IUnitOfWork context;
        private readonly IHubContext<DashBoardHub, IDashBoardHubClient> dashBoardHubcontext;

        public CommanderFinalizeRequestHandler(
                                    ILogger<CommanderFinalizeRequestHandler> logger,
                                    IMediator mediator,
                                    IEventDispatcher eventDispatcher,
                                    IPaymentServiceClient paymentApiClient,
                                    IMapper mapper,
                                    IUnitOfWork context,
                                    IHubContext<DashBoardHub, IDashBoardHubClient> dashBoardHubcontext)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.eventDispatcher = eventDispatcher;
            this.paymentApiClient = paymentApiClient;
            this.mapper = mapper;
            this.context = context;
            this.dashBoardHubcontext = dashBoardHubcontext;
        }

        public async Task<bool> Handle(CommanderFinalizeRequestCommand command, CancellationToken cancellationToken)
        {
            Domain.Entities.Transaction transaction = null;

            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);
                logger.Info("CommanderFinalizeRequestCommand", command.FinalizeRequest.MobileTxnInfo.UMTI, command.FinalizeRequest.MobileFinalizeRequest.PaymentInfo.FinalAmount);

                transaction = await mediator.Send(new GetTransactionByUmtiMIdQuery
                {
                    UMTI = command.FinalizeRequest.MobileTxnInfo.UMTI,
                    MerchantId = command.FinalizeRequest.MobileTxnInfo.MerchantId,
                });

                if (transaction == null)
                {
                    throw new ValidationException(new ValidationFailure("UMTI", $"CommanderFinalizeRequest-UMTI{command.FinalizeRequest.MobileTxnInfo.UMTI}-{command.FinalizeRequest.MobileTxnInfo.MerchantId} is invalid"));
                }

                Domain.Models.HostMPPAModel hostMPPA = await mediator.Send(new MPPAHostQuery { });
                if (hostMPPA != null && !hostMPPA.IsProdEnabled)
                {
                    command.FinalizeRequest.MobileFinalizeRequest.PaymentInfo.FinalAmount = transaction.PreauthAmount;
                }

                string message = Serializer.Serialize<FinalizeCommanderRequest>(command.FinalizeRequest);

                transaction.FinalizeDate = DateTime.UtcNow;
                transaction.FinalAmount = command.FinalizeRequest.MobileFinalizeRequest.PaymentInfo.FinalAmount;
                transaction.SettlementPeriodId = command.FinalizeRequest.MobileTxnInfo.SettlementPeriodId;

                if (transaction.StatusId != (int)Status.Canceled)
                {
                    transaction.StatusId = (int)Status.Success;
                }

                await mediator.Send(new UpdateTransactionCommand
                {
                    Transaction = transaction
                });

                await ProcessPayment(command, transaction);

                await mediator.Send(new UpdateTransactionCommand
                {
                    Transaction = transaction
                });

                await NotifyDashBoard(transaction);

                int totalTransactionCount = 0;

                if (transaction.StatusId == (int)Status.Success)
                {
                    totalTransactionCount = await context.Transactions.GetSuccessTransactionCount(transaction.UserId);
                }

                await eventDispatcher.Dispatch(new FinalizeRequestEvent
                {
                    RequestTypeId = (int)RequestType.MobileFinalize,
                    Transaction = mapper.Map<EventBus.DomainEvents.Models.Mppa.Transaction>(transaction),
                    SaleItems = command.FinalizeRequest.MobileFinalizeRequest?.ItemsPurchased == null ? null : mapper.Map<EventBus.DomainEvents.Models.Mppa.SaleItem[]>(command.FinalizeRequest.MobileFinalizeRequest?.ItemsPurchased?.SaleItems),
                    TransactionSequenceNo = totalTransactionCount
                });

                logger.Info("Send CommanderFinalizeRequestCommand", command.FinalizeRequest.MobileTxnInfo.UMTI, command.FinalizeRequest.MobileFinalizeRequest.PaymentInfo.FinalAmount);

                //Send Receipt to Mobile
                await SendStatusToMobile(command, transaction);

                logger.Info("ProcessPaymentAsync Amount", command.FinalizeRequest.MobileFinalizeRequest.PaymentInfo.FinalAmount);

                await mediator.Send(new FinalizeResponses.MppaFinalizeResponseCommand
                {
                    FinalizeRequest = command.FinalizeRequest
                });

                logger.TraceExitMethod(nameof(Handle));
                return await Task.FromResult(true);
            }
            catch (Exception ex)
            {
                logger.Error(ex, transaction, command);
                if (transaction != null)
                {
                    transaction.MppaErrorMessage = ex.Message;
                    await mediator.Send(new UpdateTransactionCommand
                    {
                        Transaction = transaction
                    });
                }
            }

            return await Task.FromResult(false);
        }

        private async Task NotifyDashBoard(Domain.Entities.Transaction transaction)
        {
            try
            {
                await this.dashBoardHubcontext.Clients.All.DashBoardMessage(new Domain.Models.DashBoardEventModel
                {
                    ChangeIdentifier = transaction.TransactionId.ToString(),
                    Event = DashBoardEvent.Transaction,
                    Message = "Transaction Added"
                });
            }
            catch (Exception ex)
            {
                logger.Error(ex, "DashBoardHub Error");
            }
        }

        private async Task SendStatusToMobile(CommanderFinalizeRequestCommand command, Domain.Entities.Transaction transaction)
        {
            EventBus.DomainEvents.Models.Mppa.PaymentInfo paymentInfo = null;
            Domain.Entities.Site site = await mediator.Send(new GetSiteByIdQuery
            {
                SiteId = transaction.SiteId
            });

            try
            {
                paymentInfo = mapper.Map<EventBus.DomainEvents.Models.Mppa.PaymentInfo>(command.FinalizeRequest.MobileFinalizeRequest.PaymentInfo);

                if (paymentInfo == null)
                {
                    paymentInfo = new EventBus.DomainEvents.Models.Mppa.PaymentInfo();
                }

                if (string.IsNullOrEmpty(paymentInfo.CardISO))
                {
                    paymentInfo.CardISO = transaction.CardPrint;
                }

                if (string.IsNullOrEmpty(paymentInfo.PaymentMethod))
                {
                    paymentInfo.PaymentMethod = transaction.CardPrint;
                }

                if (string.IsNullOrEmpty(paymentInfo.CardPANPrint))
                {
                    paymentInfo.CardPANPrint = transaction.PaymentMethod;
                }

                if (string.IsNullOrEmpty(paymentInfo.CardType))
                {
                    paymentInfo.CardType = transaction.CardType;
                }

                if (paymentInfo.PreAuthAmount <= 0)
                {
                    paymentInfo.PreAuthAmount = transaction.PreauthAmount;
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex, transaction);
            }

            await mediator.Send(new MobileFinalizesDataResponseCommand
            {
                ReceiptData = new EventBus.DomainEvents.Models.Mppa.Receipts.TransactionReceiptModel
                {
                    PaymentInfo = paymentInfo,
                    ReceiptInfoLines = new string[] { },
                    SiteName = site?.SiteName,
                    SiteAddress = site?.SiteAddress,
                    Transaction = mapper.Map<EventBus.DomainEvents.Models.Mppa.Transaction>(transaction),
                    SaleItems = command.FinalizeRequest.MobileFinalizeRequest?.ItemsPurchased == null ? null : mapper.Map<EventBus.DomainEvents.Models.Mppa.SaleItem[]>(command.FinalizeRequest.MobileFinalizeRequest?.ItemsPurchased?.SaleItems),
                }
            });
        }

        private async Task ProcessPayment(CommanderFinalizeRequestCommand command, Domain.Entities.Transaction transaction)
        {
            ProcessPaymentCommand paymentProcessCommand = null;

            if (string.IsNullOrWhiteSpace(transaction.PreauthConfirmationNo))
            {
                transaction.WalletAmount = 0;
                transaction.CardAmount = 0;
                transaction.PaymentId = 0;
                transaction.PaymentErrorMessage = "PreauthConfirmationNo Is Empty";
                return;
            }

            try
            {
                paymentProcessCommand = new ProcessPaymentCommand
                {
                    Amount = (double)command.FinalizeRequest.MobileFinalizeRequest.PaymentInfo.FinalAmount,
                    PreAuthConfirmationNo = transaction.PreauthConfirmationNo,
                    TransactionId = transaction.TransactionId,
                    UserId = transaction.UserId,
                };

                if (command.FinalizeRequest.MobileFinalizeRequest.ItemsPurchased != null && command.FinalizeRequest.MobileFinalizeRequest.ItemsPurchased.SaleItems != null)
                {
                    paymentProcessCommand.PaymentDescription = ((TransactionType)transaction.TransactionTypeId).ToString();
                }

                using (logger.LogPerformance("ProcessPaymentAsync"))
                {
                    logger.Info("ProcessPaymentAsync paymentProcessCommand", paymentProcessCommand);
                    PaymentResponseModelResponseModel paymentResponseModel = null;

                    try
                    {
                        paymentResponseModel = await paymentApiClient.FinalizeAsync(paymentProcessCommand);
                        if (paymentResponseModel != null && paymentResponseModel.Data != null)
                        {
                            transaction.WalletAmount = (decimal)paymentResponseModel.Data.WalletAmount;
                            transaction.CardAmount = (decimal)paymentResponseModel.Data.CardAmount;
                            transaction.PaymentId = paymentResponseModel.Data.PaymentId;
                        }
                    }
                    catch (Exception ex)
                    {
                        logger.Error(ex, transaction);
                        transaction.PaymentErrorMessage = ex.Message;
                    }

                    transaction.IsPaymentSuccess = paymentResponseModel?.Success ?? false;
                    logger.Info("ProcessPaymentAsync paymentResponseModel", paymentResponseModel);
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex, transaction);
            }
        }
    }
}
