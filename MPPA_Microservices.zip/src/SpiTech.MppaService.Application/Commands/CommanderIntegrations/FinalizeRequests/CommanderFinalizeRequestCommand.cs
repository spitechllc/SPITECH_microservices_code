﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.MobileFinalizes;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.FinalizeRequests
{
    public class CommanderFinalizeRequestCommand : IRequest<bool>
    {
        public FinalizeCommanderRequest FinalizeRequest { get; set; }
    }
}
