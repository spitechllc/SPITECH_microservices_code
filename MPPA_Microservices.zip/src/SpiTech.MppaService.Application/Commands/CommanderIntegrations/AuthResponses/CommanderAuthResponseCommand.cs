﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.MobileAuths;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.AuthResponses
{
    public class CommanderAuthResponseCommand : IRequest<bool>
    {
        public AuthCommanderResponse AuthResponse { get; set; }
    }
}
