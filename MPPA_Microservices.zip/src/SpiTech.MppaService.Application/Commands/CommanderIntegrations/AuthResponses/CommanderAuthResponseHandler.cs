﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.MppaService.Application.Commands.MobileIntegrations.CommanderProcessStatusResponses;
using SpiTech.MppaService.Application.Commands.UpdateTransaction;
using SpiTech.MppaService.Application.Queries.GetTransactionById;
using SpiTech.MppaService.Application.Queries.GetTransactionByUmtiMId;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Models.Commanders.MobileAuths;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.AuthResponses
{
    public class CommanderAuthResponseHandler : IRequestHandler<CommanderAuthResponseCommand, bool>
    {
        private readonly ILogger<CommanderAuthResponseHandler> logger;
        private readonly IMediator mediator;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IMapper mapper;

        public CommanderAuthResponseHandler(
                                    ILogger<CommanderAuthResponseHandler> logger,
                                    IMediator mediator,
                                    IEventDispatcher eventDispatcher,
                                    IMapper mapper)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.eventDispatcher = eventDispatcher;
            this.mapper = mapper;
        }

        public async Task<bool> Handle(CommanderAuthResponseCommand command, CancellationToken cancellationToken)
        {
            bool isSuccess = false;
            string error = "";
            Domain.Entities.Transaction transaction = null;

            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);

                transaction = await mediator.Send(new GetTransactionByUmtiMIdQuery { 
                    UMTI = command.AuthResponse.MobileTxnInfo.UMTI ,
                    MerchantId = command.AuthResponse.MobileTxnInfo.MerchantId,
                });

                if (transaction == null)
                {
                    throw new ValidationException(new ValidationFailure("UMTI", $"CommanderAuthResponse-UMTI-{command.AuthResponse.MobileTxnInfo.UMTI}-{command.AuthResponse.MobileTxnInfo.MerchantId} is invalid"));
                }

                string message = Serializer.Serialize<AuthCommanderResponse>(command.AuthResponse);

                isSuccess = command.AuthResponse.MobileAuthResponse.Response.ResponseCode == Constants.SuccessResponseCode;
                error = isSuccess ? "" : $"{command.AuthResponse.MobileAuthResponse.Response.ResponseCode}-{command.AuthResponse.MobileAuthResponse.Response.OverallResult}-{command.AuthResponse.MobileAuthResponse.Response.MessageCode}";

                //Send PumpProcessStatus to Mobile
                await mediator.Send(new MobileCommanderProcessStatusResponseCommand
                {
                    TransactionId = transaction.TransactionId,
                    RequestType = RequestType.MobileAuth,
                    SiteId = command.AuthResponse.MobileTxnInfo.SiteId,
                    UMTI = command.AuthResponse.MobileTxnInfo.UMTI,
                    UserId = transaction.UserId,
                    Status = isSuccess ? ProcessConstants.AuthSuccess : ProcessConstants.AuthError,
                    ProcessName = ProcessConstants.AuthProcessName,
                    Success = isSuccess,
                    Erorr = error
                });

                transaction.POSTransNumber = command.AuthResponse.MobileTxnInfo.POSTransNumber;

                if (!isSuccess)
                {
                    transaction.StatusId = (int)Status.Fail;
                    transaction.MppaErrorMessage = error;
                }

                await mediator.Send(new UpdateTransactionCommand
                {
                    Transaction = transaction
                });

                await eventDispatcher.Dispatch(new TransactionUpdateEvent
                {
                    Transaction = mapper.Map<EventBus.DomainEvents.Models.Mppa.Transaction>(transaction),
                    RequestTypeId = (int)RequestType.MobileAuth,
                });
            }
            catch (Exception ex)
            {
                logger.Error(ex, transaction, command);
                if (transaction != null)
                {
                    transaction.MppaErrorMessage = ex.Message;
                    await mediator.Send(new UpdateTransactionCommand
                    {
                        Transaction = transaction
                    });
                }
            }

            logger.TraceExitMethod(nameof(Handle), isSuccess);

            return await Task.FromResult(isSuccess);
        }
    }
}
