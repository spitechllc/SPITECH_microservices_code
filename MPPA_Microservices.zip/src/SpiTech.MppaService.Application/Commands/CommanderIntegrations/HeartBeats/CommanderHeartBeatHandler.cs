﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.Commands.SaveHeartBeat;
using SpiTech.MppaService.Application.Processors;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Models.Commanders;
using SpiTech.MppaService.Domain.Models.Commanders.HeartBeats;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.HeartBeats
{
    public class CommanderHeartBeatHandler : IRequestHandler<CommanderHeartBeatCommand, HeartBeatMppaResponse>
    {
        private readonly ILogger<CommanderHeartBeatHandler> logger;
        private readonly IMediator mediator;
        private readonly IMppaMessageProcessor mppaMessageProcessor;

        public CommanderHeartBeatHandler(
                                    ILogger<CommanderHeartBeatHandler> logger,
                                    IMediator mediator,
                                    IMppaMessageProcessor mppaMessageProcessor)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.mppaMessageProcessor = mppaMessageProcessor;
        }

        public async Task<HeartBeatMppaResponse> Handle(CommanderHeartBeatCommand command, CancellationToken cancellationToken)
        {
            HeartBeatMppaResponse response = null;
            logger.Warn($"MPPA CommanderHeartBeatHandler Start");
            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);

                response = new HeartBeatMppaResponse
                {
                    MobileTxnInfo = command.HeartBeatRequest.MobileTxnInfo
                };
                response.MobileTxnInfo.TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK");
                response.MobileHeartBeatResponse = new MobileResponse
                {
                    Response = new Response
                    {
                        MessageCode = Constants.SuccessMessageCode,
                        OverallResult = Constants.SuccessOverallResult,
                        ResponseCode = Constants.SuccessResponseCode
                    }
                };

                logger.Warn($"MPPA CommanderHeartBeatHandler Start 2");
                logger.Warn($"MPPA CommanderHeartBeatHandler Start 3");
                await mediator.Send(new SaveHeartBeatCommand { MobileTxnInfo = command.HeartBeatRequest.MobileTxnInfo });

                logger.Warn($"MPPA CommanderHeartBeatHandler Start 4");

                string responseMsg = Serializer.Serialize<HeartBeatMppaResponse>(response);

                ApplicationCore.Domain.Models.ResponseModel result = await mppaMessageProcessor.Process(null,
                                                            responseMsg,
                                                            response,
                                                            false,
                                                            EventBus.DomainEvents.Enums.RequestType.MobileHeartBeat,
                                                            response.MobileTxnInfo,
                                                            true,
                                                            response.MobileHeartBeatResponse.Response);

                logger.TraceExitMethod(nameof(Handle), response);

                return await Task.FromResult(response);
            }
            catch (Exception ex)
            {
                logger.Error(ex, response, command);
            }

            return await Task.FromResult(response);
        }
    }
}
