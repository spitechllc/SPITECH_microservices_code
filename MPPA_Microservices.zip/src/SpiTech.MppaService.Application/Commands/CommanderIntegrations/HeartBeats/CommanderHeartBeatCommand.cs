﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.HeartBeats;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.HeartBeats
{
    public class CommanderHeartBeatCommand : IRequest<HeartBeatMppaResponse>
    {
        public HeartBeatCommanderRequest HeartBeatRequest { get; set; }
    }
}
