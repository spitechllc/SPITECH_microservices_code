﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.BeginFueling;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.BeginFuelingResponses
{
    public class MppaBeginFuelingResponseCommand : IRequest<bool>
    {
        public BeginFuelingCommanderRequest BeginFuelingCommanderRequest { get; set; }
    }
}
