﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents;
using SpiTech.MppaService.Application.Commands.UpdateTransaction;
using SpiTech.MppaService.Application.Processors;
using SpiTech.MppaService.Application.Queries.GetTransactionById;
using SpiTech.MppaService.Application.Queries.GetTransactionByUmtiMId;
using SpiTech.MppaService.Application.Services;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Models.Commanders;
using SpiTech.MppaService.Domain.Models.Commanders.BeginFueling;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.BeginFuelingResponses
{
    public class MppaBeginFuelingResponseHandler : IRequestHandler<MppaBeginFuelingResponseCommand, bool>
    {
        private readonly ILogger<MppaBeginFuelingResponseHandler> logger;
        private readonly IMediator mediator;
        private readonly HostConfig hostConfig;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IMapper mapper;
        private readonly IMppaMessageProcessor mppaMessageProcessor;
        private readonly IPayAtPumpFakeTestService payAtPumpFakeTestService;

        public MppaBeginFuelingResponseHandler(
                                    ILogger<MppaBeginFuelingResponseHandler> logger,
                                    IMediator mediator,
                                    HostConfig hostConfig,
                                    IEventDispatcher eventDispatcher,
                                    IMapper mapper,
                                    IMppaMessageProcessor mppaMessageProcessor,
                                    IPayAtPumpFakeTestService payAtPumpFakeTestService)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.hostConfig = hostConfig;
            this.eventDispatcher = eventDispatcher;
            this.mapper = mapper;
            this.mppaMessageProcessor = mppaMessageProcessor;
            this.payAtPumpFakeTestService = payAtPumpFakeTestService;
        }

        public async Task<bool> Handle(MppaBeginFuelingResponseCommand command, CancellationToken cancellationToken)
        {
            Domain.Entities.Transaction transaction = null;

            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);

                transaction = await mediator.Send(new GetTransactionByUmtiMIdQuery { 
                    UMTI = command.BeginFuelingCommanderRequest.MobileTxnInfo.UMTI,
                    MerchantId = command.BeginFuelingCommanderRequest.MobileTxnInfo.MerchantId
                });

                if (transaction == null)
                {
                    throw new ValidationException(new ValidationFailure("UMTI", $"MppaBeginFuelingResponse-UMTI-{command.BeginFuelingCommanderRequest.MobileTxnInfo.UMTI}-{command.BeginFuelingCommanderRequest.MobileTxnInfo.MerchantId} is invalid"));
                }

                BeginFuelingMppaResponse beginFuelingMppaResponse = new()
                {
                    MobileTxnInfo = new MobileTxnInfoResponse
                    {
                        FuelingPositionId = command.BeginFuelingCommanderRequest.MobileTxnInfo.FuelingPositionId,
                        HostMPPAIdentifier = hostConfig.HostMPPAIdentifier,
                        MerchantId = command.BeginFuelingCommanderRequest.MobileTxnInfo.MerchantId,
                        SiteId = command.BeginFuelingCommanderRequest.MobileTxnInfo.SiteId,
                        UMTI = command.BeginFuelingCommanderRequest.MobileTxnInfo.UMTI,
                        TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                        SiteMPPAIdentifier = transaction.SiteMPPAIdentifier
                    },
                    MobileBeginFuelingResponse = new MobileResponse
                    {
                        Response = new Response
                        {
                            MessageCode = Constants.SuccessMessageCode,
                            OverallResult = Constants.SuccessOverallResult,
                            ResponseCode = Constants.SuccessResponseCode
                        }
                    }
                };

                string beginFuelingMppaResponseMsg = Serializer.Serialize<BeginFuelingMppaResponse>(beginFuelingMppaResponse);
                ApplicationCore.Domain.Models.ResponseModel result = null;

                //For Testing PayAtPump Begin
                if (!hostConfig.IsPayAtPumpTestingEnabled)
                {
                    result = await mppaMessageProcessor.Process(transaction.TransactionId,
                                                            beginFuelingMppaResponseMsg,
                                                            beginFuelingMppaResponse,
                                                            false,
                                                            EventBus.DomainEvents.Enums.RequestType.BeginFueling,
                                                            beginFuelingMppaResponse.MobileTxnInfo,
                                                            true,
                                                            beginFuelingMppaResponse.MobileBeginFuelingResponse.Response);
                }
                else
                {
                    result = new ApplicationCore.Domain.Models.ResponseModel { Message = "", Success = true };
                    await payAtPumpFakeTestService.GenerateFakeCommanderFinalizeRequest(transaction);
                }
                //For Testing PayAtPump END

                logger.TraceExitMethod(nameof(Handle));
                return await Task.FromResult(result.Success);
            }
            catch (Exception ex)
            {
                logger.Error(ex, transaction, command);
                if (transaction != null)
                {
                    transaction.MppaErrorMessage = ex.Message;
                    await mediator.Send(new UpdateTransactionCommand
                    {
                        Transaction = transaction
                    });
                }
            }

            return await Task.FromResult(false);
        }
    }
}
