﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.MobileFinalizes;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.FinalizeResponses
{
    public class MppaFinalizeResponseCommand : IRequest<bool>
    {
        public FinalizeCommanderRequest FinalizeRequest { get; set; }
    }
}
