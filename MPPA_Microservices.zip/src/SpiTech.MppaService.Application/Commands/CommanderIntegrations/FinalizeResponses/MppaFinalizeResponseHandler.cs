﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents;
using SpiTech.MppaService.Application.Commands.UpdateTransaction;
using SpiTech.MppaService.Application.Processors;
using SpiTech.MppaService.Application.Queries.GetTransactionById;
using SpiTech.MppaService.Application.Queries.GetTransactionByUmtiMId;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Models.Commanders;
using SpiTech.MppaService.Domain.Models.Commanders.MobileFinalizes;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.FinalizeResponses
{
    public class MppaFinalizeResponseHandler : IRequestHandler<MppaFinalizeResponseCommand, bool>
    {
        private readonly ILogger<MppaFinalizeResponseHandler> logger;
        private readonly IMediator mediator;
        private readonly HostConfig hostConfig;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IMapper mapper;
        private readonly IMppaMessageProcessor mppaMessageProcessor;

        public MppaFinalizeResponseHandler(
                                    ILogger<MppaFinalizeResponseHandler> logger,
                                    IMediator mediator,
                                    HostConfig hostConfig,
                                    IEventDispatcher eventDispatcher,
                                    IMapper mapper,
                                    IMppaMessageProcessor mppaMessageProcessor)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.hostConfig = hostConfig;
            this.eventDispatcher = eventDispatcher;
            this.mapper = mapper;
            this.mppaMessageProcessor = mppaMessageProcessor;
        }

        public async Task<bool> Handle(MppaFinalizeResponseCommand command, CancellationToken cancellationToken)
        {
            ApplicationCore.Domain.Models.ResponseModel result = new();
            Domain.Entities.Transaction transaction = null;

            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);
                transaction = await mediator.Send(new GetTransactionByUmtiMIdQuery
                {
                    UMTI = command.FinalizeRequest.MobileTxnInfo.UMTI,
                    MerchantId = command.FinalizeRequest.MobileTxnInfo.MerchantId
                });

                if (transaction == null)
                {
                    throw new ValidationException(new ValidationFailure("UMTI", $"MppaFinalizeResponse-UMTI{command.FinalizeRequest.MobileTxnInfo.UMTI}-{command.FinalizeRequest.MobileTxnInfo.MerchantId} is invalid"));
                }

                FinalizeMppaResponse finalizeMppaResponse = CreateFinalizeResponse(command);

                string finalizeMppaResponseMsg = Serializer.Serialize<FinalizeMppaResponse>(finalizeMppaResponse);

                if (hostConfig.IsPayAtPumpTestingEnabled || hostConfig.IsPosTestingEnabled)
                {
                    result = new ApplicationCore.Domain.Models.ResponseModel { Success = true };
                }
                else
                {
                    result = await mppaMessageProcessor.Process(transaction.TransactionId,
                                                                finalizeMppaResponseMsg,
                                                                finalizeMppaResponse,
                                                                false,
                                                                EventBus.DomainEvents.Enums.RequestType.MobileFinalize,
                                                                finalizeMppaResponse.MobileTxnInfo,
                                                                true,
                                                                finalizeMppaResponse.MobileFinalizeResponse.Response);
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex, transaction, command);

                if (transaction != null)
                {
                    transaction.MppaErrorMessage = ex.Message;
                    await mediator.Send(new UpdateTransactionCommand
                    {
                        Transaction = transaction
                    });
                }
            }

            logger.TraceExitMethod(nameof(Handle));
            return await Task.FromResult(result.Success);
        }

        private FinalizeMppaResponse CreateFinalizeResponse(MppaFinalizeResponseCommand command)
        {
            return new FinalizeMppaResponse
            {
                MobileTxnInfo = new MobileTxnInfoResponse
                {
                    POSTransNumber = command.FinalizeRequest.MobileTxnInfo.POSTransNumber,
                    FuelingPositionId = command.FinalizeRequest.MobileTxnInfo.FuelingPositionId,
                    HostMPPAIdentifier = hostConfig.HostMPPAIdentifier,
                    MerchantId = command.FinalizeRequest.MobileTxnInfo.MerchantId,
                    SiteId = command.FinalizeRequest.MobileTxnInfo.SiteId,
                    UMTI = command.FinalizeRequest.MobileTxnInfo.UMTI,
                    TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                    SiteMPPAIdentifier = command.FinalizeRequest.MobileTxnInfo.SiteMPPAIdentifier,
                    WorkstationId = command.FinalizeRequest.MobileTxnInfo.WorkstationId,
                    SettlementPeriodId = command.FinalizeRequest.MobileTxnInfo.SettlementPeriodId,
                },
                MobileFinalizeResponse = new MobileResponse
                {
                    Response = new Response
                    {
                        MessageCode = Constants.SuccessMessageCode,
                        OverallResult = Constants.SuccessOverallResult,
                        ResponseCode = Constants.SuccessResponseCode
                    }
                }
            };
        }
    }
}
