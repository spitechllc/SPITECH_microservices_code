﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.MobileReceiptData;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.ReceiptDataResponses
{
    public class MppaReceiptDataResponseCommand : IRequest<bool>
    {
        public ReceiptDataCommanderRequest ReceiptDataRequest { get; set; }
    }
}
