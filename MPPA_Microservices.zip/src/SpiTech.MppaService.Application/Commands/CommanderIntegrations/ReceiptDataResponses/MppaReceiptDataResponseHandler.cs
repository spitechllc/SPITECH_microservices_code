﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents;
using SpiTech.MppaService.Application.Commands.UpdateTransaction;
using SpiTech.MppaService.Application.Processors;
using SpiTech.MppaService.Application.Queries.GetTransactionById;
using SpiTech.MppaService.Application.Queries.GetTransactionByUmtiMId;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Models.Commanders;
using SpiTech.MppaService.Domain.Models.Commanders.MobileFinalizes;
using SpiTech.MppaService.Domain.Models.Commanders.MobileReceiptData;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.ReceiptDataResponses
{
    public class MppaReceiptDataResponseHandler : IRequestHandler<MppaReceiptDataResponseCommand, bool>
    {
        private readonly ILogger<MppaReceiptDataResponseHandler> logger;
        private readonly IMediator mediator;
        private readonly HostConfig hostConfig;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IMapper mapper;
        private readonly IMppaMessageProcessor mppaMessageProcessor;

        public MppaReceiptDataResponseHandler(
                                    ILogger<MppaReceiptDataResponseHandler> logger,
                                    IMediator mediator,
                                    HostConfig hostConfig,
                                    IEventDispatcher eventDispatcher,
                                    IMapper mapper,
                                    IMppaMessageProcessor mppaMessageProcessor)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.hostConfig = hostConfig;
            this.eventDispatcher = eventDispatcher;
            this.mapper = mapper;
            this.mppaMessageProcessor = mppaMessageProcessor;
        }

        public async Task<bool> Handle(MppaReceiptDataResponseCommand command, CancellationToken cancellationToken)
        {
            Domain.Entities.Transaction transaction = null;

            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);

                transaction = await mediator.Send(new GetTransactionByUmtiMIdQuery 
                { 
                    UMTI = command.ReceiptDataRequest.MobileTxnInfo.UMTI,
                    MerchantId= command.ReceiptDataRequest.MobileTxnInfo.MerchantId,
                });

                if (transaction == null)
                {
                    throw new ValidationException(new ValidationFailure("UMTI", $"MppaReceiptDataResponse-UMTI-{command.ReceiptDataRequest.MobileTxnInfo.UMTI}-{command.ReceiptDataRequest.MobileTxnInfo.MerchantId} is invalid"));
                }

                ReceiptDataMppaResponse receiptDataMppaResponse = new()
                {
                    MobileTxnInfo = new Domain.Models.Commanders.MobileReceiptData.MobileTxnInfoResponse
                    {
                        POSTransNumber = command.ReceiptDataRequest.MobileTxnInfo.POSTransNumber,
                        FuelingPositionId = command.ReceiptDataRequest.MobileTxnInfo.FuelingPositionId,
                        WorkstationId = command.ReceiptDataRequest.MobileTxnInfo.WorkstationId,
                        MerchantId = command.ReceiptDataRequest.MobileTxnInfo.MerchantId,
                        SiteId = command.ReceiptDataRequest.MobileTxnInfo.SiteId,
                        UMTI = command.ReceiptDataRequest.MobileTxnInfo.UMTI,
                        HostMPPAIdentifier = hostConfig.HostMPPAIdentifier,
                        TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                        SiteMPPAIdentifier = command.ReceiptDataRequest.MobileTxnInfo.SiteMPPAIdentifier,
                    },
                    MobileReceiptDataResponse = new MobileResponse
                    {
                        Response = new Response
                        {
                            MessageCode = Constants.SuccessMessageCode,
                            OverallResult = Constants.SuccessOverallResult,
                            ResponseCode = Constants.SuccessResponseCode
                        }
                    }
                };

                string receiptDataMppaResponseMsg = Serializer.Serialize<ReceiptDataMppaResponse>(receiptDataMppaResponse);

                ApplicationCore.Domain.Models.ResponseModel result = null;

                if (hostConfig.IsPayAtPumpTestingEnabled || hostConfig.IsPosTestingEnabled)
                {
                    result = new ApplicationCore.Domain.Models.ResponseModel { Success = true };
                }
                else
                {
                    result = await mppaMessageProcessor.Process(transaction.TransactionId,
                                                                  receiptDataMppaResponseMsg,
                                                                  receiptDataMppaResponse,
                                                                  false,
                                                                  EventBus.DomainEvents.Enums.RequestType.MobileReceiptData,
                                                                  receiptDataMppaResponse.MobileTxnInfo,
                                                                  true,
                                                                  receiptDataMppaResponse.MobileReceiptDataResponse.Response);
                }
                
                logger.TraceExitMethod(nameof(Handle));

                return await Task.FromResult(result.Success);
            }
            catch (Exception ex)
            {
                logger.Error(ex, transaction, command);

                if (transaction != null)
                {
                    transaction.MppaErrorMessage = ex.Message;
                    await mediator.Send(new UpdateTransactionCommand
                    {
                        Transaction = transaction
                    });
                }
            }

            return await Task.FromResult(false);
        }
    }
}
