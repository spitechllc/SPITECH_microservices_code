﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.EventBus.DomainEvents.Models.Mppa;
using SpiTech.MppaService.Application.Commands.MobileIntegrations.FinalReceiptResponses;
using SpiTech.MppaService.Application.Commands.UpdateTransaction;
using SpiTech.MppaService.Application.Queries.GetSiteById;
using SpiTech.MppaService.Application.Queries.GetTransactionById;
using SpiTech.MppaService.Application.Queries.GetTransactionByUmtiMId;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Models.Commanders.MobileReceiptData;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.ReceiptDataRequests
{
    public class CommanderReceiptDataRequestHandler : IRequestHandler<CommanderReceiptDataRequestCommand, bool>
    {
        private readonly ILogger<CommanderReceiptDataRequestHandler> logger;
        private readonly IMediator mediator;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IMapper mapper;

        public CommanderReceiptDataRequestHandler(
                                    ILogger<CommanderReceiptDataRequestHandler> logger,
                                    IMediator mediator,
                                    IEventDispatcher eventDispatcher,
                                    IMapper mapper)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.eventDispatcher = eventDispatcher;
            this.mapper = mapper;
        }

        public async Task<bool> Handle(CommanderReceiptDataRequestCommand command, CancellationToken cancellationToken)
        {
            Domain.Entities.Transaction transaction = null;

            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);

                transaction = await mediator.Send(new GetTransactionByUmtiMIdQuery
                { 
                    UMTI = command.ReceiptDataRequest.MobileTxnInfo.UMTI,
                    MerchantId = command.ReceiptDataRequest.MobileTxnInfo.MerchantId
                });

                if (transaction == null)
                {
                    throw new ValidationException(new ValidationFailure("UMTI", $"CommanderReceiptDataRequest-UMTI-{command.ReceiptDataRequest.MobileTxnInfo.UMTI}-{command.ReceiptDataRequest.MobileTxnInfo.MerchantId} is invalid"));
                }

                string message = Serializer.Serialize<ReceiptDataCommanderRequest>(command.ReceiptDataRequest);

                //Send Receipt to Mobile

                await SendStatusToMobile(command, transaction);

                if (transaction.StatusId == (int)Status.Inprogress)
                {
                    transaction.StatusId = (int)Status.Success;
                }

                if (command.ReceiptDataRequest.MobileReceiptDataRequest?.ReceiptInfo?.ReceiptLines != null)
                {
                    transaction.ReceiptNo = command.ReceiptDataRequest.MobileReceiptDataRequest.ReceiptInfo.ReceiptLines.FirstOrDefault(t => Constants.InvoiceMarkers.Any(i => t.Contains(i)));
                }

                transaction.ReceiptDate = DateTime.UtcNow;

                await mediator.Send(new UpdateTransactionCommand
                {
                    Transaction = transaction
                });

                await DispatchEvent(command, message, transaction);

                await mediator.Send(new ReceiptDataResponses.MppaReceiptDataResponseCommand
                {
                    ReceiptDataRequest = command.ReceiptDataRequest
                });

                logger.TraceExitMethod(nameof(Handle));
                return await Task.FromResult(true);
            }
            catch (Exception ex)
            {
                logger.Error(ex, transaction, command);

                if (transaction != null)
                {
                    transaction.MppaErrorMessage = ex.Message;
                    await mediator.Send(new UpdateTransactionCommand
                    {
                        Transaction = transaction
                    });
                }
            }

            return await Task.FromResult(false);
        }

        private async Task SendStatusToMobile(CommanderReceiptDataRequestCommand command, Domain.Entities.Transaction transaction)
        {
            Domain.Entities.Site site = await mediator.Send(new GetSiteByIdQuery
            {
                SiteId = transaction.SiteId
            });

            await mediator.Send(new MobileFinalReceiptResponseCommand
            {
                ReceiptData = new EventBus.DomainEvents.Models.Mppa.Receipts.TransactionReceiptModel
                {
                    PaymentInfo = new PaymentInfo { },
                    ReceiptInfoLines = command.ReceiptDataRequest.MobileReceiptDataRequest.ReceiptInfo.ReceiptLines.ToList(),
                    SiteName = site?.SiteName,
                    SiteAddress = site?.SiteAddress,
                    Transaction = mapper.Map<Transaction>(transaction),
                    SaleItems = mapper.Map<SaleItem[]>(command.ReceiptDataRequest.MobileReceiptDataRequest?.ItemsPurchased?.SaleItems),
                }
            });
        }

        private async Task DispatchEvent(CommanderReceiptDataRequestCommand command, string receiptDataCommanderRequestMsg, Domain.Entities.Transaction transaction)
        {
            await eventDispatcher.Dispatch(new ReceiptDataRequestEvent
            {
                RequestTypeId = (int)RequestType.MobileReceiptData,
                Transaction = mapper.Map<Transaction>(transaction),
                ReceiptLines = command.ReceiptDataRequest.MobileReceiptDataRequest.ReceiptInfo.ReceiptLines
            });
        }
    }
}
