﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.MobileReceiptData;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.ReceiptDataRequests
{
    public class CommanderReceiptDataRequestCommand : IRequest<bool>
    {
        public ReceiptDataCommanderRequest ReceiptDataRequest { get; set; }
    }
}
