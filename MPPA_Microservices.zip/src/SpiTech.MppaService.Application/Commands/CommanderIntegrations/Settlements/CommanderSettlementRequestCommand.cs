﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.Settlements;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.Settlements
{
    public class CommanderSettlementRequestCommand : IRequest<SettlementMppaResponse>
    {
        public SettlementCommanderRequest SettlementRequest { get; set; }
    }
}
