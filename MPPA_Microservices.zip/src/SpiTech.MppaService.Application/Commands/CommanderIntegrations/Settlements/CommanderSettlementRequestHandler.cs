﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.MppaService.Application.Commands.SaveSettlementRequest;
using SpiTech.MppaService.Application.Commands.UpdateSettlementRequest;
using SpiTech.MppaService.Application.Processors;
using SpiTech.MppaService.Application.Queries.GetTransactionByFilter;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models.Commanders;
using SpiTech.MppaService.Domain.Models.Commanders.Settlements;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MobileTxnInfoResponse = SpiTech.MppaService.Domain.Models.Commanders.Settlements.MobileTxnInfoResponse;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.Settlements
{
    public class CommanderSettlementRequestHandler : IRequestHandler<CommanderSettlementRequestCommand, SettlementMppaResponse>
    {
        private readonly ILogger<CommanderSettlementRequestHandler> logger;
        private readonly IMediator mediator;
        private readonly HostConfig hostConfig;
        private readonly IMapper mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IMppaMessageProcessor mppaMessageProcessor;
        private readonly IStoreServiceClient storeapiclient;
        private readonly IUnitOfWork context;

        public CommanderSettlementRequestHandler(
                                    ILogger<CommanderSettlementRequestHandler> logger,
                                    IMediator mediator,
                                    HostConfig hostConfig,
                                    IMapper mapper,
                                    IEventDispatcher eventDispatcher,
                                    IMppaMessageProcessor mppaMessageProcessor,
                                    IStoreServiceClient storeapiclient,
                                    IUnitOfWork context)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.hostConfig = hostConfig;
            this.mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.mppaMessageProcessor = mppaMessageProcessor;
            this.storeapiclient = storeapiclient;
            this.context = context;
        }

        public async Task<SettlementMppaResponse> Handle(CommanderSettlementRequestCommand command, CancellationToken cancellationToken)
        {
            SettlementMppaResponse settlementResponse = null;
            SettlementRequest settlementRequest = null;
            Service.Clients.Stores.StoreInfoModel store = null;
            string siteid = command.SettlementRequest.MobileTxnInfo.SiteId;

            logger.Warn($"MPPA Settlement Requestst:{ command.SettlementRequest}");
            logger.Warn($"MPPA Settlement Requestst:" + command.SettlementRequest.MobileTxnInfo.UMTI
                                 + ": SiteMPPAIdentifier : " + command.SettlementRequest.MobileTxnInfo.SiteMPPAIdentifier
                                 + ": SiteId : " + command.SettlementRequest.MobileTxnInfo.SiteId
                                 + ": MerchantId : " + command.SettlementRequest.MobileTxnInfo.MerchantId
                                 + ": SiteId : " + command.SettlementRequest.MobileTxnInfo.SiteId
                                 + ": TimeDateStamp : " + command.SettlementRequest.MobileTxnInfo.TimeDateStamp
                                 + ": BusinessDate : " + command.SettlementRequest.MobileSettlementRequest.SettlementDetails.BusinessDate.ToUniversalTime()
                                 + ": TerminalTotalAmount : " + command.SettlementRequest.MobileSettlementRequest.SettlementDetails.TerminalTotal
                                 + ": SettlementPeriodId : " + command.SettlementRequest.MobileSettlementRequest.SettlementDetails.SettlementPeriodID
                                 + ": StoreId : " + store?.StoreId ?? 0
                                 + ": StoreName"+ store?.StoreName);
            try
            {
                store = await storeapiclient.GetStoreInfoAsync(null, siteid);
            }
            catch (Exception ex)
            {
                logger.Error(ex, command);
            }

            if (store == null)
            {
                Site storeDB = await context.Sites.Get(siteid);
                if (storeDB != null)
                {
                    store = new Service.Clients.Stores.StoreInfoModel
                    {
                        StoreId = storeDB.StoreId ?? 0,
                        StoreName = storeDB.StoreName
                    };
                }
            }

            try
            {
                settlementResponse = DefaultResponse(command);

                string message = Serializer.Serialize<SettlementCommanderRequest>(command.SettlementRequest);

                settlementRequest = new SettlementRequest
                {
                    UMTI = command.SettlementRequest.MobileTxnInfo.UMTI,
                    SiteMPPAIdentifier = command.SettlementRequest.MobileTxnInfo.SiteMPPAIdentifier,
                    SiteId = command.SettlementRequest.MobileTxnInfo.SiteId,
                    MerchantId = command.SettlementRequest.MobileTxnInfo.MerchantId,
                    TimeDateStamp = DateTime.Parse(command.SettlementRequest.MobileTxnInfo.TimeDateStamp).ToUniversalTime(),
                    BusinessDate = command.SettlementRequest.MobileSettlementRequest.SettlementDetails.BusinessDate.ToUniversalTime(),
                    TerminalTotalAmount = command.SettlementRequest.MobileSettlementRequest.SettlementDetails.TerminalTotal,
                    SettlementPeriodId = command.SettlementRequest.MobileSettlementRequest.SettlementDetails.SettlementPeriodID,
                    SoftwareVersion = command.SettlementRequest.MobileSettlementRequest.SettlementDetails.SoftwareVersion,
                    StoreId = store?.StoreId ?? 0,
                    StoreName = store?.StoreName,
                };

                IEnumerable<Transaction> reconcileTransactionRecords = await ReconcileTransactions(
                                                            settlementRequest, command.SettlementRequest.MobileSettlementRequest);

                AddSettlementDetails(command, settlementRequest, reconcileTransactionRecords);

                bool result = await mediator.Send(new SaveSettlementRequestCommand
                {
                    SettlementRequest = settlementRequest
                });

                logger.Warn($"MPPA Settlement Requests Ram 2");
                if (result)
                {
                    settlementResponse.MobileSettlementResponse.Response.MessageCode = Constants.SuccessMessageCode;
                    settlementResponse.MobileSettlementResponse.Response.OverallResult = Constants.SuccessOverallResult;
                    settlementResponse.MobileSettlementResponse.Response.ResponseCode = Constants.SuccessResponseCode;

                    ResponseModel response = await SendResponseToCommander(settlementResponse, settlementRequest);
                    settlementRequest.Error = response.Message;
                    settlementRequest.IsResponseError = !response.Success;
                    settlementRequest.IsReconciled = response.Success;

                    if (settlementRequest.IsReconciled)
                    {
                        try
                        {
                            result = await mediator.Send(new UpdateSettlementRequestCommand
                            {
                                SettlementRequest = settlementRequest
                            });
                        }
                        catch (Exception ex)
                        {
                            settlementRequest.Error = ex.Message;
                            logger.Error(ex, settlementRequest);
                        }
                        logger.Warn($"MPPA Settlement Requests Ram 3");

                        await eventDispatcher.Dispatch(new TransactionSettlementEvent
                        {
                            SettlementRequest = mapper.Map<EventBus.DomainEvents.Models.Mppa.SettlementRequest>(settlementRequest),
                            TransactionIds = reconcileTransactionRecords.Select(r => r.TransactionId).ToArray()
                        });
                    }
                }
                else
                {
                    await SendResponseToCommander(settlementResponse, settlementRequest);
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex, settlementResponse, settlementRequest, command);
                await SendResponseToCommander(settlementResponse, settlementRequest);
            }

            return await Task.FromResult(settlementResponse);
        }

        private SettlementMppaResponse DefaultResponse(CommanderSettlementRequestCommand command)
        {
            SettlementMppaResponse settlementResponse = new()
            {
                MobileTxnInfo = new MobileTxnInfoResponse
                {
                    MerchantId = command.SettlementRequest.MobileTxnInfo.MerchantId,
                    SiteId = command.SettlementRequest.MobileTxnInfo.SiteId,
                    UMTI = command.SettlementRequest.MobileTxnInfo.UMTI,
                    SiteMPPAIdentifier = command.SettlementRequest.MobileTxnInfo.SiteMPPAIdentifier,
                    HostMPPAIdentifier = hostConfig.HostMPPAIdentifier,
                    TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK")
                },
                MobileSettlementResponse = new MobileResponse
                {
                    Response = new Response
                    {
                        MessageCode = Constants.FailMessageCode,
                        OverallResult = Constants.FailOverallResult,
                        ResponseCode = Constants.SettlementFailResponseCode
                    }
                }
            };
            return settlementResponse;
        }

        private async Task<IEnumerable<Transaction>> ReconcileTransactions(SettlementRequest settlementRequest, MobileSettlementRequest mobileSettlementRequest)
        {
            IEnumerable<Transaction> reconcileTransactionRecords = await mediator.Send(new GetTransactionByFilterQuery
            {
                SiteId = settlementRequest.SiteId,
                SettlementPeriodId = settlementRequest.SettlementPeriodId
            });

            settlementRequest.MppaTotalAmount = reconcileTransactionRecords.Sum(t => t.FinalAmount);
            settlementRequest.MppaCounts = reconcileTransactionRecords.Count();
            settlementRequest.AchAmount = reconcileTransactionRecords.Where(t => t.PaymentMethodId == (int)EnumPaymentMethod.ACH)
                                                                     .Sum(t => t.CardAmount);
            settlementRequest.CardAmount = reconcileTransactionRecords.Where(t => t.PaymentMethodId == (int)EnumPaymentMethod.CreditCard)
                                                                    .Sum(t => t.CardAmount);
            settlementRequest.CashRewardAmount = reconcileTransactionRecords.Sum(t => t.WalletAmount);
            settlementRequest.EodAchAmount = reconcileTransactionRecords.Where(t => t.PaymentMethodId == (int)EnumPaymentMethod.ACH && !t.DisableEod).Sum(t => t.CardAmount);
            settlementRequest.EodCardAmount = reconcileTransactionRecords.Where(t => t.PaymentMethodId == (int)EnumPaymentMethod.CreditCard && !t.DisableEod).Sum(t => t.CardAmount);
            settlementRequest.EodCashRewardAmount = reconcileTransactionRecords.Where(t => !t.DisableEod).Sum(t => t.WalletAmount);

            if (mobileSettlementRequest?.SettlementDetails?.TotalsInfo?.TotalAmount != null)
            {
                settlementRequest.TerminalCounts = mobileSettlementRequest.SettlementDetails.TotalsInfo.TotalAmount.Sum(t => t.Count);
            }

            settlementRequest.IsTotalAmountMatched = settlementRequest.MppaTotalAmount == settlementRequest.TerminalTotalAmount;
            settlementRequest.IsCountsMatched = settlementRequest.MppaCounts == settlementRequest.TerminalCounts;
            return reconcileTransactionRecords;
        }

        private static void AddSettlementDetails(CommanderSettlementRequestCommand command, SettlementRequest settlementRequest, IEnumerable<Transaction> reconcileTransactionRecords)
        {
            if (command.SettlementRequest.MobileSettlementRequest.SettlementDetails.TotalsInfo?.TotalAmount != null)
            {
                foreach (TotalAmount totalAmount in command.SettlementRequest.MobileSettlementRequest.SettlementDetails.TotalsInfo.TotalAmount)
                {
                    SettlementDetail detail = new()
                    {
                        TerminalCounts = totalAmount.Count,
                        TerminalTotalAmount = totalAmount.Amount,
                        TypeName = totalAmount.Type,
                        GroupName = totalAmount.Group,
                        MppaTotalAmount = reconcileTransactionRecords.Where(t => string.Equals(t.CardType, totalAmount.Type, StringComparison.InvariantCultureIgnoreCase)).Sum(t => t.FinalAmount),
                        MppaCounts = reconcileTransactionRecords.Where(t => string.Equals(t.CardType, totalAmount.Type, StringComparison.InvariantCultureIgnoreCase)).Count(),
                    };

                    detail.IsTotalAmountMatched = detail.MppaTotalAmount == detail.TerminalTotalAmount;
                    detail.IsCountsMatched = detail.MppaCounts == detail.TerminalCounts;

                    settlementRequest.SettlementDetails.Add(detail);
                }
            }
        }

        private async Task<ResponseModel> SendResponseToCommander(SettlementMppaResponse settlementResponse, SettlementRequest settlementRequest)
        {
            string responseMessage = Serializer.Serialize<SettlementMppaResponse>(settlementResponse);

            ResponseModel result = await mppaMessageProcessor.Process(null,
                                                             responseMessage,
                                                             settlementResponse,
                                                             false,
                                                             EventBus.DomainEvents.Enums.RequestType.MobileSettlement,
                                                             settlementResponse.MobileTxnInfo,
                                                             true,
                                                             settlementResponse.MobileSettlementResponse.Response);

            settlementRequest.Error = result?.Message;
            settlementRequest.IsResponseError = !result?.Success ?? false;

            return result;
        }
    }
}
