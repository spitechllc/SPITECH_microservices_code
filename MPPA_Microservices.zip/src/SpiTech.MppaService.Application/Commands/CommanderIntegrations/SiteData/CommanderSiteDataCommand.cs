﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.MobileSiteData;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.SiteData
{
    public class CommanderSiteDataCommand : IRequest<SiteDataMppaResponse>
    {
        public SiteDataCommanderRequest SiteDataRequest { get; set; }
    }
}
