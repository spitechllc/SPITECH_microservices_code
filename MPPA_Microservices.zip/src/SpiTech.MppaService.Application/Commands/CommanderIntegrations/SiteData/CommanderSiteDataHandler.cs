﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.MppaService.Application.Commands.UpdateGetSite;
using SpiTech.MppaService.Application.Processors;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models.Commanders;
using SpiTech.MppaService.Domain.Models.Commanders.MobileSiteData;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.SiteData
{
    public class CommanderSiteDataHandler : IRequestHandler<CommanderSiteDataCommand, SiteDataMppaResponse>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<CommanderSiteDataHandler> logger;
        private readonly IMediator mediator;
        private readonly HostConfig hostConfig;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IMppaMessageProcessor mppaMessageProcessor;
        private readonly IStoreServiceClient storeApiClient;

        public CommanderSiteDataHandler(IUnitOfWork context,
                                    ILogger<CommanderSiteDataHandler> logger,
                                    IMediator mediator,
                                    HostConfig hostConfig,
                                    IEventDispatcher eventDispatcher,
                                    IMppaMessageProcessor mppaMessageProcessor,
                                    IStoreServiceClient storeApiClient)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            this.hostConfig = hostConfig;
            this.eventDispatcher = eventDispatcher;
            this.mppaMessageProcessor = mppaMessageProcessor;
            this.storeApiClient = storeApiClient;
        }

        public async Task<SiteDataMppaResponse> Handle(CommanderSiteDataCommand command, CancellationToken cancellationToken)
        {
            SiteDataMppaResponse siteDataMppaResponse = null;
            try
            {
                logger.Warn($"MPPA CommanderSiteDataHandler Start");
                logger.TraceEnterMethod(nameof(Handle), command);

                await SaveSite(command);
                await SaveSiteProducts(command);

                logger.Warn($"MPPA CommanderSiteDataHandler Start 1");
                siteDataMppaResponse = new SiteDataMppaResponse
                {
                    MobileTxnInfo = new MobileTxnInfoResponse
                    {
                        MerchantId = command.SiteDataRequest.MobileTxnInfo.MerchantId,
                        SiteId = command.SiteDataRequest.MobileTxnInfo.SiteId,
                        UMTI = command.SiteDataRequest.MobileTxnInfo.UMTI,
                        SiteMPPAIdentifier = command.SiteDataRequest.MobileTxnInfo.SiteMPPAIdentifier,
                        HostMPPAIdentifier = hostConfig.HostMPPAIdentifier,
                        TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK")
                    },
                    MobileSiteDataResponse = new MobileResponse
                    {
                        Response = new Response
                        {
                            MessageCode = Constants.SuccessMessageCode,
                            OverallResult = Constants.SuccessOverallResult,
                            ResponseCode = Constants.SuccessResponseCode
                        }
                    }
                };

                string responseMsg = Serializer.Serialize<SiteDataMppaResponse>(siteDataMppaResponse);

                logger.Warn($"MPPA CommanderSiteDataHandler Start 2 siteDataMppaResponse : {responseMsg}");

                ApplicationCore.Domain.Models.ResponseModel result = await mppaMessageProcessor.Process(null,
                                                               responseMsg,
                                                               siteDataMppaResponse,
                                                               false,
                                                                                                            EventBus.DomainEvents.Enums.RequestType.MobileSiteData,
                                                               siteDataMppaResponse.MobileTxnInfo,
                                                               true,
                                                                                                                    siteDataMppaResponse.MobileSiteDataResponse.Response);


                logger.TraceExitMethod(nameof(Handle), siteDataMppaResponse);
                logger.Warn($"MPPA CommanderSiteDataHandler Exit");
            }
            catch (Exception ex)
            {
                logger.Warn($"MPPA CommanderSiteDataHandler error : {ex.Message} ");
                logger.Error(ex, siteDataMppaResponse, command);
            }

            return await Task.FromResult(siteDataMppaResponse);
        }

        private async Task SaveSiteProducts(CommanderSiteDataCommand command)
        {
            if (command.SiteDataRequest?.MobileSiteDataRequest?.FuelConfigDetails?.PumpProducts != null)
            {
                try
                {
                    bool dbSiteProducts = await context.SiteProducts.DeleteSiteProducts(command.SiteDataRequest.MobileTxnInfo.SiteId);

                    foreach (PumpProducts pumpProduct in command.SiteDataRequest?.MobileSiteDataRequest?.FuelConfigDetails?.PumpProducts)
                    {
                        await context.SiteProducts.Add(new SiteProduct
                        {
                            SiteId = command.SiteDataRequest.MobileTxnInfo.SiteId,
                            AdjustedAmount = pumpProduct.AdjustedAmount?.Amount,
                            AdjustedAmountUnitPrice = pumpProduct.AdjustedAmount?.UnitPrice,
                            Description = pumpProduct.Description,
                            OriginalAmount = pumpProduct.OriginalAmount?.Amount,
                            OriginalAmountUnitPrice = pumpProduct.OriginalAmount?.UnitPrice,
                            OutdoorPosition = pumpProduct.OutdoorPosition,
                            POSCode = pumpProduct.POSCode,
                            POSCodeModifier = pumpProduct.POSCodeModifier,
                            PriceTier = pumpProduct.PriceTier,
                            ProductCode = pumpProduct.ProductCode,
                            Quantity = pumpProduct.Quantity,
                            ItemId = pumpProduct.ItemId,
                            UnitMeasure = pumpProduct.UnitMeasure,
                        });
                    }

                    context.Commit();
                }
                catch (Exception ex)
                {
                    logger.Error(ex);
                    context.Rollback();
                }
            }
        }

        public async Task<bool> SaveSite(CommanderSiteDataCommand command)
        {
            logger.TraceEnterMethod(nameof(Handle), command);
            try
            {
                Site site = await mediator.Send(new UpdateGetSiteCommand { SiteId = command.SiteDataRequest.MobileTxnInfo.SiteId });

                if (site == null)
                {
                    site = new Site
                    {
                        SiteId = command.SiteDataRequest.MobileTxnInfo.SiteId,
                        SiteName = command.SiteDataRequest.MobileSiteDataRequest.SiteDetails.SiteName,
                        SiteMPPAIdentifier = command.SiteDataRequest.MobileTxnInfo.SiteMPPAIdentifier,
                        MerchantId = command.SiteDataRequest.MobileTxnInfo.MerchantId,
                        LocationId = command.SiteDataRequest.MobileSiteDataRequest?.SiteDetails?.LocationId,
                        SiteMobileActive = command.SiteDataRequest.MobileSiteDataRequest?.SiteDetails?.SiteMobileActive,
                        SiteAddress = command.SiteDataRequest.MobileSiteDataRequest?.SiteDetails?.SiteAddress,
                        WelcomeMsg = command.SiteDataRequest.MobileSiteDataRequest?.SiteDetails?.WelcomeMsg,
                        SettlementEmployee = command.SiteDataRequest.MobileSiteDataRequest?.SiteDetails?.SettlementEmployee,
                        PartialAuthAllowed = command.SiteDataRequest.MobileSiteDataRequest?.SiteDetails?.PartialAuthAllowed,
                        PumpTimeout = command.SiteDataRequest.MobileSiteDataRequest?.FuelConfigDetails?.PumpTimeout,
                        IsActive = true
                    };

                    await VerifyAndAssignStoreId(site);

                    await context.Execute(async () =>
                    {
                        await context.Sites.Add(site);
                    });
                }
                else
                {
                    site.SiteName = command.SiteDataRequest.MobileSiteDataRequest.SiteDetails.SiteName;
                    site.SiteMPPAIdentifier = command.SiteDataRequest.MobileTxnInfo.SiteMPPAIdentifier;
                    site.MerchantId = command.SiteDataRequest.MobileTxnInfo.MerchantId;
                    site.LocationId = command.SiteDataRequest.MobileSiteDataRequest?.SiteDetails?.LocationId;
                    site.SiteMobileActive = command.SiteDataRequest.MobileSiteDataRequest?.SiteDetails?.SiteMobileActive;
                    site.SiteAddress = command.SiteDataRequest.MobileSiteDataRequest?.SiteDetails?.SiteAddress;
                    site.WelcomeMsg = command.SiteDataRequest.MobileSiteDataRequest?.SiteDetails?.WelcomeMsg;
                    site.SettlementEmployee = command.SiteDataRequest.MobileSiteDataRequest?.SiteDetails?.SettlementEmployee;
                    site.PartialAuthAllowed = command.SiteDataRequest.MobileSiteDataRequest?.SiteDetails?.PartialAuthAllowed;
                    site.PumpTimeout = command.SiteDataRequest.MobileSiteDataRequest?.FuelConfigDetails?.PumpTimeout;

                    await VerifyAndAssignStoreId(site);

                    await context.Execute(async () =>
                    {
                        await context.Sites.Update(site);
                    });
                }

                await eventDispatcher.Dispatch(new SiteEvent
                {
                    SiteId = site.SiteId,
                    SiteName = site.SiteName,
                    SiteMPPAIdentifier = site.SiteMPPAIdentifier,
                    MerchantId = site.MerchantId,
                    LocationId = site.LocationId,
                    SiteMobileActive = site.SiteMobileActive,
                    SiteAddress = site.SiteAddress,
                    SettlementEmployee = site.SettlementEmployee,
                    PartialAuthAllowed = site.PartialAuthAllowed,
                    PumpTimeout = site.PumpTimeout,
                    StoreId = site.StoreId,
                    StoreName = site.StoreName,
                });
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return false;
            }

            logger.TraceExitMethod(nameof(Handle), true);
            return true;
        }

        private async Task VerifyAndAssignStoreId(Site site)
        {
            if (!site.StoreId.HasValue || site.StoreId == 0 || string.IsNullOrEmpty(site.StoreName))
            {
                try
                {
                    var storeResult = await storeApiClient.GetStoreInfoAsync(null, site.SiteId).ConfigureAwait(false);
                    site.StoreId = storeResult.StoreId;
                    site.StoreName = storeResult.StoreName;
                }
                catch (Exception ex)
                {
                    logger.Error(ex);
                }
            }
        }
    }
}
