﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.MppaService.Application.Commands.CreateTransaction;
using SpiTech.MppaService.Application.Commands.MobileIntegrations.PumpReserveResponses;
using SpiTech.MppaService.Application.Commands.UpdateGetSite;
using SpiTech.MppaService.Application.Commands.UpdateTransaction;
using SpiTech.MppaService.Application.Processors;
using SpiTech.MppaService.Application.Queries.GetUserInprogressTransaction;
using SpiTech.MppaService.Application.Services;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models.Commanders.MobilePumpReserves;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.PumpReserveRequests
{
    public class MppaPumpReserveRequestHandler : INotificationHandler<MppaPumpReserveRequestCommand>
    {
        private readonly ILogger<MppaPumpReserveRequestHandler> logger;
        private readonly IMediator mediator;
        private readonly HostConfig hostConfig;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IMapper mapper;
        private readonly IMppaMessageProcessor mppaMessageProcessor;
        private readonly IStoreServiceClient storeApiClient;
        private readonly IPayAtPumpFakeTestService payAtPumpFakeTestService;

        public MppaPumpReserveRequestHandler(
                                    ILogger<MppaPumpReserveRequestHandler> logger,
                                    IMediator mediator,
                                    HostConfig hostConfig,
                                    IEventDispatcher eventDispatcher,
                                    IMapper mapper,
                                    IMppaMessageProcessor mppaMessageProcessor,
                                    IStoreServiceClient storeApiClient,
                                    IPayAtPumpFakeTestService payAtPumpFakeTestService)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.hostConfig = hostConfig;
            this.eventDispatcher = eventDispatcher;
            this.mapper = mapper;
            this.mppaMessageProcessor = mppaMessageProcessor;
            this.storeApiClient = storeApiClient;
            this.payAtPumpFakeTestService = payAtPumpFakeTestService;
        }

        public async Task Handle(MppaPumpReserveRequestCommand command, CancellationToken cancellationToken)
        {
            PumpReserveMppaRequest request = null;

            string status = ProcessConstants.ReserveInprogress;
            Domain.Entities.Transaction transaction = null;

            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);
                Domain.Entities.Site siteData = null;
                Service.Clients.Stores.StoreInfoModel storeInfoModel = null;

                //var inProgressTransaction = await mediator.Send(new GetUserInprogressTransactionQuery
                //{
                //    UserId = command.UserId,
                //    TimeOutInSec = hostConfig.TransactionTimeoutInSec,
                //    TransactionType = TransactionType.FuelReserve
                //});

                //if (inProgressTransaction == null)
                //{
                siteData = await mediator.Send(new UpdateGetSiteCommand { SiteId = command.Request.SiteId });

                if (!string.IsNullOrWhiteSpace(command.Request?.SiteId))
                {
                    storeInfoModel = await storeApiClient.GetStoreInfoAsync(null, command.Request.SiteId).ConfigureAwait(false);
                }
                //}

                string utmi = UmtiGenerator.Generate(hostConfig.UtmiPrefix);

                request = new PumpReserveMppaRequest
                {
                    MobileTxnInfo = new MobileTxnInfoRequest
                    {
                        FuelingPositionId = command.Request.FuelingPositionId,
                        SiteId = command.Request.SiteId,
                        TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                        HostMPPAIdentifier = hostConfig.HostMPPAIdentifier,
                        MerchantId = siteData?.MerchantId,
                        UMTI = utmi
                    },
                    MobilePumpReserveRequest = new MobilePumpReserveRequest()
                };

                transaction = new Domain.Entities.Transaction
                {
                    SiteId = siteData == null ? null : request.MobileTxnInfo.SiteId,
                    StoreId = siteData?.StoreId,
                    StoreName = siteData?.StoreName,
                    FuelingPositionId = request.MobileTxnInfo.FuelingPositionId,
                    MerchantId = request.MobileTxnInfo.MerchantId,
                    HostMPPAIdentifier = request.MobileTxnInfo.HostMPPAIdentifier,
                    StatusId = (int)Status.Inprogress,
                    UserId = command.UserId,
                    DeviceToken = command.Request.DeviceToken,
                    AppType = command.Request.DeviceType.ToString(),
                    PreauthAmount = command.Request.CardAmount + command.Request.WalletAmount,
                    PreauthCardAmount = command.Request.CardAmount,
                    PreauthWalletAmount = command.Request.WalletAmount,
                    TransactionTypeId = (int)TransactionType.FuelReserve,
                    TransactionDate = DateTime.UtcNow,
                    PumpReserveDate = DateTime.UtcNow,
                    TransactionInfo = "Fuel",
                    UserPaymentMethodId = command.Request.UserPaymentMethodId,
                    UMTI = utmi,
                    DisableBilling = storeInfoModel?.DisableBilling ?? false,
                    DisableEod = storeInfoModel?.DisableEod ?? false,
                };

                //if (inProgressTransaction != null)
                //{
                //    transaction.StatusId = (int)Status.Fail;
                //    transaction.MppaErrorMessage = $"You have one transaction in-progress, Please try after {Math.Ceiling(hostConfig.TransactionTimeoutInSec - (DateTime.UtcNow - inProgressTransaction.TransactionDate).TotalSeconds)} seconds";
                //}
                //else 

                if (siteData == null)
                {
                    transaction.StatusId = (int)Status.Fail;
                    transaction.MppaErrorMessage = $"Site({request.MobileTxnInfo.SiteId}) information not found";
                }

                transaction.TransactionId = await mediator.Send(new CreateTransactionCommand
                {
                    Transaction = transaction
                });

                if (transaction.StatusId == (int)Status.Fail)
                {
                    await SendStatusToMobile(command, request, true, transaction.MppaErrorMessage, ProcessConstants.ReserveError, transaction?.TransactionId ?? 0);
                    await Task.CompletedTask;

                    return;
                }

                await SendStatusToMobile(command, request, false, "", status, transaction.TransactionId);

                string requestMsg = Serializer.Serialize<PumpReserveMppaRequest>(request);

                ApplicationCore.Domain.Models.ResponseModel result = null;

                //For Testing PayAtPump Begin
                if (hostConfig.IsPayAtPumpTestingEnabled)
                {
                    result = new ApplicationCore.Domain.Models.ResponseModel { Message = "", Success = true };
                }
                else
                {
                    result = await mppaMessageProcessor.Process(transaction.TransactionId,
                                                                 requestMsg,
                                                                 request,
                                                                 true,
                                                                 EventBus.DomainEvents.Enums.RequestType.MobilePumpReserve,
                                                                 request.MobileTxnInfo,
                                                                 true,
                                                                 null);
                }
                //For Testing PayAtPump END

                if (!result.Success)
                {
                    status = ProcessConstants.ReserveError;
                    transaction.StatusId = (int)Status.Fail;
                    transaction.MppaErrorMessage = result.Message;

                    await mediator.Send(new UpdateTransactionCommand
                    {
                        Transaction = transaction
                    });
                }

                await eventDispatcher.Dispatch(new PumpReserveRequestEvent
                {
                    RequestTypeId = (int)EventBus.DomainEvents.Enums.RequestType.MobilePumpReserve,
                    Transaction = mapper.Map<EventBus.DomainEvents.Models.Mppa.Transaction>(transaction),
                });

                if (!result.Success)
                {
                    await SendStatusToMobile(command, request, !result.Success, result.Message, status, transaction.TransactionId);
                }

                //For Testing PayAtPump Begin
                if (hostConfig.IsPayAtPumpTestingEnabled)
                {
                    await payAtPumpFakeTestService.GenerateFakeCommanderPumpReserveResponse(transaction);
                }
                //For Testing PayAtPump END

                logger.TraceExitMethod(nameof(Handle));
            }
            catch (Exception ex)
            {
                logger.Error(ex, transaction, command);
                status = ProcessConstants.ReserveError;

                if (transaction != null)
                {
                    transaction.StatusId = (int)Status.Fail;
                    transaction.MppaErrorMessage = ex.Message;
                    await mediator.Send(new UpdateTransactionCommand
                    {
                        Transaction = transaction
                    });
                }

                await SendStatusToMobile(command, request, true, ex.Message, ProcessConstants.ReserveError, transaction?.TransactionId ?? 0);
            }

            await Task.CompletedTask;
        }

        private async Task SendStatusToMobile(MppaPumpReserveRequestCommand command,
            PumpReserveMppaRequest request,
            bool isError,
            string error,
            string status,
            long transactionId)
        {
            try
            {
                await mediator.Send(new MobilePumpReserveResponseCommand
                {
                    TransactionId = transactionId,
                    FuelingPositionId = command.Request.FuelingPositionId,
                    SiteId = command.Request.SiteId,
                    UMTI = request?.MobileTxnInfo?.UMTI,
                    UserId = command.UserId,
                    Success = !isError,
                    Status = status,
                    Erorr = error
                });
            }
            catch (Exception ex)
            {
                logger.Error(ex, request);
            }
        }
    }
}
