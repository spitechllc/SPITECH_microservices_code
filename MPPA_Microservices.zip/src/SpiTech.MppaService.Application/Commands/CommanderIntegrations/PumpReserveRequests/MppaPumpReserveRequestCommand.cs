﻿using SpiTech.MppaService.Domain.Interfaces;
using SpiTech.MppaService.Domain.Models.Mobile;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.PumpReserveRequests
{
    public class MppaPumpReserveRequestCommand : IMobileRequest
    {
        public int UserId { get; set; }
        public ReserveRequest Request { get; set; }
    }
}
