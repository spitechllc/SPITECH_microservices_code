﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.BeginFuelingResponses;
using SpiTech.MppaService.Application.Commands.MobileIntegrations.PumpBeginFualResponses;
using SpiTech.MppaService.Application.Commands.UpdateTransaction;
using SpiTech.MppaService.Application.Queries.GetTransactionById;
using SpiTech.MppaService.Application.Queries.GetTransactionByUmtiMId;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.BeginFuelingRequests
{
    public class CommanderBeginFuelingRequestHandler : IRequestHandler<CommanderBeginFuelingRequestCommand, bool>
    {
        private readonly ILogger<CommanderBeginFuelingRequestHandler> logger;
        private readonly IMediator mediator;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IMapper mapper;

        public CommanderBeginFuelingRequestHandler(
                                    ILogger<CommanderBeginFuelingRequestHandler> logger,
                                    IMediator mediator,
                                    IEventDispatcher eventDispatcher,
                                    IMapper mapper)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.eventDispatcher = eventDispatcher;
            this.mapper = mapper;
        }

        public async Task<bool> Handle(CommanderBeginFuelingRequestCommand command, CancellationToken cancellationToken)
        {
            Domain.Entities.Transaction transaction = null;

            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);

                transaction = await mediator.Send(new GetTransactionByUmtiMIdQuery { 
                    UMTI = command.BeginFuelingRequest.MobileTxnInfo.UMTI,
                    MerchantId = command.BeginFuelingRequest.MobileTxnInfo.MerchantId,
                });

                if (transaction == null)
                {
                    throw new ValidationException(new ValidationFailure("UMTI", $"CommanderBeginFuelingRequest-UMTI-{command.BeginFuelingRequest.MobileTxnInfo.UMTI}-{command.BeginFuelingRequest.MobileTxnInfo.MerchantId} is invalid"));
                }

                //Send PumpBeginFualResponse to Mobile
                await mediator.Send(new MobilePumpBeginFualResponseCommand
                {
                    TransactionId = transaction.TransactionId,
                    SiteId = transaction.SiteId,
                    UMTI = command.BeginFuelingRequest.MobileTxnInfo.UMTI,
                    BeginFuel = true,
                    BeginFuelMessage = command.BeginFuelingRequest.MobileBeginFuelingRequest.BeginFuelMessage,
                    UserId = transaction.UserId
                });

                transaction.BeginFuelingDate = DateTime.UtcNow;

                await mediator.Send(new UpdateTransactionCommand
                {
                    Transaction = transaction
                });

                await mediator.Send(new MppaBeginFuelingResponseCommand
                {
                    BeginFuelingCommanderRequest = command.BeginFuelingRequest
                });

                logger.TraceExitMethod(nameof(Handle));
                return await Task.FromResult(true);
            }
            catch (Exception ex)
            {
                logger.Error(ex, transaction, command);
                if (transaction != null)
                {
                    transaction.MppaErrorMessage = ex.Message;
                    await mediator.Send(new UpdateTransactionCommand
                    {
                        Transaction = transaction
                    });
                }
            }

            return await Task.FromResult(false);
        }
    }
}
