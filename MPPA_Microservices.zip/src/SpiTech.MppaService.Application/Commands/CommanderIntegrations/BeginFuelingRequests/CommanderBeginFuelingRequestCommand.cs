﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.BeginFueling;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.BeginFuelingRequests
{
    public class CommanderBeginFuelingRequestCommand : IRequest<bool>
    {
        public BeginFuelingCommanderRequest BeginFuelingRequest { get; set; }
    }
}
