﻿using SpiTech.MppaService.Domain.Interfaces;
using SpiTech.MppaService.Domain.Models.Mobile;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.AuthRequestsPos
{
    public class MppaAuthRequestCommand : IMobileRequest
    {
        public int UserId { get; set; }
        public PosTransactionAuthorize Request { get; set; }
    }
}
