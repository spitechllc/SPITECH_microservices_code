﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Extensions;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.MppaService.Application.Commands.UpdateTransaction;
using SpiTech.MppaService.Application.Processors;
using SpiTech.MppaService.Application.Queries.GetSaleItemByFilter;
using SpiTech.MppaService.Application.Queries.GetTransactionById;
using SpiTech.MppaService.Application.Services;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Models.Commanders;
using SpiTech.MppaService.Domain.Models.Commanders.MobileAuths;
using SpiTech.Service.Clients.Identity;
using SpiTech.Service.Clients.Payments;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.AuthRequestsPos
{
    public class MppaAuthRequestHandler : INotificationHandler<MppaAuthRequestCommand>
    {
        private readonly ILogger<MppaAuthRequestHandler> logger;
        private readonly IMediator mediator;
        private readonly HostConfig hostConfig;
        private readonly IPaymentServiceClient paymentApiClient;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IMapper mapper;
        private readonly IMppaMessageProcessor mppaMessageProcessor;
        private readonly IIdentityServiceClient identityServiceClient;
        private readonly IStoreServiceClient storeApiClient;
        private readonly IPosFakeTestService posFakeTestService;

        public MppaAuthRequestHandler(
                                    ILogger<MppaAuthRequestHandler> logger,
                                    IMediator mediator,
                                    HostConfig hostConfig,
                                    IPaymentServiceClient paymentApiClient,
                                    IEventDispatcher eventDispatcher,
                                    IMapper mapper,
                                    IMppaMessageProcessor mppaMessageProcessor,
                                    IIdentityServiceClient identityServiceClient,
                                    IStoreServiceClient storeApiClient,
                                    IPosFakeTestService posFakeTestService)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.hostConfig = hostConfig;
            this.paymentApiClient = paymentApiClient;
            this.eventDispatcher = eventDispatcher;
            this.mapper = mapper;
            this.mppaMessageProcessor = mppaMessageProcessor;
            this.identityServiceClient = identityServiceClient;
            this.storeApiClient = storeApiClient;
            this.posFakeTestService = posFakeTestService;
        }

        public async Task Handle(MppaAuthRequestCommand command, CancellationToken cancellationToken)
        {
            AuthMppaRequest authMppaRequest = null;
            Domain.Entities.Transaction transaction = null;
            var isPreauthSuccess = false;

            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);

                transaction = await mediator.Send(new GetTransactionByIdQuery { 
                    TransactionId = long.Parse(command.Request.UMTI)
                });

                if (transaction == null)
                {
                    throw new ValidationException(new ValidationFailure("UMTI", $"MppaAuthRequest-POS-TransactionId-{command.Request.UMTI} is invalid"));
                }

                var user = await identityServiceClient.GetUserByIdAsync(transaction.UserId, cancellationToken);

                PreAuthPaymentResponseModelResponseModel preAuthPaymentResponseModel = null;

                if (command.Request.IsAuthorize && command.Request.UserPaymentMethodId > 0)
                {
                    transaction.UserPaymentMethodId = command.Request.UserPaymentMethodId;
                    transaction.PreauthCardAmount = command.Request.CardAmount;
                    transaction.PreauthWalletAmount = command.Request.WalletAmount;

                    using (logger.LogPerformance("PreAuthAsync"))
                    {
                        try
                        {
                            PreAuthPaymentCommand preAuthPaymentCommand = new()
                            {
                                UserPaymentMethodId = transaction.UserPaymentMethodId ?? 0,
                                Description = transaction.TransactionInfo,
                                CardAmount = (double)transaction.PreauthCardAmount,
                                WalletAmount = (double)transaction.PreauthWalletAmount,
                                IsPaymentRequired = false,
                                PaymentType = Service.Clients.Payments.PaymentType.StorePumpReserve,
                                StoreId = transaction.StoreId ?? 0,
                                StoreName = transaction.StoreName,
                                UserId = transaction.UserId,
                                ConsumerIP = transaction.ConsumerIP,
                                TransactionId = transaction.TransactionId,
                                SiteId = transaction.SiteId,
                            };

                            logger.Info("PreAuthAsync preAuthPaymentCommand", preAuthPaymentCommand);

                            preAuthPaymentResponseModel = await paymentApiClient.PreAuthAsync(preAuthPaymentCommand);

                            logger.Info("PreAuthAsync preAuthPaymentResponseModel", preAuthPaymentResponseModel);
                        }
                        catch (Exception ex)
                        {
                            logger.Error(ex, transaction);
                            transaction.PaymentErrorMessage = ex.Message;
                        }
                    }

                    if (preAuthPaymentResponseModel != null && preAuthPaymentResponseModel.Success)
                    {
                        isPreauthSuccess = true;
                        transaction.PaymentMethodId = preAuthPaymentResponseModel?.Data?.PaymentMethodId;
                        transaction.PreauthConfirmationNo = preAuthPaymentResponseModel?.Data?.PreAuthConfirmationNo;
                        transaction.UserPaymentMethodId = preAuthPaymentResponseModel?.Data?.UserPaymentMethodId;
                    }
                    else
                    {
                        transaction.IsPaymentSuccess = false;
                        transaction.StatusId = (int)Status.Fail;
                        transaction.PaymentErrorMessage = preAuthPaymentResponseModel?.Message ?? "PreauthConfirmationNo is invalid";
                        transaction.MppaErrorMessage = $"Preauth of payment fail";
                    }
                }

                logger.Info("PreAuthAsync preAuthPaymentResponseModel", preAuthPaymentResponseModel);

                transaction.PreAuthDate = DateTime.UtcNow;
                transaction.HostAuthNumber = hostConfig.HostAuthNumber;

                if (preAuthPaymentResponseModel != null && preAuthPaymentResponseModel.Data != null)
                {
                    transaction.CardType = preAuthPaymentResponseModel.Data.CardTypePrint;
                    transaction.PaymentMethod = preAuthPaymentResponseModel.Data.PaymentType;
                    transaction.CardPrint = preAuthPaymentResponseModel.Data.CardNumberPrint;
                }

                await mediator.Send(new UpdateTransactionCommand
                {
                    Transaction = transaction
                });

                string loyaltyNumber = await GetLoyaltyNumber(transaction, user).ConfigureAwait(false);

                authMppaRequest = await CreateAuthRequest(command, preAuthPaymentResponseModel?.Data, transaction, loyaltyNumber, isPreauthSuccess);

                string authMppaRequesttMsg = Serializer.Serialize<AuthMppaRequest>(authMppaRequest);

                ApplicationCore.Domain.Models.ResponseModel result = null;

                //For Testing Pos Begin
                if (hostConfig.IsPosTestingEnabled)
                {
                    result = new ApplicationCore.Domain.Models.ResponseModel { Message = "", Success = true };
                }
                else
                {
                    result = await mppaMessageProcessor.Process(transaction.TransactionId,
                                                                authMppaRequesttMsg,
                                                                authMppaRequest,
                                                                true,
                                                                RequestType.MobileAuth,
                                                                authMppaRequest.MobileTxnInfo,
                                                                true,
                                                                null);
                }
                //For Testing Pos END

                transaction.HostAuthNumber = hostConfig.HostAuthNumber;
                await UpdateTransaction(transaction, result.Success, result.Message);

                await eventDispatcher.Dispatch(new AuthMppaRequestEvent
                {
                    Transaction = mapper.Map<EventBus.DomainEvents.Models.Mppa.Transaction>(transaction),
                    RequestTypeId = (int)RequestType.MobileAuth,
                    PaymentInfo = mapper.Map<EventBus.DomainEvents.Models.Mppa.PaymentInfo>(authMppaRequest.MobileAuthRequest.PaymentInfo),
                });


                //For Testing POS Begin
                if (hostConfig.IsPosTestingEnabled)
                {
                    await posFakeTestService.GenerateFakeCommanderAuthPosResponse(transaction);
                }
                //For Testing POS END

                logger.TraceExitMethod(nameof(Handle));
            }
            catch (Exception ex)
            {
                logger.Error(ex, transaction, command);

                if (transaction != null)
                {
                    transaction.MppaErrorMessage = ex.Message;
                    await mediator.Send(new UpdateTransactionCommand
                    {
                        Transaction = transaction
                    });
                }
            }
        }

        private async Task UpdateTransaction(Domain.Entities.Transaction transaction,
                                            bool isSuccess,
                                            string error)
        {
            if (!isSuccess)
            {
                transaction.StatusId = (int)Status.Fail;
                transaction.MppaErrorMessage = error;
            }

            await mediator.Send(new UpdateTransactionCommand
            {
                Transaction = transaction
            });
        }

        private async Task<AuthMppaRequest> CreateAuthRequest(MppaAuthRequestCommand command,
                                                    PreAuthPaymentResponseModel preAuthPaymentModel,
                                                    Domain.Entities.Transaction transaction,
                                                    string loyaltyNumber,
                                                    bool isPreAuthSuccess)
        {
            System.Collections.Generic.IEnumerable<Domain.Entities.SaleItem> items = await mediator.Send(new GetSaleItemByFilterQuery
            {
                TransactionId = transaction.TransactionId
            });


            AuthMppaRequest authMppaRequest = new AuthMppaRequest
            {
                MobileTxnInfo = new MobileTxnInfoRequest
                {
                    WorkstationId = transaction.WorkstationId,
                    HostMPPAIdentifier = hostConfig.HostMPPAIdentifier,
                    MerchantId = transaction.MerchantId,
                    SiteId = transaction.SiteId,
                    UMTI = transaction.UMTI,
                    TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                    POSTransNumber = transaction.POSTransNumber,
                },
                MobileAuthRequest = new MobileAuthRequest
                {
                    ItemsPurchased = new ItemsPurchased()
                }
            };

            if (items != null && items.Any())
            {
                authMppaRequest.MobileAuthRequest.ItemsPurchased.SaleItems = items.Select(t =>
                {
                    return new SaleItem
                    {
                        ItemId = t.ItemId,
                        EvaluateOnly = t.EvaluateOnly,
                        PriceChangeEligible = t.PriceChangeEligible.ToString().ToLower(),
                        POSCode = t.POSCode,
                        POSCodeModifier = t.POSCodeModifier,
                        ProductCode = t.ProductCode,
                        OriginalAmount = new ItemAmount
                        {
                            Amount = t.OriginalAmount,
                            UnitPrice = t.OriginalAmountUnitPrice
                        },
                        AdjustedAmount = new ItemAmount
                        {
                            Amount = t.AdjustedAmount,
                            UnitPrice = t.AdjustedAmountUnitPrice
                        },
                        UnitMeasure = t.UnitMeasure,
                        Quantity = t.Quantity,
                        AdditionalProductInfo = t.AdditionalProductInfo,
                        Description = t.Description
                    };
                }).ToArray();
            }

            if (!string.IsNullOrWhiteSpace(loyaltyNumber) && authMppaRequest != null && isPreAuthSuccess)
            {
                authMppaRequest.MobileAuthRequest.LoyaltyInfo = new LoyaltyInfo
                {
                    LoyaltyInstrument = loyaltyNumber
                };
            }

            if (isPreAuthSuccess)
            {
                authMppaRequest.MobileAuthRequest.PaymentInfo = new PaymentInfo
                {
                    CardISO = preAuthPaymentModel?.CardNumberPrint ?? "0000",
                    PaymentMethod = preAuthPaymentModel?.PaymentType ?? "Credit",
                    CardPANPrint = preAuthPaymentModel?.CardNumberPrint ?? "0000",
                    CardType = preAuthPaymentModel?.CardTypePrint ?? "XXXX",
                    PreAuthAmount = preAuthPaymentModel == null ? 0 : transaction.PreauthAmount,
                    HostAuthNumber = hostConfig.HostAuthNumber,
                };
            }
            else
            {
                authMppaRequest.MobileAuthRequest.PaymentInfo = new PaymentInfo
                {
                    CardISO = "0000",
                    PaymentMethod = "Credit",
                    CardPANPrint = "0000",
                    CardType = "XXXX",
                    PreAuthAmount = 0,
                    HostAuthNumber = hostConfig.HostAuthNumber,
                };
            }

            return authMppaRequest;
        }

        private async Task<string> GetLoyaltyNumber(Domain.Entities.Transaction transaction, UserModelResponseModel user)
        {
            string loyaltyNumber = "";
            try
            {
                var storeInfoModel = await storeApiClient.GetStoreInfoAsync(transaction.StoreId, null).ConfigureAwait(false);

                if (storeInfoModel != null && (storeInfoModel.EnableACHLoyalty || storeInfoModel.EnableCardLoyalty))
                {
                    loyaltyNumber = user.Data?.MobileNumber;
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex, "Unable to Fetch Loyalty Setting from store");
            }

            return loyaltyNumber;
        }
    }
}
