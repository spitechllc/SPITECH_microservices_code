﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.MobileAuths;
using SpiTech.MppaService.Domain.Models.Commanders.MobilePumpReserves;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.AuthRequests
{
    public class MppaAuthRequestCommand : IRequest<AuthMppaRequest>
    {
        public PumpReserveCommanderResponse PumpReserveCommanderResponse { get; set; }
    }
}
