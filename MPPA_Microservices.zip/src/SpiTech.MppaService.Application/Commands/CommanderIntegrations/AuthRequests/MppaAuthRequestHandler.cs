﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Extensions;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.MppaService.Application.Commands.UpdateTransaction;
using SpiTech.MppaService.Application.Processors;
using SpiTech.MppaService.Application.Queries.GetTransactionById;
using SpiTech.MppaService.Application.Queries.GetTransactionByUmtiMId;
using SpiTech.MppaService.Application.Services;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Models.Commanders.MobileAuths;
using SpiTech.Service.Clients.Identity;
using SpiTech.Service.Clients.Payments;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.AuthRequests
{
    public class MppaAuthRequestHandler : IRequestHandler<MppaAuthRequestCommand, AuthMppaRequest>
    {
        private readonly ILogger<MppaAuthRequestHandler> logger;
        private readonly IMediator mediator;
        private readonly HostConfig hostConfig;
        private readonly IPaymentServiceClient paymentApiClient;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IMapper mapper;
        private readonly IMppaMessageProcessor mppaMessageProcessor;
        private readonly IIdentityServiceClient identityServiceClient;
        private readonly IStoreServiceClient storeApiClient;
        private readonly IPayAtPumpFakeTestService payAtPumpFakeTestService;

        public MppaAuthRequestHandler(
                                    ILogger<MppaAuthRequestHandler> logger,
                                    IMediator mediator,
                                    HostConfig hostConfig,
                                    IPaymentServiceClient paymentApiClient,
                                    IEventDispatcher eventDispatcher,
                                    IMapper mapper,
                                    IMppaMessageProcessor mppaMessageProcessor,
                                    IIdentityServiceClient identityServiceClient,
                                    IStoreServiceClient storeApiClient,
                                    IPayAtPumpFakeTestService payAtPumpFakeTestService)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.hostConfig = hostConfig;
            this.paymentApiClient = paymentApiClient;
            this.eventDispatcher = eventDispatcher;
            this.mapper = mapper;
            this.mppaMessageProcessor = mppaMessageProcessor;
            this.identityServiceClient = identityServiceClient;
            this.storeApiClient = storeApiClient;
            this.payAtPumpFakeTestService = payAtPumpFakeTestService;
        }

        public async Task<AuthMppaRequest> Handle(MppaAuthRequestCommand command, CancellationToken cancellationToken)
        {
            AuthMppaRequest authMppaRequest = null;
            Domain.Entities.Transaction transaction = null;
            var isPreauthSuccess = false;

            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);

                transaction = await mediator.Send(new GetTransactionByUmtiMIdQuery { 
                    UMTI = command.PumpReserveCommanderResponse.MobileTxnInfo.UMTI,
                    MerchantId = command.PumpReserveCommanderResponse.MobileTxnInfo.MerchantId,
                });

                if (transaction == null)
                {
                    throw new ValidationException(new ValidationFailure("UMTI", $"MppaAuthRequest-UMTI{command.PumpReserveCommanderResponse.MobileTxnInfo.UMTI}-{command.PumpReserveCommanderResponse.MobileTxnInfo.MerchantId} is invalid"));
                }

                var user = await identityServiceClient.GetUserByIdAsync(transaction.UserId, cancellationToken);

                PreAuthPaymentResponseModelResponseModel preAuthPaymentResponseModel = null;

                using (logger.LogPerformance("PreAuthAsync"))
                {
                    try
                    {
                        PreAuthPaymentCommand preAuthPaymentCommand = new()
                        {
                            UserPaymentMethodId = transaction.UserPaymentMethodId ?? 0,
                            Description = transaction.TransactionInfo,
                            CardAmount = (double)transaction.PreauthCardAmount,
                            WalletAmount = (double)transaction.PreauthWalletAmount,
                            IsPaymentRequired = true,
                            PaymentType = Service.Clients.Payments.PaymentType.StorePumpReserve,
                            StoreId = transaction.StoreId ?? 0,
                            StoreName = transaction.StoreName,
                            UserId = transaction.UserId,
                            ConsumerIP = transaction.ConsumerIP,
                            TransactionId = transaction.TransactionId,
                            SiteId = transaction.SiteId,
                        };

                        logger.Info("PreAuthAsync preAuthPaymentCommand", preAuthPaymentCommand);

                        preAuthPaymentResponseModel = await paymentApiClient.PreAuthAsync(preAuthPaymentCommand);

                        logger.Info("PreAuthAsync preAuthPaymentResponseModel", preAuthPaymentResponseModel);
                    }
                    catch (Exception ex)
                    {
                        logger.Error(ex, transaction);
                        transaction.PaymentErrorMessage = ex.Message;
                    }
                }

                if (preAuthPaymentResponseModel != null && preAuthPaymentResponseModel.Success)
                {
                    isPreauthSuccess = true;
                    transaction.PaymentMethodId = preAuthPaymentResponseModel?.Data?.PaymentMethodId;
                    transaction.PreauthConfirmationNo = preAuthPaymentResponseModel?.Data?.PreAuthConfirmationNo;
                    transaction.UserPaymentMethodId = preAuthPaymentResponseModel?.Data?.UserPaymentMethodId;
                }
                else
                {
                    transaction.IsPaymentSuccess = false;
                    transaction.StatusId = (int)Status.Fail;
                    transaction.PaymentErrorMessage = preAuthPaymentResponseModel?.Message ?? "PreauthConfirmationNo is invalid";
                    transaction.MppaErrorMessage = $"Preauth of payment fail";
                }
                logger.Info("PreAuthAsync preAuthPaymentResponseModel", preAuthPaymentResponseModel);

                transaction.PreAuthDate = DateTime.UtcNow;
                transaction.HostAuthNumber = hostConfig.HostAuthNumber;

                if (preAuthPaymentResponseModel != null && preAuthPaymentResponseModel.Data != null)
                {
                    transaction.CardType = preAuthPaymentResponseModel.Data.CardTypePrint;
                    transaction.PaymentMethod = preAuthPaymentResponseModel.Data.PaymentType;
                    transaction.CardPrint = preAuthPaymentResponseModel.Data.CardNumberPrint;
                }

                await mediator.Send(new UpdateTransactionCommand
                {
                    Transaction = transaction
                });

                string loyaltyNumber = await GetLoyaltyNumber(transaction, user).ConfigureAwait(false);

                authMppaRequest = CreateAuthRequest(command, preAuthPaymentResponseModel?.Data, transaction, loyaltyNumber, isPreauthSuccess);

                string authMppaRequesttMsg = Serializer.Serialize<AuthMppaRequest>(authMppaRequest);

                ApplicationCore.Domain.Models.ResponseModel result = null;

                //For Testing PayAtPump Begin
                if (hostConfig.IsPayAtPumpTestingEnabled)
                {
                    result = new ApplicationCore.Domain.Models.ResponseModel { Message = "", Success = true };
                }
                else
                {
                    result = await mppaMessageProcessor.Process(transaction.TransactionId,
                                                                authMppaRequesttMsg,
                                                                authMppaRequest,
                                                                true,
                                                                RequestType.MobileAuth,
                                                                authMppaRequest.MobileTxnInfo,
                                                                true,
                                                                null);
                }
                //For Testing PayAtPump END

                transaction.HostAuthNumber = hostConfig.HostAuthNumber;
                await UpdateTransaction(transaction, result.Success, result.Message);

                await eventDispatcher.Dispatch(new AuthMppaRequestEvent
                {
                    Transaction = mapper.Map<EventBus.DomainEvents.Models.Mppa.Transaction>(transaction),
                    RequestTypeId = (int)RequestType.MobileAuth,
                    PaymentInfo = mapper.Map<EventBus.DomainEvents.Models.Mppa.PaymentInfo>(authMppaRequest.MobileAuthRequest.PaymentInfo),
                });

                //For Testing PayAtPump Begin
                if (hostConfig.IsPayAtPumpTestingEnabled)
                {
                    await payAtPumpFakeTestService.GenerateFakeCommanderAuthResponse(transaction);
                }
                //For Testing PayAtPump END

                logger.TraceExitMethod(nameof(Handle));
            }
            catch (Exception ex)
            {
                logger.Error(ex, transaction, command);

                if (transaction != null)
                {
                    transaction.MppaErrorMessage = ex.Message;
                    await mediator.Send(new UpdateTransactionCommand
                    {
                        Transaction = transaction
                    });
                }
            }

            return await Task.FromResult(authMppaRequest);
        }

        private async Task UpdateTransaction(Domain.Entities.Transaction transaction,
                                            bool isSuccess,
                                            string error)
        {
            if (!isSuccess)
            {
                transaction.StatusId = (int)Status.Fail;
                transaction.MppaErrorMessage = error;
            }

            await mediator.Send(new UpdateTransactionCommand
            {
                Transaction = transaction
            });
        }

        private AuthMppaRequest CreateAuthRequest(MppaAuthRequestCommand command,
                                                    PreAuthPaymentResponseModel preAuthPaymentModel,
                                                    Domain.Entities.Transaction transaction,
                                                    string loyaltyNumber,
                                                    bool isPreAuthSuccess)
        {
            AuthMppaRequest authMppaRequest = new AuthMppaRequest
            {
                MobileTxnInfo = new MobileTxnInfoRequest
                {
                    FuelingPositionId = command.PumpReserveCommanderResponse.MobileTxnInfo.FuelingPositionId.ToString(),
                    HostMPPAIdentifier = hostConfig.HostMPPAIdentifier,
                    MerchantId = command.PumpReserveCommanderResponse.MobileTxnInfo.MerchantId,
                    SiteId = command.PumpReserveCommanderResponse.MobileTxnInfo.SiteId,
                    UMTI = command.PumpReserveCommanderResponse.MobileTxnInfo.UMTI,
                    TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK")
                },
                MobileAuthRequest = new MobileAuthRequest
                {
                    //ItemsPurchased = new ItemsPurchased
                    //{
                    //    SaleItems = new[]
                    //    {
                    //        new SaleItem{
                    //             ItemId = "1E1",
                    //             //ItemStatus=true,
                    //             EvaluateOnly=true,
                    //             PriceChangeEligible=true,
                    //             POSCode="00000000000000",
                    //             POSCodeModifier="0" ,
                    //             ProductCode="1",
                    //             OriginalAmount=new ItemAmount{
                    //             Amount=0,
                    //             UnitPrice=0
                    //             },
                    //             AdjustedAmount=new ItemAmount{
                    //             Amount=0,
                    //             UnitPrice=0
                    //             },
                    //             UnitMeasure="GLL",
                    //             Quantity=0,
                    //             AdditionalProductInfo="",
                    //             Description="",
                    //             PriceTier="credit",
                    //             PriceAdjustment=new PriceAdjustment
                    //            {
                    //                RewardApplied=false,
                    //                PriceAdjustmentId="Line Discount 1",
                    //                ProgramId="Discount Program 1",
                    //                PromotionReason=new PromotionReason{
                    //                    DoNotRelieveTaxFlag=false,
                    //                    Reason="loyaltyOffer"
                    //                },
                    //                Amount=0.0,
                    //                UnitPrice=0.15,
                    //                Quantity=0,
                    //                RebateLabel="Line Rebate 1"
                    //            }
                    //        }
                    //    }
                    //}
                }
            };

            if (!string.IsNullOrWhiteSpace(loyaltyNumber) && authMppaRequest != null && isPreAuthSuccess)
            {
                authMppaRequest.MobileAuthRequest.LoyaltyInfo = new LoyaltyInfo
                {
                    LoyaltyInstrument = loyaltyNumber
                };
            }

            if (isPreAuthSuccess)
            {
                authMppaRequest.MobileAuthRequest.PaymentInfo = new PaymentInfo
                {
                    CardISO = preAuthPaymentModel?.CardNumberPrint ?? "0000",
                    PaymentMethod = preAuthPaymentModel?.PaymentType ?? "Credit",
                    CardPANPrint = preAuthPaymentModel?.CardNumberPrint ?? "0000",
                    CardType = preAuthPaymentModel?.CardTypePrint ?? "XXXX",
                    PreAuthAmount = preAuthPaymentModel == null ? 0 : transaction.PreauthAmount,
                    HostAuthNumber = hostConfig.HostAuthNumber,
                };
            }
            else
            {
                authMppaRequest.MobileAuthRequest.PaymentInfo = new PaymentInfo
                {
                    CardISO = "0000",
                    PaymentMethod = "Credit",
                    CardPANPrint = "0000",
                    CardType = "XXXX",
                    PreAuthAmount = 0,
                    HostAuthNumber = hostConfig.HostAuthNumber,
                };
            }

            return authMppaRequest;
        }

        private async Task<string> GetLoyaltyNumber(Domain.Entities.Transaction transaction, UserModelResponseModel user)
        {
            string loyaltyNumber = "";
            try
            {
                var storeInfoModel = await storeApiClient.GetStoreInfoAsync(transaction.StoreId, null).ConfigureAwait(false);

                if (storeInfoModel != null && (storeInfoModel.EnableACHLoyalty || storeInfoModel.EnableCardLoyalty))
                {
                    loyaltyNumber = user.Data?.MobileNumber;
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex, "Unable to Fetch Loyalty Setting from store");
            }

            return loyaltyNumber;
        }
    }
}
