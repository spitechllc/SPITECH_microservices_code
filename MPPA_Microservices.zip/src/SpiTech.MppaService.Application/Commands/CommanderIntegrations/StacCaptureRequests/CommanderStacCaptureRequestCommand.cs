﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.MobileStacCapture;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.StacCaptureRequests
{
    public class CommanderStacCaptureRequestCommand : IRequest<bool>
    {
        public StacCaptureCommanderRequest StacCaptureRequest { get; set; }
    }
}
