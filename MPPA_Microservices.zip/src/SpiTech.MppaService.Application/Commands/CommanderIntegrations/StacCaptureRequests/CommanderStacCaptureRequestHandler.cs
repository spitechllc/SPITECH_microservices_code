﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.StacCaptureResponses;
using SpiTech.MppaService.Application.Commands.CreateTransaction;
using SpiTech.MppaService.Application.Commands.MobileIntegrations.StacCaptureResponses;
using SpiTech.MppaService.Application.Commands.UpdateGetSite;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.StacCaptureRequests
{
    public class CommanderStacCaptureRequestHandler : IRequestHandler<CommanderStacCaptureRequestCommand, bool>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<CommanderStacCaptureRequestHandler> logger;
        private readonly IMediator mediator;
        private readonly IEventDispatcher eventDispatcher;
        private readonly HostConfig hostConfig;
        private readonly IMapper mapper;
        private readonly IStoreServiceClient storeApiClient;

        public CommanderStacCaptureRequestHandler(IUnitOfWork context,
                                    ILogger<CommanderStacCaptureRequestHandler> logger,
                                    IMediator mediator,
                                    IEventDispatcher eventDispatcher,
                                    HostConfig hostConfig,
                                    IMapper mapper,
                                    IStoreServiceClient storeApiClient)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            this.eventDispatcher = eventDispatcher;
            this.hostConfig = hostConfig;
            this.mapper = mapper;
            this.storeApiClient = storeApiClient;
        }

        public async Task<bool> Handle(CommanderStacCaptureRequestCommand command, CancellationToken cancellationToken)
        {
            DateTime startTime = DateTime.UtcNow;
            bool isMatched = false;
            bool isExpaired = true;
            StacGeneration stac = null;
            Transaction transaction = null;
            string stacCaptureType = "";

            try
            {
                var stacCapture = StacGenerator.StacWithOutPrefix(command.StacCaptureRequest.MobileSTACCaptureRequest.Stac);

                IEnumerable<StacGeneration> stacs = await context.StacGenerations.GetByFilter(stacCapture);

                if (stacs != null && stacs.Any())
                {
                    stac = stacs.FirstOrDefault(t => t.SiteId == command.StacCaptureRequest.MobileTxnInfo.SiteId);

                    if (stac != null)
                    {
                        isMatched = true;
                        isExpaired = !(stac.GenerateDate > DateTime.UtcNow.AddSeconds(-hostConfig.StacTimeoutInSec));
                        stac.VerifyDate = startTime;
                        stac.IsVerified = true;
                        stac.RequestAmount = command.StacCaptureRequest.MobileSTACCaptureRequest.RequestAmount;

                        stacCaptureType = stac.QrCodeStac == stacCapture ? "Q" : stac.BarCodeStac == stacCapture ? "B" : "";
                    }
                }

                StacCaptureRequest stacCaptureRequest = await CreateStacCaptureRequest(command, stac, isMatched, isExpaired, stacCaptureType);

                if (stac != null)
                {
                    await context.Execute(async () =>
                    {
                        await context.StacGenerations.Update(stac);
                    });

                    if (isMatched && !isExpaired)
                    {
                        transaction = await CreateTransaction(command, stac, stacCaptureType);
                    }

                    await SendStatusToMobile(stac, stacCaptureRequest, false, String.Empty, transaction, command);
                }

                await mediator.Send(new MppaStacCaptureResponseCommand
                {
                    TransactionId = transaction?.TransactionId,
                    StacCaptureRequest = command.StacCaptureRequest
                });
            }
            catch (Exception ex)
            {
                logger.Error(ex, transaction, command);
            }

            return await Task.FromResult(isMatched && !isExpaired);
        }

        private async Task<Transaction> CreateTransaction(CommanderStacCaptureRequestCommand command,
                                                          StacGeneration stac,
                                                          string stacCaptureType)
        {
            Site sitedata = await mediator.Send(new UpdateGetSiteCommand { SiteId = command.StacCaptureRequest.MobileTxnInfo.SiteId });
            
            Service.Clients.Stores.StoreInfoModel storeInfoModel = null;

            if (!string.IsNullOrWhiteSpace(stac?.SiteId))
            {
                storeInfoModel = await storeApiClient.GetStoreInfoAsync(null, stac.SiteId).ConfigureAwait(false);
            }

            Transaction transaction = new()
            {
                SiteId = command.StacCaptureRequest.MobileTxnInfo.SiteId,
                StoreId = sitedata?.StoreId ?? 0,
                StoreName = sitedata?.StoreName,
                MerchantId = command.StacCaptureRequest.MobileTxnInfo.MerchantId,
                UMTI = command.StacCaptureRequest.MobileTxnInfo.UMTI,
                POSTransNumber = command.StacCaptureRequest.MobileTxnInfo.POSTransNumber,
                WorkstationId = command.StacCaptureRequest.MobileTxnInfo.WorkstationId,
                SiteMPPAIdentifier = command.StacCaptureRequest.MobileTxnInfo.SiteMPPAIdentifier,
                StatusId = (int)Status.Inprogress,
                UserId = stac.UserId,
                DeviceToken = stac.DeviceToken,
                AppType = stac.AppType,
                TransactionTypeId = (int)TransactionType.PayAtPos,
                TransactionDate = DateTime.UtcNow,
                PumpReserveDate = DateTime.UtcNow,
                PreauthAmount = stac.RequestAmount,
                CommanderTimeDateStamp = command.StacCaptureRequest.MobileTxnInfo.TimeDateStamp,
                TransactionInfo = "Store Items Purchase",
                DisableBilling = storeInfoModel?.DisableBilling ?? false,
                DisableEod = storeInfoModel?.DisableEod ?? false,
                StacCaptureType = stacCaptureType
            };

            transaction.TransactionId = await mediator.Send(new CreateTransactionCommand
            {
                Transaction = transaction
            });

            await eventDispatcher.Dispatch(new StacCaptureRequestEvent
            {
                RequestTypeId = (int)EventBus.DomainEvents.Enums.RequestType.MobileStacCapture,
                Transaction = mapper.Map<EventBus.DomainEvents.Models.Mppa.Transaction>(transaction),
            });

            return transaction;
        }

        private async Task<StacCaptureRequest> CreateStacCaptureRequest(CommanderStacCaptureRequestCommand command,
                                                                        StacGeneration stac,
                                                                        bool isMatched,
                                                                        bool isExpired,
                                                                        string stacCaptureType)
        {
            StacCaptureRequest stacCaptureRequest = new()
            {
                StacCaptureRequestId = Guid.NewGuid(),
                SiteId = command.StacCaptureRequest.MobileTxnInfo.SiteId,
                MerchantId = command.StacCaptureRequest.MobileTxnInfo.MerchantId,
                UMTI = command.StacCaptureRequest.MobileTxnInfo.UMTI,
                PosTransNumber = command.StacCaptureRequest.MobileTxnInfo.POSTransNumber,
                WorkstationId = command.StacCaptureRequest.MobileTxnInfo.WorkstationId,
                SiteMppaIdentifier = command.StacCaptureRequest.MobileTxnInfo.SiteMPPAIdentifier,
                UserId = stac?.UserId,
                DeviceToken = stac?.DeviceToken,
                AppType = stac?.AppType,
                RequestDate = DateTime.UtcNow,
                RequestAmount = command.StacCaptureRequest.MobileSTACCaptureRequest.RequestAmount,
                Stac = command.StacCaptureRequest.MobileSTACCaptureRequest.Stac,
                IsMatched = isMatched,
                IsExpired = isExpired,
                IsActive = true,
                StacGenerationId = stac?.StacGenerationId,
                StacCaptureType = stacCaptureType,
                BarCodeStac = stac?.BarCodeStac,
                QrCodeStac = stac?.QrCodeStac,
            };

            await context.Execute(async () =>
            {
                await context.StacCaptureRequests.Insert(stacCaptureRequest);
            });

            return stacCaptureRequest;
        }

        private async Task SendStatusToMobile(StacGeneration stac,
                                            StacCaptureRequest stacCaptureRequest,
                                            bool isError,
                                            string error,
                                            Transaction transaction,
                                            CommanderStacCaptureRequestCommand command)
        {
            try
            {
                await mediator.Send(new MobileStacCaptureResponseCommand
                {
                    TransactionId = transaction?.TransactionId ?? 0,
                    UMTI = stacCaptureRequest.UMTI,
                    SiteId = stacCaptureRequest.SiteId,
                    UserId = stac.UserId,
                    Success = !isError,
                    Stac = command.StacCaptureRequest.MobileSTACCaptureRequest.Stac,
                    Erorr = error,
                    CaptureDate = DateTime.UtcNow,
                    IsMatched = stacCaptureRequest.IsMatched,
                    IsExpired = stacCaptureRequest.IsExpired,
                });
            }
            catch (Exception ex)
            {
                logger.Error(ex, stac, stacCaptureRequest);
            }
        }
    }
}
