﻿
using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.MppaService.Application.Commands.MobileIntegrations.CommanderProcessStatusResponses;
using SpiTech.MppaService.Application.Commands.UpdateTransaction;
using SpiTech.MppaService.Application.Queries.GetTransactionById;
using SpiTech.MppaService.Application.Queries.GetTransactionByUmtiMId;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models.Commanders.MobilePumpReserveCancel;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.PumpReserveCancelResponses
{
    public class CommanderPumpReserveCancelResponseHandler : IRequestHandler<CommanderPumpReserveCancelResponseCommand, bool>
    {
        private readonly ILogger<CommanderPumpReserveCancelResponseHandler> logger;
        private readonly IMediator mediator;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IMapper mapper;

        public CommanderPumpReserveCancelResponseHandler(
                                    ILogger<CommanderPumpReserveCancelResponseHandler> logger,
                                    IMediator mediator,
                                    IEventDispatcher eventDispatcher,
                                    IMapper mapper)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.eventDispatcher = eventDispatcher;
            this.mapper = mapper;
        }

        public async Task<bool> Handle(CommanderPumpReserveCancelResponseCommand command, CancellationToken cancellationToken)
        {
            Domain.Entities.Transaction transaction = null;

            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);

                transaction = await mediator.Send(new GetTransactionByUmtiMIdQuery
                {
                    UMTI = command.PumpReserveCancelCommanderResponse.MobileTxnInfo.UMTI,
                    MerchantId = command.PumpReserveCancelCommanderResponse.MobileTxnInfo.MerchantId
                });

                if (transaction == null)
                {
                    throw new ValidationException(new ValidationFailure("UMTI", $"UMTI-{command.PumpReserveCancelCommanderResponse.MobileTxnInfo.UMTI}-{command.PumpReserveCancelCommanderResponse.MobileTxnInfo.MerchantId} is invalid"));
                }

                string message = Serializer.Serialize<PumpReserveCancelCommanderResponse>(command.PumpReserveCancelCommanderResponse);

                bool isSuccess = command.PumpReserveCancelCommanderResponse.MobileCancelResponse.Response.ResponseCode == Constants.SuccessResponseCode;

                string error = isSuccess ? "" : $"{command.PumpReserveCancelCommanderResponse.MobileCancelResponse.Response.ResponseCode}-{command.PumpReserveCancelCommanderResponse.MobileCancelResponse.Response.OverallResult}-{command.PumpReserveCancelCommanderResponse.MobileCancelResponse.Response.MessageCode}";

                if (isSuccess)
                {
                    transaction.CancelDate = DateTime.UtcNow;
                    transaction.StatusId = (int)Status.Canceled;

                    if (!string.IsNullOrWhiteSpace(command.PumpReserveCancelCommanderResponse.MobileTxnInfo.POSTransNumber))
                    {
                        transaction.POSTransNumber = command.PumpReserveCancelCommanderResponse.MobileTxnInfo.POSTransNumber;
                    }

                    if (!string.IsNullOrWhiteSpace(command.PumpReserveCancelCommanderResponse.MobileTxnInfo.SiteMPPAIdentifier))
                    {
                        transaction.SiteMPPAIdentifier = command.PumpReserveCancelCommanderResponse.MobileTxnInfo.SiteMPPAIdentifier;
                    }
                }
                else
                {
                    transaction.MppaErrorMessage = error;
                }

                await mediator.Send(new UpdateTransactionCommand
                {
                    Transaction = transaction
                });

                await eventDispatcher.Dispatch(new TransactionUpdateEvent
                {
                    Transaction = mapper.Map<EventBus.DomainEvents.Models.Mppa.Transaction>(transaction),
                    RequestTypeId = (int)EventBus.DomainEvents.Enums.RequestType.MobileCancel,
                });

                await SendStatusToMobile(command, transaction.UserId, !isSuccess, error, transaction);

                logger.TraceExitMethod(nameof(Handle), isSuccess);
                return await Task.FromResult(isSuccess);
            }
            catch (Exception ex)
            {
                logger.Error(ex, transaction, command);

                if (transaction != null)
                {
                    transaction.MppaErrorMessage = ex.Message;
                    await mediator.Send(new UpdateTransactionCommand
                    {
                        Transaction = transaction
                    });
                }
            }

            return await Task.FromResult(false);
        }

        private async Task SendStatusToMobile(CommanderPumpReserveCancelResponseCommand command, int userId, bool isError, string error, Transaction transaction)
        {
            try
            {
                await mediator.Send(new MobileCommanderProcessStatusResponseCommand
                {
                    TransactionId = transaction?.TransactionId ?? 0,
                    RequestType = EventBus.DomainEvents.Enums.RequestType.MobileCancel,
                    SiteId = command.PumpReserveCancelCommanderResponse.MobileTxnInfo.SiteId,
                    UMTI = command.PumpReserveCancelCommanderResponse.MobileTxnInfo.UMTI,
                    UserId = userId,
                    Status = !isError ? ProcessConstants.ReserveCancelled : ProcessConstants.ReserveCancelError,
                    ProcessName = ProcessConstants.ReserveCancelled,
                    Success = !isError,
                    Erorr = error
                });
            }
            catch (Exception ex)
            {
                logger.Error(ex, transaction);
            }
        }
    }
}
