﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.MobilePumpReserveCancel;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.PumpReserveCancelResponses
{
    public class CommanderPumpReserveCancelResponseCommand : IRequest<bool>
    {
        public PumpReserveCancelCommanderResponse PumpReserveCancelCommanderResponse { get; set; }
    }
}
