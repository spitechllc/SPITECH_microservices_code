﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents;
using SpiTech.MppaService.Application.Commands.MobileIntegrations.CommanderProcessStatusResponses;
using SpiTech.MppaService.Application.Commands.UpdateTransaction;
using SpiTech.MppaService.Application.Processors;
using SpiTech.MppaService.Application.Queries.GetTransactionById;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models.Commanders.MobilePumpReserveCancel;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.PumpReserveCancelRequests
{
    public class MppaPumpReserveCancelRequestHandler : INotificationHandler<MppaPumpReserveCancelRequestCommand>
    {
        private readonly ILogger<MppaPumpReserveCancelRequestHandler> logger;
        private readonly IMediator mediator;
        private readonly HostConfig hostConfig;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IMapper mapper;
        private readonly IMppaMessageProcessor mppaMessageProcessor;

        public MppaPumpReserveCancelRequestHandler(
                                    ILogger<MppaPumpReserveCancelRequestHandler> logger,
                                    IMediator mediator,
                                    HostConfig hostConfig,
                                    IEventDispatcher eventDispatcher,
                                    IMapper mapper,
                                    IMppaMessageProcessor mppaMessageProcessor)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.hostConfig = hostConfig;
            this.eventDispatcher = eventDispatcher;
            this.mapper = mapper;
            this.mppaMessageProcessor = mppaMessageProcessor;
        }

        public async Task Handle(MppaPumpReserveCancelRequestCommand command, CancellationToken cancellationToken)
        {
            PumpReserveCancelMppaRequest request = null;
            ApplicationCore.Domain.Models.ResponseModel result = new();
            Transaction transaction = null;

            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);

                transaction = await mediator.Send(new GetTransactionByIdQuery { TransactionId = long.Parse(command.UMTI) });

                if (transaction == null)
                {
                    throw new ValidationException(new ValidationFailure("UMTI", $"MppaPumpReserveCancelRequest-TransactionId-{command.UMTI} is invalid"));
                }

                request = new PumpReserveCancelMppaRequest
                {
                    MobileTxnInfo = new MobileTxnInfoRequest
                    {
                        UMTI = transaction.UMTI,
                        FuelingPositionId = transaction.FuelingPositionId ?? 0,
                        SiteId = transaction.SiteId,
                        TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                        MerchantId = transaction.MerchantId
                    },
                    MobileCancelRequest = new MobileCancelRequest()
                };

                string requestMsg = Serializer.Serialize<PumpReserveCancelMppaRequest>(request);

                result = await mppaMessageProcessor.Process(transaction.TransactionId,
                                                                requestMsg,
                                                                request,
                                                                true,
                                                                EventBus.DomainEvents.Enums.RequestType.MobileCancel,
                                                                request.MobileTxnInfo,
                                                                true,
                                                                null);

                await SendStatusToMobile(command, request, false, "", transaction);

                if (!result.Success)
                {
                    await SendStatusToMobile(command, request, !result.Success, result.Message, transaction);
                }

                if (!result.Success)
                {
                    transaction.MppaErrorMessage = result.Message;

                    await mediator.Send(new UpdateTransactionCommand
                    {
                        Transaction = transaction
                    });
                }

                logger.TraceExitMethod(nameof(Handle));
            }
            catch (Exception ex)
            {
                result.Message = ex.Message;
                result.Success = false;
                logger.Error(ex, transaction, command);

                await SendStatusToMobile(command, request, !result.Success, result.Message, transaction);

                if (transaction != null)
                {
                    transaction.MppaErrorMessage = ex.Message;
                    await mediator.Send(new UpdateTransactionCommand
                    {
                        Transaction = transaction
                    });
                }
            }
            await Task.CompletedTask;
        }

        private async Task SendStatusToMobile(MppaPumpReserveCancelRequestCommand command,
            PumpReserveCancelMppaRequest request,
            bool isError,
            string error,
            Transaction transaction)
        {
            try
            {
                await mediator.Send(new MobileCommanderProcessStatusResponseCommand
                {
                    TransactionId = transaction?.TransactionId ?? 0,
                    RequestType = EventBus.DomainEvents.Enums.RequestType.MobileCancel,
                    SiteId = request.MobileTxnInfo.SiteId,
                    UMTI = request.MobileTxnInfo.UMTI,
                    UserId = command.UserId,
                    Status = !isError ? ProcessConstants.ReserveCancelInprogress : ProcessConstants.ReserveCancelError,
                    ProcessName = ProcessConstants.ReserveCancelInprogress,
                    Success = !isError,
                    Erorr = error
                });
            }
            catch (Exception ex)
            {
                logger.Error(ex, transaction);
            }
        }
    }
}
