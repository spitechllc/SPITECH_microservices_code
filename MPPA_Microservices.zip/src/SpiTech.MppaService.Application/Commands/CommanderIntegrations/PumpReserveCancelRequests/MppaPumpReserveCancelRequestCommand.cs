﻿using SpiTech.MppaService.Domain.Interfaces;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.PumpReserveCancelRequests
{
    public class MppaPumpReserveCancelRequestCommand : IMobileRequest
    {
        public string UMTI { get; set; }
        public int UserId { get; set; }
    }
}
