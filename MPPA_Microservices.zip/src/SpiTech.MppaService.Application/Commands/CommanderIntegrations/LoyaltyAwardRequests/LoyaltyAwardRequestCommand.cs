﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.MobileLoyaltyAwards;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.LoyaltyAwardRequests
{
    public class LoyaltyAwardRequestCommand : IRequest<bool>
    {
        public MobileLoyaltyAwardMppaRequest MobileLoyaltyAwardMppaRequest { get; set; }
    }
}
