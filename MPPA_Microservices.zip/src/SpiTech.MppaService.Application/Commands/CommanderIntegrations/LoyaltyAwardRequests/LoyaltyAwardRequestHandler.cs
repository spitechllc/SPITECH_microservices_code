﻿using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.MppaService.Application.Processors;
using SpiTech.MppaService.Application.Queries.GetTransactionById;
using SpiTech.MppaService.Application.Queries.GetTransactionByUmtiMId;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Models.Commanders;
using SpiTech.MppaService.Domain.Models.Commanders.MobileLoyaltyAwards;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.LoyaltyAwardRequests
{
    public class LoyaltyAwardRequestHandler : IRequestHandler<LoyaltyAwardRequestCommand, bool>
    {
        private readonly ILogger<LoyaltyAwardRequestHandler> logger;
        private readonly IMediator mediator;
        private readonly HostConfig hostConfig;
        private readonly IMppaMessageProcessor mppaMessageProcessor;

        public LoyaltyAwardRequestHandler(
                                    ILogger<LoyaltyAwardRequestHandler> logger,
                                    IMediator mediator,
                                    HostConfig hostConfig,
                                    IMppaMessageProcessor mppaMessageProcessor)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.hostConfig = hostConfig;
            this.mppaMessageProcessor = mppaMessageProcessor;
        }

        public async Task<bool> Handle(LoyaltyAwardRequestCommand command, CancellationToken cancellationToken)
        {
            MobileLoyaltyAwardCommanderResponse response = null;
            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);

                var transaction = await mediator.Send(new GetTransactionByUmtiMIdQuery
                { 
                    UMTI = command.MobileLoyaltyAwardMppaRequest.MobileTxnInfo.UMTI ,
                    MerchantId = command.MobileLoyaltyAwardMppaRequest.MobileTxnInfo.MerchantId,
                });

                if (transaction == null)
                {
                    throw new ValidationException(new ValidationFailure("UMTI", $"UMTI-{command.MobileLoyaltyAwardMppaRequest.MobileTxnInfo.UMTI}-{command.MobileLoyaltyAwardMppaRequest.MobileTxnInfo.MerchantId} is invalid"));
                }

                response = new MobileLoyaltyAwardCommanderResponse
                {
                    MobileTxnInfo = new MobileTxnInfoResponse
                    {
                        MerchantId = command.MobileLoyaltyAwardMppaRequest.MobileTxnInfo.MerchantId,
                        POSTransNumber = command.MobileLoyaltyAwardMppaRequest.MobileTxnInfo.POSTransNumber,
                        SiteId = command.MobileLoyaltyAwardMppaRequest.MobileTxnInfo.SiteId,
                        UMTI = command.MobileLoyaltyAwardMppaRequest.MobileTxnInfo.UMTI,
                        TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                        WorkstationId = command.MobileLoyaltyAwardMppaRequest.MobileTxnInfo.WorkstationId,
                        SiteMPPAIdentifier = command.MobileLoyaltyAwardMppaRequest.MobileTxnInfo.SiteMPPAIdentifier,
                        FuelingPositionId = command.MobileLoyaltyAwardMppaRequest.MobileTxnInfo.FuelingPositionId,
                        HostMPPAIdentifier = hostConfig.HostMPPAIdentifier,
                    },
                    MobileLoyaltyAwardResponse = new MobileLoyaltyAwardResponse
                    {
                        Response = new Response
                        {
                            MessageCode = Constants.SuccessMessageCode,
                            OverallResult = Constants.SuccessOverallResult,
                            ResponseCode = Constants.SuccessResponseCode
                        },
                        ItemsPurchased = command.MobileLoyaltyAwardMppaRequest.MobileLoyaltyAwardRequest.ItemsPurchased
                    }
                };

                if (response.MobileLoyaltyAwardResponse?.ItemsPurchased?.SaleItems != null)
                {
                    foreach (SaleItem item in response.MobileLoyaltyAwardResponse.ItemsPurchased.SaleItems)
                    {
                        item.PriceAdjustment = null;
                        item.OutdoorPosition = null;
                        item.ServiceLevel = null;
                        item.ItemStatus = null;
                        item.PriceChangeEligible = null;
                    }
                }

                if (hostConfig.IsLoyaltyTestingEnabled)
                {
                    //if (response.MobileLoyaltyAwardResponse?.ItemsPurchased?.SaleItems != null)
                    //{
                    //    foreach (SaleItem item in response.MobileLoyaltyAwardResponse.ItemsPurchased.SaleItems)
                    //    {
                    //        item.PriceAdjustment = new PriceAdjustment
                    //        {
                    //            RewardApplied = true,
                    //            PriceAdjustmentId = "Line Discount 1",
                    //            ProgramId = "Discount Program 1",
                    //            PromotionReason = new PromotionReason { DoNotRelieveTaxFlag = false, Reason = "loyaltyOffer" },
                    //            Amount = 0.35M,
                    //            UnitPrice = 0.35M,
                    //            Quantity = 1,
                    //            RebateLabel = "Line Rebate 1"
                    //        };

                    //        item.AdjustedAmount = new ItemAmount
                    //        {
                    //            Amount = item.OriginalAmount.Amount - 0.35M,
                    //            UnitPrice = item.OriginalAmount.UnitPrice - 0.35M
                    //        };
                    //    }
                    //}
                }

                string responseMsg = Serializer.Serialize<MobileLoyaltyAwardCommanderResponse>(response);

                ApplicationCore.Domain.Models.ResponseModel result = await mppaMessageProcessor.Process(transaction?.TransactionId,
                                                            responseMsg,
                                                            response,
                                                            false,
                                                            EventBus.DomainEvents.Enums.RequestType.MobileLoyaltyAward,
                                                            response.MobileTxnInfo,
                                                            true,
                                                            response.MobileLoyaltyAwardResponse.Response);

                logger.TraceExitMethod(nameof(Handle), response);
            }
            catch (Exception ex)
            {
                logger.Error(ex, response, command);
            }

            return await Task.FromResult(true);
        }
    }
}
