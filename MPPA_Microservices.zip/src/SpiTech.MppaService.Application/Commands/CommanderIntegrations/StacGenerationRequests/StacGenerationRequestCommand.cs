﻿using SpiTech.MppaService.Domain.Interfaces;
using SpiTech.MppaService.Domain.Models.Mobile;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.StacGenerationRequests
{
    public class StacGenerationRequestCommand : IMobileRequest
    {
        public int UserId { get; set; }
        public StacGenerationRequest Request { get; set; }
    }
}
