﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.Commands.MobileIntegrations.StacGenerationResponses;
using SpiTech.MppaService.Application.Services;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Entities;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.StacGenerationRequests
{
    public class StacGenerationRequestHandler : INotificationHandler<StacGenerationRequestCommand>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<StacGenerationRequestHandler> logger;
        private readonly IMediator mediator;
        private readonly HostConfig hostConfig;
        private readonly IPosFakeTestService posFakeTestService;

        public StacGenerationRequestHandler(IUnitOfWork context,
                                    ILogger<StacGenerationRequestHandler> logger,
                                    IMediator mediator,
                                    HostConfig hostConfig,
                                    IPosFakeTestService posFakeTestService)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            this.hostConfig = hostConfig;
            this.posFakeTestService = posFakeTestService;
        }

        public async Task Handle(StacGenerationRequestCommand command, CancellationToken cancellationToken)
        {
            try
            {
                //var inProgressTransaction = await mediator.Send(new GetUserInprogressTransactionQuery { 
                //    UserId = command.UserId, 
                //    TimeOutInSec = hostConfig.TransactionTimeoutInSec,
                //    TransactionType = EventBus.DomainEvents.Enums.TransactionType.FuelReserve
                //});

                //if (inProgressTransaction != null)
                //{
                //    await mediator.Send(new MobileStacGenerationResponseCommand
                //    {
                //        SiteId = command.Request.SiteId,
                //        UserId = command.UserId,
                //        Success = false,
                //        Erorr = $"You have one transaction in-progress, Please try after {Math.Ceiling(hostConfig.TransactionTimeoutInSec - (DateTime.UtcNow - inProgressTransaction.TransactionDate).TotalSeconds)} seconds",
                //        Stac = string.Empty
                //    });

                //    return;
                //}

                StacGeneration stacGeneration = await Generate(command);
                int retry = 1;

                while (stacGeneration == null)
                {
                    stacGeneration = await Generate(command);

                    if (retry > 10)
                    {
                        break;
                    }

                    retry++;
                }

                if (stacGeneration != null)
                {
                    await mediator.Send(new MobileStacGenerationResponseCommand
                    {
                        SiteId = command.Request.SiteId,
                        UserId = command.UserId,
                        Success = true,
                        Erorr = string.Empty,
                        Stac = StacGenerator.StacWithPrefix(stacGeneration.StacGenerationId),
                        BarCodeStac = StacGenerator.StacWithPrefix(stacGeneration.BarCodeStac),
                        QrCodeStac = StacGenerator.StacWithPrefix(stacGeneration.QrCodeStac),
                        GenerateDate = stacGeneration.GenerateDate,
                    });


                    //For Testing POS Begin
                    if (hostConfig.IsPosTestingEnabled)
                    {
                        await posFakeTestService.GenerateFakeCommanderStacResponse(command, stacGeneration);
                    }
                    //For Testing POS END
                }
                else
                {
                    await mediator.Send(new MobileStacGenerationResponseCommand
                    {
                        SiteId = command.Request.SiteId,
                        UserId = command.UserId,
                        Success = false,
                        Erorr = "Unable to generate Stac",
                        Stac = string.Empty
                    });
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex, command);
                await mediator.Send(new MobileStacGenerationResponseCommand
                {
                    SiteId = command.Request.SiteId,
                    UserId = command.UserId,
                    Success = false,
                    Erorr = "Error occured while generate Stac",
                    Stac = string.Empty
                });
            }
            await Task.CompletedTask;
        }

        private async Task<StacGeneration> Generate(StacGenerationRequestCommand command)
        {
            var stacGeneration = new StacGeneration
            {
                StacGenerationId = StacGenerator.Generate(),
                QrCodeStac = StacGenerator.Generate(),
                BarCodeStac = StacGenerator.Generate(),
                SiteId = command.Request.SiteId,
                IsActive = true,
                DeviceToken = command.Request.DeviceToken,
                AppType = command.Request.DeviceType.ToString(),
                GenerateDate = DateTime.UtcNow,
                UserId = command.UserId,
            };

            try
            {
                await context.StacGenerations.Add(stacGeneration);
                context.Commit();
                return stacGeneration;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                context.Rollback();
            }

            return null;
        }
    }
}
