﻿using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Application.Processors;
using SpiTech.MppaService.Application.Queries.GetTransactionById;
using SpiTech.MppaService.Application.Queries.GetTransactionByUmtiMId;
using SpiTech.MppaService.Application.Services;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Models.Commanders.MobileStacCapture;
using SpiTech.MppaService.Domain.Models.Commanders.MobileTransactionData;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.TransactionDataRequests
{
    public class MppaTransactionDataRequestHandler : IRequestHandler<MppaTransactionDataRequestCommand, bool>
    {
        private readonly ILogger<MppaTransactionDataRequestHandler> logger;
        private readonly IMediator mediator;
        private readonly HostConfig hostConfig;
        private readonly IMppaMessageProcessor mppaMessageProcessor;
        private readonly IPosFakeTestService posFakeTestService;

        public MppaTransactionDataRequestHandler(
                                    ILogger<MppaTransactionDataRequestHandler> logger,
                                    IMediator mediator,
                                    HostConfig hostConfig,
                                    IMppaMessageProcessor mppaMessageProcessor,
                                    IPosFakeTestService posFakeTestService)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.hostConfig = hostConfig;
            this.mppaMessageProcessor = mppaMessageProcessor;
            this.posFakeTestService = posFakeTestService;
        }

        public async Task<bool> Handle(MppaTransactionDataRequestCommand command, CancellationToken cancellationToken)
        {
            try
            {
                MobileTransactionDataMppaRequest request = CreateDefaultTransactionDataMppaRequest(command.StacCaptureMppaResponse);
                Domain.Entities.Transaction transaction = await mediator.Send(new GetTransactionByUmtiMIdQuery
                { 
                    UMTI = command.StacCaptureMppaResponse.MobileTxnInfo.UMTI,
                    MerchantId = command.StacCaptureMppaResponse.MobileTxnInfo.MerchantId,
                });


                if (transaction == null)
                {
                    throw new ValidationException(new ValidationFailure("UMTI", $"MppaTransactionDataRequest-UMTI-{command.StacCaptureMppaResponse.MobileTxnInfo.UMTI}-{command.StacCaptureMppaResponse.MobileTxnInfo.MerchantId} is invalid"));
                }

                string requestMsg = Serializer.Serialize<MobileTransactionDataMppaRequest>(request);

                ApplicationCore.Domain.Models.ResponseModel result = null;

                //For Testing POS Begin
                if (hostConfig.IsPosTestingEnabled)
                {
                    await posFakeTestService.GenerateFakeCommanderTransactionResponse(transaction);
                    result = new ApplicationCore.Domain.Models.ResponseModel { Message = "", Success = true };
                }
                else
                {
                    result = await mppaMessageProcessor.Process(transaction.TransactionId,
                                                                requestMsg,
                                                                request,
                                                                true,
                                                                RequestType.MobileTransactionData,
                                                                request.MobileTxnInfo,
                                                                true,
                                                                null);
                }
                //For Testing POS END

                return await Task.FromResult(result.Success);
            }
            catch (Exception ex)
            {
                logger.Error(ex, command);
            }

            return await Task.FromResult(false);
        }

        private MobileTransactionDataMppaRequest CreateDefaultTransactionDataMppaRequest(StacCaptureMppaResponse response)
        {
            MobileTransactionDataMppaRequest mobileTransactionDataMppaRequest = new()
            {
                MobileTxnInfo = new Domain.Models.Commanders.MobileTransactionData.MobileTxnInfoRequest
                {
                    MerchantId = response.MobileTxnInfo.MerchantId,
                    SiteId = response.MobileTxnInfo.SiteId,
                    UMTI = response.MobileTxnInfo.UMTI,
                    POSTransNumber = response.MobileTxnInfo.POSTransNumber,
                    WorkstationId = response.MobileTxnInfo.WorkstationId,
                    HostMPPAIdentifier = hostConfig.HostMPPAIdentifier,
                    TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                },
                MobileTransactionDataRequest = new Domain.Models.Commanders.MobileTransactionData.MobileTransactionDataRequest()
            };

            return mobileTransactionDataMppaRequest;
        }
    }
}
