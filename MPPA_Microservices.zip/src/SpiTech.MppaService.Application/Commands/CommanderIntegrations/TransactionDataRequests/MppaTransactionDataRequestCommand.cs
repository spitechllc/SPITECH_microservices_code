﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.MobileStacCapture;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.TransactionDataRequests
{
    public class MppaTransactionDataRequestCommand : IRequest<bool>
    {
        public long TransactionId { get; set; }
        public StacCaptureMppaResponse StacCaptureMppaResponse { get; set; }
    }
}
