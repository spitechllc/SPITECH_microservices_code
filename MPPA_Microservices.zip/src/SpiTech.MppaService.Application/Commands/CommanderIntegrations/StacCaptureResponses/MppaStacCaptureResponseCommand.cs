﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.MobileStacCapture;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.StacCaptureResponses
{
    public class MppaStacCaptureResponseCommand : IRequest<bool>
    {
        public long? TransactionId { get; set; }
        public StacCaptureCommanderRequest StacCaptureRequest { get; set; }
    }
}
