﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.TransactionDataRequests;
using SpiTech.MppaService.Application.Processors;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Models.Commanders;
using SpiTech.MppaService.Domain.Models.Commanders.MobileStacCapture;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.StacCaptureResponses
{
    public class MppaStacCaptureResponseHandler : IRequestHandler<MppaStacCaptureResponseCommand, bool>
    {
        private readonly ILogger<MppaStacCaptureResponseHandler> logger;
        private readonly IMediator mediator;
        private readonly HostConfig hostConfig;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IMppaMessageProcessor mppaMessageProcessor;

        public MppaStacCaptureResponseHandler(
                                    ILogger<MppaStacCaptureResponseHandler> logger,
                                    IMediator mediator,
                                    HostConfig hostConfig,
                                    IEventDispatcher eventDispatcher,
                                    IMppaMessageProcessor mppaMessageProcessor)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.hostConfig = hostConfig;
            this.eventDispatcher = eventDispatcher;
            this.mppaMessageProcessor = mppaMessageProcessor;
        }

        public async Task<bool> Handle(MppaStacCaptureResponseCommand command, CancellationToken cancellationToken)
        {
            bool isError = false;
            DateTime startTime = DateTime.UtcNow;

            try
            {
                StacCaptureMppaResponse stacCaptureMppaResponse = CreateDefaultStacCaptureMppaResponse(command);

                string responseMsg = Serializer.Serialize<StacCaptureMppaResponse>(stacCaptureMppaResponse);

                ApplicationCore.Domain.Models.ResponseModel result = null;


                //For Testing POS Begin
                if (hostConfig.IsPosTestingEnabled)
                {
                    result = new ApplicationCore.Domain.Models.ResponseModel { Message = "", Success = true };
                }
                else
                {
                    result = await mppaMessageProcessor.Process(command.TransactionId,
                                                               responseMsg,
                                                               stacCaptureMppaResponse,
                                                               false,
                                                               RequestType.MobileStacCapture,
                                                               stacCaptureMppaResponse.MobileTxnInfo,
                                                               true,
                                                               stacCaptureMppaResponse.MobileSTACCaptureResponse.Response);
                }
                //For Testing POS END
                

                if (command.TransactionId.HasValue)
                {
                    await mediator.Send(new MppaTransactionDataRequestCommand
                    {
                        TransactionId = command.TransactionId.Value,
                        StacCaptureMppaResponse = stacCaptureMppaResponse
                    });
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex, command);
            }

            return await Task.FromResult(!isError);
        }

        private StacCaptureMppaResponse CreateDefaultStacCaptureMppaResponse(MppaStacCaptureResponseCommand command)
        {
            bool isValidStac = command.TransactionId.HasValue;

            StacCaptureMppaResponse stacCaptureMppaResponse = new()
            {
                MobileTxnInfo = new MobileTxnInfoResponse
                {
                    MerchantId = command.StacCaptureRequest.MobileTxnInfo.MerchantId,
                    SiteId = command.StacCaptureRequest.MobileTxnInfo.SiteId,
                    UMTI = command.StacCaptureRequest.MobileTxnInfo.UMTI,
                    SiteMPPAIdentifier = command.StacCaptureRequest.MobileTxnInfo.SiteMPPAIdentifier,
                    HostMPPAIdentifier = hostConfig.HostMPPAIdentifier,
                    POSTransNumber = command.StacCaptureRequest.MobileTxnInfo.POSTransNumber,
                    WorkstationId = command.StacCaptureRequest.MobileTxnInfo.WorkstationId,
                    TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                },

                MobileSTACCaptureResponse = new MobileResponse
                {
                    Response = new Response
                    {
                        MessageCode = isValidStac ? Constants.SuccessMessageCode : Constants.FailMessageCode,
                        OverallResult = isValidStac ? Constants.SuccessOverallResult : Constants.FailOverallResult,
                        ResponseCode = isValidStac ? Constants.SuccessResponseCode : Constants.StacInvalidFailResponseCode
                    }
                }
            };
            return stacCaptureMppaResponse;
        }
    }
}
