﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.MobileTransactionData;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.TransactionDataResponses
{
    public class CommanderTransactionDataResponseCommand : IRequest<bool>
    {
        public MobileTransactionDataCommanderResponse TransactionDataResponse { get; set; }
    }
}
