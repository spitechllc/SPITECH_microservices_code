﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.MppaService.Application.Commands.CreateSaleItems;
using SpiTech.MppaService.Application.Commands.MobileIntegrations.PosTransactionDataProcessResponses;
using SpiTech.MppaService.Application.Commands.UpdateTransaction;
using SpiTech.MppaService.Application.Queries.GetTransactionByUmtiMId;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models.Commanders.MobileTransactionData;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.TransactionDataResponses
{
    public class CommanderTransactionDataResponseHandler : IRequestHandler<CommanderTransactionDataResponseCommand, bool>
    {
        private readonly ILogger<CommanderTransactionDataResponseHandler> logger;
        private readonly IMediator mediator;
        private readonly HostConfig hostConfig;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IMapper mapper;

        public CommanderTransactionDataResponseHandler(
                                    ILogger<CommanderTransactionDataResponseHandler> logger,
                                    IMediator mediator,
                                    HostConfig hostConfig,
                                    IEventDispatcher eventDispatcher,
                                    IMapper mapper)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.hostConfig = hostConfig;
            this.eventDispatcher = eventDispatcher;
            this.mapper = mapper;
        }

        public async Task<bool> Handle(CommanderTransactionDataResponseCommand command, CancellationToken cancellationToken)
        {
            bool isSuccess = false;
            string error = "";

            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);

                var transaction = await mediator.Send(new GetTransactionByUmtiMIdQuery
                {
                    UMTI = command.TransactionDataResponse.MobileTxnInfo.UMTI,
                    MerchantId = command.TransactionDataResponse.MobileTxnInfo.MerchantId
                });

                if (transaction == null)
                {
                    throw new ValidationException(new ValidationFailure("UMTI", $"CommanderTransactionDataResponse-UMTI-{command.TransactionDataResponse.MobileTxnInfo.UMTI}-{command.TransactionDataResponse.MobileTxnInfo.MerchantId} is invalid"));
                }

                if (command.TransactionDataResponse.MobileTransactionDataResponse.PaymentInfo != null)
                {
                    transaction.PreauthAmount = command.TransactionDataResponse.MobileTransactionDataResponse.PaymentInfo.PreAuthAmount;

                    await mediator.Send(new UpdateTransactionCommand
                    {
                        Transaction = transaction
                    });
                }
                else
                {
                    command.TransactionDataResponse.MobileTransactionDataResponse.PaymentInfo = new PaymentInfo
                    {
                        FinalAmount = 0,
                        PreAuthAmount = transaction.PreauthAmount
                    };
                }

                string responseMsg = Serializer.Serialize<MobileTransactionDataCommanderResponse>(command.TransactionDataResponse);
                logger.Info(responseMsg);

                isSuccess = command.TransactionDataResponse.MobileTransactionDataResponse.Response.ResponseCode == Constants.SuccessResponseCode;
                error = isSuccess ? string.Empty :
                                    $"{command.TransactionDataResponse.MobileTransactionDataResponse.Response.ResponseCode}-{command.TransactionDataResponse.MobileTransactionDataResponse.Response.OverallResult}-{command.TransactionDataResponse.MobileTransactionDataResponse.Response.MessageCode}";

                isSuccess = await SaveSaleItems(transaction, command.TransactionDataResponse);

                transaction.POSTransNumber = command.TransactionDataResponse.MobileTxnInfo.POSTransNumber;

                await mediator.Send(new UpdateTransactionCommand
                {
                    Transaction = transaction
                });

                if (!isSuccess)
                {
                    transaction.StatusId = (int)Status.Fail;
                    transaction.MppaErrorMessage = error;
                }

                await eventDispatcher.Dispatch(new TransactionUpdateEvent
                {
                    RequestTypeId = (int)EventBus.DomainEvents.Enums.RequestType.MobileTransactionData,
                    Transaction = mapper.Map<EventBus.DomainEvents.Models.Mppa.Transaction>(transaction),
                });

                //Send PumpProcessStatus to Mobile
                await mediator.Send(new MobilePosTransactionDataProcessResponseCommand
                {
                    TransactionId = transaction.TransactionId,
                    SiteId = command.TransactionDataResponse.MobileTxnInfo.SiteId,
                    POSTransNumber = command.TransactionDataResponse.MobileTxnInfo.POSTransNumber,
                    WorkstationId = command.TransactionDataResponse.MobileTxnInfo.WorkstationId,
                    UMTI = command.TransactionDataResponse.MobileTxnInfo.UMTI,
                    UserId = transaction.UserId,
                    Status = isSuccess ? ProcessConstants.MobileTransactionDataSuccess : ProcessConstants.MobileTransactionDataError,
                    ProcessName = ProcessConstants.MobileTransactionDataProcessName,
                    Success = isSuccess,
                    Erorr = transaction.MppaErrorMessage,
                    FinalAmount = 0,
                    PreAuthAmount = command.TransactionDataResponse.MobileTransactionDataResponse?.PaymentInfo?.PreAuthAmount ?? 0,
                    ItemsPurchased = command.TransactionDataResponse.MobileTransactionDataResponse.ItemsPurchased
                });
            }
            catch (Exception ex)
            {
                logger.Error(ex, command);
            }

            logger.TraceExitMethod(nameof(Handle), isSuccess);
            return await Task.FromResult(isSuccess);
        }

        private async Task<bool> SaveSaleItems(Transaction transaction, MobileTransactionDataCommanderResponse transactionDataResponse)
        {
            try
            {
                return await mediator.Send(new CreateSaleItemsCommand
                {
                    TransactionId = transaction.TransactionId,
                    SaleItems = transactionDataResponse.MobileTransactionDataResponse.ItemsPurchased.SaleItems
                });
            }
            catch (Exception ex)
            {
                logger.Error(ex, transaction);
                transaction.StatusId = (int)Status.Fail;
                transaction.MppaErrorMessage = ex.Message;
                return false;
            }
        }
    }
}
