﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.MobilePumpReserves;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.PumpReserveResponses
{
    public class CommanderPumpReserveResponseCommand : IRequest<bool>
    {
        public PumpReserveCommanderResponse PumpReserveCommanderResponse { get; set; }
    }
}
