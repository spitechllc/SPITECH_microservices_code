﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.AuthRequests;
using SpiTech.MppaService.Application.Commands.MobileIntegrations.PumpReserveResponses;
using SpiTech.MppaService.Application.Commands.UpdateTransaction;
using SpiTech.MppaService.Application.Queries.GetTransactionById;
using SpiTech.MppaService.Application.Queries.GetTransactionByUmtiMId;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Models.Commanders.MobilePumpReserves;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CommanderIntegrations.PumpReserveResponses
{
    public class CommanderPumpReserveResponseHandler : IRequestHandler<CommanderPumpReserveResponseCommand, bool>
    {
        private readonly ILogger<CommanderPumpReserveResponseHandler> logger;
        private readonly IMediator mediator;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IMapper mapper;

        public CommanderPumpReserveResponseHandler(
                                    ILogger<CommanderPumpReserveResponseHandler> logger,
                                    IMediator mediator,
                                    IEventDispatcher eventDispatcher,
                                    IMapper mapper)
        {
            this.logger = logger;
            this.mediator = mediator;
            this.eventDispatcher = eventDispatcher;
            this.mapper = mapper;
        }

        public async Task<bool> Handle(CommanderPumpReserveResponseCommand command, CancellationToken cancellationToken)
        {
            bool isSuccess = false;
            string error = string.Empty;
            Domain.Entities.Transaction transaction = null;

            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);

                transaction = await mediator.Send(new GetTransactionByUmtiMIdQuery
                { 
                    UMTI = command.PumpReserveCommanderResponse.MobileTxnInfo.UMTI ,
                    MerchantId = command.PumpReserveCommanderResponse.MobileTxnInfo.MerchantId
                });

                if (transaction == null)
                {
                    throw new ValidationException(new ValidationFailure("UMTI", $"CommanderPumpReserveResponse-UMTI-{command.PumpReserveCommanderResponse.MobileTxnInfo.UMTI}-{command.PumpReserveCommanderResponse.MobileTxnInfo.MerchantId} is invalid"));
                }

                string message = Serializer.Serialize<PumpReserveCommanderResponse>(command.PumpReserveCommanderResponse);

                isSuccess = command.PumpReserveCommanderResponse.MobilePumpReserveResponse.Response.ResponseCode == Constants.SuccessResponseCode;

                error = isSuccess ? "" : $"{command.PumpReserveCommanderResponse.MobilePumpReserveResponse.Response.ResponseCode}-{command.PumpReserveCommanderResponse.MobilePumpReserveResponse.Response.OverallResult}-{command.PumpReserveCommanderResponse.MobilePumpReserveResponse.Response.MessageCode}";

                transaction.MerchantId = command.PumpReserveCommanderResponse.MobileTxnInfo.MerchantId;
                transaction.SiteMPPAIdentifier = command.PumpReserveCommanderResponse.MobileTxnInfo.SiteMPPAIdentifier;
                transaction.POSTransNumber = command.PumpReserveCommanderResponse.MobileTxnInfo.POSTransNumber;
                transaction.CommanderTimeDateStamp = command.PumpReserveCommanderResponse.MobileTxnInfo.TimeDateStamp;

                if (!isSuccess)
                {
                    transaction.StatusId = isSuccess ? (int)Status.Success : (int)Status.Fail;
                    transaction.MppaErrorMessage = error;
                }

                await mediator.Send(new UpdateTransactionCommand
                {
                    Transaction = transaction
                });

                await eventDispatcher.Dispatch(new TransactionUpdateEvent
                {
                    RequestTypeId = (int)RequestType.MobilePumpReserve,
                    Transaction = mapper.Map<EventBus.DomainEvents.Models.Mppa.Transaction>(transaction),
                });

                await SendStatusToMobile(command, isSuccess, error, transaction);

                if (isSuccess)
                {
                    await mediator.Send(new MppaAuthRequestCommand
                    {
                        PumpReserveCommanderResponse = command.PumpReserveCommanderResponse
                    });
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex, transaction, command);
                if (transaction != null)
                {
                    transaction.MppaErrorMessage = ex.Message;
                    await mediator.Send(new UpdateTransactionCommand
                    {
                        Transaction = transaction
                    });
                }
            }

            return await Task.FromResult(isSuccess);
        }

        private async Task SendStatusToMobile(CommanderPumpReserveResponseCommand command, bool isSuccess, string error, Domain.Entities.Transaction transaction)
        {
            await mediator.Send(new MobilePumpReserveResponseCommand
            {
                TransactionId = transaction.TransactionId,
                FuelingPositionId = command.PumpReserveCommanderResponse.MobileTxnInfo.FuelingPositionId,
                SiteId = command.PumpReserveCommanderResponse.MobileTxnInfo.SiteId,
                UMTI = command.PumpReserveCommanderResponse.MobileTxnInfo.UMTI,
                UserId = transaction.UserId,
                Status = isSuccess ? ProcessConstants.ReserveSuccess : ProcessConstants.ReserveError,
                Success = isSuccess,
                Erorr = error
            });
        }
    }
}
