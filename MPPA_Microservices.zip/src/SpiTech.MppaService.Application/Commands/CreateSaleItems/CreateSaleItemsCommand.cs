﻿using MediatR;
using SpiTech.MppaService.Domain.Models.Commanders.MobileTransactionData;

namespace SpiTech.MppaService.Application.Commands.CreateSaleItems
{
    public class CreateSaleItemsCommand : IRequest<bool>
    {
        public long TransactionId { get; set; }
        public SaleItem[] SaleItems { get; set; }
    }
}
