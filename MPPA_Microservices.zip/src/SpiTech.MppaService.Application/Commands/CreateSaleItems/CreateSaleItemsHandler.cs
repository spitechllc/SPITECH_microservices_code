﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CreateSaleItems
{
    public class CreateSaleItemsHandler : IRequestHandler<CreateSaleItemsCommand, bool>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateSaleItemsHandler> _logger;
        private readonly IMapper _mapper;

        public CreateSaleItemsHandler(IUnitOfWork context,
                                             ILogger<CreateSaleItemsHandler> logger,
                                             IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<bool> Handle(CreateSaleItemsCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            bool result = false;

            if (command.SaleItems != null)
            {
                try
                {
                    foreach (Domain.Models.Commanders.MobileTransactionData.SaleItem saleItem in command.SaleItems)
                    {
                        int saleItemId = await _context.SaleItems.Add(new Domain.Entities.SaleItem()
                        {
                            TransactionId = command.TransactionId,
                            ItemId = saleItem.ItemId,
                            EvaluateOnly = saleItem.EvaluateOnly,
                            PriceChangeEligible = saleItem.PriceChangeEligible,
                            POSCode = saleItem.POSCode,
                            POSCodeModifier = saleItem.POSCodeModifier,
                            ProductCode = saleItem.ProductCode,
                            OriginalAmount = saleItem.OriginalAmount.Amount,
                            OriginalAmountUnitPrice = saleItem.OriginalAmount.UnitPrice,
                            AdjustedAmount = saleItem.AdjustedAmount.Amount,
                            AdjustedAmountUnitPrice = saleItem.AdjustedAmount.UnitPrice,
                            UnitMeasure = saleItem.UnitMeasure,
                            Quantity = saleItem.Quantity,
                            AdditionalProductInfo = saleItem.AdditionalProductInfo,
                            Description = saleItem.Description,
                            CreatedOn = DateTime.UtcNow,
                            IsActive = true
                        });
                    }
                    _context.Commit();
                    result = true;
                }
                catch (Exception ex)
                {
                    _context.Rollback();
                    _logger.Error(ex, command);
                    throw;
                }
            }

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
