﻿using FluentValidation;

namespace SpiTech.MppaService.Application.Commands.UpdateTransaction
{
    public class UpdateTransactionValidator : AbstractValidator<UpdateTransactionCommand>
    {
        public UpdateTransactionValidator()
        {
            RuleFor(x => x.Transaction).NotNull().WithMessage("Transaction is required");
        }
    }
}
