﻿using MediatR;
using SpiTech.MppaService.Domain.Entities;

namespace SpiTech.MppaService.Application.Commands.UpdateTransaction
{
    public class UpdateTransactionCommand : IRequest<bool>
    {
        public Transaction Transaction { get; set; }
    }
}
