﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.UpdateTransaction
{
    public class UpdateTransactionHandler : IRequestHandler<UpdateTransactionCommand, bool>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateTransactionHandler> _logger;
        private readonly IMapper _mapper;
        public UpdateTransactionHandler(IUnitOfWork context,
                                   ILogger<UpdateTransactionHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<bool> Handle(UpdateTransactionCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            bool status = false;
            await _context.Execute(async () =>
            {
                status = await _context.Transactions.Update(command.Transaction);
            });

            _logger.TraceExitMethod(nameof(Handle), status);
            return status;
        }
    }
}
