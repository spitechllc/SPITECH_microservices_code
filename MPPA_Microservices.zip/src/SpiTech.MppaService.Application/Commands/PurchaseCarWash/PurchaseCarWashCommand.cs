﻿using MediatR;

namespace SpiTech.MppaService.Application.Commands.PurchaseCarWash
{
    public class PurchaseCarWashCommand : IRequest<ApplicationCore.Domain.Models.ResponseModel>
    {
        public decimal Amount { get; set; }
        public string SiteId { get; set; }
        public int UserId { get; set; }
        public string Description { get; set; }
        public int UserPaymentMethodId { get; set; }
        public string ConsumerIP { get; set; }
        public int CarWashId { get; set; }
        public string TransactionInfo { get; set; }
    }
}
