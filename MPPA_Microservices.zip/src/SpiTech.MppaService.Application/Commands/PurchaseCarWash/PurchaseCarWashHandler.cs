﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.MppaService.Application.Commands.CreateTransaction;
using SpiTech.MppaService.Application.Commands.UpdateGetSite;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain;
using SpiTech.Service.Clients.Payments;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.PurchaseCarWash
{
    public class PurchaseCarWashHandler : IRequestHandler<PurchaseCarWashCommand, ApplicationCore.Domain.Models.ResponseModel>
    {
        private readonly IPaymentServiceClient _paymentApiClient;
        private readonly IUnitOfWork _context;
        private readonly ILogger<PurchaseCarWashHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IMediator _mediator;
        private readonly IEventDispatcher eventDispatcher;
        private readonly HostConfig hostConfig;
        private readonly IStoreServiceClient storeApiClient;

        public PurchaseCarWashHandler(IUnitOfWork context,
                                   ILogger<PurchaseCarWashHandler> logger,
                                   IMapper mapper,
                                   IPaymentServiceClient paymentApiClient,
                                   IMediator mediator,
                                   IEventDispatcher eventDispatcher,
                                   HostConfig hostConfig,
                                   IStoreServiceClient storeApiClient)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _paymentApiClient = paymentApiClient;
            _mediator = mediator;
            this.eventDispatcher = eventDispatcher;
            this.hostConfig = hostConfig;
            this.storeApiClient = storeApiClient;
        }
        public async Task<ApplicationCore.Domain.Models.ResponseModel> Handle(PurchaseCarWashCommand command, CancellationToken cancellationToken)
        {
            bool output = false;
            _logger.TraceEnterMethod(nameof(Handle), command);
            Domain.Entities.Site sitedata = await _mediator.Send(new UpdateGetSiteCommand { SiteId = command.SiteId });

            Domain.Entities.Transaction transaction = null;
            try
            {
                Service.Clients.Stores.StoreInfoModel storeInfoModel = null;

                if (!string.IsNullOrWhiteSpace(command?.SiteId))
                {
                    storeInfoModel = await storeApiClient.GetStoreInfoAsync(null, command.SiteId).ConfigureAwait(false);
                }

                PaymentResponseModelResponseModel result = await _paymentApiClient.PaymentAsync(new PaymentCommand
                {
                    CardAmount = (double)command.Amount,
                    ConsumerIP = command.ConsumerIP,
                    Description = command.Description,
                    TransactionId = transaction.TransactionId,
                    UserId = command.UserId,
                    IsPaymentRequired = false,
                    PaymentType = Service.Clients.Payments.PaymentType.VehicleWash,
                    SiteId = command.SiteId,
                    StoreId = sitedata?.StoreId,
                    StoreName = sitedata?.StoreName,
                    UserPaymentMethodId = command.UserPaymentMethodId,
                });

                transaction = new Domain.Entities.Transaction()
                {
                    StoreId = sitedata?.StoreId ?? 0,
                    StoreName = sitedata?.StoreName,
                    FinalAmount = command.Amount,
                    PreauthConfirmationNo = result.Data.PreAuthConfirmationNo,
                    PaymentMethodId = result.Data.PaymentMethodId,
                    UserPaymentMethodId = command.UserPaymentMethodId,
                    MerchantId = null,
                    DeviceToken = null,
                    AppType = null,
                    UserId = command.UserId,
                    FuelingPositionId = 0,
                    HostMPPAIdentifier = null,
                    SiteMPPAIdentifier = null,
                    POSTransNumber = null,
                    SettlementPeriodId = null,
                    MppaErrorMessage = null,
                    SiteId = command.SiteId,
                    ReceiptNo = "", // To Do
                    TransactionTypeId = (int)TransactionType.CarWash,
                    PaymentUniqueIdentityfier = command.CarWashId.ToString(),
                    TransactionInfo = command.TransactionInfo,
                    TransactionDate = DateTime.UtcNow,
                    UMTI = UmtiGenerator.Generate(hostConfig.UtmiPrefix),
                    WalletAmount = (decimal)result.Data.WalletAmount,
                    CardAmount = (decimal)result.Data.CardAmount,
                    IsPaymentSuccess = result.Success,
                    StatusId = result.Success ? (int)Status.Success : (int)Status.Fail,
                    DisableBilling = storeInfoModel?.DisableBilling ?? false,
                    DisableEod = storeInfoModel?.DisableEod ?? false,
                };

                transaction.TransactionId = await _mediator.Send(new CreateTransactionCommand
                {
                    Transaction = transaction
                });

                if (transaction.StatusId == (int)Status.Fail)
                {
                    throw new ValidationException(new ValidationFailure("ProcessPayment", $"ProcessPayment return false"));
                }

                _context.Commit();
            }
            catch (Exception ex)
            {
                _context.Rollback();
                _logger.Error(ex, command);
                throw;
            }

            TransactionEvent transactionevent = _mapper.Map<TransactionEvent>(transaction);
            await eventDispatcher.Dispatch(transactionevent);

            return new ApplicationCore.Domain.Models.ResponseModel { Success = output, Message = output ? "Success" : "Fail" };
        }
    }
}
