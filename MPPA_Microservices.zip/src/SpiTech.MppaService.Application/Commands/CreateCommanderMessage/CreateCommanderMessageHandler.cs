﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.CreateCommanderMessage
{
    public class CreateCommanderMessageHandler : IRequestHandler<CreateCommanderMessageCommand, long>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateCommanderMessageHandler> _logger;
        private readonly IMapper _mapper;
        public CreateCommanderMessageHandler(IUnitOfWork context,
                                   ILogger<CreateCommanderMessageHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<long> Handle(CreateCommanderMessageCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            int requestid = 0;

            await _context.Execute(async () =>
            {
                requestid = await _context.CommanderMessages.Add(command.CommanderMessage);
            });

            _logger.TraceExitMethod(nameof(Handle), requestid);
            return requestid;
        }
    }
}
