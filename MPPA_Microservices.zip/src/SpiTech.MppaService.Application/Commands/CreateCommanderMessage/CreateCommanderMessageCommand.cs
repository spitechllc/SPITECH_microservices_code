﻿using MediatR;
using SpiTech.MppaService.Domain.Entities;

namespace SpiTech.MppaService.Application.Commands.CreateCommanderMessage
{
    public class CreateCommanderMessageCommand : IRequest<long>
    {
        public CommanderMessage CommanderMessage { get; set; }
    }
}
