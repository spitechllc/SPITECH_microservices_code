﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Commands.UpdatePOS
{
    public class UpdatePosHandler : IRequestHandler<UpdatePosCommand, bool>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdatePosHandler> _logger;
        private readonly IMapper _mapper;

        public UpdatePosHandler(IUnitOfWork context,
                                   ILogger<UpdatePosHandler> logger,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<bool> Handle(UpdatePosCommand request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            bool status = false;

            await _context.Execute(async () =>
            {
                status = await _context.PoseS.Update(new Domain.Entities.POS()
                {
                    PosId = request.PosId,
                    StationNumber = request.StationNumber,
                    StationIPAddress = request.StationIPAddress,
                    StoreId = request.StoreId,
                    StationSystemId = request.StationSystemId,
                    QRCode = request.QRCode,
                    BarCode = request.BarCode,
                    NetworkType = request.NetworkType,
                    Port = request.Port,
                    IsActive = request.IsActive
                });
            });

            _logger.TraceExitMethod(nameof(Handle), status);
            return await Task.FromResult(status);
        }
    }
}
