﻿using FluentValidation;

namespace SpiTech.MppaService.Application.Commands.UpdatePOS
{
    public class UpdatePosValidator : AbstractValidator<UpdatePosCommand>
    {
        public UpdatePosValidator()
        {
            RuleFor(x => x.PosId).GreaterThan(0).WithMessage("PosId must be greater than 0");
            RuleFor(x => x.StoreId).GreaterThan(0).WithMessage("StoreId must be greater than 0");
            RuleFor(x => x.StationNumber).NotNull().WithMessage("Station Number is required")
                                          .MaximumLength(50).WithMessage("Station Number must be upto 50 characters only");
            RuleFor(x => x.StationSystemId).NotNull().WithMessage("StationSystemId is required")
                                            .MaximumLength(50).WithMessage("StationSystemId must be upto 50 characters only");
            RuleFor(x => x.StationIPAddress).NotNull().WithMessage("Station IPAddress is required")
                                            .MaximumLength(16).WithMessage("Station IPAddress must be upto 16 characters only");

            RuleFor(s => s.QRCode).MaximumLength(250);
            RuleFor(s => s.BarCode).MaximumLength(250);
            RuleFor(s => s.NetworkType).MaximumLength(50);
            RuleFor(s => s.Port).MaximumLength(20);
        }
    }
}
