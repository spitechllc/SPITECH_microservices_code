﻿using SpiTech.EventBus.DomainEvents.Enums;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Handlers
{
    internal interface ICommanderComandHandler
    {
        bool IsRequestMessage { get; }
        RequestType RequestType { get; }
        string HandleType { get; }
        Task Execute(string message);
    }
}
