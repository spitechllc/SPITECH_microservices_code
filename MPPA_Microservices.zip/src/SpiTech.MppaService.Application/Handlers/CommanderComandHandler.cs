﻿using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Application.Commands.CreateCommanderMessage;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Models.Commanders;
using System;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Handlers
{
    internal abstract class CommanderComandHandler : ICommanderComandHandler
    {
        protected readonly IMediator mediator;
        private readonly ILogger<CommanderComandHandler> logger;

        public CommanderComandHandler(IMediator mediator, ILogger<CommanderComandHandler> logger)
        {
            this.mediator = mediator;
            this.logger = logger;
        }

        public abstract string HandleType { get; }
        public abstract bool IsRequestMessage { get; }
        public abstract RequestType RequestType { get; }

        public virtual Task Execute(string message)
        {
            return Task.CompletedTask;
        }

        protected async Task<bool> SaveMessage(MobileTxnInfoBase mobileTxnInfoBase, Response response, string message, object messageObject)
        {
            string jsonData = "";

            try
            {
                //XmlDocument doc = new XmlDocument();
                //doc.LoadXml(message.Substring(message.IndexOf("<NAXMLMobile")));
                //doc.LoadXml(message);
                //jsonData = JsonConvert.SerializeXmlNode(doc);
                jsonData = JsonConvert.SerializeObject(messageObject);
            }
            catch (Exception ex)
            {
                logger.Error(ex, messageObject);
            }

            try
            {
                await mediator.Send(new CreateCommanderMessageCommand
                {
                    CommanderMessage = new Domain.Entities.CommanderMessage
                    {
                        CommanderMessageId = Guid.NewGuid(),
                        XmlMessage = message,
                        JsonMessage = jsonData,
                        MerchantId = mobileTxnInfoBase.MerchantId,
                        UMTI = mobileTxnInfoBase.UMTI,
                        SiteId = mobileTxnInfoBase.SiteId,
                        StatusId = IsRequestMessage ? (int)Status.Success : (response.ResponseCode == Constants.SuccessResponseCode ? (int)Status.Success : (int)Status.Fail),
                        RequestTypeId = (int)RequestType,
                        ResponseCode = response?.ResponseCode,
                        OverallResult = response?.OverallResult,
                        MessageCode = response?.MessageCode,
                        IsRequest = IsRequestMessage,
                        IsActive = true,
                        CreatedOn = DateTime.UtcNow,
                    }
                });
            }
            catch (Exception ex)
            {
                logger.Error(ex, mobileTxnInfoBase, messageObject, response);
                return false;
            }
            return true;
        }
    }
}
