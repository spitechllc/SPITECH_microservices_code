﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.PumpReserveResponses;
using SpiTech.MppaService.Domain.Models.Commanders.MobilePumpReserves;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Handlers.CommanderCommandHandlers
{
    internal class MobilePumpReserveResponseHandler : CommanderComandHandler
    {
        public MobilePumpReserveResponseHandler(IMediator mediator, ILogger<CommanderComandHandler> logger) : base(mediator, logger)
        {
        }

        public override string HandleType => "MobilePumpReserveResponse";

        public override bool IsRequestMessage => false;

        public override RequestType RequestType => RequestType.MobilePumpReserve;

        public override async Task Execute(string message)
        {
            PumpReserveCommanderResponse pumpReserveResponse = Serializer.DeSerialize<PumpReserveCommanderResponse>(message);

            await SaveMessage(pumpReserveResponse.MobileTxnInfo, pumpReserveResponse.MobilePumpReserveResponse?.Response, message, pumpReserveResponse);

            CommanderPumpReserveResponseCommand reserveCommanderResponseCommand = new()
            {
                PumpReserveCommanderResponse = pumpReserveResponse
            };

            await mediator.Send(reserveCommanderResponseCommand);
        }
    }
}
