﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.SiteData;
using SpiTech.MppaService.Domain.Models.Commanders.MobileSiteData;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Handlers.CommanderCommandHandlers
{
    internal class MobileSiteDataRequestHandler : CommanderComandHandler
    {
        public MobileSiteDataRequestHandler(IMediator mediator, ILogger<CommanderComandHandler> logger) : base(mediator, logger)
        {
        }

        public override string HandleType => "MobileSiteDataRequest";

        public override bool IsRequestMessage => true;

        public override RequestType RequestType => RequestType.MobileSiteData;

        public override async Task Execute(string message)
        {
            SiteDataCommanderRequest siteDataRequest = Serializer.DeSerialize<SiteDataCommanderRequest>(message);
            await SaveMessage(siteDataRequest.MobileTxnInfo, null, message, siteDataRequest);

            CommanderSiteDataCommand siteDataCommanderCommand = new()
            {
                SiteDataRequest = siteDataRequest
            };

            await mediator.Send(siteDataCommanderCommand);
        }
    }
}
