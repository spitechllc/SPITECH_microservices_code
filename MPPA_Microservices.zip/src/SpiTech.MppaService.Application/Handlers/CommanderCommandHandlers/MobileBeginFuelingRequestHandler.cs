﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.BeginFuelingRequests;
using SpiTech.MppaService.Domain.Models.Commanders.BeginFueling;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Handlers.CommanderCommandHandlers
{
    internal class MobileBeginFuelingRequestHandler : CommanderComandHandler
    {
        public MobileBeginFuelingRequestHandler(IMediator mediator, ILogger<CommanderComandHandler> logger) : base(mediator, logger)
        {
        }

        public override string HandleType => "MobileBeginFuelingRequest";

        public override bool IsRequestMessage => true;

        public override RequestType RequestType => RequestType.BeginFueling;

        public override async Task Execute(string message)
        {
            BeginFuelingCommanderRequest beginFuelingRequest = Serializer.DeSerialize<BeginFuelingCommanderRequest>(message);

            await SaveMessage(beginFuelingRequest.MobileTxnInfo, null, message, beginFuelingRequest);

            CommanderBeginFuelingRequestCommand beginFuelingCommanderRequestCommand = new()
            {
                BeginFuelingRequest = beginFuelingRequest
            };

            await mediator.Send(beginFuelingCommanderRequestCommand);
        }
    }
}
