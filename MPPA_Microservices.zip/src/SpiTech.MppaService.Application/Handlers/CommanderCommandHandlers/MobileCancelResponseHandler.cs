﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.PumpReserveCancelResponses;
using SpiTech.MppaService.Domain.Models.Commanders.MobilePumpReserveCancel;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Handlers.CommanderCommandHandlers
{
    internal class MobileCancelResponseHandler : CommanderComandHandler
    {
        public MobileCancelResponseHandler(IMediator mediator, ILogger<CommanderComandHandler> logger) : base(mediator, logger)
        {
        }

        public override string HandleType => "MobileCancelResponse";

        public override bool IsRequestMessage => false;

        public override RequestType RequestType => RequestType.MobileCancel;

        public override async Task Execute(string message)
        {
            PumpReserveCancelCommanderResponse pumpReserveCancelResponse = Serializer.DeSerialize<PumpReserveCancelCommanderResponse>(message);
            await SaveMessage(pumpReserveCancelResponse.MobileTxnInfo, pumpReserveCancelResponse.MobileCancelResponse?.Response, message, pumpReserveCancelResponse);

            CommanderPumpReserveCancelResponseCommand command = new()
            {
                PumpReserveCancelCommanderResponse = pumpReserveCancelResponse
            };

            await mediator.Send(command);
        }
    }
}
