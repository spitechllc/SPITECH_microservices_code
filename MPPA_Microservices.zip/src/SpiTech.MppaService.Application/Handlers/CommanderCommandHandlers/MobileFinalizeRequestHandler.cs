﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Enums;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Handlers.CommanderCommandHandlers
{
    internal class MobileFinalizeRequestHandler : CommanderComandHandler
    {
        public MobileFinalizeRequestHandler(IMediator mediator, ILogger<CommanderComandHandler> logger) : base(mediator, logger)
        {
        }

        public override string HandleType => "MobileFinalizeRequest";

        public override bool IsRequestMessage => true;

        public override RequestType RequestType => RequestType.MobileFinalize;

        public override async Task Execute(string message)
        {
            Domain.Models.Commanders.MobileFinalizes.FinalizeCommanderRequest finalizeRequest = Serializer.DeSerialize<Domain.Models.Commanders.MobileFinalizes.FinalizeCommanderRequest>(message);
            await SaveMessage(finalizeRequest.MobileTxnInfo, null, message, finalizeRequest);

            Commands.CommanderIntegrations.FinalizeRequests.CommanderFinalizeRequestCommand finalizeCommanderRequestCommand = new()
            {
                FinalizeRequest = finalizeRequest,
            };

            await mediator.Send(finalizeCommanderRequestCommand);
        }
    }
}
