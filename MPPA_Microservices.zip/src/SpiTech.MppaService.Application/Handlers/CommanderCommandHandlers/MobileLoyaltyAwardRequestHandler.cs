﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.LoyaltyAwardRequests;
using SpiTech.MppaService.Domain.Models.Commanders.MobileLoyaltyAwards;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Handlers.CommanderCommandHandlers
{
    internal class MobileLoyaltyAwardRequestHandler : CommanderComandHandler
    {
        public MobileLoyaltyAwardRequestHandler(IMediator mediator, ILogger<CommanderComandHandler> logger) : base(mediator, logger)
        {
        }

        public override string HandleType => "MobileLoyaltyAwardRequest";

        public override bool IsRequestMessage => true;

        public override RequestType RequestType => RequestType.MobileLoyaltyAward;

        public override async Task Execute(string message)
        {
            var request = Serializer.DeSerialize<MobileLoyaltyAwardMppaRequest>(message);
            await SaveMessage(request.MobileTxnInfo, null, message, request);

            LoyaltyAwardRequestCommand requestCommand = new()
            {
                MobileLoyaltyAwardMppaRequest = request
            };

            await mediator.Send(requestCommand);
        }
    }
}
