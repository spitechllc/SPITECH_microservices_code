﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Enums;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Handlers.CommanderCommandHandlers
{
    internal class MobileReceiptDataRequestHandler : CommanderComandHandler
    {
        public MobileReceiptDataRequestHandler(IMediator mediator, ILogger<CommanderComandHandler> logger) : base(mediator, logger)
        {
        }

        public override string HandleType => "MobileReceiptDataRequest";

        public override bool IsRequestMessage => true;

        public override RequestType RequestType => RequestType.MobileReceiptData;

        public override async Task Execute(string message)
        {
            Domain.Models.Commanders.MobileReceiptData.ReceiptDataCommanderRequest receiptDataRequest = Serializer.DeSerialize<Domain.Models.Commanders.MobileReceiptData.ReceiptDataCommanderRequest>(message);

            await SaveMessage(receiptDataRequest.MobileTxnInfo, null, message, receiptDataRequest);

            Commands.CommanderIntegrations.ReceiptDataRequests.CommanderReceiptDataRequestCommand receiptDataCommanderRequestCommand = new()
            {
                ReceiptDataRequest = receiptDataRequest,
            };

            await mediator.Send(receiptDataCommanderRequestCommand);
        }
    }
}
