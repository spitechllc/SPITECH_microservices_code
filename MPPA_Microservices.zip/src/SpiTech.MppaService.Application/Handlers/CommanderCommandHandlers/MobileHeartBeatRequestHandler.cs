﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.HeartBeats;
using SpiTech.MppaService.Domain.Models.Commanders.HeartBeats;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Handlers.CommanderCommandHandlers
{
    internal class MobileHeartBeatRequestHandler : CommanderComandHandler
    {
        private readonly ILogger<MobileHeartBeatRequestHandler> _logger;
        public MobileHeartBeatRequestHandler(IMediator mediator, ILogger<MobileHeartBeatRequestHandler> logger) : base(mediator, logger)
        {
            _logger = logger;
        }

        public override string HandleType => "MobileHeartBeatRequest";

        public override bool IsRequestMessage => true;

        public override RequestType RequestType => RequestType.MobileHeartBeat;

        public override async Task Execute(string message)
        {
            _logger.Warn($"MPPA MobileHeartBeatRequestHandler Excute function call");
            
            CommanderHeartBeatCommand hartBeatCommanderCommand = new()
            {
                HeartBeatRequest = Serializer.DeSerialize<HeartBeatCommanderRequest>(message)
            };
            _logger.Warn($"MPPA MobileHeartBeatRequestHandler message : {message}");

            HeartBeatMppaResponse response = await mediator.Send(hartBeatCommanderCommand);
        }
    }
}
