﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.StacCaptureRequests;
using SpiTech.MppaService.Domain.Models.Commanders.MobileStacCapture;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Handlers.CommanderCommandHandlers
{
    internal class MobileStacCaptureRequestHandler : CommanderComandHandler
    {
        public MobileStacCaptureRequestHandler(IMediator mediator, ILogger<CommanderComandHandler> logger) : base(mediator, logger)
        {
        }

        public override string HandleType => "MobileSTACCaptureRequest";

        public override bool IsRequestMessage => true;

        public override RequestType RequestType => RequestType.MobileStacCapture;

        public override async Task Execute(string message)
        {
            StacCaptureCommanderRequest stacCaptureRequest = Serializer.DeSerialize<StacCaptureCommanderRequest>(message);

            await SaveMessage(stacCaptureRequest.MobileTxnInfo, null, message, stacCaptureRequest);

            CommanderStacCaptureRequestCommand commanderStacCaptureRequestCommand = new()
            {
                StacCaptureRequest = stacCaptureRequest
            };


            await mediator.Send(commanderStacCaptureRequestCommand);
        }
    }
}
