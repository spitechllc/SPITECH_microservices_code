﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Enums;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Handlers.CommanderCommandHandlers
{
    internal class MobileAuthResponseHandler : CommanderComandHandler
    {
        public MobileAuthResponseHandler(IMediator mediator, ILogger<CommanderComandHandler> logger) : base(mediator, logger)
        {
        }

        public override string HandleType => "MobileAuthResponse";

        public override bool IsRequestMessage => false;

        public override RequestType RequestType => RequestType.MobileAuth;

        public override async Task Execute(string message)
        {
            Domain.Models.Commanders.MobileAuths.AuthCommanderResponse authResponse = Serializer.DeSerialize<Domain.Models.Commanders.MobileAuths.AuthCommanderResponse>(message);
            await SaveMessage(authResponse.MobileTxnInfo, authResponse.MobileAuthResponse?.Response, message, authResponse);

            Commands.CommanderIntegrations.AuthResponses.CommanderAuthResponseCommand authCommanderResponseCommand = new()
            {
                AuthResponse = authResponse
            };



            await mediator.Send(authCommanderResponseCommand);
        }
    }
}
