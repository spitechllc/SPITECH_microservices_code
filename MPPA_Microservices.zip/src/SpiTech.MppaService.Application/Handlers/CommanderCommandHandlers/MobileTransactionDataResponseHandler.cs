﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.TransactionDataResponses;
using SpiTech.MppaService.Domain.Models.Commanders.MobileTransactionData;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Handlers.CommanderCommandHandlers
{
    internal class MobileTransactionDataResponseHandler : CommanderComandHandler
    {
        public MobileTransactionDataResponseHandler(IMediator mediator, ILogger<CommanderComandHandler> logger) : base(mediator, logger)
        {
        }

        public override string HandleType => "MobileTransactionDataResponse";

        public override bool IsRequestMessage => false;

        public override RequestType RequestType => RequestType.MobileTransactionData;

        public override async Task Execute(string message)
        {
            MobileTransactionDataCommanderResponse transactionDataResponse = Serializer.DeSerialize<MobileTransactionDataCommanderResponse>(message);

            await SaveMessage(transactionDataResponse.MobileTxnInfo, transactionDataResponse.MobileTransactionDataResponse?.Response, message, transactionDataResponse);

            CommanderTransactionDataResponseCommand commanderTransactionDataResponseCommand = new()
            {
                TransactionDataResponse = transactionDataResponse
            };

            bool isSuccess = await mediator.Send(commanderTransactionDataResponseCommand);
        }
    }
}
