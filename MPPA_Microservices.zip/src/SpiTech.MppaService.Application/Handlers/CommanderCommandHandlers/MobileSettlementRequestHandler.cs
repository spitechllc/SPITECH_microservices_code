﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Application.Commands.CommanderIntegrations.Settlements;
using SpiTech.MppaService.Domain.Models.Commanders.Settlements;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Handlers.CommanderCommandHandlers
{
    internal class MobileSettlementRequestHandler : CommanderComandHandler
    {
        public MobileSettlementRequestHandler(IMediator mediator, ILogger<CommanderComandHandler> logger) : base(mediator, logger)
        {
        }

        public override string HandleType => "MobileSettlementRequest";

        public override bool IsRequestMessage => true;

        public override RequestType RequestType => RequestType.MobileSettlement;

        public override async Task Execute(string message)
        {
            SettlementCommanderRequest settlementRequest = Serializer.DeSerialize<SettlementCommanderRequest>(message);
            await SaveMessage(settlementRequest.MobileTxnInfo, null, message, settlementRequest);

            CommanderSettlementRequestCommand commanderSettlementRequestCommand = new()
            {
                SettlementRequest = settlementRequest
            };

            await mediator.Send(commanderSettlementRequestCommand);
        }
    }
}
