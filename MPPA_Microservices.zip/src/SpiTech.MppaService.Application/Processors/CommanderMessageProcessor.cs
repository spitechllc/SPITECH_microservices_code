﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Application.Commands.CreateCommanderMessage;
using SpiTech.MppaService.Application.Handlers;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Processors
{
    internal class CommanderMessageProcessor : ICommanderMessageProcessor
    {
        private readonly IMediator mediator;
        private readonly ILogger<CommanderMessageProcessor> logger;
        private readonly IEnumerable<ICommanderComandHandler> handlers;

        public CommanderMessageProcessor(IMediator mediator, ILogger<CommanderMessageProcessor> logger, IEnumerable<ICommanderComandHandler> handlers)
        {
            this.mediator = mediator;
            this.logger = logger;
            this.handlers = handlers;
        }

        public async Task Process(string message, CancellationToken cancellationToken = default)
        {
            logger.Warn("MPPA CommanderMessageProcessor start");
            logger.Warn($"MPPA CommanderMessageProcessor start: {message}");
            try
            {
                if (string.IsNullOrWhiteSpace(message))
                {
                    return;
                }
                logger.Warn($"MPPA CommanderMessageProcessor start 1");

                if (message.IndexOf("<?xml") < 0)
                {
                    throw new Exception("Invalid Message received");
                }

                message = message.Substring(message.IndexOf("<?xml"));

                logger.TraceEnterMethod(nameof(Process), message);

                logger.Warn($"MPPA CommanderMessageProcessor start 2");

                bool handerFound = false;

                foreach (ICommanderComandHandler handler in handlers)
                {
                    logger.Warn($"MPPA CommanderMessageProcessor start 3: {handler.HandleType}");

                    if (message.Contains(handler.HandleType))
                    {

                        handerFound = true;
                        await handler.Execute(message);
                    }
                    logger.Warn($"MPPA CommanderMessageProcessor start 4: {handler.HandleType}");
                }

                if (!handerFound)
                {
                    throw new Exception("No handler found for message");
                }
                logger.Warn($"MPPA CommanderMessageProcessor exit");

                logger.TraceExitMethod(nameof(Process));
            }
            catch (Exception ex)
            {
                logger.Warn($"MPPA CommanderMessageProcessor Error message: {ex.Message}");
                logger.Error(ex, message);
                await SaveErrorMessage(message, "Message:" + ex.Message + ", StackTrace:" + ex.StackTrace);
            }
        }

        private async Task SaveErrorMessage(string message, string errorMessage)
        {
            try
            {
                await mediator.Send(new CreateCommanderMessageCommand
                {
                    CommanderMessage = new Domain.Entities.CommanderMessage
                    {
                        CommanderMessageId = Guid.NewGuid(),
                        XmlMessage = message,
                        JsonMessage = "",
                        MerchantId = GetMerchantId(message),
                        UMTI = GetUMTI(message),
                        SiteId = GetSiteId(message),
                        StatusId = (int)Status.Fail,
                        RequestTypeId = null,
                        ResponseCode = "",
                        OverallResult = "",
                        MessageCode = "ProcessError",
                        IsRequest = true,
                        IsActive = true,
                        CreatedOn = DateTime.UtcNow,
                        Error = errorMessage
                    }
                });
            }
            catch (Exception saveEx)
            {
                logger.Error(saveEx);
            }
        }

        private string GetSiteId(string message)
        {
            if (!string.IsNullOrWhiteSpace(message))
            {
                System.Text.RegularExpressions.Regex regex = new("<SiteID>(.*?)</SiteID>");
                System.Text.RegularExpressions.Match match = regex.Match(message);
                if (match.Success)
                {
                    return match.Groups[1].Value.Trim();
                }
            }

            return "";
        }

        private string GetMerchantId(string message)
        {
            if (!string.IsNullOrWhiteSpace(message))
            {
                System.Text.RegularExpressions.Regex regex = new("<MerchantID>(.*?)</MerchantID>");
                System.Text.RegularExpressions.Match match = regex.Match(message);
                if (match.Success)
                {
                    return match.Groups[1].Value.Trim();
                }
            }

            return "";
        }

        private string GetUMTI(string message)
        {
            if (!string.IsNullOrWhiteSpace(message))
            {
                System.Text.RegularExpressions.Regex regex = new("<UMTI>(.*?)</UMTI>");
                System.Text.RegularExpressions.Match match = regex.Match(message);
                if (match.Success)
                {
                    return match.Groups[1].Value.Trim();
                }
            }

            return "";
        }
    }
}
