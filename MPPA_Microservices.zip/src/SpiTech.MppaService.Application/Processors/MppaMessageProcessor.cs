﻿using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Application.Interfaces.HostServers;
using SpiTech.MppaService.Application.Commands.CreateCommanderMessage;
using SpiTech.MppaService.Domain.Models.Commanders;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Processors
{
    internal class MppaMessageProcessor : IMppaMessageProcessor
    {
        private readonly ILogger<MppaMessageProcessor> logger;
        private readonly IMppaSessionManager mppaSessionManager;
        private readonly IMediator mediator;

        public MppaMessageProcessor(ILogger<MppaMessageProcessor> logger, IMppaSessionManager mppaSessionManager, IMediator mediator)
        {
            this.logger = logger;
            this.mppaSessionManager = mppaSessionManager;
            this.mediator = mediator;
        }

        public async Task<ResponseModel> Process(long? transactionId,
            string message,
            object messageObject,
            bool isRequestMessage,
            RequestType requestType,
            MobileTxnInfoBase mobileTxnInfoBase,
            bool isSuccess,
            Response response,
            CancellationToken cancellationToken = default)
        {
            ResponseModel result = new() { Success = false };

            try
            {
                logger.TraceEnterMethod(nameof(Process), message);

                if (requestType != RequestType.MobileHeartBeat)
                {
                    await SaveMessage(mobileTxnInfoBase,
                                isSuccess,
                                message,
                                messageObject,
                                isRequestMessage,
                                requestType,
                                transactionId,
                                response);
                }

                result = await mppaSessionManager.SendMessage(mobileTxnInfoBase.SiteId, message).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                logger.Error(ex, transactionId, messageObject, mobileTxnInfoBase);
                result.Message = ex.Message;
            }

            logger.TraceExitMethod(nameof(Process), result);

            return result;
        }

        protected async Task<bool> SaveMessage(MobileTxnInfoBase mobileTxnInfoBase,
            bool isSuccess,
            string message,
            object messageObject,
            bool isRequestMessage,
            RequestType requestType,
            long? transactionId,
            Response response)
        {
            string jsonData = "";

            try
            {
                jsonData = JsonConvert.SerializeObject(messageObject);
            }
            catch (Exception ex)
            {
                logger.Error(ex, mobileTxnInfoBase, messageObject, transactionId, response);
            }

            try
            {
                await mediator.Send(new CreateCommanderMessageCommand
                {
                    CommanderMessage = new Domain.Entities.CommanderMessage
                    {
                        CommanderMessageId = Guid.NewGuid(),
                        XmlMessage = message,
                        JsonMessage = jsonData,
                        MerchantId = mobileTxnInfoBase.MerchantId,
                        UMTI = mobileTxnInfoBase.UMTI,
                        SiteId = mobileTxnInfoBase.SiteId,
                        StatusId = isSuccess ? (int)Status.Success : (int)Status.Fail,
                        RequestTypeId = (int)requestType,
                        ResponseCode = response?.ResponseCode,
                        OverallResult = response?.OverallResult,
                        MessageCode = response?.MessageCode,
                        IsRequest = isRequestMessage,
                        IsActive = true,
                        CreatedOn = DateTime.UtcNow,
                    }
                });
            }
            catch (Exception ex)
            {
                logger.Error(ex, mobileTxnInfoBase, messageObject, transactionId, response);
                return false;
            }
            return true;
        }
    }
}
