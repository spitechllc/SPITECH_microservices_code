﻿using SpiTech.MppaService.Domain.Interfaces;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Processors
{
    public interface IMobileMessageProcessor
    {
        Task Process(IMobileRequest request);
    }
}
