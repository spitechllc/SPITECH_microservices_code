﻿using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Application.UnitOfWorks;
using System;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Processors
{
    public class UserAppMessageLogProcessor : IUserAppMessageLogProcessor
    {
        private readonly IUnitOfWork unitOfWork;
        private readonly ILogger<MobileMessageProcessor> logger;

        public UserAppMessageLogProcessor(IUnitOfWork unitOfWork, ILogger<MobileMessageProcessor> logger)
        {
            this.unitOfWork = unitOfWork;
            this.logger = logger;
        }

        public async Task Log<T>(RequestType requestType, string siteId, int userId, long? transactionId, string utmi, string error, bool isRequestMessage, T message)
        {
            try
            {
                await unitOfWork.UserAppMessages.Add(new Domain.Entities.UserAppMessage
                {
                    UserAppMessageId = Guid.NewGuid(),
                    IsSuccess = string.IsNullOrWhiteSpace(error),
                    IsRequestMessage = isRequestMessage,
                    Error = error,
                    IsActive = true,
                    Message = ApplicationCore.Helpers.JsonObjectConverter.Serialize(message),
                    SiteId = siteId,
                    RequestTypeId = (int)requestType,
                    UserId = userId,
                    CreatedBy = userId,
                    TransactionId = transactionId,
                    UMTI = utmi,
                });
                unitOfWork.Commit();
            }
            catch (Exception ex)
            {
                unitOfWork.Rollback();
                logger.Error(ex, transactionId);
            }
        }

        public async Task LogRequest<T>(RequestType requestType, string siteId, int userId, long? transactionId, string utmi, string error, T request)
        {
            await Log(requestType, siteId, userId, transactionId, utmi, error, true, request);
        }

        public async Task LogResponse<T>(RequestType requestType, string siteId, int userId, long? transactionId, string utmi, string error, T response)
        {
            await Log(requestType, siteId, userId, transactionId, utmi, error, false, response);
        }

        public Task<bool> IsValidRequest(RequestType requestType, string utmi, int userId)
        {
            return unitOfWork.UserAppMessages.IsValidRequest((int)requestType, utmi, userId);
        }
    }
}
