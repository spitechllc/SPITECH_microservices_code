﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Domain.Interfaces;
using System;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Processors
{
    public class MobileMessageProcessor : IMobileMessageProcessor
    {
        private readonly IMediator mediator;
        private readonly ILogger<MobileMessageProcessor> logger;

        public MobileMessageProcessor(IMediator mediator, ILogger<MobileMessageProcessor> logger)
        {
            this.mediator = mediator;
            this.logger = logger;
        }

        public async Task Process(IMobileRequest request)
        {
            try
            {
                await mediator.Publish(request);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }
    }
}
