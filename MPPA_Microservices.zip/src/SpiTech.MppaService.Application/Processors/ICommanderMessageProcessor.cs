﻿using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Processors
{
    public interface ICommanderMessageProcessor
    {
        Task Process(string message, CancellationToken cancellationToken = default);
    }
}
