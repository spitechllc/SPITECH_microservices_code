﻿using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Domain.Models.Commanders;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Processors
{
    public interface IMppaMessageProcessor
    {
        Task<ResponseModel> Process(long? transactionId,
            string message,
            object messageObject,
            bool isRequestMessage,
            RequestType requestType,
            MobileTxnInfoBase mobileTxnInfoBase,
            bool isSuccess,
            Response response,
            CancellationToken cancellationToken = default);
    }
}
