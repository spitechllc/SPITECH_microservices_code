﻿using SpiTech.EventBus.DomainEvents.Enums;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Processors
{
    public interface IUserAppMessageLogProcessor
    {
        Task<bool> IsValidRequest(RequestType requestType, string utmi, int userId);
        Task LogRequest<T>(RequestType requestType, string siteId, int userId, long? transactionId, string utmi, string error, T request);
        Task LogResponse<T>(RequestType requestType, string siteId, int userId, long? transactionId, string utmi, string error, T response);
    }
}
