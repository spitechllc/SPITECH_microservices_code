﻿using SpiTech.MppaService.Domain;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace SpiTech.MppaService.Application
{
    public class Serializer
    {
        public static string Serialize<T>(object objectToSerialize)
        {
            XmlSerializerNamespaces ns = new();
            ns.Add("", "http://www.conexxus.org/schema/naxml/mobile/" + Constants.NamespaceVersion);

            XmlWriterSettings settings = new()
            {
                Indent = false,
                NewLineOnAttributes = false,
                NewLineChars = "",
                OmitXmlDeclaration = false,
                Encoding = Encoding.UTF8
            };

            using MemoryStream ms = new();
            using XmlWriter writer = XmlWriter.Create(ms, settings);
            writer.WriteStartDocument(true);
            new XmlSerializer(typeof(T)).Serialize(writer, objectToSerialize, ns);
            return Encoding.UTF8.GetString(ms.ToArray()); ;
        }

        public static T DeSerialize<T>(string message) where T : class
        {
            XmlDocument xmldoc = new();
            string extractMessage = message.Substring(message.IndexOf("<NAXMLMobile"));
            xmldoc.LoadXml(extractMessage);
            //var fromXml = JsonConvert.SerializeXmlNode(xmldoc, Newtonsoft.Json.Formatting.None, true);
            //return JsonConvert.DeserializeObject<T>(fromXml);

            T response = null;
            XmlSerializer serializer = new(typeof(T));
            using (XmlReader reader = new XmlNodeReader(xmldoc))
            {
                response = (T)serializer.Deserialize(reader);
            }

            return response;
        }
    }
}
