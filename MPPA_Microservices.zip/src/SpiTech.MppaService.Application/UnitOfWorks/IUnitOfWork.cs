﻿using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.MppaService.Application.Repositories;

namespace SpiTech.MppaService.Application.UnitOfWorks
{
    public interface IUnitOfWork : IBaseUnitOfWork
    {
        IPOSRepository PoseS { get; }
        IGasPumpRepository GasPumps { get; }
        IHostConfigrationRepository HostConfigrations { get; }
        IRequestTypeRepository RequestTypes { get; }
        IStacGenerationRepository StacGenerations { get; }
        IStacCaptureRequestRepository StacCaptureRequests { get; }
        ITransactionRepository Transactions { get; }
        ICommanderMessageRepository CommanderMessages { get; }
        IUserAppMessageRepository UserAppMessages { get; }
        ISiteRepository Sites { get; }
        ISiteProductRepository SiteProducts { get; }
        IHostMPPARepository HostMPPAs { get; }
        IAdapterRepository Adapters { get; }
        ISettlementRequestRepository SettlementRequests { get; }
        ISettlementDetailRepository SettlementDetails { get; }
        ISaleItemRepository SaleItems { get; }
    }
}
