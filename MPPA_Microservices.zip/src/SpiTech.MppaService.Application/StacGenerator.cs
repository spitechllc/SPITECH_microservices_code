﻿using System;

namespace SpiTech.MppaService.Application
{
    public class StacGenerator
    {
        private const string StacPrefix = "PAP";
        public static string Generate()
        {
            string result = Guid.NewGuid().ToString().Replace("-", "").ToUpperInvariant();
            return result.PadLeft(32, '0');
        }

        public static string StacWithPrefix(string stac)
        {
            return $"{StacPrefix}.{stac}";
        }

        public static string StacWithOutPrefix(string stac)
        {
            if(!string.IsNullOrWhiteSpace(stac))
            {
                var splits= stac.Trim().Split($"{StacPrefix}.", StringSplitOptions.RemoveEmptyEntries);
                if (splits.Length == 2)
                {
                    return splits[1];
                }
                else if (splits.Length == 1)
                {
                    return splits[0];
                }
            }

            return stac;
        }
    }
}
