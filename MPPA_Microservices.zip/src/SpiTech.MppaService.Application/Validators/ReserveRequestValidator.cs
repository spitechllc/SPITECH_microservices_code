﻿using FluentValidation;
using SpiTech.MppaService.Domain.Models.Mobile;

namespace SpiTech.MppaService.Application.Validators
{
    public class ReserveRequestValidator : AbstractValidator<ReserveRequest>
    {
        public ReserveRequestValidator()
        {
            RuleFor(x => x.SiteId).NotNull().WithMessage("SiteId is required").NotEmpty().WithMessage("SiteId is required");
            RuleFor(x => x.UserPaymentMethodId).GreaterThan(0).WithMessage("UserPaymentMethodId is required");
            RuleFor(x => x.FuelingPositionId).GreaterThan(0).WithMessage("UserPaymentMethodId is required");
            RuleFor(x => x).Must(t => t.CardAmount > 0 || t.WalletAmount > 0).WithMessage("CardAmount or WalletAmount is required");
            RuleFor(x => x.DeviceToken).NotNull().WithMessage("DeviceToken is required").NotEmpty().WithMessage("DeviceToken is required");
            RuleFor(x => x.DeviceType).IsInEnum();
        }
    }
}
