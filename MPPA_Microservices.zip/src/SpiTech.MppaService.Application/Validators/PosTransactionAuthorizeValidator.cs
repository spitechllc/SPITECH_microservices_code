﻿using FluentValidation;
using SpiTech.MppaService.Domain.Models.Mobile;

namespace SpiTech.MppaService.Application.Validators
{
    public class PosTransactionAuthorizeValidator : AbstractValidator<PosTransactionAuthorize>
    {
        public PosTransactionAuthorizeValidator()
        {
            RuleFor(x => x.UMTI).NotNull().WithMessage("UMTI is required").NotEmpty().WithMessage("UMTI is required");
            RuleFor(x => x.UserPaymentMethodId).GreaterThan(0).WithMessage("UserPaymentMethodId is required");
            When(t => t.IsAuthorize, () =>
            {
                RuleFor(x => x).Must(t => t.CardAmount > 0 || t.WalletAmount > 0).WithMessage("CardAmount or WalletAmount is required");
            });
        }
    }
}
