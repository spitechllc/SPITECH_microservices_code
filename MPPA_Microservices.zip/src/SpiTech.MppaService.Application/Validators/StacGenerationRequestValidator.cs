﻿using FluentValidation;
using SpiTech.MppaService.Domain.Models.Mobile;

namespace SpiTech.MppaService.Application.Validators
{
    public class StacGenerationRequestValidator : AbstractValidator<StacGenerationRequest>
    {
        public StacGenerationRequestValidator()
        {
            RuleFor(x => x.SiteId).NotNull().WithMessage("SiteId is required").NotEmpty().WithMessage("SiteId is required");
            RuleFor(x => x.DeviceToken).NotNull().WithMessage("DeviceToken is required").NotEmpty().WithMessage("DeviceToken is required");
            RuleFor(x => x.DeviceType).IsInEnum();
        }
    }
}
