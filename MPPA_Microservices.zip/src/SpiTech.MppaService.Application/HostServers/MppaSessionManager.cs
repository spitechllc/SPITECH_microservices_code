﻿using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Application.Interfaces.HostServers;
using SpiTech.MppaService.Domain.Models;
using Polly;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.HostServers
{
    internal class MppaSessionManager: IMppaSessionManager
    {

        private readonly ConcurrentDictionary<Guid, IMppaSession> siteConnectionsMaps = new();
        private readonly ILogger<MppaSessionManager> logger;

        public MppaSessionManager(ILogger<MppaSessionManager> logger)
        {
            this.logger = logger;
        }

        public bool AddSiteSession(IMppaSession mppaSession)
        {
            try
            {
                if (!siteConnectionsMaps.ContainsKey(mppaSession.Id))
                {
                    //logger.Warn($"MppaSessions-{siteConnectionsMaps.Where(t => t.Value.IsActive).Count()} is active out of {siteConnectionsMaps.Count} Sessions connected");
                    return siteConnectionsMaps.TryAdd(mppaSession.Id, mppaSession);
                }
                else
                {
                    RemoveSiteSession(mppaSession);
                    return siteConnectionsMaps.TryAdd(mppaSession.Id, mppaSession);
                }

               
            }
            catch (Exception ex)
            {
                logger.Error(ex, mppaSession.SiteId);
            }

            return false;
        }

        public bool RemoveSiteSession(IMppaSession mppaSession)
        {
            try
            {
                if (siteConnectionsMaps.ContainsKey(mppaSession.Id))
                {
                    return siteConnectionsMaps.Remove(mppaSession.Id, out IMppaSession session);
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex, mppaSession.SiteId);
            }

            return false;
        }


        public async Task<ResponseModel> SendMessage(string siteId, string message)
        {
            ResponseModel result = new();

            try
            {
                var retryPolicy = Policy
                .Handle<Exception>()
                .WaitAndRetryAsync(3, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));

                await retryPolicy.ExecuteAsync(async () =>
                {
                    IMppaSession mppaSession = siteConnectionsMaps?.Where(t =>
                    {
                        if (string.IsNullOrWhiteSpace(t.Value?.SiteId))
                        {
                            return false;
                        }

                        return t.Value.SiteId.Equals(siteId, StringComparison.InvariantCultureIgnoreCase);

                    }).OrderByDescending(t => t.Value.ConnectionTime).Select(t => t.Value).FirstOrDefault();

                    if (mppaSession == null)
                    {
                        throw new Exception($"No session Found with SiteId as {siteId}");
                    }

                    await mppaSession.SendMessage(message).ConfigureAwait(false);

                    result.Success = true;

                }).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                if (!string.IsNullOrWhiteSpace(ex.Message) && ex.Message.Contains("No session Found with SiteId"))
                {
                    result.Message = "Pump is not available, Choose another pump or try again later";
                    logger.Warn(ex.Message);
                }
                else
                {
                    result.Message = ex.Message;
                    logger.Error(ex);
                }
            }

            return result;
        }

        public async Task<IMppaSession> GetMppaSession(string siteId)
        {
            IMppaSession mppaSession = siteConnectionsMaps.Where(t => (!string.IsNullOrWhiteSpace(t.Value?.SiteId)) && t.Value.SiteId.Equals(siteId, StringComparison.InvariantCultureIgnoreCase)).OrderByDescending(t => t.Value.ConnectionTime).Select(t => t.Value).FirstOrDefault();

            return await Task.FromResult(mppaSession);
        }

        public async Task<List<string>> GetActiveMppaSessionSiteIds()
        {
            var mppaSessions = siteConnectionsMaps.Where(t => (!string.IsNullOrWhiteSpace(t.Value?.SiteId)) && t.Value.IsActive).Select(t => t.Value.SiteId).ToList();

            return await Task.FromResult(mppaSessions);
        }


        public async Task<List<MppaSessionStatus>> GetMppaSessionStatus(string siteId)
        {
            List<MppaSessionStatus> mppaSessionStatuses = new List<MppaSessionStatus>();

            if (!string.IsNullOrWhiteSpace(siteId))
            {
                mppaSessionStatuses = siteConnectionsMaps.Where(t => (!string.IsNullOrWhiteSpace(t.Value?.SiteId)) && t.Value.SiteId == siteId)
                    .Select(t => t.Value.GetMppaSessionStatus()).ToList();
            }

            mppaSessionStatuses = siteConnectionsMaps.Select(t => t.Value.GetMppaSessionStatus()).ToList();

            return await Task.FromResult(mppaSessionStatuses);
        }
    }
}
