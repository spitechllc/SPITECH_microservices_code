﻿using Microsoft.Extensions.DependencyInjection;
using NetCoreServer;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.Interfaces.HostServers;
using SpiTech.MppaService.Domain;
using System.Net.Sockets;

namespace SpiTech.MppaService.Application.HostServers
{
    public class MppaServer : TcpServer, IMppaServer
    {
        private readonly ILogger<MppaServer> logger;
        private readonly IMppaSessionManager mppaSessionManager;

        public IServiceScope ServiceScope { get; set; }

        public MppaServer(ILogger<MppaServer> logger, ServerConfig serverConfig, IServiceScopeFactory scopeFactory, IMppaSessionManager mppaSessionManager) : base(serverConfig.Host, serverConfig.Port)
        {
            this.logger = logger;
            this.mppaSessionManager = mppaSessionManager;
            ServiceScope = scopeFactory.CreateScope();
            logger.Warn($"TCP Server started with IP: {serverConfig.Host} , port:{serverConfig.Port}, SSL: {serverConfig.IsSSLOn}");
        }
        

        protected override TcpSession CreateSession()
        {
            var mppaSession = (MppaSession)ServiceScope.ServiceProvider.GetService<IMppaSession>();
            mppaSessionManager.AddSiteSession(mppaSession);
           
            return mppaSession;
        }

        protected override void OnError(SocketError error)
        {
            logger.Warn($"TCP server caught an error with code {error}", error);
        }
    }
}
