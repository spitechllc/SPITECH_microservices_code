﻿using Microsoft.Extensions.DependencyInjection;
using NetCoreServer;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.MppaService.Application.Interfaces.HostServers;
using SpiTech.MppaService.Application.Processors;
using SpiTech.MppaService.Domain.Models;
using System;
using System.Globalization;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.HostServers
{
    public class MppaSession : TcpSession, IMppaSession
    {
        private const string EndMessageIdentifier = "</NAXMLMobile>";
        private readonly ILogger<MppaSession> logger;
        private readonly IMppaServer server;
        private readonly IServiceScopeFactory scopeFactory;
        private readonly IMppaSessionManager mppaSessionManager;
        private string receiveMessage = "";
        public MppaSession(ILogger<MppaSession> logger, IMppaServer server, IServiceScopeFactory scopeFactory, IMppaSessionManager mppaSessionManager) : base((MppaServer)server)
        {
            this.logger = logger;
            this.SiteId = String.Empty;
            this.server = server;
            this.scopeFactory = scopeFactory;
            this.mppaSessionManager = mppaSessionManager;
            ConnectionTime = DateTime.UtcNow;
        }

        public string SiteId { get; set; }
        public DateTime ConnectionTime { get; set; }
        public DateTime DisConnectionTime { get; set; }
        public DateTime LastMessageReceived { get; set; }

        public bool IsActive => IsConnected && !IsSocketDisposed;

        protected override void OnConnected()
        {
            ConnectionTime = DateTime.UtcNow;
            logger.Warn($"TCP session with Id {Id} connected!");
        }

        protected override void OnDisconnected()
        {
            DisConnectionTime = DateTime.UtcNow;
            logger.Warn($"TCP session with Id {Id} disconnected!");
            mppaSessionManager.RemoveSiteSession(this);
        }

        protected override void OnReceived(byte[] buffer, long offset, long size)
        {
            try
            {
                if(buffer == null)
                {
                    return;
                }

                LastMessageReceived = DateTime.UtcNow;

                logger.Info($"Incoming message offset = {offset} , Size= {size}");

                string message = Encoding.UTF8.GetString(buffer, (int)offset, (int)size);

                if(string.IsNullOrEmpty(message))
                {
                    return;
                }

                if (!message.Contains("MobileHeartBeatRequest"))
                {
                    logger.Info("Incoming: " + message);
                }

                SetSiteId(message);

                //try
                //{
                //    if (message.Contains("<NAXMLMobile"))
                //    {
                //        string hexIncomming = ByteArrayToString(buffer.Take(4).ToArray());
                //        int messageLength = Convert.ToInt32(hexIncomming, 16);
                //        logger.Info($"Incoming message hex={hexIncomming}, message Length={messageLength}");
                //    }
                //}
                //catch (Exception ex)
                //{
                //    logger.Error(ex);
                //}

                if (message.Contains(EndMessageIdentifier))
                {
                    var endMessageIndex = EndMessageIndex(message);

                    receiveMessage += message.Substring(0, endMessageIndex);

                    string finalMessage = receiveMessage;

                    logger.Info("Incoming Final Message: " + finalMessage);

                    _ = Task.Run(async () =>
                         {
                             using IServiceScope serviceScope = scopeFactory.CreateScope();
                             ICommanderMessageProcessor processor = serviceScope.ServiceProvider.GetRequiredService<ICommanderMessageProcessor>();
                             await processor.Process(finalMessage).ConfigureAwait(false);
                         });

                    if (endMessageIndex < message.Length)
                    {
                        receiveMessage = message.Substring(endMessageIndex);
                    }
                    else
                    {
                        receiveMessage = "";
                    }
                }
                else
                {
                    receiveMessage += message;
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex, $"TCP session caught an error during receive message with error message {ex.Message}");
            }
        }

        private int EndMessageIndex(string message)
        {
            return message.IndexOf(EndMessageIdentifier) + EndMessageIdentifier.Length;
        }

        private void SetSiteId(string message)
        {
            if (string.IsNullOrWhiteSpace(SiteId))
            {
                System.Text.RegularExpressions.Regex regex = new("<SiteID>(.*?)</SiteID>");
                System.Text.RegularExpressions.Match match = regex.Match(message);

                if (match.Success)
                {
                    string siteId = match.Groups[1].Value.Trim();
                    logger.Trace($"TCP session SiteId -{siteId}");

                    if (!string.IsNullOrWhiteSpace(siteId))
                    {
                        SiteId = siteId;
                    }
                }
            }
        }

        public async Task SendMessage(string message)
        {
            if (!message.Contains("MobileHeartBeatResponse"))
            {
                logger.Warn("OutGoing: " + message);
            }

            byte[] bytes = Encoding.UTF8.GetBytes(message);
            string hex = DecimalToHexadouble(bytes.Length);

            logger.Info($"OutGoing Message length={bytes.Length}, Prefix bytes: {hex}");

            byte[] prefixBytes = Convert.FromHexString(hex);
            byte[] resultytes = prefixBytes.Concat(bytes).ToArray();
            Send(resultytes);
            await Task.CompletedTask;
        }

        protected override void OnError(SocketError error)
        {
            if (error == SocketError.TimedOut)
            {
                logger.Warn($"TCP session caught an error with code {error}");
            }
            else
            {
                logger.Error(new Exception($"TCP session caught an error with code {error}"), $"TCP session caught an error with code {error}");
            }
        }

        public static string ByteArrayToString(byte[] bufferArray)
        {
            StringBuilder hex = new(bufferArray.Length * 2);

            foreach (byte buffer in bufferArray)
            {
                hex.AppendFormat("{0:x2}", buffer);
            }

            return hex.ToString();
        }

        public static string DecimalToHexadouble(int value)
        {
            return value.ToString("x8", new CultureInfo("en-us"));
        }

        public MppaSessionStatus GetMppaSessionStatus()
        {
            return new MppaSessionStatus
            {
                ConnectionTime = ConnectionTime,
                SiteId = SiteId,
                DisConnectionTime = DisConnectionTime,
                IsConnected = IsConnected,
                IsSocketDisposed = IsSocketDisposed,
                LastMessageReceived = LastMessageReceived,
            };
        }
    }
}
