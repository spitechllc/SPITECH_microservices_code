﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.MppaService.Application.Commands.UpdateTransaction;
using SpiTech.MppaService.Application.Queries.GetTransactionById;
using SpiTech.MppaService.Application.UnitOfWorks;
using System;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.EventConsumers
{
    public class PaymentStatusEventConsumer : IConsumer<PaymentStatusEvent>

    {
        private readonly IMediator mediator;
        private readonly ILogger<PaymentStatusEventConsumer> logger;
        private readonly IUnitOfWork dbContext;

        public PaymentStatusEventConsumer(IMediator mediator, ILogger<PaymentStatusEventConsumer> logger, IUnitOfWork dbContext)
        {
            this.mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.dbContext = dbContext;
        }

        public async Task Consume(ConsumeContext<PaymentStatusEvent> context)
        {
            logger.TraceEnterMethod(nameof(Consume), context);

            Domain.Entities.Transaction transaction = await mediator.Send(new GetTransactionByIdQuery { TransactionId = context.Message.TransactionId });

            if (transaction != null)
            {
                transaction.IsPaymentSuccess = context.Message.IsSuccess;

                await this.dbContext.Transactions.UpdatePaymentStatus(context.Message.TransactionId, context.Message.IsSuccess, context.Message.ErrorMessage);
            }

            logger.Info($"PaymentStatusEvent consumed successfully.");
        }
    }
}
