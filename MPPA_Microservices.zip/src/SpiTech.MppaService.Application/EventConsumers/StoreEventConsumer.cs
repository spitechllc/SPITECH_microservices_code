﻿using MassTransit;
using MediatR;
using Microsoft.AspNetCore.SignalR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Store;
using SpiTech.MppaService.Application.Commands.UpdateGetSite;
using SpiTech.MppaService.Application.Hubs;
using SpiTech.MppaService.Application.UnitOfWorks;
using System;
using System.Threading.Tasks;
using static SpiTech.MppaService.Domain.Constants;
using static Slapper.AutoMapper;

namespace SpiTech.MppaService.Application.EventConsumers
{
    public class StoreEventConsumer : IConsumer<StoreEvent>
    {
        private readonly IUnitOfWork dbContext;
        private readonly IMediator mediator;
        private readonly ILogger<StoreEventConsumer> logger;
        private readonly IHubContext<DashBoardHub, IDashBoardHubClient> dashBoardHubcontext;

        public StoreEventConsumer(IUnitOfWork dbContext, IMediator mediator, ILogger<StoreEventConsumer> logger, IHubContext<DashBoardHub, IDashBoardHubClient> dashBoardHubcontext)
        {
            this.dbContext = dbContext;
            this.mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.dashBoardHubcontext = dashBoardHubcontext;
        }

        public async Task Consume(ConsumeContext<StoreEvent> context)
        {
            logger.TraceEnterMethod(nameof(Consume), context);

            if (string.IsNullOrWhiteSpace(context.Message.SiteId))
            {
                return;
            }

            await NotifyDashboard(context);

            await mediator.Send(new UpdateGetSiteCommand
            {
                SiteId = context.Message.SiteId,
                StoreId = context.Message.StoreId,
                StoreName = context.Message.StoreName,
                Update = true
            });

            logger.Info($"StoreEvent consumed successfully. StoreId : {context.Message.StoreId}");
        }

        private async Task NotifyDashboard(ConsumeContext<StoreEvent> context)
        {
            try
            {
                await this.dashBoardHubcontext.Clients.All.DashBoardMessage(new Domain.Models.DashBoardEventModel
                {
                    ChangeIdentifier = context.Message.StoreId.ToString(),
                    Event = DashBoardEvent.Store,
                    Message = "Store Change"
                });
            }
            catch (Exception ex)
            {
                logger.Error(ex, "DashBoardHub Error");
            }
        }
    }
}
