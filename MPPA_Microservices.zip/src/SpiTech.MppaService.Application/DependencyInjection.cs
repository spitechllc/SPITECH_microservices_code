﻿using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.ApplicationCore.AppSettingsConfigLoader;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Mobiles;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.EventBus.DomainEvents.Events.Store;
using SpiTech.EventBus.DomainEvents.ServiceCollection;
using SpiTech.MppaService.Application.EventConsumers;
using SpiTech.MppaService.Application.Handlers;
using SpiTech.MppaService.Application.Handlers.CommanderCommandHandlers;
using SpiTech.MppaService.Application.HostServers;
using SpiTech.MppaService.Application.Hubs;
using SpiTech.MppaService.Application.Interfaces.HostServers;
using SpiTech.MppaService.Application.Processors;
using SpiTech.MppaService.Application.Providers;
using SpiTech.MppaService.Application.Services;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Mappers;
using Rebus.Config;
using Rebus.Routing.TypeBased;
using Rebus.SignalR;
using System;
using System.Reflection;

namespace SpiTech.MppaService.Application
{
    public static class DependencyInjection
    {
        private static string GenerateTransientQueueName(string inputQueueName)
        {
            return $"{inputQueueName}-{Environment.MachineName}-{Guid.NewGuid().ToString()}";
        }

        public static IServiceCollection AddApplication(this IServiceCollection services, IConfiguration configuration)
        {
            services
                .AddMediatR(Assembly.GetExecutingAssembly()).AddAutoMapper(typeof(AdapterProfile))
                .AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());

           

            var rabbitMqConfiguration = configuration.GetSection(nameof(RabbitMqConfiguration)).Get<RabbitMqConfiguration>();

            var rabbitMqConnectionString =
        $"amqp://{rabbitMqConfiguration.UserName}:{rabbitMqConfiguration.Password}@{rabbitMqConfiguration.HostNames[0]}/{rabbitMqConfiguration.VirtualHost}";


            services.AddRebus(configure => configure.Transport(x =>
                                                    {
                                                        x.UseRabbitMq(rabbitMqConnectionString, GenerateTransientQueueName("Rebus.SignalR"))
                                                        .InputQueueOptions(o =>
                                                        {
                                                            o.SetAutoDelete(true);
                                                            o.SetDurable(false);
                                                        });
                                                    })
                                                    .Options(o => o.EnableSynchronousRequestReply())
                                                    .Routing(r => r.TypeBased()));

            services.AddConfig<ServerConfig>(configuration);
            services.AddConfig<HostConfig>(configuration);

            services.AddSingleton<IUserIdProvider, NameUserIdProvider>();

            services.AddSingleton<IMppaSessionManager, MppaSessionManager>();
            services.AddSingleton<IMppaServer, MppaServer>();
            services.AddTransient<IMppaSession, MppaSession>();
            services.AddTransient<IMppaMessageProcessor, MppaMessageProcessor>();
            services.AddTransient<ICommanderMessageProcessor, CommanderMessageProcessor>();
            services.AddTransient<IMobileMessageProcessor, MobileMessageProcessor>();
            services.AddTransient<IUserAppMessageLogProcessor, UserAppMessageLogProcessor>();
            services.AddTransient<IPosFakeTestService, PosFakeTestService>();
            services.AddTransient<IPayAtPumpFakeTestService, PayAtPumpFakeTestService>();

            services.AddScoped<IMppaClient, MppaClient>();

            services.AddScoped<ICommanderComandHandler, MobileAuthResponseHandler>();
            services.AddScoped<ICommanderComandHandler, MobileBeginFuelingRequestHandler>();
            services.AddScoped<ICommanderComandHandler, MobileCancelResponseHandler>();
            services.AddScoped<ICommanderComandHandler, MobileFinalizeRequestHandler>();
            services.AddScoped<ICommanderComandHandler, MobileHeartBeatRequestHandler>();
            services.AddScoped<ICommanderComandHandler, MobilePumpReserveResponseHandler>();
            services.AddScoped<ICommanderComandHandler, MobileReceiptDataRequestHandler>();
            services.AddScoped<ICommanderComandHandler, MobileSettlementRequestHandler>();
            services.AddScoped<ICommanderComandHandler, MobileSiteDataRequestHandler>();
            services.AddScoped<ICommanderComandHandler, MobileStacCaptureRequestHandler>();
            services.AddScoped<ICommanderComandHandler, MobileTransactionDataResponseHandler>();
            services.AddScoped<ICommanderComandHandler, MobileLoyaltyAwardRequestHandler>();

            // MassTransit-RabbitMQ Configuration
            services.RegisterMessageQueue(configuration, config =>
            {
                config.AddConsumer<PaymentStatusEventConsumer>();
                config.AddConsumer<StoreEventConsumer>();
            }, (ctx, cfg) =>
            {
                cfg.ConfigurePublishEvent<MobileFinalizesDataResponseEvent>();
                cfg.ConfigurePublishEvent<MobilePumpBeginFualResponsesEvent>();
                cfg.ConfigurePublishEvent<MobilePumpReserveResponsesEvent>();
                cfg.ConfigurePublishEvent<MobileStacCaptureResponsesEvent>();
                cfg.ConfigurePublishEvent<AuthMppaRequestEvent>();
                cfg.ConfigurePublishEvent<FinalizeRequestEvent>();
                cfg.ConfigurePublishEvent<PumpReserveRequestEvent>();
                cfg.ConfigurePublishEvent<ReceiptDataRequestEvent>();
                cfg.ConfigurePublishEvent<TransactionUpdateEvent>();
                cfg.ConfigurePublishEvent<MppaPaymentProcessEvent>();
                cfg.ConfigurePublishEvent<SiteEvent>();
                cfg.ConfigurePublishEvent<StacCaptureRequestEvent>();
                cfg.ConfigurePublishEvent<TransactionSettlementEvent>();
                cfg.ConfigurePublishEvent<ReconcileFailTransactionEvent>();


                cfg.BindConsumer<PaymentStatusEvent, PaymentStatusEventConsumer>(ctx, EventBusConstants.MppaService);
                cfg.BindConsumer<StoreEvent, StoreEventConsumer>(ctx, EventBusConstants.MppaService);
            });

            return services;
        }
    }
}