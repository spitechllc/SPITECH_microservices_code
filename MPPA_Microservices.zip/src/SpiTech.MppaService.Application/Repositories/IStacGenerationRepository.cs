﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.MppaService.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Repositories
{
    public interface IStacGenerationRepository : IRepository<StacGeneration>
    {
        Task<IEnumerable<StacGeneration>> GetByFilter(string stac);
    }
}
