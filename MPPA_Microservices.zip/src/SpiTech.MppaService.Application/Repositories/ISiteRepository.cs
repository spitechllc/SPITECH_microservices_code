﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Repositories
{
    public interface ISiteRepository : IRepository<Site>
    {
        Task<Site> GetByStoreId(int storeId);
        Task<Site> GetByStoreId(string siteId);
        Task<List<SiteModel>> GetSites(string[] siteIds);
        Task Update(int storeId, string siteId, string storeName);
    }
}
