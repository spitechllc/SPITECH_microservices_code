﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Repositories
{
    public interface IHostConfigrationRepository : IRepository<HostConfigration>
    {
        Task<HostConfigrationModel> GetByStoreId(int storeId);
    }
}
