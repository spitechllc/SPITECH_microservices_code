﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.MppaService.Domain.Entities;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Repositories
{
    public interface ISettlementRequestRepository : IRepository<SettlementRequest>
    {

        Task<SettlementRequest> InsertSettlement(SettlementRequest settlementRequest);

        Task<bool> UpdateSettlement(SettlementRequest settlementRequest);
    }
}
