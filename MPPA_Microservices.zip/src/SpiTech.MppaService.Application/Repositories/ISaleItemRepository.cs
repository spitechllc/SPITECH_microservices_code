﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.MppaService.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Repositories
{
    public interface ISaleItemRepository : IRepository<SaleItem>
    {
        Task<List<SaleItem>> GetSaleItemByfilter(long transactionId);
    }
}
