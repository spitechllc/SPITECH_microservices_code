﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Repositories
{
    public interface ITransactionRepository : IRepository<Transaction>
    {
        Task<Transaction> GetById(long transactionId);
        Task<Transaction> GetByUMTI(string uMTI, string merchantId);
        Task<IEnumerable<Transaction>> GetByFilter(string siteId, string settlementPeriodId);
        Task<int> GetSuccessTransactionCount(int userId);
        Task<bool> UpdatePaymentStatus(long transactionId, bool isPaymentSuccess, string paymentErrorMessage);
        Task<Transaction> GetUserInprogressTransaction(int userId, int timeOutInSec, TransactionType transactionType);
        Task<List<long>> ReconcileFailTransactions(int timeOutInSec);
    }
}
