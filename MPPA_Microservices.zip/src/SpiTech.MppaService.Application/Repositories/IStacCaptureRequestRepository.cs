﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.MppaService.Domain.Entities;

namespace SpiTech.MppaService.Application.Repositories
{
    public interface IStacCaptureRequestRepository : IRepository<StacCaptureRequest>
    {
    }
}
