﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.MppaService.Domain.Entities;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Repositories
{
    public interface IUserAppMessageRepository : IRepository<UserAppMessage>
    {
        Task<bool> IsValidRequest(int requestTypeId, string utmi, int userId);
    }
}
