﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Enums;
using SpiTech.MppaService.Domain.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Repositories
{
    public interface ICommanderMessageRepository : IRepository<CommanderMessage>
    {
        Task<IEnumerable<CommanderMessageModel>> Get(int pageIndex, int pageSize, DateTime? from, DateTime? to,
            EventBus.DomainEvents.Enums.RequestType? requestType, string uMTI,
            string siteId, string merchantId, long? TransactionId,
            CommanderMessageSortBy? sortBy, SortOrderEnum? sortOrder);
    }
}
