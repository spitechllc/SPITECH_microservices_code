﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Application.Repositories
{
    public interface ISiteProductRepository : IRepository<SiteProduct>
    {
        Task<IEnumerable<SiteProduct>> GetSiteProducts(string siteId);
        Task<bool> DeleteSiteProducts(string siteId);
        Task<IEnumerable<SiteProductModel>> GetSiteProducts(string[] siteIds);
    }
}
