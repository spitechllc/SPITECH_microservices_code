﻿using AutoMapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.MppaService.Application.Repositories;
using SpiTech.MppaService.Domain.Entities;

namespace SpiTech.MppaService.Infrastructure.Repositories
{
    public class StacCaptureRequestRepository : Repository<StacCaptureRequest>, IStacCaptureRequestRepository
    {
        public StacCaptureRequestRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
    }
}
