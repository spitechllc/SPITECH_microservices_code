﻿using AutoMapper;
using Dapper;
using DapperQueryBuilder;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.MppaService.Application.Repositories;
using SpiTech.MppaService.Domain.Entities;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Infrastructure.Repositories
{
    public class UserAppMessageRepository : Repository<UserAppMessage>, IUserAppMessageRepository
    {
        public UserAppMessageRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<bool> IsValidRequest(int requestTypeId, string utmi, int userId)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("RequestTypeId", requestTypeId);
            dynamicParams.Add("utmi", utmi);
            dynamicParams.Add("userId", userId);

            string query = "SELECT count(1) FROM [UserAppMessage] WHERE UMTI = @utmi and RequestTypeId=@RequestTypeId and UserId=@userId and IsRequestMessage=1 ";

            var result = await DbConnection.ExecuteScalarAsync<int>(query, dynamicParams, DbTransaction);

            return result == 0;
        }
    }
}
