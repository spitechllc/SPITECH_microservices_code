﻿using Dapper;
using SpiTech.ApplicationCore.Database;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.MppaService.Application.Repositories;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Infrastructure.Repositories
{
    public class SiteRepository : Repository<Site>, ISiteRepository
    {
        public SiteRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<Site> GetByStoreId(string siteId)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("siteId", siteId);

            var query = $"select * from [Site] where siteId = @siteId ";

            query += " order by CurrentHeartBeatTime desc ";

            return await DbConnection.QueryFirstOrDefaultAsync<Site>(query, dynamicParams, DbTransaction);
        }

        public async Task<Site> GetByStoreId(int storeId)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("storeId", storeId);

            var query = $"select * from [Site] where storeId= @storeId ";

            query += " order by CurrentHeartBeatTime desc ";

            return await DbConnection.QueryFirstOrDefaultAsync<Site>(query, dynamicParams, DbTransaction);
        }

        public async Task<List<SiteModel>> GetSites(string[] siteIds)
        {
            DynamicParameters dynamicParams = new();

            string query = $"select * from [Site] where 1=1 ";

            if (siteIds != null && siteIds.Any())
            {
                siteIds = siteIds.Distinct().ToArray();
                query += " and siteId in (select KeyValue from @siteIds)";
                dynamicParams.Add("siteIds", siteIds.GetTableValuedParameter("[dbo].[UdtStringKeys]", "KeyValue"));

            }

            query += " order by CurrentHeartBeatTime desc ";

            return (await DbConnection.QueryAsync<SiteModel>(query, dynamicParams, DbTransaction)).ToList();
        }

        public async Task Update(int storeId, string siteId, string storeName)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("StoreId", storeId);
            dynamicParams.Add("SiteId", siteId);
            dynamicParams.Add("StoreName", storeName);

            await DbConnection.ExecuteAsync($"UpdateSite", dynamicParams, DbTransaction, commandType: System.Data.CommandType.StoredProcedure);
        }

    }
}
