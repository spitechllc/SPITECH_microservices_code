﻿using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.MppaService.Application.Repositories;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Infrastructure.Repositories
{
    public class HostConfigrationRepository : Repository<HostConfigration>, IHostConfigrationRepository
    {
        public HostConfigrationRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<HostConfigrationModel> GetByStoreId(int storeId)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("storeId", storeId);

            return (await DbConnection.QueryFirstOrDefaultAsync<HostConfigrationModel>("select * from [HostConfigration] where storeId= @storeId", dynamicParams, DbTransaction));
        }
    }
}
