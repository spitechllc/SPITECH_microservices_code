﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.MppaService.Application.Repositories;
using SpiTech.MppaService.Domain.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Infrastructure.Repositories
{
    public class GasPumpRepository : Repository<GasPump>, IGasPumpRepository
    {
        public GasPumpRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<List<GasPump>> GetByStoreId(int storeId)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("storeId", storeId);

            return (await DbConnection.QueryAsync<GasPump>("Select * from [GasPump] where storeId = @storeId", dynamicParams, DbTransaction)).ToList();
        }
    }
}
