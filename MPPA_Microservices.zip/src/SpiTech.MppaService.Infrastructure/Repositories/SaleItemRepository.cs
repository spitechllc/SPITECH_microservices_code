﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.MppaService.Application.Repositories;
using SpiTech.MppaService.Domain.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Infrastructure.Repositories
{
    public class SaleItemRepository : Repository<SaleItem>, ISaleItemRepository
    {
        public SaleItemRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<List<SaleItem>> GetSaleItemByfilter(long transactionId)
        {
            string query = " select * from dbo.[SaleItem] where isActive=1  ";
            DynamicParameters dynamicParams = new();

            if (transactionId > 0)
            {
                query += " and TransactionId = @transactionId ";
                dynamicParams.Add("transactionId", transactionId);
            }

            return (await DbConnection.QueryAsync<SaleItem>(query, dynamicParams, DbTransaction)).ToList();
        }
    }
}
