﻿using AutoMapper;
using Dapper;
using DapperQueryBuilder;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.MppaService.Application.Repositories;
using SpiTech.MppaService.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Infrastructure.Repositories
{
    public class StacGenerationRepository : Repository<StacGeneration>, IStacGenerationRepository
    {
        public StacGenerationRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<IEnumerable<StacGeneration>> GetByFilter(string stac)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("StacGenerationId", stac);

            string query = "SELECT * FROM [StacGeneration] WHERE IsActive=1 and (StacGenerationId = @StacGenerationId or QRCodeStac = @StacGenerationId or BarCodeStac = @StacGenerationId) order by CreatedOn desc";

            return await DbConnection.QueryAsync<StacGeneration>(query, dynamicParams, DbTransaction);
        }
    }
}
