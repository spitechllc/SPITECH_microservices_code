﻿using AutoMapper;
using Dapper;
using DapperQueryBuilder;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Application.Repositories;
using SpiTech.MppaService.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Infrastructure.Repositories
{
    public class TransactionRepository : Repository<Transaction>, ITransactionRepository
    {
        public TransactionRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<Transaction> GetById(long transactionId)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("TransactionId", transactionId);

            return await DbConnection.QueryFirstOrDefaultAsync<Transaction>("SELECT * FROM [Transaction] WHERE TransactionId = @TransactionId", dynamicParams, DbTransaction);
        }

        public async Task<Transaction> GetByUMTI(string uMTI, string merchantId)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("UMTI", uMTI);
            dynamicParams.Add("merchantId", merchantId);

            return await DbConnection.QueryFirstOrDefaultAsync<Transaction>("SELECT top 1 * FROM [Transaction] WHERE UMTI = @UMTI and merchantId =@merchantId order by TransactionId desc", dynamicParams, DbTransaction);
        }

        public async Task<IEnumerable<Transaction>> GetByFilter(string siteId, string settlementPeriodId)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("siteId", siteId);
            dynamicParams.Add("settlementPeriodId", settlementPeriodId);

            string query = "SELECT * FROM [Transaction] WHERE IsActive = 1 and StatusId = 2 and siteId = @siteId and SettlementPeriodId = @settlementPeriodId";

            return await DbConnection.QueryAsync<Transaction>(query, dynamicParams, DbTransaction);
        }

        public async Task<Transaction> GetUserInprogressTransaction(int userId, int timeOutInSec, TransactionType transactionType)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("userId", userId);
            dynamicParams.Add("timeOutInSec", timeOutInSec);
            dynamicParams.Add("TransactionTypeId", (int)transactionType);

            string query = $@"SELECT * FROM [Transaction] WHERE [StatusId]=1 and userid = @userId 
                                        and DATEDIFF(s, TransactionDate, getutcdate()) <= @timeOutInSec 
                                        and TransactionTypeId = @TransactionTypeId
                                        order by TransactionId desc";

            return await DbConnection.QueryFirstOrDefaultAsync<Transaction>(query, dynamicParams, DbTransaction);
        }

        public async Task<int> GetSuccessTransactionCount(int userId)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("userId", userId);

            string query = "SELECT count(1) FROM [Transaction] WHERE IsActive = 1 and StatusId = 2 and UserId = @userId and FinalAmount > 0";

            return await DbConnection.QueryFirstOrDefaultAsync<int>(query, dynamicParams, DbTransaction);
        }

        public async Task<bool> UpdatePaymentStatus(long transactionId, bool isPaymentSuccess, string paymentErrorMessage)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("TransactionId", transactionId);
            dynamicParams.Add("IsPaymentSuccess", isPaymentSuccess ? 1 : 0);
            dynamicParams.Add("PaymentErrorMessage", paymentErrorMessage);
            dynamicParams.Add("UpdatedBy", GetActionUserId());

            return (await DbConnection.ExecuteAsync("Update [Transaction] set IsPaymentSuccess=@IsPaymentSuccess, PaymentErrorMessage=@PaymentErrorMessage , UpdatedOn=getutcdate(), UpdatedBy=@UpdatedBy  WHERE TransactionId = @TransactionId", dynamicParams, DbTransaction)) > 0;
        }

        public async Task<List<long>> ReconcileFailTransactions(int timeOutInSec)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("timeOutInSec", timeOutInSec);

            var result = await DbConnection.QueryMultipleAsync(" Select TransactionId From [Transaction] WHERE [StatusId]=1 and TransactionDate < DATEADD(second, -@timeOutInSec, GETUTCDATE()) ;" +
                " Update [Transaction] set [StatusId]=3, [MppaErrorMessage] ='Cancelled/No Response '+isnull([MppaErrorMessage],''),[UpdatedOn]=GETUTCDATE()  WHERE [StatusId]=1 and TransactionDate < DATEADD(second, -@timeOutInSec, GETUTCDATE()) ;"
                , dynamicParams, DbTransaction);

            return result.Read<long>().AsList();
        }
    }
}
