﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.MppaService.Application.Repositories;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Domain.Entities;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Infrastructure.Repositories
{
    public class SettlementRequestRepository : Repository<SettlementRequest>, ISettlementRequestRepository
    {
        private readonly ISettlementDetailRepository settlementDetailRepository;
        public SettlementRequestRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
            settlementDetailRepository = ((IUnitOfWork)unitOfWork).SettlementDetails;
        }

        public async Task<SettlementRequest> InsertSettlement(SettlementRequest settlementRequest)
        {
            if (settlementRequest != null)
            {
                settlementRequest.SettlementRequestId = await Add(settlementRequest);

                if (settlementRequest.SettlementDetails != null && settlementRequest.SettlementDetails.Any())
                {
                    foreach (SettlementDetail settlementDetail in settlementRequest.SettlementDetails)
                    {
                        settlementDetail.SettlementRequestId = settlementRequest.SettlementRequestId;
                        settlementDetail.SettlementDetailId = await settlementDetailRepository.Add(settlementDetail);
                    }
                }

                return settlementRequest;
            }

            return null;
        }

        public async Task<bool> UpdateSettlement(SettlementRequest settlementRequest)
        {
            bool result = false;

            if (settlementRequest != null)
            {
                result = await Update(settlementRequest);

                if (settlementRequest.IsReconciled)
                {
                    DynamicParameters dynamicParams = new();

                    dynamicParams.Add("siteId", settlementRequest.SiteId);
                    dynamicParams.Add("settlementPeriodId", settlementRequest.SettlementPeriodId);

                    dynamicParams.Add("settlementRequestId", settlementRequest.SettlementRequestId);
                    dynamicParams.Add("reconciledDate", System.DateTime.UtcNow);
                    dynamicParams.Add("UpdatedBy", GetActionUserId());

                    await DbConnection.ExecuteAsync("Update [Transaction] Set [IsReconciled]=1 , SettlementRequestId = @settlementRequestId, ReconciledDate = @reconciledDate, UpdatedOn=getutcdate(), UpdatedBy=@UpdatedBy Where siteId = @siteId and SettlementPeriodId = @settlementPeriodId", dynamicParams, DbTransaction);

                }
            }

            return result;
        }

    }
}
