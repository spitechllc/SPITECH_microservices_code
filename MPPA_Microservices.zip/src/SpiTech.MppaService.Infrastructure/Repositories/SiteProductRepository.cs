﻿using AutoMapper;
using Dapper;
using DapperQueryBuilder;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.MppaService.Application.Repositories;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Infrastructure.Repositories
{
    public class SiteProductRepository : Repository<SiteProduct>, ISiteProductRepository
    {
        public SiteProductRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<bool> DeleteSiteProducts(string siteId)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("siteId", siteId);

            return (await DbConnection.ExecuteAsync("Delete from [SiteProduct] WHERE SiteId= @siteId", dynamicParams, DbTransaction)) > 0;
        }

        public async Task<IEnumerable<SiteProduct>> GetSiteProducts(string siteId)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("siteId", siteId);

            return (await DbConnection.QueryAsync<SiteProduct>("SELECT * FROM [SiteProduct] WHERE SiteId= @siteId", dynamicParams, DbTransaction)).ToList();
        }

        public async Task<IEnumerable<SiteProductModel>> GetSiteProducts(string[] siteIds)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("siteIds", siteIds);

            return (await DbConnection.QueryAsync<SiteProductModel>("SELECT distinct SiteId, OriginalAmountUnitPrice, UnitMeasure, Description, PriceTier  FROM [SiteProduct] WHERE SiteId in @siteIds order by SiteId, OriginalAmountUnitPrice Asc ", dynamicParams, DbTransaction)).ToList();
        }
    }
}
