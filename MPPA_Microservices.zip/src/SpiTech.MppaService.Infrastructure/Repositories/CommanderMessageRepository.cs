﻿using AutoMapper;
using Dapper;
using DapperQueryBuilder;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.MppaService.Application.Repositories;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Enums;
using SpiTech.MppaService.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Infrastructure.Repositories
{
    public class CommanderMessageRepository : Repository<CommanderMessage>, ICommanderMessageRepository
    {
        public CommanderMessageRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<IEnumerable<CommanderMessageModel>> Get(int pageIndex, int pageSize, DateTime? from, DateTime? to,
            EventBus.DomainEvents.Enums.RequestType? requestType, string uMTI, 
            string siteId, string merchantId, long? TransactionId,
            CommanderMessageSortBy? sortBy, SortOrderEnum? sortOrder)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("UMTI", uMTI);

            string query = "SELECT Count(1) over() as TotalRecord, * FROM [CommanderMessage] WHERE IsActive = 1 ";

            if (requestType.HasValue && ((int)requestType.Value) > 0)
            {
                query += " and RequestTypeId =  @requestTypeId ";
                dynamicParams.Add("requestTypeId", (int)requestType);
            }

            if (TransactionId.HasValue && TransactionId.Value > 0)
            {
                query += " and TransactionId =  @TransactionId ";
                dynamicParams.Add("TransactionId", TransactionId);
            }

            if (!string.IsNullOrWhiteSpace(uMTI))
            {
                dynamicParams.Add("UMTI", uMTI);
                query += " and UMTI = @UMTI ";
            }

            if (!string.IsNullOrWhiteSpace(siteId))
            {
                dynamicParams.Add("siteId", siteId);
                query += " and siteId = @siteId ";
            }

            if (!string.IsNullOrWhiteSpace(merchantId))
            {
                dynamicParams.Add("merchantId", merchantId);
                query += " and merchantId = @merchantId ";
            }

            if (from.HasValue && to.HasValue)
            {
                dynamicParams.Add("start", from.Value);
                dynamicParams.Add("end", to.Value);

                query += " and CreatedOn >= @start and CreatedOn <= @end ";
            }

            if (sortBy != null && sortOrder != null && sortBy.Value != CommanderMessageSortBy.None && sortOrder.Value != SortOrderEnum.None)
            {
                query += $" Order by {sortBy.Value} {sortOrder.Value}";
            }
            else
            {
                query += " Order by CreatedOn desc";
            }

            if (pageIndex > 0 && pageSize > 0)
            {
                int skipvalue = (pageIndex - 1) * pageSize;
                query += $" OFFSET {skipvalue} ROWS FETCH NEXT {pageSize} ROWS ONLY ";
            }

            return (await DbConnection.QueryAsync<CommanderMessageModel>(query, dynamicParams, DbTransaction)).ToList();
        }
    }
}
