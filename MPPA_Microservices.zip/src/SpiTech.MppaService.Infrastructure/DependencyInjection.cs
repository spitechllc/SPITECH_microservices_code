﻿using AutoMapper;
using FluentValidation;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Infrastructure.UnitOfWorks;
using System.Reflection;

namespace SpiTech.MppaService.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            string connectionString = configuration.GetConnectionString("MPPA");
            services
                .AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());

            services.AddScoped<IUnitOfWork, UnitOfWork>(serviceProvider => new UnitOfWork(connectionString, serviceProvider));

            DapperExtensions.DapperExtensions.SetMappingAssemblies(new[]{
                    typeof(DependencyInjection).Assembly
            });
            return services;
        }
    }
}