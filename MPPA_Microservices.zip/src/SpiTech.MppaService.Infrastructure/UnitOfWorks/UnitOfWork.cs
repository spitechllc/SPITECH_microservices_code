﻿using AutoMapper;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.MppaService.Application.Repositories;
using SpiTech.MppaService.Application.UnitOfWorks;
using SpiTech.MppaService.Infrastructure.Repositories;
using System.Data;

namespace SpiTech.MppaService.Infrastructure.UnitOfWorks
{
    public sealed class UnitOfWork : BaseUnitOfWork, IUnitOfWork
    {
        public UnitOfWork(string connectionString,
                         System.IServiceProvider serviceProvider,
                        IsolationLevel isolationLevel = IsolationLevel.ReadCommitted)
                        : base(connectionString, serviceProvider, isolationLevel)
        {
        }

        private IPOSRepository _poseS = null;
        private IGasPumpRepository _gasPumps = null;
        private IHostConfigrationRepository _hostConfigrations = null;
        private IRequestTypeRepository _requestTypes = null;
        private ITransactionRepository _transactions = null;
        private ISiteRepository _sites = null;
        private ISiteProductRepository _siteProducts = null;
        private IHostMPPARepository _hostMPPAs = null;
        private IAdapterRepository _adapters = null;
        private ISettlementRequestRepository _settlementRequests = null;
        private ISettlementDetailRepository _settlementDetails = null;
        private IStacCaptureRequestRepository _stacCaptureRequests = null;
        private IStacGenerationRepository _stacGenerations = null;
        private ICommanderMessageRepository _commanderMessages = null;
        private ISaleItemRepository _saleItems = null;
        private IUserAppMessageRepository _userAppMessages = null;

        public IPOSRepository PoseS => _poseS ??= new POSRepository(this, serviceProvider);
        public IGasPumpRepository GasPumps => _gasPumps ??= new GasPumpRepository(this, serviceProvider);
        public IHostConfigrationRepository HostConfigrations => _hostConfigrations ??= new HostConfigrationRepository(this, serviceProvider);
        public IRequestTypeRepository RequestTypes => _requestTypes ??= new RequestTypeRepository(this, serviceProvider);
        public ITransactionRepository Transactions => _transactions ??= new TransactionRepository(this, serviceProvider);
        public ISiteRepository Sites => _sites ??= new SiteRepository(this, serviceProvider);
        public ISiteProductRepository SiteProducts => _siteProducts ??= new SiteProductRepository(this, serviceProvider);
        public IHostMPPARepository HostMPPAs => _hostMPPAs ??= new HostMPPARepository(this, serviceProvider);
        public IAdapterRepository Adapters => _adapters ??= new AdapterRepository(this, serviceProvider);
        public ISettlementRequestRepository SettlementRequests => _settlementRequests ??= new SettlementRequestRepository(this, serviceProvider);
        public ISettlementDetailRepository SettlementDetails => _settlementDetails ??= new SettlementDetailRepository(this, serviceProvider);
        public IStacCaptureRequestRepository StacCaptureRequests => _stacCaptureRequests ??= new StacCaptureRequestRepository(this, serviceProvider);
        public IStacGenerationRepository StacGenerations => _stacGenerations ??= new StacGenerationRepository(this, serviceProvider);
        public ICommanderMessageRepository CommanderMessages => _commanderMessages ??= new CommanderMessageRepository(this, serviceProvider);
        public ISaleItemRepository SaleItems => _saleItems ??= new SaleItemRepository(this, serviceProvider);
        public IUserAppMessageRepository UserAppMessages => _userAppMessages ??= new UserAppMessageRepository(this, serviceProvider);

        public override void ResetRepositories()
        {
            _poseS = null;
            _gasPumps = null;
            _hostConfigrations = null;
            _requestTypes = null;
            _transactions = null;
            _sites = null;
            _siteProducts = null;
            _hostMPPAs = null;
            _adapters = null;
            _settlementRequests = null;
            _settlementDetails = null;
            _stacCaptureRequests = null;
            _stacGenerations = null;
            _commanderMessages = null;
            _saleItems = null;
            _userAppMessages = null;
        }
    }
}
