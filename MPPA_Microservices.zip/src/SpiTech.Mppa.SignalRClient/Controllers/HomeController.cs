﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SpiTech.Mppa.SignalRClient.Models;
using System.Diagnostics;
using System.Threading.Tasks;
using Controller = Microsoft.AspNetCore.Mvc.Controller;

namespace SpiTech.Mppa.SignalRClient.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration configuration;

        public HomeController(ILogger<HomeController> logger,IConfiguration configuration)
        {
            _logger = logger;
            this.configuration = configuration;
        }

        public IActionResult Index()
        {
            return View();
        }

       [Authorize]
        public async Task<IActionResult> SignalR()
        {
            dynamic model = new System.Dynamic.ExpandoObject();
            model.AccessToken = await HttpContext.GetTokenAsync("access_token");
            model.RefreshToken = await HttpContext.GetTokenAsync("refresh_token");
            model.WsEnabled = configuration.GetValue<bool>("SignalRConfig:WSEnable");
            model.HubUrl = configuration.GetValue<string>("SignalRConfig:HubUrl");

            return View("SignalR", model);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult Logout()
        {
            return SignOut("Cookie", "oidc");
        }
    }
}
