﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Application.Queries.GetSiteProductBySiteId;
using SpiTech.MppaService.Application.Queries.GetSiteProducts;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class SiteProductController : ControllerBase
    {
        private readonly IMediator _mediator;
        public SiteProductController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Returns Collection of Site Products by site ids
        /// </summary>
        /// <param name="request">Object of GetSiteProductsQuery</param>
        /// <returns>It will return ResponseList in the form of SiteProductModel</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_SiteProduct_GetById")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet()]
        public async Task<ActionResult<ResponseList<SiteProductModel>>> GetSiteProducts([FromQuery] GetSiteProductsQuery request)
        {
            ResponseList<SiteProductModel> result = new()
            {
                Data = await _mediator.Send(request).ConfigureAwait(false)
            };
            return Ok(result);
        }

        /// <summary>
        /// Returns Collection of site product based on site id
        /// </summary>
        /// <param name="siteId">Varriable of string</param>
        /// <returns>It will return IEnumerable in the form of SiteProduct</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_SiteProduct_BySiteId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("BySiteId/{siteId}")]
        public async Task<ActionResult<IEnumerable<SiteProduct>>> GetSiteProductBySiteId([FromRoute] string siteId)
        {
            return Ok(await _mediator.Send(new GetSiteProductBySiteIdQuery() { SiteId = siteId }).ConfigureAwait(false));
        }
    }
}
