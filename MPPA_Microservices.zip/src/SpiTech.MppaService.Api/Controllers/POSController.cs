﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Application.Commands.CreatePOS;
using SpiTech.MppaService.Application.Commands.UpdatePOS;
using SpiTech.MppaService.Application.Queries.GetPosById;
using SpiTech.MppaService.Application.Queries.GetPosByStoreId;
using SpiTech.MppaService.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.MppaService.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class POSController : ControllerBase
    {
        private readonly IMediator _mediator;
        public POSController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Returns Details of Pos System by pos id
        /// </summary>
        /// <param name="posId">Varriable of int</param>
        /// <returns>It will return in the form of POSModel</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_POS_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("{posId}")]
        public async Task<ActionResult<POSModel>> GetById([FromRoute] int posId)
        {
            return Ok(await _mediator.Send(new GetPosByIdQuery() { PosId = posId }).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns collection of pos system based on store id
        /// </summary>
        /// <param name="storeId">Object of int</param>
        /// <returns>It will return ResponseList in the form of POSModel</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_POS_ByStoreId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("ByStoreId/{storeId}")]
        public async Task<ActionResult<ResponseList<POSModel>>> GetPosByStoreId([FromRoute] int storeId)
        {
            return Ok(await _mediator.Send(new GetPosByStoreIdQuery() { StoreId = storeId }).ConfigureAwait(false));
        }

        /// <summary>
        /// Add pos system for store
        /// </summary>
        /// <param name="model">Object of CreatePosCommand</param>
        /// <returns>It will return in the form of int</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_POS_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost()]
        public async Task<ActionResult<int>> Create(CreatePosCommand model)
        {
            return Ok(await _mediator.Send(model).ConfigureAwait(false));
        }

        /// <summary>
        /// Update pos sytem for store
        /// </summary>
        /// <param name="model">Object of UpdatePosCommand</param>
        /// <returns>It will return in the form of bool</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_POS_Patch")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch()]
        public async Task<ActionResult<bool>> Update(UpdatePosCommand model)
        {
            return Ok(await _mediator.Send(model).ConfigureAwait(false));
        }
    }
}
