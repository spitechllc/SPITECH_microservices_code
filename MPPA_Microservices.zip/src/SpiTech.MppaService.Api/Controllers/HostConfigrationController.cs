﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Application.Commands.CreateHostConfigration;
using SpiTech.MppaService.Application.Commands.UpdateHostConfigration;
using SpiTech.MppaService.Application.Queries.GetAdapter;
using SpiTech.MppaService.Application.Queries.GetHostConfigrationByStoreId;
using SpiTech.MppaService.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.MppaService.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class HostConfigrationController : ControllerBase
    {
        private readonly IMediator _mediator;
        public HostConfigrationController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Returns Host configuration for store
        /// </summary>
        /// <param name="storeId">Varriable of int</param>
        /// <returns>It will return in the form of HostConfigrationModel</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_HostConfigration_ByStoreId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("ByStoreId/{storeId}")]
        public async Task<ActionResult<HostConfigrationModel>> GetByStoreId(int storeId)
        {
            return Ok(await _mediator.Send(new GetHostConfigrationByStoreIdQuery() { StoreId = storeId }).ConfigureAwait(false));
        }

        /// <summary>
        /// Add Host configuration for store
        /// </summary>
        /// <param name="model">Object of CreateHostConfigrationCommand</param>
        /// <returns>It will return in the form of int</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_HostConfigration_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost]
        public async Task<ActionResult<int>> Create(CreateHostConfigrationCommand model)
        {
            return Ok(await _mediator.Send(model).ConfigureAwait(false));
        }

        /// <summary>
        /// Update host configuration details for store
        /// </summary>
        /// <param name="model">Object of UpdateHostConfigrationCommand</param>
        /// <returns>It will return in the form of Bool</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_HostConfigration_Patch")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch]
        public async Task<ActionResult<bool>> Update(UpdateHostConfigrationCommand model)
        {
            return Ok(await _mediator.Send(model).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns collection of adapter details
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of AdapterModel</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_HostConfigration_Adapter")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("Adapter")]
        public async Task<ActionResult<ResponseList<AdapterModel>>> GetAdapter()
        {
            return Ok(await _mediator.Send(new GetAdapterQuery()).ConfigureAwait(false));
        }
    }
}
