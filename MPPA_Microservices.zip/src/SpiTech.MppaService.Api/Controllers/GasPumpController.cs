﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.MppaService.Application.Commands.CreateGasPump;
using SpiTech.MppaService.Application.Commands.UpdateGasPump;
using SpiTech.MppaService.Application.Queries.GetGasPumpById;
using SpiTech.MppaService.Application.Queries.GetGasPumpByStoreId;
using SpiTech.MppaService.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.MppaService.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class GasPumpController : ControllerBase
    {
        private readonly IMediator _mediator;
        public GasPumpController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Returns gas pump details by id
        /// </summary>
        /// <param name="GasPumpId">Varriable of int</param>
        /// <returns>It will return in the form of GasPumpModel</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_GasPump_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("{GasPumpId}")]
        public async Task<ActionResult<GasPumpModel>> GetById([FromRoute] int GasPumpId)
        {
            return Ok(await _mediator.Send(new GetGasPumpByIdQuery() { GasPumpId = GasPumpId }).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns gas pump details for the store by store id
        /// </summary>
        /// <param name="storeId">Varriable of int</param>
        /// <returns>It will return ResponseList in the form of GasPumpModel</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_GasPump_ByStoreId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("ByStoreId/{storeId}")]
        public async Task<ActionResult<ResponseList<GasPumpModel>>> GetGasPumpByStoreId([FromRoute] int storeId)
        {
            return Ok(await _mediator.Send(new GetGasPumpByStoreIdQuery() { StoreId = storeId }).ConfigureAwait(false));
        }

        /// <summary>
        /// Create gas pump for store
        /// </summary>
        /// <param name="model">Object of CreateGasPumpCommand</param>
        /// <returns>It will return in the form of int</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_GasPump_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost()]
        public async Task<ActionResult<int>> Create(CreateGasPumpCommand model)
        {
            return Ok(await _mediator.Send(model).ConfigureAwait(false));
        }

        /// <summary>
        /// Update gas pump information for store
        /// </summary>
        /// <param name="model">Object of UpdateGasPumpCommand</param>
        /// <returns>It will return in the form of bool</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_GasPump_Patch")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch()]
        public async Task<ActionResult<bool>> Update(UpdateGasPumpCommand model)
        {
            return Ok(await _mediator.Send(model).ConfigureAwait(false));
        }
    }
}
