﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.MppaService.Application.Interfaces.HostServers;
using SpiTech.MppaService.Application.Queries.GetCommanderMessages;
using SpiTech.MppaService.Application.Queries.GetCommanderStatus;
using SpiTech.MppaService.Application.Queries.GetCommanderStatuses;
using SpiTech.MppaService.Application.Queries.GetSiteStatuses;
using SpiTech.MppaService.Domain.Models;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class CommanderController : ControllerBase
    {
        private readonly IMediator mediator;
        private readonly IMppaSessionManager mppaSessionManager;

        public CommanderController(IMediator mediator, IMppaSessionManager mppaSessionManager)
        {
            this.mediator = mediator;
            this.mppaSessionManager = mppaSessionManager;
        }
        /// <summary>
        /// Returns Site Status by site Id
        /// </summary>
        /// <param name="siteId">Varriable of string</param>
        /// <returns>It will return in the form of SiteModel</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_Commander_Status")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("Status/{siteId}")]
        public async Task<ActionResult<SiteModel>> GetStatus([FromRoute] string siteId)
        {
            return Ok(await mediator.Send(new GetCommanderStatusQuery() { SiteId = siteId }).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns Sites status based on ids and heartbeat interval
        /// </summary>
        /// <param name="statusesQuery">object of GetCommanderStatusesQuery</param>
        /// <returns>It will return ResponseList in the form of SiteModel</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_Commander_Statuses")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("Statuses")]
        public async Task<ActionResult<ResponseList<SiteModel>>> GetStatus([FromBody] GetCommanderStatusesQuery statusesQuery)
        {
            return Ok(new ResponseList<SiteModel>(await mediator.Send(statusesQuery).ConfigureAwait(false)));
        }

        /// <summary>
        /// Returns Sites based on online status
        /// </summary>
        /// <param name="query">object of GetSiteStatusesQuery</param>
        /// <returns>It will return ResponseList in the form of SiteModel</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_Commander_SiteStatuses")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("SiteStatuses")]
        public async Task<ActionResult<ResponseList<SiteModel>>> GetSiteStatuses([FromQuery] GetSiteStatusesQuery query)
        {
            return Ok(new ResponseList<SiteModel>(await mediator.Send(query).ConfigureAwait(false)));
        }

        /// <summary>
        /// Get Message from commander based on flters
        /// </summary>
        /// <param name="query">Object of GetCommanderMessagesQuery</param>
        /// <returns>It will return PaginatedList in the form of CommanderMessageModel</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_Commander_messages")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("messages")]
        public async Task<ActionResult<PaginatedList<CommanderMessageModel>>> Messages([FromQuery] GetCommanderMessagesQuery query)
        {
            return Ok(await mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns Site connection status with mppa
        /// </summary>
        /// <param name="siteId">Varriable of string</param>
        /// <returns>It will return List in the form of MppaSessionStatus</returns>
        [ApiPermissionAuthorize(Permissions = "Mppaapi_Commander_site-connections")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("site-connections")]
        public async Task<ActionResult<List<MppaSessionStatus>>> GetSiteConnections([FromQuery] string siteId)
        {
            return Ok(await this.mppaSessionManager.GetMppaSessionStatus(siteId).ConfigureAwait(false));
        }
    }
}
