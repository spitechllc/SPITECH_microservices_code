using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using SpiTech.Application.Logging;
using SpiTech.Application.Logging.Extensions;
using System;

namespace SpiTech.MppaService.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            LoggerExtensions.InitializeLogger();
            Logger.Information("MPPA API starting");
            try
            {
                IHost host = CreateHostBuilder(args).Build();
                host.Run();
                Logger.Information($"MPPA Application started in environment: {Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")}");
            }
            catch (Exception e)
            {
                Logger.Error("MPPA API Server Host terminated unexpected", e);
                throw;
            }
            finally
            {
                Logger.Information("MPPA API Server stopped");
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            return Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseLogger();
                    webBuilder.UseStartup<Startup>();
                });
        }
    }
}
