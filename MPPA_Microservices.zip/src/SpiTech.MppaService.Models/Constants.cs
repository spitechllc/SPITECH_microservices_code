﻿namespace SpiTech.MppaService.Domain
{
    public static class Constants
    {
        public const string NamespaceVersion = "v02";
        public const string Version = "2.0";

        public const string SuccessMessageCode = "Success";
        public const string SuccessOverallResult = "Success";
        public const string SuccessResponseCode = "00000";

        public const string FailMessageCode = "Fail";
        public const string FailOverallResult = "Fail";
        public const string SettlementFailResponseCode = "08008";
        public const string StacInvalidFailResponseCode = "10004";
        public const string StacGenericFailResponseCode = "10001";


        public const string Mobile = "Mobile";
        public const string Commander = "Commander";
        public const string MPPA = "MPPA";

        public static string[] InvoiceMarkers = new[] { "TRAN#", "INVOICE" };

        public static class DashBoardEvent
        {
            public const string Store = "Store";
            public const string Transaction = "Transaction";
        }
    }

    public static class ProcessConstants
    {
        public const string ReserveSuccess = "ReserveSuccess";
        public const string ReserveInprogress = "ReserveInprogress";
        public const string ReserveError = "ReserveError";
        public const string ReserveCancelled = "ReserveCancelled";
        public const string ReserveCancelInprogress = "ReserveCancelInprogress";
        public const string ReserveCancelError = "ReserveCancelError";

        public const string AuthSuccess = "AuthSuccess";
        public const string AuthError = "AuthError";
        public const string AuthProcessName = "Auth";

        public const string FuelingSuccess = "FuelingSuccess";
        public const string FuelingError = "FuelingError";
        public const string FuelingProcessName = "Fueling";

        public const string MobileTransactionDataSuccess = "MobileTransactionDataSuccess";
        public const string MobileTransactionDataError = "MobileTransactionDataError";
        public const string MobileTransactionDataProcessName = "MobileTransactionData";
    }
}
