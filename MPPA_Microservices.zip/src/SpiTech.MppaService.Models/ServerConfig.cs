﻿namespace SpiTech.MppaService.Domain
{
    public class ServerConfig
    {
        public string Host { get; set; }
        public int Port { get; set; }
        public bool IsSSLOn { get; set; }
        public string SSlCertificateName { get; set; }
        public string Password { get; set; }
        public string HostMPPAIdentifier { get; set; }
    }
}
