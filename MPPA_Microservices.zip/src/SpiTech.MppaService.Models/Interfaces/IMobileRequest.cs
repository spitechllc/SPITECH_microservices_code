﻿using MediatR;

namespace SpiTech.MppaService.Domain.Interfaces
{
    public interface IMobileRequest : INotification
    {
    }
}
