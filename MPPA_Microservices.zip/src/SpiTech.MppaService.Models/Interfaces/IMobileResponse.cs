﻿namespace SpiTech.MppaService.Domain.Interfaces
{
    public interface IMobileResponse
    {
        int UserId { get; set; }
    }
}
