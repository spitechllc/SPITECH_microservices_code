﻿namespace SpiTech.MppaService.Domain.Models
{
    public class POSModel
    {
        public int PosId { get; set; }
        public int StoreId { get; set; }
        public string StationNumber { get; set; }
        public string StationSystemId { get; set; }
        public string StationIPAddress { get; set; }
        public string QRCode { get; set; }
        public string BarCode { get; set; }
        public string NetworkType { get; set; }
        public string Port { get; set; }
    }
}
