﻿namespace SpiTech.MppaService.Domain.Models
{
    public class GasPumpModel
    {
        public int GasPumpId { get; set; }
        public int StoreId { get; set; }
        public int PosId { get; set; }
        public string PumpNumber { get; set; }
        public string PumpSystemId { get; set; }
        public string QRCode { get; set; }
        public string BarCode { get; set; }
    }
}
