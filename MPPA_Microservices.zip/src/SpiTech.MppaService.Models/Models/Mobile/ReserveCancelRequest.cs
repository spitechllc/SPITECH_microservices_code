﻿namespace SpiTech.MppaService.Domain.Models.Mobile
{
    public class ReserveCancelRequest
    {
        public string UMTI { get; set; }
    }
}
