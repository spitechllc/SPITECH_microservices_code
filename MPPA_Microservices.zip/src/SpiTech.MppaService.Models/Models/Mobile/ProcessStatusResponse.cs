﻿using SpiTech.MppaService.Domain.Interfaces;

namespace SpiTech.MppaService.Domain.Models.Mobile
{
    public class ProcessStatusResponse : IMobileResponse
    {
        public string UMTI { get; set; }
        public int UserId { get; set; }
        public string SiteId { get; set; }
        public string Status { get; set; }
        public string ProcessName { get; set; }
        public bool Success { get; set; }
        public string Erorr { get; set; }
    }
}
