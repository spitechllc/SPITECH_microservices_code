﻿using SpiTech.EventBus.DomainEvents.Enums;

namespace SpiTech.MppaService.Domain.Models.Mobile
{
    public class ReserveRequest
    {
        public string DeviceToken { get; set; }
        public DeviceType DeviceType { get; set; }
        public string SiteId { get; set; }
        public decimal CardAmount { get; set; }
        public decimal WalletAmount { get; set; }
        public int UserPaymentMethodId { get; set; }
        public int FuelingPositionId { get; set; }
    }
}
