﻿using SpiTech.EventBus.DomainEvents.Enums;

namespace SpiTech.MppaService.Domain.Models.Mobile
{
    public class StacGenerationRequest
    {
        public string DeviceToken { get; set; }
        public DeviceType DeviceType { get; set; }
        public string SiteId { get; set; }
    }
}
