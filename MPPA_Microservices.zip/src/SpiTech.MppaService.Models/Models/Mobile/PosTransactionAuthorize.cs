﻿namespace SpiTech.MppaService.Domain.Models.Mobile
{
    public class PosTransactionAuthorize
    {
        public string UMTI { get; set; }
        public int UserPaymentMethodId { get; set; }
        public decimal CardAmount { get; set; }
        public decimal WalletAmount { get; set; }
        public bool IsAuthorize { get; set; }
    }
}
