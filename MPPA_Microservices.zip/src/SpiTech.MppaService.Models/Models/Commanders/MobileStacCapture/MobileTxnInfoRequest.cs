﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileStacCapture
{
    public class MobileTxnInfoRequest : MobileTxnInfoBase
    {
        public string POSTransNumber { get; set; }

        [XmlElement("WorkstationID")]
        public string WorkstationId { get; set; }
        public string SiteMPPAIdentifier { get; set; }
    }
}
