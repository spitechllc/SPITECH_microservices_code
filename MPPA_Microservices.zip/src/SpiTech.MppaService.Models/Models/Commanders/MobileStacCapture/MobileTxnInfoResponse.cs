﻿namespace SpiTech.MppaService.Domain.Models.Commanders.MobileStacCapture
{
    public class MobileTxnInfoResponse : MobileTxnInfoRequest
    {
        public string HostMPPAIdentifier { get; set; }
    }
}
