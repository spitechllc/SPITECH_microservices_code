﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileStacCapture
{
    [XmlRoot(ElementName = "NAXMLMobile", Namespace = "http://www.conexxus.org/schema/naxml/mobile/" + Constants.NamespaceVersion)]
    public class StacCaptureCommanderRequest : MessageCommand
    {
        public MobileTxnInfoRequest MobileTxnInfo { get; set; }
        public MobileSTACCaptureRequest MobileSTACCaptureRequest { get; set; }
    }

    public class MobileSTACCaptureRequest
    {
        [XmlAttribute(AttributeName = "stac")]
        public string Stac { get; set; }

        [XmlAttribute(AttributeName = "requestAmount")]
        public decimal RequestAmount { get; set; }
    }
}
