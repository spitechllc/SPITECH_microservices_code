﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders
{

    [XmlRoot(ElementName = "PumpProducts")]
    public class PumpProducts
    {
        [XmlElement(ElementName = "POSCode")]
        public string POSCode { get; set; }

        [XmlElement(ElementName = "POSCodeModifier")]
        public string POSCodeModifier { get; set; }

        [XmlElement(ElementName = "ProductCode")]
        public string ProductCode { get; set; }

        [XmlElement(ElementName = "OriginalAmount")]
        public ItemAmount OriginalAmount { get; set; }

        [XmlElement(ElementName = "AdjustedAmount")]
        public ItemAmount AdjustedAmount { get; set; }

        [XmlElement(ElementName = "UnitMeasure")]
        public string UnitMeasure { get; set; }

        [XmlElement(ElementName = "Quantity")]
        public decimal Quantity { get; set; }

        [XmlElement(ElementName = "Description")]
        public string Description { get; set; }

        [XmlElement(ElementName = "PriceTier")]
        public string PriceTier { get; set; }

        [XmlElement(ElementName = "MerchandiseCode")]
        public string MerchandiseCode { get; set; }

        [XmlElement(ElementName = "OutdoorPosition")]
        public int OutdoorPosition { get; set; }

        [XmlAttribute(AttributeName = "itemID")]
        public string ItemId { get; set; }
    }
}