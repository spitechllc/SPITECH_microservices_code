﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders
{
    public class ItemAmount
    {
        [XmlElement(ElementName = "Amount")]
        public decimal Amount { get; set; }

        [XmlElement(ElementName = "UnitPrice")]
        public decimal UnitPrice { get; set; }
    }
}
