﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileFinalizes
{
    [XmlRoot(ElementName = "NAXMLMobile", Namespace = "http://www.conexxus.org/schema/naxml/mobile/" + Constants.NamespaceVersion)]
    public class FinalizeCommanderRequest : MessageCommand
    {
        public MobileTxnInfoRequest MobileTxnInfo { get; set; }
        public MobileFinalizeRequest MobileFinalizeRequest { get; set; }
    }

    public class MobileFinalizeRequest
    {
        public PaymentInfo PaymentInfo { get; set; }
        public ItemsPurchased ItemsPurchased { get; set; }
    }
}
