﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileFinalizes
{
    public class PaymentInfo : PaymentInfoBase
    {
        [XmlAttribute(AttributeName = "finalAmount")]
        public decimal FinalAmount { get; set; }
    }
}