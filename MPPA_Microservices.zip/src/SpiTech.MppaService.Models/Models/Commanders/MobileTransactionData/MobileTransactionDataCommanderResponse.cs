﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileTransactionData
{
    [XmlRoot(ElementName = "NAXMLMobile", Namespace = "http://www.conexxus.org/schema/naxml/mobile/" + Constants.NamespaceVersion)]
    public class MobileTransactionDataCommanderResponse : MessageCommand
    {
        public MobileTxnInfoResponse MobileTxnInfo { get; set; }
        public MobileTransactionDataResponse MobileTransactionDataResponse { get; set; }
    }

    public class MobileTransactionDataResponse
    {
        public Response Response { get; set; }

        public PaymentInfo PaymentInfo { get; set; }

        public ItemsPurchased ItemsPurchased { get; set; }
    }

    public class PaymentInfo
    {
        [XmlAttribute(AttributeName = "preAuthAmount")]
        public decimal PreAuthAmount { get; set; }

        [XmlAttribute(AttributeName = "finalAmount")]
        public decimal FinalAmount { get; set; }
    }

    [XmlRoot(ElementName = "ItemsPurchased")]
    public class ItemsPurchased
    {
        [XmlElement(ElementName = "SaleItem")]
        public SaleItem[] SaleItems { get; set; }
    }

    public class SaleItem
    {
        [XmlAttribute(AttributeName = "itemID")]
        public string ItemId { get; set; }

        [XmlAttribute(AttributeName = "evaluateOnly")]
        public bool EvaluateOnly { get; set; }

        [XmlAttribute(AttributeName = "itemStatus")]
        public string ItemStatus { get; set; }

        [XmlAttribute(AttributeName = "priceChangeEligible")]
        public bool PriceChangeEligible { get; set; }

        public string POSCode { get; set; }
        public string POSCodeModifier { get; set; }
        public string POSCodeFormat { get; set; }
        public string ProductCode { get; set; }
        public ItemAmount OriginalAmount { get; set; }
        public ItemAmount AdjustedAmount { get; set; }
        public string UnitMeasure { get; set; }
        public decimal Quantity { get; set; }
        public string AdditionalProductInfo { get; set; }
        public string Description { get; set; }
        public string PriceTier { get; set; }
        public double SellingUnits { get; set; }
        public string ServiceLevel { get; set; }
        public string OutdoorPosition { get; set; }
    }
}
