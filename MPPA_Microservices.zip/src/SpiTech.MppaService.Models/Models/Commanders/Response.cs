﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders
{
    public class Response
    {
        [XmlAttribute(AttributeName = "overallResult")]
        public string OverallResult { get; set; }

        [XmlAttribute(AttributeName = "responseCode")]
        public string ResponseCode { get; set; }

        [XmlAttribute(AttributeName = "messageCode")]
        public string MessageCode { get; set; }
    }
}