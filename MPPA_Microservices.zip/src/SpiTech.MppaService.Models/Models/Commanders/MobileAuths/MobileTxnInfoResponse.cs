﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileAuths
{
    public class MobileTxnInfoResponse : MobileTxnInfoBase
    {
        public string POSTransNumber { get; set; }

        [XmlElement("FuelingPositionID")]
        public int FuelingPositionId { get; set; }

        public string SiteMPPAIdentifier { get; set; }
    }
}
