﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileAuths
{
    public class PaymentInfo : PaymentInfoBase
    {
        [XmlAttribute(AttributeName = "preAuthAmount")]
        public decimal PreAuthAmount { get; set; }
    }
}