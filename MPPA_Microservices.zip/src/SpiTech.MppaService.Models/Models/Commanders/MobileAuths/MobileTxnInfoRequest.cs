﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileAuths
{
    public class MobileTxnInfoRequest : MobileTxnInfoBase
    {
        public string POSTransNumber { get; set; }

        [XmlElement("WorkstationID")]
        public string WorkstationId { get; set; }

        [XmlElement("FuelingPositionID")]
        public string FuelingPositionId { get; set; }
        public string HostMPPAIdentifier { get; set; }
    }
}
