﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileAuths
{
    [XmlRoot(ElementName = "NAXMLMobile", Namespace = "http://www.conexxus.org/schema/naxml/mobile/" + Constants.NamespaceVersion)]
    public class AuthMppaRequest : MessageCommand
    {
        public MobileTxnInfoRequest MobileTxnInfo { get; set; }
        public MobileAuthRequest MobileAuthRequest { get; set; }
    }

    public class MobileAuthRequest
    {
        public PaymentInfo PaymentInfo { get; set; }
        public ItemsPurchased ItemsPurchased { get; set; }
        public LoyaltyInfo LoyaltyInfo { get; set; }
    }

    public class LoyaltyInfo
    {
        public string LoyaltyInstrument { get; set; }
    }
}
