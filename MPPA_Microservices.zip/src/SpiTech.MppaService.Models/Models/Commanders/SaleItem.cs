﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders
{
    public class SaleItem
    {
        [XmlAttribute(AttributeName = "itemID")]
        public string ItemId { get; set; }

        [XmlAttribute(AttributeName = "evaluateOnly")]
        public bool EvaluateOnly { get; set; }

        [XmlAttribute(AttributeName = "reverseSale")]
        public string ReverseSale { get; set; }

        [XmlAttribute(AttributeName = "itemStatus")]
        public string ItemStatus { get; set; }

        [XmlAttribute(AttributeName = "priceChangeEligible")]
        public string PriceChangeEligible { get; set; }

        public string POSCode { get; set; }
        public string POSCodeModifier { get; set; }
        public string POSCodeFormat { get; set; }
        public string ProductCode { get; set; }
        public ItemAmount OriginalAmount { get; set; }
        public ItemAmount AdjustedAmount { get; set; }
        public string UnitMeasure { get; set; }
        public decimal Quantity { get; set; }
        public string AdditionalProductInfo { get; set; }
        public string Description { get; set; }
        public string PriceTier { get; set; }
        public string RebateLabel { get; set; }
        public string ServiceLevel { get; set; }
        public string OutdoorPosition { get; set; }
        public PriceAdjustment PriceAdjustment { get; set; }
    }
}