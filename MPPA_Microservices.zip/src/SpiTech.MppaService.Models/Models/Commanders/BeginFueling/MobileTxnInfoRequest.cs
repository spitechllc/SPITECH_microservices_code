﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.BeginFueling
{
    public class MobileTxnInfoRequest : MobileTxnInfoBase
    {
        public string POSTransNumber { get; set; }

        [XmlElement("FuelingPositionID")]
        public int FuelingPositionId { get; set; }
        public string SiteMPPAIdentifier { get; set; }
    }
}
