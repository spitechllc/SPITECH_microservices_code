﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.BeginFueling
{
    [XmlRoot(ElementName = "NAXMLMobile", Namespace = "http://www.conexxus.org/schema/naxml/mobile/" + Constants.NamespaceVersion)]
    public class BeginFuelingCommanderRequest : MessageCommand
    {
        public MobileTxnInfoRequest MobileTxnInfo { get; set; }
        public MobileBeginFuelingRequest MobileBeginFuelingRequest { get; set; }
    }

    public class MobileBeginFuelingRequest
    {
        public string BeginFuelMessage { get; set; }
    }
}
