﻿namespace SpiTech.MppaService.Domain.Models.Commanders.BeginFueling
{
    public class MobileTxnInfoResponse : MobileTxnInfoRequest
    {
        public string HostMPPAIdentifier { get; set; }
    }
}
