﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.BeginFueling
{
    [XmlRoot(ElementName = "NAXMLMobile", Namespace = "http://www.conexxus.org/schema/naxml/mobile/" + Constants.NamespaceVersion)]
    public class BeginFuelingMppaResponse : MessageCommand
    {
        public MobileTxnInfoResponse MobileTxnInfo { get; set; }
        public MobileResponse MobileBeginFuelingResponse { get; set; }
    }
}
