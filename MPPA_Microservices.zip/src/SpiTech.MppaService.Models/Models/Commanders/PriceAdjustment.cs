﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders
{
    public class PriceAdjustment
    {
        [XmlAttribute(AttributeName = "rewardApplied")]
        public bool RewardApplied { get; set; }

        [XmlAttribute(AttributeName = "priceAdjustmentID")]
        public string PriceAdjustmentId { get; set; }

        [XmlAttribute(AttributeName = "programID")]
        public string ProgramId { get; set; }
        public PromotionReason PromotionReason { get; set; }

        public decimal Amount { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Quantity { get; set; }
        public string MaximumQuantity { get; set; }
        public string RebateLabel { get; set; }
    }
}