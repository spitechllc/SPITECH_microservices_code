﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobilePumpReserves
{
    [XmlRoot(ElementName = "NAXMLMobile", Namespace = "http://www.conexxus.org/schema/naxml/mobile/" + Constants.NamespaceVersion)]
    public class PumpReserveMppaRequest : MessageCommand
    {
        public MobileTxnInfoRequest MobileTxnInfo { get; set; }
        public MobilePumpReserveRequest MobilePumpReserveRequest { get; set; }
    }

    public class MobilePumpReserveRequest
    {
    }
}
