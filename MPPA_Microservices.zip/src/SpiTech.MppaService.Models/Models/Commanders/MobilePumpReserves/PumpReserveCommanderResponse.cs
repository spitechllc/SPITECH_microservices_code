﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobilePumpReserves
{
    [XmlRoot(ElementName = "NAXMLMobile", Namespace = "http://www.conexxus.org/schema/naxml/mobile/" + Constants.NamespaceVersion)]
    public class PumpReserveCommanderResponse : MessageCommand
    {
        public MobileTxnInfoResponse MobileTxnInfo { get; set; }
        public MobileResponse MobilePumpReserveResponse { get; set; }
    }
}
