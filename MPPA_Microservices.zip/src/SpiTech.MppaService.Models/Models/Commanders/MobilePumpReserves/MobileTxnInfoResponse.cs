﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobilePumpReserves
{
    public class MobileTxnInfoResponse : MobileTxnInfoBase
    {
        [XmlElement("FuelingPositionID")]
        public int FuelingPositionId { get; set; }
        public string SiteMPPAIdentifier { get; set; }
        public string POSTransNumber { get; set; }
    }
}
