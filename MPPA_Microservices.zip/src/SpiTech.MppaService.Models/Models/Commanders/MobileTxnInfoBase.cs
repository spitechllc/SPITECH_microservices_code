﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders
{
    public class MobileTxnInfoBase
    {
        [XmlElement(ElementName = "UMTI")]
        public string UMTI { get; set; }

        [XmlElement(ElementName = "MerchantID")]
        public string MerchantId { get; set; }

        [XmlElement(ElementName = "TimeDateStamp")]
        public string TimeDateStamp { get; set; }

        [XmlElement(ElementName = "SiteID")]
        public string SiteId { get; set; }
    }
}
