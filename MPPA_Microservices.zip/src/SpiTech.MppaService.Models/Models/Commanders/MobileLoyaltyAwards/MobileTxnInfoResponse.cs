﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileLoyaltyAwards
{
    public class MobileTxnInfoResponse : MobileTxnInfoBase
    {
        public string POSTransNumber { get; set; }

        [XmlElement("WorkstationID")]
        public string WorkstationId { get; set; }
        public string SiteMPPAIdentifier { get; set; }
        public string HostMPPAIdentifier { get; set; }

        [XmlElement("FuelingPositionID")]
        public string FuelingPositionId { get; set; }
    }
}
