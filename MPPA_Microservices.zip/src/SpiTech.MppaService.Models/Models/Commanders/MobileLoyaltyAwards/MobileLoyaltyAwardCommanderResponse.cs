﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileLoyaltyAwards
{
    [XmlRoot(ElementName = "NAXMLMobile", Namespace = "http://www.conexxus.org/schema/naxml/mobile/" + Constants.NamespaceVersion)]
    public class MobileLoyaltyAwardCommanderResponse : MessageCommand
    {
        public MobileTxnInfoResponse MobileTxnInfo { get; set; }
        public MobileLoyaltyAwardResponse MobileLoyaltyAwardResponse { get; set; }
    }

    public class MobileLoyaltyAwardResponse
    {
        public Response Response { get; set; }

        public ItemsPurchased ItemsPurchased { get; set; }
    }
}
