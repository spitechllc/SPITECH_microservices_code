﻿using SpiTech.MppaService.Domain.Models.Commanders.MobileFinalizes;
using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileLoyaltyAwards
{
    [XmlRoot(ElementName = "NAXMLMobile", Namespace = "http://www.conexxus.org/schema/naxml/mobile/" + Constants.NamespaceVersion)]
    public class MobileLoyaltyAwardMppaRequest : MessageCommand
    {
        public MobileTxnInfoRequest MobileTxnInfo { get; set; }
        public MobileLoyaltyAwardRequest MobileLoyaltyAwardRequest { get; set; }
    }

    public class MobileLoyaltyAwardRequest
    {
        public PaymentInfo PaymentInfo { get; set; }

        public ItemsPurchased ItemsPurchased { get; set; }
    }
}
