﻿namespace SpiTech.MppaService.Domain.Models.Commanders.Settlements
{
    public class MobileTxnInfoResponse : MobileTxnInfoRequest
    {
        public string HostMPPAIdentifier { get; set; }
    }
}
