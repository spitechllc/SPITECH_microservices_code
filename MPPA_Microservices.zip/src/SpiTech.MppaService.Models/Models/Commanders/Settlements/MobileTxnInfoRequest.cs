﻿namespace SpiTech.MppaService.Domain.Models.Commanders.Settlements
{
    public class MobileTxnInfoRequest : MobileTxnInfoBase
    {
        public string SiteMPPAIdentifier { get; set; }
    }
}
