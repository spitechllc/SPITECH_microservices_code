﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.Settlements
{
    [XmlRoot(ElementName = "NAXMLMobile", Namespace = "http://www.conexxus.org/schema/naxml/mobile/" + Constants.NamespaceVersion)]
    public class SettlementMppaResponse : MessageCommand
    {
        public MobileTxnInfoResponse MobileTxnInfo { get; set; }
        public MobileResponse MobileSettlementResponse { get; set; }
    }
}
