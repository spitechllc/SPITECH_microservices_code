﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.Settlements
{
    [XmlRoot(ElementName = "NAXMLMobile", Namespace = "http://www.conexxus.org/schema/naxml/mobile/" + Constants.NamespaceVersion)]
    public class SettlementCommanderRequest : MessageCommand
    {
        public MobileTxnInfoRequest MobileTxnInfo { get; set; }
        public MobileSettlementRequest MobileSettlementRequest { get; set; }
    }

    public class MobileSettlementRequest
    {
        public SettlementDetails SettlementDetails { get; set; }
    }

    public class SettlementDetails
    {
        [XmlElement(ElementName = "TotalsInfo")]
        public TotalsInfo TotalsInfo { get; set; }

        [XmlAttribute(AttributeName = "settlementPeriodID")]
        public string SettlementPeriodID { get; set; }

        [XmlAttribute(AttributeName = "businessDate")]
        public DateTime BusinessDate { get; set; }

        [XmlAttribute(AttributeName = "terminalTotal")]
        public decimal TerminalTotal { get; set; }

        [XmlAttribute(AttributeName = "softwareVersion")]
        public string SoftwareVersion { get; set; }

        [XmlText]
        public string Text { get; set; }
    }

    [XmlRoot(ElementName = "TotalsInfo")]
    public class TotalsInfo
    {

        [XmlElement(ElementName = "TotalAmount")]
        public List<TotalAmount> TotalAmount { get; set; }
    }

    [XmlRoot(ElementName = "TotalAmount")]
    public class TotalAmount
    {
        [XmlAttribute(AttributeName = "count")]
        public int Count { get; set; }

        [XmlAttribute(AttributeName = "type")]
        public string Type { get; set; }

        [XmlAttribute(AttributeName = "group")]
        public string Group { get; set; }

        [XmlText]
        public decimal Amount { get; set; }
    }
}
