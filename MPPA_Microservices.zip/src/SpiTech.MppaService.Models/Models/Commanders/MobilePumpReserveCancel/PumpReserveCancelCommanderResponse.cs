﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobilePumpReserveCancel
{
    [XmlRoot(ElementName = "NAXMLMobile", Namespace = "http://www.conexxus.org/schema/naxml/mobile/" + Constants.NamespaceVersion)]
    public class PumpReserveCancelCommanderResponse : MessageCommand
    {
        public MobileTxnInfoResponse MobileTxnInfo { get; set; }
        public MobileResponse MobileCancelResponse { get; set; }
    }
}
