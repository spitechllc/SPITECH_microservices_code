﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobilePumpReserveCancel
{
    public class MobileTxnInfoRequest : MobileTxnInfoBase
    {
        [XmlElement("FuelingPositionID")]
        public int FuelingPositionId { get; set; }
    }
}
