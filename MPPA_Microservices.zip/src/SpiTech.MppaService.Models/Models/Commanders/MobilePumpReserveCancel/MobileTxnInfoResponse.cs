﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobilePumpReserveCancel
{
    public class MobileTxnInfoResponse : MobileTxnInfoBase
    {
        [XmlElement("FuelingPositionID")]
        public int FuelingPositionId { get; set; }
        public string POSTransNumber { get; set; }
        public string SiteMPPAIdentifier { get; set; }
    }
}
