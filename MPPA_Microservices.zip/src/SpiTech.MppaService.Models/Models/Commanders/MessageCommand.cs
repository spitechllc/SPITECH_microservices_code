﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders
{
    public class MessageCommand
    {
        [XmlAttribute(AttributeName = "version")]
        public string Version { get; set; } = Constants.Version;
    }
}
