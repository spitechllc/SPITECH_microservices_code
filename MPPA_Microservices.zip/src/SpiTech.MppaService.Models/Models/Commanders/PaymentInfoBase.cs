﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders
{
    public class PaymentInfoBase
    {
        [XmlAttribute(AttributeName = "cardPANPrint")]
        public string CardPANPrint { get; set; }

        [XmlAttribute(AttributeName = "cardISO")]
        public string CardISO { get; set; }

        [XmlAttribute(AttributeName = "cardCircuit")]
        public string CardCircuit { get; set; }

        [XmlAttribute(AttributeName = "paymentMethod")]
        public string PaymentMethod { get; set; }

        [XmlAttribute(AttributeName = "hostAuthNumber")]
        public string HostAuthNumber { get; set; }

        [XmlAttribute(AttributeName = "cardType")]
        public string CardType { get; set; }
    }
}