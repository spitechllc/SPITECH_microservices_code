﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders
{
    public class PromotionReason
    {
        [XmlAttribute(AttributeName = "doNotRelieveTaxFlag")]
        public bool DoNotRelieveTaxFlag { get; set; }

        [XmlText]
        public string Reason { get; set; }
    }
}