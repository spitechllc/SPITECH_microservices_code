﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileSiteData
{
    [XmlRoot(ElementName = "FuelConfigDetails")]
    public class FuelConfigDetails
    {
        [XmlElement(ElementName = "PumpProducts")]
        public List<PumpProducts> PumpProducts { get; set; }

        [XmlAttribute(AttributeName = "pumpTimeout")]
        public int PumpTimeout { get; set; }
    }
}