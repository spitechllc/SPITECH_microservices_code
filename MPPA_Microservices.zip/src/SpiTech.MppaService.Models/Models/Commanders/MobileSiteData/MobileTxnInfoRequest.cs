﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileSiteData
{
    [XmlRoot(ElementName = "MobileTxnInfo")]
    public class MobileTxnInfoRequest : MobileTxnInfoBase
    {
        [XmlElement(ElementName = "SiteMPPAIdentifier")]
        public string SiteMPPAIdentifier { get; set; }
    }
}
