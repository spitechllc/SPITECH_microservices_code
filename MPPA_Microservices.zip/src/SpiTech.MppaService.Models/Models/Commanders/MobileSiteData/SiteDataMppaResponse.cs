﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileSiteData
{
    [XmlRoot(ElementName = "NAXMLMobile", Namespace = "http://www.conexxus.org/schema/naxml/mobile/" + Constants.NamespaceVersion)]
    public class SiteDataMppaResponse : MessageCommand
    {
        [XmlElement(ElementName = "MobileTxnInfo")]
        public MobileTxnInfoResponse MobileTxnInfo { get; set; }

        [XmlElement(ElementName = "MobileSiteDataResponse")]
        public MobileResponse MobileSiteDataResponse { get; set; }
    }
}
