﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileSiteData
{
    [XmlRoot(ElementName = "NAXMLMobile", Namespace = "http://www.conexxus.org/schema/naxml/mobile/" + Constants.NamespaceVersion)]
    public class SiteDataCommanderRequest : MessageCommand
    {
        [XmlElement(ElementName = "MobileTxnInfo")]
        public MobileTxnInfoRequest MobileTxnInfo { get; set; }

        [XmlElement(ElementName = "MobileSiteDataRequest")]
        public MobileSiteDataRequest MobileSiteDataRequest { get; set; }
    }

    [XmlRoot(ElementName = "MobileSiteDataRequest")]
    public class MobileSiteDataRequest
    {

        [XmlElement(ElementName = "SiteDetails")]
        public SiteDetails SiteDetails { get; set; }

        [XmlElement(ElementName = "FuelConfigDetails")]
        public FuelConfigDetails FuelConfigDetails { get; set; }
    }
}
