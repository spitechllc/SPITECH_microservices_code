﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileSiteData
{
    [XmlRoot(ElementName = "POSTerminals")]
    public class POSTerminals
    {

        [XmlElement(ElementName = "POSTerminal")]
        public List<POSTerminal> POSTerminal { get; set; }
    }


    [XmlRoot(ElementName = "POSTerminal")]
    public class POSTerminal
    {

        [XmlAttribute(AttributeName = "terminalID")]
        public int TerminalId { get; set; }

        [XmlAttribute(AttributeName = "terminalType")]
        public string TerminalType { get; set; }
    }
}