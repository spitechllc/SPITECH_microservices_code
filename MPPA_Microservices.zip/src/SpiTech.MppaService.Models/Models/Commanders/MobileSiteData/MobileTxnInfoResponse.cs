﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileSiteData
{
    [XmlRoot(ElementName = "MobileTxnInfo")]
    public class MobileTxnInfoResponse : MobileTxnInfoRequest
    {
        [XmlElement(ElementName = "HostMPPAIdentifier")]
        public string HostMPPAIdentifier { get; set; }
    }
}
