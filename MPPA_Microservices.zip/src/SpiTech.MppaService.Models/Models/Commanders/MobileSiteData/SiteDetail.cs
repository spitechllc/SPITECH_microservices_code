﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileSiteData
{
    [XmlRoot(ElementName = "SiteDetails")]
    public class SiteDetails
    {
        [XmlElement(ElementName = "POSTerminals")]
        public POSTerminals POSTerminals { get; set; }

        [XmlAttribute(AttributeName = "merchantID")]
        public string MerchantId { get; set; }

        [XmlAttribute(AttributeName = "locationID")]
        public string LocationId { get; set; }

        [XmlAttribute(AttributeName = "siteMobileActive")]
        public bool SiteMobileActive { get; set; }

        [XmlAttribute(AttributeName = "siteName")]
        public string SiteName { get; set; }

        [XmlAttribute(AttributeName = "siteAddress")]
        public string SiteAddress { get; set; }

        [XmlAttribute(AttributeName = "welcomeMsg")]
        public string WelcomeMsg { get; set; }

        [XmlAttribute(AttributeName = "settlementEmployee")]
        public string SettlementEmployee { get; set; }

        [XmlAttribute(AttributeName = "partialAuthAllowed")]
        public bool PartialAuthAllowed { get; set; }
    }
}