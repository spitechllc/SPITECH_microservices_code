﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.HeartBeats
{
    [XmlRoot(ElementName = "NAXMLMobile", Namespace = "http://www.conexxus.org/schema/naxml/mobile/" + Constants.NamespaceVersion)]
    public class HeartBeatMppaResponse : MessageCommand
    {
        public MobileTxnInfoBase MobileTxnInfo { get; set; }
        public MobileResponse MobileHeartBeatResponse { get; set; }
    }
}
