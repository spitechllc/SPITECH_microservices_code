﻿namespace SpiTech.MppaService.Domain.Models.Commanders
{
    public class MobileResponse
    {
        public Response Response { get; set; }
    }
}