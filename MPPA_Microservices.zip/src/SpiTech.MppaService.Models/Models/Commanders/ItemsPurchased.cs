﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders
{
    [XmlRoot(ElementName = "ItemsPurchased")]
    public class ItemsPurchased
    {

        [XmlElement(ElementName = "SaleItem")]
        public SaleItem[] SaleItems { get; set; }
    }
}