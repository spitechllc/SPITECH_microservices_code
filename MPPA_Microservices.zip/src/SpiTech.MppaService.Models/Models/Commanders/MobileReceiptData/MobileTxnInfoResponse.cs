﻿namespace SpiTech.MppaService.Domain.Models.Commanders.MobileReceiptData
{
    public class MobileTxnInfoResponse : MobileTxnInfoRequest
    {
        public string HostMPPAIdentifier { get; set; }
    }
}
