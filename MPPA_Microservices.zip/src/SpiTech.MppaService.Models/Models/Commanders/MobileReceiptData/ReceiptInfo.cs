﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileReceiptData
{
    [XmlRoot(ElementName = "ReceiptInfo")]
    public class ReceiptInfo
    {

        [XmlElement(ElementName = "ReceiptLine")]
        public string[] ReceiptLines { get; set; }
    }
}