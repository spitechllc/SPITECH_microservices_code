﻿using System.Xml.Serialization;

namespace SpiTech.MppaService.Domain.Models.Commanders.MobileReceiptData
{
    [XmlRoot(ElementName = "NAXMLMobile", Namespace = "http://www.conexxus.org/schema/naxml/mobile/" + Constants.NamespaceVersion)]
    public class ReceiptDataCommanderRequest : MessageCommand
    {
        public MobileTxnInfoRequest MobileTxnInfo { get; set; }
        public MobileReceiptDataRequest MobileReceiptDataRequest { get; set; }
    }

    public class MobileReceiptDataRequest
    {
        public ReceiptInfo ReceiptInfo { get; set; }
        public ItemsPurchased ItemsPurchased { get; set; }
    }
}
