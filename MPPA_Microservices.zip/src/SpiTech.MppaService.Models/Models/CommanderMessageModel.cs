﻿using SpiTech.EventBus.DomainEvents.Enums;
using System;

namespace SpiTech.MppaService.Domain.Models
{
    public class CommanderMessageModel
    {
        public Guid CommanderMessageId { get; set; }
        public int RequestTypeId { get; set; }
        public string RequestTypeName { get { return ((RequestType)RequestTypeId).ToString(); } }
        public string UMTI { get; set; }
        public string SiteId { get; set; }
        public string MerchantId { get; set; }
        public long? TransactionId { get; set; }
        public string XmlMessage { get; set; }
        public string JsonMessage { get; set; }
        public string OverallResult { get; set; }
        public string ResponseCode { get; set; }
        public string MessageCode { get; set; }
        public string Error { get; set; }
        public int StatusId { get; set; }
        public bool IsRequest { get; set; }
        public string Status { get { return ((Status)StatusId).ToString(); } }
        public DateTime? CreatedOn { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        [Newtonsoft.Json.JsonIgnore]
        public int TotalRecord { get; set; }
    }
}
