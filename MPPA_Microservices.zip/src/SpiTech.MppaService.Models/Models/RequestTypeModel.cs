﻿namespace SpiTech.MppaService.Domain.Models
{
    public class RequestTypeModel
    {
        public int RequestTypeId { get; set; }
        public string Name { get; set; }
    }
}
