﻿namespace SpiTech.MppaService.Domain.Models
{
    public class SiteProductModel
    {
        public string SiteId { get; set; }
        public decimal? OriginalAmountUnitPrice { get; set; }
        public string UnitMeasure { get; set; }
        public string Description { get; set; }
        public string PriceTier { get; set; }
    }
}
