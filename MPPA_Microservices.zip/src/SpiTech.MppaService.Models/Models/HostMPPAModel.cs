﻿namespace SpiTech.MppaService.Domain.Models
{
    public class HostMPPAModel
    {
        public string HostMPPAIdentifier { get; set; }
        public string HostIP { get; set; }
        public bool IsProdEnabled { get; set; }
    }
}
