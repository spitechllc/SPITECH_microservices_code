﻿namespace SpiTech.MppaService.Domain.Models
{
    public class UserModel
    {
        public string DeviceToken { get; set; }
        public string AppType { get; set; }
        public int UserId { get; set; }
        public string ConnectionId { get; set; }
    }
}
