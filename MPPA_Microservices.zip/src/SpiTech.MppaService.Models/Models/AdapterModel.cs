﻿namespace SpiTech.MppaService.Domain.Models
{
    public class AdapterModel
    {
        public int AdapterId { get; set; }
        public string AdapterName { get; set; }
    }
}
