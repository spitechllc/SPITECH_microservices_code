﻿using System;

namespace SpiTech.MppaService.Domain.Models
{
    public class MppaSessionStatus
    {
        public string SiteId { get; set; }
        public bool IsConnected { get; set; }
        public bool IsSocketDisposed { get; set; }
        public DateTime ConnectionTime { get; set; }
        public DateTime DisConnectionTime { get; set; }
        public DateTime LastMessageReceived { get; set; }
    }
}
