﻿namespace SpiTech.MppaService.Domain
{
    public class HostConfig
    {
        public string HostMPPAIdentifier { get; set; }
        public string HostAuthNumber { get; set; }
        public int TransactionTimeoutInSec { get; set; }
        public string UtmiPrefix { get; set; }
        public bool IsPosTestingEnabled { get; set; }
        public bool IsPayAtPumpTestingEnabled { get; set; }
        public bool IsLoyaltyTestingEnabled { get; set; }
        public int StacTimeoutInSec { get; set; }
        public int FailTransReconcileExecInSec { get; set; }
    }
}
