﻿using AutoMapper;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models;

namespace SpiTech.MppaService.Domain.Mappers
{
    public class RequestTypeProfile : Profile
    {
        public RequestTypeProfile()
        {
            CreateMap<RequestType, RequestTypeModel>().ReverseMap();
        }
    }
}
