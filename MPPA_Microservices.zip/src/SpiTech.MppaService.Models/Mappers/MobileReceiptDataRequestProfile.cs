﻿using AutoMapper;

namespace SpiTech.MppaService.Domain.Mappers
{
    public class MobileReceiptDataRequestProfile : Profile
    {
        public MobileReceiptDataRequestProfile()
        {
            CreateMap<SpiTech.MppaService.Domain.Models.Commanders.MobileReceiptData.MobileReceiptDataRequest,
                SpiTech.EventBus.DomainEvents.Models.Mppa.MobileReceiptData.MobileReceiptDataRequest>()
                .ReverseMap();
        }
    }
}
