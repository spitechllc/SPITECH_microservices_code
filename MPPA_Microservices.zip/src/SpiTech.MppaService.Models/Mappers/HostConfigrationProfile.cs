﻿using AutoMapper;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models;

namespace SpiTech.MppaService.Domain.Mappers
{
    public class HostConfigrationProfile : Profile
    {
        public HostConfigrationProfile()
        {
            CreateMap<HostConfigration, HostConfigrationModel>().ReverseMap();
        }
    }
}
