﻿using AutoMapper;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models;

namespace SpiTech.MppaService.Domain.Mappers
{
    public class AdapterProfile : Profile
    {
        public AdapterProfile()
        {

            CreateMap<Adapter, AdapterModel>().ReverseMap();
        }
    }
}
