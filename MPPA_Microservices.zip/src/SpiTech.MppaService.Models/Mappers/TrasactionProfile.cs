﻿using AutoMapper;
using SpiTech.MppaService.Domain.Entities;

namespace SpiTech.MppaService.Domain.Mappers
{
    public class TrasactionProfile : Profile
    {
        public TrasactionProfile()
        {
            CreateMap<Transaction, EventBus.DomainEvents.Models.Mppa.Transaction>().ReverseMap();
        }
    }
}
