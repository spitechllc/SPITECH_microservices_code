﻿using AutoMapper;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models;

namespace SpiTech.MppaService.Domain.Mappers
{
    public class HostMPPAProfile : Profile
    {
        public HostMPPAProfile()
        {
            CreateMap<HostMPPA, HostMPPAModel>().ReverseMap();
        }
    }
}
