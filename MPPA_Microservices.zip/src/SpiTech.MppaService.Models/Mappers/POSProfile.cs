﻿using AutoMapper;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models;

namespace SpiTech.MppaService.Domain.Mappers
{
    public class POSProfile : Profile
    {
        public POSProfile()
        {
            CreateMap<POS, POSModel>().ReverseMap();
        }
    }
}
