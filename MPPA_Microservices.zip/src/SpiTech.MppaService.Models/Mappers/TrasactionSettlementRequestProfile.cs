﻿using AutoMapper;
using SpiTech.MppaService.Domain.Entities;

namespace SpiTech.MppaService.Domain.Mappers
{
    public class TrasactionSettlementRequestProfile : Profile
    {
        public TrasactionSettlementRequestProfile()
        {
            CreateMap<SettlementRequest, EventBus.DomainEvents.Models.Mppa.SettlementRequest>().ReverseMap();
            CreateMap<SettlementDetail, EventBus.DomainEvents.Models.Mppa.SettlementDetail>().ReverseMap();
        }
    }
}
