﻿using AutoMapper;
using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.MppaService.Domain.Entities;
using SpiTech.MppaService.Domain.Models;

namespace SpiTech.MppaService.Domain.Mappers
{
    public class SiteProfile : Profile
    {
        public SiteProfile()
        {
            CreateMap<Site, SiteModel>().ReverseMap();
            CreateMap<Site, SiteEvent>().ReverseMap().IgnoreAllPropertiesWithAnInaccessibleSetter();
        }
    }
}
