﻿using AutoMapper;

namespace SpiTech.MppaService.Domain.Mappers.Events
{
    public class PaymentInfoProfile : Profile
    {
        public PaymentInfoProfile()
        {
            CreateMap<EventBus.DomainEvents.Models.Mppa.PaymentInfo, Models.Commanders.MobileAuths.PaymentInfo>().ReverseMap();
            CreateMap<EventBus.DomainEvents.Models.Mppa.PaymentInfo, Models.Commanders.MobileFinalizes.PaymentInfo>().ReverseMap();
        }
    }
}
