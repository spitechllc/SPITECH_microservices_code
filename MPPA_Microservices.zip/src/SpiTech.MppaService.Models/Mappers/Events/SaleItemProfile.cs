﻿using AutoMapper;
using SpiTech.MppaService.Domain.Models.Commanders;

namespace SpiTech.MppaService.Domain.Mappers.Events
{
    public class SaleItemProfile : Profile
    {
        public SaleItemProfile()
        {
            CreateMap<SaleItem, EventBus.DomainEvents.Models.Mppa.SaleItem>()
                .ForMember(t => t.OriginalAmount, d => d.MapFrom(s => s.OriginalAmount.Amount))
                .ForMember(t => t.OriginalAmountUnitPrice, d => d.MapFrom(s => s.OriginalAmount.UnitPrice))
                .ForMember(t => t.AdjustedAmount, d => d.MapFrom(s => s.AdjustedAmount.Amount))
                .ForMember(t => t.AdjustedAmountUnitPrice, d => d.MapFrom(s => s.AdjustedAmount.UnitPrice))
                .ReverseMap();

            CreateMap<PriceAdjustment, EventBus.DomainEvents.Models.Mppa.PriceAdjustment>()
                .ForMember(t => t.DoNotRelieveTaxFlag, d => d.MapFrom(s => s.PromotionReason.DoNotRelieveTaxFlag))
                .ForMember(t => t.PromotionReason, d => d.MapFrom(s => s.PromotionReason.Reason))
                .ReverseMap();
        }
    }
}
