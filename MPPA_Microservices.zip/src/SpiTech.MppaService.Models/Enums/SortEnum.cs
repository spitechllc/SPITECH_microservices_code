﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SpiTech.MppaService.Domain.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum CommanderMessageSortBy
    {
        None = 0,
        CreatedOn = 1,
        SiteId = 2,
        UMTI = 3, 
        TransactionId = 4,
    }
}
