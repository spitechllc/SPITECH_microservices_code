﻿namespace SpiTech.MppaService.Domain
{
    public class MessageConstants
    {
        public const string PumpReserveErorr = "Unable to Connect Server, Please try later";
    }
}
