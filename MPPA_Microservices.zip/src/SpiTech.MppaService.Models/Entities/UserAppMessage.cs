﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.MppaService.Domain.Entities
{
    [Table("UserAppMessage")]
    public class UserAppMessage : BaseEntity
    {
        [ExplicitKey]
        public Guid UserAppMessageId { get; set; }
        public int RequestTypeId { get; set; }
        public string SiteId { get; set; }
        public int UserId { get; set; }
        public long? TransactionId { get; set; }
        public string UMTI { get; set; }
        public string Message { get; set; }
        public bool IsRequestMessage { get; set; }
        public string Error { get; set; }
        public bool IsSuccess { get; set; }
    }
}
