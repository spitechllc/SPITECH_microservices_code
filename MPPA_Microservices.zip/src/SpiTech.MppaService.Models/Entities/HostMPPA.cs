﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.MppaService.Domain.Entities
{
    [Table("HostMPPA")]
    public class HostMPPA : BaseEntity
    {
        [ExplicitKey]
        public string HostMPPAIdentifier { get; set; }
        public string HostIP { get; set; }
        public bool IsProdEnabled { get; set; }
    }
}
