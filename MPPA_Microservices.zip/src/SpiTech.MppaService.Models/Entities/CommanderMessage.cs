﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.MppaService.Domain.Entities
{
    [Table("CommanderMessage")]
    public class CommanderMessage : BaseEntity
    {
        [ExplicitKey]
        public Guid CommanderMessageId { get; set; }
        public int? RequestTypeId { get; set; }
        public string UMTI { get; set; }
        public string SiteId { get; set; }
        public string MerchantId { get; set; }
        public long? TransactionId { get; set; }
        public string XmlMessage { get; set; }
        public string JsonMessage { get; set; }
        public string OverallResult { get; set; }
        public string ResponseCode { get; set; }
        public string MessageCode { get; set; }
        public string Error { get; set; }
        public int StatusId { get; set; }
        public bool IsRequest { get; set; }
    }
}
