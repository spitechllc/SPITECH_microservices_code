﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.MppaService.Domain.Entities
{
    [Table("Adapter")]
    public class Adapter : BaseEntity
    {
        [Key]
        public int AdapterId { get; set; }
        public string AdapterName { get; set; }
    }
}
