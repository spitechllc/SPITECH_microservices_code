﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.MppaService.Domain.Entities
{
    [Table("[StacGeneration]")]
    public class StacGeneration : BaseEntity
    {
        [ExplicitKey]
        public string StacGenerationId { get; set; }
        [ExplicitKey]
        public string QrCodeStac { get; set; }
        [ExplicitKey]
        public string BarCodeStac { get; set; }
        public string SiteId { get; set; }
        public int UserId { get; set; }
        public string DeviceToken { get; set; }
        public string AppType { get; set; }
        public DateTime GenerateDate { get; set; }
        public decimal RequestAmount { get; set; }
        public bool IsVerified { get; set; }
        public DateTime? VerifyDate { get; set; }
    }
}
