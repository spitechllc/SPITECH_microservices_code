﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.MppaService.Domain.Entities
{
    [Table("POS")]
    public class POS : BaseEntity
    {
        [Key]
        public int PosId { get; set; }
        public int StoreId { get; set; }
        public string StationNumber { get; set; }
        public string StationSystemId { get; set; }
        public string StationIPAddress { get; set; }
        public string QRCode { get; set; }
        public string BarCode { get; set; }
        public string NetworkType { get; set; }
        public string Port { get; set; }
    }
}
