﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.MppaService.Domain.Entities
{
    [Table("[StacCaptureRequest]")]
    public class StacCaptureRequest : BaseEntity
    {
        [ExplicitKey]
        public Guid StacCaptureRequestId { get; set; }
        public string UMTI { get; set; }
        public string SiteId { get; set; }
        public int? UserId { get; set; }
        public string DeviceToken { get; set; }
        public string AppType { get; set; }
        public string MerchantId { get; set; }
        public string WorkstationId { get; set; }
        public string SiteMppaIdentifier { get; set; }
        public string PosTransNumber { get; set; }
        public string Stac { get; set; }
        public string StacGenerationId { get; set; }
        public string QrCodeStac { get; set; }
        public string BarCodeStac { get; set; }
        public DateTime RequestDate { get; set; }
        public decimal RequestAmount { get; set; }
        public bool IsMatched { get; set; }
        public bool IsExpired { get; set; }
        public string StacCaptureType { get; set; }
    }
}
