﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.MppaService.Domain.Entities
{
    [Table("TransactionType")]
    public class RequestType : BaseEntity
    {
        [ExplicitKey]
        public int RequestTypeId { get; set; }
        public string Name { get; set; }
    }
}
