﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.MppaService.Domain.Entities
{
    [Table("GasPump")]
    public class GasPump : BaseEntity
    {
        [Key]
        public int GasPumpId { get; set; }
        public int StoreId { get; set; }
        public int PosId { get; set; }
        public string PumpNumber { get; set; }
        public string PumpSystemId { get; set; }
        public string QRCode { get; set; }
        public string BarCode { get; set; }
    }
}
