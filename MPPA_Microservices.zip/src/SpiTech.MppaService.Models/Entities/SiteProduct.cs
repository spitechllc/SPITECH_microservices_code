﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.MppaService.Domain.Entities
{
    [Table("SiteProduct")]
    public class SiteProduct : BaseEntity
    {
        [ExplicitKey]
        public string ItemId { get; set; }
        [ExplicitKey]
        public string SiteId { get; set; }
        public string POSCode { get; set; }
        public string POSCodeModifier { get; set; }
        public string ProductCode { get; set; }
        public decimal? OriginalAmount { get; set; }
        public decimal? OriginalAmountUnitPrice { get; set; }
        public decimal? AdjustedAmount { get; set; }
        public decimal? AdjustedAmountUnitPrice { get; set; }
        public string UnitMeasure { get; set; }
        public decimal? Quantity { get; set; }
        public string Description { get; set; }
        public string PriceTier { get; set; }
        public string MerchandiseCode { get; set; }
        public int? OutdoorPosition { get; set; }
    }
}
