﻿namespace SpiTech.Mppa.Client
{
    public class HostConfig
    {
        public string SiteId { get; set; }
        public string MerchantId { get; set; }
        public string HostMPPAIdentifier { get; set; }
        public int FuelingPositionId { get; set; }
    }
}
