﻿using SpiTech.MppaService.Domain;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace SpiTech.Mppa.Client
{
    class Serializer
    {
        public static string Serialize<T>(object objectToSerialize)
        {
            XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
            ns.Add("", "http://www.conexxus.org/schema/naxml/mobile/"+ Constants.NamespaceVersion);

            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = false;
            settings.NewLineOnAttributes = false;
            settings.NewLineChars = "";
            settings.OmitXmlDeclaration = false;
            settings.Encoding = Encoding.UTF8;

            using MemoryStream ms = new MemoryStream();
            using XmlWriter writer = XmlWriter.Create(ms, settings);
            writer.WriteStartDocument(true);
            new XmlSerializer(typeof(T)).Serialize(writer, objectToSerialize, ns);
            return Encoding.UTF8.GetString(ms.ToArray()); ;
        }
    }
}
