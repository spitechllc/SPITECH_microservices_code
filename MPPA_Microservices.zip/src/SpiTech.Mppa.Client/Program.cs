﻿using Microsoft.Extensions.Configuration;
using NetCoreServer;
using SpiTech.ApplicationCore.AppSettingsConfigLoader;
using SpiTech.MppaService.Domain;
using SpiTech.MppaService.Domain.Models.Commanders.HeartBeats;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;

namespace SpiTech.Mppa.Client
{
    class Program
    {
        public static string DecimalToHexadouble(int dec)
        {
            return dec.ToString("x8", new CultureInfo("en-us"));
            //if (dec < 1) return "0";

            //int hex = dec;
            //string hexStr = string.Empty;

            //while (dec > 0)
            //{
            //    hex = dec % 16;

            //    if (hex < 10)
            //        hexStr = hexStr.Insert(0, Convert.ToChar(hex + 48).ToString());
            //    else
            //        hexStr = hexStr.Insert(0, Convert.ToChar(hex + 55).ToString());

            //    dec /= 16;
            //}

            //return hexStr.PadLeft(8, '0');

        }

        public static string ByteArrayToString(byte[] ba)
        {
            StringBuilder hex = new StringBuilder(ba.Length * 2);
            foreach (byte b in ba)
                hex.AppendFormat("{0:x2}", b);
            return hex.ToString();
        }

        static void Main(string[] args)
        {
            var ggg = DateTime.UtcNow.Ticks.ToString();
            //string FinalizeRequestMessage = @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?><NAXMLMobile version=""2.0"" xmlns=""http://www.conexxus.org/schema/naxml/mobile/v02""><MobileTxnInfo><UMTI>63f425d5-332c-4bcb-964b-48a16a028404</UMTI><MerchantID>686657</MerchantID><TimeDateStamp>2021-09-25T12:40:20.805-05:00</TimeDateStamp><SiteID>497231540889</SiteID><POSTransNumber>9010078</POSTransNumber><FuelingPositionID>1</FuelingPositionID><SettlementPeriodID>20210824.001</SettlementPeriodID><SiteMPPAIdentifier>2</SiteMPPAIdentifier></MobileTxnInfo><MobileFinalizeRequest><PaymentInfo cardPANPrint=""1234"" cardISO=""4545"" cardCircuit=""56546"" paymentMethod=""Credit"" finalAmount=""100"" hostAuthNumber=""01"" cardType=""visa""/><ItemsPurchased><SaleItem itemID=""1"" itemStatus=""true"" evaluateOnly=""false"" priceChangeEligible=""false""><POSCode>45500000000000</POSCode><POSCodeModifier>10</POSCodeModifier><ProductCode>1</ProductCode><OriginalAmount><Amount>8.09</Amount><UnitPrice>5.089</UnitPrice></OriginalAmount><AdjustedAmount><Amount>1.07</Amount><UnitPrice>7.105</UnitPrice></AdjustedAmount><UnitMeasure>GLL</UnitMeasure><Quantity>8.009</Quantity><AdditionalProductInfo>UNLEAD CR #01</AdditionalProductInfo><Description>UNLEAD</Description><PriceTier>credit</PriceTier><ServiceLevel>S</ServiceLevel><OutdoorPosition>1</OutdoorPosition></SaleItem></ItemsPurchased></MobileFinalizeRequest></NAXMLMobile>";
            //var FinalizeRequest = SpiTech.MppaService.Application.Serializer.DeSerialize<FinalizeCommanderRequest>(FinalizeRequestMessage);

            //string MobileReceiptDataRequestMessage = @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?><NAXMLMobile version=""2.0"" xmlns=""http://www.conexxus.org/schema/naxml/mobile/v02""><MobileTxnInfo><UMTI>63f425d5-332c-4bcb-964b-48a16a028404</UMTI><MerchantID>686657</MerchantID><TimeDateStamp>2021-09-25T12:40:21.649-05:00</TimeDateStamp><SiteID>497231540889</SiteID><POSTransNumber>9010078</POSTransNumber><FuelingPositionID>1</FuelingPositionID><SiteMPPAIdentifier>2</SiteMPPAIdentifier></MobileTxnInfo><MobileReceiptDataRequest><ReceiptInfo><ReceiptLine>      WELCOME       </ReceiptLine><ReceiptLine>        LAB         </ReceiptLine><ReceiptLine> 1408 S FRETZ AVE.  </ReceiptLine><ReceiptLine>     EDMOND OK      </ReceiptLine><ReceiptLine>       73003        </ReceiptLine><ReceiptLine></ReceiptLine><ReceiptLine>DATE 9/25/21 12:40</ReceiptLine><ReceiptLine>TRAN# 9010078</ReceiptLine><ReceiptLine>PUMP# 01</ReceiptLine><ReceiptLine>SERVICE LEVEL: SELF </ReceiptLine><ReceiptLine>PRODUCT: UNLEAD    </ReceiptLine><ReceiptLine>GALLONS:       0.000</ReceiptLine><ReceiptLine>PRICE/G:      $0.000</ReceiptLine><ReceiptLine>FUEL SALE      $0.00</ReceiptLine><ReceiptLine>   MOBILE      $0.00</ReceiptLine><ReceiptLine></ReceiptLine><ReceiptLine>MOBILE</ReceiptLine><ReceiptLine>visa</ReceiptLine><ReceiptLine>CREDIT</ReceiptLine><ReceiptLine>1234</ReceiptLine><ReceiptLine>AUTH #: 01</ReceiptLine><ReceiptLine>     </ReceiptLine><ReceiptLine></ReceiptLine><ReceiptLine>     THANK YOU      </ReceiptLine><ReceiptLine>  HAVE A NICE DAY   </ReceiptLine></ReceiptInfo><ItemsPurchased><SaleItem itemID=""1"" itemStatus=""true"" evaluateOnly=""false"" priceChangeEligible=""false""><POSCode>00000000000000</POSCode><POSCodeModifier>60</POSCodeModifier><ProductCode>1</ProductCode><OriginalAmount><Amount>66.07</Amount><UnitPrice>3.007</UnitPrice></OriginalAmount><AdjustedAmount><Amount>4.06</Amount><UnitPrice>4.056</UnitPrice></AdjustedAmount><UnitMeasure>GLL</UnitMeasure><Quantity>2.004</Quantity><AdditionalProductInfo>UNLEAD CR #01</AdditionalProductInfo><Description>UNLEAD</Description><PriceTier>credit</PriceTier><ServiceLevel>S</ServiceLevel><OutdoorPosition>1</OutdoorPosition></SaleItem></ItemsPurchased></MobileReceiptDataRequest></NAXMLMobile>";
            //var ReceiptDataRequest = SpiTech.MppaService.Application.Serializer.DeSerialize<ReceiptDataCommanderRequest>(MobileReceiptDataRequestMessage);

            //var begin = @"<NAXMLMobile xmlns=""http://www.conexxus.org/schema/naxml/mobile/v02"" version=""2.0""><MobileTxnInfo><UMTI>db40714b-eaf2-4426-96a8-5ebacb88e9fd</UMTI><MerchantID>MID002</MerchantID><TimeDateStamp>2018-06-01T14:48:06.704-04:00</TimeDateStamp><SiteID/><POSTransNumber>9010011</POSTransNumber><FuelingPositionID>1</FuelingPositionID><SiteMPPAIdentifier>2</SiteMPPAIdentifier></MobileTxnInfo><MobileBeginFuelingRequest><BeginFuelMessage>Fueling Started</BeginFuelMessage></MobileBeginFuelingRequest></NAXMLMobile>";
            //var ReceiptDataRequest = SpiTech.MppaService.Application.Serializer.DeSerialize<BeginFuelingCommanderRequest>(begin);

            //int num = 419;
            //var ss = num.ToString("x8",new CultureInfo("en-us"));
            //var hexval = DecimalToHexadouble(num);
            //var prefixBytes = Encoding.UTF8.GetBytes(hexval);
            //var prefixBytes2 = Convert.FromHexString(hexval);

            //var hex1 = ByteArrayToString(prefixBytes);
            //var hex2 = ByteArrayToString(prefixBytes2);
            IConfiguration configuration = new ConfigurationBuilder()
                           .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                           .Build();

            var serverConfig = configuration.LoadConfig<ServerConfig>();
            var hostConfig = configuration.LoadConfig<HostConfig>();
            int heartbeatInterval = int.Parse(configuration["HeartbeatInterval"]);
            Console.WriteLine($"TCP server address: {serverConfig.Host}");
            Console.WriteLine($"TCP server port: {serverConfig.Port}");
            Console.WriteLine($"TCP server connected with SSL: {serverConfig.IsSSLOn}");

            Console.WriteLine();
            string certificateName = configuration["SSlCertificateName"];

            string certificatePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CommanderCACerts", serverConfig.SSlCertificateName);

            X509Certificate2 x509Certificate = null;

            //if (string.IsNullOrWhiteSpace(serverConfig.Password))
            //{
            //    x509Certificate = new X509Certificate2(certificatePath);
            //}
            //else
            //{
            //    x509Certificate = new X509Certificate2(certificatePath, serverConfig.Password);
            //}

            IMppaClient client;
            // Create a new TCP client
            if (serverConfig.IsSSLOn)
            {
                var context = new SslContext(SslProtocols.Tls12, x509Certificate, (sender, certificate, chain, sslPolicyErrors) => true);
                client = new MppaSslClient(context, serverConfig.Host, serverConfig.Port);
            }
            else
            {
                client = new MppaClient(serverConfig.Host, serverConfig.Port);
            }

            // Connect the client
            Console.Write("Client connecting...");
            client.ConnectAsync();
            Console.WriteLine("Done!");

            Console.WriteLine("Press Enter to stop the client or '!' to reconnect the client...");
            try
            {
                while (true)
                {
                    //count++;
                    //var request = new HeartBeatCommanderRequest
                    //{
                    //    MobileHeartBeatRequest = new MobileHeartBeatRequest
                    //    {
                    //        Heartbeat = $"VFI_HB_REQUEST{count}"
                    //    },
                    //    MobileTxnInfo = new MppaService.Domain.Models.Commanders.MobileTxnInfoBase
                    //    {
                    //        MerchantId = hostConfig.MerchantId,
                    //        SiteId = hostConfig.SiteId,
                    //        TimeDateStamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffK"),
                    //        UMTI = Guid.NewGuid().ToString()
                    //    }
                    //};

                    //string responseMsg = Serializer.Serialize<HeartBeatCommanderRequest>(request);
                    //if (count <= 10)
                    //    SendMessage(client, responseMsg);
                    //Thread.Sleep(heartbeatInterval);
                }
            }
            finally
            {
                // Disconnect the client
                Console.Write("Client disconnecting...");
                client.DisconnectAndStop();
                Console.WriteLine("Done!");
                Console.ReadLine();
            }
        }

        public static void SendMessage(IMppaClient client, string responseMsg)
        {
            Console.WriteLine("");
            Console.WriteLine("OutGoing: " + responseMsg);
            var bytes = Encoding.UTF8.GetBytes(responseMsg);
            Console.WriteLine("");
            Console.WriteLine("OutGoing Message length: " + bytes.Length);
            var hex = Program.DecimalToHexadouble(bytes.Length);
            Console.WriteLine("");
            Console.WriteLine("OutGoing Prefix bytes: " + hex);
            var prefixBytes = Convert.FromHexString(hex);
            byte[] resultytes = prefixBytes.Concat(bytes).ToArray();
            Console.WriteLine("");
            client.Send(resultytes);
        }
    }
}
