﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Mppa.Client
{
    public interface IMppaClient
    {
        bool ConnectAsync();
        void DisconnectAndStop();
        long Send(string text);
        long Send(byte[] bytes);
    }
}
