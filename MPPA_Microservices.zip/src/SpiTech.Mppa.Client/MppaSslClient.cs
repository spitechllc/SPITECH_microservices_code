﻿using NetCoreServer;
using System;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace SpiTech.Mppa.Client
{
    class MppaSslClient : SslClient, IMppaClient
    {
        public MppaSslClient(SslContext context, string address, int port) : base(context, address, port) { }

        public void DisconnectAndStop()
        {
            _stop = true;
            DisconnectAsync();
            while (IsConnected)
                Thread.Yield();
        }

        protected override void OnConnected()
        {
            Console.WriteLine($"TCP client connected a new session with Id {Id}");
        }

        protected override void OnDisconnected()
        {
            Console.WriteLine($"TCP client disconnected a session with Id {Id}");

            // Wait for a while...
            Thread.Sleep(1000);

            // Try to connect again
            if (!_stop)
                ConnectAsync();
        }

        protected override void OnHandshaked()
        {
            Console.WriteLine($"SSL client handshaked a new session with Id {Id}");
        }

        protected override void OnReceived(byte[] buffer, long offset, long size)
        {
            Console.WriteLine("");
            Console.WriteLine("Incomming prefix Byte: " + BitConverter.ToInt32(buffer.Take(4).ToArray()));
            Console.WriteLine("");
            Console.WriteLine("Incomming: " + Encoding.UTF8.GetString(buffer, 4, (int)size));
        }

        protected override void OnError(SocketError error)
        {
            Console.WriteLine($"TCP client caught an error with code {error}");
        }

        private bool _stop;
    }
}
