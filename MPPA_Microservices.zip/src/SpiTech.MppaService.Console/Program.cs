﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using SpiTech.MppaService.Application.Services;
using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using Serilog;
using System.IO;

namespace SpiTech.MppaService.ConsoleApp
{
    class Program
    {
        public static void Main(string[] args)
        {
            Environment.SetEnvironmentVariable("LogDir", AppDomain.CurrentDomain.BaseDirectory);

            var configuration = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true).Build();

            Log.Logger = new LoggerConfiguration()
                .ReadFrom.Configuration(configuration)
                .CreateLogger();
            try
            {
                CreateHostBuilder(args).Build().Run();

                Serilog.Log.Information($"Application started in environment: {Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")}");
            }
            catch (Exception e)
            {
                Serilog.Log.Error("MPPA.Server Host terminated unexpected", e);
                throw;
            }
            finally
            {
                Serilog.Log.Information("MPPA.Server stopped");
            }
            
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
            .UseSerilog((context, config) =>
            {
                config.ReadFrom.Configuration(context.Configuration);
            })
            .ConfigureServices(t => {
                t.AddLogging(configure => configure.AddConsole());
            })
            .ConfigureServices((hostContext, services) =>
            {
                services.AddHostedService<MppaHostedService>();
            });
    }
}
