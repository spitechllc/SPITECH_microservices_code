﻿using AutoMapper;
using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.Transaction.Application.Commands.CreateSettlement;
using SpiTech.Transaction.Application.Commands.ProcessStoreEodSettlement;
using SpiTech.Transaction.Application.Commands.ReconcileTransaction;
using System;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.EventConsumers
{
    public class TransactionSettlementEventConsumer : IConsumer<TransactionSettlementEvent>
    {
        private readonly IMediator mediator;
        private readonly IMapper mapper;
        private readonly ILogger<TransactionSettlementEventConsumer> logger;

        public TransactionSettlementEventConsumer(IMediator mediator,
            IMapper mapper,
            ILogger<TransactionSettlementEventConsumer> logger)
        {
            this.mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            this.mapper = mapper;
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task Consume(ConsumeContext<TransactionSettlementEvent> context)
        {
            logger.TraceEnterMethod(nameof(Consume), context);

            if (context.Message.SettlementRequest != null)
            {
                await mediator.Send(new CreateSettlementCommand
                {
                    SettlementInfo = context.Message.SettlementRequest
                });

                bool result = await mediator.Send(new ReconcileTransactionCommand
                {
                    SettlementPeriodId = context.Message.SettlementRequest.SettlementPeriodId,
                    SettlementRequestId = context.Message.SettlementRequest.SettlementRequestId,
                    SiteId = context.Message.SettlementRequest.SiteId,
                    StoreId = context.Message.SettlementRequest.StoreId,
                });

                await mediator.Send(new ProcessStoreEodSettlementQuery() { SettlementRequestId = context.Message.SettlementRequest.SettlementRequestId });
            }

            logger.Info($"TransactionSettlementEvent consumed successfully. SettlementRequestId : {context.Message.SettlementRequest.SettlementRequestId}");
        }
    }
}
