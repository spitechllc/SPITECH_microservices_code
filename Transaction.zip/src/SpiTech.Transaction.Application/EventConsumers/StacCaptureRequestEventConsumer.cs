﻿using AutoMapper;
using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.Transaction.Application.Commands.CreateTransaction;
using SpiTech.Transaction.Application.Queries.GetTransactionByTransactionId;
using System;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.EventConsumers
{
    public class StacCaptureRequestEventConsumer : IConsumer<StacCaptureRequestEvent>
    {
        private readonly IMediator mediator;
        private readonly ILogger<StacCaptureRequestEventConsumer> logger;
        private readonly IMapper mapper;

        public StacCaptureRequestEventConsumer(IMediator mediator,
            ILogger<StacCaptureRequestEventConsumer> logger,
            IMapper mapper)
        {
            this.mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.mapper = mapper;
        }

        public async Task Consume(ConsumeContext<StacCaptureRequestEvent> context)
        {
            logger.TraceEnterMethod(nameof(Consume), context);
            Domain.Entities.Transaction transaction = await mediator.Send(new GetTransactionByTransactionIdQuery { TransactionId = context.Message.Transaction.TransactionId });

            if (transaction == null)
            {
                logger.Info($"StaCaptureRequestEvent: Transaction not found");

                transaction = mapper.Map<Domain.Entities.Transaction>(context.Message.Transaction);

                await mediator.Send(new CreateTransactionCommand { Transaction = transaction });
            }

            logger.Info($"StaCaptureRequestEvent consumed successfully. TransactionId : {context.Message.Transaction.TransactionId}");
        }
    }
}
