﻿using AutoMapper;
using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.Transaction.Application.Commands.CreatePaymentInfo;
using SpiTech.Transaction.Application.Commands.CreateTransaction;
using SpiTech.Transaction.Application.Commands.UpdatePaymentInfo;
using SpiTech.Transaction.Application.Commands.UpdateTransaction;
using SpiTech.Transaction.Application.Queries.GetPaymentInfoByFilter;
using SpiTech.Transaction.Application.Queries.GetTransactionByTransactionId;
using SpiTech.Transaction.Domain.Entities;
using System;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.EventConsumers
{

    public class AuthMppaRequestEventConsumer : IConsumer<AuthMppaRequestEvent>
    {
        private readonly IMediator mediator;
        private readonly ILogger<AuthMppaRequestEventConsumer> logger;
        private readonly IMapper mapper;

        public AuthMppaRequestEventConsumer(IMediator mediator,
            ILogger<AuthMppaRequestEventConsumer> logger,
            IMapper mapper)
        {
            this.mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.mapper = mapper;
        }

        public async Task Consume(ConsumeContext<AuthMppaRequestEvent> context)
        {
            logger.TraceEnterMethod(nameof(Consume), context);

            logger.TraceEnterMethod("AuthMppaRequestEventConsumer", context);

            Domain.Entities.Transaction transaction = await mediator.Send(new GetTransactionByTransactionIdQuery { TransactionId = context.Message.Transaction.TransactionId });

            logger.TraceEnterMethod("transaction Variable", transaction);

            if (transaction == null)
            {
                transaction = mapper.Map<Domain.Entities.Transaction>(context.Message.Transaction);

                logger.TraceEnterMethod("before CreateTransactionCommand called", transaction);
                await mediator.Send(new CreateTransactionCommand { Transaction = transaction });
            }
            else
            {
                transaction = mapper.Map<Domain.Entities.Transaction>(context.Message.Transaction);

                logger.TraceEnterMethod("before UpdateTransactionCommand called transaction is null", transaction);
                await mediator.Send(new UpdateTransactionCommand { Transaction = transaction });
            }

            PaymentInfo paymentInfo = await mediator.Send(new GetPaymentInfoByFilterQuery
            {
                TransactionId = context.Message.Transaction.TransactionId
            });


            if (paymentInfo == null)
            {
                await mediator.Send(new CreatePaymentInfoCommand
                {
                    PaymentInfo = new PaymentInfo
                    {
                        CardCircuit = context.Message.PaymentInfo.CardCircuit,
                        CardISO = context.Message.PaymentInfo.CardISO,
                        CardPANPrint = context.Message.PaymentInfo.CardPANPrint,
                        CardType = context.Message.PaymentInfo.CardType,
                        HostAuthNumber = context.Message.PaymentInfo.HostAuthNumber,
                        PaymentMethod = context.Message.PaymentInfo.PaymentMethod,
                        PreAuthAmount = context.Message.PaymentInfo.PreAuthAmount,
                        TransactionId = context.Message.Transaction.TransactionId,
                    }
                });
            }
            else
            {
                paymentInfo.CardCircuit = context.Message.PaymentInfo.CardCircuit;
                paymentInfo.CardISO = context.Message.PaymentInfo.CardISO;
                paymentInfo.CardPANPrint = context.Message.PaymentInfo.CardPANPrint;
                paymentInfo.CardType = context.Message.PaymentInfo.CardType;
                paymentInfo.HostAuthNumber = context.Message.PaymentInfo.HostAuthNumber;
                paymentInfo.PaymentMethod = context.Message.PaymentInfo.PaymentMethod;
                paymentInfo.PreAuthAmount = context.Message.PaymentInfo.PreAuthAmount;
                paymentInfo.TransactionId = context.Message.Transaction.TransactionId;

                await mediator.Send(new UpdatePaymentInfoCommand
                {
                    PaymentInfo = paymentInfo
                });
            }

            logger.Info($"AuthMppaRequestEvent consumed successfully. TransactionId : {context.Message.Transaction.TransactionId}");
        }
    }
}
