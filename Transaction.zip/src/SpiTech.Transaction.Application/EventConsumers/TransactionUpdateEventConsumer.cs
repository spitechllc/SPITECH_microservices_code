﻿using AutoMapper;
using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.Transaction.Application.Commands.UpdateTransaction;
using SpiTech.Transaction.Application.Queries.GetTransactionByTransactionId;
using System;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.EventConsumers
{
    public class TransactionUpdateEventConsumer : IConsumer<TransactionUpdateEvent>
    {
        private readonly IMediator mediator;
        private readonly ILogger<TransactionUpdateEventConsumer> logger;
        private readonly IMapper mapper;

        public TransactionUpdateEventConsumer(IMediator mediator,
            ILogger<TransactionUpdateEventConsumer> logger,
            IMapper mapper)
        {
            this.mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.mapper = mapper;
        }

        public async Task Consume(ConsumeContext<TransactionUpdateEvent> context)
        {
            logger.TraceEnterMethod(nameof(Consume), context);
            Domain.Entities.Transaction transaction = await mediator.Send(new GetTransactionByTransactionIdQuery { TransactionId = context.Message.Transaction.TransactionId });

            if (transaction != null)
            {
                transaction = mapper.Map<Domain.Entities.Transaction>(context.Message.Transaction);

                await mediator.Send(new UpdateTransactionCommand { Transaction = transaction });
            }

            logger.Info($"TransactionUpdateEvent consumed successfully. TransactionId : {context.Message.Transaction.TransactionId}");
        }
    }
}
