﻿using AutoMapper;
using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.Transaction.Application.Commands.CreateTransaction;
using SpiTech.Transaction.Application.Queries.GetTransactionByTransactionId;
using System;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.EventConsumers
{
    public class PumpReserveRequestEventConsumer : IConsumer<PumpReserveRequestEvent>
    {
        private readonly IMediator mediator;
        private readonly ILogger<PumpReserveRequestEventConsumer> logger;
        private readonly IMapper mapper;

        public PumpReserveRequestEventConsumer(IMediator mediator,
            ILogger<PumpReserveRequestEventConsumer> logger,
            IMapper mapper)
        {
            this.mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.mapper = mapper;
        }

        public async Task Consume(ConsumeContext<PumpReserveRequestEvent> context)
        {
            logger.TraceEnterMethod(nameof(Consume), context);
            Domain.Entities.Transaction transaction = await mediator.Send(new GetTransactionByTransactionIdQuery { TransactionId = context.Message.Transaction.TransactionId });

            if (transaction == null)
            {
                logger.Info($"PumpReserveRequestEvent: Transaction not found");

                transaction = mapper.Map<Domain.Entities.Transaction>(context.Message.Transaction);

                await mediator.Send(new CreateTransactionCommand { Transaction = transaction });
            }

            logger.Info($"PumpReserveRequestEvent consumed successfully. TransactionId : {context.Message.Transaction.TransactionId}");
        }
    }
}
