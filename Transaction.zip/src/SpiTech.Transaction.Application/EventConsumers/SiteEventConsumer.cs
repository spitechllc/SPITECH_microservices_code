﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.Transaction.Application.Commands.UpdateGetSite;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using System;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.EventConsumers
{
    public class SiteEventConsumer : IConsumer<SiteEvent>
    {
        private readonly IUnitOfWork dbContext;
        private readonly IMediator mediator;
        private readonly ILogger<SiteEventConsumer> logger;

        public SiteEventConsumer(IUnitOfWork dbContext, IMediator mediator, ILogger<SiteEventConsumer> logger)
        {
            this.dbContext = dbContext;
            this.mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task Consume(ConsumeContext<SiteEvent> context)
        {
            logger.TraceEnterMethod(nameof(Consume), context);

            if (string.IsNullOrWhiteSpace(context.Message.SiteId))
            {
                return;
            }

            var updateSite = await mediator.Send(new UpdateGetSiteCommand
            {
                SiteId = context.Message.SiteId,
                StoreId = context.Message.StoreId ?? 0,
                StoreName = context.Message.StoreName,
                Update = true
            });

            Site newSite = new()
            {
                SiteId = updateSite.SiteId,
                SiteName = context.Message.SiteName,
                SiteMPPAIdentifier = context.Message.SiteMPPAIdentifier,
                MerchantId = context.Message.MerchantId,
                LocationId = context.Message.LocationId,
                SiteMobileActive = context.Message.SiteMobileActive,
                SiteAddress = context.Message.SiteAddress,
                SettlementEmployee = context.Message.SettlementEmployee,
                PartialAuthAllowed = context.Message.PartialAuthAllowed,
                PumpTimeout = context.Message.PumpTimeout,
                StoreId = updateSite.StoreId,
                StoreName = updateSite.StoreName,
                IsActive = true,
                CurrentHeartBeatTime = DateTime.UtcNow,
            };

            var site = await dbContext.Sites.GetByStoreId(context.Message.SiteId);

            try
            {
                if (site == null)
                {
                    await dbContext.Sites.Add(newSite);
                }
                else
                {
                    await dbContext.Sites.Update(newSite);
                }

                dbContext.Commit();
            }
            catch (Exception ex)
            {
                logger.Error(ex, context.Message);
                dbContext.Rollback();
            }

            logger.Info($"SiteEvent consumed successfully. TransactionId : {context.Message.SiteId}");
        }
    }
}
