﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.Transaction.Application.Commands.UpdateTransaction;
using SpiTech.Transaction.Application.Queries.GetTransactionByTransactionId;
using System;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.EventConsumers
{
    public class PaymentStatusEventConsumer : IConsumer<PaymentStatusEvent>
    {
        private readonly IMediator mediator;
        private readonly ILogger<PaymentStatusEventConsumer> logger;

        public PaymentStatusEventConsumer(IMediator mediator, ILogger<PaymentStatusEventConsumer> logger)
        {
            this.mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task Consume(ConsumeContext<PaymentStatusEvent> context)
        {
            logger.TraceEnterMethod(nameof(Consume), context);
            Domain.Entities.Transaction transaction = await mediator.Send(new GetTransactionByTransactionIdQuery { TransactionId = context.Message.TransactionId });

            if (transaction != null)
            {
                transaction.IsPaymentSuccess = context.Message.IsSuccess;
                await mediator.Send(new UpdateTransactionCommand { Transaction = transaction });
            }

            logger.Info($"PaymentStatusEvent consumed successfully. TransactionId : {context.Message.TransactionId}");
        }
    }
}
