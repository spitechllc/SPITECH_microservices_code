﻿using AutoMapper;
using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.Transaction.Application.Commands.CreateSaleItem;
using SpiTech.Transaction.Application.Commands.CreateTransaction;
using SpiTech.Transaction.Application.Commands.UpdateTransaction;
using SpiTech.Transaction.Application.Queries.GetSaleItemByFilter;
using SpiTech.Transaction.Application.Queries.GetTransactionByTransactionId;
using SpiTech.Transaction.Domain.Models;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.EventConsumers
{
    public class FinalizeRequestEventConsumer : IConsumer<FinalizeRequestEvent>
    {
        private readonly IMediator mediator;
        private readonly ILogger<FinalizeRequestEventConsumer> logger;
        private readonly IMapper mapper;

        public FinalizeRequestEventConsumer(IMediator mediator,
            ILogger<FinalizeRequestEventConsumer> logger,
            IMapper mapper)
        {
            this.mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.mapper = mapper;
        }

        public async Task Consume(ConsumeContext<FinalizeRequestEvent> context)
        {
            logger.TraceEnterMethod(nameof(Consume), context);

            Domain.Entities.Transaction transaction = await mediator.Send(new GetTransactionByTransactionIdQuery { TransactionId = context.Message.Transaction.TransactionId });

            if (transaction == null)
            {
                transaction = mapper.Map<Domain.Entities.Transaction>(context.Message.Transaction);

                await mediator.Send(new CreateTransactionCommand { Transaction = transaction });
            }
            else
            {
                transaction = mapper.Map<Domain.Entities.Transaction>(context.Message.Transaction);

                await mediator.Send(new UpdateTransactionCommand { Transaction = transaction });
            }

            await CreateTransactionSaleItems(context);

            logger.Info($"FinalizeRequestEvent consumed successfully. TransactionId : {context.Message.Transaction.TransactionId}");
        }

        private async Task CreateTransactionSaleItems(ConsumeContext<FinalizeRequestEvent> context)
        {
            if (context.Message.SaleItems != null)
            {
                System.Collections.Generic.IEnumerable<SaleItemModel> saleItems = await mediator.Send(new GetSaleItemByFilterQuery { TransactionId = context.Message.Transaction.TransactionId });

                if (saleItems == null || !saleItems.Any())
                {
                    await mediator.Send(new CreateSaleItemCommand
                    {
                        TransactionId = context.Message.Transaction.TransactionId,
                        SaleItems = context.Message.SaleItems?.Select(saleItem => new SaleItemModel
                        {
                            ItemId = saleItem.ItemID,
                            EvaluateOnly = saleItem.EvaluateOnly,
                            ReverseSale = saleItem.ReverseSale,
                            ItemStatus = saleItem.ItemStatus,
                            PriceChangeEligible = saleItem.PriceChangeEligible,
                            POSCode = saleItem.POSCode,
                            POSCodeModifier = saleItem.POSCodeModifier,
                            POSCodeFormat = saleItem.POSCodeFormat,
                            ProductCode = saleItem.ProductCode,
                            OriginalAmount = saleItem.OriginalAmount,
                            OriginalAmountUnitPrice = saleItem.OriginalAmountUnitPrice,
                            AdjustedAmount = saleItem.AdjustedAmount,
                            AdjustedAmountUnitPrice = saleItem.AdjustedAmountUnitPrice,
                            UnitMeasure = saleItem.UnitMeasure,
                            Quantity = saleItem.Quantity,
                            AdditionalProductInfo = saleItem.AdditionalProductInfo,
                            Description = saleItem.Description,
                            PriceTier = saleItem.PriceTier,
                            RebateLabel = saleItem.RebateLabel,
                            ServiceLevel = saleItem.ServiceLevel,
                            OutdoorPosition = saleItem.OutdoorPosition,
                            TransactionId = context.Message.Transaction.TransactionId,
                            PriceAdjustments = saleItem.PriceAdjustments?.Select(priceAdjustment => new PriceAdjustmentModel
                            {
                                RewardApplied = priceAdjustment.RewardApplied,
                                AdjustmentId = priceAdjustment.PriceAdjustmentId,
                                ProgramId = priceAdjustment.ProgramId,
                                DoNotRelieveTaxFlag = priceAdjustment.DoNotRelieveTaxFlag,
                                PromotionReason = priceAdjustment.PromotionReason,
                                Amount = priceAdjustment.Amount,
                                UnitPrice = priceAdjustment.UnitPrice,
                                Quantity = priceAdjustment.Quantity,
                                RebateLabel = priceAdjustment.RebateLabel,
                            }).ToArray()
                        }).ToArray()
                    });
                }
            }
        }
    }
}
