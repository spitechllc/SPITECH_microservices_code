﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.EventConsumers
{
    public class ReconcileFailTransactionEventConsumer : IConsumer<ReconcileFailTransactionEvent>
    {
        private readonly IUnitOfWork dbContext;
        private readonly IMediator mediator;
        private readonly ILogger<ReconcileFailTransactionEventConsumer> logger;

        public ReconcileFailTransactionEventConsumer(IUnitOfWork dbContext, IMediator mediator, ILogger<ReconcileFailTransactionEventConsumer> logger)
        {
            this.dbContext = dbContext;
            this.mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task Consume(ConsumeContext<ReconcileFailTransactionEvent> context)
        {
            logger.TraceEnterMethod(nameof(Consume), context);

            try
            {
                var result = await dbContext.Transactions.ReconcileFailTransactions(context.Message.TransactionIds);
                dbContext.Commit();
            }
            catch (Exception ex)
            {
                logger.Error(ex, context.Message);
                dbContext.Rollback();
            }

            logger.Info($"ReconcileFailTransactionEvent consumed successfully. StoreId : {context.Message.TransactionIds}");
        }

    }
}
