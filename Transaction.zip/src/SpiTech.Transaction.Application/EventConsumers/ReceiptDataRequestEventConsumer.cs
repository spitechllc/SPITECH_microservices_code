﻿using AutoMapper;
using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.Transaction.Application.Commands.CreateReceiptInfoLine;
using SpiTech.Transaction.Application.Commands.CreateTransaction;
using SpiTech.Transaction.Application.Commands.UpdateTransaction;
using SpiTech.Transaction.Application.Queries.GetReceiptInfoLineByTransactionId;
using SpiTech.Transaction.Application.Queries.GetTransactionByTransactionId;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.EventConsumers
{
    public class ReceiptDataRequestEventConsumer : IConsumer<ReceiptDataRequestEvent>
    {
        private readonly IMediator mediator;
        private readonly ILogger<ReceiptDataRequestEventConsumer> logger;
        private readonly IMapper mapper;

        public ReceiptDataRequestEventConsumer(IMediator mediator,
            ILogger<ReceiptDataRequestEventConsumer> logger,
            IMapper mapper)
        {
            this.mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.mapper = mapper;
        }

        public async Task Consume(ConsumeContext<ReceiptDataRequestEvent> context)
        {
            logger.TraceEnterMethod(nameof(Consume), context);

            Domain.Entities.Transaction transaction = await mediator.Send(new GetTransactionByTransactionIdQuery { TransactionId = context.Message.Transaction.TransactionId });

            if (transaction == null)
            {
                logger.Info($"PumpReserveRequestEvent: Transaction not found");

                transaction = mapper.Map<Domain.Entities.Transaction>(context.Message.Transaction);

                await mediator.Send(new CreateTransactionCommand { Transaction = transaction });
            }
            else
            {
                transaction = mapper.Map<Domain.Entities.Transaction>(context.Message.Transaction);

                await mediator.Send(new UpdateTransactionCommand { Transaction = transaction });
            }

            System.Collections.Generic.IEnumerable<Domain.Models.ReceiptInfoLineModel> receiptlines = await mediator.Send(new GetReceiptInfoLineByTransactionIdQuery
            {
                TransactionId = context.Message.Transaction.TransactionId
            });

            if (receiptlines == null || !receiptlines.Any())
            {
                await mediator.Send(new CreateReceiptInfoLineCommand
                {
                    ReceiptLines = context.Message.ReceiptLines,
                    TransactionId = context.Message.Transaction.TransactionId
                });
            }

            logger.Info($"ReceiptDataRequestEvent consumed successfully. TransactionId : {context.Message.Transaction.TransactionId}");
        }
    }
}
