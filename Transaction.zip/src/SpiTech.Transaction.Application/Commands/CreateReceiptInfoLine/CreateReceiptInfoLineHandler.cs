﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.CreateReceiptInfoLine
{
    public class CreateReceiptInfoLineHandler : IRequestHandler<CreateReceiptInfoLineCommand, bool>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateReceiptInfoLineHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        public CreateReceiptInfoLineHandler(IUnitOfWork context,
                                             ILogger<CreateReceiptInfoLineHandler> logger,
                                             IMapper mapper,
        IEventDispatcher eventDispatcher,
        IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        /// <summary>
        /// Create ReceiptInfoLines 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<bool> Handle(CreateReceiptInfoLineCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            string receiptLines = "";

            if (command.ReceiptLines != null)
            {
                receiptLines = string.Join("\n\r", command.ReceiptLines);
            }

            int receiptid = 0;

            await _context.Execute(async () =>
            {
                receiptid = await _context.ReceiptInfoLines.Add(new Domain.Entities.ReceiptInfoLine()
                {
                    TransactionId = command.TransactionId,
                    ReceiptLine = receiptLines,
                    CreatedOn = DateTime.UtcNow,
                    IsActive = true
                });
            });

            _logger.TraceExitMethod(nameof(Handle), true);
            await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication()?.UserId??0, (int)ActivityType.CreateReceiptInfoLine, "ReceiptInfo Created.", false, null);
            return true;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress(),
                IsError = isError,
                ErrorMessage = errorMessage

            });
        }
    }
}
