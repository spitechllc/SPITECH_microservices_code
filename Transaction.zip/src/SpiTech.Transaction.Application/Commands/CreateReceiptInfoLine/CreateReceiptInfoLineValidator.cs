﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.CreateReceiptInfoLine
{
    public class CreateReceiptInfoLineValidator : AbstractValidator<CreateReceiptInfoLineCommand>
    {
        public CreateReceiptInfoLineValidator()
        {
            RuleFor(x => x.TransactionId).GreaterThan(0).WithMessage("TransactionId must be greater than 0");
            RuleFor(x => x.ReceiptLines).NotNull().WithMessage("ReceiptLines is required");
        }
    }
}
