﻿using MediatR;

namespace SpiTech.Transaction.Application.Commands.CreateReceiptInfoLine
{
    public class CreateReceiptInfoLineCommand : IRequest<bool>
    {
        public long TransactionId { get; set; }
        public string[] ReceiptLines { get; set; }
    }
}
