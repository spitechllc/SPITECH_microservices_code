﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.Services;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using ResponseModel = SpiTech.ApplicationCore.Domain.Models.ResponseModel;

namespace SpiTech.Transaction.Application.Commands.ProcessSaleAgentMonthlyInvoice
{
    public class ProcessSaleAgentMonthlyInvoiceHandler : IRequestHandler<ProcessSaleAgentMonthlyInvoiceQuery, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<ProcessSaleAgentMonthlyInvoiceHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IHtmlPdfConverterService converterService;
        private readonly IStorageService storageService;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IStoreServiceClient storeapiclient;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public ProcessSaleAgentMonthlyInvoiceHandler(IUnitOfWork context,
                                                 ILogger<ProcessSaleAgentMonthlyInvoiceHandler> logger,
                                                 IMapper mapper,
                                                 IStorageServiceFactory storageServiceFactory,
                                                 IHtmlPdfConverterService converterService,
                                                 IEventDispatcher eventDispatcher,
                                                 IStoreServiceClient storeapiclient,
                                                 IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.converterService = converterService;
            this.storageService = storageServiceFactory.Get(ContainerType.SaleAgentMonthlyInvoicePdf);
            _eventDispatcher = eventDispatcher;
            this.storeapiclient = storeapiclient;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<ResponseModel> Handle(ProcessSaleAgentMonthlyInvoiceQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            var saleAgentBillings = await _context.SaleAgentBillings.GetUnprocessedMontlyInvoiceBatch();

            if (saleAgentBillings == null || !saleAgentBillings.Any())
            {
                return null;
            }

            ResponseModel res = new ResponseModel() { Success = false };
            try
            {
                var salesAgents = await storeapiclient.SaleAgentsAsync(saleAgentBillings.Select(t => t.SaleAgentId).Distinct(), cancellationToken);

                foreach (var saleAgentBilling in saleAgentBillings)
                {
                    var salesAgent = salesAgents.FirstOrDefault(t => t.SaleAgentId == saleAgentBilling.SaleAgentId);
                    saleAgentBilling.SaleAgentName = salesAgent?.FirstName + " " + salesAgent?.LastName;

                    byte[] fileBytes = await this.converterService.CreatePdfFromView("SaleAgentMonthlyInvoice", saleAgentBilling);

                    await SaveAndDispatchEmailEvent(saleAgentBilling, fileBytes);
                }

                res.Success = true;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
            _logger.TraceExitMethod(nameof(Handle), res);
            return res;
        }

        private async Task SaveAndDispatchEmailEvent(SaleAgentBillingModel saleAgentBilling, byte[] fileBytes)
        {
            saleAgentBilling.InvoiceFileName = saleAgentBilling.SaleAgentBillingId + "_saleagentmonthlyinvoice" + "_" + UniqueIdGenerator.Generate() + ".pdf";

            saleAgentBilling.InvoiceFilePath = await SaveFile(Convert.ToBase64String(fileBytes), saleAgentBilling.InvoiceFileName, "application/pdf");

            if (!string.IsNullOrEmpty(saleAgentBilling.InvoiceFilePath))
            {
                await _context.SaleAgentBillings.UpdateInvoicePdfFilePath(saleAgentBilling.SaleAgentBillingId, saleAgentBilling.InvoiceFileName, saleAgentBilling.InvoiceFilePath);


                if (saleAgentBilling.TotalFee > 0 && saleAgentBilling.ProcessStatus != DomainConstant.ProcessStatus.Completed)
                {
                    await _eventDispatcher.Dispatch(new SaleAgentMonthlyBillingInvoiceEvent
                    {
                        SaleAgentBilling = saleAgentBilling
                    });

                    await _context.SaleAgentBillings.UpdateProcessStatus(saleAgentBilling.SaleAgentBillingId, DomainConstant.ProcessStatus.Completed);
                }

                _context.Commit();
            }
        }

        private async Task<string> SaveFile(string base64file, string filename, string contenttype)
        {
            await storageService.UploadBlobBase64(base64file, filename, contenttype);
            Blob res = await storageService.GetFile(filename);
            return res != null ? res.StorageUri : string.Empty;
        }
    }
}
