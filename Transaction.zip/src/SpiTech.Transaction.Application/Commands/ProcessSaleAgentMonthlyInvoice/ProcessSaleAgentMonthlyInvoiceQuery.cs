﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.ProcessSaleAgentMonthlyInvoice
{
    public class ProcessSaleAgentMonthlyInvoiceQuery : IRequest<ResponseModel>
    {
    }
}
