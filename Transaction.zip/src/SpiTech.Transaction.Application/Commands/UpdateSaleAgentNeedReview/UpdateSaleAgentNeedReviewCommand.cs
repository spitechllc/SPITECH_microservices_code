﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.UpdateSaleAgentNeedReview
{
    public class UpdateSaleAgentNeedReviewCommand : IRequest<ResponseModel>
    {
        public int[] SaleAgentBillingIds { get; set; }
        public bool IsNeedReview { get; set; }
    }
}
