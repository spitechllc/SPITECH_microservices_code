﻿using FluentValidation;
using System.Linq;

namespace SpiTech.Transaction.Application.Commands.UpdateSaleAgentNeedReview
{
    public class UpdateSaleAgentNeedReviewValidator : AbstractValidator<UpdateSaleAgentNeedReviewCommand>
    {
        public UpdateSaleAgentNeedReviewValidator()
        {
            RuleFor(x => x.SaleAgentBillingIds).Cascade(CascadeMode.Stop)
                                                .NotNull()
                                                .NotEmpty()
                                                .Must(NotEqualZero)
                                                .WithMessage("SaleAgentBillingId should be valid");
        }

        private bool NotEqualZero(int[] storeBillingIds)
        {
            return storeBillingIds?.All(i => i > 0) ?? false;
        }
    }
}
