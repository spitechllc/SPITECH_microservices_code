﻿using AutoMapper;
using IdentityModel.Client;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain;
using SpiTech.ApplicationCore.Domain.Configs;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Services;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.Transaction.Application.Commands.CreateLogInfo;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Transaction.Application.Commands.ProcessAchNachaReturnFile
{
    public class ProcessAchNachaReturnFileHandler : IRequestHandler<ProcessAchNachaReturnFileCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<ProcessAchNachaReturnFileHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider authenticationProvider;
        private readonly IMediator _mediator;

        public IServiceScope ServiceScope { get; set; }
        private readonly IFnboEncryptService fnboEncryptService;
        private readonly ISftpService _sftpService;
        private readonly IEventDispatcher eventDispatcher;
        private readonly SftpConfigs sftpConfigs;
        private readonly IStorageService fnboStorageService;
        CultureInfo provider = CultureInfo.InvariantCulture;
        public static string RoutingNo, GUID;

        public ProcessAchNachaReturnFileHandler(IUnitOfWork context,
                                                 ILogger<ProcessAchNachaReturnFileHandler> logger,
                                                 IMapper mapper,
                                                 IStorageServiceFactory storageServiceFactory,
                                                 IUserAuthenticationProvider authenticationProvider,
                                                 IFnboEncryptService fnboEncryptService,
                                                SftpConfigs sftpConfigs,
                                        ISftpService sftpService,
                                        IEventDispatcher eventDispatcher, IMediator mediator)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _mediator = mediator;
            this.authenticationProvider = authenticationProvider;

            this.fnboEncryptService = fnboEncryptService;
            this.sftpConfigs = sftpConfigs;
            this.fnboStorageService = storageServiceFactory.Get(ContainerType.FNBOReceivedNachaFile);
            _sftpService = sftpService;
            this.eventDispatcher = eventDispatcher;
        }

        public async Task<ResponseModel> Handle(ProcessAchNachaReturnFileCommand request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            ResponseModel res = new ResponseModel() { Success = false };
            CreateLogInfoCommand command = new CreateLogInfoCommand();

            var status = sftpConfigs.Get(DomainConstant.SftpConfig.FNBO).ExecReturnFile;
            if (!string.IsNullOrEmpty(status))
            {
                command.Message = "File Process Status : " + status + "";
                command.Exception = "";
                await _mediator.Send(command);
            }
            
            try
            {
                var fnboConfig = this.sftpConfigs.Get(DomainConstant.SftpConfig.FNBO);
                var files = this._sftpService.GetFiles(fnboConfig.DownloadFolder, fnboConfig);

                if (files != null && files.Any())
                {
                    _logger.Warn($"Files exists for process starting");

                    command.Method = "Files exists for process starting ";
                    command.Message = fnboConfig.DownloadFolder + "" + fnboConfig.ExecReturnFile;
                    command.Exception = "";
                    await _mediator.Send(command);

                    var unProcessedFileDetails = this._sftpService.DownloadFiles(files, fnboConfig);
                    foreach (var unProcessedFileDetail in unProcessedFileDetails)
                    {
                        var fileName = unProcessedFileDetail.FileName;

                        string checkExistFile = await _context.FnboReturnHeaders.CheckFileName(fileName);

                        if (!string.IsNullOrEmpty(checkExistFile))
                        {
                            continue;
                        }

                        var achNachaReturnFileEvent = new AchNachaReturnFileEvent();

                        achNachaReturnFileEvent.TranGuid = GUID = Guid.NewGuid().ToString("N");

                        try
                        {
                            await this.fnboStorageService.UploadBlob(unProcessedFileDetail.Bytes, unProcessedFileDetail.FileName, "text/plain");

                            Blob blobProcess = await fnboStorageService.GetFile(unProcessedFileDetail.FileName);
                            achNachaReturnFileEvent.ReturnFileName = fileName;
                            achNachaReturnFileEvent.ReturnFilePath = blobProcess.StorageUri;

                            command.Method = "ReturnFileName and ReturnFilePath  is ";
                            command.Message = fileName + "" + blobProcess.StorageUri;
                            command.Exception = "Got file";
                            await _mediator.Send(command);

                            using (Stream encryptStream = new MemoryStream(unProcessedFileDetail.Bytes))
                            {
                                using (var decryptedStream = await fnboEncryptService.Decrypt(encryptStream, fnboConfig.DecryptKeyFile, fnboConfig.DecryptPassword))
                                {
                                    var decryptFileName = achNachaReturnFileEvent.TranGuid + unProcessedFileDetail.FileName.Replace(".pgp", "");

                                    await this.fnboStorageService.UploadBlob(decryptedStream, decryptFileName, "text/plain");

                                    Blob blobDecryptedStreamProcess = await fnboStorageService.GetFile(decryptFileName);
                                    achNachaReturnFileEvent.DecryptFileName = decryptFileName;
                                    achNachaReturnFileEvent.DecryptFilePath = blobDecryptedStreamProcess.StorageUri;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.Error(ex, $"unProcessedFileDetail in ParseACHReturnFile at: {DateTimeOffset.Now}");
                        }

                        Stream stream = new MemoryStream(unProcessedFileDetail.Bytes.ToArray());

                        Stream streamTest = new MemoryStream(unProcessedFileDetail.Bytes.ToArray());
                        StreamReader src = new StreamReader(streamTest);
                        string fileContent = src.ReadToEnd();
                        _logger.Warn($"ACH parse file content is: {fileContent}");

                        command.Method = "ACH parse file content is final check ";
                        command.Message = fileContent;
                        command.Exception = "Got file";
                        await _mediator.Send(command);

                        //var bytes = await System.IO.File.ReadAllBytesAsync("SETTLEMENT638192926721045904_20230510051752.txt");
                        //Stream stream = new MemoryStream(bytes);


                        using (var decryptedStream = await fnboEncryptService.Decrypt(stream, fnboConfig.DecryptKeyFile, fnboConfig.DecryptPassword))
                        {
                            using (StreamReader sr = new StreamReader(decryptedStream))
                            {
                                string line;
                                while ((line = sr.ReadLine()) != null)
                                {
                                    if (line.Length > 0 && !string.IsNullOrEmpty(line))
                                    {

                                        string RowWiseData = line;
                                        _logger.Warn($"ACH parse file content is: {RowWiseData}");
                                        if (Convert.ToInt32(RowWiseData.Substring(0, 1)) == (int)FnboReturnFile.FileHeader)
                                        {
                                            _logger.Warn($"ACH Header file process value with datetime : {DateTimeOffset.Now} " + RowWiseData.Substring(0, 1));
                                            var fnboReturnHeaderId = await _context.FnboReturnHeaders.Add(new Domain.Entities.FnboReturnHeader()
                                            {
                                                TranGuid = GUID,
                                                TypeOfRecord = RowWiseData.Substring(0, 1),
                                                FileName = fileName,
                                                RecordTypeCode = RowWiseData.Substring(1, 2),
                                                PriorityCode = RowWiseData.Substring(1, 2),
                                                RoutingNumber = RowWiseData.Substring(4, 9),
                                                SecCode = RowWiseData.Substring(50, 3),
                                                FederalId = "",
                                                FileCreationDate = DateTime.ParseExact(RowWiseData.Substring(23, 6), "yyMMdd", provider).ToShortDateString(),
                                                FileCreationTime = RowWiseData.Substring(29, 4),
                                                BankName = RowWiseData.Substring(40, 22),
                                                CompanyName = RowWiseData.Substring(63, 22),
                                                ReturnFilePath = achNachaReturnFileEvent.ReturnFilePath,
                                                DecryptFileName = achNachaReturnFileEvent.DecryptFileName,
                                                DecryptFilePath = achNachaReturnFileEvent.DecryptFilePath,
                                            });
                                        }
                                        else if (Convert.ToInt32(RowWiseData.Substring(0, 1)) == (int)FnboReturnFile.Transaction)
                                        {
                                            try
                                            {
                                                _logger.Warn($"ACH Transaction file process value with datetime : {DateTimeOffset.Now} " + RowWiseData.Substring(0, 1));
                                                await _context.FnboReturnTransactions.Add(new Domain.Entities.FnboReturnTransaction()
                                                {
                                                    TranGuid = GUID,
                                                    TransactionCode = RowWiseData.Substring(1, 2),
                                                    TypeOfRecord = "Transactions",
                                                    RecordTypeCode = Convert.ToInt32(RowWiseData.Substring(0, 1)),
                                                    ACHReturnCode = "",
                                                    ReturnCodeStatus = "",
                                                    ReceivingDFIId = Convert.ToInt32(RowWiseData.Substring(3, 9)),
                                                    DFIAccountNumber = RowWiseData.Substring(12, 16),
                                                    //Amount = RowWiseData.Substring(29, 9),
                                                    Amount = Convert.ToDecimal(RowWiseData.Substring(29, 8) + '.' + RowWiseData.Substring(37, 2)),
                                                    IdentificationNumber = RowWiseData.Substring(39, 14),
                                                    ReceivingCompanyName = RowWiseData.Substring(54, 22),
                                                    NachaAchFile = "",
                                                    HeaderRouteNumber = RoutingNo,
                                                    CreateDate = DateTime.Now,
                                                    CreatedOn = DateTime.UtcNow,
                                                    IsActive = true
                                                });
                                            }
                                            catch (Exception ex)
                                            {
                                                _logger.Error(ex, $"Error at Ach transaction file: {DateTimeOffset.Now}");
                                            }
                                        }
                                        else
                                        {
                                            _logger.Warn($"ACH Other file process value with datetime : {DateTimeOffset.Now} " + RowWiseData.Substring(0, 1));
                                            FnboReturnOtherModel fnboReturnOtherModel = new FnboReturnOtherModel();
                                            fnboReturnOtherModel.RecordTypeCode = Convert.ToInt32(RowWiseData.Substring(0, 1));

                                            if (fnboReturnOtherModel.RecordTypeCode == (int)FnboReturnFile.BatchHeader)
                                            {
                                                if (fnboReturnOtherModel.RecordTypeCode == 5)
                                                {
                                                    fnboReturnOtherModel.RecordType = "Batch Header";
                                                }
                                                if ((RowWiseData.Substring(3, 1)) == "R")
                                                {
                                                    fnboReturnOtherModel.ACHReturnCode = RowWiseData.Substring(3, 3);
                                                    if ((fnboReturnOtherModel.ACHReturnCode) == "R02" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R03" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R04")
                                                    {
                                                        fnboReturnOtherModel.ReturnCodeStatus = "Administrative Return Codes";
                                                    }
                                                    else if ((fnboReturnOtherModel.ACHReturnCode) == "R05" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R07" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R10" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R11" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R29" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R51")
                                                    {
                                                        fnboReturnOtherModel.ReturnCodeStatus = "Unauthorized Return Codes";
                                                    }
                                                    else
                                                    {
                                                        fnboReturnOtherModel.ReturnCodeStatus = "Other Return Codes";
                                                    }
                                                }

                                                fnboReturnOtherModel.ServiceClassCode = Convert.ToInt32(RowWiseData.Substring(1, 3));
                                                fnboReturnOtherModel.CompanyName = RowWiseData.Substring(4, 16);
                                                fnboReturnOtherModel.CompanyIdentification = RowWiseData.Substring(40, 10);
                                                fnboReturnOtherModel.SECCode = RowWiseData.Substring(50, 3);

                                                fnboReturnOtherModel.CompanyEntryDesc = RowWiseData.Substring(53, 10);
                                                fnboReturnOtherModel.CompanyDescDate = RowWiseData.Substring(63, 6);
                                                fnboReturnOtherModel.OriginatingDFIID = RowWiseData.Substring(79, 7);
                                                fnboReturnOtherModel.EffectiveEntryDate = RowWiseData.Substring(69, 6);
                                                fnboReturnOtherModel.Reserved = RowWiseData.Substring(75, 3);
                                                fnboReturnOtherModel.GUID = GUID;
                                            }

                                            if (fnboReturnOtherModel.RecordTypeCode == (int)FnboReturnFile.AddendaRecord)
                                            {
                                                if ((RowWiseData.Substring(3, 1)) == "R")
                                                {
                                                    fnboReturnOtherModel.ACHReturnCode = RowWiseData.Substring(3, 3);
                                                    if ((fnboReturnOtherModel.ACHReturnCode) == "R02" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R03" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R04")
                                                    {
                                                        fnboReturnOtherModel.ReturnCodeStatus = "Administrative Return Codes";
                                                    }
                                                    else if ((fnboReturnOtherModel.ACHReturnCode) == "R05" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R07" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R10" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R11" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R29" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R51")
                                                    {
                                                        fnboReturnOtherModel.ReturnCodeStatus = "Unauthorized Return Codes";
                                                    }
                                                    else
                                                    {
                                                        fnboReturnOtherModel.ReturnCodeStatus = "Other Return Codes";
                                                    }
                                                }

                                                fnboReturnOtherModel.RecordType = "Addenda record";
                                                fnboReturnOtherModel.AddendaTypeCode = RowWiseData.Substring(1, 2);
                                                fnboReturnOtherModel.AddendaPaymentRelatedInformation = RowWiseData.Substring(3, 80);
                                                fnboReturnOtherModel.AddendaSequenceNumber = Convert.ToInt32(RowWiseData.Substring(83, 4));
                                                fnboReturnOtherModel.AddendaEntryDetailSeqNo = Convert.ToInt32(RowWiseData.Substring(87, 7));
                                                fnboReturnOtherModel.GUID = GUID;
                                            }

                                            if (fnboReturnOtherModel.RecordTypeCode == (int)(FnboReturnFile.BatchFooter))
                                            {
                                                if ((RowWiseData.Substring(3, 1)) == "R")
                                                {
                                                    fnboReturnOtherModel.ACHReturnCode = RowWiseData.Substring(3, 3);
                                                    if ((fnboReturnOtherModel.ACHReturnCode) == "R02" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R03" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R04")
                                                    {
                                                        fnboReturnOtherModel.ReturnCodeStatus = "Administrative Return Codes";
                                                    }
                                                    else if ((fnboReturnOtherModel.ACHReturnCode) == "R05" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R07" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R10" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R11" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R29" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R51")
                                                    {
                                                        fnboReturnOtherModel.ReturnCodeStatus = "Unauthorized Return Codes";
                                                    }
                                                    else
                                                    {
                                                        fnboReturnOtherModel.ReturnCodeStatus = "Other Return Codes";
                                                    }
                                                }
                                                fnboReturnOtherModel.RecordType = "Batch Footer";
                                                fnboReturnOtherModel.ServiceClassCode = Convert.ToInt32(RowWiseData.Substring(1, 3));


                                                fnboReturnOtherModel.TotalDebitEntry = RowWiseData.Substring(21, 12);
                                                fnboReturnOtherModel.TotalCreditEntry = RowWiseData.Substring(33, 12);
                                                fnboReturnOtherModel.Reserved = RowWiseData.Substring(73, 6);
                                                fnboReturnOtherModel.OriginatingDFIID = RowWiseData.Substring(79, 8);
                                                fnboReturnOtherModel.BatchNumber = Convert.ToInt32(RowWiseData.Substring(87, 7));
                                                fnboReturnOtherModel.CompanyIdentification = RowWiseData.Substring(44, 10);
                                                fnboReturnOtherModel.GUID = GUID;

                                            }

                                            if (fnboReturnOtherModel.RecordTypeCode == (int)FnboReturnFile.FileFooter)
                                            {
                                                if ((RowWiseData.Substring(3, 1)) == "R")
                                                {
                                                    fnboReturnOtherModel.ACHReturnCode = RowWiseData.Substring(3, 3);
                                                    if ((fnboReturnOtherModel.ACHReturnCode) == "R02" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R03" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R04")
                                                    {
                                                        fnboReturnOtherModel.ReturnCodeStatus = "Administrative Return Codes";
                                                    }
                                                    else if ((fnboReturnOtherModel.ACHReturnCode) == "R05" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R07" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R10" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R11" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R29" ||
                                                        (fnboReturnOtherModel.ACHReturnCode) == "R51")
                                                    {
                                                        fnboReturnOtherModel.ReturnCodeStatus = "Unauthorized Return Codes";
                                                    }
                                                    else
                                                    {
                                                        fnboReturnOtherModel.ReturnCodeStatus = "Other Return Codes";
                                                    }
                                                }
                                                fnboReturnOtherModel.RecordType = "File Footer";
                                                fnboReturnOtherModel.TotalDebitEntry = RowWiseData.Substring(31, 12);
                                                fnboReturnOtherModel.TotalCreditEntry = RowWiseData.Substring(43, 12);
                                                fnboReturnOtherModel.Reserved = RowWiseData.Substring(55, 3);

                                                fnboReturnOtherModel.GUID = GUID;

                                            }
                                            fnboReturnOtherModel.HeaderRouteNumber = RoutingNo;
                                            fnboReturnOtherModel.BankName = "";
                                            fnboReturnOtherModel.PriorityCode = 0;
                                            fnboReturnOtherModel.RoutingNumber = "";

                                            await _context.FnboReturnOthers.Add(new Domain.Entities.FnboReturnOther()
                                            {
                                                TranGuid = GUID,
                                                RecordTypeCode = Convert.ToInt32(fnboReturnOtherModel.RecordTypeCode),
                                                ServiceClassCode = Convert.ToString(RowWiseData.Substring(1, 3)),
                                                RecordType = fnboReturnOtherModel.RecordType,
                                                ACHReturnCode = fnboReturnOtherModel.ACHReturnCode ?? "",
                                                ReturnCodeStatus = fnboReturnOtherModel.ReturnCodeStatus ?? "",
                                                PriorityCode = 0,
                                                RoutingNumber = fnboReturnOtherModel.RoutingNumber,
                                                CompanyName = fnboReturnOtherModel.CompanyName,
                                                CompanyIdentification = fnboReturnOtherModel.CompanyIdentification,
                                                CompanyEntryDesc = fnboReturnOtherModel.CompanyEntryDesc,
                                                CompanyDescDate = fnboReturnOtherModel.CompanyDescDate,
                                                OriginatingDFIID = fnboReturnOtherModel.OriginatingDFIID,
                                                SECCode = fnboReturnOtherModel.SECCode,
                                                AddendaTypeCode = fnboReturnOtherModel.AddendaTypeCode,
                                                AddendaPaymentRelatedInformation = fnboReturnOtherModel.AddendaPaymentRelatedInformation,
                                                AddendaSequenceNumber = Convert.ToInt32(fnboReturnOtherModel.AddendaSequenceNumber),
                                                AddendaEntryDetailSeqNo = Convert.ToInt32(fnboReturnOtherModel.AddendaEntryDetailSeqNo),
                                                EffectiveEntryDate = fnboReturnOtherModel.EffectiveEntryDate,
                                                Reserved = fnboReturnOtherModel.Reserved,
                                                TotalDebitEntry = fnboReturnOtherModel.TotalDebitEntry,
                                                TotalCreditEntry = fnboReturnOtherModel.TotalCreditEntry,
                                                BankName = fnboReturnOtherModel.BankName,
                                                HeaderRouteNumber = fnboReturnOtherModel.HeaderRouteNumber,
                                                CreatedOn = DateTime.UtcNow,
                                                IsActive = true
                                            });
                                        }
                                        _context.Commit();
                                    }
                                }

                                res.Success = true;
                            }
                        }
                        await eventDispatcher.Dispatch(achNachaReturnFileEvent);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"unProcessedFileDetail in ParseACHReturnFile at: {DateTimeOffset.Now}");
            }

            _logger.TraceExitMethod("File Processed successfully", res);
            return res;
        }
    }
}