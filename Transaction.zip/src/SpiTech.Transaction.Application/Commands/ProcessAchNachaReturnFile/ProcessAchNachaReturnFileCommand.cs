﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.ProcessAchNachaReturnFile
{
    public class ProcessAchNachaReturnFileCommand : IRequest<ResponseModel>
    {
    }
}
