﻿using MediatR;

namespace SpiTech.Transaction.Application.Commands.CreateTransaction
{
    public class CreateTransactionCommand : IRequest<long>
    {
        public Domain.Entities.Transaction Transaction { get; set; }
    }
}
