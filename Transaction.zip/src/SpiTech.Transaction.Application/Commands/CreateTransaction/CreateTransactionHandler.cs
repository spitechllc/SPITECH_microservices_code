﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.CreateTransaction
{
    public class CreateTransactionHandler : IRequestHandler<CreateTransactionCommand, long>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateTransactionHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public CreateTransactionHandler(IUnitOfWork context,
                                             ILogger<CreateTransactionHandler> logger,
                                             IMapper mapper,
                                             IEventDispatcher eventDispatcher, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<long> Handle(CreateTransactionCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            command.Transaction.IsActive = true;
            command.Transaction.CreatedOn = DateTime.UtcNow;
            long transactionid = 0;

            try
            {
                transactionid = await _context.Transactions.Insert(command.Transaction);
                _context.Commit();
            }
            catch (Exception)
            {
                _context.Rollback();
                await DispatchActivityLogEvent(command.Transaction.UserId, (int)ActivityType.CreateTransaction, "Transaction Failed.", true,null);
                throw;
            }

            if (transactionid > 0)
            {
                await eventDispatcher.Dispatch(new TransactionEvent
                {
                    Transaction = _mapper.Map<EventBus.DomainEvents.Models.Mppa.Transaction>(command.Transaction)
                });

                await DispatchActivityLogEvent(command.Transaction.UserId, (int)ActivityType.CreateTransaction, "New Transaction Done.", false, null);
            }

            _logger.TraceExitMethod(nameof(Handle), transactionid);
            return transactionid;
        }

        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress(),
                IsError = isError,
                ErrorMessage = errorMessage

            });
        }
    }
}
