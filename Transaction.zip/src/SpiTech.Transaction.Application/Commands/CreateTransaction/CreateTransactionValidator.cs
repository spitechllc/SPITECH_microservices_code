﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.CreateTransaction
{
    public class CreateTransactionValidator : AbstractValidator<CreateTransactionCommand>
    {
        public CreateTransactionValidator()
        {
            RuleFor(x => x.Transaction.UserId).GreaterThan(0).WithMessage("Userid must be greater than 0");
            RuleFor(x => x.Transaction.UMTI).NotNull().WithMessage("UMTI is required");
        }
    }
}
