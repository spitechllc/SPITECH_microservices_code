﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.CreatePaymentInfo
{
    public class CreatePaymentInfoValidator : AbstractValidator<CreatePaymentInfoCommand>
    {
        public CreatePaymentInfoValidator()
        {
            RuleFor(x => x.PaymentInfo.TransactionId).GreaterThan(0).WithMessage("TransactionId is required");
        }
    }
}
