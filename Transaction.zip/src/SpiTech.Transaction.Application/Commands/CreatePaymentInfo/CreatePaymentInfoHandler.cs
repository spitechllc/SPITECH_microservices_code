﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.CreatePaymentInfo
{
    public class CreatePaymentInfoHandler : IRequestHandler<CreatePaymentInfoCommand, int>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreatePaymentInfoHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        public CreatePaymentInfoHandler(IUnitOfWork context,
                                             ILogger<CreatePaymentInfoHandler> logger,
                                             IMapper mapper,
        IEventDispatcher eventDispatcher,
        IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        /// <summary>
        /// Create payment PaymentInfo
        /// </summary>
        /// <param name="command"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<int> Handle(CreatePaymentInfoCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            command.PaymentInfo.CreatedOn = DateTime.UtcNow;
            command.PaymentInfo.IsActive = true;
            int paymentid = 0;

            await _context.Execute(async () =>
            {
                paymentid = await _context.PaymentInfos.Add(command.PaymentInfo);
            });

            _logger.TraceExitMethod(nameof(Handle), paymentid);
            await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication()?.UserId??0, (int)ActivityType.CreatePaymentInfo, "Payment Info Created.", false, null);
            return paymentid;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress(),
                IsError = isError,
                ErrorMessage = errorMessage

            });
        }
        
    }
}
