﻿using MediatR;
using SpiTech.Transaction.Domain.Entities;

namespace SpiTech.Transaction.Application.Commands.CreatePaymentInfo
{
    public class CreatePaymentInfoCommand : IRequest<int>
    {
        public PaymentInfo PaymentInfo { get; set; }
    }
}
