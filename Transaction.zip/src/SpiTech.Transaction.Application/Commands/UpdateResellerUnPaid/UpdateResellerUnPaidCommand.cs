﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.UpdateResellerUnPaid
{
    public class UpdateResellerUnPaidCommand : IRequest<ResponseModel>
    {
        public int ResellerBillingId { get; set; }
        public string Reason { get; set; }
    }
}
