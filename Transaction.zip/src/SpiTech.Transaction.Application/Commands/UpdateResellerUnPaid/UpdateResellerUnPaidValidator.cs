﻿using FluentValidation;
using System.Linq;

namespace SpiTech.Transaction.Application.Commands.UpdateResellerUnPaid
{
    public class UpdateResellerUnPaidValidator : AbstractValidator<UpdateResellerUnPaidCommand>
    {
        public UpdateResellerUnPaidValidator()
        {
            RuleFor(x => x.ResellerBillingId).Cascade(CascadeMode.Stop)
                                                .GreaterThan(0)
                                                .WithMessage("ResellerBillingId should be valid");
            RuleFor(x => x.Reason).Cascade(CascadeMode.Stop)
                                                .NotNull()
                                                .NotEmpty()
                                                .MaximumLength(500)
                                                .WithMessage("Reason should not be empty");
        }
    }
}
