﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.ProcessStoreEodSettlement
{
    public class ProcessStoreEodSettlementQuery : IRequest<ResponseModel>
    {
        public int SettlementRequestId { get;set; }
    }
}
