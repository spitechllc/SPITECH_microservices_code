﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.GenerateSaleAgentBilling
{
    public class GenerateSaleAgentBillingHandler : IRequestHandler<GenerateSaleAgentBillingCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GenerateSaleAgentBillingHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IStoreServiceClient storeServiceClient;

        public GenerateSaleAgentBillingHandler(IUnitOfWork context,
                                            ILogger<GenerateSaleAgentBillingHandler> logger,
                                            IMapper mapper,
                                            IEventDispatcher eventDispatcher,
                                            IUserAuthenticationProvider userAuthenticationProvider,
                                            IStoreServiceClient storeServiceClient)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
            this.storeServiceClient = storeServiceClient;
        }

        public async Task<ResponseModel> Handle(GenerateSaleAgentBillingCommand request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            int generatedBy = userAuthenticationProvider.GetUserAuthentication()?.UserId??0;

            ResponseModel result = new() { Success = false };

            var nonBillTransactions = await _context.Transactions.GetNonBillSaleAgentTransactions(request.Month, request.Year);

            var saleAgentBillings = Enumerable.Empty<object>()
            .Select(r => new { SaleAgentBilling = new SaleAgentBilling(), TransactionIds = new long[] { } })
            .ToList();

            if (nonBillTransactions == null || !nonBillTransactions.Any())
            {
                result.Message = "No Transaction found in this billing cycle";
                return result;
            }

            string groupBillingIdentifier = "BLS" + DateTime.Now.Ticks.ToString();

            List<int> nonBillStoreIds = nonBillTransactions.Select(x => x.StoreId).Distinct().ToList();

            var storeInfos = await storeServiceClient.GetStoreInfosAsync(nonBillStoreIds, cancellationToken);

            var finalProcessingStores = storeInfos.Where(t => t.IsActive && (t.SaleAgentId ?? 0) > 0 && (t.IsSaleAgentActive ?? false) && !t.IsTestStore).ToList();

            var finalProcessingStoreIds = finalProcessingStores.Select(t => t.StoreId).Distinct().ToList();

            List<SaleAgentFee> saleAgentFees = await _context.SaleAgentFees.GetByStoreIds(finalProcessingStoreIds);

            SaleAgentFee defaultSaleAgentFee = await _context.SaleAgentFees.GetDefaultSaleAgentFees();

            if (defaultSaleAgentFee == null)
            {
                result.Message = $"Default SaleAgentFee has not configured fees in system. Please configure";
                return result;
            }

            foreach (var storeInfo in finalProcessingStores)
            {
                var saleAgentFee = saleAgentFees.OrderByDescending(t => t.SaleAgentFeeId).FirstOrDefault(t => t.StoreId == storeInfo.StoreId && t.SaleAgentId == (storeInfo.SaleAgentId ?? 0));

                if (saleAgentFee == null)
                {
                    saleAgentFee = defaultSaleAgentFee;
                }

                var transactions = nonBillTransactions.Where(t => t.StoreId == storeInfo.StoreId).ToList();

                int totalTransactionCount = transactions.Count();
                var totalTransactionAmount = transactions.Sum(t => t.FinalAmount);

                if (saleAgentFee != null)
                {
                    var saleAgentTransactionPercentageFee = totalTransactionAmount * saleAgentFee.TransactionPercentageFee / 100;

                    var saleAgentBilling = new SaleAgentBilling
                    {
                        StoreId = storeInfo.StoreId,
                        StoreName = storeInfo.StoreName,
                        SiteId = storeInfo.SiteId,
                        SaleAgentId = storeInfo.SaleAgentId.Value,
                        InvoiceNumber = "INV" + DateTime.Now.Ticks.ToString(),
                        Month = request.Month,
                        Year = request.Year,
                        TransactionCount = totalTransactionCount,
                        TransactionAmount = totalTransactionAmount,
                        DefineTransactionPercentageFee = saleAgentFee.TransactionPercentageFee,
                        DefineMonthlySaasFee = saleAgentFee.MonthlySaasFee,
                        TransactionPercentageFee = saleAgentTransactionPercentageFee,
                        TotalFee = saleAgentTransactionPercentageFee + saleAgentFee.MonthlySaasFee,
                        NeedReview = false,
                        IsPaid = false,
                        InvoiceFileName = "",
                        InvoiceFilePath = "",
                        ProcessStatus = "",
                        IsActive = true,
                        CreatedBy = generatedBy,
                        CreatedOn = DateTime.UtcNow,
                    };

                    saleAgentBillings.Add(new { SaleAgentBilling = saleAgentBilling, TransactionIds = transactions.Select(t => t.TransactionId).ToArray() });
                }
            }

            try
            {
                foreach (var saleAgentBilling in saleAgentBillings)
                {
                    var saleAgentBillingId = await _context.SaleAgentBillings.Add(saleAgentBilling.SaleAgentBilling);
                    await _context.SaleAgentBillings.UpdateInvoiceNumber(saleAgentBillingId, $"INV2{saleAgentBillingId.ToString("000000000")}");

                    await _context.Transactions.UpdateSaleAgentBilling(saleAgentBillingId, saleAgentBilling.TransactionIds, generatedBy);
                }

                _context.Commit();
                result.Success = true;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, ex.Message);
                result.Success = false;
                _context.Rollback();
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
