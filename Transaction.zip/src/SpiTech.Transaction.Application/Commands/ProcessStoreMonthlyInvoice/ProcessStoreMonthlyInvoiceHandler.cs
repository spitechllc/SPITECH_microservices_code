﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Service.Clients.Finance;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.Services;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ResponseModel = SpiTech.ApplicationCore.Domain.Models.ResponseModel;

namespace SpiTech.Transaction.Application.Commands.ProcessStoreMonthlyInvoice
{
    public class ProcessStoreMonthlyInvoiceHandler : IRequestHandler<ProcessStoreMonthlyInvoiceQuery, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<ProcessStoreMonthlyInvoiceHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IHtmlPdfConverterService converterService;
        private readonly IStorageService storageService;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IFinanceServiceClient _financeapiclient;
        private readonly IStoreServiceClient storeServiceClient;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public ProcessStoreMonthlyInvoiceHandler(IUnitOfWork context,
                                                 ILogger<ProcessStoreMonthlyInvoiceHandler> logger,
                                                 IMapper mapper, IStorageServiceFactory storageServiceFactory,
                                                 IHtmlPdfConverterService converterService,
                                                 IEventDispatcher eventDispatcher,
                                                 IFinanceServiceClient financeapiclient,
                                                 IStoreServiceClient storeServiceClient,
                                                 IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.converterService = converterService;
            this.storageService = storageServiceFactory.Get(ContainerType.MonthlyInvoicePdf);
            _eventDispatcher = eventDispatcher;
            _financeapiclient = financeapiclient;
            this.storeServiceClient = storeServiceClient;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        /// <summary>
        /// Process Store Monthly Invoice and Save And DispatchEmailEvent and allso perform 
        /// DispatchActivityLogEvent
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ResponseModel> Handle(ProcessStoreMonthlyInvoiceQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            ResponseModel res = new ResponseModel() { Success = false };

            try
            {
                List<StoreBillingModel> result = await _context.StoreBillings.GetUnprocessedMontlyInvoiceBatch();

                if (result != null && result.Count > 0)
                {
                    foreach (StoreBillingModel storeBilling in result)
                    {
                        var storeBillingInvoiceModel = new StoreBillingInvoiceModel
                        {
                            StoreBilling = storeBilling
                        };

                        Service.Clients.Stores.StoreInfoModel store = await storeServiceClient.GetStoreInfoAsync(storeBilling.StoreId, "");

                        Service.Clients.Stores.AddressModel address = store.Addresses.FirstOrDefault();

                        if (address != null)
                        {
                            storeBillingInvoiceModel.StoreBilling.StoreAddress = new EventBus.DomainEvents.Models.Address
                            {
                                AddressLine1 = address.AddressLine1,
                                AddressLine2 = address.AddressLine2,
                                City = address.City,
                                Country = address.Country,
                                State = address.State,
                                ZipCode = address.ZipCode,
                            };
                        }

                        DateTime from = DateTime.SpecifyKind(new DateTime(storeBilling.Year, storeBilling.Month, 1), DateTimeKind.Utc);
                        DateTime to = from.AddMonths(1).AddTicks(-1);

                        GetCashRewardDetailsByFilterQuery query = new()
                        {
                            StoreIds = new List<int>() { storeBilling.StoreId },
                            StartDate = from,
                            EndDate = to
                        };

                        var cashReward = (await _financeapiclient.GetCashRewardDetailsByStoreIdAsync(query)).ToList();

                        if (cashReward != null)
                        {
                            storeBillingInvoiceModel.TotalCashBackEarned = (decimal)cashReward.Where(s => s.StoreId == storeBilling.StoreId).Sum(t => t.TotalEarned);
                        }

                        byte[] fileBytes = await this.converterService.CreatePdfFromView("StoreMonthlyInvoice", storeBillingInvoiceModel);

                        await SaveAndDispatchEmailEvent(storeBilling, fileBytes);
                    }

                    res.Success = true;
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }

            _logger.TraceExitMethod(nameof(Handle), res);
            return res;
        }

        private async Task SaveAndDispatchEmailEvent(StoreBillingModel storeBillingModel, byte[] fileBytes)
        {
            string base64String = Convert.ToBase64String(fileBytes);
            storeBillingModel.InvoiceFileName = storeBillingModel.StoreBillingId + "_storemonthlyinvoice" + "_" + UniqueIdGenerator.Generate() + ".pdf";
            storeBillingModel.InvoiceFilePath = await SaveFile(base64String, storeBillingModel.InvoiceFileName, "application/pdf");

            if (!string.IsNullOrEmpty(storeBillingModel.InvoiceFilePath))
            {
                await _context.StoreBillings.UpdateInvoicePdfFilePath(storeBillingModel.StoreBillingId, storeBillingModel.InvoiceFileName, storeBillingModel.InvoiceFilePath);

                if (storeBillingModel.TotalFee > 0 && storeBillingModel.ProcessStatus != DomainConstant.ProcessStatus.Completed)
                {
                    await _eventDispatcher.Dispatch(new StoreMonthlyBillingInvoiceEvent
                    {
                        StoreBilling = storeBillingModel
                    });

                    await _context.StoreBillings.UpdateProcessStatus(storeBillingModel.StoreBillingId, DomainConstant.ProcessStatus.Completed);
                }

                _context.Commit();
            }
        }

        private async Task<string> SaveFile(string base64file, string filename, string contenttype)
        {
            await storageService.UploadBlobBase64(base64file, filename, contenttype);
            Blob res = await storageService.GetFile(filename);
            return res != null ? res.StorageUri : string.Empty;
        }
    }
}
