﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.GenerateResellerBilling
{
    public class GenerateResellerBillingValidator : AbstractValidator<GenerateResellerBillingCommand>
    {
        public GenerateResellerBillingValidator()
        {
            RuleFor(x => x).Must(x => x.Month >= 1 && x.Month <= 12).WithMessage("Month is invalid");
            RuleFor(x => x.Year).GreaterThan(2021).WithMessage("Year is invalid");
        }
    }
}
