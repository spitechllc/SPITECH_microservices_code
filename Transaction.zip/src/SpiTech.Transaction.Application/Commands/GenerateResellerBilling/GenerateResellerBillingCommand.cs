﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.GenerateResellerBilling
{
    public class GenerateResellerBillingCommand : IRequest<ResponseModel>
    {
        public int Month { get; set; }
        public int Year { get; set; }
    }
}
