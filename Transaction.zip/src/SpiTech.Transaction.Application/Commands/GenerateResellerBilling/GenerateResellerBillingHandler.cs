﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.GenerateResellerBilling
{
    public class GenerateResellerBillingHandler : IRequestHandler<GenerateResellerBillingCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GenerateResellerBillingHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IStoreServiceClient storeServiceClient;

        public GenerateResellerBillingHandler(IUnitOfWork context,
                                            ILogger<GenerateResellerBillingHandler> logger,
                                            IMapper mapper,
                                            IEventDispatcher eventDispatcher,
                                            IUserAuthenticationProvider userAuthenticationProvider,
                                            IStoreServiceClient storeServiceClient)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
            this.storeServiceClient = storeServiceClient;
        }

        public async Task<ResponseModel> Handle(GenerateResellerBillingCommand request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            int generatedBy = userAuthenticationProvider.GetUserAuthentication()?.UserId??0;

            ResponseModel result = new() { Success = false };

            var nonBillTransactions = await _context.Transactions.GetNonBillResellerTransactions(request.Month, request.Year);

            var resellerBillings = Enumerable.Empty<object>()
            .Select(r => new { ResellerBilling = new ResellerBilling(), TransactionIds = new long[] { } })
            .ToList();

            if (nonBillTransactions == null || !nonBillTransactions.Any())
            {
                result.Message = "No Transaction found in this billing cycle";
                return result;
            }

            List<int> nonBillStoreIds = nonBillTransactions.Select(x => x.StoreId).Distinct().ToList();

            if (nonBillStoreIds == null || !nonBillStoreIds.Any())
            {
                result.Message = "No Store found in this billing cycle";
                return result;
            }

            var storeInfos = await storeServiceClient.GetStoreInfosAsync(nonBillStoreIds, cancellationToken);

            var finalProcessingStores = storeInfos.Where(t => t.IsActive && (t.ResellerId ?? 0) > 0 && (t.IsResellerActive ?? false) && !t.IsTestStore).ToList();

            if (finalProcessingStores == null || !finalProcessingStores.Any())
            {
                result.Message = "No Active Reseller found in this billing cycle";
                return result;
            }

            var finalProcessingResellerIds = finalProcessingStores.Select(t => t.ResellerId.Value).Distinct().ToArray();
            var groupProcessingResellers = finalProcessingStores.GroupBy(t => t.ResellerId.Value);

            List<ResellerFee> resellerFees = await _context.ResellerFees.GetByResellerIds(finalProcessingResellerIds);

            if (resellerFees == null || !resellerFees.Any())
            {
                result.Message = $"Fee has not configured for Resellers({string.Join(",", finalProcessingResellerIds)}) in system. Please configure";
                return result;
            }

            foreach (var groupProcessingReseller in groupProcessingResellers)
            {
                var selectedResellerFees = resellerFees.Where(t => t.ResellerId == groupProcessingReseller.Key && t.IsActive);

                if (resellerFees == null || !resellerFees.Any())
                {
                    result.Message = $"Fee for resellerId({groupProcessingReseller.Key}) has not configured in system. Please configure";
                    return result;
                }

                var transactions = nonBillTransactions.Where(t => groupProcessingReseller.Select(t => t.StoreId).Contains(t.StoreId)).ToList();

                var resellerName = groupProcessingReseller.FirstOrDefault().ResellerName;
                int storeCount = groupProcessingReseller.Select(t => t.StoreId).Distinct().Count();
                int totalTransactionCount = transactions.Count();
                var totalTransactionAmount = transactions.Sum(t => t.FinalAmount);
                var totalCardTransactionAmount = transactions.Where(t => t.PaymentMethodId == 1).Sum(t => t.CardAmount);
                var totalACHTransactionAmount = transactions.Where(t => t.PaymentMethodId == 2).Sum(t => t.CardAmount);
                var totalCashRewardTransactionAmount = transactions.Sum(t => t.WalletAmount);

                var resellerFee = selectedResellerFees.FirstOrDefault(t => storeCount >= t.MinStoreRange && storeCount <= t.MaxStoreRange);

                if (resellerFee == null)
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("ResellerFee", $"Reseller Fee is not found for ResellerId-{groupProcessingReseller.Key} and transaction range of {totalTransactionCount} "));
                }

                if (resellerFee != null)
                {
                    var cashRewardTransactionFee = totalCashRewardTransactionAmount * resellerFee.CashRewardTransactionFee / 100;
                    var cardTransactionFee = totalCardTransactionAmount * resellerFee.CardTransactionFee / 100;
                    var achTransactionFee = totalACHTransactionAmount * resellerFee.ACHTransactionFee / 100;
                    var achProcessingFee = totalACHTransactionAmount * resellerFee.ACHProcessingFee / 100;

                    var resellerBilling = new ResellerBilling
                    {
                        ResellerId = groupProcessingReseller.Key,
                        ResellerName = resellerName ?? "",
                        InvoiceNumber = "INV" + DateTime.Now.Ticks.ToString(),
                        Month = request.Month,
                        Year = request.Year,
                        StoreCount = storeCount,
                        TransactionCount = totalTransactionCount,
                        TransactionAmount = totalTransactionAmount,
                        ACHTransactionAmount = totalACHTransactionAmount,
                        CardTransactionAmount = totalCardTransactionAmount,
                        CashRewardTransactionAmount = totalCashRewardTransactionAmount,
                        DefineMinStoreRange = resellerFee.MinStoreRange,
                        DefineMaxStoreRange = resellerFee.MaxStoreRange,
                        DefineACHTransactionFee = resellerFee.ACHTransactionFee,
                        DefineCardTransactionFee = resellerFee.CardTransactionFee,
                        DefineCashRewardTransactionFee = resellerFee.CashRewardTransactionFee,
                        DefineACHProcessingFee = resellerFee.ACHProcessingFee,
                        DefineMonthlySaasFee = resellerFee.MonthlySaasFee,
                        DefineCoreProcessingName = resellerFee.CoreProcessingName,
                        ACHTransactionFee = achTransactionFee,
                        CardTransactionFee = cardTransactionFee,
                        CashRewardTransactionFee = cashRewardTransactionFee,
                        ACHProcessingFee = achProcessingFee,
                        TotalFee = achTransactionFee + cardTransactionFee + cashRewardTransactionFee + achProcessingFee + resellerFee.MonthlySaasFee,
                        NeedReview = false,
                        IsPaid = false,
                        InvoiceFileName = "",
                        InvoiceFilePath = "",
                        ProcessStatus = "",
                        IsActive = true,
                        CreatedBy = generatedBy,
                        CreatedOn = DateTime.UtcNow
                    };

                    resellerBillings.Add(new { ResellerBilling = resellerBilling, TransactionIds = transactions.Select(t => t.TransactionId).ToArray() });
                }
            }

            try
            {
                foreach (var resellerBilling in resellerBillings)
                {
                    var resellerBillingId = await _context.ResellerBillings.Add(resellerBilling.ResellerBilling);
                    await _context.ResellerBillings.UpdateInvoiceNumber(resellerBillingId, $"INV3{resellerBillingId.ToString("000000000")}");

                    await _context.Transactions.UpdateResellerBilling(resellerBillingId, resellerBilling.TransactionIds, generatedBy);
                }

                _context.Commit();
                result.Success = true;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, ex.Message);
                result.Success = false;
                _context.Rollback();
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
