﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.UpdateSaleAgentUnPaid
{
    public class UpdateSaleAgentUnPaidCommand : IRequest<ResponseModel>
    {
        public int SaleAgentBillingId { get; set; }
        public string Reason { get; set; }
    }
}
