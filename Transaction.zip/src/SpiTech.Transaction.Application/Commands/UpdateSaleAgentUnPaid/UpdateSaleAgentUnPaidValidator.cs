﻿using FluentValidation;
using System.Linq;

namespace SpiTech.Transaction.Application.Commands.UpdateSaleAgentUnPaid
{
    public class UpdateSaleAgentUnPaidValidator : AbstractValidator<UpdateSaleAgentUnPaidCommand>
    {
        public UpdateSaleAgentUnPaidValidator()
        {
            RuleFor(x => x.SaleAgentBillingId).Cascade(CascadeMode.Stop)
                                                .GreaterThan(0)
                                                .WithMessage("SaleAgentBillingId should be valid");
            RuleFor(x => x.Reason).Cascade(CascadeMode.Stop)
                                                .NotNull()
                                                .NotEmpty()
                                                .MaximumLength(500)
                                                .WithMessage("Reason should not be empty");
        }
    }
}
