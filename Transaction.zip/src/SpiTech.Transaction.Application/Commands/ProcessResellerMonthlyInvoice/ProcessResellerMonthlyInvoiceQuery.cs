﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.ProcessResellerMonthlyInvoice
{
    public class ProcessResellerMonthlyInvoiceQuery : IRequest<ResponseModel>
    {
    }
}
