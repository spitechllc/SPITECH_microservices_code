﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.Services;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using ResponseModel = SpiTech.ApplicationCore.Domain.Models.ResponseModel;

namespace SpiTech.Transaction.Application.Commands.ProcessResellerMonthlyInvoice
{
    public class ProcessResellerMonthlyInvoiceHandler : IRequestHandler<ProcessResellerMonthlyInvoiceQuery, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<ProcessResellerMonthlyInvoiceHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IHtmlPdfConverterService converterService;
        private readonly IStorageService storageService;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IStoreServiceClient storeapiclient;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public ProcessResellerMonthlyInvoiceHandler(IUnitOfWork context,
                                                 ILogger<ProcessResellerMonthlyInvoiceHandler> logger,
                                                 IMapper mapper,
                                                 IStorageServiceFactory storageServiceFactory,
                                                 IHtmlPdfConverterService converterService,
                                                 IEventDispatcher eventDispatcher,
                                                 IStoreServiceClient storeapiclient,
                                                 IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.converterService = converterService;
            this.storageService = storageServiceFactory.Get(ContainerType.ResellerMonthlyInvoicePdf);
            _eventDispatcher = eventDispatcher;
            this.storeapiclient = storeapiclient;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        /// <summary>
        /// Process Reseller Monthly Invoice
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ResponseModel> Handle(ProcessResellerMonthlyInvoiceQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            var resellerBillings = await _context.ResellerBillings.GetUnprocessedMontlyInvoiceBatch();

            if (resellerBillings == null || !resellerBillings.Any())
            {
                return null;
            }

            ResponseModel res = new ResponseModel() { Success = false };
            try
            {
                var salesAgents = await storeapiclient.ResellersAsync(resellerBillings.Select(t => t.ResellerId).Distinct(), cancellationToken);

                foreach (var resellerBilling in resellerBillings)
                {
                    var salesAgent = salesAgents.FirstOrDefault(t => t.ResellerId == resellerBilling.ResellerId);
                    resellerBilling.ResellerName = salesAgent?.FirstName + " " + salesAgent?.LastName;

                    byte[] fileBytes = await this.converterService.CreatePdfFromView("ResellerMonthlyInvoice", resellerBilling);

                    await SaveAndDispatchEmailEvent(resellerBilling, fileBytes);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
            res.Success = true;
            _logger.TraceExitMethod(nameof(Handle), res);
            return res;
        }

        private async Task SaveAndDispatchEmailEvent(ResellerBillingModel resellerBilling, byte[] fileBytes)
        {
            resellerBilling.InvoiceFileName = resellerBilling.ResellerBillingId + "_saleagentmonthlyinvoice" + "_" + UniqueIdGenerator.Generate() + ".pdf";

            resellerBilling.InvoiceFilePath = await SaveFile(Convert.ToBase64String(fileBytes), resellerBilling.InvoiceFileName, "application/pdf");

            if (!string.IsNullOrEmpty(resellerBilling.InvoiceFilePath))
            {
                await _context.ResellerBillings.UpdateInvoicePdfFilePath(resellerBilling.ResellerBillingId, resellerBilling.InvoiceFileName, resellerBilling.InvoiceFilePath);


                if (resellerBilling.TotalFee > 0 && resellerBilling.ProcessStatus != DomainConstant.ProcessStatus.Completed)
                {
                    await _eventDispatcher.Dispatch(new ResellerMonthlyBillingInvoiceEvent
                    {
                        ResellerBilling = resellerBilling
                    });

                    await _context.ResellerBillings.UpdateProcessStatus(resellerBilling.ResellerBillingId, DomainConstant.ProcessStatus.Completed);
                }

                _context.Commit();
            }
        }

        private async Task<string> SaveFile(string base64file, string filename, string contenttype)
        {
            await storageService.UploadBlobBase64(base64file, filename, contenttype);
            Blob res = await storageService.GetFile(filename);
            return res != null ? res.StorageUri : string.Empty;
        }
    }
}
