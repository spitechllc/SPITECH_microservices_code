﻿using MediatR;
using SpiTech.Transaction.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.CreateLogInfo
{
    public class CreateLogInfoCommand : IRequest<int>
    {
        public string Message { get; set; }
        public string Method { get; set; }
        public string Exception { get; set; }
        public DateTime CreateDate { get; set; }
    }
}
