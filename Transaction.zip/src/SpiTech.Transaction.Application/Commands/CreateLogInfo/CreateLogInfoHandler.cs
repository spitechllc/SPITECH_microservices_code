﻿using AutoMapper;
using MediatR;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Transaction.Application.Commands.CreatePaymentInfo;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Domain.Entities;

namespace SpiTech.Transaction.Application.Commands.CreateLogInfo
{
    public class CreateLogInfoHandler : IRequestHandler<CreateLogInfoCommand, int>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateLogInfoHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        public CreateLogInfoHandler(IUnitOfWork context,
                                             ILogger<CreateLogInfoHandler> logger,
                                             IMapper mapper,
        IEventDispatcher eventDispatcher,
        IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        /// <summary>
        /// Create payment PaymentInfo
        /// </summary>
        /// <param name="command"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<int> Handle(CreateLogInfoCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            int paymentid = 0;
            LogInfo logInfo = new LogInfo();
            logInfo.IsActive = true;
            logInfo.CreatedOn = DateTime.UtcNow;
            logInfo.Message= command.Message;
            logInfo.Method = command.Method;
            logInfo.Exception = command.Exception;

            await _context.Execute(async () =>
            {
                paymentid = await _context.LogInfos.Add(logInfo);
            });

            _logger.TraceExitMethod(nameof(Handle), paymentid);
            return paymentid;
        }
    }
}
