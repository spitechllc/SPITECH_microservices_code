﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.CreateResellerFee
{
    public class CreateResellerFeeHandler : IRequestHandler<CreateResellerFeeCommand, ResponseModel>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateResellerFeeHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        public CreateResellerFeeHandler(IUnitOfWork context,
                                 ILogger<CreateResellerFeeHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper,
        IEventDispatcher eventDispatcher,
        IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<ResponseModel> Handle(CreateResellerFeeCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            ResponseModel responseModel = new();
            Domain.Entities.ResellerFee model = new()
            {
                ResellerId = command.ResellerId,
                MinStoreRange = command.MinStoreRange,
                MaxStoreRange = command.MaxStoreRange,
                ACHTransactionFee = command.ACHTransactionFee,
                CardTransactionFee = command.CardTransactionFee,
                CashRewardTransactionFee = command.CashRewardTransactionFee,
                IsActive = true,
                ACHProcessingFee = command.ACHProcessingFee,
                MonthlySaasFee = command.MonthlySaasFee,
                CoreProcessingName = command.CoreProcessingName,
                CreatedOn = DateTime.UtcNow,
                IsDefault = command.IsDefault
            };

            var dbfees = command.IsDefault ? await _context.ResellerFees.GetDefaultFees(command.CoreProcessingName) : await _context.ResellerFees.GetByResellerId(command.ResellerId ?? 0);


            var fee = dbfees.FirstOrDefault(t => t.MinStoreRange == command.MinStoreRange || t.MaxStoreRange == command.MaxStoreRange);

            if (fee != null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreRange", "Duplicate MinStoreRange/MaxStoreRange"));
            }

            fee = dbfees.FirstOrDefault(t => t.MinStoreRange <= command.MinStoreRange && command.MaxStoreRange <= t.MaxStoreRange);

            if (fee != null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("MinStoreRange", "MinStoreRange already in between other ranges"));
            }

            fee = dbfees.FirstOrDefault(t => t.MaxStoreRange <= command.MaxStoreRange && command.MaxStoreRange <= t.MaxStoreRange);

            if (fee != null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("MaxStoreRange", "MaxStoreRange already in between other ranges"));
            }

            try
            {
                int resellerFeeId = await _context.ResellerFees.Add(model);
                _context.Commit();
                responseModel.Success = true;
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication()?.UserId??0, (int)ActivityType.CreateResellerFee, "ResellerFee Created.", false, null);
            }
            catch (Exception ex)
            {
                responseModel.Success = false;
                _logger.Error(ex, command, model);
                _context.Rollback();
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication()?.UserId??0, (int)ActivityType.CreateResellerFee, "ResellerFee Creation Failed.", true, ex.Message);
            }

            return responseModel;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress(),
                IsError = isError,
                ErrorMessage = errorMessage

            });
        }
    }
}
