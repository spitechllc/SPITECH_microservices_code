﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.CreateStoreSettlementConfig
{
    public class CreateStoreSettlementConfigCommand : IRequest<ResponseModel>
    {
        public int? StoreId { get; set; }
        public bool EnableACH { get; set; }
        public bool EnableCard { get; set; }
        public bool EnableCashReward { get; set; }
        public bool IsDefault { get; set; }
    }
}
