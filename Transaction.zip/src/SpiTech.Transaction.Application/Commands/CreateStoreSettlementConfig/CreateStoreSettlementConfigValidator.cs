﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.CreateStoreSettlementConfig
{
    public class CreateStoreSettlementConfigValidator : AbstractValidator<CreateStoreSettlementConfigCommand>
    {
        public CreateStoreSettlementConfigValidator()
        {
            When(t => t.IsDefault, () => {
                RuleFor(h => h.StoreId).Null().WithMessage("StoreId must be null for default");
            });

            When(t => !t.IsDefault, () => {
                RuleFor(h => h.StoreId).GreaterThan(0).WithMessage("StoreId must be greater than 0");
            });
        }
    }
}
