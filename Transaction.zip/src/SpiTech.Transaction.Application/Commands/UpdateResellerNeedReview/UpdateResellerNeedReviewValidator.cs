﻿using FluentValidation;
using System.Linq;

namespace SpiTech.Transaction.Application.Commands.UpdateResellerNeedReview
{
    public class UpdateResellerNeedReviewValidator : AbstractValidator<UpdateResellerNeedReviewCommand>
    {
        public UpdateResellerNeedReviewValidator()
        {
            RuleFor(x => x.ResellerBillingIds).Cascade(CascadeMode.Stop)
                                                .NotNull()
                                                .NotEmpty()
                                                .Must(NotEqualZero)
                                                .WithMessage("ResellerBillingId should be valid");
        }

        private bool NotEqualZero(int[] resellerBillingIds)
        {
            return resellerBillingIds?.All(i => i > 0) ?? false;
        }
    }
}
