﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.UpdateResellerNeedReview
{
    public class UpdateResellerNeedReviewCommand : IRequest<ResponseModel>
    {
        public int[] ResellerBillingIds { get; set; }
        public bool IsNeedReview { get; set; }
    }
}
