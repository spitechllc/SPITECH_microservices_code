﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.CreateStoreSettlementConfigFromDefault
{
    public class CreateStoreSettlementConfigFromDefaultHandler : IRequestHandler<CreateStoreSettlementConfigFromDefaultCommand, ResponseModel>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateStoreSettlementConfigFromDefaultHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider authenticationProvider;
        public CreateStoreSettlementConfigFromDefaultHandler(IUnitOfWork context,
                                     ILogger<CreateStoreSettlementConfigFromDefaultHandler> logger,
                                     IMediator mediator,
                                     IMapper mapper,
                                    IEventDispatcher eventDispatcher,
                                    IUserAuthenticationProvider authenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
            this.authenticationProvider = authenticationProvider;
        }
        /// <summary>
        /// Add Store Settlement Configs with rollback transaction
        /// </summary>
        /// <param name="command"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ResponseModel> Handle(CreateStoreSettlementConfigFromDefaultCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel responseModel = new();

            var storeSettlementConfig = await _context.StoreSettlementConfigs.GetDefault();

            if (storeSettlementConfig == null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreSettlementConfig", "Default StoreSettlementConfig not found"));
            }

            try
            {
                var storeSettlementConfigEntity = _mapper.Map<StoreSettlementConfig>(storeSettlementConfig);

                storeSettlementConfigEntity.StoreId = command.StoreId;
                storeSettlementConfigEntity.IsDefault = false;
                storeSettlementConfigEntity.IsActive = true;
                storeSettlementConfigEntity.CreatedOn = DateTime.UtcNow;

                int storeBillingFeeId = await _context.StoreSettlementConfigs.Add(storeSettlementConfigEntity);

                _context.Commit();
                responseModel.Success = true;
            }
            catch (Exception ex)
            {
                responseModel.Success = false;
                _logger.Error(ex, command, storeSettlementConfig);
                _context.Rollback();
            }

            return responseModel;
        }
    }
}
