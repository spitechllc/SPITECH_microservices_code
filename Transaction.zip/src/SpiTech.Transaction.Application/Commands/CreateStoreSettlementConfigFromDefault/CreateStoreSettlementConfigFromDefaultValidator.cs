﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.CreateStoreSettlementConfigFromDefault
{
    public class CreateStoreSettlementConfigFromDefaultValidator : AbstractValidator<CreateStoreSettlementConfigFromDefaultCommand>
    {
        public CreateStoreSettlementConfigFromDefaultValidator()
        {
            RuleFor(h => h.StoreId).GreaterThan(0).WithMessage("StoreId must be greater than 0");
        }
    }
}
