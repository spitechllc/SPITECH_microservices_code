﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.CreateStoreSettlementConfigFromDefault
{
    public class CreateStoreSettlementConfigFromDefaultCommand : IRequest<ResponseModel>
    {
        public int StoreId { get; set; }
        public int? TenantId { get; set; }
    }
}
