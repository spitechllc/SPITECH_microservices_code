﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.CreateSaleAgentFee
{
    public class CreateSaleAgentFeeCommand : IRequest<ResponseModel>
    {
        public int? SaleAgentId { get; set; }
        public int? StoreId { get; set; }
        public decimal TransactionPercentageFee { get; set; }
        public decimal MonthlySaasFee { get; set; }
        public bool IsDefault { get; set; }
    }
}
