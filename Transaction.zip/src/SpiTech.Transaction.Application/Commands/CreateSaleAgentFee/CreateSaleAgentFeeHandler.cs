﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.CreateSaleAgentFee
{
    public class CreateSaleAgentFeeHandler : IRequestHandler<CreateSaleAgentFeeCommand, ResponseModel>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateSaleAgentFeeHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        public CreateSaleAgentFeeHandler(IUnitOfWork context,
                                 ILogger<CreateSaleAgentFeeHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper,
        IEventDispatcher eventDispatcher,
        IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<ResponseModel> Handle(CreateSaleAgentFeeCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel responseModel = new();

            Domain.Entities.SaleAgentFee model = new()
            {
                StoreId = command.StoreId,
                SaleAgentId = command.SaleAgentId,
                TransactionPercentageFee = command.TransactionPercentageFee,
                MonthlySaasFee = command.MonthlySaasFee,
                IsActive = true,
                CreatedOn = DateTime.UtcNow,
                IsDefault= command.IsDefault
            };

            if(command.IsDefault)
            {
                var saleAgentFee = await _context.SaleAgentFees.GetDefaultSaleAgentFees();

                if (saleAgentFee != null)
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("SaleAgentId", "Duplicate Default SaleAgentFee"));
                }
            }
            else
            {
                var saleAgentFee = await _context.SaleAgentFees.GetByStoreId(command.StoreId.Value, command.SaleAgentId.Value);

                if (saleAgentFee != null)
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("SaleAgentId", "Duplicate SaleAgentId and StoreId"));
                }
            }

            try
            {
                int SaleAgentFeeId = await _context.SaleAgentFees.Add(model);
                _context.Commit();
                responseModel.Success = true;
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication()?.UserId??0, (int)ActivityType.CreateSaleAgentFee, "SaleAgentFee Created.", false, null);
            }
            catch (Exception ex)
            {
                responseModel.Success = false;
                _logger.Error(ex, command, model);
                _context.Rollback();
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication()?.UserId??0, (int)ActivityType.CreateSaleAgentFee, "SaleAgentFee Creation Failed.", true, ex.Message);
            }

            return responseModel;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress(),
                IsError = isError,
                ErrorMessage = errorMessage

            });
        }
    }
}
