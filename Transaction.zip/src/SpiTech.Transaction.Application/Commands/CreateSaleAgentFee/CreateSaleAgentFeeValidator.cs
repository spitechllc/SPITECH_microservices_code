﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.CreateSaleAgentFee
{
    public class CreateSaleAgentFeeValidator : AbstractValidator<CreateSaleAgentFeeCommand>
    {
        public CreateSaleAgentFeeValidator()
        {
            When(t => t.IsDefault, () => {
                RuleFor(h => h.StoreId).Null().WithMessage("StoreId must be null");
                RuleFor(h => h.SaleAgentId).Null().WithMessage("SaleAgentId must be null");
            }).Otherwise(() =>{
                RuleFor(h => h.StoreId).NotNull().GreaterThan(0).WithMessage("StoreId must be greater than 0");
                RuleFor(h => h.SaleAgentId).NotNull().GreaterThan(0).WithMessage("SaleAgentId must be greater than 0");
            });
            
            RuleFor(h => h.TransactionPercentageFee).GreaterThanOrEqualTo(0);
            RuleFor(h => h.MonthlySaasFee).GreaterThanOrEqualTo(0);
        }
    }
}
