﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.UpdatePaymentInfo
{
    public class UpdatePaymentInfoHandler : IRequestHandler<UpdatePaymentInfoCommand, int>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdatePaymentInfoHandler> _logger;
        private readonly IMapper _mapper;
        public UpdatePaymentInfoHandler(IUnitOfWork context,
                                             ILogger<UpdatePaymentInfoHandler> logger,
                                             IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<int> Handle(UpdatePaymentInfoCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            command.PaymentInfo.IsActive = true;

            int paymentid = 0;

            await _context.Execute(async () =>
            {
                paymentid = await _context.PaymentInfos.Add(command.PaymentInfo);
            });

            _logger.TraceExitMethod(nameof(Handle), paymentid);
            return paymentid;
        }
    }
}
