﻿using MediatR;
using SpiTech.Transaction.Domain.Entities;

namespace SpiTech.Transaction.Application.Commands.UpdatePaymentInfo
{
    public class UpdatePaymentInfoCommand : IRequest<int>
    {
        public PaymentInfo PaymentInfo { get; set; }
    }
}
