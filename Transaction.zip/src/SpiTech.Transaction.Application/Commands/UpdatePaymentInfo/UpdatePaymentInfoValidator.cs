﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.UpdatePaymentInfo
{
    public class UpdatePaymentInfoValidator : AbstractValidator<UpdatePaymentInfoCommand>
    {
        public UpdatePaymentInfoValidator()
        {
            RuleFor(x => x.PaymentInfo.TransactionId).GreaterThan(0).WithMessage("TransactionId is required");
        }
    }
}
