﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain;
using SpiTech.ApplicationCore.Domain.Configs;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using SpiTech.ApplicationCore.Nacha;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.Queries.GetNachaStoreBillingProcessingAccount;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.ProcessPaymentStoreBilling
{
    public class ProcessPaymentStoreBillingHandler : IRequestHandler<ProcessPaymentStoreBillingCommand, ResponseModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<ProcessPaymentStoreBillingHandler> logger;
        private readonly IMediator mediator;
        private readonly INachaFileBuilder nachaFileBuilder;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IStorageService storageService;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IPaymentServiceClient paymentService;
        private readonly SftpConfigs sftpConfigs;

        public ProcessPaymentStoreBillingHandler(IUnitOfWork context,
                                    ILogger<ProcessPaymentStoreBillingHandler> logger,
                                    IMediator mediator,
                                    INachaFileBuilder nachaFileBuilder,
                                    IStorageServiceFactory storageServiceFactory,
                                    IUserAuthenticationProvider userAuthenticationProvider,
                                    IEventDispatcher eventDispatcher,
                                    IPaymentServiceClient paymentService,
                                    SftpConfigs sftpConfigs)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            this.nachaFileBuilder = nachaFileBuilder;
            this.userAuthenticationProvider = userAuthenticationProvider;
            storageService = storageServiceFactory.Get(ContainerType.MonthlyInvoiceNachaFile);
            _eventDispatcher = eventDispatcher;
            this.paymentService = paymentService;
            this.sftpConfigs = sftpConfigs;
        }
        /// <summary>
        /// Process Payment StoreBilling
        /// </summary>
        /// <param name="command"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ResponseModel> Handle(ProcessPaymentStoreBillingCommand command, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), command);
            Domain.Entities.StoreBillingPayment storeBillingPayment = null;

            int uploadUserId = userAuthenticationProvider.GetUserAuthentication()?.UserId ?? 0;
            ResponseModel response = new();
            var nachaConfig = (await context.NachaConfigs.GetAll()).FirstOrDefault();

            if (nachaConfig == null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("NachaConfig", "Unable to get NachaConfigs"));
            }

            NachaProcessingModel nachaProcessingModel = await mediator.Send(new GetNachaStoreBillingProcessingAccountQuery
            {
                Year = command.Year,
                Month = command.Month,
                EffectiveDate = command.EffectiveDate,
            });

            if (nachaProcessingModel == null || nachaProcessingModel.ProcessingEntities == null || !nachaProcessingModel.ProcessingEntities.Any())
            {
                response.Message = "No StoreBilling found for processing";
                return response;
            }

            try
            {
                var accounts = nachaProcessingModel.ProcessingEntities.SelectMany(t => t.Accounts).ToList();

                storeBillingPayment = new Domain.Entities.StoreBillingPayment
                {
                    BillGenerateBy = uploadUserId,
                    BillGenerateDate = DateTime.UtcNow,
                    AccountNo = nachaProcessingModel.Config.AccountNo,
                    Month = command.Month,
                    Year = command.Year,
                    Bank = nachaProcessingModel.Config.BankName,
                    AccountName = nachaProcessingModel.Config.BatchCompanyName,
                    RoutingNo = nachaProcessingModel.Config.RoutingNo,
                    IsChecking = true,
                    IsActive = true,
                    TotalAmount = accounts.Sum(t => t.Amount),
                    NachaFilePath = "",
                    CreatedBy = uploadUserId,
                    CreatedOn = DateTime.UtcNow,
                };

                int storeBillingPaymentId = await context.StoreBillingPayments.Add(storeBillingPayment);

                foreach (var processingEntity in nachaProcessingModel.ProcessingEntities)
                {
                    if (processingEntity.Accounts != null)
                    {
                        foreach (NachaModel nachaModel in processingEntity.Accounts)
                        {
                            await context.StoreBillingPaymentDetails.Add(new Domain.Entities.StoreBillingPaymentDetail
                            {
                                AccountNo = nachaModel.ProcessingAccount.AccountNo,
                                RoutingNo = nachaModel.ProcessingAccount.RoutingNo,
                                Amount = nachaModel.Amount,
                                AccountName = nachaModel.ProcessingAccount.AccountName,
                                IsChecking = nachaModel.ProcessingAccount.AccountType == AccountType.Checking,
                                StoreId = (int)nachaModel.AccountEntityId,
                                StoreBillingPaymentId = storeBillingPaymentId,
                                IdentificationNumber = nachaModel.IdentificationNumber,
                                StoreBillingId = ((StoreBillingModel)processingEntity.Entity).StoreBillingId,
                                IsActive = true,
                                CreatedBy = uploadUserId,
                                CreatedOn = DateTime.UtcNow,
                            });
                        }
                    }
                }

                NachaFileBytesModel nachaProcessFileBytesModel = nachaFileBuilder.GetBytes(nachaProcessingModel.Config, accounts);

                string nachaUploadError = "";
                bool isNachaUploaded = true;

                if (nachaProcessFileBytesModel != null)
                {
                    await storageService.UploadBlob(nachaProcessFileBytesModel.Bytes, nachaProcessFileBytesModel.File, "text/plain");
                    Blob blobProcess = await storageService.GetFile(nachaProcessFileBytesModel.File);

                    await context.StoreBillingPayments.UpdateNachaFilePath(storeBillingPaymentId,
                                                                            blobProcess.StorageUri,
                                                                            nachaProcessFileBytesModel.File,
                                                                            "",
                                                                            "",
                                                                            DomainConstant.SftpConfig.FNBO);

                    try
                    {
                        response.Success = await nachaFileBuilder.UploadFileInSftp(nachaProcessFileBytesModel, nachaConfig.IsProdEnabled, this.sftpConfigs.Get(DomainConstant.SftpConfig.FNBO));
                    }
                    catch (Exception ex)
                    {
                        nachaUploadError = ex.Message;
                        logger.Error(ex, command, nachaProcessFileBytesModel, nachaConfig);
                        response.Success = false;
                        isNachaUploaded = false;
                    }
                }
                else
                {
                    response.Success = true;
                }

                await context.StoreBillings.UpdatePaid(nachaProcessingModel.ProcessingEntities.Where(t => t.Entity != null)
                    .Select(t => ((StoreBillingModel)t.Entity).StoreBillingId).Distinct().ToArray(), uploadUserId, response.Success);
                await context.StoreBillingPayments.UpdateNachaFileUploadStatus(storeBillingPaymentId, isNachaUploaded, nachaUploadError, false, "");

                context.Commit();
            }
            catch (Exception ex)
            {
                logger.Error(ex, command);
                context.Rollback();
                response.Success = false;
            }

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
