﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.ProcessPaymentStoreBilling
{
    public class ProcessPaymentStoreBillingValidator : AbstractValidator<ProcessPaymentStoreBillingCommand>
    {
        public ProcessPaymentStoreBillingValidator()
        {
            RuleFor(x => x).Must(x => x.Month >= 1 && x.Month <= 12).WithMessage("Month is invalid");
            RuleFor(x => x.Year).GreaterThan(2000).WithMessage("Year is invalid");
        }
    }
}
