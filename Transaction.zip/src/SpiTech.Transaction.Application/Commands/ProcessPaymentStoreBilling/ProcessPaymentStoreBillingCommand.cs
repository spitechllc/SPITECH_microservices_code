﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using System;

namespace SpiTech.Transaction.Application.Commands.ProcessPaymentStoreBilling
{
    public class ProcessPaymentStoreBillingCommand : IRequest<ResponseModel>
    {
        public int Month { get; set; }
        public int Year { get; set; }
        public DateTime? EffectiveDate { get; set; }
    }
}
