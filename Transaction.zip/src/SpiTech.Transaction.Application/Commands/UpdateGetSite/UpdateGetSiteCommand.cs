﻿using MediatR;
using SpiTech.Transaction.Domain.Entities;

namespace SpiTech.Transaction.Application.Commands.UpdateGetSite
{
    public class UpdateGetSiteCommand : IRequest<Site>
    {
        public string StoreName { get; set; }
        public string SiteId { get; set; }
        public int StoreId { get; set; }
        public bool Update { get; set; }
    }
}
