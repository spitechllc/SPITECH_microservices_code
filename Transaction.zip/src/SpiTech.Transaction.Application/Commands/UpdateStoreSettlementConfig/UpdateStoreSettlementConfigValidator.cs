﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.UpdateStoreSettlementConfig
{
    public class UpdateStoreSettlementConfigValidator : AbstractValidator<UpdateStoreSettlementConfigCommand>
    {
        public UpdateStoreSettlementConfigValidator()
        {
            RuleFor(h => h.StoreSettlementConfigId).GreaterThan(0).WithMessage("StoreSettlementConfigId must be greater than 0");
        }
    }
}
