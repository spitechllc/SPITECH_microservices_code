﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.UpdateStoreSettlementConfig
{
    public class UpdateStoreSettlementConfigCommand : IRequest<ResponseModel>
    {
        public int StoreSettlementConfigId { get; set; }
        public bool EnableACH { get; set; }
        public bool EnableCard { get; set; }
        public bool EnableCashReward { get; set; }
        public bool IsActive { get; set; }
    }
}