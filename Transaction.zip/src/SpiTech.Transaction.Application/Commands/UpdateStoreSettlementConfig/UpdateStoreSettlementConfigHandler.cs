﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.UpdateStoreSettlementConfig
{
    public class UpdateStoreSettlementConfigHandler : IRequestHandler<UpdateStoreSettlementConfigCommand, ResponseModel>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateStoreSettlementConfigHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider authenticationProvider;
        public UpdateStoreSettlementConfigHandler(IUnitOfWork context,
                                 ILogger<UpdateStoreSettlementConfigHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper, IEventDispatcher eventDispatcher,
                                 IUserAuthenticationProvider authenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
            this.authenticationProvider = authenticationProvider;
        }
        public async Task<ResponseModel> Handle(UpdateStoreSettlementConfigCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            ResponseModel responseModel = new();

            var storeSettlementConfig = await _context.StoreSettlementConfigs.Get(command.StoreSettlementConfigId);

            if (storeSettlementConfig == null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreSettlementConfigId", "Invalid StoreSettlementConfigId"));
            }

            try
            {
                storeSettlementConfig.EnableACH = command.EnableACH;
                storeSettlementConfig.EnableCard = command.EnableCard;
                storeSettlementConfig.EnableCashReward = command.EnableCashReward;
                responseModel.Success = await _context.StoreSettlementConfigs.Update(storeSettlementConfig);
                _context.Commit();
            }
            catch (Exception ex)
            {
                _logger.Error(ex, command, storeSettlementConfig);
                _context.Rollback();
            }

            _logger.TraceExitMethod(nameof(Handle), responseModel);

            return await Task.FromResult(responseModel);
        }
    }
}
