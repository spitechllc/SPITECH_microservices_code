﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.GenerateStoreBilling
{
    public class GenerateStoreBillingCommand : IRequest<ResponseModel>
    {
        public int Month { get; set; }
        public int Year { get; set; }
    }
}
