﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using SpiTech.Transaction.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.GenerateStoreBilling
{
    public class GenerateStoreBillingHandler : IRequestHandler<GenerateStoreBillingCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GenerateStoreBillingHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IStoreServiceClient storeServiceClient;
        private List<long> usedTransactionIds = new List<long>();

        public GenerateStoreBillingHandler(IUnitOfWork context,
                                            ILogger<GenerateStoreBillingHandler> logger,
                                            IMapper mapper,
                                            IEventDispatcher eventDispatcher,
                                            IUserAuthenticationProvider userAuthenticationProvider,
                                            IStoreServiceClient storeServiceClient)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
            this.storeServiceClient = storeServiceClient;
        }

        public async Task<ResponseModel> Handle(GenerateStoreBillingCommand request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            int generatedBy = userAuthenticationProvider.GetUserAuthentication()?.UserId ?? 0;

            ResponseModel result = new() { Success = false };

            List<NonBillStoreTransactionModel> nonBillTransactions = await _context.Transactions.GetNonBillStoreTransactions(request.Month, request.Year);

            var storeBillings = Enumerable.Empty<object>()
             .Select(r => new { StoreBilling = new StoreBilling(), TransactionIds = new long[] { } })
             .ToList();

            if (nonBillTransactions == null || !nonBillTransactions.Any())
            {
                //throw new ValidationException(new FluentValidation.Results.ValidationFailure("Transactions", "No Transaction Found"));
                result.Message = "No Transaction found in this billing cycle";
                return result;
            }

            string groupBillingIdentifier = "BLG" + DateTime.Now.Ticks.ToString();
            List<int> nonBillStoreIds = nonBillTransactions.Select(x => x.StoreId).Distinct().ToList();

            var storeInfos = await storeServiceClient.GetStoreInfosAsync(nonBillStoreIds, cancellationToken);

            List<StoreBillingFeeModel> storeDefaultBillingFees = await _context.StoreBillingFees.GetDefaultFees(true);

            if (storeDefaultBillingFees == null || !storeDefaultBillingFees.Any())
            {
                result.Message = $"Store Default Billing Fees is not found. Please configure";
                return result;
            }

            List<StoreBillingFeeModel> storeBillingFees = await _context.StoreBillingFees.GetByStoreIds(nonBillStoreIds);

            foreach (var store in storeInfos)
            {
                if (!store.IsActive || store.IsTestStore)
                {
                    continue;
                }

                string billingNumber = "INV" + DateTime.Now.Ticks.ToString();
                List<StoreBillingFeeModel> nonBillStoreBillingFees = storeBillingFees.Where(t => t.StoreId == store.StoreId).ToList();
                List<NonBillStoreTransactionModel> transactions = nonBillTransactions.Where(t => t.StoreId == store.StoreId).ToList();

                int totalTransactionCount = transactions.Count();

                StoreBillingDetail cardStoreBillingDetail = GetStoreBillingDetail(store, EnumPaymentMethod.CreditCard, transactions, nonBillStoreBillingFees, storeDefaultBillingFees, generatedBy);

                StoreBillingDetail achStoreBillingDetail = GetStoreBillingDetail(store, EnumPaymentMethod.ACH, transactions, nonBillStoreBillingFees, storeDefaultBillingFees, generatedBy);

                StoreBillingDetail cashrewardStoreBillingDetail = GetStoreBillingDetail(store, EnumPaymentMethod.CashReward, transactions, nonBillStoreBillingFees, storeDefaultBillingFees, generatedBy);

                decimal transactionAmount = transactions.Sum(t => t.FinalAmount);

                var nonBillStoreBillingFee = nonBillStoreBillingFees.FirstOrDefault(t => t.MonthlySaasFee > 0);
                if (nonBillStoreBillingFee == null)
                {
                    nonBillStoreBillingFee = storeDefaultBillingFees.FirstOrDefault(t => t.MonthlySaasFee > 0);
                }

                //if (nonBillStoreBillingFee == null)
                //{
                //    throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreBillingFee", $"MonthlySaasFee is not found for StoreId-{store.StoreId}-{store.StoreName}"));
                //}

                decimal monthlySaasFee = nonBillStoreBillingFee?.MonthlySaasFee ?? 0;
                decimal transactionFee = (cardStoreBillingDetail?.TransactionFee ?? 0) + (achStoreBillingDetail?.TransactionFee ?? 0) + (cashrewardStoreBillingDetail?.TransactionFee ?? 0);
                decimal transactionPercentageFee = (cardStoreBillingDetail?.TransactionPercentageFee ?? 0) + (achStoreBillingDetail?.TransactionPercentageFee ?? 0) + (cashrewardStoreBillingDetail?.TransactionPercentageFee ?? 0);

                StoreBilling storeBilling = new()
                {
                    StoreId = store.StoreId,
                    BillGenerateBy = generatedBy,
                    BillGenerateDate = DateTime.UtcNow,
                    CreatedBy = generatedBy,
                    BillingNumber = billingNumber,
                    CreatedOn = DateTime.UtcNow,
                    GroupBillingIdentifier = groupBillingIdentifier,
                    IsActive = true,
                    Month = request.Month,
                    Year = request.Year,
                    MonthlySaasFee = monthlySaasFee,
                    NeedReview = false,
                    SiteId = transactions.FirstOrDefault()?.SiteId,
                    StoreName = transactions.FirstOrDefault()?.StoreName,
                    TransactionAmount = transactionAmount,
                    TransactionCount = totalTransactionCount,
                    TransactionFee = transactionFee,
                    TransactionPercentageFee = transactionPercentageFee,
                    TotalFee = monthlySaasFee + transactionFee + transactionPercentageFee,
                    IsPaid = false
                };

                if (cardStoreBillingDetail != null)
                {
                    storeBilling.StoreBillingDetails.Add(cardStoreBillingDetail);
                }

                if (achStoreBillingDetail != null)
                {
                    storeBilling.StoreBillingDetails.Add(achStoreBillingDetail);
                }

                if (cashrewardStoreBillingDetail != null)
                {
                    storeBilling.StoreBillingDetails.Add(cashrewardStoreBillingDetail);
                }

                storeBillings.Add(new { StoreBilling = storeBilling, TransactionIds = transactions.Select(t => t.TransactionId).ToArray() });
            }

            try
            {
                await _context.StoreBillings.InactiveUnpaid(request.Month, request.Year);
                await _context.StoreBillingDetails.InactiveUnpaid(request.Month, request.Year);

                foreach (var storeBillingModel in storeBillings)
                {
                    var storeBillingDb = await _context.StoreBillings.GeStoreBill(storeBillingModel.StoreBilling.StoreId, storeBillingModel.StoreBilling.Month, storeBillingModel.StoreBilling.Year);
                    IEnumerable<StoreBillingDetail> storebillingDetails = null;

                    if (storeBillingDb != null)
                    {
                        storeBillingModel.StoreBilling.IsActive = true;
                        storeBillingModel.StoreBilling.StoreBillingId = storeBillingDb.StoreBillingId;
                        storeBillingModel.StoreBilling.UpdatedOn = DateTime.UtcNow;
                        await _context.StoreBillings.Update(storeBillingModel.StoreBilling);
                        storebillingDetails = await _context.StoreBillingDetails.GetStoreBillingDetails(storeBillingDb.StoreBillingId);
                    }
                    else
                    {
                        storeBillingModel.StoreBilling.StoreBillingId = await _context.StoreBillings.Add(storeBillingModel.StoreBilling);
                        await _context.StoreBillings.UpdateInvoiceNumber(storeBillingModel.StoreBilling.StoreBillingId, $"INV1{storeBillingModel.StoreBilling.StoreBillingId.ToString("000000000")}");
                    }

                    foreach (var storeBillingDetail in storeBillingModel.StoreBilling.StoreBillingDetails)
                    {
                        if (storebillingDetails != null && storebillingDetails.Any(t => t.PaymentMethodId == storeBillingDetail.PaymentMethodId))
                        {
                            storeBillingDetail.IsActive = true;
                            storeBillingDetail.StoreBillingDetailId = storebillingDetails.FirstOrDefault(t => t.PaymentMethodId == storeBillingDetail.PaymentMethodId).StoreBillingDetailId;
                            storeBillingDetail.StoreBillingId = storeBillingModel.StoreBilling.StoreBillingId;
                            storeBillingDetail.UpdatedOn = DateTime.UtcNow;
                            await _context.StoreBillingDetails.Add(storeBillingDetail);
                        }
                        else
                        {
                            storeBillingDetail.StoreBillingId = storeBillingModel.StoreBilling.StoreBillingId;
                            await _context.StoreBillingDetails.Add(storeBillingDetail);
                        }
                    }

                    await _context.Transactions.UpdateStoreBilling(storeBillingModel.StoreBilling.StoreBillingId, storeBillingModel.TransactionIds, generatedBy);
                }

                _context.Commit();
                result.Success = true;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, ex.Message);
                result.Success = false;
                _context.Rollback();
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }

        private StoreBillingDetail GetStoreBillingDetail(SpiTech.Service.Clients.Stores.StoreInfoModel storeInfoModel, EnumPaymentMethod paymentMethod, List<NonBillStoreTransactionModel> transactions, List<StoreBillingFeeModel> nonBillStoreBillingFees, List<StoreBillingFeeModel> defaultStoreBillingFees, int generatedBy)
        {
            StoreBillingDetail storeBillingDetail = null;

            List<NonBillStoreTransactionModel> paymentMethodTransactions = null;

            if (paymentMethod == EnumPaymentMethod.CreditCard || paymentMethod == EnumPaymentMethod.ACH)
            {
                paymentMethodTransactions = transactions.Where(t => (int)paymentMethod == t.PaymentMethodId && t.FinalAmount > 0 && t.CardAmount > 0).ToList();
            }
            else if (paymentMethod == EnumPaymentMethod.CashReward)
            {
                paymentMethodTransactions = transactions.Where(t => t.FinalAmount > 0 && t.WalletAmount > 0).ToList();
            }

            int totalTransactionCount = paymentMethodTransactions.Count() - paymentMethodTransactions.Select(t => t.TransactionId).Intersect(usedTransactionIds).Count();

            if (totalTransactionCount > 0)
            {
                StoreBillingFeeModel storeBillingFee = nonBillStoreBillingFees.FirstOrDefault(t => t.PaymentMethodId == (int)paymentMethod && totalTransactionCount >= t.MinTransactionRange && totalTransactionCount <= t.MaxTransactionRange);

                if (storeBillingFee == null)
                {
                    storeBillingFee = defaultStoreBillingFees.FirstOrDefault(t => t.PaymentMethodId == (int)paymentMethod && totalTransactionCount >= t.MinTransactionRange && totalTransactionCount <= t.MaxTransactionRange);
                }

                if (storeBillingFee == null)
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreBillingFee", $"Store Billing Fee is not found for StoreId-{storeInfoModel.StoreId}-{storeInfoModel.StoreName} and transaction range of {totalTransactionCount} "));
                }

                decimal transactionAmount = 0;

                if (paymentMethod == EnumPaymentMethod.CreditCard || paymentMethod == EnumPaymentMethod.ACH)
                {
                    transactionAmount = paymentMethodTransactions.Sum(t => t.CardAmount);
                }
                else if (paymentMethod == EnumPaymentMethod.CashReward)
                {
                    transactionAmount = paymentMethodTransactions.Sum(t => t.WalletAmount);
                }

                decimal transactionFee = totalTransactionCount * storeBillingFee.TransactionFee;

                if (transactionFee > 0)
                {
                    usedTransactionIds.AddRange(paymentMethodTransactions.Select(t => t.TransactionId).ToArray());
                }

                decimal transactionPercentageFee = transactionAmount * storeBillingFee.TransactionPercentageFee / 100;

                storeBillingDetail = new StoreBillingDetail
                {
                    CreatedBy = generatedBy,
                    CreatedOn = DateTime.UtcNow,
                    DefineMonthlySaasFee = storeBillingFee.MonthlySaasFee,
                    DefineTransactionFee = storeBillingFee.TransactionFee,
                    DefineTransactionPercentageFee = storeBillingFee.TransactionPercentageFee,
                    MaxTransactionRange = storeBillingFee.MaxTransactionRange,
                    MinTransactionRange = storeBillingFee.MinTransactionRange,
                    IsActive = true,
                    TransactionAmount = transactionAmount,
                    TransactionCount = totalTransactionCount,
                    TransactionFee = transactionFee,
                    TransactionPercentageFee = transactionPercentageFee,
                    PaymentMethodId = (int)paymentMethod,
                };
            }

            return storeBillingDetail;
        }
    }
}
