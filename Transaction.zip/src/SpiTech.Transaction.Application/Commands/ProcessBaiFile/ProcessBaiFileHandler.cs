﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.BankFileParsers;
using SpiTech.ApplicationCore.Domain;
using SpiTech.ApplicationCore.Domain.Configs;
using SpiTech.ApplicationCore.Services;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.Transaction.Application.Services;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain;
using Renci.SshNet.Sftp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ResponseModel = SpiTech.ApplicationCore.Domain.Models.ResponseModel;

namespace SpiTech.Transaction.Application.Commands.ProcessBaiFile
{
    public class ProcessBaiFileHandler : IRequestHandler<ProcessBaiFileQuery, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<ProcessBaiFileHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IHtmlPdfConverterService converterService;
        private readonly IStorageService storageService;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly ISftpService sftpService;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly SftpConfigs sftpConfigs;

        public ProcessBaiFileHandler(IUnitOfWork context,
                                    ILogger<ProcessBaiFileHandler> logger,
                                    IMapper mapper,
                                    IStorageServiceFactory storageServiceFactory,
                                    IHtmlPdfConverterService converterService,
                                    IEventDispatcher eventDispatcher,
                                    ISftpService sftpService,
                                    IUserAuthenticationProvider userAuthenticationProvider,
                                    SftpConfigs sftpConfigs
                                    )
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.converterService = converterService;
            this.storageService = storageServiceFactory.Get(ContainerType.StrideBAIIncommingFile);
            _eventDispatcher = eventDispatcher;
            this.sftpService = sftpService;
            this.userAuthenticationProvider = userAuthenticationProvider;
            this.sftpConfigs = sftpConfigs;
        }

        public async Task<ResponseModel> Handle(ProcessBaiFileQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            ResponseModel res = new ResponseModel() { Success = false };

            try
            {
                var dbFiles = await _context.BaiFiles.UnArchivedFiles();
                var files = this.sftpService.GetFiles("BAI", this.sftpConfigs.Get(DomainConstant.SftpConfig.STRIDE));
                var unProcessedFiles = new List<SftpFile>();

                if (files != null && files.Any())
                {
                    foreach (var file in files)
                    {
                        if (!dbFiles.Any(t => t.BaiFileName.Equals(file.Name, System.StringComparison.OrdinalIgnoreCase)))
                        {
                            unProcessedFiles.Add(file);
                        }
                    }

                    if (unProcessedFiles.Any())
                    {
                        var unProcessedFileDetails = this.sftpService.DownloadFiles(unProcessedFiles, this.sftpConfigs.Get(DomainConstant.SftpConfig.STRIDE));

                        List<Domain.Entities.BaiFile> newBaiFiles = new List<Domain.Entities.BaiFile>();
                        foreach (var unProcessedFileDetail in unProcessedFileDetails)
                        {
                            try
                            {
                                using var memoryStream = new MemoryStream(unProcessedFileDetail.Bytes);
                                var parser = new BaiParser();
                                var bai = parser.Parse(memoryStream, Encoding.UTF8);
                                var trans = BaiTranslator.Translate(bai);
                                var baiAccountDetails = trans.GetDetailInformation();

                                //string fileName = Path.GetFileNameWithoutExtension(unProcessedFileDetail.FileName);
                                //string fileExt = Path.GetExtension(unProcessedFileDetail.FileName);
                                //string finalFileName = $"{fileName}_{DateTime.UtcNow.ToString("yyyyMMdd")}{fileExt}";

                                var uploaded = await this.storageService.UploadBlob(unProcessedFileDetail.Bytes, unProcessedFileDetail.FileName, "text/plain");
                                Blob blob = await storageService.GetFile(unProcessedFileDetail.FileName);

                                if (uploaded)
                                {
                                    var newBaiFile = new Domain.Entities.BaiFile
                                    {
                                        BaiFileName = unProcessedFileDetail.FileName,
                                        FileCreation = trans.FileCreationDateTime,
                                        IsArchived = false,
                                        ReceiverIdentification = trans.ReceiverIdentification,
                                        SenderIdentification = trans.SenderIdentification,
                                        TotalAmount = baiAccountDetails.Sum(t => t.Amount),
                                        UploadFileName = unProcessedFileDetail.FileName,
                                        UploadFilePath = blob.StorageUri,
                                        IsActive = true,
                                        CreatedOn = DateTime.UtcNow,
                                        BaiFileDetails = new List<Domain.Entities.BaiFileDetail>()
                                    };
                                    newBaiFiles.Add(newBaiFile);

                                    foreach (var baiAccountDetail in baiAccountDetails)
                                    {
                                        newBaiFile.BaiFileDetails.Add(new Domain.Entities.BaiFileDetail
                                        {
                                            Amount = baiAccountDetail.Amount,
                                            BankReferenceNumber = baiAccountDetail.BankReferenceNumber,
                                            CustomerAccountNumber = baiAccountDetail.CustomerAccountNumber,
                                            CustomerReferenceNumber = baiAccountDetail.CustomerReferenceNumber,
                                            FileIdentificationNumber = baiAccountDetail.FileIdentificationNumber,
                                            SenderIdentification = baiAccountDetail.SenderIdentification,
                                            TypeCode = baiAccountDetail.TypeCode,
                                            TypeDescription = baiAccountDetail.TypeDescription,
                                            IsActive = true,
                                            CreatedOn = DateTime.UtcNow,
                                        });
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                _logger.Error(ex, unProcessedFileDetail);
                                await _context.BaiErrorFiles.Add(new Domain.Entities.BaiErrorFile
                                {
                                    BaiFileName = unProcessedFileDetail.FileName,
                                    ErrorMessage = ex.Message,
                                    ErrorStackTrace = ex.StackTrace,
                                    IsActive = true,
                                    CreatedOn = DateTime.UtcNow,
                                });
                            }
                        }

                        try
                        {
                            foreach (var newBaiFile in newBaiFiles)
                            {
                                int baiFileId = await _context.BaiFiles.Add(newBaiFile);

                                foreach (var baiFileDetail in newBaiFile.BaiFileDetails)
                                {
                                    baiFileDetail.BaiFileId = baiFileId;
                                    int baiFileDetailId = await _context.BaiFileDetails.Add(baiFileDetail);
                                }
                            }

                            _context.Commit();
                        }
                        catch (Exception ex)
                        {
                            _logger.Error(ex, request, newBaiFiles);
                            _context.Rollback();
                        }
                    }

                    res.Success = true;
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, request);
            }

            _logger.TraceExitMethod(nameof(Handle), res);
            return res;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress(),
                IsError = isError,
                ErrorMessage = errorMessage

            });
        }
    }
}
