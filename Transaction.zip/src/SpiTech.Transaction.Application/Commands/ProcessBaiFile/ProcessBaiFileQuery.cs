﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.ProcessBaiFile
{
    public class ProcessBaiFileQuery : IRequest<ResponseModel>
    {
    }
}
