﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.CreateSaleItem
{
    public class CreateSaleItemHandler : IRequestHandler<CreateSaleItemCommand, bool>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateSaleItemHandler> _logger;
        private readonly IMapper _mapper;

        public CreateSaleItemHandler(IUnitOfWork context,
                                             ILogger<CreateSaleItemHandler> logger,
                                             IMapper mapper)
        {

            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<bool> Handle(CreateSaleItemCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            if (command.SaleItems != null)
            {
                try
                {
                    foreach (Domain.Models.SaleItemModel saleItem in command.SaleItems)
                    {
                        int saleItemId = await _context.SaleItems.Add(new Domain.Entities.SaleItem()
                        {
                            TransactionId = command.TransactionId,
                            ItemId = saleItem.ItemId,
                            EvaluateOnly = saleItem.EvaluateOnly,
                            ReverseSale = saleItem.ReverseSale,
                            ItemStatus = saleItem.ItemStatus,
                            PriceChangeEligible = saleItem.PriceChangeEligible,
                            POSCode = saleItem.POSCode,
                            POSCodeModifier = saleItem.POSCodeModifier,
                            POSCodeFormat = saleItem.POSCodeFormat,
                            ProductCode = saleItem.ProductCode,
                            OriginalAmount = saleItem.OriginalAmount,
                            OriginalAmountUnitPrice = saleItem.OriginalAmountUnitPrice,
                            AdjustedAmount = saleItem.AdjustedAmount,
                            AdjustedAmountUnitPrice = saleItem.AdjustedAmountUnitPrice,
                            UnitMeasure = saleItem.UnitMeasure,
                            Quantity = saleItem.Quantity,
                            AdditionalProductInfo = saleItem.AdditionalProductInfo,
                            Description = saleItem.Description,
                            PriceTier = saleItem.PriceTier,
                            RebateLabel = saleItem.RebateLabel,
                            ServiceLevel = saleItem.ServiceLevel,
                            OutdoorPosition = saleItem.OutdoorPosition,
                            CreatedOn = DateTime.UtcNow,
                            IsActive = true
                        });

                        if (saleItem.PriceAdjustments != null)
                        {
                            foreach (Domain.Models.PriceAdjustmentModel priceAdjustment in saleItem.PriceAdjustments)
                            {
                                await _context.PriceAdjustments.Add(new Domain.Entities.PriceAdjustment()
                                {
                                    SaleItemId = saleItemId,
                                    RewardApplied = priceAdjustment.RewardApplied,
                                    AdjustmentId = priceAdjustment.AdjustmentId,
                                    ProgramId = priceAdjustment.ProgramId,
                                    DoNotRelieveTaxFlag = priceAdjustment.DoNotRelieveTaxFlag,
                                    PromotionReason = priceAdjustment.PromotionReason,
                                    Amount = priceAdjustment.Amount,
                                    UnitPrice = priceAdjustment.UnitPrice,
                                    Quantity = priceAdjustment.Quantity,
                                    RebateLabel = priceAdjustment.RebateLabel,
                                    CreatedOn = DateTime.UtcNow,
                                    IsActive = true
                                });
                            }
                        }
                    }

                    _context.Commit();
                }
                catch (Exception)
                {
                    _context.Rollback();
                    throw;
                }
            }
            _logger.TraceExitMethod(nameof(Handle), true);
            return true;
        }
    }
}
