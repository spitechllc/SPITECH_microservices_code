﻿using MediatR;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.CreateSaleItem
{
    public class CreateSaleItemCommand : IRequest<bool>
    {
        public long TransactionId { get; set; }
        public SaleItemModel[] SaleItems { get; set; }
    }
}
