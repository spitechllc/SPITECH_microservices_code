﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.CreateSaleItem
{
    public class CreateSaleItemValidator : AbstractValidator<CreateSaleItemCommand>
    {
        public CreateSaleItemValidator()
        {
            RuleFor(x => x.TransactionId).GreaterThan(0).WithMessage("TransactionId must be greater than 0");
        }
    }

}
