﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.CreateStoreBillingFeeFromDefault
{
    public class CreateStoreBillingFeeFromDefaultHandler : IRequestHandler<CreateStoreBillingFeeFromDefaultCommand, ResponseModel>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateStoreBillingFeeFromDefaultHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        public CreateStoreBillingFeeFromDefaultHandler(IUnitOfWork context,
                                 ILogger<CreateStoreBillingFeeFromDefaultHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper,
        IEventDispatcher eventDispatcher,
        IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        /// <summary>
        /// Create Store Billing Fee From Default withn roollback transaction and also DispatchActivityLogEvent
        /// </summary>
        /// <param name="command"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ResponseModel> Handle(CreateStoreBillingFeeFromDefaultCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel responseModel = new();
            
            var dbStoreBillingFees = await _context.StoreBillingFees.GetDefaultFees();

            if (dbStoreBillingFees == null || !dbStoreBillingFees.Any())
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("DefaultFees", "Default Billing Fees not found"));
            }

            dbStoreBillingFees = dbStoreBillingFees.Where(t => t.IsActive).ToList();

            try
            {
                foreach (var dbStoreBillingFee in dbStoreBillingFees)
                {
                    Domain.Entities.StoreBillingFee model = new()
                    {
                        StoreId = command.StoreId,
                        SiteId = command.SiteId,
                        TransactionFee = dbStoreBillingFee.TransactionFee,
                        TransactionPercentageFee = dbStoreBillingFee.TransactionPercentageFee,
                        MonthlySaasFee = dbStoreBillingFee.MonthlySaasFee,
                        IsActive = true,
                        MaxTransactionRange = dbStoreBillingFee.MaxTransactionRange,
                        MinTransactionRange = dbStoreBillingFee.MinTransactionRange,
                        PaymentMethodId = dbStoreBillingFee.PaymentMethodId,
                        CreatedOn = DateTime.UtcNow,
                        IsDefault = false
                    };

                    int storeBillingFeeId = await _context.StoreBillingFees.Add(model);
                }
                
                _context.Commit();
                responseModel.Success = true;
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication()?.UserId??0, (int)ActivityType.CreateStoreBillingFee, "New StoreBillingFee Created from Default.", false, null);
            }
            catch (Exception ex)
            {
                responseModel.Success = false;
                _logger.Error(ex, command, dbStoreBillingFees);
                _context.Rollback(); 
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication()?.UserId??0, (int)ActivityType.CreateStoreBillingFee, "New StoreBillingFee Creation from Default Failed.", true, ex.Message);
            }

            return responseModel;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress(),
                IsError = isError,
                ErrorMessage = errorMessage

            });
        }
    }
}
