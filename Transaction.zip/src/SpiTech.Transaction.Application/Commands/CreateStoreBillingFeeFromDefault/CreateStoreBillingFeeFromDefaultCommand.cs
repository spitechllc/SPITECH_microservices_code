﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.CreateStoreBillingFeeFromDefault
{
    public class CreateStoreBillingFeeFromDefaultCommand : IRequest<ResponseModel>
    {
        public int StoreId { get; set; }
        public string SiteId { get; set; }
    }
}
