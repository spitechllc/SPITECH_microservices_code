﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.CreateStoreBillingFeeFromDefault
{
    public class CreateStoreBillingFeeFromDefaultValidator : AbstractValidator<CreateStoreBillingFeeFromDefaultCommand>
    {
        public CreateStoreBillingFeeFromDefaultValidator()
        {
            RuleFor(h => h.StoreId).GreaterThan(0).WithMessage("StoreId must be greater than 0");
            RuleFor(h => h.SiteId).NotNull().NotEmpty();
        }
    }
}
