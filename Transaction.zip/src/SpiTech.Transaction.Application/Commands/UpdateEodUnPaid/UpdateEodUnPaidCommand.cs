﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.UpdateEodUnPaid
{
    public class UpdateEodUnPaidCommand : IRequest<ResponseModel>
    {
        public int SettlementRequestId { get; set; }
        public bool OnlyCard { get; set; }
        public bool OnlyCashReward { get; set; }
        public bool OnlyACH { get; set; }
        public string Reason { get; set; }
    }
}
