﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using SpiTech.Transaction.Domain.Models;
using Polly;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.UpdateEodUnPaid
{
    public class UpdateEodUnPaidHandler : IRequestHandler<UpdateEodUnPaidCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateEodUnPaidHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public UpdateEodUnPaidHandler(IUnitOfWork context,
                                             ILogger<UpdateEodUnPaidHandler> logger,
                                             IMapper mapper,
                                             IEventDispatcher eventDispatcher,
                                             IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        /// <summary>
        /// Update Eod UnPaid
        /// </summary>
        /// <param name="command"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ResponseModel> Handle(UpdateEodUnPaidCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel result = new() { Success = false };
            bool status = false;
            int updateUserId = userAuthenticationProvider.GetUserAuthentication()?.UserId??0;

            try
            {
                status = await _context.SettlementRequests.UpdatePaymentStatus(new[] { command.SettlementRequestId },
                    command.OnlyCard ? Domain.Enums.PaymentStatusEnum.NotPaid : null,
                    command.OnlyCashReward ? Domain.Enums.PaymentStatusEnum.NotPaid : null,
                    command.OnlyACH ? Domain.Enums.PaymentStatusEnum.NotPaid : null,
                    null,
                    null,
                    updateUserId);

                if(status)
                {
                    status = await _context.SettlementPaymentDetails.MarkUnPaid(command.SettlementRequestId, command.OnlyCard, command.OnlyCashReward, command.OnlyACH,updateUserId, command.Reason);
                }
                
                List<TransactionModel> resultTran = _mapper.Map<List<TransactionModel>>(await _context.Transactions.GetTransactionByfilter(command.SettlementRequestId, 0, ""));

                bool tranResponse= false;
                if (resultTran[0].PaymentMethod == "Cash")
                {
                    tranResponse =  await _context.Transactions.UpdateTranProcessSettlementStatus(command.SettlementRequestId,
                        resultTran[0].AchPaymentStatusId == 1 ? 0 : 0,
                        resultTran[0].CardPaymentStatusId,
                        resultTran[0].CashRewardPaymentStatusId == 0 ? 0 : 1,
                        resultTran[0].MerchantPay == true ? false : false,
                        resultTran[0].ConsumerPay == true ? false: false,
                        resultTran[0].ConsumerPaid == 1 ? 0 : 0, 
                        resultTran[0].MerchantPaid == 1 ? 0 : 0);
                }
                if (resultTran[0].PaymentMethod == "Credit")
                {
                    tranResponse = await _context.Transactions.UpdateTranProcessSettlementStatus(command.SettlementRequestId,
                        resultTran[0].AchPaymentStatusId,
                        resultTran[0].CardPaymentStatusId == 1 ? 0 : 1,
                        resultTran[0].CashRewardPaymentStatusId,
                        resultTran[0].MerchantPay == true ? false : false,
                        resultTran[0].ConsumerPay,
                        (int)resultTran[0].ConsumerPaid,
                        resultTran[0].MerchantPaid == 1 ? 0 : 0);
                }

                

                _context.Commit();
                if (tranResponse)
                {
                    result.Success = true;
                    result.Message = "Success";
                }
                //if (!status)
                //{
                //    result.Success = false;
                //    result.Message = "Invalid SettlementRequestId";
                //}
                else
                {
                    result.Success = true;
                    await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication()?.UserId??0, (int)ActivityType.UpdateEodUnpaid, "Eod Unpaid Updated.", false, null, null, null);
                }
            }
            catch (Exception ex)
            {
                _context.Rollback();
                _logger.Error(ex, command);
                result.Success = false;
                result.Message = "Error occured while processing your request";
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication()?.UserId??0, (int)ActivityType.UpdateEodUnpaid, "Eod Unpaid Updation Failed.", true, ex.Message, null, null);
            }

            _logger.TraceExitMethod(nameof(Handle), status);
            return result;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage, string preData, string postData)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress(),
                IsError = isError,
                ErrorMessage = errorMessage,
                ActivityPreData = preData,
                ActivityPostData = postData

            });
        }
    }
}
