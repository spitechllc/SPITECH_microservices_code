﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.UpdateEodUnPaid
{
    public class UpdateEodUnPaidValidator : AbstractValidator<UpdateEodUnPaidCommand>
    {
        public UpdateEodUnPaidValidator()
        {
            RuleFor(x => x.SettlementRequestId).Cascade(CascadeMode.Stop)
                                                .GreaterThan(0)
                                                .WithMessage("SettlementRequestId should be valid");
            RuleFor(x => x.Reason).Cascade(CascadeMode.Stop)
                                                .NotNull()
                                                .NotEmpty()
                                                .MaximumLength(500)
                                                .WithMessage("Reason should not be empty");
        }
    }
}
