﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.CreateStoreBillingFee
{
    public class CreateStoreBillingFeeHandler : IRequestHandler<CreateStoreBillingFeeCommand, ResponseModel>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateStoreBillingFeeHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        public CreateStoreBillingFeeHandler(IUnitOfWork context,
                                 ILogger<CreateStoreBillingFeeHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper,
        IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
        }
        public async Task<ResponseModel> Handle(CreateStoreBillingFeeCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel responseModel = new();
            Domain.Entities.StoreBillingFee model = new()
            {
                StoreId = command.StoreId,
                SiteId = command.SiteId,
                TransactionFee = command.TransactionFee,
                TransactionPercentageFee = command.TransactionPercentageFee,
                MonthlySaasFee = command.MonthlySaasFee,
                IsActive = true,
                MaxTransactionRange = command.MaxTransactionRange,
                MinTransactionRange = command.MinTransactionRange,
                PaymentMethodId = command.PaymentMethodId,
                CreatedOn = DateTime.UtcNow,
                IsDefault = command.IsDefault
            };

            var dbStoreBillingFees = command.IsDefault ? await _context.StoreBillingFees.GetDefaultFees() : await _context.StoreBillingFees.GetByStoreId(command.StoreId);

            System.Collections.Generic.List<Domain.Models.StoreBillingFeeModel> storeBillingFees = (dbStoreBillingFees).Where(t => t.PaymentMethodId == command.PaymentMethodId).ToList();

            Domain.Models.StoreBillingFeeModel storeBillingFee = storeBillingFees.FirstOrDefault(t => t.MinTransactionRange == command.MinTransactionRange || t.MaxTransactionRange == command.MaxTransactionRange);

            if (storeBillingFee != null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("TransactionRange", "Duplicate MinTransactionRange/MaxTransactionRange"));
            }

            storeBillingFee = storeBillingFees.FirstOrDefault(t => t.MinTransactionRange <= command.MinTransactionRange && command.MinTransactionRange <= t.MaxTransactionRange);

            if (storeBillingFee != null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("MinTransactionRange", "MinTransactionRange already in between other ranges"));
            }

            storeBillingFee = storeBillingFees.FirstOrDefault(t => t.MinTransactionRange <= command.MaxTransactionRange && command.MaxTransactionRange <= t.MaxTransactionRange);

            if (storeBillingFee != null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("MaxTransactionRange", "MaxTransactionRange already in between other ranges"));
            }

            try
            {
                int storeBillingFeeId = await _context.StoreBillingFees.Add(model);
                _context.Commit();
                responseModel.Success = true;
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication()?.UserId??0, (int)ActivityType.CreateStoreBillingFee, "StoreBillingFee Created.", false, null);
            }
            catch (Exception ex)
            {
                responseModel.Success = false;
                _logger.Error(ex, command, model);
                _context.Rollback();
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication()?.UserId??0, (int)ActivityType.CreateStoreBillingFee, "StoreBillingFee Creation Failed.", true, ex.Message);
            }

            return responseModel;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress(),
                IsError = isError,
                ErrorMessage = errorMessage

            });
        }
    }
}
