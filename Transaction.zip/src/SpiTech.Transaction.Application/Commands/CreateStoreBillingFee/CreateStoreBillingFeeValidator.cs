﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.CreateStoreBillingFee
{
    public class CreateStoreBillingFeeValidator : AbstractValidator<CreateStoreBillingFeeCommand>
    {
        public CreateStoreBillingFeeValidator()
        {
            When(t => t.IsDefault, () => {
                RuleFor(h => h.SiteId).Empty();
                RuleFor(h => h.StoreId).Equal(0).WithMessage("StoreId must be 0 for default");
            });

            When(t => !t.IsDefault, () => {
                RuleFor(h => h.SiteId).NotNull().NotEmpty();
                RuleFor(h => h.StoreId).GreaterThan(0).WithMessage("StoreId must be greater than 0");
            });

            RuleFor(h => h.PaymentMethodId).GreaterThan(0).WithMessage("PaymentMethodId must be greater than 0");
            RuleFor(h => h.MinTransactionRange).GreaterThanOrEqualTo(0);
            RuleFor(h => h.MaxTransactionRange).GreaterThan(0);
            RuleFor(h => h.MinTransactionRange).LessThan(t => t.MaxTransactionRange);
            RuleFor(h => h.TransactionPercentageFee).GreaterThanOrEqualTo(0);
            RuleFor(h => h.MonthlySaasFee).GreaterThanOrEqualTo(0);
            RuleFor(h => h.TransactionFee).GreaterThanOrEqualTo(0);
        }
    }
}
