﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.CreateStoreBillingFee
{
    public class CreateStoreBillingFeeCommand : IRequest<ResponseModel>
    {
        public int StoreId { get; set; }
        public string SiteId { get; set; }
        public int PaymentMethodId { get; set; }
        public int MinTransactionRange { get; set; }
        public int MaxTransactionRange { get; set; }
        public decimal TransactionFee { get; set; }
        public decimal TransactionPercentageFee { get; set; }
        public decimal MonthlySaasFee { get; set; }
        public bool IsDefault { get; set; }
    }
}
