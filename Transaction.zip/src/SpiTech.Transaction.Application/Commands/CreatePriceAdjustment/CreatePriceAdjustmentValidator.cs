﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.CreatePriceAdjustment
{
    public class CreatePriceAdjustmentValidator : AbstractValidator<CreatePriceAdjustmentCommand>
    {
        public CreatePriceAdjustmentValidator()
        {
            RuleFor(x => x.PriceAdjustment).NotNull();
        }
    }
}
