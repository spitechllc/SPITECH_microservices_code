﻿using MediatR;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.CreatePriceAdjustment
{
    public class CreatePriceAdjustmentCommand : IRequest<int>
    {
        public PriceAdjustmentModel PriceAdjustment { get; set; }
    }
}
