﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.CreateResellerFeeFromDefault
{
    public class CreateResellerFeeFromDefaultHandler : IRequestHandler<CreateResellerFeeFromDefaultCommand, ResponseModel>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateResellerFeeFromDefaultHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        public CreateResellerFeeFromDefaultHandler(IUnitOfWork context,
                                 ILogger<CreateResellerFeeFromDefaultHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper,
        IEventDispatcher eventDispatcher,
        IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<ResponseModel> Handle(CreateResellerFeeFromDefaultCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel responseModel = new();

            var dbResellerFees = await _context.ResellerFees.GetDefaultFees(command.CoreProcessingName);

            if (dbResellerFees == null || !dbResellerFees.Any())
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("DefaultFees", $"Default Billing Fees not found for CoreProcessingName({command.CoreProcessingName})"));
            }

            dbResellerFees = dbResellerFees.Where(t => t.IsActive).ToList();

            try
            {
                foreach (var dbResellerFee in dbResellerFees)
                {
                    Domain.Entities.ResellerFee model = new()
                    {
                        ResellerId = command.ResellerId,
                        MinStoreRange = dbResellerFee.MinStoreRange,
                        MaxStoreRange = dbResellerFee.MaxStoreRange,
                        ACHTransactionFee = dbResellerFee.ACHTransactionFee,
                        CardTransactionFee = dbResellerFee.CardTransactionFee,
                        CashRewardTransactionFee = dbResellerFee.CashRewardTransactionFee,
                        IsActive = true,
                        ACHProcessingFee = dbResellerFee.ACHProcessingFee,
                        MonthlySaasFee = dbResellerFee.MonthlySaasFee,
                        CoreProcessingName = command.CoreProcessingName,
                        CreatedOn = DateTime.UtcNow,
                        IsDefault = false
                    };

                    int resellerFeeId = await _context.ResellerFees.Add(model);
                }

                _context.Commit();
                responseModel.Success = true;
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication()?.UserId??0, (int)ActivityType.CreateResellerFee, "ResellerFee Created from Default.", false, null);
            }
            catch (Exception ex)
            {
                responseModel.Success = false;
                _logger.Error(ex, command, dbResellerFees);
                _context.Rollback();
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication()?.UserId??0, (int)ActivityType.CreateResellerFee, "ResellerFee Creation from Default Failed.", true, ex.Message);
            }

            return responseModel;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress(),
                IsError = isError,
                ErrorMessage = errorMessage

            });
        }
    }
}
