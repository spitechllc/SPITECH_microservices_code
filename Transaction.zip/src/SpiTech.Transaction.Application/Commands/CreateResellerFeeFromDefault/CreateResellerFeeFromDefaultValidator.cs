﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.CreateResellerFeeFromDefault
{
    public class CreateResellerFeeFromDefaultValidator : AbstractValidator<CreateResellerFeeFromDefaultCommand>
    {
        public CreateResellerFeeFromDefaultValidator()
        {
            RuleFor(h => h.ResellerId).GreaterThan(0).WithMessage("ResellerId must be greater than 0");
            RuleFor(h => h.CoreProcessingName).NotNull().NotEmpty();
        }
    }
}
