﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.CreateResellerFeeFromDefault
{
    public class CreateResellerFeeFromDefaultCommand : IRequest<ResponseModel>
    {
        public int ResellerId { get; set; }
        public string CoreProcessingName { get; set; }
    }
}
