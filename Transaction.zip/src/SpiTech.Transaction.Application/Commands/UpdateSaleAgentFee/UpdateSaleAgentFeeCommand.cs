﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.UpdateSaleAgentFee
{
    public class UpdateSaleAgentFeeCommand : IRequest<ResponseModel>
    {
        public int SaleAgentFeeId { get; set; }
        public decimal TransactionPercentageFee { get; set; }
        public decimal MonthlySaasFee { get; set; }
        public bool IsActive { get; set; }
    }
}
