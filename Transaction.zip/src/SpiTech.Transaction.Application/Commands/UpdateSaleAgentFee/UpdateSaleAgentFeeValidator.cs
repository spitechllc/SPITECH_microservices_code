﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.UpdateSaleAgentFee
{
    public class UpdateSaleAgentFeeValidator : AbstractValidator<UpdateSaleAgentFeeCommand>
    {
        public UpdateSaleAgentFeeValidator()
        {
            RuleFor(h => h.SaleAgentFeeId).GreaterThan(0).WithMessage("SaleAgentFeeId must be greater than 0");
            RuleFor(h => h.TransactionPercentageFee).GreaterThanOrEqualTo(0);
            RuleFor(h => h.MonthlySaasFee).GreaterThanOrEqualTo(0);
        }
    }
}
