﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.UpdateSaleAgentFee
{
    public class UpdateSaleAgentFeeHandler : IRequestHandler<UpdateSaleAgentFeeCommand, ResponseModel>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateSaleAgentFeeHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        public UpdateSaleAgentFeeHandler(IUnitOfWork context,
                                 ILogger<UpdateSaleAgentFeeHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper, IEventDispatcher eventDispatcher,
                                 IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        /// <summary>
        /// Update Sale Agent Fee
        /// </summary>
        /// <param name="command"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<ResponseModel> Handle(UpdateSaleAgentFeeCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel responseModel = new();

            var saleAgentFee = await _context.SaleAgentFees.Get(command.SaleAgentFeeId);

            if (saleAgentFee == null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("SaleAgentFeeId", "Invalid SaleAgentFeeId"));
            }

            saleAgentFee.TransactionPercentageFee = command.TransactionPercentageFee;  
            saleAgentFee.MonthlySaasFee = command.MonthlySaasFee;
            saleAgentFee.IsActive = command.IsActive;

            try
            {
                responseModel.Success = await _context.SaleAgentFees.Update(saleAgentFee);
                _context.Commit();
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication()?.UserId??0, (int)ActivityType.UpdateSaleAgentFee, "SaleAgentFee Updated.", false, null, null, null);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, command, saleAgentFee);
                _context.Rollback();
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication()?.UserId??0, (int)ActivityType.UpdateSaleAgentFee, "SaleAgentFee Updation Failed.", true, ex.Message, null, null);
            }

            _logger.TraceExitMethod(nameof(Handle), responseModel);

            return await Task.FromResult(responseModel);
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage, string preData, string postData)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress(),
                IsError = isError,
                ErrorMessage = errorMessage,
                ActivityPreData = preData,
                ActivityPostData = postData

            });
        }
    }
}
