﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.ReconcileTransaction
{
    public class ReconcileTransactionHandler : IRequestHandler<ReconcileTransactionCommand, bool>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<ReconcileTransactionHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public ReconcileTransactionHandler(IUnitOfWork context,
                                             ILogger<ReconcileTransactionHandler> logger,
                                             IMapper mapper,
                                             IEventDispatcher eventDispatcher,
                                             IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        /// <summary>
        /// Reconcile Transaction
        /// </summary>
        /// <param name="command"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<bool> Handle(ReconcileTransactionCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            bool result = false;

            try
            {
                await _context.Execute(async () =>
                {
                    result = await _context.Transactions.ReconcileTransaction(command.StoreId, command.SiteId, command.SettlementPeriodId, command.SettlementRequestId);
                });
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
