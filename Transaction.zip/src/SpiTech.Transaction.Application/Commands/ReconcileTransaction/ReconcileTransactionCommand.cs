﻿using MediatR;

namespace SpiTech.Transaction.Application.Commands.ReconcileTransaction
{
    public class ReconcileTransactionCommand : IRequest<bool>
    {
        public int StoreId { get; set; }
        public string SiteId { get; set; }
        public string SettlementPeriodId { get; set; }
        public int SettlementRequestId { get; set; }
    }
}
