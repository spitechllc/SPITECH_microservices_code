﻿using FluentValidation;
using System.Linq;

namespace SpiTech.Transaction.Application.Commands.UpdateStoreBillingNeedReview
{
    public class UpdateStoreBillingNeedReviewValidator : AbstractValidator<UpdateStoreBillingNeedReviewCommand>
    {
        public UpdateStoreBillingNeedReviewValidator()
        {
            RuleFor(x => x.StoreBillingIds).Cascade(CascadeMode.Stop)
                                                .NotNull()
                                                .NotEmpty()
                                                .Must(NotEqualZero)
                                                .WithMessage("StoreBillingId should be valid");
        }

        private bool NotEqualZero(int[] storeBillingIds)
        {
            return storeBillingIds?.All(i => i > 0) ?? false;
        }
    }
}
