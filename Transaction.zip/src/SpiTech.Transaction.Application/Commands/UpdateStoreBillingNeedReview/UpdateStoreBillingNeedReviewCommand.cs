﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.UpdateStoreBillingNeedReview
{
    public class UpdateStoreBillingNeedReviewCommand : IRequest<ResponseModel>
    {
        public int[] StoreBillingIds { get; set; }
        public bool IsNeedReview { get; set; }
    }
}
