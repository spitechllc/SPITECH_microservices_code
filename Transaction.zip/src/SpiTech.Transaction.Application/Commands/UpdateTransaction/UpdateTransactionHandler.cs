﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.UpdateTransaction
{
    public class UpdateTransactionHandler : IRequestHandler<UpdateTransactionCommand, bool>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateTransactionHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public UpdateTransactionHandler(IUnitOfWork context,
                                             ILogger<UpdateTransactionHandler> logger,
                                             IMapper mapper,
                                             IEventDispatcher eventDispatcher, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<bool> Handle(UpdateTransactionCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            bool status = false;

            try
            {
                status = await _context.Transactions.Update(command.Transaction);

                _context.Commit();
            }
            catch (Exception ex)
            {
                _context.Rollback();
                throw;
            }

            if (status)
            {
                await eventDispatcher.Dispatch(new TransactionEvent
                {
                    Transaction = _mapper.Map<EventBus.DomainEvents.Models.Mppa.Transaction>(command.Transaction)
                });
            }

            _logger.TraceExitMethod(nameof(Handle), status);
            return status;
        }
    }
}
