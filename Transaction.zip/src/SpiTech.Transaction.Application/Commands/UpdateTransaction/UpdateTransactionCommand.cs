﻿using MediatR;

namespace SpiTech.Transaction.Application.Commands.UpdateTransaction
{
    public class UpdateTransactionCommand : IRequest<bool>
    {
        public Domain.Entities.Transaction Transaction { get; set; }
    }
}
