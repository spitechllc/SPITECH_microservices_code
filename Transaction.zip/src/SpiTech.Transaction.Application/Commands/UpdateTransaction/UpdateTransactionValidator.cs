﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.UpdateTransaction
{
    public class UpdateTransactionValidator : AbstractValidator<UpdateTransactionCommand>
    {
        public UpdateTransactionValidator()
        {
            RuleFor(x => x.Transaction.TransactionId).GreaterThan(0).WithMessage("TransactionId must be greater than 0");
            RuleFor(x => x.Transaction.UserId).GreaterThan(0).WithMessage("Userid must be greater than 0");
            RuleFor(x => x.Transaction.UMTI).NotNull().WithMessage("UMTI is required");
        }
    }
}
