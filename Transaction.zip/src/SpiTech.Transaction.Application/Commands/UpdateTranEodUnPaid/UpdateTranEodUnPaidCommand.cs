﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.UpdateTranEodUnPaid
{
    public class UpdateTranEodUnPaidCommand : IRequest<ResponseModel>
    {
        public int TransactionId { get; set; }
        public bool OnlyCard { get; set; }
        public bool OnlyCashReward { get; set; }
        public bool OnlyACH { get; set; }
        public string Reason { get; set; }
    }
}
