﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.ProcessStoreEodSettlementList
{
    public class ProcessStoreEodSettlementListQuery : IRequest<ResponseModel>
    {
    }
}
