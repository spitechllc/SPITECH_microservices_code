﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Service.Clients.Finance;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.Services;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ResponseModel = SpiTech.ApplicationCore.Domain.Models.ResponseModel;

namespace SpiTech.Transaction.Application.Commands.ProcessStoreEodSettlementList
{
    public class ProcessStoreEodSettlementListHandler : IRequestHandler<ProcessStoreEodSettlementListQuery, ResponseModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<ProcessStoreEodSettlementListHandler> logger;
        private readonly IMediator mediator;
        private readonly IStoreServiceClient _storeapiclient;
        private readonly IFinanceServiceClient _financeapiclient;
        private readonly IHtmlPdfConverterService converterService;
        private readonly IStorageService storageService;
        private readonly IEventDispatcher _eventDispatcher;

        public ProcessStoreEodSettlementListHandler(IUnitOfWork context,
                                            ILogger<ProcessStoreEodSettlementListHandler> logger
                                            , IMediator mediator
                                            , IStoreServiceClient storeapiclient
                                            , IFinanceServiceClient financeapiclient
                                            , IStorageServiceFactory storageServiceFactory
                                            , IHtmlPdfConverterService converterService
                                            , IEventDispatcher eventDispatcher)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            _storeapiclient = storeapiclient;
            _financeapiclient = financeapiclient;
            this.converterService = converterService;
            this.storageService = storageServiceFactory.Get(ContainerType.EodPdf);
            _eventDispatcher = eventDispatcher;
        }

        public async Task<ResponseModel> Handle(ProcessStoreEodSettlementListQuery query, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), query);
            ResponseModel eODInvoiceResponseModel = new ResponseModel() { Success = false };

            var storeEodSettlements = await context.SettlementRequests.GetUnPorcessedStoreEodSettlements();

            if (storeEodSettlements != null && storeEodSettlements.Any())
            {
                List<Service.Clients.Stores.StoreSearchResult> storeDetails = (await _storeapiclient.GetStoresPrimaryDetailsBySiteIdsAsync(storeEodSettlements.Select(t => t.SiteID))).ToList();

                DateTime businessDate = DateTime.SpecifyKind(storeEodSettlements.First().BusinessDate, DateTimeKind.Utc);

                GetCashRewardDetailsByFilterQuery request = new()
                {
                    StoreIds = storeEodSettlements.Select(t => t.StoreId).ToList(),
                    StartDate = businessDate.Date,
                    EndDate = businessDate.Date.AddDays(1).AddTicks(-1)
                };

                var cashRewards = (await _financeapiclient.GetCashRewardDetailsByStoreIdAsync(request)).ToList();

                foreach (var storeEodSettlement in storeEodSettlements)
                {
                    storeEodSettlement.PaymentMethodDetails = (await context.Transactions.GetPaymentMethodDetails(storeEodSettlement.SettlementRequestId)) ?? new List<PaymentMethodDetail>();

                    storeEodSettlement.StoreId = storeDetails.Where(s => s.SiteId == storeEodSettlement.SiteID).FirstOrDefault()?.StoreId ?? 0;
                    storeEodSettlement.StoreName = storeDetails.Where(s => s.SiteId == storeEodSettlement.SiteID).FirstOrDefault()?.StoreName;

                    ICollection<Service.Clients.Stores.AddressModel> address = storeDetails.Where(s => s.SiteId == storeEodSettlement.SiteID).FirstOrDefault()?.Addresses;

                    if (address != null)
                    {
                        storeEodSettlement.StoreAddress = address.FirstOrDefault()?.AddressLine1 + " " + address.FirstOrDefault()?.AddressLine2;
                    }

                    if (cashRewards != null)
                    {
                        storeEodSettlement.TotalCashRewardAwarded = cashRewards.Where(s => s.StoreId == storeEodSettlement.StoreId).Sum(t => t.TotalEarned);
                        storeEodSettlement.TotalCashRewardRedeemed = cashRewards.Where(s => s.StoreId == storeEodSettlement.StoreId).Sum(t => t.TotalRedeemed);
                    }

                    byte[] fileBytes = await this.converterService.CreatePdfFromView("StoreEodInvoice", storeEodSettlement);

                    await SaveAndDispatchEmailEvent(storeEodSettlement, fileBytes);

                    eODInvoiceResponseModel.Success = true;
                }
            }

            logger.TraceExitMethod(nameof(Handle), storeEodSettlements);

            return eODInvoiceResponseModel;
        }

        private async Task SaveAndDispatchEmailEvent(StoreEodSettlementModel storeEodSettlement, byte[] fileBytes)
        {
            storeEodSettlement.SettlementFileName = storeEodSettlement.SettlementRequestId + "_storeeodinvoice" + "_" + UniqueIdGenerator.Generate() + ".pdf";
            storeEodSettlement.SettlementFilePath = await SaveBlobFile(Convert.ToBase64String(fileBytes), storeEodSettlement.SettlementFileName, "application/pdf");

            if (!string.IsNullOrEmpty(storeEodSettlement.SettlementFilePath))
            {
                await context.SettlementRequests.UpdateInvoicePdfFilePath(storeEodSettlement.SettlementRequestId, storeEodSettlement.SettlementFileName, storeEodSettlement.SettlementFilePath);

                if (storeEodSettlement.TerminalTotalAmount > 0 && storeEodSettlement.ProcessStatus != DomainConstant.ProcessStatus.Completed)
                {
                    await _eventDispatcher.Dispatch(new StoreEodSettlementEvent
                    {
                        StoreEodSettlement = storeEodSettlement
                    });

                    await context.SettlementRequests.UpdateProcessStatus(new[] { storeEodSettlement.SettlementRequestId }, null, DomainConstant.ProcessStatus.Completed);
                }

                context.Commit();
            }
        }

        private async Task<string> SaveBlobFile(string base64file, string filename, string contenttype)
        {
            await storageService.UploadBlobBase64(base64file, filename, contenttype);
            Blob res = await storageService.GetFile(filename);
            return res != null ? res.StorageUri : string.Empty;
        }
    }
}
