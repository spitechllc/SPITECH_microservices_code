﻿using AutoMapper;
using MediatR;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Transaction.Application.Commands.UpdateTranEodUnPaid;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Domain.Models;
using SpiTech.ApplicationCore.Domain.Models;
using System.Net.Http;
using SpiTech.Transaction.Application.Services.Interface;
using Microsoft.CodeAnalysis;
using Newtonsoft.Json;
using SpiTech.Transaction.Domain.Configs;

namespace SpiTech.Transaction.Application.Commands.CheckBalance
{
 
    public class CheckBalanceHandler : IRequestHandler<CheckBalanceCommand, CheckBalanceModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CheckBalanceHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IPlaidService _plaidService;
        //private readonly PlaidGatewayConfigs _plaidGatewayConfigs;



        public CheckBalanceHandler(IUnitOfWork context,
                                             ILogger<CheckBalanceHandler> logger,
                                             IMapper mapper,
                                             IEventDispatcher eventDispatcher,
                                             IUserAuthenticationProvider userAuthenticationProvider,
                                             IPlaidService plaidService
                                             )
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _plaidService = plaidService;
            //_plaidGatewayConfigs = plaidGatewayConfigs;
        }

        public async Task<CheckBalanceModel> Handle(CheckBalanceCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            CheckBalanceModel responseModel = new();
            CheckBalanceCommandModel reqInput = new CheckBalanceCommandModel();
            #region sanbox
            //string requestvalue = "https://sandbox.plaid.com/accounts/balance/get";
            //reqInput.client_id = "62177b634de41c001bc8d33f";
            //reqInput.secret = "6a04e8ff5ab8536918a86f152c4d6a";
            #endregion

            #region Production
            string requestvalue = "https://api.plaid.com/accounts/balance/get";
            reqInput.client_id = "623b92759814fc001a6325a4";
            reqInput.secret = "0f1bdc7f9834d713d3608b33826451";
            #endregion

            reqInput.access_token = command.access_token;
            string strjson = ApplicationCore.Helpers.JsonObjectConverter.Serialize(reqInput);
            HttpContent content = new StringContent(strjson, Encoding.UTF8, "application/json");
            _logger.Warn($"Check Balance Input Request:" + strjson);

            HttpResponseMessage balanceInfo = await _plaidService.SendRequest(HttpMethod.Post, requestvalue, content, null, null, null);
            if (balanceInfo.IsSuccessStatusCode)
            {
                _logger.Warn($"Check Balance IsSuccessStatusCode:" + balanceInfo.IsSuccessStatusCode);
                string responseData = await balanceInfo.Content.ReadAsStringAsync();
                CheckBalanceModel objModel = new CheckBalanceModel();
                objModel = JsonConvert.DeserializeObject<CheckBalanceModel>(responseData);
                _logger.Warn($"Check Balance request_id:" + objModel.request_id);
                responseModel.request_id = objModel.request_id;
                responseModel.accounts= objModel.accounts;
            }

            return responseModel;
        }
    }
}
