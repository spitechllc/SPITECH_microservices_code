﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Transaction.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.CheckBalance
{
    public class CheckBalanceCommand : IRequest<CheckBalanceModel>
    {
        public string access_token { get; set; }
    }

    public class CheckBalanceCommandModel
    {
        public string client_id { get; set; }
        public string secret { get; set; }
        public string access_token { get; set; }
    }
}
