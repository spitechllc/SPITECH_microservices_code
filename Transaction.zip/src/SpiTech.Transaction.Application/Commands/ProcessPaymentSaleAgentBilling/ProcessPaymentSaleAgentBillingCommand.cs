﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.ProcessPaymentSaleAgentBilling
{
    public class ProcessPaymentSaleAgentBillingCommand : IRequest<ResponseModel>
    {
        public int Month { get; set; }
        public int Year { get; set; }
    }
}
