﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain;
using SpiTech.ApplicationCore.Domain.Configs;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using SpiTech.ApplicationCore.Nacha;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.Queries.GetNachaSaleAgentBillingProcessingAccount;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.ProcessPaymentSaleAgentBilling
{
    public class ProcessPaymentSaleAgentBillingHandler : IRequestHandler<ProcessPaymentSaleAgentBillingCommand, ResponseModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<ProcessPaymentSaleAgentBillingHandler> logger;
        private readonly IMediator mediator;
        private readonly INachaFileBuilder nachaFileBuilder;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IStorageService storageService;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IPaymentServiceClient paymentService;
        private readonly SftpConfigs sftpConfigs;

        public ProcessPaymentSaleAgentBillingHandler(IUnitOfWork context,
                                    ILogger<ProcessPaymentSaleAgentBillingHandler> logger,
                                    IMediator mediator,
                                    INachaFileBuilder nachaFileBuilder,
                                    IStorageServiceFactory storageServiceFactory,
                                    IUserAuthenticationProvider userAuthenticationProvider,
                                    IEventDispatcher eventDispatcher,
                                    IPaymentServiceClient paymentService,
                                    SftpConfigs sftpConfigs)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            this.nachaFileBuilder = nachaFileBuilder;
            this.userAuthenticationProvider = userAuthenticationProvider;
            storageService = storageServiceFactory.Get(ContainerType.MonthlySaleAgentInvoiceNachaFile);
            _eventDispatcher = eventDispatcher;
            this.paymentService = paymentService;
            this.sftpConfigs = sftpConfigs;
        }

        public async Task<ResponseModel> Handle(ProcessPaymentSaleAgentBillingCommand command, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), command);
            Domain.Entities.SaleAgentBillingPayment saleAgentBillingPayment = null;

            int uploadUserId = userAuthenticationProvider.GetUserAuthentication()?.UserId??0;

            ResponseModel response = new();

            var nachaConfig = (await context.NachaConfigs.GetAll()).FirstOrDefault();

            if (nachaConfig == null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("NachaConfig", "Unable to get NachaConfigs"));
            }

            NachaProcessingModel nachaProcessingModel = await mediator.Send(new GetNachaSaleAgentBillingProcessingAccountQuery
            {
                Year = command.Year,
                Month = command.Month,
            });

            if (nachaProcessingModel == null)
            {
                response.Message = "No StoreBilling found for processing";
                return response;
            }

            try
            {
                var accounts = nachaProcessingModel.ProcessingEntities.SelectMany(t => t.Accounts).ToList();
                saleAgentBillingPayment = new Domain.Entities.SaleAgentBillingPayment
                {
                    BillGenerateBy = uploadUserId,
                    BillGenerateDate = DateTime.UtcNow,
                    AccountNo = nachaProcessingModel.Config.AccountNo,
                    Month = command.Month,
                    Year = command.Year,
                    Bank = nachaProcessingModel.Config.BankName,
                    AccountName = nachaProcessingModel.Config.BatchCompanyName,
                    RoutingNo = nachaProcessingModel.Config.RoutingNo,
                    IsChecking = true,
                    IsActive = true,
                    TotalAmount = accounts.Sum(t => t.Amount),
                    NachaFilePath = "",
                    CreatedBy = uploadUserId,
                    CreatedOn = DateTime.UtcNow,
                };

                int saleAgentBillingPaymentId = await context.SaleAgentBillingPayments.Add(saleAgentBillingPayment);

                foreach (NachaModel nachaModel in accounts)
                {
                    await context.SaleAgentBillingPaymentDetails.Add(new Domain.Entities.SaleAgentBillingPaymentDetail
                    {
                        AccountNo = nachaModel.ProcessingAccount.AccountNo,
                        RoutingNo = nachaModel.ProcessingAccount.RoutingNo,
                        Amount = nachaModel.Amount,
                        AccountName = nachaModel.ProcessingAccount.AccountName,
                        IsChecking = nachaModel.ProcessingAccount.AccountType == AccountType.Checking,
                        StoreId = (int)nachaModel.AccountEntityId,
                        SaleAgentBillingPaymentId = saleAgentBillingPaymentId,
                        IdentificationNumber = nachaModel.IdentificationNumber,
                        //SaleAgentBillingId = nachaModel.RequestId,
                        IsActive = true,
                        CreatedBy = uploadUserId,
                        CreatedOn = DateTime.UtcNow,
                    });
                }

                NachaFileBytesModel nachaProcessFileBytesModel = nachaFileBuilder.GetBytes(nachaProcessingModel.Config, accounts);

                string nachaUploadError = "";
                bool isNachaUploaded = true;

                if (nachaProcessFileBytesModel != null)
                {
                    await storageService.UploadBlob(nachaProcessFileBytesModel.Bytes, nachaProcessFileBytesModel.File, "text/plain");
                    Blob blobProcess = await storageService.GetFile(nachaProcessFileBytesModel.File);

                    await context.SaleAgentBillingPayments.UpdateNachaFilePath(saleAgentBillingPaymentId,
                                                                                blobProcess.StorageUri,
                                                                                nachaProcessFileBytesModel.File,
                                                                                "",
                                                                                "",
                                                                                DomainConstant.SftpConfig.FNBO);
                    try
                    {
                        response.Success = await nachaFileBuilder.UploadFileInSftp(nachaProcessFileBytesModel, nachaConfig.IsProdEnabled, this.sftpConfigs.Get(DomainConstant.SftpConfig.FNBO));
                    }
                    catch (Exception ex)
                    {
                        nachaUploadError = ex.Message;
                        logger.Error(ex, command, nachaProcessFileBytesModel, nachaConfig);
                        response.Success = false;
                        isNachaUploaded = false;
                    }
                }
                else
                {
                    response.Success = true;
                }

                //await context.SaleAgentBillings.UpdatePaid(nachaProcessingModel.Accounts.Select(t => t.RequestId).Distinct().ToArray(), uploadUserId, response.Success);

                await context.SaleAgentBillingPayments.UpdateNachaFileUploadStatus(saleAgentBillingPaymentId, isNachaUploaded, nachaUploadError, false, "");

                context.Commit();
            }
            catch (Exception ex)
            {
                logger.Error(ex, command);
                context.Rollback();
                response.Success = false;
            }

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
