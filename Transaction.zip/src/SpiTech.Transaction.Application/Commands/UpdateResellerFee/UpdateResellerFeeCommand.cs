﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.UpdateResellerFee
{
    public class UpdateResellerFeeCommand : IRequest<ResponseModel>
    {
        public int ResellerFeeId { get; set; }
        public int? ResellerId { get; set; }
        public int MinStoreRange { get; set; }
        public int MaxStoreRange { get; set; }
        public decimal ACHTransactionFee { get; set; }
        public decimal CardTransactionFee { get; set; }
        public decimal CashRewardTransactionFee { get; set; }
        public decimal ACHProcessingFee { get; set; }
        public decimal MonthlySaasFee { get; set; }
        public string CoreProcessingName { get; set; }
        public bool IsDefault { get; set; }
        public bool IsActive { get; set; }
    }
}
