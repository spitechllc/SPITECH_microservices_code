﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.UpdateResellerFee
{
    public class UpdateResellerFeeHandler : IRequestHandler<UpdateResellerFeeCommand, ResponseModel>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateResellerFeeHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        public UpdateResellerFeeHandler(IUnitOfWork context,
                                 ILogger<UpdateResellerFeeHandler> logger,
                                 IMediator mediator,
                                 IMapper mapper, IEventDispatcher eventDispatcher,
                                 IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<ResponseModel> Handle(UpdateResellerFeeCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel responseModel = new();

            Domain.Entities.ResellerFee model = new()
            {
                ResellerId = command.ResellerId,
                MinStoreRange = command.MinStoreRange,
                MaxStoreRange = command.MaxStoreRange,
                ACHTransactionFee = command.ACHTransactionFee,
                CardTransactionFee = command.CardTransactionFee,
                CashRewardTransactionFee = command.CashRewardTransactionFee,
                ACHProcessingFee = command.ACHProcessingFee,
                MonthlySaasFee = command.MonthlySaasFee,
                CoreProcessingName = command.CoreProcessingName,
                ResellerFeeId = command.ResellerFeeId,
                IsDefault = command.IsDefault,
                IsActive = command.IsActive,
            };

            var dbResellerFees = command.IsDefault ? await _context.ResellerFees.GetDefaultFees(command.CoreProcessingName) : await _context.ResellerFees.GetByResellerId(command.ResellerId ?? 0);


            if (dbResellerFees.FirstOrDefault(t => t.ResellerFeeId == command.ResellerFeeId) == null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("ResellerFeeId", "Invalid ResellerFeeId"));
            }

            dbResellerFees = dbResellerFees.Where(t => t.ResellerFeeId != command.ResellerFeeId).ToList();

            var resellerFee = dbResellerFees.FirstOrDefault(t => t.MinStoreRange == command.MinStoreRange || t.MaxStoreRange == command.MaxStoreRange);

            if (resellerFee != null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("TransactionRange", "Duplicate MinTransactionRange/MaxTransactionRange"));
            }

            resellerFee = dbResellerFees.FirstOrDefault(t => t.MinStoreRange <= command.MinStoreRange && command.MinStoreRange <= t.MinStoreRange);

            if (resellerFee != null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("MinStoreRange", "MinStoreRange already in between other ranges"));
            }

            resellerFee = dbResellerFees.FirstOrDefault(t => t.MaxStoreRange <= command.MaxStoreRange && command.MaxStoreRange <= t.MaxStoreRange);

            if (resellerFee != null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("MaxStoreRange", "MaxStoreRange already in between other ranges"));
            }

            try
            {
                responseModel.Success = await _context.ResellerFees.Update(model);
                _context.Commit();
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication()?.UserId??0, (int)ActivityType.UpdateResellerFee, "ResellerFee Updated.", false, null, null, null);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, command, model);
                _context.Rollback();
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication()?.UserId??0, (int)ActivityType.UpdateResellerFee, "ResellerFee Updation Failed.", true, ex.Message, null, null);
            }

            _logger.TraceExitMethod(nameof(Handle), responseModel);

            return await Task.FromResult(responseModel);
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage, string preData, string postData)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress(),
                IsError = isError,
                ErrorMessage = errorMessage,
                ActivityPreData = preData,
                ActivityPostData = postData

            });
        }
    }
}
