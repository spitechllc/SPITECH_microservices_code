﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.UpdateResellerFee
{
    public class UpdateResellerFeeValidator : AbstractValidator<UpdateResellerFeeCommand>
    {
        public UpdateResellerFeeValidator()
        {
            RuleFor(h => h.ResellerFeeId).NotNull().GreaterThan(0).WithMessage("ResellerFeeId must be greater than 0");

            When(t => t.IsDefault, () =>
            {
                RuleFor(h => h.ResellerId).Null().WithMessage("ResellerId must be null");
            }).Otherwise(() =>
            {
                RuleFor(h => h.ResellerId).NotNull().GreaterThan(0).WithMessage("ResellerId must be greater than 0");
            });

            RuleFor(h => h.MinStoreRange).GreaterThanOrEqualTo(0);
            RuleFor(h => h.MaxStoreRange).GreaterThan(0);
            RuleFor(h => h.MinStoreRange).LessThan(t => t.MaxStoreRange);
            RuleFor(h => h.ACHTransactionFee).GreaterThanOrEqualTo(0);
            RuleFor(h => h.CardTransactionFee).GreaterThanOrEqualTo(0);
            RuleFor(h => h.CashRewardTransactionFee).GreaterThanOrEqualTo(0);
            RuleFor(h => h.ACHProcessingFee).GreaterThanOrEqualTo(0);
            RuleFor(h => h.MonthlySaasFee).GreaterThanOrEqualTo(0);
            RuleFor(h => h.CoreProcessingName).NotEmpty();
        }
    }
}
