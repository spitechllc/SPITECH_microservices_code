﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.UpdateStoreBillingUnPaid
{
    public class UpdateStoreBillingUnPaidCommand : IRequest<ResponseModel>
    {
        public int StoreBillingId { get; set; }
        public string Reason { get; set; }
    }
}
