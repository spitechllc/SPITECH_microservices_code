﻿using FluentValidation;
using System.Linq;

namespace SpiTech.Transaction.Application.Commands.UpdateStoreBillingUnPaid
{
    public class UpdateStoreBillingUnPaidValidator : AbstractValidator<UpdateStoreBillingUnPaidCommand>
    {
        public UpdateStoreBillingUnPaidValidator()
        {
            RuleFor(x => x.StoreBillingId).Cascade(CascadeMode.Stop)
                                                .GreaterThan(0)
                                                .WithMessage("StoreBillingId should be valid");
            RuleFor(x => x.Reason).Cascade(CascadeMode.Stop)
                                                .NotNull()
                                                .NotEmpty()
                                                .WithMessage("Reason should not be empty");
        }
    }
}
