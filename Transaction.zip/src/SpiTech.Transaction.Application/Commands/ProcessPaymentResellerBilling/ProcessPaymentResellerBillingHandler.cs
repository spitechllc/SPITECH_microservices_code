﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain;
using SpiTech.ApplicationCore.Domain.Configs;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using SpiTech.ApplicationCore.Nacha;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.Queries.GetNachaResellerBillingProcessingAccount;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.ProcessPaymentResellerBilling
{
    public class ProcessPaymentResellerBillingHandler : IRequestHandler<ProcessPaymentResellerBillingCommand, ResponseModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<ProcessPaymentResellerBillingHandler> logger;
        private readonly IMediator mediator;
        private readonly INachaFileBuilder nachaFileBuilder;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IStorageService storageService;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IPaymentServiceClient paymentService;
        private readonly SftpConfigs sftpConfigs;

        public ProcessPaymentResellerBillingHandler(IUnitOfWork context,
                                    ILogger<ProcessPaymentResellerBillingHandler> logger,
                                    IMediator mediator,
                                    INachaFileBuilder nachaFileBuilder,
                                    IStorageServiceFactory storageServiceFactory,
                                    IUserAuthenticationProvider userAuthenticationProvider,
                                    IEventDispatcher eventDispatcher,
                                    IPaymentServiceClient paymentService,
                                    SftpConfigs sftpConfigs)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            this.nachaFileBuilder = nachaFileBuilder;
            this.userAuthenticationProvider = userAuthenticationProvider;
            storageService = storageServiceFactory.Get(ContainerType.MonthlyResellerInvoiceNachaFile);
            _eventDispatcher = eventDispatcher;
            this.paymentService = paymentService;
            this.sftpConfigs = sftpConfigs;
        }

        public async Task<ResponseModel> Handle(ProcessPaymentResellerBillingCommand command, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), command);
            Domain.Entities.ResellerBillingPayment resellerBillingPayment = null;

            int uploadUserId = userAuthenticationProvider.GetUserAuthentication()?.UserId ?? 0;

            ResponseModel response = new();

            var nachaConfig = (await context.NachaConfigs.GetAll()).FirstOrDefault();

            if (nachaConfig == null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("NachaConfig", "Unable to get NachaConfigs"));
            }

            NachaProcessingModel nachaProcessingModel = await mediator.Send(new GetNachaResellerBillingProcessingAccountQuery
            {
                Year = command.Year,
                Month = command.Month,
            });

            if (nachaProcessingModel == null && nachaProcessingModel.ProcessingEntities != null)
            {
                response.Message = "No StoreBilling found for processing";
                return response;
            }

            try
            {
                var accounts = nachaProcessingModel.ProcessingEntities.SelectMany(t => t.Accounts).ToList();
                resellerBillingPayment = new Domain.Entities.ResellerBillingPayment
                {
                    BillGenerateBy = uploadUserId,
                    BillGenerateDate = DateTime.UtcNow,
                    AccountNo = nachaProcessingModel.Config.AccountNo,
                    Month = command.Month,
                    Year = command.Year,
                    Bank = nachaProcessingModel.Config.BankName,
                    AccountName = nachaProcessingModel.Config.BatchCompanyName,
                    RoutingNo = nachaProcessingModel.Config.RoutingNo,
                    IsChecking = true,
                    IsActive = true,
                    TotalAmount = accounts.Sum(t => t.Amount),
                    NachaFilePath = "",
                    CreatedBy = uploadUserId,
                    CreatedOn = DateTime.UtcNow,
                };

                int resellerBillingPaymentId = await context.ResellerBillingPayments.Add(resellerBillingPayment);

                //foreach (NachaModel nachaModel in accounts)
                //{
                //    await context.ResellerBillingPaymentDetails.Add(new Domain.Entities.ResellerBillingPaymentDetail
                //    {
                //        AccountNo = nachaModel.ProcessingAccount.AccountNo,
                //        RoutingNo = nachaModel.ProcessingAccount.RoutingNo,
                //        Amount = nachaModel.Amount,
                //        AccountName = nachaModel.ProcessingAccount.AccountName,
                //        IsChecking = nachaModel.ProcessingAccount.AccountType == AccountType.Checking,
                //        ResellerBillingPaymentId = resellerBillingPaymentId,
                //        IdentificationNumber = nachaModel.IdentificationNumber,
                //        ResellerBillingId = nachaModel.RequestId,
                //        IsActive = true,
                //        CreatedBy = uploadUserId,
                //        CreatedOn = DateTime.UtcNow,
                //    });
                //}

                NachaFileBytesModel nachaProcessFileBytesModel = nachaFileBuilder.GetBytes(nachaProcessingModel.Config, accounts);

                string nachaUploadError = "";
                bool isNachaUploaded = true;

                if (nachaProcessFileBytesModel != null)
                {
                    await storageService.UploadBlob(nachaProcessFileBytesModel.Bytes, nachaProcessFileBytesModel.File, "text/plain");
                    Blob blobProcess = await storageService.GetFile(nachaProcessFileBytesModel.File);

                    await context.ResellerBillingPayments.UpdateNachaFilePath(resellerBillingPaymentId,
                                                                                blobProcess.StorageUri,
                                                                                nachaProcessFileBytesModel.File,
                                                                                "",
                                                                                "",
                                                                                DomainConstant.SftpConfig.FNBO);

                    try
                    {
                        response.Success = await nachaFileBuilder.UploadFileInSftp(nachaProcessFileBytesModel, nachaConfig.IsProdEnabled, this.sftpConfigs.Get(DomainConstant.SftpConfig.FNBO));
                    }
                    catch (Exception ex)
                    {
                        nachaUploadError = ex.Message;
                        logger.Error(ex, command, nachaProcessFileBytesModel, nachaConfig);
                        response.Success = false;
                        isNachaUploaded = false;
                    }
                }
                else
                {
                    response.Success = true;
                }

                //await context.ResellerBillings.UpdatePaid(accounts.Select(t => t.RequestId).Distinct().ToArray(), uploadUserId, response.Success);

                await context.ResellerBillingPayments.UpdateNachaFileUploadStatus(resellerBillingPaymentId, isNachaUploaded, nachaUploadError, false, "");

                context.Commit();
            }
            catch (Exception ex)
            {
                logger.Error(ex, command);
                context.Rollback();
                response.Success = false;
            }

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
