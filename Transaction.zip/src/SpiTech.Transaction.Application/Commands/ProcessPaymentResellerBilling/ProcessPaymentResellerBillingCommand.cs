﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.ProcessPaymentResellerBilling
{
    public class ProcessPaymentResellerBillingCommand : IRequest<ResponseModel>
    {
        public int Month { get; set; }
        public int Year { get; set; }
    }
}
