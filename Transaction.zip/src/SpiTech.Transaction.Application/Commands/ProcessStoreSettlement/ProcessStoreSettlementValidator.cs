﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Commands.ProcessStoreSettlement
{
    public class ProcessStoreSettlementValidator : AbstractValidator<ProcessStoreSettlementCommand>
    {
        public ProcessStoreSettlementValidator()
        {
            //RuleFor(x => x.SettlementRequestId).GreaterThan(0);
        }
    }
}
