﻿using AutoMapper;
using ChoETL;
using MediatR;
using Microsoft.VisualBasic;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain;
using SpiTech.ApplicationCore.Domain.Configs;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.ApplicationCore.Nacha;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.Queries.GetNachaEodProcessingAccount;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.ProcessStoreSettlement
{
    public class ProcessStoreSettlementHandler : IRequestHandler<ProcessStoreSettlementCommand, ResponseModel<NachaProcessingModel>>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<ProcessStoreSettlementHandler> logger;
        private readonly IMediator mediator;
        private readonly INachaFileBuilder nachaFileBuilder;
        private readonly IUserAuthenticationProvider authenticationProvider;
        private readonly IStorageService storageService;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IPaymentServiceClient paymentService;
        private readonly IMapper mapper;
        private readonly SftpConfigs sftpConfigs;
        private bool CheckTransaction;
        private bool CheckConsumerPay;
        public ProcessStoreSettlementHandler(IUnitOfWork context,
                                            ILogger<ProcessStoreSettlementHandler> logger,
                                            IMediator mediator,
                                            INachaFileBuilder nachaFileBuilder,
                                            IStorageServiceFactory storageServiceFactory,
                                            IUserAuthenticationProvider authenticationProvider,
                                            IEventDispatcher eventDispatcher,
                                            IPaymentServiceClient paymentService,
                                            IMapper mapper,
                                            SftpConfigs sftpConfigs)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            this.nachaFileBuilder = nachaFileBuilder;
            this.authenticationProvider = authenticationProvider;
            this.storageService = storageServiceFactory.Get(ContainerType.EodSettlementNachaFile);
            this.eventDispatcher = eventDispatcher;
            this.paymentService = paymentService;
            this.mapper = mapper;
            this.sftpConfigs = sftpConfigs;
        }

        public async Task<ResponseModel<NachaProcessingModel>> Handle(ProcessStoreSettlementCommand command, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel<NachaProcessingModel> response = new() { };
            int uploadUserId = 0;
            Domain.Entities.SettlementPayment settlementPayment = null;
            NachaProcessingModel nachaProcessingModel = null;
            logger.Warn($"EOD Settlement Ram 1");
            try
            {
                uploadUserId = authenticationProvider.GetUserAuthentication()?.UserId ?? 0;

                var nachaConfig = (await context.NachaConfigs.GetAll()).FirstOrDefault();

                if (nachaConfig == null)
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("NachaConfig", "Unable to get NachaConfigs"));
                }

                nachaProcessingModel = await mediator.Send(new GetNachaEodProcessingAccountQuery
                {
                    BusinessDate = command.BusinessDate,
                    CardPayment = command.CardPayment,
                    AchPayment = command.AchPayment,
                    CashRewardPayment = command.CashRewardPayment,
                    IsPreview = false,
                    EffectiveDate = command.EffectiveDate,
                    SettlementRequest= command.settlementRequest
                });

                if (nachaProcessingModel == null ||
                    nachaProcessingModel.ProcessingEntities == null ||
                    !nachaProcessingModel.ProcessingEntities.Any())
                {
                    response.Message = "No settlement found for process";
                    return response;
                }

                logger.Warn($"EOD Settlement Ram 10");


                response.Data = nachaProcessingModel;

                var paymentProcessingAccount = nachaProcessingModel.Config;

                var accounts = nachaProcessingModel.ProcessingEntities.SelectMany(x => x.Accounts).ToList();

                settlementPayment = new Domain.Entities.SettlementPayment
                {
                    BusinessDate = command.BusinessDate,
                    IdentificationNumber = nachaProcessingModel.IdentificationNumber,
                    AccountNo = paymentProcessingAccount.AccountNo,
                    Bank = paymentProcessingAccount.BankName,
                    AccountName = paymentProcessingAccount.BatchCompanyName,
                    RoutingNo = paymentProcessingAccount.RoutingNo,
                    IsChecking = true,
                    IsActive = true,
                    TotalAmount = accounts.Sum(t => t.Amount),
                    TotalCardAmount = accounts.Where(t => t.AmountType == AmountType.CreditDebit).Sum(t => t.Amount),
                    TotalRewardAmount = accounts.Where(t => t.AmountType == AmountType.CashReward).Sum(t => t.Amount),
                    TotalAchAmount = accounts.Where(t => t.AmountType == AmountType.ACH).Sum(t => t.Amount),
                    NachaFilePath = "",
                    CreatedBy = uploadUserId
                };

                int settlementPaymentId = await context.SettlementPayments.Add(settlementPayment);

                foreach (var processingEntity in nachaProcessingModel.ProcessingEntities)
                {
                    if (processingEntity != null)
                    {
                        foreach (var nachaModel in processingEntity.Accounts)
                        {
                            settlementPayment.SettlementPaymentDetails.Add(new Domain.Entities.SettlementPaymentDetail
                            {
                                AccountNo = nachaModel.ProcessingAccount.AccountNo,
                                RoutingNo = nachaModel.ProcessingAccount.RoutingNo,
                                Amount = nachaModel.Amount,
                                AmountTypeId = (int)nachaModel.AmountType,
                                AccountName = nachaModel.ProcessingAccount.AccountName,
                                IsChecking = nachaModel.ProcessingAccount.AccountType == AccountType.Checking,
                                StoreId = processingEntity.GetEntity<EodSettlementModel>().StoreId,
                                SettlementPaymentId = settlementPaymentId,
                                IdentificationNumber = nachaModel.IdentificationNumber,
                                SettlementRequestId = processingEntity.GetEntity<EodSettlementModel>().SettlementRequestId,
                                TransactionId = (long)nachaModel.AccountEntityId,
                                IsActive = true,
                                CreatedBy = uploadUserId,
                            });
                        }
                    }
                }

                logger.Warn($"EOD Settlement Ram 11");


                foreach (var settlementPaymentDetail in settlementPayment.SettlementPaymentDetails)
                {
                    await context.SettlementPaymentDetails.Add(settlementPaymentDetail);
                }

                NachaFileBytesModel nachaProcessFileBytesModel = null;

                if (accounts != null && accounts.Any())
                {
                    nachaProcessFileBytesModel = nachaFileBuilder.GetBytes(nachaProcessingModel.Config, accounts);
                }

                string nachaUploadError = "";
                bool isNachaUploaded = false;

                if (nachaProcessFileBytesModel != null)
                {
                    Blob blobProcess = null;
                    Blob blobOffset = null;

                    if (nachaProcessFileBytesModel != null)
                    {
                        logger.Warn($"EOD Settlement Ram 12 upload blob");

                        await storageService.UploadBlob(nachaProcessFileBytesModel.Bytes, nachaProcessFileBytesModel.File, "text/plain");
                        blobProcess = await storageService.GetFile(nachaProcessFileBytesModel.File);
                    }

                    await context.SettlementPayments.UpdateNachaFilePath(settlementPaymentId,
                                                                        (blobProcess?.StorageUri ?? ""),
                                                                        (nachaProcessFileBytesModel?.File ?? ""),
                                                                        (blobOffset?.StorageUri ?? ""),
                                                                        "",
                                                                        DomainConstant.SftpConfig.FNBO);

                    if (nachaProcessFileBytesModel != null)
                    {
                        try
                        {
                            isNachaUploaded = await nachaFileBuilder.UploadFileInSftp(nachaProcessFileBytesModel, nachaConfig.IsProdEnabled, this.sftpConfigs.Get(DomainConstant.SftpConfig.FNBO));
                        }
                        catch (Exception ex)
                        {
                            nachaUploadError = ex.Message;
                            logger.Error(ex, command, nachaProcessFileBytesModel, nachaConfig);
                            response.Success = false;
                            isNachaUploaded = false;
                        }
                    }

                    response.Success = isNachaUploaded;
                }
                else
                {
                    response.Success = true;
                }

                var zeroSettlements = nachaProcessingModel.ProcessingEntities.Where(t => t.Accounts == null || t.Accounts.Count() == 0);

                if (zeroSettlements.Any())
                {
                    foreach (var item in command.settlementRequest)
                    {
                        await context.Transactions.UpdateTranProcessSettlementStatus(item.TransactionId, (int)command.AchPayment, (int)command.CardPayment, (int)command.CashRewardPayment, item.MerchantProcess, item.ConsumerProcess, item.MerchantProcess == true ? 1 : 0, item.ConsumerProcess == true ? 1 : 0);
                    }
                    await context.SettlementRequests.UpdatePaymentStatus(
                                    zeroSettlements.Select(t => t.GetEntity<EodSettlementModel>().SettlementRequestId).ToArray(),
                                    command.CardPayment == PaymentStatusEnum.Paid || command.CardPayment == PaymentStatusEnum.MarkAsPaid ? PaymentStatusEnum.MarkAsPaid : null,
                                    command.CashRewardPayment == PaymentStatusEnum.Paid || command.CashRewardPayment == PaymentStatusEnum.MarkAsPaid ? PaymentStatusEnum.MarkAsPaid : null,
                                    command.AchPayment == PaymentStatusEnum.Paid || command.AchPayment == PaymentStatusEnum.MarkAsPaid ? PaymentStatusEnum.MarkAsPaid : null,
                                    null,
                                    null,
                                    uploadUserId);
                }

                var actualSettlements = nachaProcessingModel.ProcessingEntities.Where(t => t.Accounts != null && t.Accounts.Count() > 0);

                if (actualSettlements.Any())
                {
                    if (response.Success)
                    {
                        logger.Warn($"EOD Settlement Ram 12");
                        foreach (var item in command.settlementRequest)
                        {
                            List<TransactionModel> result = mapper.Map<List<TransactionModel>>(await context.Transactions.GetTransactionByfilter(item.TransactionId, 0, ""));
                            if (result.Count > 0)
                            {
                                var PaymentMethod = result[0].PaymentMethodId;
                                decimal walletAmount = result[0].WalletAmount;
                                if (PaymentMethod == 2)
                                {
                                    command.CardPayment = PaymentStatusEnum.NotPaid;
                                    command.AchPayment = PaymentStatusEnum.Paid;
                                    if (walletAmount == Convert.ToDecimal(0.0))
                                    {
                                        command.CashRewardPayment = PaymentStatusEnum.NotPaid;
                                    }
                                }
                                else
                                {
                                    command.CardPayment = PaymentStatusEnum.Paid;
                                    command.AchPayment = PaymentStatusEnum.NotPaid;
                                    if (walletAmount == Convert.ToDecimal(0.0))
                                    {
                                        command.CashRewardPayment = PaymentStatusEnum.NotPaid;
                                    }
                                }
                            }
                            if (item.ConsumerProcess != false && item.MerchantProcess != false)
                            {
                                await context.Transactions.UpdateTranProcessSettlementStatus(item.TransactionId, (int)command.AchPayment, (int)command.CardPayment, (int)command.CashRewardPayment, item.MerchantProcess, item.ConsumerProcess, item.ConsumerProcess == true ? 1 : 0, item.MerchantProcess == true ? 1 : 0);
                            }
                            else if (item.MerchantProcess == true && item.ConsumerProcess == false)
                            {
                                await context.Transactions.UpdateTranProcessSettlementStatus(item.TransactionId, (int)command.AchPayment, (int)command.CardPayment, (int)command.CashRewardPayment, item.MerchantProcess, item.ConsumerProcess, item.ConsumerProcess == true ? 1 : 0, item.MerchantProcess == true ? 1 : 0);
                            }
                        }

                        foreach (var item in command.settlementRequest)
                        {
                            var transactionsDetail = await context.Transactions.GetEodTransactions(item.SettlementRequestId);
                            foreach (var itemTranCheckStatus in transactionsDetail)
                            {
                                if (itemTranCheckStatus.ConsumerPay == true 
                                    && itemTranCheckStatus.MerchantPay == true)
                                {
                                    CheckTransaction = true;
                                    command.AchPayment = PaymentStatusEnum.Paid ;
                                    command.CardPayment = PaymentStatusEnum.Paid;
                                }
                                else if (itemTranCheckStatus.ConsumerPay == true
                                    && itemTranCheckStatus.MerchantPay == false)
                                {
                                    CheckTransaction = true;
                                    command.AchPayment = PaymentStatusEnum.Paid;
                                }
                                else if (itemTranCheckStatus.ConsumerPay == false
                                    && itemTranCheckStatus.MerchantPay == true)
                                {
                                    CheckTransaction = true;
                                    command.CardPayment = PaymentStatusEnum.Paid;
                                }
                                else {
                                    CheckTransaction = false;
                                    CheckConsumerPay = false;
                                    break;
                                }
                            }
                        }

                        if (CheckTransaction == true)
                        {
                            await context.SettlementRequests.UpdatePaymentStatus(
                                        actualSettlements.Select(t => t.GetEntity<EodSettlementModel>().SettlementRequestId).ToArray(),
                                        command.CardPayment == PaymentStatusEnum.Paid ? PaymentStatusEnum.Paid : command.CardPayment == PaymentStatusEnum.MarkAsPaid ? PaymentStatusEnum.MarkAsPaid : null,
                                        command.CashRewardPayment == PaymentStatusEnum.Paid ? PaymentStatusEnum.Paid : command.CashRewardPayment == PaymentStatusEnum.MarkAsPaid ? PaymentStatusEnum.MarkAsPaid : null,
command.AchPayment == PaymentStatusEnum.Paid ? PaymentStatusEnum.Paid : command.AchPayment == PaymentStatusEnum.MarkAsPaid ? PaymentStatusEnum.MarkAsPaid : null,
                                        null,
                                        null,
                                        uploadUserId);
                        }
                    }
                    else
                    {
                        await context.SettlementRequests.UpdatePaymentStatus(
                                            actualSettlements.Select(t => t.GetEntity<EodSettlementModel>().SettlementRequestId).ToArray(),
                                            null,
                                            null,
                                            null,
                                            DomainConstant.ProcessStatus.Error,
                                            nachaUploadError,
                                            uploadUserId);

                    }
                }

                await context.SettlementPayments.UpdateNachaFileUploadStatus(settlementPaymentId, isNachaUploaded, nachaUploadError, false, "");                

                context.Commit();
            }
            catch (Exception ex)
            {
                logger.Error(ex, command);
                context.Rollback();
                response.Success = false;
                response.Message = ex.Message;

                if (nachaProcessingModel != null && nachaProcessingModel.ProcessingEntities != null)
                {
                    await context.SettlementRequests.UpdateProcessStatus(
                                    nachaProcessingModel.ProcessingEntities.Select(t => t.GetEntity<EodSettlementModel>().SettlementRequestId).ToArray(),
                                    DomainConstant.ProcessStatus.Error,
                                    ex.Message);
                }
                context.Commit();
            }


            try
            {
                if (response.Success)
                {
                    if (nachaProcessingModel != null && nachaProcessingModel.ProcessingEntities != null)
                    {
                        settlementPayment = await context.SettlementPayments.Get(settlementPayment.SettlementPaymentId);

                        if (settlementPayment.TotalAmount > 0)
                        {
                            settlementPayment.AccountNo = settlementPayment.AccountNo.Mask(4);
                            await eventDispatcher.Dispatch(new StoreEodSettlementInvoiceAdminEvent
                            {
                                SettlementPayment = mapper.Map<SettlementPaymentModel>(settlementPayment)
                            });
                        }

                        foreach (var processingEntity in nachaProcessingModel.ProcessingEntities)
                        {
                            if (processingEntity != null && processingEntity.Accounts != null && processingEntity.Accounts.Any())
                            {
                                var storeEodSettlementInvoiceEvent = new StoreEodSettlementInvoiceEvent
                                {
                                    StoreId = processingEntity.GetEntity<EodSettlementModel>().StoreId,
                                    AccountNo = settlementPayment.AccountNo.Mask(4),
                                    TotalAmount = settlementPayment.TotalAmount,
                                    TotalCardAmount = settlementPayment.TotalCardAmount,
                                    TotalRewardAmount = settlementPayment.TotalRewardAmount,
                                    TotalAchAmount=settlementPayment.TotalAchAmount,
                                    IdentificationNumber = settlementPayment.IdentificationNumber,
                                    BusinessDate = settlementPayment.BusinessDate,
                                    FilePath = settlementPayment.NachaFilePath,
                                    FileName = settlementPayment.NachaFileName
                                };

                                if (storeEodSettlementInvoiceEvent.TotalAmount > 0)
                                {
                                    await eventDispatcher.Dispatch(storeEodSettlementInvoiceEvent);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex, command, settlementPayment, settlementPayment);
                response.Message = ex.Message;
            }

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
