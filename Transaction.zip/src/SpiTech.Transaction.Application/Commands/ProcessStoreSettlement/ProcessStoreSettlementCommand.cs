﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.Transaction.Domain.Enums;
using System;
using System.Collections.Generic;

namespace SpiTech.Transaction.Application.Commands.ProcessStoreSettlement
{
    public class ProcessStoreSettlementCommand : IRequest<ResponseModel<NachaProcessingModel>>
    {
        public DateTime BusinessDate { get; set; }
        public PaymentStatusEnum CardPayment { get; set; }
        public PaymentStatusEnum CashRewardPayment { get; set; }
        public PaymentStatusEnum AchPayment { get; set; }
        public DateTime? EffectiveDate { get; set; }

        public List<SettlementRequest> settlementRequest { get; set; }

        
    }

    public class SettlementRequest
    {
        public int SettlementRequestId { get; set; }
        public string MerchantId { get; set; }
        public int ConsumerId { get; set; }
        public int TransactionId { get; set; }
        public bool MerchantProcess { get; set; }
        public bool ConsumerProcess { get; set; }
    }
}
