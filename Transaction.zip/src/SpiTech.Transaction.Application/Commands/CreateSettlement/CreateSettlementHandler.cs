﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Transaction.Application.Commands.UpdateGetSite;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Commands.CreateSettlement
{
    public class CreateSettlementHandler : IRequestHandler<CreateSettlementCommand, bool>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateSettlementHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IMediator _mediator;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IEventDispatcher _eventDispatcher;

        public CreateSettlementHandler(IUnitOfWork context,
                                        ILogger<CreateSettlementHandler> logger,
                                        IMapper mapper,
                                        IMediator mediator, IUserAuthenticationProvider userAuthenticationProvider, IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _mediator = mediator;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _eventDispatcher = eventDispatcher;
        }

        public async Task<bool> Handle(CreateSettlementCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            try
            {
                var siteData = await _mediator.Send(new UpdateGetSiteCommand { SiteId = command.SettlementInfo.SiteId, StoreId = command.SettlementInfo.StoreId });

                if (siteData == null)
                {
                    var site = new Domain.Entities.Site
                    {
                        SiteId = command.SettlementInfo.SiteId,
                        StoreId = command.SettlementInfo.StoreId,
                        StoreName = command.SettlementInfo.StoreName
                    };

                    await _context.Sites.Add(site);
                }

                SettlementRequest settlementRequest = _mapper.Map<SettlementRequest>(command.SettlementInfo);

                var dbSettlementRequest = await _context.SettlementRequests.Get(settlementRequest.SettlementRequestId);

                _logger.Warn($"Settlement Requests Ram 1");

                if (dbSettlementRequest == null)
                {
                    _logger.Warn($"Settlement Requests Ram 2");
                    await _context.SettlementRequests.Add(settlementRequest);

                    foreach (SettlementDetail settlementDetail in settlementRequest.SettlementDetails)
                    {
                        await _context.SettlementDetails.Add(settlementDetail);
                    }
                    _logger.Warn($"Settlement Requests Ram 3");
                }
                else
                {
                    await _context.SettlementRequests.Update(settlementRequest);

                    foreach (SettlementDetail settlementDetail in settlementRequest.SettlementDetails)
                    {
                        await _context.SettlementDetails.Update(settlementDetail);
                    }
                }                

                _context.Commit();
            }
            catch (Exception ex)
            {
                _logger.Error(ex, command);
                _context.Rollback();
                throw;
            }

            _logger.TraceExitMethod(nameof(Handle), true);
            return true;
        }
    }
}
