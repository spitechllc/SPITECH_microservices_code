﻿using MediatR;
using SpiTech.EventBus.DomainEvents.Models.Mppa;

namespace SpiTech.Transaction.Application.Commands.CreateSettlement
{
    public class CreateSettlementCommand : IRequest<bool>
    {
        public SettlementRequest SettlementInfo { get; set; }
    }
}
