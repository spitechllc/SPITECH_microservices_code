﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Application.Commands.UpdateEodNeedReview
{
    public class UpdateEodNeedReviewCommand : IRequest<ResponseModel>
    {
        public int[] SettlementRequestIds { get; set; }
        public bool IsNeedReview { get; set; }
    }
}
