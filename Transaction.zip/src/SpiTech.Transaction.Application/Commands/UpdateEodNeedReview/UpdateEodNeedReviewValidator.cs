﻿using FluentValidation;
using System.Linq;

namespace SpiTech.Transaction.Application.Commands.UpdateEodNeedReview
{
    public class UpdateEodNeedReviewValidator : AbstractValidator<UpdateEodNeedReviewCommand>
    {
        public UpdateEodNeedReviewValidator()
        {
            RuleFor(x => x.SettlementRequestIds).Cascade(CascadeMode.Stop)
                                                .NotNull()
                                                .NotEmpty()
                                                .Must(NotEqualZero)
                                                .WithMessage("SettlementRequestId should be valid");
        }

        private bool NotEqualZero(int[] settlementRequestIds)
        {
            return settlementRequestIds?.All(i => i > 0) ?? false;
        }
    }
}
