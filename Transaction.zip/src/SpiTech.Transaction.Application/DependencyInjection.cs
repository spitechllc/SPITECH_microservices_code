﻿using FluentValidation;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.ApplicationCore.Nacha;
using SpiTech.ApplicationCore.ServiceCollection;
using SpiTech.ApplicationCore.Services;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.EventBus.DomainEvents.Events.Store;
using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.EventBus.DomainEvents.ServiceCollection;
using SpiTech.Transaction.Application.EventConsumers;
using SpiTech.Transaction.Application.Services;
using SpiTech.Transaction.Application.Services.Backgrounds;
using SpiTech.Transaction.Application.Services.Interface;
using SpiTech.Transaction.Domain.Mappers;
using System.Reflection;
using WkHtmlToPdfDotNet.Contracts;

namespace SpiTech.Transaction.Application
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSingleton(typeof(IConverter), new WkHtmlToPdfDotNet.SynchronizedConverter(new WkHtmlToPdfDotNet.PdfTools()));
            services.AddSftpService(configuration);
            services.AddFnboService(configuration);

            services.AddScoped<INachaFileBuilder, NachaFileBuilder>();
            services.AddTransient<IHtmlPdfConverterService, HtmlPdfConverterService>();
            services.AddTransient<IPlaidService, PlaidService>();

            services
                .AddMediatR(Assembly.GetExecutingAssembly()).AddAutoMapper(typeof(PaymentInfoProfile))
                .AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());

            services.AddHostedService<StoreEodBackgroundService>();
            services.AddHostedService<StoreMonthlyInvoiceBackgroundService>();
            services.AddHostedService<SaleAgentMonthlyInvoiceBackgroundService>();
            services.AddHostedService<ResellerMonthlyInvoiceBackgroundService>();
            services.AddHostedService<ProcessAchNachaReturnFileService>();

            services.AddTransient<IPlaidService, PlaidService>();

            // MassTransit-RabbitMQ Configuration
            services.RegisterMessageQueue(configuration, config =>
            {
                config.AddConsumer<StacCaptureRequestEventConsumer>();
                config.AddConsumer<TransactionUpdateEventConsumer>();
                config.AddConsumer<AuthMppaRequestEventConsumer>();
                config.AddConsumer<FinalizeRequestEventConsumer>();
                config.AddConsumer<PumpReserveRequestEventConsumer>();
                config.AddConsumer<ReceiptDataRequestEventConsumer>();
                config.AddConsumer<PaymentStatusEventConsumer>();
                config.AddConsumer<TransactionSettlementEventConsumer>();
                config.AddConsumer<ReconcileFailTransactionEventConsumer>();
                config.AddConsumer<StoreEventConsumer>();
                config.AddConsumer<SiteEventConsumer>();
            }, (ctx, cfg) =>
            {
                cfg.ConfigurePublishEvent<ResellerMonthlyBillingInvoiceEvent>();
                cfg.ConfigurePublishEvent<SaleAgentMonthlyBillingInvoiceEvent>();
                cfg.ConfigurePublishEvent<StoreEodSettlementInvoiceEvent>();
                cfg.ConfigurePublishEvent<StoreEodSettlementInvoiceAdminEvent>();
                cfg.ConfigurePublishEvent<TransactionEvent>();
                cfg.ConfigurePublishEvent<StoreEodSettlementEvent>();
                cfg.ConfigurePublishEvent<StoreMonthlyBillingInvoiceEvent>();
                cfg.ConfigurePublishEvent<UserActivityLogEvent>();
                cfg.ConfigurePublishEvent<AchNachaReturnFileEvent>();

                cfg.BindConsumer<StacCaptureRequestEvent, StacCaptureRequestEventConsumer>(ctx, EventBusConstants.TransactionService);
                cfg.BindConsumer<TransactionUpdateEvent, TransactionUpdateEventConsumer>(ctx, EventBusConstants.TransactionService);
                cfg.BindConsumer<AuthMppaRequestEvent, AuthMppaRequestEventConsumer>(ctx, EventBusConstants.TransactionService);
                cfg.BindConsumer<FinalizeRequestEvent, FinalizeRequestEventConsumer>(ctx, EventBusConstants.TransactionService);
                cfg.BindConsumer<PumpReserveRequestEvent, PumpReserveRequestEventConsumer>(ctx, EventBusConstants.TransactionService);
                cfg.BindConsumer<ReceiptDataRequestEvent, ReceiptDataRequestEventConsumer>(ctx, EventBusConstants.TransactionService);
                cfg.BindConsumer<PaymentStatusEvent, PaymentStatusEventConsumer>(ctx, EventBusConstants.TransactionService);
                cfg.BindConsumer<TransactionSettlementEvent, TransactionSettlementEventConsumer>(ctx, EventBusConstants.TransactionService);
                cfg.BindConsumer<ReconcileFailTransactionEvent, ReconcileFailTransactionEventConsumer>(ctx, EventBusConstants.TransactionService);
                cfg.BindConsumer<StoreEvent, StoreEventConsumer>(ctx, EventBusConstants.TransactionService);
                cfg.BindConsumer<SiteEvent, SiteEventConsumer>(ctx, EventBusConstants.TransactionService);
            });
            return services;
        }
    }
}