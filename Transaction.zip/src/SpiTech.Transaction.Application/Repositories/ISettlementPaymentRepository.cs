﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Transaction.Domain.Entities;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface ISettlementPaymentRepository : IRepository<SettlementPayment>
    {
        Task<StoreBillingPayment> GetSettlementPayment(int settlementRequestId);
        Task<bool> UpdateNachaFilePath(int settlementPaymentId,
           string nachaFilePath,
           string nachaFileName,
           string offsetNachaFilePath,
           string offsetNachaFileName,
           string sftpConfig);

        Task<bool> UpdateNachaFileUploadStatus(int settlementPaymentId,
            bool isNachaUploaded,
            string nachaUploadError,
            bool isOffsetNachaUploaded,
            string offsetNachaUploadError);
    }
}
