﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Transaction.Domain.Entities;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface ISettlementDetailRepository : IRepository<SettlementDetail>
    {
    }
}
