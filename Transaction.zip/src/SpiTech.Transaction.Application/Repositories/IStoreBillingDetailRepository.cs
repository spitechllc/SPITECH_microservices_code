﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Transaction.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface IStoreBillingDetailRepository : IRepository<StoreBillingDetail>
    {
        Task<IEnumerable<StoreBillingDetail>> GetStoreBillingDetails(int storeBillingId);
        Task<bool> InactiveUnpaid(int month, int year);
    }
}
