﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Transaction.Domain.Entities;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface IResellerBillingRepository : IRepository<ResellerBilling>
    {
        Task<ResellerBillingAggregateModel> GeAggregatetBills(int month, int year, bool? isNeedReview, bool? isPaid);
        Task<List<ResellerBillingModel>> GetBills(int? ResellerBillingId);
        Task<List<ResellerBillingModel>> GetBills(int pageIndex, int pageSize, int month, int year, bool? isNeedReview, bool? isPaid, ResellerBillingSortBy? sortBy, SortOrderEnum? sortOrder);
        Task<List<ResellerBilling>> GetUnBilledForReseller(int month, int year);
        Task<List<ResellerBilling>> GetUnPaidBills(int month, int year);
        Task<List<ResellerBillingModel>> GetUnprocessedMontlyInvoiceBatch();
        Task<bool> UpdateInvoiceNumber(int ResellerBillingId, string invoiceNumber);
        Task<bool> UpdateInvoicePdfFilePath(int ResellerBillingId, string filename, string invoiceFilePath);
        Task<bool> UpdateNeedReview(int[] ResellerBillingIds, bool isNeedReview, int requestedBy);
        Task<bool> UpdatePaid(int[] resellerBillingIds, int requestedBy, bool isPaid);
        Task<bool> UpdateProcessStatus(int ResellerBillingId, string status);
    }
}
