﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Transaction.Domain.Entities;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface IStoreBillingFeeRepository : IRepository<StoreBillingFee>
    {
        Task<List<StoreBillingFeeModel>> GetByStoreId(int storeId);
        Task<List<StoreBillingFeeModel>> GetDefaultFees(bool? onlyActive = null);
        Task<List<StoreBillingFeeModel>> GetByStoreIds(List<int> storeIds);
    }
}
