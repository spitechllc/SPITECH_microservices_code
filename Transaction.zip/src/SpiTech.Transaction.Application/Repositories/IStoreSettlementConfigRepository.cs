﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Transaction.Domain.Entities;
using SpiTech.Transaction.Domain.Models;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface IStoreSettlementConfigRepository : IRepository<StoreSettlementConfig>
    {
        Task<StoreSettlementConfigModel> GetByStoreId(int storeId);
        Task<StoreSettlementConfigModel> GetDefault();
    }
}
