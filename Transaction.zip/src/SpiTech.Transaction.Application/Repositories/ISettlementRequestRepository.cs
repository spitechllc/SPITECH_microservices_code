﻿using GreenPipes.Filters;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Transaction.Domain.Entities;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface ISettlementRequestRepository : IRepository<SettlementRequest>
    {
        Task<IEnumerable<SettlementRequest>> GetByFilter(string siteId, DateTime start, DateTime end);
        Task<List<EODDetails>> GetEODDetailsBySiteId(string siteId, DateTime startDate, DateTime endDate);
        Task<List<CreditCardDetails>> GetEODCardTransactionDetailsBySiteId(string siteId, 
            DateTime startDate, 
            DateTime endDate);

        Task<bool> UpdateProcessStatus(int[] settlementRequestIds,
                                                    string processStatus,
                                                    string error);

        Task<bool> UpdatePaymentStatus(int[] settlementRequestIds,
                                    PaymentStatusEnum? cardPaymentStatus,
                                    PaymentStatusEnum? cashRewardPaymentStatus,
                                    PaymentStatusEnum? achPaymentStatus,
                                    string processStatus,
                                    string error,
                                    int requestedBy);
        Task<bool> UpdateNeedReview(int[] settlementRequestIds, bool isNeedReview, int requestedBy);
        Task<EodSettlementAggregateModel> GetEodSettlementAggregateByFilter(
                                                                            DateTime businessDate,
                                                                            int? storeId,
                                                                            bool? isNeedReview,
                                                                            bool? hasTransaction,
                                                                            PaymentStatusEnum? cardPayment,
                                                                            PaymentStatusEnum? cashRewardPayment,
                                                                            PaymentStatusEnum? achPayment,
                                                                            bool? amountMatched);        
             Task<IEnumerable<EodSettlementModel>> GetByFilterEODSettment(
                                                        DateTime businessDate,
                                                        int? storeId,
                                                        bool? isNeedReview,
                                                        PaymentStatusEnum? cardPayment,
                                                        PaymentStatusEnum? cashRewardPayment,
                                                        PaymentStatusEnum? achPayment,
                                                        bool? amountMatched,
                                                        bool? hasTransaction,
                                                        int? pageIndex,
                                                        int? pageSize,
                                                        EodSettlementSortBy? sortBy,
                                                        SortOrderEnum? sortOrder);

        Task<IEnumerable<EodSettlementModel>> GetByFilter(
                                                        DateTime businessDate,
                                                        int? storeId,
                                                        bool? isNeedReview,
                                                        PaymentStatusEnum? cardPayment,
                                                        PaymentStatusEnum? cashRewardPayment,
                                                        PaymentStatusEnum? achPayment,
                                                        bool? amountMatched,
                                                        bool? hasTransaction,
                                                        int? pageIndex,
                                                        int? pageSize,
                                                        EodSettlementSortBy? sortBy,
                                                        SortOrderEnum? sortOrder);

        Task<List<StoreEodSettlementModel>> GetUnPorcessedStoreEodSettlements();
        Task<StoreEodSettlementModel> GetStoreEodSettlement(int settlementRequestId);
        Task<bool> UpdateInvoicePdfFilePath(int settlementRequestId, string settlementFileName, string settlementFilePath);

        Task<List<EodSettlementReportModel>> GetEODReport(int pageIndex, 
                                                            int pageSize, 
                                                            int? storeId, 
                                                            DateTime startDateUtc, 
                                                            DateTime endDateUtc,
                                                            PaymentStatusEnum? cardPayment,
                                                            PaymentStatusEnum? cashRewardPayment,
                                                            PaymentStatusEnum? achPayment,
                                                            bool? hasTransaction, 
                                                            bool? isAmountMached, 
                                                            EodReportSortBy? sortBy, 
                                                            SortOrderEnum? sortOrder);

        Task<EodSettlementReportAggregateModel> GetAggregatetEODReport(int? storeId, 
                                                                        DateTime startDateUtc, 
                                                                        DateTime endDateUtc,
                                                                        PaymentStatusEnum? cardPayment,
                                                                        PaymentStatusEnum? cashRewardPayment,
                                                                        PaymentStatusEnum? achPayment,
                                                                        bool? hasTransaction, 
                                                                        bool? isAmountMached);

        Task<List<TransactionReconcileModel>> GetTransactionReconcileReport(
                                                                            int pageIndex, 
                                                                            int pageSize, 
                                                                            int? storeId, 
                                                                            DateTime startDateUtc, 
                                                                            DateTime endDateUtc,
                                                                            PaymentStatusEnum? cardPayment,
                                                                            PaymentStatusEnum? cashRewardPayment,
                                                                            PaymentStatusEnum? achPayment,
                                                                            TransactionReconcileSortBy? sortBy, 
                                                                            SortOrderEnum? sortOrder);

        Task<TransactionReconcileAggregateModel> GetAggregatetTransactionReconcileReport(int? storeId, 
                                                                                        DateTime startDateUtc, 
                                                                                        DateTime endDateUtc,
                                                                                        PaymentStatusEnum? cardPayment,
                                                                                        PaymentStatusEnum? cashRewardPayment,
                                                                                        PaymentStatusEnum? achPayment);
    }
}
