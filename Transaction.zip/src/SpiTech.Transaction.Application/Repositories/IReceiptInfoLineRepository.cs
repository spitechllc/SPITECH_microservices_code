﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.EventBus.DomainEvents.Models.Mppa.Receipts;
using SpiTech.Transaction.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface IReceiptInfoLineRepository : IRepository<ReceiptInfoLine>
    {
        Task<List<ReceiptInfoLine>> GetReceiptInfoLineByfilter(long transactionId, string utmi);
        Task<TransactionReceiptModel> GetReceiptInfo(long transactionId);
    }
}
