﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Transaction.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface ISaleAgentFeeRepository : IRepository<SaleAgentFee>
    {
        Task<SaleAgentFee> GetDefaultSaleAgentFees();
        Task<SaleAgentFee> GetByStoreId(int storeId, int saleAgentId);
        Task<List<SaleAgentFee>> GetByStoreId(int storeId);
        Task<List<SaleAgentFee>> GetByStoreIds(List<int> storeIds);
    }
}
