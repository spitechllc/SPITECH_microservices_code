﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Transaction.Domain.Entities;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface IFnboReturnTransactionRepository : IRepository<FnboReturnTransaction>
    {
        Task<List<NachaDailyReturnReportModel>> DailyNachaReturnReport(int? pageIndex,
            int? pageSize, DateTime fromDate,DateTime toDate, NachaReturnSortBy? SortBy, SortOrderEnum? SortOrder);

        Task<List<ACHReturnReportModel>> ACHReturnReport(DateTime fromdate,DateTime toDate, int? pageIndex,
            int? pageSize, ACHReturnSortBy? sortBy, SortOrderEnum? sortOrder);
    }
}
