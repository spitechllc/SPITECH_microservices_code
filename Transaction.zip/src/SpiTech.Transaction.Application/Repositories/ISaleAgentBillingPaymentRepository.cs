﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Transaction.Domain.Entities;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface ISaleAgentBillingPaymentRepository : IRepository<SaleAgentBillingPayment>
    {
        Task<bool> UpdateNachaFilePath(int SaleAgentBillingPaymentId,
            string nachaFilePath,
            string nachaFileName,
            string offsetNachaFilePath,
            string offsetNachaFileName,
            string sftpConfig);
        Task<SaleAgentBillingPayment> GetSaleAgentBillingPayment(int saleAgentBillingId);
        Task<bool> UpdateNachaFileUploadStatus(int saleAgentBillingPaymentId,
            bool isNachaUploaded,
            string nachaUploadError,
            bool isOffsetNachaUploaded,
            string offsetNachaUploadError);
    }
}
