﻿using SpiTech.ApplicationCore.Repositories;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface IBaiFileDetailRepository : IRepository<Domain.Entities.BaiFileDetail>
    {
    }
}
