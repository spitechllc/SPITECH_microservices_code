﻿using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Transaction.Application.Queries.GetACHTransactionReport;
using SpiTech.Transaction.Application.Queries.GetTransactionDetailReport;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface ITransactionRepository : IRepository<Domain.Entities.Transaction>
    {
        Task<List<TransactionModel>> GetTransactionBySettlementRequestId(int settlementRequestId);
        Task<List<Domain.Entities.Transaction>> GetTransactionByStoreBillingId(int storeBillingId);
        Task<List<Domain.Entities.Transaction>> GetTransactionBySiteId(string siteId, int month, int year);
        Task<List<Domain.Entities.Transaction>> GetTransactionByfilter(long transactionId, int userId = 0, string uMTI = "");
        Task<List<Domain.Entities.Transaction>> GetTransactionByDateRange(DateTime fromDateUtc, DateTime toDateUtc);
        Task<bool> ReconcileTransaction(int storeid, string siteId, string settlementPeriodId, int settlementRequestId);
        Task<List<TransactionModel>> PaymentReconcile(int pageIndex, int pageSize, long LastTransactionId);
        Task<TransactionCountModel> GetTransactionCount(string SiteId, int Noofdays, int StoreId);
        Task<List<int>> GetTransactionStoreIds(string SiteId, int Noofdays, int StoreId);
        Task<TransactionCountModel> GetTransactionCountByFilters(StoreFilters storeFilters, DateTime FromDate, DateTime ToDate, string FilterValue);
        Task<List<MonthlyTransactionModel>> GetMonthlyTransactions(int pageIndex, int pageSize, int? storeId, DateTime startUtcDate, DateTime endUtcDate, bool? isSuccess, bool? isCancelled, bool? isFailed, MonthlyTransactionSortBy? sortBy, SortOrderEnum? sortOrder);
        Task<List<int>> GetTransactionStoreIdsByFilters(StoreFilters storeFilters, DateTime FromDate, DateTime ToDate, string FilterValue);
        Task<MonthlyTransactionAggregateModel> GetMonthlyTransactionsAggregate(int? storeId, DateTime startUtcDate, DateTime endUtcDate, bool? isSuccess, bool? isCancelled, bool? isFailed);
        Task<List<TransactionSettlementModel>> GetDailyTransactionBySiteId(string siteId, DateTime TransactionDate);
        Task<List<MonthlyTransactionModel>> GetMonthlyTransactionBySiteId(string siteId, int month, int year);
        Task<List<NonBillStoreTransactionModel>> GetNonBillStoreTransactions(int month, int year);
        Task<bool> UpdateStoreBilling(int storeBillingId, long[] transactionIds, int updatedBy);
        Task<List<TransactionModel>> GetStoreByTransactionIds(long[] transactionIds);
        Task<List<PaymentMethodDetail>> GetPaymentMethodDetails(int settlementRequestId);
        Task<List<Domain.Entities.Transaction>> GetLastTransactionByFilter(int[] storeId, int[] userId);
        Task<bool> UpdateSaleAgentBilling(int saleAgentBillingId, long[] transactionIds, int updatedBy);
        Task<List<NonBillSaleAgentTransactionModel>> GetNonBillSaleAgentTransactions(int month, int year);
        Task<List<NonBillResellerTransactionModel>> GetNonBillResellerTransactions(int month, int year);
        Task<bool> UpdateResellerBilling(int resellerBillingId, long[] transactionIds, int updatedBy);

        Task<bool> ReconcileFailTransactions(long[] transactionIds);
        Task<List<EodTransactionModel>> GetEodTransactions(int settlementRequestId);
        Task<DashboardTransactionModel> GetTransactionDetailsForDashboard(DateTime? startDate, DateTime? endDate, int[] storeIds, int? userId, int? month, int? year);
        Task<DashboardTransactionModel> GetCurrentTransactionDetailsForDashboard(int? userId, int[] storeIds);
        Task<List<DashboardStoreModel>> GetStoreTransactionDetailsForDashboard(DateTime? startDate, DateTime? endDate, int[] storeIds, int? userId, int? month, int? year, StoreDetailDashboardSortBy? sortBy, SortOrderEnum? sortOrder);
        Task<List<DashboardSaleItemsModel>> GetSaleItemInfoForDashBoard(DateTime? startDate, DateTime? endDate, int[] storeIds, int? userId, int? month, int? year);
        Task<DashboardConsumersModel> GetConsumerSummaryForDashboard(DateTime? startDate, DateTime? endDate, int[] storeIds, int? userId, int? month, int? year);
        Task<List<DashboardUserModel>> GetConsumerDetailsForDashboard(DateTime? startDate, DateTime? endDate, int[] storeIds, int? userId, int? month, int? year);
        Task<List<DashboardYearWiseModel>> GetYearwiseDetailForDashboard(DateTime? startDate, DateTime? endDate, int[] storeIds, int? userId, int? month, int? year);
        Task<List<DashboardMonthwiseModel>> GetMonthWiseDetailForDashboard(int valueYear, int? month, int[] storeIds, int? userId);
        Task<List<ACHTransactionReportModel>> ACHTransactionReport(GetACHTransactionReportQuery request);
        Task<List<TransactionReportModel>> TransactionDetailReport(GetTransactionDetailReportQuery request);
        Task<List<DashboardStoreModel>> GetStoreCurrentTransactionDetailsForDashboard();
        Task<List<ConsumersList>> GetConsumerListForDashboard(int? pageIndex, int? pageSize, ConsumerSortBy? sortBy, SortOrderEnum? sortOrder, int[] storeIds);
        Task<List<DashboardProfileWithTransaction>> GetConsumerListFor7DaysTranDashboard(IEnumerable<int> userIds);
        Task<List<TransactionModel>> GetTransactionUserId(DateTime? startDate, DateTime? endDate);
        Task<List<DashboardProfileWithTransaction>> GetProfileWithoutTransactionLast7Day(IEnumerable<int> userIds);

        Task<List<DashboardStoreModel>> GetDayWiseStoreTransactionDetailsForDashboard(int storeId, int? userId, int month, int year, StoreDetailDashboardSortBy? sortBy, SortOrderEnum? sortOrder);

        Task<List<MobileDashboardStoreTransactionModel>> GetTransactionDetailsForMobileDashboard(DateTime? startDate, DateTime? endDate, int[] storeIds);
        Task<List<TransactionDetailEOD>> TransactionDetailEod(long SettlementRequestId, string StoreId, string SiteId);

        Task<bool> UpdateTranProcessSettlementStatus(int TransactionId, int AchPaymentStatusId,
           int CardPaymentStatusId, int CashRewardPaymentStatusId, bool MerchantPay,bool ConsumerPay, int ConsumerPaid, int MerchantPaid);
        Task<bool> UpdateTranansactionStatus(int TransactionId,
           int CardPaymentStatusId, int CashRewardPaymentStatusId, int AchPaymentStatusId, string Reason);
    }
}


