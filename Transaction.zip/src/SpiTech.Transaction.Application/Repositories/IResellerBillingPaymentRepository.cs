﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Transaction.Domain.Entities;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface IResellerBillingPaymentRepository : IRepository<ResellerBillingPayment>
    {
        Task<ResellerBillingPayment> GetResellerBillingPayment(int ResellerBillingId);

        Task<bool> UpdateNachaFilePath(int resellerBillingPaymentId,
                                        string nachaFilePath,
                                        string nachaFileName,
                                        string offsetNachaFilePath,
                                        string offsetNachaFileName,
                                        string sftpConfig);

        Task<bool> UpdateNachaFileUploadStatus(int resellerBillingPaymentId,
                                                bool isNachaUploaded,
                                                string nachaUploadError,
                                                bool isOffsetNachaUploaded,
                                                string offsetNachaUploadError);
    }
}
