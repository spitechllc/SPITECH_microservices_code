﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Transaction.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface ISiteRepository : IRepository<Site>
    {
        Task<Site> GetByStoreId(string siteId);
        Task<Site> GetByStoreId(int storeId);
        Task Update(int storeId, string siteId, string storeName);
    }
}
