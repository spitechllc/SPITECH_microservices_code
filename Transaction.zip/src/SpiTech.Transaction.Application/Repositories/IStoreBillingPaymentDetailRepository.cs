﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Transaction.Domain.Entities;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface IStoreBillingPaymentDetailRepository : IRepository<StoreBillingPaymentDetail>
    {
        Task<bool> MarkUnPaid(int storeBillingId, int updateUserId, string reason);
    }
}
