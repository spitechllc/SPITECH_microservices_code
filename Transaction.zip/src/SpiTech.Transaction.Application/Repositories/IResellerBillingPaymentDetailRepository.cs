﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Transaction.Domain.Entities;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface IResellerBillingPaymentDetailRepository : IRepository<ResellerBillingPaymentDetail>
    {
        Task<bool> MarkUnPaid(int ResellerBillingId, int updateUserId, string reason);
    }
}
