﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Transaction.Domain.Entities;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface ISaleAgentBillingPaymentDetailRepository : IRepository<SaleAgentBillingPaymentDetail>
    {
        Task<bool> MarkUnPaid(int saleAgentBillingId, int updateUserId, string reason);
    }
}
