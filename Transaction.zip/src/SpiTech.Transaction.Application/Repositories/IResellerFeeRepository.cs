﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Transaction.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface IResellerFeeRepository : IRepository<ResellerFee>
    {
        Task<List<ResellerFee>> GetDefaultFees(string coreProcessingName);
        Task<List<ResellerFee>> GetByResellerId(int resellerId);
        Task<List<ResellerFee>> GetByResellerIds(int[] resellerId);
    }
}
