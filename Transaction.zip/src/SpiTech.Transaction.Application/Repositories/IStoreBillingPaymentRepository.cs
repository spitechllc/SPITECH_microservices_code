﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Transaction.Domain.Entities;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface IStoreBillingPaymentRepository : IRepository<StoreBillingPayment>
    {
        Task<StoreBillingPayment> GetStoreBillingPayment(int storeBillingId);
        Task<bool> UpdateNachaFilePath(int storeBillingPaymentId,
           string nachaFilePath,
           string nachaFileName,
           string offsetNachaFilePath,
           string offsetNachaFileName,
           string sftpConfig);

        Task<bool> UpdateNachaFileUploadStatus(int storeBillingPaymentId,
            bool isNachaUploaded,
            string nachaUploadError,
            bool isOffsetNachaUploaded,
            string offsetNachaUploadError);
    }
}
