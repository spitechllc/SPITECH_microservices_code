﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Transaction.Domain.Entities;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface ISaleAgentBillingRepository : IRepository<SaleAgentBilling>
    {
        Task<List<SaleAgentBillingModel>> GetUnprocessedMontlyInvoiceBatch();
        Task<List<SaleAgentBillingModel>> GetBills(int? saleAgentBillingId);
        Task<List<SaleAgentBilling>> GetStoreUnBilledForSaleAgent(int month, int year);
        Task<List<SaleAgentBilling>> GetUnPaidBills(int month, int year);
        Task<bool> UpdatePaid(int[] saleAgentBillingIds, int requestedBy, bool isPaid);
        Task<bool> UpdateNeedReview(int[] saleAgentBillingIds, bool isNeedReview, int requestedBy);
        Task<bool> UpdateInvoicePdfFilePath(int saleAgentBillingId, string filename, string azurefileurl);
        Task<bool> UpdateProcessStatus(int saleAgentBillingId, string status);
        Task<bool> UpdateInvoiceNumber(int saleAgentBillingId, string invoiceNumber);
        Task<List<SaleAgentBillingModel>> GetBills(int pageIndex, int pageSize, int? storeId, int month, int year, bool? isAgentNeedReview, bool? isPaid, SaleAgentBillingSortBy? sortBy, SortOrderEnum? sortOrder);
        Task<SaleAgentBillingAggregateModel> GeAggregatetBills(int? storeId, int month, int year, bool? isAgentNeedReview, bool? isPaid);
    }
}
