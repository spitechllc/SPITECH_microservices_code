﻿using SpiTech.ApplicationCore.Repositories;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface IBaiErrorFileRepository : IRepository<Domain.Entities.BaiErrorFile>
    {
    }
}
