﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Transaction.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface IPaymentInfoRepository : IRepository<PaymentInfo>
    {
        Task<List<PaymentInfo>> GetPaymentInfoByfilter(long transactionId);
    }
}
