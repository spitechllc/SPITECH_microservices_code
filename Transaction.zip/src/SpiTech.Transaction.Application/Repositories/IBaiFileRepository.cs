﻿using SpiTech.ApplicationCore.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface IBaiFileRepository : IRepository<Domain.Entities.BaiFile>
    {
        Task<List<Domain.Entities.BaiFile>> UnArchivedFiles();
    }
}
