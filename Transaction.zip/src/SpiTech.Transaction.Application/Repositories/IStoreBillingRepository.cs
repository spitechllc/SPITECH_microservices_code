﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Transaction.Domain.Entities;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface IStoreBillingRepository : IRepository<StoreBilling>
    {
        Task<bool> InactiveUnpaid(int month, int year);
        Task<StoreBilling> GeStoreBill(int storeId, int month, int year);
        Task<StoreBillingAggregateModel> GeStoreAggregatetBills(int? storeId, int month, int year, bool? isNeedReview, bool? isPaid);
        Task<List<StoreBillingModel>> GetBills(int pageIndex, int pageSize, int? storeId, int month, int year, bool? isNeedReview, bool? isPaid, StoreBillingSortBy? sortBy, SortOrderEnum? sortOrder, bool withDetails = false);
        Task<bool> UpdateNeedReview(int[] storeBillingIds, bool isNeedReview, int requestedBy);
        Task<bool> UpdatePaid(int[] storeBillingIds, int requestedBy, bool isPaid);
        Task<List<StoreBillingModel>> GetUnprocessedMontlyInvoiceBatch();
        Task<StoreBillingModel> GetMontlyBillingForInvoice(int storeBillingId);
        Task<bool> UpdateInvoicePdfFilePath(int storeBillingId, string invoiceFileName, string invoiceFilePath);
        Task<bool> UpdateProcessStatus(int storeBillingId, string status);
        Task<bool> UpdateInvoiceNumber(int storeBillingId, string invoiceNumber);
    }
}
