﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Transaction.Application.Queries.GetDailyNachaProcessingReport;
using SpiTech.Transaction.Domain.Entities;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface ISettlementPaymentDetailRepository : IRepository<SettlementPaymentDetail>
    {
        Task<bool> MarkUnPaid(int settlementRequestId, bool onlyCard, bool onlyCashReward, bool onlyACH, int updateUserId, string reason);
        Task<List<NachaDailyProcessingReportModel>> DailyNachaProcessingReport(GetDailyNachaProcessingReportQuery request);
    }
}
