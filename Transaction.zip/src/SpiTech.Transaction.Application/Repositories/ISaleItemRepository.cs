﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Transaction.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface ISaleItemRepository : IRepository<SaleItem>
    {
        Task<List<SaleItem>> GetSaleItemByfilter(long transactionId, int saleItemId, int itemID);
    }
}
