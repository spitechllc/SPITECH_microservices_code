﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Transaction.Domain.Entities;

namespace SpiTech.Transaction.Application.Repositories
{
    public interface INachaConfigRepository : IRepository<NachaConfig>
    {
    }
}
