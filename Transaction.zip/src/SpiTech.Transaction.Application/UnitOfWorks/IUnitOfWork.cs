﻿using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Transaction.Application.Repositories;

namespace SpiTech.Transaction.Application.UnitOfWorks
{
    public interface IUnitOfWork : IBaseUnitOfWork
    {
        INachaConfigRepository NachaConfigs { get; }
        IBaiFileRepository BaiFiles { get; }
        IBaiErrorFileRepository BaiErrorFiles { get; }
        IBaiFileDetailRepository BaiFileDetails { get; }

        ITransactionRepository Transactions { get; }
        IPaymentInfoRepository PaymentInfos { get; }
        ISaleItemRepository SaleItems { get; }
        IPriceAdjustmentRepository PriceAdjustments { get; }
        IReceiptInfoLineRepository ReceiptInfoLines { get; }
        ISiteRepository Sites { get; }

        ISettlementRequestRepository SettlementRequests { get; }
        ISettlementDetailRepository SettlementDetails { get; }
        ISettlementPaymentRepository SettlementPayments { get; }
        ISettlementPaymentDetailRepository SettlementPaymentDetails { get; }

        IResellerFeeRepository ResellerFees { get; }
        IResellerBillingRepository ResellerBillings { get; }
        IResellerBillingPaymentRepository ResellerBillingPayments { get; }
        IResellerBillingPaymentDetailRepository ResellerBillingPaymentDetails { get; }

        ISaleAgentFeeRepository SaleAgentFees { get; }
        ISaleAgentBillingRepository SaleAgentBillings { get; }
        ISaleAgentBillingPaymentRepository SaleAgentBillingPayments { get; }
        ISaleAgentBillingPaymentDetailRepository SaleAgentBillingPaymentDetails { get; }

        IStoreBillingFeeRepository StoreBillingFees { get; }
        IStoreBillingRepository StoreBillings { get; }
        IStoreBillingDetailRepository StoreBillingDetails { get; }
        IStoreBillingPaymentRepository StoreBillingPayments { get; }
        IStoreBillingPaymentDetailRepository StoreBillingPaymentDetails { get; }
        IStoreSettlementConfigRepository StoreSettlementConfigs { get; }
        IFnboReturnHeaderRepository FnboReturnHeaders { get; }
        IFnboReturnTransactionRepository FnboReturnTransactions { get; }
        IFnboReturnOtherRepository FnboReturnOthers { get; }
        ILogInfoRepository LogInfos { get; }
    }
}