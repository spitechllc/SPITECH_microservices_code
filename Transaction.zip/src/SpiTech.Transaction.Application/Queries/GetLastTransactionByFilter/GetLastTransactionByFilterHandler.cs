﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetLastTransactionByFilter
{
    public class GetLastTransactionByFilterHandler :
        IRequestHandler<GetLastTransactionByFilterQuery, ResponseList<TransactionModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetLastTransactionByFilterHandler> _logger;
        private readonly IMapper _mapper;

        public GetLastTransactionByFilterHandler(IUnitOfWork context,
                                             ILogger<GetLastTransactionByFilterHandler> logger,
                                             IMapper mapper
                                             )
        {

            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<ResponseList<TransactionModel>> Handle(GetLastTransactionByFilterQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod($"Consumer Pro GetLastTransactionByFilter Handler step1");
            _logger.TraceEnterMethod(nameof(Handle), request);

            ResponseList<TransactionModel> res = new ResponseList<TransactionModel>();

            IEnumerable<TransactionModel> transactionModel = _mapper.Map<IEnumerable<TransactionModel>>(await _context.Transactions.GetLastTransactionByFilter(request.StoreIds, request.UserIds));
            _logger.TraceEnterMethod($"Consumer Pro GetLastTransactionByFilter Handler step2");
            if (transactionModel != null && transactionModel.Count()>0)
            {
                _logger.TraceEnterMethod($"Consumer Pro GetLastTransactionByFilter Handler step3");
                res.Data = transactionModel;
            }
            _logger.TraceEnterMethod($"Consumer Pro GetLastTransactionByFilter Handler step4");
            _logger.TraceExitMethod(nameof(Handle), transactionModel);
            return res;
        }
    }
}
