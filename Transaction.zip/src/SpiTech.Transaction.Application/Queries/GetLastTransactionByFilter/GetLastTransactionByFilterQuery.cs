﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.Transaction.Application.Queries.GetLastTransactionByFilter
{
    public class GetLastTransactionByFilterQuery : IRequest<ResponseList<TransactionModel>>
    {
        public int[] StoreIds { get; set; }
        public int[] UserIds { get; set; }
    }
}
