﻿using MediatR;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.Transaction.Application.Queries.GetTransactionsByStoreBillingId
{
    public class GetTransactionsByStoreBillingIdQuery : IRequest<IEnumerable<TransactionModel>>
    {
        public int StoreBillingId { get; set; }
    }
}
