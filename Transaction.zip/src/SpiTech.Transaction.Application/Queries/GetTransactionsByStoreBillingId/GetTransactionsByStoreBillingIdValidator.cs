﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetTransactionsByStoreBillingId
{
    public class GetTransactionsByStoreBillingIdValidator : AbstractValidator<GetTransactionsByStoreBillingIdQuery>
    {
        public GetTransactionsByStoreBillingIdValidator()
        {
            RuleFor(x => x.StoreBillingId).GreaterThan(0).WithMessage("StoreBillingId required");
        }
    }
}
