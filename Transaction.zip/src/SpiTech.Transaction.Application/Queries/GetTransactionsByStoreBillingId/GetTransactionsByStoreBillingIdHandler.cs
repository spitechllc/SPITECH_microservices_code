﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetTransactionsByStoreBillingId
{
    public class GetTransactionsByStoreBillingIdHandler :
        IRequestHandler<GetTransactionsByStoreBillingIdQuery, IEnumerable<TransactionModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetTransactionsByStoreBillingIdHandler> _logger;
        private readonly IMapper _mapper;

        public GetTransactionsByStoreBillingIdHandler(IUnitOfWork context,
                                             ILogger<GetTransactionsByStoreBillingIdHandler> logger,
                                             IMapper mapper
                                             )
        {

            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<IEnumerable<TransactionModel>> Handle(GetTransactionsByStoreBillingIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            List<TransactionModel> result = _mapper.Map<List<TransactionModel>>(await _context.Transactions.GetTransactionByStoreBillingId(request.StoreBillingId));

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
