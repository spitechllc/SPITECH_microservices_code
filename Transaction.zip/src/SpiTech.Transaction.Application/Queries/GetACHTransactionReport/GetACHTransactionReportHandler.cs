﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Service.Clients.Payments;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetACHTransactionReport
{
    public class GetACHTransactionReportHandler : IRequestHandler<GetACHTransactionReportQuery, PaginatedList<ACHTransactionReportModel>>
    {
        private readonly ILogger<GetACHTransactionReportHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly IPaymentServiceClient _paymentApiClient;
        private readonly IStoreServiceClient _storeServiceClient;

        public GetACHTransactionReportHandler(
                                    ILogger<GetACHTransactionReportHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper, IPaymentServiceClient paymentApiClient, IStoreServiceClient storeServiceClient)
        {
            _logger = logger;
            _context = context;
            _mapper = mapper;
            _paymentApiClient = paymentApiClient;
            _storeServiceClient = storeServiceClient;
        }

        public async Task<PaginatedList<ACHTransactionReportModel>> Handle(GetACHTransactionReportQuery request, CancellationToken cancellationToken)
        {
            List<ACHTransactionReportModel> result = await _context.Transactions.ACHTransactionReport(request);

            int totalRecord = 0;

            ICollection<UserPaymentMethodModel> userPaymentMethod = new List<UserPaymentMethodModel>();
            ICollection<StoreInfoModel> storeDetails = new List<StoreInfoModel>();

            if (result != null && result.Count() > 0)
            {
                totalRecord = result.Select(x => x.TotalRecord).FirstOrDefault();

                int[] ids = result.Select(t => t.UserPaymentMethodId).Distinct().ToArray();
                userPaymentMethod = (await _paymentApiClient.GetAsync(ids)) ?? new List<UserPaymentMethodModel>();

                //get store details
                int[] storeIds = result.Select(t => t.StoreId).Distinct().ToArray();
                storeDetails = (await _storeServiceClient.GetStoreInfosAsync(storeIds)) ?? new List<StoreInfoModel>();

                foreach (var item in result)
                {
                    item.Bank = userPaymentMethod.Where(t => t.UserPaymentMethodId == item.UserPaymentMethodId).FirstOrDefault().BankName;
                    item.StoreAddress = storeDetails.Where(t => t.StoreId == item.StoreId).FirstOrDefault()?.Addresses.Where(t => t.StoreId == item.StoreId).FirstOrDefault()?.AddressLine1;
                    item.StoreCity = storeDetails.Where(t => t.StoreId == item.StoreId).FirstOrDefault()?.Addresses.Where(t => t.StoreId == item.StoreId).FirstOrDefault()?.City;
                    item.StoreState = storeDetails.Where(t => t.StoreId == item.StoreId).FirstOrDefault()?.Addresses.Where(t => t.StoreId == item.StoreId).FirstOrDefault()?.State;
                }
            }
            return new PaginatedList<ACHTransactionReportModel>
            {
                Data = result,
                PageIndex = request.PageIndex ?? 0,
                PageSize = request.PageSize ?? 0,
                TotalCount = totalRecord,
            };
        }

    }
}
