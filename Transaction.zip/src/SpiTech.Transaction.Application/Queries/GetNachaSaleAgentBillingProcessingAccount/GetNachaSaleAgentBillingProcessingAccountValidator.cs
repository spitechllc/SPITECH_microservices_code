﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetNachaSaleAgentBillingProcessingAccount
{
    public class GetNachaSaleAgentBillingProcessingAccountValidator : AbstractValidator<GetNachaSaleAgentBillingProcessingAccountQuery>
    {
        public GetNachaSaleAgentBillingProcessingAccountValidator()
        {
            RuleFor(x => x).Must(x => x.Month >= 1 && x.Month <= 12).WithMessage("Month is invalid");
            RuleFor(x => x.Year).GreaterThan(2000).WithMessage("Year is invalid");
        }
    }
}
