﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.Service.Clients.Payments;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetNachaSaleAgentBillingProcessingAccount
{
    public class GetNachaSaleAgentBillingProcessingAccountHandler : IRequestHandler<GetNachaSaleAgentBillingProcessingAccountQuery, NachaProcessingModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetNachaSaleAgentBillingProcessingAccountHandler> logger;
        private readonly IMediator mediator;
        private readonly IPaymentServiceClient paymentClient;

        public GetNachaSaleAgentBillingProcessingAccountHandler(IUnitOfWork context,
                                    ILogger<GetNachaSaleAgentBillingProcessingAccountHandler> logger,
                                    IMediator mediator,
                                    IPaymentServiceClient paymentClient)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            this.paymentClient = paymentClient;
        }

        public async Task<NachaProcessingModel> Handle(GetNachaSaleAgentBillingProcessingAccountQuery query, CancellationToken cancellationToken)
        {
            NachaProcessingModel response = null;
            logger.TraceEnterMethod(nameof(Handle), query);

            var saleAgentBillings = await context.SaleAgentBillings.GetUnPaidBills(query.Month, query.Year);

            if (saleAgentBillings != null && saleAgentBillings.Any())
            {
                var saleAgentIds = saleAgentBillings.Select(t => t.SaleAgentId).Distinct().ToList();

                StoreConfigModelResponseList storeConfigs = await paymentClient.MasterStoreConfigAsync(cancellationToken);

                if (storeConfigs.Data == null || !storeConfigs.Data.Any())
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreConfigs", "Unable to get MasterStoreConfigs"));
                }

                if (query.IsPreview)
                {
                    foreach (var storeConfig in storeConfigs.Data)
                    {
                        if (string.IsNullOrWhiteSpace(storeConfig.AccountNo))
                        {
                            storeConfig.AccountNo = storeConfig.AccountNo.MaskAccountNumber();
                        }
                    }
                }

                IEnumerable<StoreConfigModel> masterAccounts = storeConfigs.Data.Where(t => t.IsMasterAccount);

                if (masterAccounts == null || !masterAccounts.Any())
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreConfigs", "Unable to get masterAccount in MasterStoreConfigs"));
                }

                if (masterAccounts.Count() > 1)
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreConfigs", "Found multiple masterAccount in MasterStoreConfigs"));
                }

                StoreConfigModel masterAccount = storeConfigs.Data.FirstOrDefault(t => t.IsMasterAccount);

                var saleAgentConfigModelResponseList = await paymentClient.AllSaleAgentConfigsAsync(new GetSaleAgentConfigsQuery { SaleAgentIds = saleAgentIds }, cancellationToken);

                if (saleAgentConfigModelResponseList.Data == null || !saleAgentConfigModelResponseList.Data.Any())
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("SaleAgentConfig", "Unable to get SaleAgentConfig"));
                }

                if (query.IsPreview)
                {
                    foreach (var saleAgentConfig in saleAgentConfigModelResponseList.Data)
                    {
                        if (string.IsNullOrWhiteSpace(saleAgentConfig.AccountNo))
                        {
                            saleAgentConfig.AccountNo = saleAgentConfig.AccountNo.MaskAccountNumber();
                        }
                    }
                }

                var nachaConfig = (await context.NachaConfigs.GetAll()).FirstOrDefault();

                if (nachaConfig == null)
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("NachaConfig", "Unable to get NachaConfigs"));
                }

                if (query.IsPreview)
                {
                    nachaConfig.AccountNo = nachaConfig.AccountNo.MaskAccountNumber();
                }

                response = new NachaProcessingModel
                {
                    Config = new ApplicationCore.Domain.Nacha.NachaConfig
                    {
                        BankName = nachaConfig.Bank,
                        ImmediateOriginName = nachaConfig.AccountName,
                        AccountNo = nachaConfig.AccountNo,
                        RoutingNo = nachaConfig.RoutingNo,
                        BankRoutingNo = nachaConfig.ReceivingBankRoutingNo,
                        BatchCompanyName = masterAccount.AccountName,
                        ProcessType = NachaProcessType.AGENTBILL,
                    }
                };

                foreach (var saleAgentBilling in saleAgentBillings)
                {
                    var saleAgentConfig = saleAgentConfigModelResponseList.Data
                                                .FirstOrDefault(t => t.SaleAgentId == saleAgentBilling.SaleAgentId);
                    if (saleAgentConfig == null)
                    {
                        throw new ValidationException(new FluentValidation.Results.ValidationFailure("saleAgentConfig", $"Unable to get saleAgentConfig for SaleAgentId ({saleAgentBilling.SaleAgentId})"));
                    }

                    //response.Accounts.Add(new NachaModel
                    //{
                    //    AccountEntityId = saleAgentBilling.StoreId,
                    //    TransactionCodeType = TransactionCodeType.Credit,
                    //    ProcessingAccount = new NachaAccount
                    //    {
                    //        AccountName = saleAgentConfig.AccountName,
                    //        AccountNo = saleAgentConfig.AccountNo,
                    //        RoutingNo = saleAgentConfig.RoutingNo,
                    //        AccountType = saleAgentConfig.IsChecking ? AccountType.Checking :
                    //                                                AccountType.Savings
                    //    },
                    //    Amount = saleAgentBilling.TotalFee,
                    //    IdentificationNumber = saleAgentBilling
                    //                                .SaleAgentBillingId.ToString(string.Concat(Enumerable.Repeat("0", 12))),
                    //    RequestId = saleAgentBilling.SaleAgentBillingId,
                    //});
                }
            }

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
