﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Nacha;

namespace SpiTech.Transaction.Application.Queries.GetNachaSaleAgentBillingProcessingAccount
{
    public class GetNachaSaleAgentBillingProcessingAccountQuery : IRequest<NachaProcessingModel>
    {
        public int Month { get; set; }
        public int Year { get; set; }
        public bool IsPreview { get; set; }
    }
}
