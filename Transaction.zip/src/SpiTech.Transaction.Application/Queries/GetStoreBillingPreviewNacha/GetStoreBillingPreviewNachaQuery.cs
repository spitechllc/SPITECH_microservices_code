﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Nacha;
using System;

namespace SpiTech.Transaction.Application.Queries.GetStoreBillingPreviewNacha
{
    public class GetStoreBillingPreviewNachaQuery : IRequest<NachaFileBytesModel>
    {
        public int Month { get; set; }
        public int Year { get; set; }
        public DateTime? EffectiveDate { get; set; }
    }
}
