﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using SpiTech.Transaction.Domain.Models;
using System;


namespace SpiTech.Transaction.Application.Queries.GetGetTransactionCountByFilters
{
    public class GetGetTransactionCountByFiltersQuery : IRequest<TransactionCountModel>
    {
        /// <remarks>
        /// format(MM/dd/yyyy)
        /// </remarks>
        public DateTime FromDate { get; set; } = System.DateTime.UtcNow.AddHours(-24);
        /// <remarks>
        /// format(MM/dd/yyyy)
        /// </remarks>
        public DateTime ToDate { get; set; } = System.DateTime.UtcNow;
        public StoreFilters StoreFilters { get; set; }
        public string FilterValue { get; set; }
    }
}
