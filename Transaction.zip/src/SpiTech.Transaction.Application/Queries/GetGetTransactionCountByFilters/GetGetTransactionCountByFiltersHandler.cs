﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Service.Clients.Finance;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetGetTransactionCountByFilters
{
    public class GetGetTransactionCountByFiltersHandler : IRequestHandler<GetGetTransactionCountByFiltersQuery, TransactionCountModel>
    {


        private readonly IUnitOfWork _context;
        private readonly ILogger<GetGetTransactionCountByFiltersHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IFinanceServiceClient _financeApiClient;
        public GetGetTransactionCountByFiltersHandler(IUnitOfWork context,
                                             ILogger<GetGetTransactionCountByFiltersHandler> logger,
                                             IMapper mapper,
                                             IFinanceServiceClient financeApiClient
                                           )
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _financeApiClient = financeApiClient;
        }

        public async Task<TransactionCountModel> Handle(GetGetTransactionCountByFiltersQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            System.Collections.Generic.List<int> storeids = await _context.Transactions.GetTransactionStoreIdsByFilters(request.StoreFilters, request.FromDate, request.ToDate, request.FilterValue);

            System.Collections.Generic.ICollection<CashRewardModel> financeresponse = await _financeApiClient.GetCashRewardDetailsByStoreIdAsync(new GetCashRewardDetailsByFilterQuery
            {
                StoreIds = storeids,
            });

            TransactionCountModel result = new();

            result = await _context.Transactions.GetTransactionCountByFilters(request.StoreFilters, request.FromDate, request.ToDate, request.FilterValue);

            foreach (CashRewardModel item in financeresponse)
            {
                result.TotalCashRewardEarned += Convert.ToDecimal(item.TotalEarned);
                result.TotalCashRewardRedeemed += Convert.ToDecimal(item.TotalRedeemed);
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
