﻿using FluentValidation;
using SpiTech.ApplicationCore.Domain.Nacha.Enums;

namespace SpiTech.Transaction.Application.Queries.GetGetTransactionCountByFilters
{
    public class GetGetTransactionCountByFiltersValidator : AbstractValidator<GetGetTransactionCountByFiltersQuery>
    {
        public GetGetTransactionCountByFiltersValidator()
        {
            RuleFor(x => x.FromDate).NotNull().NotEmpty().GreaterThan(new System.DateTime(2021, 1, 1)).WithMessage("Invalid Date. Transaction does not exist");
            RuleFor(x => x.ToDate).NotNull().NotEmpty().GreaterThan(new System.DateTime(2021, 1, 1)).WithMessage("Invalid Date. Transaction does not exist");
            RuleFor(x => x.FilterValue).NotNull().NotEmpty().WithMessage("FilterValue Required ").When(s => s.StoreFilters != StoreFilters.None);
        }
    }
}
