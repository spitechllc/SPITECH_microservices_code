﻿using MediatR;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.Transaction.Application.Queries.GetTransactionByFilter
{
    public class GetTransactionByFilterQuery : IRequest<IEnumerable<TransactionModel>>
    {
        public long TransactionId { get; set; }
        public int UserId { get; set; }
        public string UMTI { get; set; }
    }
}
