﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetSaleAgentNacha
{
    public class GetSaleAgentNachaValidator : AbstractValidator<GetSaleAgentNachaQuery>
    {
        public GetSaleAgentNachaValidator()
        {
            RuleFor(x => x.SaleAgentBillingId).GreaterThan(0).WithMessage("SaleAgentBillingId is invalid");
        }
    }
}
