﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.Transaction.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetSaleAgentNacha
{
    public class GetSaleAgentNachaHandler : IRequestHandler<GetSaleAgentNachaQuery, NachaFileBytesModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetSaleAgentNachaHandler> logger;
        private readonly IStorageService storageService;

        public GetSaleAgentNachaHandler(IUnitOfWork context,
                                    ILogger<GetSaleAgentNachaHandler> logger,
                                    IStorageServiceFactory storageServiceFactory)
        {
            this.context = context;
            this.logger = logger;
            storageService = storageServiceFactory.Get(ContainerType.MonthlySaleAgentInvoiceNachaFile);
        }

        public async Task<NachaFileBytesModel> Handle(GetSaleAgentNachaQuery query, CancellationToken cancellationToken)
        {
            NachaFileBytesModel response = null;
            logger.TraceEnterMethod(nameof(Handle), query);

            var saleAgentBillingPayment = await context.SaleAgentBillingPayments.GetSaleAgentBillingPayment(query.SaleAgentBillingId);

            //if (saleAgentBillingPayment != null && !string.IsNullOrEmpty(saleAgentBillingPayment.NachaFilePath))
            //{
            //    response = new NachaFileBytesModel();
            //    response.File = saleAgentBillingPayment.NachaFileName;
            //    response.Bytes = await storageService.DownloadBytesAsync(saleAgentBillingPayment.NachaFilePath);
            //}

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
