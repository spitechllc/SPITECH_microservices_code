﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Nacha;

namespace SpiTech.Transaction.Application.Queries.GetSaleAgentNacha
{
    public class GetSaleAgentNachaQuery : IRequest<NachaFileBytesModel>
    {
        public int SaleAgentBillingId { get; set; }
    }
}
