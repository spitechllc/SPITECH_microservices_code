﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Service.Clients.Payments;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetTransactionDetailReport
{
    public class GetTransactionDetailReportHandler : IRequestHandler<GetTransactionDetailReportQuery, PaginatedList<TransactionReportModel>>
    {
        private readonly ILogger<GetTransactionDetailReportHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider authenticationProvider;
        private readonly IPaymentServiceClient _paymentApiClient;
        private readonly IStoreServiceClient _storeServiceClient;

        public GetTransactionDetailReportHandler(
                                    ILogger<GetTransactionDetailReportHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper, IUserAuthenticationProvider authenticationProvider, IPaymentServiceClient paymentApiClient, IStoreServiceClient storeServiceClient)
        {
            _logger = logger;
            _context = context;
            _mapper = mapper;
            this.authenticationProvider = authenticationProvider;
            _paymentApiClient = paymentApiClient;
            _storeServiceClient = storeServiceClient;
        }

        public async Task<PaginatedList<TransactionReportModel>> Handle(GetTransactionDetailReportQuery request, CancellationToken cancellationToken)
        {
            List<TransactionReportModel> result =  await _context.Transactions.TransactionDetailReport(request);

            int totalRecord = 0;

            ICollection<UserPaymentMethodModel> userPaymentMethod = new List<UserPaymentMethodModel>();
            ICollection<StoreInfoModel> storeDetails = new List<StoreInfoModel>();

            if (result != null && result.Count() > 0)
            {
                totalRecord = result.Select(x => x.TotalRecord).FirstOrDefault();

                int[] ids = result.Select(t => t.UserPaymentMethodId??0).Distinct().ToArray();
                userPaymentMethod = (await _paymentApiClient.GetAsync(ids)) ?? new List<UserPaymentMethodModel>();

             

                foreach (var item in result)
                {
                    item.paymentMethodDetails = _mapper.Map<PaymentMethodDetails>(userPaymentMethod.Where(t => t.UserPaymentMethodId == item.UserPaymentMethodId).FirstOrDefault());
                }
            }
            return new PaginatedList<TransactionReportModel>
            {
                Data = result,
                PageIndex = request.PageIndex??0,
                PageSize = request.PageSize ?? 0,
                TotalCount = totalRecord,
            };
        }

    }
}
