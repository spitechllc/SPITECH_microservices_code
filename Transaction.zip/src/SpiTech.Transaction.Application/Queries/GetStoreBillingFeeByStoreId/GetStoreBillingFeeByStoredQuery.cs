﻿using MediatR;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.Transaction.Application.Queries.GetStoreBillingFeeByStoreId
{
    public class GetStoreBillingFeeByStoreIdQuery : IRequest<List<StoreBillingFeeModel>>
    {
        public int StoreId { get; set; }
    }
}
