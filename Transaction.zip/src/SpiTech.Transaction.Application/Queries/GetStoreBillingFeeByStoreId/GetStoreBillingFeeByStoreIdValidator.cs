﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetStoreBillingFeeByStoreId
{
    public class GetStoreBillingFeeByStoreIdValidator : AbstractValidator<GetStoreBillingFeeByStoreIdQuery>
    {
        public GetStoreBillingFeeByStoreIdValidator()
        {
            RuleFor(s => s.StoreId).GreaterThan(0);
        }
    }
}
