﻿using MediatR;
using SpiTech.Transaction.Domain.Entities;
using System.Collections.Generic;

namespace SpiTech.Transaction.Application.Queries.GetSaleAgentFeeByStoreId
{
    public class GetSaleAgentFeeByStoreIdQuery : IRequest<List<SaleAgentFee>>
    {
        public int StoreId { get; set; }
    }
}
