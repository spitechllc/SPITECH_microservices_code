﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetSaleAgentFeeByStoreId
{
    public class GetSaleAgentFeeByStoreIdValidator : AbstractValidator<GetSaleAgentFeeByStoreIdQuery>
    {
        public GetSaleAgentFeeByStoreIdValidator()
        {
            RuleFor(s => s.StoreId).GreaterThan(0);
        }
    }
}
