﻿using MediatR;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetGetTransactionCount
{
    public class GetGetTransactionCountQuery : IRequest<TransactionCountModel>
    {
        public string SiteId { get; set; }
        public int Noofdays { get; set; }
        public int StoreId { get; set; }
    }
}
