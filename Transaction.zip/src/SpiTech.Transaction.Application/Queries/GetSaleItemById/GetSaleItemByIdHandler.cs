﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetSaleItemById
{
    public class GetSaleItemByIdHandler : IRequestHandler<GetSaleItemByIdQuery, SaleItemModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetSaleItemByIdHandler> _logger;
        private readonly IMapper _mapper;
        public GetSaleItemByIdHandler(IUnitOfWork context,
                                    ILogger<GetSaleItemByIdHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<SaleItemModel> Handle(GetSaleItemByIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            SaleItemModel result = _mapper.Map<SaleItemModel>(await _context.SaleItems.Get(request.SaleItemId));
            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
