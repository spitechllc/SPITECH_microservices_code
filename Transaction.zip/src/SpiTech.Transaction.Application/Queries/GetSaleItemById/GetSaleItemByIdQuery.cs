﻿using MediatR;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetSaleItemById
{
    public class GetSaleItemByIdQuery : IRequest<SaleItemModel>
    {
        public int SaleItemId { get; set; }
    }
}
