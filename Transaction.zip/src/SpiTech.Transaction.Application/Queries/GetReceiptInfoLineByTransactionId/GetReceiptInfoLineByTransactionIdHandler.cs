﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetReceiptInfoLineByTransactionId
{
    public class GetReceiptInfoLineByTransactionIdHandler : IRequestHandler<GetReceiptInfoLineByTransactionIdQuery, IEnumerable<ReceiptInfoLineModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetReceiptInfoLineByTransactionIdHandler> _logger;
        private readonly IMapper _mapper;
        public GetReceiptInfoLineByTransactionIdHandler(IUnitOfWork context,
                                             ILogger<GetReceiptInfoLineByTransactionIdHandler> logger,
                                             IMapper mapper
                                           )
        {

            _context = context;
            _logger = logger;
            _mapper = mapper;

        }
        public async Task<IEnumerable<ReceiptInfoLineModel>> Handle(GetReceiptInfoLineByTransactionIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            List<ReceiptInfoLineModel> result = _mapper.Map<List<ReceiptInfoLineModel>>(await _context.ReceiptInfoLines.GetReceiptInfoLineByfilter(request.TransactionId, request.UMTI));

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
