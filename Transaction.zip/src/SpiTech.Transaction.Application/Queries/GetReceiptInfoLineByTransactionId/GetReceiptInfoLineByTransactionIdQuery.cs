﻿using MediatR;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.Transaction.Application.Queries.GetReceiptInfoLineByTransactionId
{
    public class GetReceiptInfoLineByTransactionIdQuery : IRequest<IEnumerable<ReceiptInfoLineModel>>
    {
        public long TransactionId { get; set; }
        public string UMTI { get; set; }
    }
}
