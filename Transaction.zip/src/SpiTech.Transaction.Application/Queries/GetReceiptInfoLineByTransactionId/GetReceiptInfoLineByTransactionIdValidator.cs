﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetReceiptInfoLineByTransactionId
{
    public class GetReceiptInfoLineByTransactionIdValidator : AbstractValidator<GetReceiptInfoLineByTransactionIdQuery>
    {
        public GetReceiptInfoLineByTransactionIdValidator()
        {
            RuleFor(x => x).Must(t => t.TransactionId > 0 || !string.IsNullOrWhiteSpace(t.UMTI)).WithMessage("TransactionId or UMTI required");
        }
    }
}
