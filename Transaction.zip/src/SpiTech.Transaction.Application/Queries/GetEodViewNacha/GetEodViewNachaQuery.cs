﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Nacha;

namespace SpiTech.Transaction.Application.Queries.GetEodViewNacha
{
    public class GetEodViewNachaQuery : IRequest<NachaFileBytesModel>
    {
        public int SettlementRequestId { get; set; }
    }
}
