﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.Transaction.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetEodViewNacha
{
    public class GetEodViewNachaHandler : IRequestHandler<GetEodViewNachaQuery, NachaFileBytesModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetEodViewNachaHandler> logger;
        private readonly IStorageService storageService;

        public GetEodViewNachaHandler(IUnitOfWork context,
                                    ILogger<GetEodViewNachaHandler> logger,
                                    IStorageServiceFactory storageServiceFactory)
        {
            this.context = context;
            this.logger = logger;
            storageService = storageServiceFactory.Get(ContainerType.EodSettlementNachaFile);
        }

        public async Task<NachaFileBytesModel> Handle(GetEodViewNachaQuery query, CancellationToken cancellationToken)
        {
            NachaFileBytesModel response = null;
            logger.TraceEnterMethod(nameof(Handle), query);

            var settlementPayment = await context.SettlementPayments.GetSettlementPayment(query.SettlementRequestId);

            //if (settlementPayment != null && !string.IsNullOrEmpty(settlementPayment.NachaFilePath))
            //{
            //    response = new NachaFileBytesModel();
            //    response.File = settlementPayment.NachaFileName;
            //    response.Bytes = await storageService.DownloadBytesAsync(settlementPayment.NachaFilePath);
            //}

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
