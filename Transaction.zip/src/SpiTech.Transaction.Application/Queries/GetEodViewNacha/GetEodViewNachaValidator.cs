﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetEodViewNacha
{
    public class GetEodViewNachaValidator : AbstractValidator<GetEodViewNachaQuery>
    {
        public GetEodViewNachaValidator()
        {
            RuleFor(x => x.SettlementRequestId).GreaterThan(0);
        }
    }
}
