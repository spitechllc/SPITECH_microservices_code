﻿using MediatR;
using SpiTech.Transaction.Domain.Entities;
using System.Collections.Generic;

namespace SpiTech.Transaction.Application.Queries.GetResellerFeeByResellerId
{
    public class GetResellerFeeByResellerIdQuery : IRequest<List<ResellerFee>>
    {
        public int ResellerId { get; set; }
    }
}
