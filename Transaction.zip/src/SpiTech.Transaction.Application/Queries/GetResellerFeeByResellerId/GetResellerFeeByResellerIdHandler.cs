﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetResellerFeeByResellerId
{
    public class GetResellerFeeByResellerIdHandler : IRequestHandler<GetResellerFeeByResellerIdQuery, List<ResellerFee>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetResellerFeeByResellerIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetResellerFeeByResellerIdHandler(IUnitOfWork context,
                                    ILogger<GetResellerFeeByResellerIdHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<List<ResellerFee>> Handle(GetResellerFeeByResellerIdQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            var result = await _context.ResellerFees.GetByResellerId(query.ResellerId);

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
