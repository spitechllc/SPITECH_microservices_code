﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetResellerFeeByResellerId
{
    public class GetResellerFeeByResellerIdValidator : AbstractValidator<GetResellerFeeByResellerIdQuery>
    {
        public GetResellerFeeByResellerIdValidator()
        {
            RuleFor(s => s.ResellerId).GreaterThan(0);
        }
    }
}
