﻿using MediatR;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetSaleAgentBilling
{
    public class GetSaleAgentBillingQuery : IRequest<SaleAgentBillingPaginatedList>
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public int? StoreId { get; set; }
        public bool? IsNeedReview { get; set; }
        public bool? IsPaid { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public SaleAgentBillingSortBy? SortBy { get; set; }
        public SortOrderEnum? SortOrder { get; set; }
    }
}
