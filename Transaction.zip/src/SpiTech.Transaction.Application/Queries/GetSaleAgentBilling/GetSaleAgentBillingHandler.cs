﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetSaleAgentBilling
{
    public class GetSaleAgentBillingHandler : IRequestHandler<GetSaleAgentBillingQuery, SaleAgentBillingPaginatedList>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetSaleAgentBillingHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IStoreServiceClient storeServiceClient;

        public GetSaleAgentBillingHandler(IUnitOfWork context,
                                             ILogger<GetSaleAgentBillingHandler> logger,
                                             IMapper mapper,
                                             IStoreServiceClient storeServiceClient)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.storeServiceClient = storeServiceClient;
        }

        public async Task<SaleAgentBillingPaginatedList> Handle(GetSaleAgentBillingQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            SaleAgentBillingAggregateModel aggregateResult = null;

            List<SaleAgentBillingModel> result = await _context.SaleAgentBillings.GetBills(request.PageIndex, request.PageSize, request.StoreId, request.Month, request.Year, request.IsNeedReview, request.IsPaid, request.SortBy, request.SortOrder);

            int totalrecord = 0;
            if (result != null && result.Count() > 0)
            {
                var saleAgents = await this.storeServiceClient.SaleAgentsAsync(result.Select(t => t.SaleAgentId));

                foreach (var saleAgentBillingModel in result)
                {
                    var saleAgent = saleAgents?.FirstOrDefault(t => t.SaleAgentId == saleAgentBillingModel.SaleAgentId);
                    if (saleAgent != null)
                        saleAgentBillingModel.SaleAgentName = saleAgent?.FirstName + " " + saleAgent?.LastName;
                }

                aggregateResult = await _context.SaleAgentBillings.GeAggregatetBills(request.StoreId, request.Month, request.Year, request.IsNeedReview, request.IsPaid);

                totalrecord = result.Select(x => x.TotalRecord).FirstOrDefault();
            }

            SaleAgentBillingPaginatedList response = new()
            {
                Data = result.ToList(),
                PageIndex = request.PageIndex,
                PageSize = request.PageSize,
                TotalCount = totalrecord,
                DefineMonthlySaasFee = result?.FirstOrDefault()?.DefineMonthlySaasFee ?? 0,
                DefineTransactionPercentageFee = result?.FirstOrDefault()?.DefineTransactionPercentageFee ?? 0,
                TotalFee = aggregateResult?.TotalFee ?? 0,
                TotalTransactionAmount = aggregateResult?.TotalTransactionAmount ?? 0,
                TotalTransactionPercentageFee = aggregateResult?.TotalTransactionPercentageFee ?? 0,
            };

            _logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
