﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetStoreSettlementConfigByStoreId
{
    public class GetStoreSettlementConfigByStoreIdValidator : AbstractValidator<GetStoreSettlementConfigByStoreIdQuery>
    {
        public GetStoreSettlementConfigByStoreIdValidator()
        {
            RuleFor(s => s.StoreId).GreaterThan(0);
        }
    }
}
