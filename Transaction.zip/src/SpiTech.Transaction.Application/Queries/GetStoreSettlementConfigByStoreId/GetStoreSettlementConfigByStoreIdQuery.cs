﻿using MediatR;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetStoreSettlementConfigByStoreId
{
    public class GetStoreSettlementConfigByStoreIdQuery : IRequest<StoreSettlementConfigModel>
    {
        public int StoreId { get; set; }
        public int? TenantId { get; set; }
    }
}
