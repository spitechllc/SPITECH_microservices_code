﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetStoreSettlementConfigByStoreId
{
    public class GetStoreSettlementConfigByStoreIdHandler : IRequestHandler<GetStoreSettlementConfigByStoreIdQuery, StoreSettlementConfigModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetStoreSettlementConfigByStoreIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetStoreSettlementConfigByStoreIdHandler(IUnitOfWork context,
                                    ILogger<GetStoreSettlementConfigByStoreIdHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<StoreSettlementConfigModel> Handle(GetStoreSettlementConfigByStoreIdQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            var result = await _context.StoreSettlementConfigs.GetByStoreId(query.StoreId);

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;

        }
    }
}
