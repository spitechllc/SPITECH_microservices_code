﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.Transaction.Application.Commands.ProcessStoreSettlement;
using SpiTech.Transaction.Domain.Enums;
using System;
using System.Collections.Generic;

namespace SpiTech.Transaction.Application.Queries.GetEodPreviewNacha
{
    public class GetEodPreviewNachaQuery : IRequest<NachaFileBytesModel>
    {
        public DateTime BusinessDate { get; set; }
        public PaymentStatusEnum CardPayment { get; set; }
        public PaymentStatusEnum CashRewardPayment { get; set; }
        public PaymentStatusEnum AchPayment { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public List<SettlementRequest> settlementRequest { get; set; }
    }
}
