﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetEodPreviewNacha
{
    public class GetEodPreviewNachaValidator : AbstractValidator<GetEodPreviewNachaQuery>
    {
        public GetEodPreviewNachaValidator()
        {
            RuleFor(x => x.BusinessDate).NotNull().GreaterThan(new System.DateTime(2021, 1, 1)).WithMessage("Invalid Date. Transaction does not exist");
        }
    }
}
