﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using SpiTech.ApplicationCore.Nacha;
using SpiTech.Transaction.Application.Queries.GetNachaEodProcessingAccount;
using SpiTech.Transaction.Application.UnitOfWorks;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetEodPreviewNacha
{
    public class GetEodPreviewNachaHandler : IRequestHandler<GetEodPreviewNachaQuery, NachaFileBytesModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetEodPreviewNachaHandler> logger;
        private readonly IMediator mediator;
        private readonly INachaFileBuilder nachaFileBuilder;

        public GetEodPreviewNachaHandler(IUnitOfWork context,
                                    ILogger<GetEodPreviewNachaHandler> logger,
                                    IMediator mediator,
                                    INachaFileBuilder nachaFileBuilder)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            this.nachaFileBuilder = nachaFileBuilder;
        }

        public async Task<NachaFileBytesModel> Handle(GetEodPreviewNachaQuery query, CancellationToken cancellationToken)
        {
            NachaFileBytesModel response = null;
            logger.TraceEnterMethod(nameof(Handle), query);

            logger.Warn($"EOD Settlement Ram 2 GetEodPreviewNachaQuery");

            var nachaEodProcessingAccount = await mediator.Send(new GetNachaEodProcessingAccountQuery
            {
                BusinessDate = query.BusinessDate,
                CardPayment = query.CardPayment,
                AchPayment = query.AchPayment,
                CashRewardPayment = query.CashRewardPayment,
                IsPreview = true,
                EffectiveDate = query.EffectiveDate,
                SettlementRequest = query.settlementRequest
            });

            logger.Warn($"EOD Settlement Ram 3 nachaEodProcessingAccount: "+ nachaEodProcessingAccount.IdentificationNumber +":"+ nachaEodProcessingAccount.ProcessingEntities[0].Accounts.Count() +":"+ nachaEodProcessingAccount.Config.AccountNo);
            logger.Warn($"EOD Settlement Ram 3 nachaEodProcessingAccount");
            if (nachaEodProcessingAccount != null && 
                nachaEodProcessingAccount.ProcessingEntities != null && 
                nachaEodProcessingAccount.ProcessingEntities.Any())
            {
                logger.Warn($"EOD Settlement Ram 4 nachaEodProcessingAccount");

                response = nachaFileBuilder.GetBytes(nachaEodProcessingAccount.Config, nachaEodProcessingAccount.ProcessingEntities.SelectMany(t => t.Accounts).ToList());
            }

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
