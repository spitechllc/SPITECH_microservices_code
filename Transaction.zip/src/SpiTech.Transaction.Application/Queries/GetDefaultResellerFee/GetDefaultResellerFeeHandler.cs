﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetDefaultResellerFee
{
    public class GetDefaultResellerFeeHandler : IRequestHandler<GetDefaultResellerFeeQuery, List<ResellerFee>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetDefaultResellerFeeHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetDefaultResellerFeeHandler(IUnitOfWork context,
                                    ILogger<GetDefaultResellerFeeHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<List<ResellerFee>> Handle(GetDefaultResellerFeeQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            var result = await _context.ResellerFees.GetDefaultFees(null);

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
