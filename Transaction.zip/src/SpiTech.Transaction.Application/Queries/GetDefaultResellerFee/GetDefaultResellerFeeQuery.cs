﻿using MediatR;
using SpiTech.Transaction.Domain.Entities;
using System.Collections.Generic;

namespace SpiTech.Transaction.Application.Queries.GetDefaultResellerFee
{
    public class GetDefaultResellerFeeQuery : IRequest<List<ResellerFee>>
    {
    }
}
