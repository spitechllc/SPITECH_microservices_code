﻿using MediatR;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetReceiptInfoLineById
{
    public class GetReceiptInfoLineByIdQuery : IRequest<ReceiptInfoLineModel>
    {
        public int ReceiptInfoLineId { get; set; }
    }
}
