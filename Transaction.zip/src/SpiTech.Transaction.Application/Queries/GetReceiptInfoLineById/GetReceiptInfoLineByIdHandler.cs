﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetReceiptInfoLineById
{
    public class GetReceiptInfoLineByIdHandler : IRequestHandler<GetReceiptInfoLineByIdQuery, ReceiptInfoLineModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetReceiptInfoLineByIdHandler> _logger;
        private readonly IMapper _mapper;
        public GetReceiptInfoLineByIdHandler(IUnitOfWork context,
                                             ILogger<GetReceiptInfoLineByIdHandler> logger,
                                             IMapper mapper
                                           )
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<ReceiptInfoLineModel> Handle(GetReceiptInfoLineByIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            ReceiptInfoLineModel result = _mapper.Map<ReceiptInfoLineModel>(await _context.ReceiptInfoLines.Get(request.ReceiptInfoLineId));
            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
