﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Nacha;
using System;

namespace SpiTech.Transaction.Application.Queries.GetUserAchNachaProcessingAccount
{
    public class GetUserAchNachaProcessingAccountQuery : IRequest<NachaProcessingModel>
    {
    }
}
