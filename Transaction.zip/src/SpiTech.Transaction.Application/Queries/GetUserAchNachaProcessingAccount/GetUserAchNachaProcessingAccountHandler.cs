﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetUserAchNachaProcessingAccount
{
    public class GetUserAchNachaProcessingAccountHandler : IRequestHandler<GetUserAchNachaProcessingAccountQuery, NachaProcessingModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetUserAchNachaProcessingAccountHandler> logger;
        private readonly IPaymentServiceClient paymentClient;
        private readonly IMediator mediator;

        public GetUserAchNachaProcessingAccountHandler(IUnitOfWork context,
                                                        ILogger<GetUserAchNachaProcessingAccountHandler> logger,
                                                        IPaymentServiceClient paymentClient,
                                                        IMediator mediator)
        {
            this.context = context;
            this.logger = logger;
            this.paymentClient = paymentClient;
            this.mediator = mediator;
        }

        public async Task<NachaProcessingModel> Handle(GetUserAchNachaProcessingAccountQuery query, CancellationToken cancellationToken)
        {
            NachaProcessingModel response = null;
            //logger.TraceEnterMethod(nameof(Handle), query);

            //IEnumerable<UserAchNachaProcessingModel> userAchNachaProcessingModels = null;//await context.Payments.GetUserAchNachaProcessingAccounts();

            //if (userAchNachaProcessingModels != null && userAchNachaProcessingModels.Any())
            //{
            //    StoreConfigModelResponseList storeConfigs = await paymentClient.AllStoreConfigsAsync(new GetStoreConfigsModel
            //    {
            //        StoreIds = new[] { 1}//storeIds
            //    });

            //    if (storeConfigs.Data == null || !storeConfigs.Data.Any())
            //    {
            //        throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreConfigs", "Unable to get StoreConfigs"));
            //    }

            //    //if (query.IsPreview)
            //    //{
            //    //    foreach (var storeConfig in storeConfigs.Data)
            //    //    {
            //    //        if (string.IsNullOrWhiteSpace(storeConfig.AccountNo))
            //    //        {
            //    //            storeConfig.AccountNo = storeConfig.AccountNo.MaskAccountNumber();
            //    //        }
            //    //    }
            //    //}

            //    IEnumerable<StoreConfigModel> masterAccounts = storeConfigs.Data.Where(t => t.IsMasterAccount);

            //    if (masterAccounts == null || !masterAccounts.Any())
            //    {
            //        throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreConfigs", "Unable to get masterAccount in StoreConfigs"));
            //    }

            //    if (masterAccounts.Count() > 1)
            //    {
            //        throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreConfigs", "Found multiple masterAccount in StoreConfigs"));
            //    }

            //    StoreConfigModel masterAccount = storeConfigs.Data.FirstOrDefault(t => t.IsMasterAccount);

            //    var nachaConfig = await paymentClient.NachaConfigAsync(cancellationToken);

            //    if (nachaConfig == null)
            //    {
            //        throw new ValidationException(new FluentValidation.Results.ValidationFailure("NachaConfig", "Unable to get NachaConfigs"));
            //    }

            //    var masterAccounts = await context.StoreConfigs.GetMasterStoreConfigs(null);

            //    if (masterAccounts == null || !masterAccounts.Any())
            //    {
            //        throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreConfigs", "Unable to get masterAccount in StoreConfigs"));
            //    }

            //    if (masterAccounts.Count() > 1)
            //    {
            //        throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreConfigs", "Found multiple masterAccount in StoreConfigs"));
            //    }

            //    var masterAccount = masterAccounts.FirstOrDefault(t => t.IsMasterAccount);

            //    var nachaConfig = (await context.NachaConfigs.GetAll()).FirstOrDefault();

            //    if (nachaConfig == null)
            //    {
            //        throw new ValidationException(new FluentValidation.Results.ValidationFailure("NachaConfig", "Unable to get NachaConfigs"));
            //    }

            //    response = new NachaProcessingModel
            //    {
            //        NachaAccounts = new List<NachaModel>(),
            //        ProcessType = NachaProcessType.USERACH,
            //        NachaConfig = new ApplicationCore.Domain.Nacha.NachaConfig
            //        {
            //            BankName = nachaConfig.Bank,
            //            CompanyName = nachaConfig.AccountName,
            //            AccountNo = nachaConfig.AccountNo,
            //            RoutingNo = nachaConfig.RoutingNo,
            //            BankRoutingNo = nachaConfig.ReceivingBankRoutingNo,
            //            AccountNo = masterAccount.AccountNo,
            //            RoutingNo = masterAccount.RoutingNo,
            //            AccountName = masterAccount.AccountName,
            //            AccountType = masterAccount.IsChecking ? AccountType.Checking : AccountType.Savings,
            //            IdentificationNumber = "P" + DateTime.UtcNow.ToString("ddMMyyyy")
            //        }
            //    };


            //    foreach (var userAchNachaProcessingModel in userAchNachaProcessingModels)
            //    {
            //        response.NachaAccounts.Add(new NachaModel
            //        {
            //            AccountEntityId = userAchNachaProcessingModel.UserPaymentMethodId,
            //            AccountName = userAchNachaProcessingModel.AccountName,
            //            AccountNo = userAchNachaProcessingModel.AccountNo,
            //            RoutingNo = userAchNachaProcessingModel.RoutingNo,
            //            AccountType = userAchNachaProcessingModel.IsChecking ? AccountType.Checking :
            //                                                        AccountType.Savings,
            //            Amount = userAchNachaProcessingModel.Amount,
            //            AmountType = AmountType.ACH,
            //            IdentificationNumber = userAchNachaProcessingModel.PaymentId.ToString("0000000000000"),
            //            RequestId = userAchNachaProcessingModel.PaymentId,
            //        });
            //    }
            //}

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
