﻿using MediatR;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.Transaction.Application.Queries.GetSaleItemByFilter
{
    public class GetSaleItemByFilterQuery : IRequest<IEnumerable<SaleItemModel>>
    {
        public long TransactionId { get; set; }
        public int SaleItemId { get; set; }
        public int ItemId { get; set; }
    }
}
