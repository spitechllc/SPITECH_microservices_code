﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetSaleItemByFilter
{
    public class GetSaleItemByFilterHandler : IRequestHandler<GetSaleItemByFilterQuery, IEnumerable<SaleItemModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetSaleItemByFilterHandler> _logger;
        private readonly IMapper _mapper;
        public GetSaleItemByFilterHandler(IUnitOfWork context,
                                             ILogger<GetSaleItemByFilterHandler> logger,
                                             IMapper mapper
                                           )
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<IEnumerable<SaleItemModel>> Handle(GetSaleItemByFilterQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            List<SaleItemModel> result = _mapper.Map<List<SaleItemModel>>(
                await _context.SaleItems.GetSaleItemByfilter(request.TransactionId,
                request.SaleItemId, request.ItemId));

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}