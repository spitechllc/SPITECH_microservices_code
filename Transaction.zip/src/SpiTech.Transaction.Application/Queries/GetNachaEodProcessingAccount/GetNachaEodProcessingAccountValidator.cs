﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetNachaEodProcessingAccount
{
    public class GetNachaEodProcessingAccountValidator : AbstractValidator<GetNachaEodProcessingAccountQuery>
    {
        public GetNachaEodProcessingAccountValidator()
        {
            RuleFor(x => x.BusinessDate).NotNull().GreaterThan(new System.DateTime(2021, 1, 1)).WithMessage("Invalid Date. Transaction does not exist");
        }
    }
}
