﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using SpiTech.Service.Clients.Payments;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetNachaEodProcessingAccount
{
    public class GetNachaEodProcessingAccountHandler : IRequestHandler<GetNachaEodProcessingAccountQuery, NachaProcessingModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetNachaEodProcessingAccountHandler> logger;
        private readonly IMediator mediator;
        private readonly IPaymentServiceClient paymentClient;
        private readonly IStoreServiceClient storeServiceClient;

        public GetNachaEodProcessingAccountHandler(IUnitOfWork context,
                                                    ILogger<GetNachaEodProcessingAccountHandler> logger,
                                                    IMediator mediator,
                                                    IPaymentServiceClient paymentClient,
                                                    IStoreServiceClient storeServiceClient)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            this.paymentClient = paymentClient;
            this.storeServiceClient = storeServiceClient;
        }

        public async Task<NachaProcessingModel> Handle(GetNachaEodProcessingAccountQuery query, CancellationToken cancellationToken)
        {
            NachaProcessingModel response = null;
            logger.TraceEnterMethod(nameof(Handle), query);

            PaymentStatusEnum? cardPayment = query.CardPayment == Domain.Enums.PaymentStatusEnum.Paid || query.CardPayment == Domain.Enums.PaymentStatusEnum.MarkAsPaid ? Domain.Enums.PaymentStatusEnum.NotPaid : null;
            PaymentStatusEnum? cashRewardPayment = query.CashRewardPayment == Domain.Enums.PaymentStatusEnum.Paid || query.CashRewardPayment == Domain.Enums.PaymentStatusEnum.MarkAsPaid ? Domain.Enums.PaymentStatusEnum.NotPaid : null;
            PaymentStatusEnum? achPayment = query.AchPayment == Domain.Enums.PaymentStatusEnum.Paid || query.AchPayment == Domain.Enums.PaymentStatusEnum.MarkAsPaid ? Domain.Enums.PaymentStatusEnum.NotPaid : null;

            IEnumerable<EodSettlementModel> settlementReq  = await context.SettlementRequests.GetByFilterEODSettment(query.BusinessDate, null, false, cardPayment, cashRewardPayment, achPayment, null, null, null, null, null, null);
            logger.Warn($"EOD Settlement Ram 2");

            List<long> settelementReqId = new List<long>();

            IEnumerable<EodSettlementModel> settlementRequests = new List<EodSettlementModel>();

            if (query.SettlementRequest != null)
            {
                foreach (var settReqId in query.SettlementRequest)
                {
                    settelementReqId.Add(settReqId.SettlementRequestId);
                }
                var setid = settelementReqId.Distinct().ToArray();
                settlementRequests = settlementReq.Where(settlementRequests => setid.Contains(settlementRequests.SettlementRequestId));
            }
            else
            {
                settlementRequests = settlementReq;
            }

            logger.Warn($"EOD Settlement Ram 3");

            var settlementRequestWithAmounts = settlementRequests?.Where(t => t.TerminalTotalAmount > 0).ToList();
            var storeIds = settlementRequestWithAmounts.Select(t => t.StoreId).Distinct().ToArray();

            if (settlementRequests != null && settlementRequests.Any())
            {
                StoreConfigModelResponseList storeConfigs = null;
                StoreConfigModel masterAccount = null;

                if (storeIds.Any())
                {
                    storeConfigs = await paymentClient.AllStoreConfigsAsync(new GetStoreConfigsQuery
                    {
                        StoreIds = storeIds
                    });

                    if (storeConfigs.Data == null || !storeConfigs.Data.Any())
                    {
                        throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreConfigs", "Unable to get StoreConfigs"));
                    }

                    IEnumerable<StoreConfigModel> masterAccounts = storeConfigs.Data.Where(t => t.IsMasterAccount);

                    if (masterAccounts == null || !masterAccounts.Any())
                    {
                        throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreConfigs", "Unable to get masterAccount in StoreConfigs"));
                    }

                    if (masterAccounts.Count() > 1)
                    {
                        throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreConfigs", "Found multiple masterAccount in StoreConfigs"));
                    }

                    masterAccount = storeConfigs.Data.FirstOrDefault(t => t.IsMasterAccount);
                }

                var nachaConfig = (await context.NachaConfigs.GetAll()).FirstOrDefault();

                if (nachaConfig == null)
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("NachaConfig", "Unable to get NachaConfigs"));
                }
                logger.Warn($"EOD Settlement Ram 4");

                response = new NachaProcessingModel
                {
                    Config = new ApplicationCore.Domain.Nacha.NachaConfig
                    {
                        BankName = nachaConfig.Bank,
                        ImmediateOriginName = nachaConfig.AccountName,
                        AccountNo = nachaConfig.AccountNo,
                        RoutingNo = nachaConfig.RoutingNo,
                        BankRoutingNo = nachaConfig.ReceivingBankRoutingNo,
                        BatchCompanyName = masterAccount?.AccountName,
                        EffectiveEntryDate = query.EffectiveDate ?? DateTime.Now,
                        ProcessType = NachaProcessType.SETTLEMENT,
                    },
                    ProcessingEntities = new List<NachaProcessingEntity>()
                };

                foreach (var settlementRequest in settlementRequests)
                {
                    var transactions = await context.Transactions.GetEodTransactions(settlementRequest.SettlementRequestId);

                    var nachaProcessingEntity = new NachaProcessingEntity
                    {
                        Accounts = new List<NachaModel> { },
                        Entity = settlementRequest
                    };

                    response.ProcessingEntities.Add(nachaProcessingEntity);

                    if (transactions == null || !transactions.Any())
                    {
                        continue;
                    }

                    StoreConfigModel storeConfig = null;
                    if (storeConfigs.Data.Where(t => t.StoreId == settlementRequest.StoreId).Count()>0)
                    {
                        storeConfig = storeConfigs.Data.FirstOrDefault(t => t.StoreId == settlementRequest.StoreId);
                    }

                    if (storeConfig == null)
                    {
                        throw new ExecutionException($"Unable to get StoreConfig for store id ({settlementRequest.StoreId}) for SettlementRequestId = {settlementRequest.SettlementRequestId}");
                    }
                    if (query.CardPayment == PaymentStatusEnum.Paid)
                    {
                        logger.Warn($"EOD Settlement Ram 1 CardPayment");
                        if (query.SettlementRequest.Count > 0)
                        {
                            List<long> transactionIds = new List<long>();
                            foreach (var itemt in query.SettlementRequest)
                            {
                                if (itemt.ConsumerProcess != false && itemt.MerchantProcess != false)
                                {
                                    transactionIds.Add(itemt.TransactionId);
                                }
                                if (itemt.MerchantProcess == true)
                                {
                                    transactionIds.Add(itemt.TransactionId);
                                }
                            }
                            string tranIds = string.Join(", ", transactionIds);

                            logger.Warn($"EOD Settlement Ram 1 CardPayment TransId:" + tranIds);


                            var cardTransactions = transactions.
                            Where(t => t.CardAmount > 0
                            && t.PaymentMethodId == (int)EventBus.DomainEvents.Enums.EnumPaymentMethod.CreditCard).
                            Where(transactions => transactionIds.Contains(transactions.TransactionId)).Where(t=>t.MerchantPay != true).ToList();

                            if (cardTransactions.Any())
                            {
                                logger.Warn($"EOD Settlement Ram 2 cardTransactions");

                                settlementRequest.CardPaymentStatusId = (int)PaymentStatusEnum.Paid;
                                foreach (var transactionDtl in cardTransactions)
                                {
                                    logger.Warn($"EOD Settlement Ram 2 cardTransactions Id :" + transactionDtl.TransactionId);

                                    nachaProcessingEntity.Accounts.Add(new NachaModel
                                    {
                                        BatchCompanyName = storeConfig.AccountName.Length > 16 ? storeConfig.AccountName.Substring(0, 16) : storeConfig.AccountName,
                                        AccountEntityId = transactionDtl.TransactionId,
                                        TransactionCodeType = TransactionCodeType.Credit,
                                        ProcessingAccount = new NachaAccount
                                        {
                                            BankName = storeConfig.Bank,
                                            AccountName = storeConfig.AccountName,
                                            AccountNo = storeConfig.AccountNo,
                                            RoutingNo = storeConfig.RoutingNo,
                                            AccountType = storeConfig.IsChecking ? AccountType.Checking : AccountType.Savings,
                                        },
                                        Amount = transactionDtl.CardAmount,
                                        AmountType = AmountType.CreditDebit,
                                        IdentificationNumber = "CR" + transactionDtl.TransactionId.ToString(string.Concat(Enumerable.Repeat("0", 10))),
                                    });
                                }

                                logger.Warn($"EOD Settlement Ram 2 cardTransactions count :" + nachaProcessingEntity.Accounts.Count());

                                logger.Warn($"EOD Settlement Ram 2 cardTransactions end");
                            }
                        }
                    }

                    if (query.CashRewardPayment == PaymentStatusEnum.Paid)
                    {
                        var cashRewardTransactions = transactions.Where(t => t.WalletAmount > 0).ToList();

                        if (cashRewardTransactions.Any())
                        {
                            settlementRequest.CashRewardPaymentStatusId = (int)PaymentStatusEnum.Paid;

                            foreach (var cashRewardTransaction in cashRewardTransactions)
                            {
                                nachaProcessingEntity.Accounts.Add(new NachaModel
                                {
                                    AccountEntityId = cashRewardTransaction.TransactionId,
                                    TransactionCodeType = TransactionCodeType.Credit,
                                    ProcessingAccount = new NachaAccount
                                    {
                                        BankName = storeConfig.Bank,
                                        AccountName = storeConfig.AccountName,
                                        AccountNo = storeConfig.AccountNo,
                                        RoutingNo = storeConfig.RoutingNo,
                                        AccountType = storeConfig.IsChecking ? AccountType.Checking : AccountType.Savings,
                                    },
                                    Amount = cashRewardTransaction.WalletAmount,
                                    AmountType = AmountType.CashReward,
                                    IdentificationNumber = "CR" + cashRewardTransaction.TransactionId.ToString(string.Concat(Enumerable.Repeat("0", 10))),
                                });
                            }
                        }
                    }

                    if (query.AchPayment == PaymentStatusEnum.Paid)
                    {
                        logger.Warn($"EOD Settlement Ram 5");

                        if (query.SettlementRequest != null)
                        {
                            List<long> transactionIds = new List<long>();
                            foreach (var itemt in query.SettlementRequest)
                            {
                                if (itemt.ConsumerProcess != false && itemt.MerchantProcess != false)
                                {
                                    transactionIds.Add(itemt.TransactionId);
                                }
                            }
                            var achTransactions = transactions.
                                Where(t => t.CardAmount > 0
                            && t.PaymentMethodId == (int)EventBus.DomainEvents.Enums.EnumPaymentMethod.ACH
                            ).Where(transactions => transactionIds.Contains(transactions.TransactionId)).ToList();

                            logger.Warn($"EOD Settlement Ram 6");

                            if (achTransactions.Any())
                            {
                                settlementRequest.AchPaymentStatusId = (int)PaymentStatusEnum.Paid;
                                var userPaymentMethodIds = achTransactions.Select(t => t.UserPaymentMethodId ?? 0).Distinct().ToList();

                                if (userPaymentMethodIds != null && userPaymentMethodIds.Any())
                                {
                                    var userPaymentMethods = await paymentClient.GetAsync(userPaymentMethodIds, cancellationToken);

                                    foreach (var achTransaction in achTransactions)
                                    {
                                        var merchantProcess = query.SettlementRequest.Where(x => x.TransactionId == achTransaction.TransactionId).FirstOrDefault().MerchantProcess;
                                        var consumerProcess = query.SettlementRequest.Where(x => x.TransactionId == achTransaction.TransactionId).FirstOrDefault().ConsumerProcess;
                                        

                                        var userPaymentMethod = userPaymentMethods.FirstOrDefault(t => t.UserPaymentMethodId == achTransaction.UserPaymentMethodId);

                                        if (merchantProcess == true && consumerProcess == false)
                                        {
                                            nachaProcessingEntity.Accounts.Add(new NachaModel
                                            {
                                                BatchCompanyName = storeConfig.AccountName.Length > 16 ? storeConfig.AccountName.Substring(0, 16) : storeConfig.AccountName,
                                                AccountEntityId = achTransaction.TransactionId,
                                                TransactionCodeType = TransactionCodeType.Credit,
                                                ProcessingAccount = new NachaAccount
                                                {
                                                    BankName = storeConfig.Bank,
                                                    AccountName = storeConfig.AccountName,
                                                    AccountNo = storeConfig.AccountNo,
                                                    RoutingNo = storeConfig.RoutingNo,
                                                    AccountType = storeConfig.IsChecking ? AccountType.Checking : AccountType.Savings,
                                                },
                                                Amount = achTransaction.CardAmount,
                                                AmountType = AmountType.ACH,
                                                IdentificationNumber = "AC" + achTransaction.TransactionId.ToString(string.Concat(Enumerable.Repeat("0", 10))),
                                            });

                                        }
                                        if (merchantProcess == true && consumerProcess == true)
                                        {
                                            logger.Warn($"EOD Settlement Ram 7");

                                            nachaProcessingEntity.Accounts.Add(new NachaModel
                                            {
                                                BatchCompanyName = storeConfig.AccountName.Length > 16 ? storeConfig.AccountName.Substring(0, 16) : storeConfig.AccountName,
                                                AccountEntityId = achTransaction.TransactionId,
                                                TransactionCodeType = TransactionCodeType.Credit,
                                                ProcessingAccount = new NachaAccount
                                                {
                                                    BankName = storeConfig.Bank,
                                                    AccountName = storeConfig.AccountName,
                                                    AccountNo = storeConfig.AccountNo,
                                                    RoutingNo = storeConfig.RoutingNo,
                                                    AccountType = storeConfig.IsChecking ? AccountType.Checking : AccountType.Savings,
                                                },
                                                Amount = achTransaction.CardAmount,
                                                AmountType = AmountType.ACH,
                                                IdentificationNumber = "AC" + achTransaction.TransactionId.ToString(string.Concat(Enumerable.Repeat("0", 10))),
                                            });

                                            if (userPaymentMethod != null && !string.IsNullOrWhiteSpace(userPaymentMethod.AccountNumber))
                                            {
                                                logger.Warn($"EOD Settlement Ram 8");
                                                nachaProcessingEntity.Accounts.Add(new NachaModel
                                                {
                                                    BatchCompanyName = storeConfig.AccountName.Length > 16 ? storeConfig.AccountName.Substring(0, 16) : storeConfig.AccountName,
                                                    AccountEntityId = achTransaction.TransactionId,
                                                    TransactionCodeType = TransactionCodeType.Debit,
                                                    ProcessingAccount = new NachaAccount
                                                    {
                                                        BankName = userPaymentMethod.BankName,
                                                        AccountName = userPaymentMethod.AccountNumber,
                                                        AccountNo = userPaymentMethod.AccountNumber,
                                                        RoutingNo = userPaymentMethod.RoutingNumber,
                                                        AccountType = userPaymentMethod.AccountType.Equals("Checking", StringComparison.InvariantCultureIgnoreCase) ? AccountType.Checking : AccountType.Savings,
                                                    },
                                                    Amount = achTransaction.CardAmount,
                                                    AmountType = AmountType.ACH,
                                                    IdentificationNumber = "AD" + achTransaction.TransactionId.ToString(string.Concat(Enumerable.Repeat("0", 10))),
                                                });
                                            }
                                        }
                                        if (consumerProcess == true && merchantProcess == false)
                                        {
                                            if (userPaymentMethod != null && !string.IsNullOrWhiteSpace(userPaymentMethod.AccountNumber))
                                            {
                                                nachaProcessingEntity.Accounts.Add(new NachaModel
                                                {
                                                    BatchCompanyName = storeConfig.AccountName.Length > 16 ? storeConfig.AccountName.Substring(0, 16) : storeConfig.AccountName,
                                                    AccountEntityId = achTransaction.TransactionId,
                                                    TransactionCodeType = TransactionCodeType.Debit,
                                                    ProcessingAccount = new NachaAccount
                                                    {
                                                        BankName = userPaymentMethod.BankName,
                                                        AccountName = userPaymentMethod.AccountNumber,
                                                        AccountNo = userPaymentMethod.AccountNumber,
                                                        RoutingNo = userPaymentMethod.RoutingNumber,
                                                        AccountType = userPaymentMethod.AccountType.Equals("Checking", StringComparison.InvariantCultureIgnoreCase) ? AccountType.Checking : AccountType.Savings,
                                                    },
                                                    Amount = achTransaction.CardAmount,
                                                    AmountType = AmountType.ACH,
                                                    IdentificationNumber = "AD" + achTransaction.TransactionId.ToString(string.Concat(Enumerable.Repeat("0", 10))),
                                                });
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else 
                        {
                            // for Preview nacha file
                            var achTransactions = transactions.
                                Where(t => t.CardAmount > 0
                            && t.PaymentMethodId == (int)EventBus.DomainEvents.Enums.EnumPaymentMethod.ACH
                            ).ToList();

                            if (achTransactions.Any())
                            {
                                settlementRequest.AchPaymentStatusId = (int)PaymentStatusEnum.Paid;
                                var userPaymentMethodIds = achTransactions.Select(t => t.UserPaymentMethodId ?? 0).Distinct().ToList();

                                if (userPaymentMethodIds != null && userPaymentMethodIds.Any())
                                {
                                    var userPaymentMethods = await paymentClient.GetAsync(userPaymentMethodIds, cancellationToken);

                                    foreach (var achTransaction in achTransactions)
                                    {
                                        var merchantProcess = query.SettlementRequest.Where(x => x.TransactionId == achTransaction.TransactionId).FirstOrDefault().MerchantProcess;
                                        var consumerProcess = query.SettlementRequest.Where(x => x.TransactionId == achTransaction.TransactionId).FirstOrDefault().ConsumerProcess;


                                        var userPaymentMethod = userPaymentMethods.FirstOrDefault(t => t.UserPaymentMethodId == achTransaction.UserPaymentMethodId);

                                        if (merchantProcess == true && consumerProcess == false)
                                        {
                                            nachaProcessingEntity.Accounts.Add(new NachaModel
                                            {
                                                BatchCompanyName = storeConfig.AccountName.Length > 16 ? storeConfig.AccountName.Substring(0, 16) : storeConfig.AccountName,
                                                AccountEntityId = achTransaction.TransactionId,
                                                TransactionCodeType = TransactionCodeType.Credit,
                                                ProcessingAccount = new NachaAccount
                                                {
                                                    BankName = storeConfig.Bank,
                                                    AccountName = storeConfig.AccountName,
                                                    AccountNo = storeConfig.AccountNo,
                                                    RoutingNo = storeConfig.RoutingNo,
                                                    AccountType = storeConfig.IsChecking ? AccountType.Checking : AccountType.Savings,
                                                },
                                                Amount = achTransaction.CardAmount,
                                                AmountType = AmountType.ACH,
                                                IdentificationNumber = "AC" + achTransaction.TransactionId.ToString(string.Concat(Enumerable.Repeat("0", 10))),
                                            });

                                        }
                                        if (merchantProcess == true && consumerProcess == true)
                                        {
                                            nachaProcessingEntity.Accounts.Add(new NachaModel
                                            {
                                                BatchCompanyName = storeConfig.AccountName.Length > 16 ? storeConfig.AccountName.Substring(0, 16) : storeConfig.AccountName,
                                                AccountEntityId = achTransaction.TransactionId,
                                                TransactionCodeType = TransactionCodeType.Credit,
                                                ProcessingAccount = new NachaAccount
                                                {
                                                    BankName = storeConfig.Bank,
                                                    AccountName = storeConfig.AccountName,
                                                    AccountNo = storeConfig.AccountNo,
                                                    RoutingNo = storeConfig.RoutingNo,
                                                    AccountType = storeConfig.IsChecking ? AccountType.Checking : AccountType.Savings,
                                                },
                                                Amount = achTransaction.CardAmount,
                                                AmountType = AmountType.ACH,
                                                IdentificationNumber = "AC" + achTransaction.TransactionId.ToString(string.Concat(Enumerable.Repeat("0", 10))),
                                            });

                                            if (userPaymentMethod != null && !string.IsNullOrWhiteSpace(userPaymentMethod.AccountNumber))
                                            {
                                                nachaProcessingEntity.Accounts.Add(new NachaModel
                                                {
                                                    BatchCompanyName = storeConfig.AccountName.Length > 16 ? storeConfig.AccountName.Substring(0, 16) : storeConfig.AccountName,
                                                    AccountEntityId = achTransaction.TransactionId,
                                                    TransactionCodeType = TransactionCodeType.Debit,
                                                    ProcessingAccount = new NachaAccount
                                                    {
                                                        BankName = userPaymentMethod.BankName,
                                                        AccountName = userPaymentMethod.AccountNumber,
                                                        AccountNo = userPaymentMethod.AccountNumber,
                                                        RoutingNo = userPaymentMethod.RoutingNumber,
                                                        AccountType = userPaymentMethod.AccountType.Equals("Checking", StringComparison.InvariantCultureIgnoreCase) ? AccountType.Checking : AccountType.Savings,
                                                    },
                                                    Amount = achTransaction.CardAmount,
                                                    AmountType = AmountType.ACH,
                                                    IdentificationNumber = "AD" + achTransaction.TransactionId.ToString(string.Concat(Enumerable.Repeat("0", 10))),
                                                });
                                            }
                                        }
                                        if (consumerProcess == true && merchantProcess == false)
                                        {
                                            if (userPaymentMethod != null && !string.IsNullOrWhiteSpace(userPaymentMethod.AccountNumber))
                                            {
                                                nachaProcessingEntity.Accounts.Add(new NachaModel
                                                {
                                                    BatchCompanyName = storeConfig.AccountName.Length > 16 ? storeConfig.AccountName.Substring(0, 16) : storeConfig.AccountName,
                                                    AccountEntityId = achTransaction.TransactionId,
                                                    TransactionCodeType = TransactionCodeType.Debit,
                                                    ProcessingAccount = new NachaAccount
                                                    {
                                                        BankName = userPaymentMethod.BankName,
                                                        AccountName = userPaymentMethod.AccountNumber,
                                                        AccountNo = userPaymentMethod.AccountNumber,
                                                        RoutingNo = userPaymentMethod.RoutingNumber,
                                                        AccountType = userPaymentMethod.AccountType.Equals("Checking", StringComparison.InvariantCultureIgnoreCase) ? AccountType.Checking : AccountType.Savings,
                                                    },
                                                    Amount = achTransaction.CardAmount,
                                                    AmountType = AmountType.ACH,
                                                    IdentificationNumber = "AD" + achTransaction.TransactionId.ToString(string.Concat(Enumerable.Repeat("0", 10))),
                                                });
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            logger.TraceExitMethod(nameof(Handle), response);
            logger.Warn($"EOD Settlement Ram 9");
            var res = response.ProcessingEntities.Count();
            logger.Warn($"EOD Settlement Ram 9 ProcessingEntities: " + res);

            return response;
        }
    }
}
