﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetTransactionsByDateRange
{
    public class GetTransactionsByDateRangeValidator : AbstractValidator<GetTransactionsByDateRangeQuery>
    {
        public GetTransactionsByDateRangeValidator()
        {
            RuleFor(x => x.FromDate).NotNull().NotEmpty().GreaterThan(new System.DateTime(2021, 1, 1)).WithMessage("Invalid Date. Transaction does not exist");
            RuleFor(x => x.FromDate).NotNull().NotEmpty().GreaterThan(new System.DateTime(2021, 1, 1)).WithMessage("Invalid Date. Transaction does not exist");
        }
    }
}
