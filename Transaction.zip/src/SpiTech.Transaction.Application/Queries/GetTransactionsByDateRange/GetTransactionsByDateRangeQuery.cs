﻿using MediatR;
using SpiTech.Transaction.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetTransactionsByDateRange
{
    public class GetTransactionsByDateRangeQuery : IRequest<IEnumerable<TransactionModel>>
    {
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        
    }
}
