﻿using MediatR;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetAllResellerMonthlyInvoicePdf
{
    public class GetAllResellerMonthlyInvoicePdfQuery : IRequest<InvoiceFileBytesModel>
    {
        public bool? IsNeedReview { get; set; }
        public bool? IsPaid { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
    }
}
