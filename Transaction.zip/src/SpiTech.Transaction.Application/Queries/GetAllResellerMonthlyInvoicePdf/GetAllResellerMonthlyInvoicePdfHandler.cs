﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.Services;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetAllResellerMonthlyInvoicePdf
{
    public class GetAllResellerMonthlyInvoicePdfHandler : IRequestHandler<GetAllResellerMonthlyInvoicePdfQuery, InvoiceFileBytesModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetAllResellerMonthlyInvoicePdfHandler> logger;
        private readonly IStoreServiceClient _storeapiclient;
        private readonly IFinanceServiceClient _financeapiclient;
        private readonly IPaymentServiceClient _paymentapiclient;
        private readonly IHtmlPdfConverterService converterService;

        public GetAllResellerMonthlyInvoicePdfHandler(IUnitOfWork context,
                                                ILogger<GetAllResellerMonthlyInvoicePdfHandler> logger,
                                                IStoreServiceClient storeapiclient,
                                                IFinanceServiceClient financeapiclient,
                                                IPaymentServiceClient paymentapiclient,
                                                IHtmlPdfConverterService converterService
                                    )
        {
            this.context = context;
            this.logger = logger;
            _storeapiclient = storeapiclient;
            _financeapiclient = financeapiclient;
            _paymentapiclient = paymentapiclient;
            this.converterService = converterService;
        }

        public async Task<InvoiceFileBytesModel> Handle(GetAllResellerMonthlyInvoicePdfQuery request, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), request);

            var result = await context.ResellerBillings.GetBills(0, 0, request.Month, request.Year, request.IsNeedReview, request.IsPaid, null, null);

            if (result == null || !result.Any())
            {
                return null;
            }

            var resellers = (await _storeapiclient.ResellersAsync(result.Select(t=>t.ResellerId).Distinct(), cancellationToken));

            foreach(var resellerBilling in result)
            {
                var reseller= resellers.FirstOrDefault(t=> t.ResellerId == resellerBilling.ResellerId);

                if(reseller != null)
                {
                    resellerBilling.ResellerName = reseller?.FirstName + " " + reseller?.LastName;
                }
            }

            ResellerBillingListModel resellerBillingList = new ResellerBillingListModel { };
            resellerBillingList.ResellerBillings = result;

            var response = new InvoiceFileBytesModel();
            response.Bytes = await this.converterService.CreatePdfFromView("AllResellerMonthlyInvoice", resellerBillingList);
            response.File = "AllResellerMonthlyInvoice.pdf";

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
