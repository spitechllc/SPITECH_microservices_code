﻿using MediatR;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetAllStoreMonthlyInvoicePdf
{
    public class GetAllStoreMonthlyInvoicePdfQuery : IRequest<InvoiceFileBytesModel>
    {
        public int? StoreId { get; set; }
        public bool? IsNeedReview { get; set; }
        public bool? IsPaid { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
    }
}
