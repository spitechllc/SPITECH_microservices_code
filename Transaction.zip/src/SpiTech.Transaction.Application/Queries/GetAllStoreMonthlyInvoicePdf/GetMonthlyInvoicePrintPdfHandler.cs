﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.Services;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetAllStoreMonthlyInvoicePdf
{
    public class GetAllStoreMonthlyInvoicePdfHandler : IRequestHandler<GetAllStoreMonthlyInvoicePdfQuery, InvoiceFileBytesModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetAllStoreMonthlyInvoicePdfHandler> logger;
        private readonly IStoreServiceClient _storeapiclient;
        private readonly IFinanceServiceClient _financeapiclient;
        private readonly IPaymentServiceClient _paymentapiclient;
        private readonly IHtmlPdfConverterService converterService;

        public GetAllStoreMonthlyInvoicePdfHandler(IUnitOfWork context,
                                                ILogger<GetAllStoreMonthlyInvoicePdfHandler> logger,
                                                IStoreServiceClient storeapiclient,
                                                IFinanceServiceClient financeapiclient,
                                                IPaymentServiceClient paymentapiclient,
                                                IHtmlPdfConverterService converterService

                                    )
        {
            this.context = context;
            this.logger = logger;
            _storeapiclient = storeapiclient;
            _financeapiclient = financeapiclient;
            _paymentapiclient = paymentapiclient;
            this.converterService = converterService;
        }

        public async Task<InvoiceFileBytesModel> Handle(GetAllStoreMonthlyInvoicePdfQuery query, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), query);

            List<StoreBillingModel> result = await context.StoreBillings.GetBills(0, 0, query.StoreId, query.Month, query.Year, query.IsNeedReview, query.IsPaid, null, null, true);

            if (result == null || !result.Any())
            {
                return null;
            }

            StoreBillingListModel storeBillingListModel = new StoreBillingListModel { };
            storeBillingListModel.StoreBillings = result;

            var response = new InvoiceFileBytesModel();
            response.Bytes = await this.converterService.CreatePdfFromView("AllStoreMonthlyInvoice", storeBillingListModel, WkHtmlToPdfDotNet.PaperKind.A3);
            response.File = "AllStoreMonthlyInvoice.pdf";

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
