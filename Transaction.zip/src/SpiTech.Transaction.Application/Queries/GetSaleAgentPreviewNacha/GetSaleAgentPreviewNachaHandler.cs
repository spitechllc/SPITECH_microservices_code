﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using SpiTech.ApplicationCore.Nacha;
using SpiTech.Transaction.Application.Queries.GetNachaSaleAgentBillingProcessingAccount;
using SpiTech.Transaction.Application.UnitOfWorks;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetSaleAgentPreviewNacha
{
    public class GetSaleAgentPreviewNachaHandler : IRequestHandler<GetSaleAgentPreviewNachaQuery, NachaFileBytesModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetSaleAgentPreviewNachaHandler> logger;
        private readonly IMediator mediator;
        private readonly INachaFileBuilder nachaFileBuilder;

        public GetSaleAgentPreviewNachaHandler(IUnitOfWork context,
                                    ILogger<GetSaleAgentPreviewNachaHandler> logger,
                                    IMediator mediator,
                                    INachaFileBuilder nachaFileBuilder)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            this.nachaFileBuilder = nachaFileBuilder;
        }

        public async Task<NachaFileBytesModel> Handle(GetSaleAgentPreviewNachaQuery query, CancellationToken cancellationToken)
        {
            NachaFileBytesModel response = null;
            logger.TraceEnterMethod(nameof(Handle), query);

            NachaProcessingModel nachaProcessingModel = await mediator.Send(new GetNachaSaleAgentBillingProcessingAccountQuery
            {
                Year = query.Year,
                Month = query.Month,
                IsPreview = true
            });

            if (nachaProcessingModel != null && nachaProcessingModel.ProcessingEntities != null && nachaProcessingModel.ProcessingEntities.Any())
            {
                response = new NachaFileBytesModel();

                response = nachaFileBuilder.GetBytes(nachaProcessingModel.Config, nachaProcessingModel.ProcessingEntities.SelectMany(t => t.Accounts).ToList());
            }

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
