﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Nacha;

namespace SpiTech.Transaction.Application.Queries.GetSaleAgentPreviewNacha
{
    public class GetSaleAgentPreviewNachaQuery : IRequest<NachaFileBytesModel>
    {
        public int Month { get; set; }
        public int Year { get; set; }
    }
}
