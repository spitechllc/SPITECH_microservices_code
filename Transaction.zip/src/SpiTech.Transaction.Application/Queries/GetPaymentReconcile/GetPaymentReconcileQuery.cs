﻿using MediatR;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetPaymentReconcile
{
    public class GetPaymentReconcileQuery : IRequest<PaginatedList<TransactionModel>>
    {
        public int PageIndex { get; set; }

        public int PageSize { get; set; }

        public long LastTransactionId { get; set; }
    }
}
