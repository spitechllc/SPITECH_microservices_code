﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetPaymentReconcile
{
    public class GetPaymentReconcileHandler : IRequestHandler<GetPaymentReconcileQuery, PaginatedList<TransactionModel>>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<GetPaymentReconcileHandler> _logger;
        private readonly IMapper _mapper;
        public GetPaymentReconcileHandler(IUnitOfWork context,
                                             ILogger<GetPaymentReconcileHandler> logger,
                                             IMapper mapper
                                           )
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<PaginatedList<TransactionModel>> Handle(GetPaymentReconcileQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            System.Collections.Generic.List<TransactionModel> result = await _context.Transactions.PaymentReconcile(
                   request.PageIndex, request.PageSize, request.LastTransactionId);
            _logger.TraceExitMethod(nameof(Handle), result);

            int totalrecord = 0;
            if (result != null && result.Count() > 0)
            {
                totalrecord = result.Select(x => x.TotalRecord).FirstOrDefault();
            }

            return new PaginatedList<TransactionModel>
            {
                Data = result.ToList(),
                PageIndex = request.PageIndex,
                PageSize = request.PageSize,
                TotalCount = totalrecord
            };
        }
    }
}
