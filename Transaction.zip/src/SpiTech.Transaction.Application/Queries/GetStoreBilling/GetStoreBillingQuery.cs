﻿using MediatR;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetStoreBilling
{
    public class GetStoreBillingQuery : IRequest<StoreBillingPaginatedList>
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public int? StoreId { get; set; }
        public bool? IsNeedReview { get; set; }
        public bool? IsPaid { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public StoreBillingSortBy? SortBy { get; set; }
        public SortOrderEnum? SortOrder { get; set; }
    }
}
