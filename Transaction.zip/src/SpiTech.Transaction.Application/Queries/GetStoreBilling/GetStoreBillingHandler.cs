﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetStoreBilling
{
    public class GetStoreBillingHandler : IRequestHandler<GetStoreBillingQuery, StoreBillingPaginatedList>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetStoreBillingHandler> _logger;
        private readonly IMapper _mapper;

        public GetStoreBillingHandler(IUnitOfWork context,
                                    ILogger<GetStoreBillingHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<StoreBillingPaginatedList> Handle(GetStoreBillingQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            //StoreBillingAggregateModel aggregateResult = null;

            List<StoreBillingModel> result = await _context.StoreBillings.GetBills(request.PageIndex, request.PageSize, request.StoreId, request.Month, request.Year, request.IsNeedReview, request.IsPaid, request.SortBy, request.SortOrder, true);

            //if (result != null && result.Count() > 0)
            //{
            //    aggregateResult = await _context.StoreBillings.GeStoreAggregatetBills(request.StoreId, request.Month, request.Year, request.IsNeedReview, request.IsPaid);
            //    totalrecord = result.Select(x => x.TotalRecord).FirstOrDefault();
            //}

            StoreBillingPaginatedList response = new()
            {
                Data = result.ToList(),
                PageIndex = request.PageIndex,
                PageSize = request.PageSize,
                TotalCount = result?.Select(x => x.TotalRecord).FirstOrDefault() ?? 0,
                TotalFee = result?.Sum(t=>t.TotalFee) ?? 0,
                TotalMonthlySaasFee = result?.Sum(t => t.MonthlySaasFee) ?? 0,
                TotalTransactionAmount = result?.Sum(t => t.TransactionAmount) ?? 0,
                TotalTransactionCount = result?.Sum(t => t.TransactionCount) ?? 0,
                TotalTransactionFee = result?.Sum(t => t.TransactionFee) ?? 0,
                TotalTransactionPercentageFee = result?.Sum(t => t.TransactionPercentageFee) ?? 0,
                WalletTransactionAmount = result?.Sum(t => t.WalletTransactionAmount) ?? 0,
                WalletTransactionCount = result?.Sum(t => t.WalletTransactionCount) ?? 0,
                WalletTransactionFee = result?.Sum(t => t.WalletTransactionFee) ?? 0,
                WalletTransactionPercentageFee = result?.Sum(t => t.WalletTransactionPercentageFee) ?? 0,
                CardTransactionAmount = result?.Sum(t => t.CardTransactionAmount) ?? 0,
                CardTransactionCount = result?.Sum(t => t.CardTransactionCount) ?? 0,
                CardTransactionFee = result?.Sum(t => t.CardTransactionFee) ?? 0,
                CardTransactionPercentageFee = result?.Sum(t => t.CardTransactionPercentageFee) ?? 0,
                AchTransactionAmount = result?.Sum(t => t.AchTransactionAmount) ?? 0,
                AchTransactionCount = result?.Sum(t => t.AchTransactionCount) ?? 0,
                AchTransactionFee = result?.Sum(t => t.AchTransactionFee) ?? 0,
                AchTransactionPercentageFee = result?.Sum(t => t.AchTransactionPercentageFee) ?? 0,
            };

            _logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
