﻿using MediatR;

namespace SpiTech.Transaction.Application.Queries.GetTransactionByTransactionId
{
    public class GetTransactionByTransactionIdQuery : IRequest<Domain.Entities.Transaction>
    {
        public long TransactionId { get; set; }
    }
}
