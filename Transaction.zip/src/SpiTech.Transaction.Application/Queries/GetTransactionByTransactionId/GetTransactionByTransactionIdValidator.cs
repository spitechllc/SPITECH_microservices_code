﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetTransactionByTransactionId
{
    public class GetTransactionByTransactionIdValidator : AbstractValidator<GetTransactionByTransactionIdQuery>
    {
        public GetTransactionByTransactionIdValidator()
        {
            RuleFor(x => x.TransactionId).GreaterThan(0).WithMessage("TransactionId required");
        }
    }
}
