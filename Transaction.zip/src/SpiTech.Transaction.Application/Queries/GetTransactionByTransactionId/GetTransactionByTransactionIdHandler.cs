﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetTransactionByTransactionId
{
    public class GetTransactionByTransactionIdHandler :
        IRequestHandler<GetTransactionByTransactionIdQuery, Domain.Entities.Transaction>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetTransactionByTransactionIdHandler> _logger;
        private readonly IMapper _mapper;

        public GetTransactionByTransactionIdHandler(IUnitOfWork context,
                                             ILogger<GetTransactionByTransactionIdHandler> logger,
                                             IMapper mapper
                                             )
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<Domain.Entities.Transaction> Handle(GetTransactionByTransactionIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            Domain.Entities.Transaction result = await _context.Transactions.Get(request.TransactionId);

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
