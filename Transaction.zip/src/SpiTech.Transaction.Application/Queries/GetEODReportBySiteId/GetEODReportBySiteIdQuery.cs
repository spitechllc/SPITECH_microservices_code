﻿using MediatR;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models;
using System;

namespace SpiTech.Transaction.Application.Queries.GetEODReportBySiteId
{
    public class GetEODReportBySiteIdQuery : IRequest<EodSettlementPaginatedList>
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public int? StoreId { get; set; }
        public DateTime StartDateUtc { get; set; }
        public DateTime EndDateUtc { get; set; }
        public PaymentStatusEnum? CardPayment { get; set; }
        public PaymentStatusEnum? CashRewardPayment { get; set; }
        public PaymentStatusEnum? AchPayment { get; set; }
        public bool? HasTransaction { get; set; }
        public bool? IsAmountMached { get; set; }
        public EodReportSortBy? SortBy { get; set; }
        public SortOrderEnum? SortOrder { get; set; }
    }
}
