﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetEODReportBySiteId
{
    public class GetEODReportBySiteIdHandler : IRequestHandler<GetEODReportBySiteIdQuery, EodSettlementPaginatedList>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetEODReportBySiteIdHandler> logger;
        private readonly IMediator mediator;
        private readonly IStoreServiceClient _storeapiclient;
        private readonly IFinanceServiceClient _financeapiclient;
        private readonly IPaymentServiceClient _paymentapiclient;

        public GetEODReportBySiteIdHandler(IUnitOfWork context,
                                    ILogger<GetEODReportBySiteIdHandler> logger,
                                    IMediator mediator
            , IStoreServiceClient storeapiclient
            , IFinanceServiceClient financeapiclient
            , IPaymentServiceClient paymentapiclient)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            _storeapiclient = storeapiclient;
            _financeapiclient = financeapiclient;
            _paymentapiclient = paymentapiclient;
        }
        public async Task<EodSettlementPaginatedList> Handle(GetEODReportBySiteIdQuery query, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), query);

            EodSettlementReportAggregateModel aggregateResult = null;

            List<EodSettlementReportModel> result = await context.SettlementRequests.GetEODReport(query.PageIndex,
                query.PageSize,
                query.StoreId,
                query.StartDateUtc,
                query.EndDateUtc,
                query.CardPayment,
                query.CashRewardPayment,
                query.AchPayment,
                query.HasTransaction,
                query.IsAmountMached,
                query.SortBy,
                query.SortOrder);

            int totalrecord = 0;

            if (result != null && result.Count() > 0)
            {
                aggregateResult = await context.SettlementRequests.GetAggregatetEODReport(query.StoreId, 
                    query.StartDateUtc, 
                    query.EndDateUtc,
                    query.CardPayment,
                    query.CashRewardPayment,
                    query.AchPayment,
                    query.HasTransaction, 
                    query.IsAmountMached);

                totalrecord = result.Select(x => x.TotalRecord).FirstOrDefault();
            }

            EodSettlementPaginatedList response = new()
            {
                Data = result.ToList(),
                PageIndex = query.PageIndex,
                PageSize = query.PageSize,
                TotalCount = totalrecord,
                TotalTerminalTotalAmount = aggregateResult?.TotalTerminalTotalAmount ?? 0,
                TotalMppaTotalAmount = aggregateResult?.TotalMppaTotalAmount ?? 0,
                TotalCashRewardAmount = aggregateResult?.TotalCashRewardAmount ?? 0,
                TotalAchAmount = aggregateResult?.TotalAchAmount ?? 0,
                TotalCardAmount = aggregateResult?.TotalCardAmount ?? 0,
                TotalTerminalCounts = aggregateResult?.TotalTerminalCounts ?? 0,
                TotalMppaCounts = aggregateResult?.TotalMppaCounts ?? 0,
            };

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
