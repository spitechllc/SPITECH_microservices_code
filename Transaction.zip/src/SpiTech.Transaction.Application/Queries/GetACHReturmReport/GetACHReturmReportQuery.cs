﻿using MediatR;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models;
using System;

namespace SpiTech.Transaction.Application.Queries.GetACHReturmReport
{
    public class GetACHReturmReportQuery : IRequest<PaginatedList<ACHReturnReportModel>>
    {
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public int? PageIndex { get; set; }
        public int? PageSize { get; set; }
        public ACHReturnSortBy? SortBy { get; set; }
        public SortOrderEnum? SortOrder { get; set; }
    }
}
