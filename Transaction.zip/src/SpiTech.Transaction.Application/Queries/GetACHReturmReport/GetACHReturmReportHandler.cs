﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Service.Clients.Payments;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetACHReturmReport
{
    public class GetACHReturmReportHandler : IRequestHandler<GetACHReturmReportQuery, PaginatedList<ACHReturnReportModel>>
    {
        private readonly ILogger<GetACHReturmReportHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;

        public GetACHReturmReportHandler(
                                    ILogger<GetACHReturmReportHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper)
        {
            _logger = logger;
            _context = context;
            _mapper = mapper;
        }

        public async Task<PaginatedList<ACHReturnReportModel>> Handle(GetACHReturmReportQuery request, CancellationToken cancellationToken)
        {
            List<ACHReturnReportModel> result =
            await _context.FnboReturnTransactions.ACHReturnReport(request.FromDate,request.ToDate, request.PageIndex, request.PageSize,request.SortBy,request.SortOrder);
            
            int totalRecord = 0;
            if (result != null && result.Count() > 0)
            {
                
                totalRecord = result.Select(x => x.TotalRecord).FirstOrDefault();
                
            }
            return new PaginatedList<ACHReturnReportModel>
            {
                Data = result,
                PageIndex = request.PageIndex??0,
                PageSize = request.PageSize ?? 0,
                TotalCount = totalRecord,
            };
        }

    }
}
