﻿using AutoMapper;
using MediatR;
using Newtonsoft.Json.Linq;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Service.Clients.Identity;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using Serilog.Formatting.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace SpiTech.Transaction.Application.Queries.GetDashboardConsumersProfileDetails
{
    public class GetDashboardConsumersProfileDetailsHandler : IRequestHandler<GetDashboardConsumersProfileDetailsQuery, ResponseModel<DashboardConsumersProfileModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetDashboardConsumersProfileDetailsHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IIdentityServiceClient _identityServiceClient;
        private readonly IPaymentServiceClient _paymentServiceClient;

        public GetDashboardConsumersProfileDetailsHandler(IUnitOfWork context,
                                    ILogger<GetDashboardConsumersProfileDetailsHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper,
                                    IIdentityServiceClient identityServiceClient,
                                    IPaymentServiceClient paymentServiceClient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _identityServiceClient = identityServiceClient;
            _paymentServiceClient = paymentServiceClient;
        }
        public async Task<ResponseModel<DashboardConsumersProfileModel>> Handle(GetDashboardConsumersProfileDetailsQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            ResponseModel<DashboardConsumersProfileModel> res = new() { Success = false };
            var result = new DashboardConsumersProfileModel();
           
            IEnumerable<UserModel> userList = _mapper.Map<IEnumerable<UserModel>>(await _identityServiceClient.GetUserByDateAsync(query.StartDate, query.EndDate));

            result.ProfilesCurrentCreated = userList.Count();
            result.consumerCurrentProfileData = userList;

            DateTime startDate = query.StartDate.Value.Date.AddDays(-7);
            DateTime endDate = query.EndDate.Value.Date.AddDays(1).AddSeconds(-1);

            IEnumerable<UserModel> lastSevenDaysUser = _mapper.Map<IEnumerable<UserModel>>(await _identityServiceClient.GetLast7daysUserAsync(startDate, endDate));

            result.ProfilesLast7DaysCreated = lastSevenDaysUser.Count();
            result.consumerProfileLast7daysData = lastSevenDaysUser;

            IEnumerable<int> userIds = lastSevenDaysUser.Select(t => t.UserId).Distinct();

            if (userIds.Count() > 0)
            {
                List<DashboardProfileWithTransaction> last7ProfileWithTransaction = await _context.Transactions.GetConsumerListFor7DaysTranDashboard(userIds);

                foreach (var item in last7ProfileWithTransaction)
                {
                    var id = item.UserId;
                    item.UserName = lastSevenDaysUser.Where(t => t.UserId == item.UserId)?.FirstOrDefault().DisplayName;
                    item.FirstName = lastSevenDaysUser.Where(t => t.UserId == item.UserId)?.FirstOrDefault().FirstName;
                    item.LastName = lastSevenDaysUser.Where(t => t.UserId == item.UserId)?.FirstOrDefault().LastName;
                    item.Email = lastSevenDaysUser.Where(t => t.UserId == item.UserId)?.FirstOrDefault().Email;
                    item.DeviceType = lastSevenDaysUser.Where(t => t.UserId == item.UserId)?.FirstOrDefault().DeviceType;
                }
                result.profileWithTransaction = last7ProfileWithTransaction;
                result.ProfileWithTransactionCount = last7ProfileWithTransaction.Count();

                IEnumerable<int> distinctUserIdsWithTransaction = last7ProfileWithTransaction.Select(t => t.UserId).Distinct();
                var newProfileNoTranIds = userIds.Except(distinctUserIdsWithTransaction);

                IEnumerable<UserModel> newPofileNoTransactionData = _mapper.Map<IEnumerable<UserModel>>(await _identityServiceClient.GetUserListForProfileAsync(newProfileNoTranIds));
                string log =   string.Join(",", newProfileNoTranIds);
                _logger.Warn("GetUserListForProfileAsync newProfileNoTranIds", log);

                var profileWithoutTransaction = new List<DashboardProfileWithTransaction>();
                foreach (var item in newPofileNoTransactionData)
                {
                    profileWithoutTransaction.Add(new DashboardProfileWithTransaction { UserId = item.UserId, UserName = item.UserName, FirstName = item.FirstName, LastName = item.LastName, Email=item.Email, FinalAmount="0", StoreName="", DeviceType="", CreatedOn = item.CreatedOn.Value.DateTime });
                }
                result.profileWithoutTransaction = profileWithoutTransaction;
                result.ProfileWithoutTransactionCount = profileWithoutTransaction.Count();
            }

            var UserPaymentMethod = await _paymentServiceClient.GetUserWithPaymentMethodAsync();
            IEnumerable<int> userIdWithPayment = UserPaymentMethod.Data.Select(s => s.UserId).Distinct();
            IEnumerable<User> profilesWithoutMOP = _mapper.Map<IEnumerable<User>>(await _identityServiceClient.GetUserWithNoPaymentMethodAsync(userIdWithPayment));
            result.usersProfileswithoutMOP = profilesWithoutMOP;
            result.usersProfilesWithoutMOPCount = profilesWithoutMOP.Count();

            var repeatConsumerTran = await _context.Transactions.GetTransactionUserId(query.StartDate, query.EndDate);
            IEnumerable<int> userIdsRepeatTran = repeatConsumerTran.Select(t => t.UserId).Distinct();
            IEnumerable<UserModel> userListRepeatTran = _mapper.Map<IEnumerable<UserModel>>(await _identityServiceClient.GetUserListAsync(userIdsRepeatTran));
            result.repeatConsumerTranDataCount = userListRepeatTran.Count();
            result.repeatConsumerTranData = userListRepeatTran;

            _logger.TraceExitMethod(nameof(Handle), res);

            res.Data = result;
            return res;
        }
    }
}
