﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetDashboardConsumersProfileDetails
{
    public class GetDashboardConsumersProfileDetailsModel
    {
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
    public class GetDashboardConsumersProfileDetailsQuery : GetDashboardConsumersProfileDetailsModel, IRequest<ResponseModel<DashboardConsumersProfileModel>>
    {
    }
}
