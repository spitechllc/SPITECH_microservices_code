﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetResellerFeeById
{
    public class GetResellerFeeByIdValidator : AbstractValidator<GetResellerFeeByIdQuery>
    {
        public GetResellerFeeByIdValidator()
        {
            RuleFor(s => s.ResellerFeeId).GreaterThan(0);
        }
    }
}
