﻿using MediatR;
using SpiTech.Transaction.Domain.Entities;

namespace SpiTech.Transaction.Application.Queries.GetResellerFeeById
{
    public class GetResellerFeeByIdQuery : IRequest<ResellerFee>
    {
        public int ResellerFeeId { get; set; }
    }
}
