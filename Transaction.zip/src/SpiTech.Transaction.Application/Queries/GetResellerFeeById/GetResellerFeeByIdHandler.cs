﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetResellerFeeById
{
    public class GetResellerFeeByIdHandler : IRequestHandler<GetResellerFeeByIdQuery, ResellerFee>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetResellerFeeByIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetResellerFeeByIdHandler(IUnitOfWork context,
                                    ILogger<GetResellerFeeByIdHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<ResellerFee> Handle(GetResellerFeeByIdQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            var result = await _context.ResellerFees.Get(query.ResellerFeeId);

            _logger.TraceExitMethod(nameof(Handle), result);

            return await Task.FromResult(result);
        }
    }
}
