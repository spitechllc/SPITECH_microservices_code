﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetStoreSettlementConfigDefault
{
    public class GetStoreSettlementConfigDefaultHandler : IRequestHandler<GetStoreSettlementConfigDefaultQuery, StoreSettlementConfigModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetStoreSettlementConfigDefaultHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetStoreSettlementConfigDefaultHandler(IUnitOfWork context,
                                    ILogger<GetStoreSettlementConfigDefaultHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<StoreSettlementConfigModel> Handle(GetStoreSettlementConfigDefaultQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            var result = await _context.StoreSettlementConfigs.GetDefault();

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
