﻿using MediatR;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetStoreSettlementConfigDefault
{
    public class GetStoreSettlementConfigDefaultQuery : IRequest<StoreSettlementConfigModel>
    {
    }
}
