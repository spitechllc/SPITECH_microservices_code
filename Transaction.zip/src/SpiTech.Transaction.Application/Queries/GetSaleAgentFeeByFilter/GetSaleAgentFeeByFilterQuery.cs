﻿using MediatR;
using SpiTech.Transaction.Domain.Entities;

namespace SpiTech.Transaction.Application.Queries.GetSaleAgentFeeByFilter
{
    public class GetSaleAgentFeeByFilterQuery : IRequest<SaleAgentFee>
    {
        public int SaleAgentId { get; set; }
        public int StoreId { get; set; }
    }
}
