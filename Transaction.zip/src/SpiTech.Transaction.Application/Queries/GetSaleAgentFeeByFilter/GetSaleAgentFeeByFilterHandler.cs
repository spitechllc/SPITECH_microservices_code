﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetSaleAgentFeeByFilter
{
    public class GetSaleAgentFeeByFilterHandler : IRequestHandler<GetSaleAgentFeeByFilterQuery, SaleAgentFee>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetSaleAgentFeeByFilterHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetSaleAgentFeeByFilterHandler(IUnitOfWork context,
                                    ILogger<GetSaleAgentFeeByFilterHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<SaleAgentFee> Handle(GetSaleAgentFeeByFilterQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            var saleAgentFee = await _context.SaleAgentFees.GetByStoreId(query.StoreId, query.SaleAgentId);

            _logger.TraceExitMethod(nameof(Handle), saleAgentFee);

            return saleAgentFee;
        }
    }
}
