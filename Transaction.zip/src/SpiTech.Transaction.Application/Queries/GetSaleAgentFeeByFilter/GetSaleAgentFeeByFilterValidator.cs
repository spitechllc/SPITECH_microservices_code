﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetSaleAgentFeeByFilter
{
    public class GetSaleAgentFeeByFilterValidator : AbstractValidator<GetSaleAgentFeeByFilterQuery>
    {
        public GetSaleAgentFeeByFilterValidator()
        {
            RuleFor(s => s.SaleAgentId).GreaterThan(0);
            RuleFor(s => s.StoreId).GreaterThan(0);
        }
    }
}
