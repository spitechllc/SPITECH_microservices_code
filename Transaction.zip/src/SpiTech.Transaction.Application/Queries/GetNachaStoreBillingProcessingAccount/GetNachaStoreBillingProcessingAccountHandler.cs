﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Service.Clients.Payments;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetNachaStoreBillingProcessingAccount
{
    public class GetNachaStoreBillingProcessingAccountHandler : IRequestHandler<GetNachaStoreBillingProcessingAccountQuery, NachaProcessingModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetNachaStoreBillingProcessingAccountHandler> logger;
        private readonly IMediator mediator;
        private readonly IPaymentServiceClient paymentClient;

        public GetNachaStoreBillingProcessingAccountHandler(IUnitOfWork context,
                                    ILogger<GetNachaStoreBillingProcessingAccountHandler> logger,
                                    IMediator mediator,
                                    IPaymentServiceClient paymentClient)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            this.paymentClient = paymentClient;
        }

        public async Task<NachaProcessingModel> Handle(GetNachaStoreBillingProcessingAccountQuery query, CancellationToken cancellationToken)
        {
            NachaProcessingModel response = null;
            logger.TraceEnterMethod(nameof(Handle), query);

            List<StoreBillingModel> storeBillings = await context.StoreBillings.GetBills(0, 0, null, query.Month, query.Year, false, false, null, null);

            if (storeBillings != null && storeBillings.Any())
            {
                StoreConfigModelResponseList storeConfigs = await paymentClient.AllStoreConfigsAsync(new GetStoreConfigsQuery
                {
                    StoreIds = storeBillings.Select(t => t.StoreId).Distinct().ToArray()
                });

                if (storeConfigs.Data == null || !storeConfigs.Data.Any())
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreConfigs", "Unable to get StoreConfigs"));
                }

                //if (query.IsPreview)
                //{
                //    foreach (var storeConfig in storeConfigs.Data)
                //    {
                //        if (string.IsNullOrWhiteSpace(storeConfig.AccountNo))
                //        {
                //            storeConfig.AccountNo = storeConfig.AccountNo.MaskAccountNumber();
                //        }
                //    }
                //}

                IEnumerable<StoreConfigModel> masterAccounts = storeConfigs.Data.Where(t => t.IsMasterAccount);

                if (masterAccounts == null || !masterAccounts.Any())
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreConfigs", "Unable to get masterAccount in StoreConfigs"));
                }

                if (masterAccounts.Count() > 1)
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreConfigs", "Found multiple masterAccount in StoreConfigs"));
                }

                StoreConfigModel masterAccount = storeConfigs.Data.FirstOrDefault(t => t.IsMasterAccount);

                var nachaConfig = (await context.NachaConfigs.GetAll()).FirstOrDefault();

                if (nachaConfig == null)
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("NachaConfig", "Unable to get NachaConfigs"));
                }

                //if (query.IsPreview)
                //{
                //    nachaConfig.AccountNo = nachaConfig.AccountNo.MaskAccountNumber();
                //}

                response = new NachaProcessingModel
                {
                    Config = new ApplicationCore.Domain.Nacha.NachaConfig
                    {
                        BankName = nachaConfig.Bank,
                        ImmediateOriginName = nachaConfig.AccountName,
                        AccountNo = nachaConfig.AccountNo,
                        RoutingNo = nachaConfig.RoutingNo,
                        BankRoutingNo = nachaConfig.ReceivingBankRoutingNo,
                        BatchCompanyName = masterAccount.AccountName,
                        EffectiveEntryDate = query.EffectiveDate ?? DateTime.Now,
                        ProcessType = NachaProcessType.STOREBILL,
                    },
                    ProcessingEntities = new List<NachaProcessingEntity>()
                };

                foreach (StoreBillingModel storeBilling in storeBillings)
                {
                    StoreConfigModel storeConfig = storeConfigs.Data
                                                .FirstOrDefault(t => t.StoreId == storeBilling.StoreId);
                    if (storeConfig == null)
                    {
                        throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreConfigs", $"Unable to get StoreConfig for store name ({storeBilling.StoreName})"));
                    }

                    var nachaProcessingEntity = new NachaProcessingEntity
                    {
                        Accounts = new List<NachaModel> { },
                        Entity = storeBilling
                    };

                    nachaProcessingEntity.Accounts.Add(new NachaModel
                    {
                        BatchCompanyName = masterAccount.AccountName.Length > 16 ? masterAccount.AccountName.Substring(0, 16) : masterAccount.AccountName,
                        AccountEntityId = storeConfig.StoreId,
                        TransactionCodeType = TransactionCodeType.Debit,
                        ProcessingAccount = new NachaAccount
                        {
                            BankName = storeConfig.Bank,
                            AccountName = storeConfig.AccountName,
                            AccountNo = storeConfig.AccountNo,
                            RoutingNo = storeConfig.RoutingNo,
                            AccountType = storeConfig.IsChecking ? AccountType.Checking : AccountType.Savings,
                        },
                        Amount = storeBilling.TotalFee,
                        AmountType = AmountType.CashReward,
                        IdentificationNumber = "SB" + storeBilling.StoreBillingId.ToString(string.Concat(Enumerable.Repeat("0", 10))),
                    });

                    response.ProcessingEntities.Add(nachaProcessingEntity);
                }
            }

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
