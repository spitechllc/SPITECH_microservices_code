﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Nacha;
using System;

namespace SpiTech.Transaction.Application.Queries.GetNachaStoreBillingProcessingAccount
{
    public class GetNachaStoreBillingProcessingAccountQuery : IRequest<NachaProcessingModel>
    {
        public int Month { get; set; }
        public int Year { get; set; }
        public bool IsPreview { get; set; }
        public DateTime? EffectiveDate { get; set; }
    }
}
