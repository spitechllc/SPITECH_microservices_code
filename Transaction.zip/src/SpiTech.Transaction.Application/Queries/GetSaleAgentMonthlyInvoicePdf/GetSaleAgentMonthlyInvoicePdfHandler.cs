﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.Services;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetSaleAgentMonthlyInvoicePdf
{
    public class GetSaleAgentMonthlyInvoicePdfHandler : IRequestHandler<GetSaleAgentMonthlyInvoicePdfQuery, InvoiceFileBytesModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetSaleAgentMonthlyInvoicePdfHandler> logger;
        private readonly IStorageService storageService;
        private readonly IStoreServiceClient _storeapiclient;
        private readonly IPaymentServiceClient _paymentapiclient;
        private readonly IHtmlPdfConverterService converterService;

        public GetSaleAgentMonthlyInvoicePdfHandler(IUnitOfWork context,
                                                ILogger<GetSaleAgentMonthlyInvoicePdfHandler> logger,
                                                IStorageServiceFactory storageServiceFactory,
                                                IStoreServiceClient storeapiclient,
                                                IPaymentServiceClient paymentapiclient,
                                                IHtmlPdfConverterService converterService
                                    )
        {
            this.context = context;
            this.logger = logger;
            storageService = storageServiceFactory.Get(ContainerType.SaleAgentMonthlyInvoicePdf);
            _storeapiclient = storeapiclient;
            _paymentapiclient = paymentapiclient;
            this.converterService = converterService;
        }

        public async Task<InvoiceFileBytesModel> Handle(GetSaleAgentMonthlyInvoicePdfQuery query, CancellationToken cancellationToken)
        {
            InvoiceFileBytesModel response = null;
            logger.TraceEnterMethod(nameof(Handle), query);

            var saleAgentBilling = (await context.SaleAgentBillings.GetBills(query.SaleAgentBillingId)).FirstOrDefault();

            if (saleAgentBilling == null)
            {
                return null;
            }

            if (!string.IsNullOrWhiteSpace(saleAgentBilling.InvoiceFilePath))
            {
                response = new InvoiceFileBytesModel();
                response.File = saleAgentBilling.InvoiceFileName;
                response.Bytes = await storageService.DownloadBytesAsync(saleAgentBilling.InvoiceFilePath);
            }
            else
            {
                response = new InvoiceFileBytesModel();
                var salesAgent = (await _storeapiclient.SaleAgentsAsync(new[] { saleAgentBilling.SaleAgentId }, cancellationToken)).FirstOrDefault();

                saleAgentBilling.SaleAgentName = salesAgent?.FirstName + " " + salesAgent?.LastName;

                response.Bytes = await this.converterService.CreatePdfFromView("SaleAgentMonthlyInvoice", saleAgentBilling);
                response.File = "SaleAgentMonthlyInvoice.pdf";
            }

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
