﻿using MediatR;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetSaleAgentMonthlyInvoicePdf
{
    public class GetSaleAgentMonthlyInvoicePdfQuery : IRequest<InvoiceFileBytesModel>
    {
        public int SaleAgentBillingId { get; set; }
    }
}
