﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetPriceAdjustmentById
{
    public class GetPriceAdjustmentByIdHandler : IRequestHandler<GetPriceAdjustmentByIdQuery, PriceAdjustmentModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetPriceAdjustmentByIdHandler> _logger;
        private readonly IMapper _mapper;
        public GetPriceAdjustmentByIdHandler(IUnitOfWork context,
                                             ILogger<GetPriceAdjustmentByIdHandler> logger,
                                             IMapper mapper
                                           )
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<PriceAdjustmentModel> Handle(GetPriceAdjustmentByIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            PriceAdjustmentModel result = _mapper.Map<PriceAdjustmentModel>(await _context.PriceAdjustments.Get(request.AdjustmentId));
            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
