﻿using MediatR;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetPriceAdjustmentById
{
    public class GetPriceAdjustmentByIdQuery : IRequest<PriceAdjustmentModel>
    {
        public int AdjustmentId { get; set; }
    }
}
