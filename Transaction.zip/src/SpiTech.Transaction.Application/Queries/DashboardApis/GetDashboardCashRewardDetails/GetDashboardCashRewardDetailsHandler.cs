﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Service.Clients.Finance;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.DashboardApis.GetDashboardCashRewardDetails
{
    public class GetDashboardCashRewardDetailsHandler : IRequestHandler<GetDashboardCashRewardDetailsQuery, ResponseModel<DashboardCashRewardModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetDashboardCashRewardDetailsHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IFinanceServiceClient _financeServiceClient;
        private readonly IStoreServiceClient _storeServiceClient;
        private readonly IUserAuthenticationProvider _authenticationProvider;

        public GetDashboardCashRewardDetailsHandler(IUnitOfWork context,
                                    ILogger<GetDashboardCashRewardDetailsHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper,
                                    IFinanceServiceClient financeServiceClient,
                                    IStoreServiceClient storeServiceClient,
                                    IUserAuthenticationProvider authenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _financeServiceClient = financeServiceClient;
            _storeServiceClient = storeServiceClient;
            _authenticationProvider = authenticationProvider;
        }
        public async Task<ResponseModel<DashboardCashRewardModel>> Handle(GetDashboardCashRewardDetailsQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            ResponseModel<DashboardCashRewardModel> res = new() { Success = false };
            ICollection<StoresSearchModel> storeDetails = new List<StoresSearchModel>();
            try
            {
                if (!query.StoreIds.Any())
                {
                    GetStoresForDashboardQuery request = new GetStoresForDashboardQuery();
                    request.StateId = query.StateId;
                    request.City = query.City;
                    request.Zipcode = query.Zipcode;
                    request.UserId = _authenticationProvider.GetUserAuthentication().UserId;
                    request.RoleId = query.RoleId;
                    request.CompanyId = query.CompanyId;
                    if (query.StoreGroupIds.Length > 0)
                    {
                        request.StoreGroupIds = query.StoreGroupIds;
                    }
                    request.StoreGroupIds = null;

                    storeDetails = (await _storeServiceClient.GetStoresForDashboard(request)).Data ?? new List<StoresSearchModel>();

                    if (storeDetails.Any() && storeDetails != null)
                    {
                        query.StoreIds = storeDetails.Select(t => t.StoreId).Distinct().ToArray();
                    }
                    else
                    {
                        return res;
                    }
                }
                if (query.AppIds != null && query.AppIds.Length > 0)
                {
                    GetStoresForDashboardQuery request = new GetStoresForDashboardQuery();
                    request.StateId = 0;
                    request.StoreGroupIds = new List<int>();
                    request.UserId = _authenticationProvider.GetUserAuthentication().UserId;
                    request.AppIds = query.AppIds;
                    storeDetails = (await _storeServiceClient.GetStoresForDashboard(request)).Data ?? new List<StoresSearchModel>();
                    if (storeDetails.Any() && storeDetails != null)
                    {
                        query.StoreIds = storeDetails.Select(t => t.StoreId).Distinct().ToArray();
                    }
                    else
                    {
                        return res;
                    }
                }
                GetRewardDetailsDashboardQuery req = new GetRewardDetailsDashboardQuery();
                req.StartDate = query.StartDate;
                req.EndDate = query.EndDate;
                req.StoreIds = query.StoreIds;
                req.UserId = query.UserId;
                req.Month = query.Month;
                req.Year = query.Year;
                var result = await _financeServiceClient.CashRewardDetailsForDashBoardAsync(req);
                if (result != null)
                {
                    res.Data = _mapper.Map<DashboardCashRewardModel>(result.Data);
                    res.Data.storeRewardDetails = _mapper.Map<IEnumerable<DashboardStoreRewardDetails>>(result.Data.StoreRewardDetails);
                    res.Data.monthWiseRewardDetails = _mapper.Map<IEnumerable<DashboardMonthWiseRewardDetails>>(result.Data.MonthWiseRewardDetails);
                    res.Success = true;

                }
                _logger.TraceExitMethod(nameof(Handle), res);
            }
            catch (Exception ex)
            { throw; }
            return res;
        }
    }
}
