﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.DashboardApis.GetDashboardTransactionDetails
{
    public class GetDashboardTransactionDetailsHandler : IRequestHandler<GetDashboardTransactionDetailsQuery, ResponseModel<DashboardTransactionModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetDashboardTransactionDetailsHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IStoreServiceClient _storeServiceClient;
        private readonly IUserAuthenticationProvider _authenticationProvider;

        public GetDashboardTransactionDetailsHandler(IUnitOfWork context,
                                    ILogger<GetDashboardTransactionDetailsHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper,
                                    IStoreServiceClient storeServiceClient,
                                    IUserAuthenticationProvider authenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _storeServiceClient = storeServiceClient;
            _authenticationProvider = authenticationProvider;
        }
        public async Task<ResponseModel<DashboardTransactionModel>> Handle(GetDashboardTransactionDetailsQuery query, CancellationToken cancellationToken)
        {
            _logger.Warn($"GetDashboardTransactionDetailsHandler step1");
            _logger.TraceEnterMethod(nameof(Handle), query);
            ResponseModel<DashboardTransactionModel> res = new() { Success = false };
            ICollection<StoresSearchModel> storeDetails = new List<StoresSearchModel>();
            if (!query.StoreIds.Any())
            {
                _logger.Warn($"GetDashboardTransactionDetailsHandler step2");
                GetStoresForDashboardQuery request = new GetStoresForDashboardQuery();
                request.StateId = query.StateId;
                request.City = query.City;
                request.Zipcode = query.Zipcode;
                _logger.Warn($"GetDashboardTransactionDetailsHandler step4:");
                request.UserId = _authenticationProvider.GetUserAuthentication().UserId;
                _logger.Warn($"SS");
                _logger.Warn($"GetDashboardTransactionDetailsHandler step5:"+ request.UserId);
                request.CompanyId = query.CompanyId;
                if(query.StoreGroupIds.Length > 0)
                {
                    request.StoreGroupIds = query.StoreGroupIds;
                }
                _logger.Warn($"GetDashboardTransactionDetailsHandler step9:"+ request.UserId);
                request.StoreGroupIds = null;
                request.RoleId = query.RoleId;
                _logger.Warn($"GetStoresForDashboard Initial1");
                storeDetails = (await _storeServiceClient.GetStoresForDashboard(request)).Data ?? new List<StoresSearchModel>();
                _logger.Warn($"GetStoresForDashboard Initial 2");
                if (storeDetails.Any() && storeDetails != null)
                {
                    query.StoreIds = storeDetails.Select(t => t.StoreId).Distinct().ToArray();
                }
                else
                {
                    return res;
                }
            }
            _logger.Warn($"GetDashboardTransactionDetailsHandler step5");
            if (query.AppIds != null && query.AppIds.Length > 0)
            {
                GetStoresForDashboardQuery request = new GetStoresForDashboardQuery();
                request.StateId = 0;
                request.StoreGroupIds = new List<int>();
                request.UserId = _authenticationProvider.GetUserAuthentication().UserId;
                request.AppIds = query.AppIds;
                storeDetails = (await _storeServiceClient.GetStoresForDashboard(request)).Data ?? new List<StoresSearchModel>();
                if (storeDetails.Any() && storeDetails != null)
                {
                    query.StoreIds = storeDetails.Select(t => t.StoreId).Distinct().ToArray();
                }
                else
                {
                    return res;
                }
            }
_logger.Warn($"GetDashboardTransactionDetailsHandler step6");
            var result = await _context.Transactions.GetTransactionDetailsForDashboard(query.StartDate, query.EndDate, query.StoreIds, query.UserId, query.Month, query.Year);
            if (result != null)
            {
                _logger.Warn($"GetDashboardTransactionDetailsHandler step7");
                var currentData = await _context.Transactions.GetCurrentTransactionDetailsForDashboard(query.UserId, query.StoreIds);
                result.TotalCurrentSuccessAmount = currentData.TotalSuccessAmount;
                result.TotalCurrentSuccessTransactions = currentData.TotalSuccessTransactions;

                result.storeTransactionModel = await _context.Transactions.GetStoreTransactionDetailsForDashboard(query.StartDate, query.EndDate, query.StoreIds, query.UserId, query.Month, query.Year, query.SortBy, query.SortOrder);
                result.yearWiseTransactionModel = await _context.Transactions.GetYearwiseDetailForDashboard(query.StartDate, query.EndDate, query.StoreIds.ToArray(), query.UserId, query.Month, query.Year);
                result.monthWiseTransactionModel = await _context.Transactions.GetMonthWiseDetailForDashboard(DateTime.Now.Year, null, query.StoreIds.ToArray(), query.UserId);
                if (result.storeTransactionModel != null)
                {
                    result.TotalStoreAmount = result.storeTransactionModel.Sum(t => t.TotalSuccessAmount);
                    result.TotalStoreTransactions = (int)result.storeTransactionModel.Sum(t => t.TotalSuccessTransactions);
                    result.TotalStoreACHAmount = result.storeTransactionModel.Sum(t => t.TotalACHAmount);
                    result.TotalStoreACHTransactions = (int)result.storeTransactionModel.Sum(t => t.TotalACHTransactions);
                    result.TotalStoreCardAmount = result.storeTransactionModel.Sum(t => t.TotalCardAmount);
                    result.TotalStoreCardTransactions = (int)result.storeTransactionModel.Sum(t => t.TotalCardTransactions);
                    result.TotalStoreWalletAmount = result.storeTransactionModel.Sum(t => t.TotalWalletAmount);
                    result.TotalStoreWalletTransactions = (int)result.storeTransactionModel.Sum(t => t.TotalWalletTransactions);
                }
                if (result.yearWiseTransactionModel != null)
                {
                    result.TotalYearWiseAmount = result.yearWiseTransactionModel.Sum(t => t.TotalyearAmount);
                    result.TotalYearWiseAmountStoreCount = result.yearWiseTransactionModel.Sum(t => t.TotalyearAmountStoreCount);
                    result.TotalYearWisePumpAmount = result.yearWiseTransactionModel.Sum(t => t.TotalyearPumpAmount);
                    result.TotalYearWisePumpAmountStoreCount = result.yearWiseTransactionModel.Sum(t => t.TotalyearPumpAmountStoreCount);
                    result.TotalYearWiseStoreAmount = result.yearWiseTransactionModel.Sum(t => t.TotalyearStoreAmount);
                    result.TotalYearWiseStoreAmountStoreCount = result.yearWiseTransactionModel.Sum(t => t.TotalyearStoreAmountStoreCount);

                }
                if (result.monthWiseTransactionModel != null)
                {
                    result.TotalMonthWiseAmount = result.monthWiseTransactionModel.Sum(t => t.Amount);
                    result.TotalMonthWisePumpAmount = result.monthWiseTransactionModel.Sum(t => t.PumpAmount);
                    result.TotalMonthWiseStoreAmount = result.monthWiseTransactionModel.Sum(t => t.StoreAmount);
                    //foreach (var month in result.monthWiseTransactionModel)
                    //{
                    //    month.monthWiseStoreTransactionModel = await _context.Transactions.GetStoreTransactionDetailsForDashboard(null, null, query.StoreIds, query.UserId, month.MonthId, DateTime.Now.Year, query.SortBy, query.SortOrder);

                    //    if (month.monthWiseStoreTransactionModel != null)
                    //    {
                    //        month.MonthlyTotalStoreAmount = month.monthWiseStoreTransactionModel.Sum(t => t.TotalSuccessAmount);
                    //        month.MonthlyTotalStoreTransactions = (int)month.monthWiseStoreTransactionModel.Sum(t => t.TotalSuccessTransactions);
                    //        month.MonthlyTotalStoreACHAmount = month.monthWiseStoreTransactionModel.Sum(t => t.TotalACHAmount);
                    //        month.MonthlyTotalStoreACHTransactions = (int)month.monthWiseStoreTransactionModel.Sum(t => t.TotalACHTransactions);
                    //        month.MonthlyTotalStoreCardAmount = month.monthWiseStoreTransactionModel.Sum(t => t.TotalCardAmount);
                    //        month.MonthlyTotalStoreCardTransactions = (int)month.monthWiseStoreTransactionModel.Sum(t => t.TotalCardTransactions);
                    //        month.MonthlyTotalStoreWalletAmount = month.monthWiseStoreTransactionModel.Sum(t => t.TotalWalletAmount);
                    //        month.MonthlyTotalStoreWalletTransactions = (int)month.monthWiseStoreTransactionModel.Sum(t => t.TotalWalletTransactions);
                    //        //day wise store data
                    //        foreach (var store in month.monthWiseStoreTransactionModel)
                    //        {
                    //            store.dayWiseStoreDetails = await _context.Transactions.GetDayWiseStoreTransactionDetailsForDashboard(store.StoreId, query.UserId, month.MonthId, DateTime.Now.Year, query.SortBy, query.SortOrder);
                    //        }
                    //    }
                    //}

                }

                foreach (var item in result.yearWiseTransactionModel)
                {
                    item.monthWiseDetails = await _context.Transactions.GetMonthWiseDetailForDashboard(item.years, null, query.StoreIds.ToArray(), query.UserId);

                    //if (item.monthWiseDetails != null)
                    //{
                    //    foreach (var month in item.monthWiseDetails)
                    //    {
                    //        month.monthWiseStoreTransactionModel = await _context.Transactions.GetStoreTransactionDetailsForDashboard(null, null, query.StoreIds, query.UserId, month.MonthId, item.years, query.SortBy, query.SortOrder);

                    //        if (month.monthWiseStoreTransactionModel != null)
                    //        {
                    //            month.MonthlyTotalStoreAmount = month.monthWiseStoreTransactionModel.Sum(t => t.TotalSuccessAmount);
                    //            month.MonthlyTotalStoreTransactions = (int)month.monthWiseStoreTransactionModel.Sum(t => t.TotalSuccessTransactions);
                    //            month.MonthlyTotalStoreACHAmount = month.monthWiseStoreTransactionModel.Sum(t => t.TotalACHAmount);
                    //            month.MonthlyTotalStoreACHTransactions = (int)month.monthWiseStoreTransactionModel.Sum(t => t.TotalACHTransactions);
                    //            month.MonthlyTotalStoreCardAmount = month.monthWiseStoreTransactionModel.Sum(t => t.TotalCardAmount);
                    //            month.MonthlyTotalStoreCardTransactions = (int)month.monthWiseStoreTransactionModel.Sum(t => t.TotalCardTransactions);
                    //            month.MonthlyTotalStoreWalletAmount = month.monthWiseStoreTransactionModel.Sum(t => t.TotalWalletAmount);
                    //            month.MonthlyTotalStoreWalletTransactions = (int)month.monthWiseStoreTransactionModel.Sum(t => t.TotalWalletTransactions);
                    //            //day wise store data
                    //            foreach (var store in month.monthWiseStoreTransactionModel)
                    //            {
                    //                store.dayWiseStoreDetails = await _context.Transactions.GetDayWiseStoreTransactionDetailsForDashboard(store.StoreId, query.UserId, month.MonthId, item.years, query.SortBy, query.SortOrder);
                    //            }
                    //        }
                    //    }
                    //}
                }
                //get all stores for moving strip in dashboard
                ICollection<StoresSearchModel> allstoreDetails = new List<StoresSearchModel>();

                GetStoresForDashboardQuery request = new GetStoresForDashboardQuery();
                request.StateId = 0;
                request.StoreGroupIds = new List<int>();
                request.UserId = _authenticationProvider.GetUserAuthentication().UserId;
                request.AppIds = query.AppIds;

                allstoreDetails = (await _storeServiceClient.GetStoresForDashboard(request)).Data ?? new List<StoresSearchModel>();

                if (allstoreDetails.Any() && allstoreDetails != null)
                {
                    IEnumerable<DashboardStoreModel> storecurrentTransactionModel = await _context.Transactions.GetStoreCurrentTransactionDetailsForDashboard();
                    result.allStoreTransactionModel = _mapper.Map<IEnumerable<DashboardAllStoreDetails>>(allstoreDetails);

                    foreach (var item in result.allStoreTransactionModel)
                    {
                        if (storecurrentTransactionModel.Where(t => t.StoreId == item.StoreId).Count() > 0)
                        {
                            item.TransactionCount = (int)(storecurrentTransactionModel.Where(t => t.StoreId == item.StoreId)?.FirstOrDefault().TotalSuccessTransactions ?? 0);
                            item.Amount = (decimal)(storecurrentTransactionModel.Where(t => t.StoreId == item.StoreId)?.FirstOrDefault().TotalSuccessAmount ?? 0);
                        }
                    }

                }
                res.Success = true;
                res.Data = result;
            }
            _logger.TraceExitMethod(nameof(Handle), result);

            return res;
        }
    }
}
