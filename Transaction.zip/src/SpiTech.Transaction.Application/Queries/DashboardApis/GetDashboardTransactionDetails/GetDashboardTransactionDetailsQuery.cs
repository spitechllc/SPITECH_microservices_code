﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using System;

namespace SpiTech.Transaction.Application.Queries.DashboardApis.GetDashboardTransactionDetails
{
    public class GetDashboardTransactionDetailsQuery: IRequest<ResponseModel<DashboardTransactionModel>>
    {
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int[] StoreIds { get; set; }
        public int? UserId { get; set; }
        public int? Month { get; set; }
        public int? Year { get; set; }
        public string Zipcode { get; set; }
        public string City { get; set; }
        public int? StateId { get; set; }
        public int? CompanyId { get; set; }
        public int[] StoreGroupIds { get; set; }
        public string RoleId { get; set; }
        public StoreDetailDashboardSortBy? SortBy { get; set; }
        public SortOrderEnum? SortOrder { get; set; }
        public int[] AppIds { get; set; }
    }
}
