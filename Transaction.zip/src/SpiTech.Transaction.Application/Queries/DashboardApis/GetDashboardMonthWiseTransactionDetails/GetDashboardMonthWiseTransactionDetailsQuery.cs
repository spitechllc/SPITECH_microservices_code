﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;

namespace SpiTech.Transaction.Application.Queries.DashboardApis.GetDashboardMonthWiseTransactionDetails
{
    public class GetDashboardMonthWiseTransactionDetailsQuery :IRequest<ResponseList<DashboardMonthwiseModel>>
    {
       
        public int[] StoreIds { get; set; }
        public int? UserId { get; set; }
        public int? Month { get; set; }
        public int Year { get; set; }
        public string Zipcode { get; set; }
        public string City { get; set; }
        public int? StateId { get; set; }
        public int? CompanyId { get; set; }
        public int[] StoreGroupIds { get; set; }
        public int UserIdToken { get; set; }
    }
}