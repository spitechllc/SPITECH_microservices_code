﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.DashboardApis.GetDashboardMonthWiseTransactionDetails
{
    public class GetDashboardMonthWiseTransactionDetailsHandler : IRequestHandler<GetDashboardMonthWiseTransactionDetailsQuery, ResponseList<DashboardMonthwiseModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetDashboardMonthWiseTransactionDetailsHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IStoreServiceClient _storeServiceClient;
        private readonly IUserAuthenticationProvider _authenticationProvider;

        public GetDashboardMonthWiseTransactionDetailsHandler(IUnitOfWork context,
                                    ILogger<GetDashboardMonthWiseTransactionDetailsHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper,
                                    IStoreServiceClient storeServiceClient,
                                    IUserAuthenticationProvider authenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _storeServiceClient = storeServiceClient;
            _authenticationProvider = authenticationProvider;
        }
        public async Task<ResponseList<DashboardMonthwiseModel>> Handle(GetDashboardMonthWiseTransactionDetailsQuery query, CancellationToken cancellationToken)
        {            
            _logger.TraceEnterMethod(nameof(Handle), query);
            ResponseList<DashboardMonthwiseModel> res = new();
            ICollection<StoresSearchModel> storeDetails = new List<StoresSearchModel>();
            if (!query.StoreIds.Any())
            {
                    GetStoresForDashboardQuery request = new GetStoresForDashboardQuery();
                    request.StateId = query.StateId;
                    request.City = query.City;
                    request.Zipcode = query.Zipcode;
                    request.UserId = _authenticationProvider.GetUserAuthentication().UserId;
                    request.CompanyId = query.CompanyId;
                    request.StoreGroupIds = query.StoreGroupIds;
                    storeDetails = (await _storeServiceClient.GetStoresForDashboard(request)).Data ?? new List<StoresSearchModel>();
                
                if(storeDetails.Any() && storeDetails!=null)
                {
                    query.StoreIds = storeDetails.Select(t => t.StoreId).Distinct().ToArray();
                }
            }
            var result = await _context.Transactions.GetMonthWiseDetailForDashboard(query.Year,query.Month, query.StoreIds, query.UserId);
            if (result != null)
            {
                foreach (var month in result)
                {
                    month.monthWiseStoreTransactionModel = await _context.Transactions.GetStoreTransactionDetailsForDashboard(null, null, query.StoreIds, query.UserId, month.MonthId, DateTime.Now.Year, null, null);

                    if (month.monthWiseStoreTransactionModel != null)
                    {
                        month.MonthlyTotalStoreAmount = month.monthWiseStoreTransactionModel.Sum(t => t.TotalSuccessAmount);
                        month.MonthlyTotalStoreTransactions = (int)month.monthWiseStoreTransactionModel.Sum(t => t.TotalSuccessTransactions);
                        month.MonthlyTotalStoreACHAmount = month.monthWiseStoreTransactionModel.Sum(t => t.TotalACHAmount);
                        month.MonthlyTotalStoreACHTransactions = (int)month.monthWiseStoreTransactionModel.Sum(t => t.TotalACHTransactions);
                        month.MonthlyTotalStoreCardAmount = month.monthWiseStoreTransactionModel.Sum(t => t.TotalCardAmount);
                        month.MonthlyTotalStoreCardTransactions = (int)month.monthWiseStoreTransactionModel.Sum(t => t.TotalCardTransactions);
                        month.MonthlyTotalStoreWalletAmount = month.monthWiseStoreTransactionModel.Sum(t => t.TotalWalletAmount);
                        month.MonthlyTotalStoreWalletTransactions = (int)month.monthWiseStoreTransactionModel.Sum(t => t.TotalWalletTransactions);
                        //day wise store data
                        foreach (var store in month.monthWiseStoreTransactionModel)
                        {
                            store.dayWiseStoreDetails = await _context.Transactions.GetDayWiseStoreTransactionDetailsForDashboard(store.StoreId, query.UserId, month.MonthId, query.Year, null, null);
                        }
                    }

                }

                res.Data = result;
            }
            _logger.TraceExitMethod(nameof(Handle), result);

            return res;
        }
    }
}
