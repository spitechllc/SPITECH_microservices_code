﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using System;

namespace SpiTech.Transaction.Application.Queries.DashboardApis.GetMobileDashboardDetails
{
    public class GetMobileDashboardDetailsQuery : IRequest<ResponseList<MobileDashboardStoreDetailsModel>>
    {
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}