﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Service.Clients.Finance;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.DashboardApis.GetMobileDashboardDetails
{
    public class GetMobileDashboardDetailsHandler : IRequestHandler<GetMobileDashboardDetailsQuery, ResponseList<MobileDashboardStoreDetailsModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetMobileDashboardDetailsHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IStoreServiceClient _storeServiceClient;
        private readonly IFinanceServiceClient _financeServiceClient;
        private readonly IUserAuthenticationProvider _authenticationProvider;

        public GetMobileDashboardDetailsHandler(IUnitOfWork context,
                                    ILogger<GetMobileDashboardDetailsHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper,
                                    IStoreServiceClient storeServiceClient,
                                    IFinanceServiceClient financeServiceClient,
                                    IUserAuthenticationProvider authenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _storeServiceClient = storeServiceClient;
            _financeServiceClient = financeServiceClient;
            _authenticationProvider = authenticationProvider;
        }
        public async Task<ResponseList<MobileDashboardStoreDetailsModel>> Handle(GetMobileDashboardDetailsQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            ResponseList<MobileDashboardStoreDetailsModel> res = new();
            ICollection<StoreGroupUsersModel> storeDetails = new List<StoreGroupUsersModel>();
            int[] StoreIds = new List<int>().ToArray();

            storeDetails = (await _storeServiceClient.StoreGroupStoresByUserIdAsync(_authenticationProvider.GetUserAuthentication().UserId, cancellationToken)).Data ?? new List<StoreGroupUsersModel>();


            List<MobileDashboardStoreDetailsModel> MobileDashboardStoreDetailsModel = new List<MobileDashboardStoreDetailsModel>();

            if (storeDetails.Any() && storeDetails != null)
            {
                StoreIds = storeDetails.Select(t => t.StoreId).Distinct().ToArray();

                ResponseModel<DashboardCashRewardModel> cashRewardModel = new() { Success = false };
                GetRewardDetailsDashboardQuery req = new GetRewardDetailsDashboardQuery();
                req.StartDate = query.StartDate;
                req.EndDate = query.EndDate;
                req.StoreIds = StoreIds;
                RewardDetailsDashboardModelResponseModel rewardDetailsDashboardModel = await _financeServiceClient.CashRewardDetailsForDashBoardAsync(req);
                if (rewardDetailsDashboardModel != null)
                {
                    cashRewardModel.Data = _mapper.Map<DashboardCashRewardModel>(rewardDetailsDashboardModel.Data);
                    cashRewardModel.Data.storeRewardDetails = _mapper.Map<IEnumerable<DashboardStoreRewardDetails>>(rewardDetailsDashboardModel.Data.StoreRewardDetails);
                    cashRewardModel.Data.monthWiseRewardDetails = _mapper.Map<IEnumerable<DashboardMonthWiseRewardDetails>>(rewardDetailsDashboardModel.Data.MonthWiseRewardDetails);

                }

                var result = await _context.Transactions.GetTransactionDetailsForMobileDashboard(query.StartDate, query.EndDate, StoreIds);
                foreach (var item in storeDetails)
                {
                    MobileDashboardStoreDetailsModel mobileDashboardStoreDetail = new MobileDashboardStoreDetailsModel();
                    mobileDashboardStoreDetail.StoreId = item.StoreId;
                    mobileDashboardStoreDetail.StoreName = item.StoreName;
                    mobileDashboardStoreDetail.storeTransactionModels = result.Where(t => t.StoreId == item.StoreId)?.FirstOrDefault();
                    if (rewardDetailsDashboardModel.Data.StoreRewardDetails.Where(x => x.StoreId == item.StoreId).Count() > 0)
                    {
                        mobileDashboardStoreDetail.storeTransactionModels.TotalCashBackEarned = (decimal)(rewardDetailsDashboardModel.Data.StoreRewardDetails.Where(x => x.StoreId == item.StoreId).FirstOrDefault()?.Earned);
                        mobileDashboardStoreDetail.storeTransactionModels.TotalCashBackEarned = (decimal)(rewardDetailsDashboardModel.Data.StoreRewardDetails.Where(x => x.StoreId == item.StoreId).FirstOrDefault()?.Redeemed);
                    }
                    MobileDashboardStoreDetailsModel.Add(mobileDashboardStoreDetail);
                }
                res.Data = MobileDashboardStoreDetailsModel;
            }
            _logger.TraceExitMethod(nameof(Handle), MobileDashboardStoreDetailsModel);

            return res;
        }
    }
}
