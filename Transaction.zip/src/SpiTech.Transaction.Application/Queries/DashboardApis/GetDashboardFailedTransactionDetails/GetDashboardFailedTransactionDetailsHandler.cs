﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.Queries.DashBoardApis.GetDashboardFailedTransactionDetails;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.DashboardApis.GetDashboardFailedTransactionDetails
{
   public class GetDashboardFailedTransactionDetailsHandler : IRequestHandler<GetDashboardFailedTransactionDetailsQuery, ResponseModel<DashboardTransactionModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetDashboardFailedTransactionDetailsHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IStoreServiceClient _storeServiceClient;
        private readonly IUserAuthenticationProvider _authenticationProvider;

        public GetDashboardFailedTransactionDetailsHandler(IUnitOfWork context,
                                    ILogger<GetDashboardFailedTransactionDetailsHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper, IStoreServiceClient storeServiceClient, IUserAuthenticationProvider authenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _storeServiceClient = storeServiceClient;
            _authenticationProvider = authenticationProvider;
        }
        public async Task<ResponseModel<DashboardTransactionModel>> Handle(GetDashboardFailedTransactionDetailsQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            ResponseModel<DashboardTransactionModel> res = new() { Success = false };
            ICollection<StoresSearchModel> storeDetails = new List<StoresSearchModel>();
            if (!query.StoreIds.Any())
            {
                    GetStoresForDashboardQuery request = new GetStoresForDashboardQuery();
                    request.StateId = query.StateId;
                    request.City = query.City;
                    request.Zipcode = query.Zipcode;
                    request.UserId = _authenticationProvider.GetUserAuthentication().UserId;
                    request.RoleId = query.RoleId;
                    request.CompanyId = query.CompanyId;
                    request.StoreGroupIds = query.StoreGroupIds;

                    storeDetails = (await _storeServiceClient.GetStoresForDashboard(request)).Data ?? new List<StoresSearchModel>();
               
                if (storeDetails.Any() && storeDetails != null)
                {
                    query.StoreIds = storeDetails.Select(t => t.StoreId).Distinct().ToArray();
                }
            }

            var result = await _context.Transactions.GetTransactionDetailsForDashboard(query.StartDate,query.EndDate, query.StoreIds, query.UserId, query.Month, query.Year);
            if (result!=null)
            {
                result.storeTransactionModel = await _context.Transactions.GetStoreTransactionDetailsForDashboard(query.StartDate, query.EndDate, query.StoreIds, query.UserId, query.Month, query.Year,query.SortBy,query.SortOrder);
                res.Success = true;
                res.Data = result;
            }
            _logger.TraceExitMethod(nameof(Handle), result);

            return res;
        }
    }
}
