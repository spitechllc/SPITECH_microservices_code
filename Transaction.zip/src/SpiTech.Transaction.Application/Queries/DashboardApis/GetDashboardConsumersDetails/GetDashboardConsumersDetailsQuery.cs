﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using System;

namespace SpiTech.Transaction.Application.Queries.DashboardApis.GetDashboardConsumersDetails
{
    public class GetDashboardConsumersDetailsQuery : IRequest<ResponseModel<DashboardConsumersModel>>
    {
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int[] StoreIds { get; set; }
        public int? UserId { get; set; }
        public int? Month { get; set; }
        public int? Year { get; set; }
        public string Zipcode { get; set; }
        public string City { get; set; }
        public int? StateId { get; set; }
        public int? CompanyId { get; set; }
        public int[] StoreGroupIds { get; set; }
        public string RoleId { get; set; }
        public int[] AppIds { get; set; }
    }
}
