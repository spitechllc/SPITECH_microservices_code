﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Service.Clients.Finance;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.DashboardApis.GetDashboardConsumersDetails
{
    public class GetDashboardConsumersDetailsHandler : IRequestHandler<GetDashboardConsumersDetailsQuery, ResponseModel<DashboardConsumersModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetDashboardConsumersDetailsHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IStoreServiceClient _storeServiceClient;
        private readonly IIdentityServiceClient _identityServiceClient;
        private readonly IFinanceServiceClient _financeServiceClient;
        private readonly IUserAuthenticationProvider _authenticationProvider;

        public GetDashboardConsumersDetailsHandler(IUnitOfWork context,
                                    ILogger<GetDashboardConsumersDetailsHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper, IStoreServiceClient storeServiceClient, IIdentityServiceClient identityServiceClient, IFinanceServiceClient financeServiceClient,
                                    IUserAuthenticationProvider authenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _storeServiceClient = storeServiceClient;
            _identityServiceClient = identityServiceClient;
            _financeServiceClient = financeServiceClient;
            _authenticationProvider = authenticationProvider;
        }
        public async Task<ResponseModel<DashboardConsumersModel>> Handle(GetDashboardConsumersDetailsQuery query, CancellationToken cancellationToken)
        {

            _logger.TraceEnterMethod(nameof(Handle), query);
            ResponseModel<DashboardConsumersModel> res = new() { Success = false };
            ICollection<StoresSearchModel> storeDetails = new List<StoresSearchModel>();
            if (!query.StoreIds.Any())
            {
                GetStoresForDashboardQuery request = new GetStoresForDashboardQuery();
                request.StateId = query.StateId;
                request.City = query.City;
                request.Zipcode = query.Zipcode;
                request.UserId = _authenticationProvider.GetUserAuthentication().UserId;
                request.RoleId = query.RoleId;
                request.CompanyId = query.CompanyId;
                if (query.StoreGroupIds.Length > 0)
                {
                    request.StoreGroupIds = query.StoreGroupIds;
                }
                request.StoreGroupIds = null;

                storeDetails = (await _storeServiceClient.GetStoresForDashboard(request)).Data ?? new List<StoresSearchModel>();

                if (storeDetails.Any() && storeDetails != null)
                {
                    query.StoreIds = storeDetails.Select(t => t.StoreId).Distinct().ToArray();
                }
                else
                {
                    return res;
                }
            }
            if (query.AppIds != null && query.AppIds.Length > 0)
            {
                GetStoresForDashboardQuery request = new GetStoresForDashboardQuery();
                request.StateId = 0;
                request.StoreGroupIds = new List<int>();
                request.UserId = _authenticationProvider.GetUserAuthentication().UserId;
                request.AppIds = query.AppIds;
                storeDetails = (await _storeServiceClient.GetStoresForDashboard(request)).Data ?? new List<StoresSearchModel>();
                if (storeDetails.Any() && storeDetails != null)
                {
                    query.StoreIds = storeDetails.Select(t => t.StoreId).Distinct().ToArray();
                }
                else
                {
                    return res;
                }
            }
            var result = await _context.Transactions.GetConsumerSummaryForDashboard(query.StartDate, query.EndDate, query.StoreIds, query.UserId, query.Month, query.Year);

            if (result != null)
            {
                result.consumerModel = await _context.Transactions.GetConsumerDetailsForDashboard(query.StartDate, query.EndDate, query.StoreIds, query.UserId, query.Month, query.Year);

                if (result.consumerModel != null && result.consumerModel.Count() > 0)
                {
                    try
                    {
                        // ICollection<SpiTech.Service.Clients.Identity.UserModel> userDetails = new List<SpiTech.Service.Clients.Identity.UserModel>();
                        System.Collections.Generic.IEnumerable<int> userIds = result.consumerModel.Select(t => t.UserId).Distinct();
                        System.Collections.Generic.ICollection<Service.Clients.Identity.UserModel> userList = await _identityServiceClient.GetUserListAsync(userIds);
                        GetConsumersRewardDetailsDashboardQuery req = new GetConsumersRewardDetailsDashboardQuery();
                        req.StartDate = query.StartDate;
                        req.EndDate = query.EndDate;
                        req.StoreIds = query.StoreIds;
                        req.UserIds = userIds.ToArray();
                        req.Month = query.Month;
                        req.Year = query.Year;
                        if (req.UserIds.Count() > 0)
                        {
                            var rewardDetails = await _financeServiceClient.ConsumersRewardDetailsForDashBoardAsync(req, cancellationToken);


                            if (userList != null)
                            {
                                foreach (var item in result.consumerModel)
                                {
                                    var resultdata = userList.Where(t => t.UserId == item.UserId).ToList();
                                    foreach (var itmes in resultdata)
                                    {
                                        item.UserName = itmes.DisplayName;
                                    }
                                    if (rewardDetails.Data != null)
                                    {
                                        if ((rewardDetails.Data.Where(x => x.UserId == item.UserId)).Count() > 0)
                                        {
                                            item.TotalCashRewardEarned = (decimal)(rewardDetails.Data.Where(x => x.UserId == item.UserId)?.FirstOrDefault().Earned);
                                            item.TotalCashRewardRedeemed = (decimal)(rewardDetails.Data.Where(x => x.UserId == item.UserId)?.FirstOrDefault().Redeemed);
                                            item.TotalBalanceAmount = (decimal)(rewardDetails.Data.Where(x => x.UserId == item.UserId)?.FirstOrDefault().Balance);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    { throw; }
                    result.TotalConsumerAmount = result.consumerModel.Sum(t => t.TotalAmount);
                    result.TotalConsumerTransactions = result.consumerModel.Sum(t => t.TotalTransactions);
                    result.TotalConsumerAmountPump = result.consumerModel.Sum(t => t.TotalAmountPump);
                    result.TotalConsumerAmountStore = result.consumerModel.Sum(t => t.TotalAmountStore);
                    result.TotalConsumerStoreTransactions = result.consumerModel.Sum(t => t.TotalStoreTransactions);
                    result.TotalConsumerCashRewardEarned = result.consumerModel.Sum(t => t.TotalCashRewardEarned);
                    result.TotalConsumerCashRewardRedeemed = result.consumerModel.Sum(t => t.TotalCashRewardRedeemed);
                    result.TotalConsumerBalanceAmount = result.consumerModel.Sum(t => t.TotalBalanceAmount);
                }
                res.Success = true;
                res.Data = result;
            }
            _logger.TraceExitMethod(nameof(Handle), result);

            return res;
        }
    }
}
