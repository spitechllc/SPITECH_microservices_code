﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.Queries.DashBoardApis.GetDashboardSaleItemsDetails;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.DashboardApis.GetDashboardSaleItemsDetails
{
   public class GetDashboardSaleItemsDetailsHandler : IRequestHandler<GetDashboardSaleItemsDetailsQuery, ResponseList<DashboardSaleItemsModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetDashboardSaleItemsDetailsHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IStoreServiceClient _storeServiceClient;
        private readonly IUserAuthenticationProvider _authenticationProvider;

        public GetDashboardSaleItemsDetailsHandler(IUnitOfWork context,
                                    ILogger<GetDashboardSaleItemsDetailsHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper, IStoreServiceClient storeServiceClient,
                                    IUserAuthenticationProvider authenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _storeServiceClient = storeServiceClient;
            _authenticationProvider = authenticationProvider;
        }
        public async Task<ResponseList<DashboardSaleItemsModel>> Handle(GetDashboardSaleItemsDetailsQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            ResponseList<DashboardSaleItemsModel> res = new();
            ICollection<StoresSearchModel> storeDetails = new List<StoresSearchModel>();
            if (!query.StoreIds.Any())
            {               
                    GetStoresForDashboardQuery request = new GetStoresForDashboardQuery();
                    request.StateId = query.StateId;
                    request.City = query.City;
                    request.Zipcode = query.Zipcode;
                    request.UserId = _authenticationProvider.GetUserAuthentication().UserId;
                    request.CompanyId = query.CompanyId;
                    request.StoreGroupIds = query.StoreGroupIds;
                    request.RoleId = query.RoleId;

                    storeDetails = (await _storeServiceClient.GetStoresForDashboard(request)).Data ?? new List<StoresSearchModel>();
             
                if (storeDetails.Any() && storeDetails != null)
                {
                    query.StoreIds = storeDetails.Select(t => t.StoreId).Distinct().ToArray();
                }
            }

            var result = await _context.Transactions.GetSaleItemInfoForDashBoard(query.StartDate, query.EndDate, query.StoreIds, query.UserId, query.Month, query.Year);
            if (result!=null)
            {
                res.Data = result;
            }
            _logger.TraceExitMethod(nameof(Handle), result);

            return res;
        }
    }
}
