﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.DashboardApis.GetMobileDashboardYearWiseTransactionDetails
{
    public class GetMobileDashboardYearWiseTransactionDetailsHandler : IRequestHandler<GetMobileDashboardYearWiseTransactionDetailsQuery, ResponseList<DashboardYearWiseModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetMobileDashboardYearWiseTransactionDetailsHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IStoreServiceClient _storeServiceClient;
        private readonly IUserAuthenticationProvider _authenticationProvider;

        public GetMobileDashboardYearWiseTransactionDetailsHandler(IUnitOfWork context,
                                    ILogger<GetMobileDashboardYearWiseTransactionDetailsHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper,
                                    IStoreServiceClient storeServiceClient,
                                    IUserAuthenticationProvider authenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _storeServiceClient = storeServiceClient;
            _authenticationProvider = authenticationProvider;
        }
        public async Task<ResponseList<DashboardYearWiseModel>> Handle(GetMobileDashboardYearWiseTransactionDetailsQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            ResponseList<DashboardYearWiseModel> res = new();
            ICollection<StoreGroupUsersModel> storeDetails = new List<StoreGroupUsersModel>();
            int[] StoreIds=new List<int>().ToArray();

            storeDetails = (await _storeServiceClient.StoreGroupStoresByUserIdAsync(_authenticationProvider.GetUserAuthentication().UserId, cancellationToken)).Data ?? new List<StoreGroupUsersModel>();

            if (storeDetails.Any() && storeDetails != null)
            {
                StoreIds = storeDetails.Select(t => t.StoreId).Distinct().ToArray();
                var result = await _context.Transactions.GetYearwiseDetailForDashboard(query.StartDate,query.EndDate, StoreIds, null, null, null);
                if (result != null)
                {
                    foreach (var item in result)
                    {
                        item.monthWiseDetails = await _context.Transactions.GetMonthWiseDetailForDashboard(item.years, 0, StoreIds, null);
                        foreach (var month in item.monthWiseDetails)
                        {
                            month.monthWiseStoreTransactionModel = await _context.Transactions.GetStoreTransactionDetailsForDashboard(null, null, StoreIds, null, month.MonthId, item.years, null, null);

                            if (month.monthWiseStoreTransactionModel != null)
                            {
                                month.MonthlyTotalStoreAmount = month.monthWiseStoreTransactionModel.Sum(t => t.TotalSuccessAmount);
                                month.MonthlyTotalStoreTransactions = (int)month.monthWiseStoreTransactionModel.Sum(t => t.TotalSuccessTransactions);
                                month.MonthlyTotalStoreACHAmount = month.monthWiseStoreTransactionModel.Sum(t => t.TotalACHAmount);
                                month.MonthlyTotalStoreACHTransactions = (int)month.monthWiseStoreTransactionModel.Sum(t => t.TotalACHTransactions);
                                month.MonthlyTotalStoreCardAmount = month.monthWiseStoreTransactionModel.Sum(t => t.TotalCardAmount);
                                month.MonthlyTotalStoreCardTransactions = (int)month.monthWiseStoreTransactionModel.Sum(t => t.TotalCardTransactions);
                                month.MonthlyTotalStoreWalletAmount = month.monthWiseStoreTransactionModel.Sum(t => t.TotalWalletAmount);
                                month.MonthlyTotalStoreWalletTransactions = (int)month.monthWiseStoreTransactionModel.Sum(t => t.TotalWalletTransactions);
                                //day wise store data
                                foreach (var store in month.monthWiseStoreTransactionModel)
                                {
                                    store.dayWiseStoreDetails = await _context.Transactions.GetDayWiseStoreTransactionDetailsForDashboard(store.StoreId, null, month.MonthId, item.years, null, null);
                                }
                            }
                        }
                    }
                    res.Data = result;
                }
                _logger.TraceExitMethod(nameof(Handle), result);
            }
            

            return res;
        }
    }
}
