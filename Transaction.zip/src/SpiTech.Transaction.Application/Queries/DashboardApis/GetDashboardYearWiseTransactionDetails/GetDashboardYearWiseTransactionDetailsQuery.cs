﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using System;

namespace SpiTech.Transaction.Application.Queries.DashboardApis.GetDashboardYearWiseTransactionDetails
{
    public class GetDashboardYearWiseTransactionDetailsQuery: IRequest<ResponseList<DashboardYearWiseModel>>
    {
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int[] StoreIds { get; set; }
        public int? UserId { get; set; }
        public int? Month { get; set; }
        public int? Year { get; set; }
        public string Zipcode { get; set; }
        public string City { get; set; }
        public int? StateId { get; set; }
        public int? CompanyId { get; set; }
        public int[] StoreGroupIds { get; set; }
    }
   
}