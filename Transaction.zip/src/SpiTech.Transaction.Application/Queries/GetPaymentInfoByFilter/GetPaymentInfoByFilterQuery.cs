﻿using MediatR;
using SpiTech.Transaction.Domain.Entities;

namespace SpiTech.Transaction.Application.Queries.GetPaymentInfoByFilter
{
    public class GetPaymentInfoByFilterQuery : IRequest<PaymentInfo>
    {
        public long TransactionId { get; set; }
    }
}
