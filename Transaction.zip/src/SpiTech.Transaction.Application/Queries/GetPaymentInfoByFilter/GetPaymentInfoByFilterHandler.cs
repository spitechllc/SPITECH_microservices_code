﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetPaymentInfoByFilter
{
    public class GetPaymentInfoByFilterHandler : IRequestHandler<GetPaymentInfoByFilterQuery, PaymentInfo>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetPaymentInfoByFilterHandler> _logger;
        private readonly IMapper _mapper;
        public GetPaymentInfoByFilterHandler(IUnitOfWork context,
                                             ILogger<GetPaymentInfoByFilterHandler> logger,
                                             IMapper mapper
                                           )
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<PaymentInfo> Handle(GetPaymentInfoByFilterQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            PaymentInfo result = (await _context.PaymentInfos.GetPaymentInfoByfilter(request.TransactionId)).FirstOrDefault();

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
