﻿using Azure.Core;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetEodSettlement
{
    public class GetEodSettlementHandler : IRequestHandler<GetEodSettlementQuery, SettlementPaginatedList>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetEodSettlementHandler> logger;
        private readonly IMediator mediator;
        private readonly IIdentityServiceClient _identityServiceClient;
        private readonly IPaymentServiceClient _paymentServiceClient;
        private string IAccToken = string.Empty;
        public GetEodSettlementHandler(IUnitOfWork context,
                                    ILogger<GetEodSettlementHandler> logger,
                                    IMediator mediator, IIdentityServiceClient identityServiceClient,
                                    IPaymentServiceClient paymentServiceClient)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            _identityServiceClient = identityServiceClient;
            _paymentServiceClient = paymentServiceClient;
        }

        public async Task<SettlementPaginatedList> Handle(GetEodSettlementQuery query, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), query);
            EodSettlementAggregateModel aggregateResult = null;

            var result = await context.SettlementRequests.GetByFilter(query.BusinessDate,
                                                                    query.StoreId,
                                                                    query.IsNeedReview,
                                                                    query.CardPayment,
                                                                    query.CashRewardPayment,
                                                                    query.AchPayment,
                                                                    query.AmountMatched,
                                                                    query.HasTransactionAmount,
                                                                    query.PageIndex,
                                                                    query.PageSize,
                                                                    query.SortBy,
                                                                    query.SortOrder);
            int totalrecord = 0;
            string UserName = "";
            var UserMop = await _paymentServiceClient.GetAllUserMOPAsync();

            foreach (var item in result)
            {
                decimal TotalACH = 0;
                decimal TotalCard = 0;
                decimal? TotalWallet = 0;

                List<TransactionDetailEOD> Details = new List<TransactionDetailEOD>();
                var tranDetails = await context.Transactions.TransactionDetailEod(item.SettlementRequestId, item.StoreId.ToString(),item.SiteId);

                foreach (var itemtotalAmount in tranDetails)
                {
                    TotalACH = TotalACH + itemtotalAmount.NewAchAmount;
                    TotalCard = TotalCard + itemtotalAmount.NewCardAmount;
                    TotalWallet = TotalWallet + itemtotalAmount.WalletAmount;
                }

                if (tranDetails.Count() > 0)
                {
                    foreach (var itemTranDetail in tranDetails)
                    {
                        int intValue = itemTranDetail.UserId;
                        int[] intArray = new int[] { intValue };
                        ICollection<Service.Clients.Identity.UserModel> userList = await _identityServiceClient.GetUserListAsync(intArray);

                        if (userList.Count() == 0)
                        {
                            UserName = "User Not found";
                        }
                        else {
                            UserName = userList.Where(t => t.UserId == itemTranDetail.UserId)?.FirstOrDefault().UserName;
                        }
                       var AccessToken = UserMop.Data.Where(x => x.UserId == itemTranDetail.UserId).FirstOrDefault();
                        var itemDetail = new TransactionDetailEOD()
                        {
                            TransactionId= itemTranDetail.TransactionId,
                            SettlementRequestId = itemTranDetail.SettlementRequestId,
                            StoreName = itemTranDetail.StoreName,
                            TransactionDate= itemTranDetail.TransactionDate,
                            UserId = itemTranDetail.UserId,
                            UserName= UserName,
                            CheckBalance = "BalanceBtn",
                            AccessToken = AccessToken == null ? IAccToken = string.Empty : (IAccToken = AccessToken.Token),
                            FinalAmount = itemTranDetail.FinalAmount,
                            CardAmount = itemTranDetail.CardAmount,
                            WalletAmount = itemTranDetail.WalletAmount,
                            NewCardAmount= itemTranDetail.NewCardAmount,
                            NewAchAmount= itemTranDetail.NewAchAmount,
                            NewPaymentMethod= itemTranDetail.NewPaymentMethod,
                            UserPaymentMethodId = itemTranDetail.UserPaymentMethodId,
                            PaymentMethodId = itemTranDetail.PaymentMethodId,
                            AchPaymentStatusId = itemTranDetail.AchPaymentStatusId,
                            CardPaymentStatusId= itemTranDetail.CardPaymentStatusId,
                            CashRewardPaymentStatusId= itemTranDetail.CashRewardPaymentStatusId,
                            MerchantPay =itemTranDetail.MerchantPay,
                            ConsumerPay = itemTranDetail.ConsumerPay,
                            MerchantPaid = itemTranDetail.MerchantPaid,
                            ConsumerPaid = itemTranDetail.ConsumerPaid,
                            ACHTotal = TotalACH,
                            CardTotal= TotalCard
                        };
                        Details.Add(itemDetail);
                    }

                    var itemTotal = new TransactionDetailEOD()
                    {
                        AchPaymentStatusId = 5,
                        CardPaymentStatusId = 5,
                        CashRewardPaymentStatusId = 5,
                        NewAchAmount = TotalACH,
                        NewCardAmount = TotalCard,
                        WalletAmount= TotalWallet,
                        MerchantPay = true,
                        ConsumerPay = true,
                    };
                    Details.Add(itemTotal);
                }
                
                item.TransactionDetailsEod = Details;
            }

            if (result != null && result.Count() > 0)
            {
                aggregateResult = await context.SettlementRequests.GetEodSettlementAggregateByFilter(query.BusinessDate,
                   query.StoreId,
                   query.IsNeedReview,
                   query.HasTransactionAmount,
                   query.CardPayment,
                   query.CashRewardPayment,
                   query.AchPayment,
                   query.AmountMatched);
                totalrecord = result.Select(x => x.TotalRecord).FirstOrDefault();
            }

            SettlementPaginatedList response = new()
            {
                Data = result.ToList(),
                PageIndex = query.PageIndex,
                PageSize = query.PageSize,
                TotalCount = totalrecord,
                TotalAchAmount = aggregateResult?.TotalAchAmount ?? 0,
                TotalCardAmount = aggregateResult?.TotalCardAmount ?? 0,
                TotalCashRewardAmount = aggregateResult?.TotalCashRewardAmount ?? 0,
                TotalMppaAmount = aggregateResult?.TotalMppaAmount ?? 0,
                TotalMppaCounts = aggregateResult?.TotalMppaCounts ?? 0,
                TotalTerminalAmount = aggregateResult?.TotalTerminalAmount ?? 0,
                TotalTerminalCounts = aggregateResult?.TotalTerminalCounts ?? 0
            };

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
