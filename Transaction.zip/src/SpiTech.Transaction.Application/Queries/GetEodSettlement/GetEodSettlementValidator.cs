﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetEodSettlement
{
    public class GetEodSettlementValidator : AbstractValidator<GetEodSettlementQuery>
    {
        public GetEodSettlementValidator()
        {
            RuleFor(x => x.BusinessDate).NotNull().GreaterThan(new System.DateTime(2021, 1, 1)).WithMessage("Invalid Date. Transaction does not exist");
        }
    }
}
