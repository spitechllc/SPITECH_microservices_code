﻿using MediatR;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetResellerMonthlyInvoicePdf
{
    public class GetResellerMonthlyInvoicePdfQuery : IRequest<InvoiceFileBytesModel>
    {
        public int ResellerBillingId { get; set; }
    }
}
