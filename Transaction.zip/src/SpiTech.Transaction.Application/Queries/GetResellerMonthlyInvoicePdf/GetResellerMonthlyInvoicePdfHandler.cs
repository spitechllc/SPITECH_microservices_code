﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.Services;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetResellerMonthlyInvoicePdf
{
    public class GetResellerMonthlyInvoicePdfHandler : IRequestHandler<GetResellerMonthlyInvoicePdfQuery, InvoiceFileBytesModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetResellerMonthlyInvoicePdfHandler> logger;
        private readonly IStorageService storageService;
        private readonly IStoreServiceClient _storeapiclient;
        private readonly IPaymentServiceClient _paymentapiclient;
        private readonly IHtmlPdfConverterService converterService;

        public GetResellerMonthlyInvoicePdfHandler(IUnitOfWork context,
                                                ILogger<GetResellerMonthlyInvoicePdfHandler> logger,
                                                IStorageServiceFactory storageServiceFactory,
                                                IStoreServiceClient storeapiclient,
                                                IPaymentServiceClient paymentapiclient,
                                                IHtmlPdfConverterService converterService
                                    )
        {
            this.context = context;
            this.logger = logger;
            storageService = storageServiceFactory.Get(ContainerType.ResellerMonthlyInvoicePdf);
            _storeapiclient = storeapiclient;
            _paymentapiclient = paymentapiclient;
            this.converterService = converterService;
        }

        public async Task<InvoiceFileBytesModel> Handle(GetResellerMonthlyInvoicePdfQuery query, CancellationToken cancellationToken)
        {
            InvoiceFileBytesModel response = null;
            logger.TraceEnterMethod(nameof(Handle), query);

            var resellerBilling = (await context.ResellerBillings.GetBills(query.ResellerBillingId)).FirstOrDefault();

            if (resellerBilling == null)
            {
                return null;
            }

            if (!string.IsNullOrWhiteSpace(resellerBilling.InvoiceFilePath))
            {
                response = new InvoiceFileBytesModel();
                response.File = resellerBilling.InvoiceFileName;
                response.Bytes = await storageService.DownloadBytesAsync(resellerBilling.InvoiceFilePath);
            }
            else
            {
                response = new InvoiceFileBytesModel();
                var salesAgent = (await _storeapiclient.ResellersAsync(new[] { resellerBilling.ResellerId }, cancellationToken)).FirstOrDefault();

                resellerBilling.ResellerName = salesAgent?.FirstName + " " + salesAgent?.LastName;

                response.Bytes = await this.converterService.CreatePdfFromView("ResellerMonthlyInvoice", resellerBilling);
                response.File = "ResellerMonthlyInvoice.pdf";
            }

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
