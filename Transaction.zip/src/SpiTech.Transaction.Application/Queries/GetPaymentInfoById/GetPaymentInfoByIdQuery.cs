﻿using MediatR;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetPaymentInfoById
{
    public class GetPaymentInfoByIdQuery : IRequest<PaymentInfoModel>
    {
        public int PaymentInfoId { get; set; }
    }
}
