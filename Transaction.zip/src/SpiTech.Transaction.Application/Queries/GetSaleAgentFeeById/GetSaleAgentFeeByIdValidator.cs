﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetSaleAgentFeeById
{
    public class GetSaleAgentFeeByIdValidator : AbstractValidator<GetSaleAgentFeeByIdQuery>
    {
        public GetSaleAgentFeeByIdValidator()
        {
            RuleFor(s => s.SaleAgentFeeId).GreaterThan(0);
        }
    }
}
