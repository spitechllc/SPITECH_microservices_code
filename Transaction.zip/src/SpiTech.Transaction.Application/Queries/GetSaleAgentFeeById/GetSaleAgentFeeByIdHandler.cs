﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetSaleAgentFeeById
{
    public class GetSaleAgentFeeByIdHandler : IRequestHandler<GetSaleAgentFeeByIdQuery, SaleAgentFee>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetSaleAgentFeeByIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetSaleAgentFeeByIdHandler(IUnitOfWork context,
                                    ILogger<GetSaleAgentFeeByIdHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<SaleAgentFee> Handle(GetSaleAgentFeeByIdQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            var result = await _context.SaleAgentFees.Get(query.SaleAgentFeeId);

            _logger.TraceExitMethod(nameof(Handle), result);

            return await Task.FromResult(result);
        }
    }
}
