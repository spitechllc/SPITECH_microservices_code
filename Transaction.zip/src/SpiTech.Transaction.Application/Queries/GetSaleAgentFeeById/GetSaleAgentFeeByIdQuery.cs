﻿using MediatR;
using SpiTech.Transaction.Domain.Entities;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetSaleAgentFeeById
{
    public class GetSaleAgentFeeByIdQuery : IRequest<SaleAgentFee>
    {
        public int SaleAgentFeeId { get; set; }
    }
}
