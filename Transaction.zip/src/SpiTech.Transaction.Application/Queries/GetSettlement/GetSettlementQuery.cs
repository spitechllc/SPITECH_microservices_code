﻿using MediatR;
using SpiTech.Transaction.Domain.Entities;
using System;
using System.Collections.Generic;

namespace SpiTech.Transaction.Application.Queries.GetSettlement
{
    public class GetSettlementQuery : IRequest<IEnumerable<SettlementRequest>>
    {
        public string SiteId { get; set; }
        public DateTime StartDateUtc { get; set; }
        public DateTime EndDateUtc { get; set; }
    }
}
