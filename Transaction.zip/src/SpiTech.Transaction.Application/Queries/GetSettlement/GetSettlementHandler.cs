﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetSettlement
{
    public class GetSettlementHandler : IRequestHandler<GetSettlementQuery, IEnumerable<SettlementRequest>>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetSettlementHandler> logger;
        private readonly IMediator mediator;

        public GetSettlementHandler(IUnitOfWork context,
                                    ILogger<GetSettlementHandler> logger,
                                    IMediator mediator)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
        }

        public async Task<IEnumerable<SettlementRequest>> Handle(GetSettlementQuery query, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), query);

            IEnumerable<SettlementRequest> response = await context.SettlementRequests.GetByFilter(query.SiteId, query.StartDateUtc, query.EndDateUtc);

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
