﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetSettlement
{
    public class GetSettlementValidator : AbstractValidator<GetSettlementQuery>
    {
        public GetSettlementValidator()
        {
            RuleFor(x => x.StartDateUtc).NotNull().GreaterThan(new System.DateTime(2021, 1, 1)).WithMessage("Invalid Date. Transaction does not exist");
            RuleFor(x => x.EndDateUtc).NotNull().GreaterThan(new System.DateTime(2021, 1, 1)).WithMessage("Invalid Date. Transaction does not exist");
        }
    }
}
