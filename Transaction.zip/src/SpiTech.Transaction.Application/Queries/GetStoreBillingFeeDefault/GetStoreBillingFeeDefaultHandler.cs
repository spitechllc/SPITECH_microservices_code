﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetStoreBillingFeeDefault
{
    public class GetStoreBillingFeeDefaultHandler : IRequestHandler<GetStoreBillingFeeDefaultQuery, List<StoreBillingFeeModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetStoreBillingFeeDefaultHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetStoreBillingFeeDefaultHandler(IUnitOfWork context,
                                    ILogger<GetStoreBillingFeeDefaultHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<List<StoreBillingFeeModel>> Handle(GetStoreBillingFeeDefaultQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            List<StoreBillingFeeModel> result = await _context.StoreBillingFees.GetDefaultFees();

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;

        }
    }
}
