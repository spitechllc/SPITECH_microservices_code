﻿using MediatR;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.Transaction.Application.Queries.GetStoreBillingFeeDefault
{
    public class GetStoreBillingFeeDefaultQuery : IRequest<List<StoreBillingFeeModel>>
    {
    }
}
