﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetReceiptInfo
{
    public class GetReceiptInfoValidator : AbstractValidator<GetReceiptInfoQuery>
    {
        public GetReceiptInfoValidator()
        {
            RuleFor(x => x).Must(t => t.TransactionId > 0).WithMessage("TransactionId required");
        }
    }
}
