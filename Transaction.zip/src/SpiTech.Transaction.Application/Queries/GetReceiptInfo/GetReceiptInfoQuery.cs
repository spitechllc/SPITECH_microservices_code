﻿using MediatR;
using SpiTech.EventBus.DomainEvents.Models.Mppa.Receipts;

namespace SpiTech.Transaction.Application.Queries.GetReceiptInfo
{
    public class GetReceiptInfoQuery : IRequest<TransactionReceiptModel>
    {
        public long TransactionId { get; set; }
    }
}
