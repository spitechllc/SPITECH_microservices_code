﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Models.Mppa.Receipts;
using SpiTech.Transaction.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetReceiptInfo
{
    public class GetReceiptInfoHandler : IRequestHandler<GetReceiptInfoQuery, TransactionReceiptModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetReceiptInfoHandler> _logger;
        private readonly IMapper _mapper;
        public GetReceiptInfoHandler(IUnitOfWork context,
                                             ILogger<GetReceiptInfoHandler> logger,
                                             IMapper mapper
                                           )
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<TransactionReceiptModel> Handle(GetReceiptInfoQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            TransactionReceiptModel result = await _context.ReceiptInfoLines.GetReceiptInfo(request.TransactionId);

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
