﻿using MediatR;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetEodInvoicePreViewPdf
{
    public class GetEodInvoicePreViewPdfQuery : IRequest<InvoiceFileBytesModel>
    {
        public int SettlementRequestId { get; set; }
    }
}
