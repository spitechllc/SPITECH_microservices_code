﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Service.Clients.Finance;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.Services;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetEodInvoicePreViewPdf
{
    public class GetEodInvoicePreViewPdfHandler : IRequestHandler<GetEodInvoicePreViewPdfQuery, InvoiceFileBytesModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetEodInvoicePreViewPdfHandler> logger;
        private readonly IStorageService storageService;
        private readonly IStoreServiceClient _storeapiclient;
        private readonly IFinanceServiceClient _financeapiclient;
        private readonly IPaymentServiceClient _paymentapiclient;
        private readonly IHtmlPdfConverterService converterService;

        public GetEodInvoicePreViewPdfHandler(IUnitOfWork context,
                                            ILogger<GetEodInvoicePreViewPdfHandler> logger,
                                            IStorageServiceFactory storageServiceFactory,
                                            IStoreServiceClient storeapiclient,
                                            IFinanceServiceClient financeapiclient,
                                            IPaymentServiceClient paymentapiclient,
                                            IHtmlPdfConverterService converterService
                                            )
        {
            this.context = context;
            this.logger = logger;
            storageService = storageServiceFactory.Get(ContainerType.EodPdf);
            _storeapiclient = storeapiclient;
            _financeapiclient = financeapiclient;
            _paymentapiclient = paymentapiclient;
            this.converterService = converterService;
        }

        public async Task<InvoiceFileBytesModel> Handle(GetEodInvoicePreViewPdfQuery query, CancellationToken cancellationToken)
        {
            InvoiceFileBytesModel response = null;
            logger.TraceEnterMethod(nameof(Handle), query);

            Domain.Entities.SettlementRequest settlementRequest = await context.SettlementRequests.Get(query.SettlementRequestId);

            if (settlementRequest == null)
            {
                return null;
            }

            if (!string.IsNullOrWhiteSpace(settlementRequest.SettlementFilePath))
            {
                response = new InvoiceFileBytesModel();
                response.File = settlementRequest.SettlementFileName;
                response.Bytes = await storageService.DownloadBytesAsync(settlementRequest.SettlementFilePath);
            }
            else
            {
                var storeEodSettlement = await context.SettlementRequests.GetStoreEodSettlement(query.SettlementRequestId);

                if (storeEodSettlement != null)
                {
                    response = new InvoiceFileBytesModel();

                    List<Service.Clients.Stores.StoreSearchResult> storeDetails = (await _storeapiclient.GetStoresPrimaryDetailsBySiteIdsAsync(new[] { storeEodSettlement.SiteID })).ToList();

                    DateTime businessDate = DateTime.SpecifyKind(storeEodSettlement.BusinessDate, DateTimeKind.Utc);

                    GetCashRewardDetailsByFilterQuery request = new()
                    {
                        StoreIds = new[] { storeEodSettlement.StoreId },
                        StartDate = businessDate.Date,
                        EndDate = businessDate.Date.AddDays(1).AddTicks(-1)
                    };

                    var cashRewards = (await _financeapiclient.GetCashRewardDetailsByStoreIdAsync(request)).ToList();

                    storeEodSettlement.PaymentMethodDetails = (await context.Transactions.GetPaymentMethodDetails(storeEodSettlement.SettlementRequestId)) ?? new List<PaymentMethodDetail>();

                    storeEodSettlement.StoreId = storeDetails.Where(s => s.SiteId == storeEodSettlement.SiteID).FirstOrDefault()?.StoreId ?? 0;
                    storeEodSettlement.StoreName = storeDetails.Where(s => s.SiteId == storeEodSettlement.SiteID).FirstOrDefault()?.StoreName;

                    ICollection<Service.Clients.Stores.AddressModel> address = storeDetails.Where(s => s.SiteId == storeEodSettlement.SiteID).FirstOrDefault()?.Addresses;

                    if (address != null)
                    {
                        storeEodSettlement.StoreAddress = address.FirstOrDefault()?.AddressLine1 + " " + address.FirstOrDefault()?.AddressLine2;
                    }

                    if (cashRewards != null)
                    {
                        storeEodSettlement.TotalCashRewardAwarded = cashRewards.Where(s => s.StoreId == storeEodSettlement.StoreId).Sum(t => t.TotalEarned);
                        storeEodSettlement.TotalCashRewardRedeemed = cashRewards.Where(s => s.StoreId == storeEodSettlement.StoreId).Sum(t => t.TotalRedeemed);
                    }

                    response.Bytes = await this.converterService.CreatePdfFromView("StoreEodInvoice", storeEodSettlement);
                    response.File = "StoreEodInvoice.pdf";
                }
            }

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
