﻿using MediatR;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetStoreMonthlyInvoicePdf
{
    public class GetStoreMonthlyInvoicePdfQuery : IRequest<InvoiceFileBytesModel>
    {
        public int StoreBillingId { get; set; }
    }
}
