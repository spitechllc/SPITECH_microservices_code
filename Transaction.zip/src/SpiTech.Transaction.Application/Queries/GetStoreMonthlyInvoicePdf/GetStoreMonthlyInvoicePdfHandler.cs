﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Service.Clients.Finance;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.Services;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetStoreMonthlyInvoicePdf
{
    public class GetStoreMonthlyInvoicePdfHandler : IRequestHandler<GetStoreMonthlyInvoicePdfQuery, InvoiceFileBytesModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetStoreMonthlyInvoicePdfHandler> logger;
        private readonly IStorageService storageService;
        private readonly IStoreServiceClient storeServiceClient;
        private readonly IFinanceServiceClient financeServiceClient;
        private readonly IPaymentServiceClient paymentServiceClient;
        private readonly IHtmlPdfConverterService converterService;
        private readonly IMapper mapper;

        public GetStoreMonthlyInvoicePdfHandler(IUnitOfWork context,
                                                ILogger<GetStoreMonthlyInvoicePdfHandler> logger,
                                                IStorageServiceFactory storageServiceFactory,
                                                IStoreServiceClient storeServiceClient,
                                                IFinanceServiceClient financeServiceClient,
                                                IPaymentServiceClient paymentServiceClient,
                                                IHtmlPdfConverterService converterService,
                                                AutoMapper.IMapper mapper
                                    )
        {
            this.context = context;
            this.logger = logger;
            storageService = storageServiceFactory.Get(ContainerType.MonthlyInvoicePdf);
            this.storeServiceClient = storeServiceClient;
            this.financeServiceClient = financeServiceClient;
            this.paymentServiceClient = paymentServiceClient;
            this.converterService = converterService;
            this.mapper = mapper;
        }

        public async Task<InvoiceFileBytesModel> Handle(GetStoreMonthlyInvoicePdfQuery query, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), query);

            var storeBilling = await context.StoreBillings.GetMontlyBillingForInvoice(query.StoreBillingId);

            if (storeBilling == null)
            {
                return null;
            }

            InvoiceFileBytesModel response = new InvoiceFileBytesModel();

            if (!string.IsNullOrWhiteSpace(storeBilling.InvoiceFilePath))
            {
                response.File = storeBilling.InvoiceFileName;
                response.Bytes = await storageService.DownloadBytesAsync(storeBilling.InvoiceFilePath);
            }
            else
            {
                if (!storeBilling.StoreBillingDetails.Any(t => t.PaymentMethodId == 1))
                {
                    storeBilling.StoreBillingDetails.Add(new StoreBillingDetailModel { PaymentMethodId = 1 });
                }

                if (!storeBilling.StoreBillingDetails.Any(t => t.PaymentMethodId == 2))
                {
                    storeBilling.StoreBillingDetails.Add(new StoreBillingDetailModel { PaymentMethodId = 2 });
                }

                if (!storeBilling.StoreBillingDetails.Any(t => t.PaymentMethodId == 3))
                {
                    storeBilling.StoreBillingDetails.Add(new StoreBillingDetailModel { PaymentMethodId = 3 });
                }

                storeBilling.StoreBillingDetails = storeBilling.StoreBillingDetails.OrderBy(t => t.PaymentMethodId).ToList();

                var storeBillingInvoiceModel = new StoreBillingInvoiceModel
                {
                    StoreBilling = storeBilling
                };

                Service.Clients.Stores.StoreInfoModel store = await storeServiceClient.GetStoreInfoAsync(storeBilling.StoreId, "");

                Service.Clients.Stores.AddressModel address = store.Addresses.FirstOrDefault();

                if (address != null)
                {
                    storeBillingInvoiceModel.StoreBilling.StoreAddress = new EventBus.DomainEvents.Models.Address
                    {
                        AddressLine1 = address.AddressLine1,
                        AddressLine2 = address.AddressLine2,
                        City = address.City,
                        Country = address.Country,
                        State = address.State,
                        ZipCode = address.ZipCode,
                    };
                }

                DateTime from = DateTime.SpecifyKind(new DateTime(storeBilling.Year, storeBilling.Month, 1), DateTimeKind.Utc);
                DateTime to = from.AddMonths(1).AddTicks(-1);

                GetCashRewardDetailsByFilterQuery request = new()
                {
                    StoreIds = new List<int>() { storeBilling.StoreId },
                    StartDate = from,
                    EndDate = to
                };

                var cashReward = (await financeServiceClient.GetCashRewardDetailsByStoreIdAsync(request)).ToList();

                if (cashReward != null)
                {
                    storeBillingInvoiceModel.TotalCashBackEarned = (decimal)cashReward.Where(s => s.StoreId == storeBilling.StoreId).Sum(t => t.TotalEarned);
                }

                response.Bytes = await this.converterService.CreatePdfFromView("StoreMonthlyInvoice", storeBillingInvoiceModel);
                response.File = "StoreMonthlyInvoice.pdf";
            }

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
