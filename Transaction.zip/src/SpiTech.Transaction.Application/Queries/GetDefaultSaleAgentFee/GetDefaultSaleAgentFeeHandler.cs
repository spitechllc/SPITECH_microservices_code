﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetDefaultSaleAgentFee
{
    public class GetDefaultSaleAgentFeeHandler : IRequestHandler<GetDefaultSaleAgentFeeQuery, SaleAgentFee>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetDefaultSaleAgentFeeHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetDefaultSaleAgentFeeHandler(IUnitOfWork context,
                                    ILogger<GetDefaultSaleAgentFeeHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<SaleAgentFee> Handle(GetDefaultSaleAgentFeeQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            var result = await _context.SaleAgentFees.GetDefaultSaleAgentFees();

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;

        }
    }
}
