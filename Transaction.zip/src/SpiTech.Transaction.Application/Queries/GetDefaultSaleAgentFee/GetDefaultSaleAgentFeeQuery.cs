﻿using MediatR;
using SpiTech.Transaction.Domain.Entities;

namespace SpiTech.Transaction.Application.Queries.GetDefaultSaleAgentFee
{
    public class GetDefaultSaleAgentFeeQuery : IRequest<SaleAgentFee>
    {
    }
}
