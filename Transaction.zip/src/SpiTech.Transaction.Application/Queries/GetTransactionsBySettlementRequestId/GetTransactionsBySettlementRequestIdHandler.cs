﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetTransactionsBySettlementRequestId
{
    public class GetTransactionsBySettlementRequestIdHandler :
        IRequestHandler<GetTransactionsBySettlementRequestIdQuery, IEnumerable<TransactionModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetTransactionsBySettlementRequestIdHandler> _logger;
        private readonly IMapper _mapper;

        public GetTransactionsBySettlementRequestIdHandler(IUnitOfWork context,
                                             ILogger<GetTransactionsBySettlementRequestIdHandler> logger,
                                             IMapper mapper
                                             )
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<IEnumerable<TransactionModel>> Handle(GetTransactionsBySettlementRequestIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            List<TransactionModel> result = await _context.Transactions.GetTransactionBySettlementRequestId(request.SettlementRequestId);

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
