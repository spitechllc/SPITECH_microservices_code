﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetTransactionsBySettlementRequestId
{
    public class GetTransactionsBySettlementRequestIdValidator : AbstractValidator<GetTransactionsBySettlementRequestIdQuery>
    {
        public GetTransactionsBySettlementRequestIdValidator()
        {
            RuleFor(x => x.SettlementRequestId).GreaterThan(0).WithMessage("SettlementRequestId required");
        }
    }
}
