﻿using MediatR;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.Transaction.Application.Queries.GetTransactionsBySettlementRequestId
{
    public class GetTransactionsBySettlementRequestIdQuery : IRequest<IEnumerable<TransactionModel>>
    {
        public int SettlementRequestId { get; set; }
    }
}
