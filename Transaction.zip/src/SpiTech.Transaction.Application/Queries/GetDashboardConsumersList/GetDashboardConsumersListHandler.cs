﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Service.Clients.Identity;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Dynamic;
using System.Globalization;
using System.Linq;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetDashboardConsumersList
{
    public class GetDashboardConsumersListHandler : IRequestHandler<GetDashboardConsumersListQuery, PaginatedList<ConsumersList>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetDashboardConsumersListHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IStoreServiceClient _storeServiceClient;
        private readonly IIdentityServiceClient _identityServiceClient;
        private readonly IFinanceServiceClient _financeServiceClient;
        private readonly IUserAuthenticationProvider _authenticationProvider;
        public GetDashboardConsumersListHandler(IUnitOfWork context,
                                    ILogger<GetDashboardConsumersListHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper,
                                    IStoreServiceClient storeServiceClient, IIdentityServiceClient identityServiceClient,
                                    IFinanceServiceClient financeServiceClient,
                                    IUserAuthenticationProvider authenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _storeServiceClient = storeServiceClient;
            _identityServiceClient = identityServiceClient;
            _financeServiceClient = financeServiceClient;
            _authenticationProvider = authenticationProvider;
        }
        public async Task<PaginatedList<ConsumersList>> Handle(GetDashboardConsumersListQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            ResponseModel<DashboardConsumersListModel> res = new() { Success = false };
            ICollection<StoresSearchModel> storeDetails = new List<StoresSearchModel>();

            int totalRecord = 0;
            try
            {
                GetStoresForDashboardQuery request = new GetStoresForDashboardQuery();
                request.UserId = _authenticationProvider.GetUserAuthentication().UserId;
                request.StoreGroupIds = new int[0];

                storeDetails = (await _storeServiceClient.GetStoresForDashboard(request)).Data ?? new List<StoresSearchModel>();

                if (storeDetails.Any() && storeDetails != null)
                {
                    query.StoreIds = storeDetails.Select(t => t.StoreId).Distinct().ToArray();
                }
                if (query.AppIds != null && query.AppIds.Length > 0)
                {
                    request.AppIds = query.AppIds;
                    storeDetails = (await _storeServiceClient.GetStoresForDashboard(request)).Data ?? new List<StoresSearchModel>();
                    if (storeDetails.Any() && storeDetails != null)
                    {
                        query.StoreIds = storeDetails.Select(t => t.StoreId).Distinct().ToArray();
                    }
                }

                List<ConsumersList> result = await _context.Transactions.GetConsumerListForDashboard(query.PageIndex, query.PageSize,
                    query.SortBy, query.SortOrder, query.StoreIds);

                if (result != null && result.Count() > 0)
                {

                    totalRecord = result.Count();
                }

                if (result != null)
                {
                    IEnumerable<int> userIds = result.Select(t => t.UserId).Distinct();

                    ICollection<Service.Clients.Identity.UserModel> userList = await _identityServiceClient.GetUserListAsync(userIds);

                    IEnumerable<DashboardFinanceUserWalletDetailModel> wallerdata = _mapper.Map<IEnumerable<DashboardFinanceUserWalletDetailModel>>(await _financeServiceClient.GetWalletDetailsListByIds(userIds));


                    if (userList != null)
                    {
                        foreach (var item in result)
                        {
                            var check = userList.Where(t => t.UserId == item.UserId).FirstOrDefault();
                            if (check == null)
                            {
                                item.UserName = "user not exist";
                            }
                            if (check != null)
                            {
                                List<TenantMasterDatas> tenantMasterDatasList = new List<TenantMasterDatas>();
                                var data = userList.Where(t => t.UserId == item.UserId).ToList();
                                foreach (var datas in data)
                                {
                                    var results = datas.TenantMasterLists;
                                    TenantMasterDatas tenantMasterDatas = new TenantMasterDatas();
                                    foreach (var resultdata in results)
                                    {
                                        tenantMasterDatas.TenantId = resultdata.TenantId;
                                        tenantMasterDatas.TenantName = resultdata.TenantName;
                                        tenantMasterDatasList.Add(tenantMasterDatas);
                                    }
                                }
                                item.tenantMasterLists = tenantMasterDatasList;
                                item.UserName = userList.Where(t => t.UserId == item.UserId)?.FirstOrDefault().DisplayName;

                                if (string.IsNullOrEmpty(item.UserName))
                                {
                                    item.UserName = userList.Where(t => t.UserId == item.UserId)?.FirstOrDefault().UserName;
                                }

                                item.MemberSince = userList.Where(t => t.UserId == item.UserId)?.FirstOrDefault().CreatedOn;

                                var checkWallet = wallerdata.Where(t => t.UserId == item.UserId).FirstOrDefault();
                                if (checkWallet != null)
                                {
                                    item.TotalRewardsEarned = wallerdata.Where(t => t.UserId == item.UserId)?.FirstOrDefault().TotalReceivedAmount;

                                    item.TotalRewardsBalance = wallerdata.Where(t => t.UserId == item.UserId)?.FirstOrDefault().TotalAvailableAmount;
                                }
                            }
                        }
                    }
                }
                if (query.AppIds != null && query.AppIds.Length > 0)
                {
                    List<ConsumersList> data = new List<ConsumersList>();
                    for (int i = 0; i < query.AppIds.Length; i++)
                    {
                        int tenantId = query.AppIds[i];
                        foreach (var appId in result)
                        {
                            ConsumersList datas = new ConsumersList();
                            if (appId.tenantMasterLists != null)
                            {
                                var results = appId.tenantMasterLists.Where(x => x.TenantId == tenantId).ToList();
                                if (results.Count > 0 && results != null)
                                {
                                    List<TenantMasterDatas> tenantMasterDatasList = new List<TenantMasterDatas>();
                                    foreach (var consumer in results)
                                    {
                                        TenantMasterDatas tenantMasterDatas = new TenantMasterDatas();
                                        tenantMasterDatas.TenantId = consumer.TenantId;
                                        tenantMasterDatas.TenantName = consumer.TenantName;
                                        tenantMasterDatasList.Add(tenantMasterDatas);
                                        datas.tenantMasterLists = tenantMasterDatasList;
                                    }
                                    datas.UserId = appId.UserId;
                                    datas.UserName = appId.UserName;
                                    datas.TotalTransactions = appId.TotalTransactions;
                                    datas.TotalAmount = appId.TotalAmount;
                                    datas.TotalStoreTransactions = appId.TotalStoreTransactions;
                                    datas.TotalAmountPump = appId.TotalAmountPump;
                                    datas.TotalAmountStore = appId.TotalAmountStore;
                                    datas.TotalAmountInCard = appId.TotalAmountInCard;
                                    datas.TotalACHAmount = appId.TotalACHAmount;
                                    datas.TotalAmountInRewards = appId.TotalAmountInRewards;
                                    datas.TotalRewardsEarned = appId.TotalRewardsEarned;
                                    datas.TotalRewardsBalance = appId.TotalRewardsBalance;
                                    datas.DateOfLastTransaction = appId.DateOfLastTransaction;
                                    datas.DeviceType = appId.DeviceType;
                                    datas.MemberSince = appId.MemberSince;
                                    data.Add(datas);
                                }
                            }
                        }
                    }
                    result = data;
                }
                var sortcolumn = "";
                if (query.SortBy != null && query.SortOrder != null && query.SortBy.Value != ConsumerSortBy.None)
                {
                    sortcolumn = query.SortBy.Value.ToString();
                    if (!string.IsNullOrEmpty(sortcolumn) && sortcolumn == "UserName")
                    {
                        result = result.OrderByDescending(x => x.UserName).ToList();
                    }
                }

                return new PaginatedList<ConsumersList>
                {
                    Data = result,
                    PageIndex = query.PageIndex ?? 0,
                    PageSize = query.PageSize ?? 0,
                    TotalCount = totalRecord,
                };
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
