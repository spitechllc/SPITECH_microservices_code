﻿using MediatR;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetDashboardConsumersList
{
    public class GetDashboardConsumersListQuery : IRequest<PaginatedList<ConsumersList>>
    {
        public int? PageIndex { get; set; }
        public int? PageSize { get; set; }
        public ConsumerSortBy? SortBy { get; set; }

        public SortOrderEnum? SortOrder { get; set; }
        public int[] StoreIds { get; set; }
        public int[] AppIds { get; set; }
    }
}
