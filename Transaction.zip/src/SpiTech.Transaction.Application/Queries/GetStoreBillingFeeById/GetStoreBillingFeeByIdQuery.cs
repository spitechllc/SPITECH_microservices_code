﻿using MediatR;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetStoreBillingFeeById
{
    public class GetStoreBillingFeeByIdQuery : IRequest<StoreBillingFeeModel>
    {
        public int StoreBillingFeeId { get; set; }
    }
}
