﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetStoreBillingFeeById
{
    public class GetStoreBillingFeeByIdHandler : IRequestHandler<GetStoreBillingFeeByIdQuery, StoreBillingFeeModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetStoreBillingFeeByIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public GetStoreBillingFeeByIdHandler(IUnitOfWork context,
                                    ILogger<GetStoreBillingFeeByIdHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }
        public async Task<StoreBillingFeeModel> Handle(GetStoreBillingFeeByIdQuery query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            StoreBillingFeeModel result = _mapper.Map<StoreBillingFeeModel>(await _context.StoreBillingFees.Get(query.StoreBillingFeeId));

            _logger.TraceExitMethod(nameof(Handle), result);

            return await Task.FromResult(result);
        }
    }
}
