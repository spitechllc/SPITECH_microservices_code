﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetStoreBillingFeeById
{
    public class GetStoreBillingFeeByIdValidator : AbstractValidator<GetStoreBillingFeeByIdQuery>
    {
        public GetStoreBillingFeeByIdValidator()
        {
            RuleFor(s => s.StoreBillingFeeId).GreaterThan(0);
        }
    }
}
