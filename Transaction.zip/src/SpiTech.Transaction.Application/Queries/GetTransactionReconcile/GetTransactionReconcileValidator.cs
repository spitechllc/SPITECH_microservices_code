﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetTransactionReconcile
{
    public class GetTransactionReconcileValidator : AbstractValidator<GetTransactionReconcileQuery>
    {
        public GetTransactionReconcileValidator()
        {
            RuleFor(x => x.StartDateUtc).NotNull().NotEmpty().WithMessage("StartDateUtc is required").GreaterThan(new System.DateTime(2021, 1, 1)).WithMessage("Invalid Date. Transaction does not exist");
            RuleFor(x => x.EndDateUtc).NotNull().NotEmpty().WithMessage("EndDateUtc is required").GreaterThan(new System.DateTime(2021, 1, 1)).WithMessage("Invalid Date. Transaction does not exist");
        }
    }
}
