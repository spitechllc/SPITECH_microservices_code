﻿using MediatR;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models;
using System;

namespace SpiTech.Transaction.Application.Queries.GetTransactionReconcile
{
    public class GetTransactionReconcileQuery : IRequest<TransactionReconcilePaginatedList>
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public int? StoreId { get; set; }
        public DateTime StartDateUtc { get; set; }
        public DateTime EndDateUtc { get; set; }
        public PaymentStatusEnum? CardPayment { get; set; }
        public PaymentStatusEnum? CashRewardPayment { get; set; }
        public PaymentStatusEnum? AchPayment { get; set; }
        public TransactionReconcileSortBy? SortBy { get; set; }
        public SortOrderEnum? SortOrder { get; set; }
    }
}
