﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetTransactionReconcile
{
    public class GetTransactionReconcileHandler :
        IRequestHandler<GetTransactionReconcileQuery, TransactionReconcilePaginatedList>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetTransactionReconcileHandler> logger;
        private readonly IMapper mapper;

        public GetTransactionReconcileHandler(IUnitOfWork context,
                                             ILogger<GetTransactionReconcileHandler> logger,
                                             IMapper mapper
                                             )
        {

            this.context = context;
            this.logger = logger;
            this.mapper = mapper;
        }

        public async Task<TransactionReconcilePaginatedList> Handle(GetTransactionReconcileQuery query, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), query);

            TransactionReconcileAggregateModel aggregateResult = null;

            List<TransactionReconcileModel> result = await context.SettlementRequests.GetTransactionReconcileReport(query.PageIndex, 
                                                                                                                    query.PageSize, 
                                                                                                                    query.StoreId, 
                                                                                                                    query.StartDateUtc, 
                                                                                                                    query.EndDateUtc, 
                                                                                                                    query.CardPayment, 
                                                                                                                    query.CashRewardPayment, 
                                                                                                                    query.AchPayment, 
                                                                                                                    query.SortBy, 
                                                                                                                    query.SortOrder);

            int totalrecord = 0;

            if (result != null && result.Count() > 0)
            {
                aggregateResult = await context.SettlementRequests.GetAggregatetTransactionReconcileReport(query.StoreId, 
                                                                                                            query.StartDateUtc, 
                                                                                                            query.EndDateUtc,
                                                                                                            query.CardPayment,
                                                                                                            query.CashRewardPayment,
                                                                                                            query.AchPayment);

                totalrecord = result.Select(x => x.TotalRecord).FirstOrDefault();
            }

            TransactionReconcilePaginatedList response = new()
            {
                Data = result.ToList(),
                PageIndex = query.PageIndex,
                PageSize = query.PageSize,
                TotalCount = totalrecord,
                TotalTerminalTotalAmount = aggregateResult?.TotalTerminalTotalAmount ?? 0,
                TotalMppaTotalAmount = aggregateResult?.TotalMppaTotalAmount ?? 0,
                TotalCashRewardAmount = aggregateResult?.TotalCashRewardAmount ?? 0,
                TotalAchAmount = aggregateResult?.TotalAchAmount ?? 0,
                TotalCardAmount = aggregateResult?.TotalCardAmount ?? 0,
                TotalNMIAmount = aggregateResult?.TotalNMIAmount ?? 0,
                TotalAuroraAmount = aggregateResult?.TotalAuroraAmount ?? 0,
            };

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
