﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.Transaction.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetResellerNacha
{
    public class GetResellerNachaHandler : IRequestHandler<GetResellerNachaQuery, NachaFileBytesModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetResellerNachaHandler> logger;
        private readonly IStorageService storageService;

        public GetResellerNachaHandler(IUnitOfWork context,
                                    ILogger<GetResellerNachaHandler> logger,
                                    IStorageServiceFactory storageServiceFactory)
        {
            this.context = context;
            this.logger = logger;
            storageService = storageServiceFactory.Get(ContainerType.MonthlyResellerInvoiceNachaFile);
        }

        public async Task<NachaFileBytesModel> Handle(GetResellerNachaQuery query, CancellationToken cancellationToken)
        {
            NachaFileBytesModel response = null;
            logger.TraceEnterMethod(nameof(Handle), query);

            var resellerBillingPayment = await context.ResellerBillingPayments.GetResellerBillingPayment(query.ResellerBillingId);

            //if (resellerBillingPayment != null && !string.IsNullOrEmpty(resellerBillingPayment.NachaFilePath))
            //{
            //    response = new NachaFileBytesModel();
            //    response.File = resellerBillingPayment.NachaFileName;
            //    response.Bytes = await storageService.DownloadBytesAsync(resellerBillingPayment.NachaFilePath);
            //}

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
