﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Nacha;

namespace SpiTech.Transaction.Application.Queries.GetResellerNacha
{
    public class GetResellerNachaQuery : IRequest<NachaFileBytesModel>
    {
        public int ResellerBillingId { get; set; }
    }
}
