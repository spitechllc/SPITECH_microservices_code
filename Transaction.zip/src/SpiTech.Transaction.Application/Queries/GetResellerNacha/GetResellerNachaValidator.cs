﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetResellerNacha
{
    public class GetResellerNachaValidator : AbstractValidator<GetResellerNachaQuery>
    {
        public GetResellerNachaValidator()
        {
            RuleFor(x => x.ResellerBillingId).GreaterThan(0).WithMessage("ResellerBillingId is invalid");
        }
    }
}
