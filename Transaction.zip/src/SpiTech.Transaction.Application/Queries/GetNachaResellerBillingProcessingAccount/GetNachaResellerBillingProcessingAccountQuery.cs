﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Nacha;

namespace SpiTech.Transaction.Application.Queries.GetNachaResellerBillingProcessingAccount
{
    public class GetNachaResellerBillingProcessingAccountQuery : IRequest<NachaProcessingModel>
    {
        public int Month { get; set; }
        public int Year { get; set; }
        public bool IsPreview { get; set; }
    }
}
