﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.Service.Clients.Payments;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetNachaResellerBillingProcessingAccount
{
    public class GetNachaResellerBillingProcessingAccountHandler : IRequestHandler<GetNachaResellerBillingProcessingAccountQuery, NachaProcessingModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetNachaResellerBillingProcessingAccountHandler> logger;
        private readonly IMediator mediator;
        private readonly IPaymentServiceClient paymentClient;

        public GetNachaResellerBillingProcessingAccountHandler(IUnitOfWork context,
                                    ILogger<GetNachaResellerBillingProcessingAccountHandler> logger,
                                    IMediator mediator,
                                    IPaymentServiceClient paymentClient)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            this.paymentClient = paymentClient;
        }

        public async Task<NachaProcessingModel> Handle(GetNachaResellerBillingProcessingAccountQuery query, CancellationToken cancellationToken)
        {
            NachaProcessingModel response = null;
            logger.TraceEnterMethod(nameof(Handle), query);

            var resellerBillings = await context.ResellerBillings.GetUnPaidBills(query.Month, query.Year);

            if (resellerBillings != null && resellerBillings.Any())
            {
                var resellerIds = resellerBillings.Select(t => t.ResellerId).Distinct().ToList();

                StoreConfigModelResponseList storeConfigs = await paymentClient.MasterStoreConfigAsync(cancellationToken);

                if (storeConfigs.Data == null || !storeConfigs.Data.Any())
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreConfigs", "Unable to get MasterStoreConfigs"));
                }

                if (query.IsPreview)
                {
                    foreach (var storeConfig in storeConfigs.Data)
                    {
                        if (string.IsNullOrWhiteSpace(storeConfig.AccountNo))
                        {
                            storeConfig.AccountNo = storeConfig.AccountNo.MaskAccountNumber();
                        }
                    }
                }

                IEnumerable<StoreConfigModel> masterAccounts = storeConfigs.Data.Where(t => t.IsMasterAccount);

                if (masterAccounts == null || !masterAccounts.Any())
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreConfigs", "Unable to get masterAccount in MasterStoreConfigs"));
                }

                if (masterAccounts.Count() > 1)
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("StoreConfigs", "Found multiple masterAccount in MasterStoreConfigs"));
                }

                StoreConfigModel masterAccount = storeConfigs.Data.FirstOrDefault(t => t.IsMasterAccount);

                var resellerConfigModelResponseList = await paymentClient.AllResellerConfigsAsync(new GetResellerConfigsQuery { ResellerIds = resellerIds }, cancellationToken);

                if (resellerConfigModelResponseList.Data == null || !resellerConfigModelResponseList.Data.Any())
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("ResellerConfig", "Unable to get ResellerConfig"));
                }

                if (query.IsPreview)
                {
                    foreach (var resellerConfig in resellerConfigModelResponseList.Data)
                    {
                        if (string.IsNullOrWhiteSpace(resellerConfig.AccountNo))
                        {
                            resellerConfig.AccountNo = resellerConfig.AccountNo.MaskAccountNumber();
                        }
                    }
                }

                var nachaConfig = (await context.NachaConfigs.GetAll()).FirstOrDefault();

                if (nachaConfig == null)
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("NachaConfig", "Unable to get NachaConfigs"));
                }

                if (query.IsPreview)
                {
                    nachaConfig.AccountNo = nachaConfig.AccountNo.MaskAccountNumber();
                }

                response = new NachaProcessingModel
                {
                    Config = new ApplicationCore.Domain.Nacha.NachaConfig
                    {
                        BankName = nachaConfig.Bank,
                        ImmediateOriginName = nachaConfig.AccountName,
                        AccountNo = nachaConfig.AccountNo,
                        RoutingNo = nachaConfig.RoutingNo,
                        BankRoutingNo = nachaConfig.ReceivingBankRoutingNo,
                        BatchCompanyName = masterAccount.AccountName,
                        ProcessType = NachaProcessType.RESELLERBILL,
                    }
                };

                foreach (var resellerBilling in resellerBillings)
                {
                    var resellerConfig = resellerConfigModelResponseList.Data
                                                .FirstOrDefault(t => t.ResellerId == resellerBilling.ResellerId);
                    if (resellerConfig == null)
                    {
                        throw new ValidationException(new FluentValidation.Results.ValidationFailure("resellerConfig", $"Unable to get resellerConfig for ResellerId ({resellerBilling.ResellerId})"));
                    }

                    //response.Accounts.Add(new NachaModel
                    //{
                    //    AccountEntityId = resellerBilling.ResellerBillingId,
                    //    TransactionCodeType = TransactionCodeType.Credit,
                    //    ProcessingAccount = new NachaAccount
                    //    {
                    //        AccountName = resellerConfig.AccountName,
                    //        AccountNo = resellerConfig.AccountNo,
                    //        RoutingNo = resellerConfig.RoutingNo,
                    //        AccountType = resellerConfig.IsChecking ? AccountType.Checking :
                    //                                                AccountType.Savings
                    //    },
                    //    Amount = resellerBilling.TotalFee,
                    //    IdentificationNumber = resellerBilling
                    //                                .ResellerBillingId.ToString(string.Concat(Enumerable.Repeat("0", 12))),
                    //    RequestId = resellerBilling.ResellerBillingId,
                    //});
                }
            }

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
