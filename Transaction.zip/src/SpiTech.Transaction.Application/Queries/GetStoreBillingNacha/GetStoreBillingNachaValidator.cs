﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetStoreBillingNacha
{
    public class GetStoreBillingNachaValidator : AbstractValidator<GetStoreBillingNachaQuery>
    {
        public GetStoreBillingNachaValidator()
        {
            RuleFor(x => x.StoreBillingId).GreaterThan(0).WithMessage("StoreBillingId is invalid");
        }
    }
}
