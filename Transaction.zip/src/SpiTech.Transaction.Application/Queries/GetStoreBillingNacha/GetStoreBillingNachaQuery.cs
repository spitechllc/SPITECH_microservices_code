﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Nacha;

namespace SpiTech.Transaction.Application.Queries.GetStoreBillingNacha
{
    public class GetStoreBillingNachaQuery : IRequest<NachaFileBytesModel>
    {
        public int StoreBillingId { get; set; }
    }
}
