﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.Transaction.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetStoreBillingNacha
{
    public class GetStoreBillingNachaHandler : IRequestHandler<GetStoreBillingNachaQuery, NachaFileBytesModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetStoreBillingNachaHandler> logger;
        private readonly IStorageService storageService;

        public GetStoreBillingNachaHandler(IUnitOfWork context,
                                    ILogger<GetStoreBillingNachaHandler> logger,
                                    IStorageServiceFactory storageServiceFactory)
        {
            this.context = context;
            this.logger = logger;
            storageService = storageServiceFactory.Get(ContainerType.MonthlyInvoiceNachaFile);
        }

        public async Task<NachaFileBytesModel> Handle(GetStoreBillingNachaQuery query, CancellationToken cancellationToken)
        {
            NachaFileBytesModel response = null;
            logger.TraceEnterMethod(nameof(Handle), query);

            Domain.Entities.StoreBillingPayment storeBillingPayment = await context.StoreBillingPayments.GetStoreBillingPayment(query.StoreBillingId);

            //if (storeBillingPayment != null && !string.IsNullOrEmpty(storeBillingPayment.NachaFilePath))
            //{
            //    response = new NachaFileBytesModel();
            //    response.File = storeBillingPayment.NachaFileName;
            //    response.Bytes = await storageService.DownloadBytesAsync(storeBillingPayment.NachaFilePath);
            //}

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
