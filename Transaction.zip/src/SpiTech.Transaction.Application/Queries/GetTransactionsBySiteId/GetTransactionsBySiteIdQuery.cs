﻿using MediatR;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.Transaction.Application.Queries.GetTransactionsBySiteId
{
    public class GetTransactionsBySiteIdQuery : IRequest<IEnumerable<TransactionModel>>
    {
        public string SiteId { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
    }
}
