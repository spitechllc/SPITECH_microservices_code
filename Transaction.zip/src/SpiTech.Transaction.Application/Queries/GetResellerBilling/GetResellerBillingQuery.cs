﻿using MediatR;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetResellerBilling
{
    public class GetResellerBillingQuery : IRequest<ResellerBillingPaginatedList>
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public bool? IsNeedReview { get; set; }
        public bool? IsPaid { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public ResellerBillingSortBy? SortBy { get; set; }
        public SortOrderEnum? SortOrder { get; set; }
    }
}
