﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetResellerBilling
{
    public class GetResellerBillingHandler : IRequestHandler<GetResellerBillingQuery, ResellerBillingPaginatedList>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetResellerBillingHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IStoreServiceClient storeServiceClient;

        public GetResellerBillingHandler(IUnitOfWork context,
                                             ILogger<GetResellerBillingHandler> logger,
                                             IMapper mapper,
                                             IStoreServiceClient storeServiceClient)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.storeServiceClient = storeServiceClient;
        }

        public async Task<ResellerBillingPaginatedList> Handle(GetResellerBillingQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            ResellerBillingAggregateModel aggregateResult = null;

            List<ResellerBillingModel> result = await _context.ResellerBillings.GetBills(request.PageIndex, request.PageSize, request.Month, request.Year, request.IsNeedReview, request.IsPaid, request.SortBy, request.SortOrder);

            int totalrecord = 0;
            if (result != null && result.Count() > 0)
            {
                var resellers = await this.storeServiceClient.ResellersAsync(result.Select(t => t.ResellerId));

                foreach (var resellerBillingModel in result)
                {
                    var reseller = resellers?.FirstOrDefault(t => t.ResellerId == resellerBillingModel.ResellerId);
                    if (reseller != null)
                        resellerBillingModel.ResellerName = reseller?.FirstName + " " + reseller?.LastName;
                }

                aggregateResult = await _context.ResellerBillings.GeAggregatetBills(request.Month, request.Year, request.IsNeedReview, request.IsPaid);

                totalrecord = result.Select(x => x.TotalRecord).FirstOrDefault();
            }

            ResellerBillingPaginatedList response = new()
            {
                Data = result.ToList(),
                PageIndex = request.PageIndex,
                PageSize = request.PageSize,
                TotalCount = totalrecord,

                DefineACHTransactionFee = aggregateResult?.DefineACHTransactionFee ?? 0,
                DefineCardTransactionFee = aggregateResult?.DefineCardTransactionFee ?? 0,
                DefineCashRewardTransactionFee = aggregateResult?.DefineCashRewardTransactionFee ?? 0,
                DefineACHProcessingFee = aggregateResult?.DefineACHProcessingFee ?? 0,
                DefineMonthlySaasFee = aggregateResult?.DefineMonthlySaasFee ?? 0,
                TotalTransactionAmount = aggregateResult?.TotalTransactionAmount ?? 0,
                TotalACHTransactionAmount = aggregateResult?.TotalACHTransactionAmount ?? 0,
                TotalCardTransactionAmount = aggregateResult?.TotalCardTransactionAmount ?? 0,
                TotalCashRewardTransactionAmount = aggregateResult?.TotalCashRewardTransactionAmount ?? 0,
                TotalACHTransactionFee = aggregateResult?.TotalACHTransactionFee ?? 0,
                TotalCardTransactionFee = aggregateResult?.TotalCardTransactionFee ?? 0,
                TotalCashRewardTransactionFee = aggregateResult?.TotalCashRewardTransactionFee ?? 0,
                TotalACHProcessingFee = aggregateResult?.TotalACHProcessingFee ?? 0,
                TotalFee = aggregateResult?.TotalFee ?? 0,
            };

            _logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
