﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetResellerBilling
{
    public class GetResellerBillingValidator : AbstractValidator<GetResellerBillingQuery>
    {
        public GetResellerBillingValidator()
        {
            RuleFor(x => x).Must(x => x.Month >= 1 && x.Month <= 12).WithMessage("Month is invalid");
            RuleFor(x => x.Year).GreaterThan(2000).WithMessage("Year is invalid");
        }
    }
}
