﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.Services;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetAllSaleAgentMonthlyInvoicePdf
{
    public class GetAllSaleAgentMonthlyInvoicePdfHandler : IRequestHandler<GetAllSaleAgentMonthlyInvoicePdfQuery, InvoiceFileBytesModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetAllSaleAgentMonthlyInvoicePdfHandler> logger;
        private readonly IStoreServiceClient _storeapiclient;
        private readonly IFinanceServiceClient _financeapiclient;
        private readonly IPaymentServiceClient _paymentapiclient;
        private readonly IHtmlPdfConverterService converterService;

        public GetAllSaleAgentMonthlyInvoicePdfHandler(IUnitOfWork context,
                                                ILogger<GetAllSaleAgentMonthlyInvoicePdfHandler> logger,
                                                IStoreServiceClient storeapiclient,
                                                IFinanceServiceClient financeapiclient,
                                                IPaymentServiceClient paymentapiclient,
                                                IHtmlPdfConverterService converterService
                                    )
        {
            this.context = context;
            this.logger = logger;
            _storeapiclient = storeapiclient;
            _financeapiclient = financeapiclient;
            _paymentapiclient = paymentapiclient;
            this.converterService = converterService;
        }

        public async Task<InvoiceFileBytesModel> Handle(GetAllSaleAgentMonthlyInvoicePdfQuery request, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), request);

            var result = await context.SaleAgentBillings.GetBills(0, 0, request.StoreId, request.Month, request.Year, request.IsNeedReview, request.IsPaid, null, null);

            if (result == null || !result.Any())
            {
                return null;
            }

            var salesAgents = (await _storeapiclient.SaleAgentsAsync(result.Select(t=>t.SaleAgentId).Distinct(), cancellationToken));

            foreach(var saleAgentBilling in result)
            {
                var salesAgent= salesAgents.FirstOrDefault(t=> t.SaleAgentId == saleAgentBilling.SaleAgentId);

                if(salesAgent != null)
                {
                    saleAgentBilling.SaleAgentName = salesAgent?.FirstName + " " + salesAgent?.LastName;
                }
            }

            SaleAgentBillingListModel saleAgentBillingList = new SaleAgentBillingListModel { };
            saleAgentBillingList.SaleAgentBillings = result;

            var response = new InvoiceFileBytesModel();
            response.Bytes = await this.converterService.CreatePdfFromView("AllSaleAgentMonthlyInvoice", saleAgentBillingList);
            response.File = "AllSaleAgentMonthlyInvoice.pdf";

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
