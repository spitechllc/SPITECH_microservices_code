﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetDailyNachaProcessingReport
{
    public class GetDailyNachaProcessingReportHandler : IRequestHandler<GetDailyNachaProcessingReportQuery, PaginatedList<NachaDailyProcessingReportModel>>
    {
        private readonly ILogger<GetDailyNachaProcessingReportHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly IStoreServiceClient _storeServiceClient;

        public GetDailyNachaProcessingReportHandler(
                                    ILogger<GetDailyNachaProcessingReportHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper, IStoreServiceClient storeServiceClient)
        {
            _logger = logger;
            _context = context;
            _mapper = mapper;
            _storeServiceClient = storeServiceClient;
        }

        public async Task<PaginatedList<NachaDailyProcessingReportModel>> Handle(GetDailyNachaProcessingReportQuery request, CancellationToken cancellationToken)
        {
            List<NachaDailyProcessingReportModel> result =  await _context.SettlementPaymentDetails.DailyNachaProcessingReport(request);

            ICollection<StoreSearchResult> companyDetails = new List<StoreSearchResult>();
            int totalRecord = 0;
            if (result != null && result.Count() > 0)
            {
                totalRecord = result.Select(x => x.TotalRecord).FirstOrDefault();
                int[] storeIds = result.Select(t => t.StoreId).Distinct().ToArray();
                companyDetails = (await _storeServiceClient.GetCompaniesByStoreIdAsync(storeIds))?.Data??new List<StoreSearchResult>();

				foreach (var item in result)
				{
                    item.LegalName = companyDetails.Where(t => t.StoreId == item.StoreId).FirstOrDefault()?.Company;
				}
			}

            return new PaginatedList<NachaDailyProcessingReportModel>
            {
                Data = result,
                PageIndex = request.PageIndex ?? 0,
                PageSize = request.PageSize ?? 0,
                TotalCount = totalRecord,
            };
        }

    }
}
