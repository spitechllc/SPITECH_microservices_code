﻿using FluentValidation;

namespace SpiTech.Transaction.Application.Queries.GetMonthlyTransactionsBySiteId
{
    public class GetMonthlyTransactionsBySiteIdValidator : AbstractValidator<GetMonthlyTransactionsBySiteIdQuery>
    {
        public GetMonthlyTransactionsBySiteIdValidator()
        {
            RuleFor(x => x.Month).Must(t => t > 0 && t < 12).WithMessage("Month is invalid");
            RuleFor(x => x.Year).GreaterThan(2021).WithMessage("year is invalid");
        }
    }
}
