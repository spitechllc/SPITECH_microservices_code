﻿using MediatR;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Transaction.Domain.Enums;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Application.Queries.GetMonthlyTransactionsBySiteId
{
    public class GetMonthlyTransactionsBySiteIdQuery : IRequest<MonthlyTransactionPaginatedList>
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public int? StoreId { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public bool? IsSuccess { get; set; }
        public bool? IsCancelled { get; set; }
        public bool? IsFailed { get; set; }
        public MonthlyTransactionSortBy? SortBy { get; set; }
        public SortOrderEnum? SortOrder { get; set; }
    }
}
