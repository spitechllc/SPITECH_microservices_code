﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Application.UnitOfWorks;
using SpiTech.Transaction.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Queries.GetMonthlyTransactionsBySiteId
{
    public class GetMonthlyTransactionsBySiteIdHandler :
        IRequestHandler<GetMonthlyTransactionsBySiteIdQuery, MonthlyTransactionPaginatedList>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<GetMonthlyTransactionsBySiteIdHandler> logger;
        private readonly IMapper mapper;
        private readonly IFinanceServiceClient financeServiceClient;

        public GetMonthlyTransactionsBySiteIdHandler(IUnitOfWork context,
                                             ILogger<GetMonthlyTransactionsBySiteIdHandler> logger,
                                             IMapper mapper,
                                             IFinanceServiceClient financeServiceClient
                                             )
        {
            this.context = context;
            this.logger = logger;
            this.mapper = mapper;
            this.financeServiceClient = financeServiceClient;
        }

        public async Task<MonthlyTransactionPaginatedList> Handle(GetMonthlyTransactionsBySiteIdQuery query, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), query);

            decimal totalCashBackEarned = 0;
            int daysInMonth = DateTime.DaysInMonth(query.Year, query.Month);
            DateTime startDate = (new DateTime(query.Year, query.Month, 1)).ToUniversalTime();
            DateTime endDate = (new DateTime(query.Year, query.Month, daysInMonth, 23, 59, 59)).ToUniversalTime();

            MonthlyTransactionAggregateModel aggregateResult = null;

            List<MonthlyTransactionModel> result = await context.Transactions.GetMonthlyTransactions(query.PageIndex, query.PageSize, query.StoreId, startDate, endDate, query.IsSuccess, query.IsCancelled, query.IsFailed, query.SortBy, query.SortOrder);

            int totalrecord = 0;

            if (result != null && result.Count() > 0)
            {
                aggregateResult = await context.Transactions.GetMonthlyTransactionsAggregate(query.StoreId, startDate, endDate, query.IsSuccess, query.IsCancelled, query.IsFailed);

                totalrecord = result.Select(x => x.TotalRecord).FirstOrDefault();

                var transactions = await context.Transactions.GetTransactionByDateRange(startDate, endDate);

                var walletCredits = await financeServiceClient.GetWalletCreditByTransactionIdsAsync(new Service.Clients.Finance.GetWalletCreditByTransactionIdsQuery { TransactionIds = transactions.Select(t => t.TransactionId).ToList() });

                if (walletCredits != null && walletCredits.Data != null)
                {
                    totalCashBackEarned = (decimal)walletCredits.Data.Sum(t => t.Amount);

                    foreach (var store in result)
                    {
                        store.TotalCashBackEarned = (decimal)walletCredits.Data.Where(t => t.StoreId == store.StoreId).Sum(t => t.Amount);
                    }
                }
            }

            MonthlyTransactionPaginatedList response = new()
            {
                Data = result.ToList(),
                PageIndex = query.PageIndex,
                PageSize = query.PageSize,
                TotalCount = totalrecord,
                TotalAmount = aggregateResult?.TotalAmount ?? 0,
                TotalTransactions = aggregateResult?.TotalTransactions ?? 0,
                TotalSuccessAmount = aggregateResult?.TotalSuccessAmount ?? 0,
                TotalSuccessTransactions = aggregateResult?.TotalSuccessTransactions ?? 0,
                TotalCashBackRedeemed = aggregateResult?.TotalCashBackRedeemed ?? 0,
                TotalCancelledAmount = aggregateResult?.TotalCancelledAmount ?? 0,
                TotalCancelledTransactions = aggregateResult?.TotalCancelledTransactions ?? 0,
                TotalFailedAmount = aggregateResult?.TotalFailedAmount ?? 0,
                TotalFailedTransactions = aggregateResult?.TotalFailedTransactions ?? 0,
                TotalCashBackEarned = totalCashBackEarned,
            };

            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
