﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.Transaction.Application.Queries.GetStoreByTransactionIds
{
    public class GetStoreByTransactionIdsQuery : IRequest<IEnumerable<TransactionModel>>
    {
        public long[] TransactionIds { get; set; }
    }
}
