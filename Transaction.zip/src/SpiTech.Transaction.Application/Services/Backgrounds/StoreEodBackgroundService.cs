﻿using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.Commands.ProcessStoreEodSettlementList;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Services.Backgrounds
{
    public class StoreEodBackgroundService : BackgroundService
    {
        private readonly ILogger<StoreEodBackgroundService> _logger;
        private readonly IServiceScope serviceScope;

        public StoreEodBackgroundService(ILogger<StoreEodBackgroundService> logger,
                                    IServiceScopeFactory scopeFactory
                                    )
        {
            _logger = logger;
            serviceScope = scopeFactory.CreateScope();
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.Info($"StoreEodBackgroundService Starting");

            try
            {
                while (!stoppingToken.IsCancellationRequested)
                {
                    var mediator = serviceScope.ServiceProvider.GetService<IMediator>();
                    await mediator.Send(new ProcessStoreEodSettlementListQuery());
                    await Task.Delay(TimeSpan.FromMinutes(10), stoppingToken);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"Error at: {DateTimeOffset.Now}");
            }
            _logger.Info($"StoreEodBackgroundService Stop");
        }
    }
}
