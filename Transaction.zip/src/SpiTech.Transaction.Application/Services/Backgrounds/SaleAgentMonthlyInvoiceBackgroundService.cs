﻿using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.Commands.ProcessSaleAgentMonthlyInvoice;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Services.Backgrounds
{
    public class SaleAgentMonthlyInvoiceBackgroundService : BackgroundService
    {
        private readonly ILogger<SaleAgentMonthlyInvoiceBackgroundService> _logger;
        private readonly IServiceScope serviceScope;

        public SaleAgentMonthlyInvoiceBackgroundService(ILogger<SaleAgentMonthlyInvoiceBackgroundService> logger,
                                    IServiceScopeFactory scopeFactory
                                    )
        {
            _logger = logger;
            serviceScope = scopeFactory.CreateScope();
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.Info($"SaleAgentMonthlyInvoiceBackgroundService Starting");

            try
            {
                while (!stoppingToken.IsCancellationRequested)
                {
                    var mediator = serviceScope.ServiceProvider.GetService<IMediator>();
                    await mediator.Send(new ProcessSaleAgentMonthlyInvoiceQuery());
                    await Task.Delay(TimeSpan.FromMinutes(10), stoppingToken);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"Error at: {DateTimeOffset.Now}");
            }
            _logger.Info($"SaleAgentMonthlyInvoiceBackgroundService Stop");
        }
    }
}
