﻿using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain;
using SpiTech.ApplicationCore.Domain.Configs;
using SpiTech.Transaction.Application.Commands.CreateLogInfo;
using SpiTech.Transaction.Application.Commands.ProcessAchNachaReturnFile;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Services.Backgrounds
{
    public class ProcessAchNachaReturnFileService : BackgroundService
    {
        private readonly ILogger<ProcessAchNachaReturnFileService> _logger;
        private readonly SftpConfigs sftpConfig;
        private readonly IServiceScope serviceScope;

        public ProcessAchNachaReturnFileService(ILogger<ProcessAchNachaReturnFileService> logger,
                                    SftpConfigs sftpConfig,
                                    IServiceScopeFactory scopeFactory)
        {
            _logger = logger;
            this.sftpConfig = sftpConfig;
            serviceScope = scopeFactory.CreateScope();
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.Info($"ACHParseFileService Starting");
            var status = sftpConfig.Get(DomainConstant.SftpConfig.FNBO).ExecReturnFile;

            CreateLogInfoCommand command = new CreateLogInfoCommand();
            command.Method = "ProcessAchNachaReturnFileService";
            command.Message = "File Status : +" + status + "";
            command.Exception = "No process file return here";
            var mediator = serviceScope.ServiceProvider.GetService<IMediator>();
            await mediator.Send(command);

            //if (!string.Equals(sftpConfig.Get(DomainConstant.SftpConfig.FNBO).ExecReturnFile, "ON", StringComparison.InvariantCultureIgnoreCase))
            //{
            //    CreateLogInfoCommand command = new CreateLogInfoCommand();
            //    command.Method = "ProcessAchNachaReturnFileService";
            //    command.Message = "File Status : +" + status + "";
            //    command.Exception = "No process file return here";
            //    var mediator = serviceScope.ServiceProvider.GetService<IMediator>();
            //    await mediator.Send(command);
            //    return;
            //}
            try
            {
                while (!stoppingToken.IsCancellationRequested)
                {
                    mediator = serviceScope.ServiceProvider.GetService<IMediator>();
                    await mediator.Send(new ProcessAchNachaReturnFileCommand());
                    await Task.Delay(TimeSpan.FromHours(1), stoppingToken);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"Error at: {DateTimeOffset.Now}");
            }
            _logger.Info($"ACHParseFileService Stop");
        }
    }
}
