﻿using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Transaction.Application.Commands.ProcessStoreMonthlyInvoice;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Application.Services.Backgrounds
{
    public class StoreMonthlyInvoiceBackgroundService : BackgroundService
    {
        private readonly ILogger<StoreMonthlyInvoiceBackgroundService> _logger;
        private readonly IServiceScope serviceScope;

        public StoreMonthlyInvoiceBackgroundService(ILogger<StoreMonthlyInvoiceBackgroundService> logger,
                                    IServiceScopeFactory scopeFactory
                                    )
        {
            _logger = logger;
            serviceScope = scopeFactory.CreateScope();
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.Info($"StoreMonthlyInvoiceBackgroundService Starting");

            try
            {
                while (!stoppingToken.IsCancellationRequested)
                {
                    var mediator = serviceScope.ServiceProvider.GetService<IMediator>();
                    await mediator.Send(new ProcessStoreMonthlyInvoiceQuery());
                    await Task.Delay(TimeSpan.FromMinutes(10), stoppingToken);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"Error at: {DateTimeOffset.Now}");
            }
            _logger.Info($"StoreMonthlyInvoiceBackgroundService Stop");
        }
    }
}
