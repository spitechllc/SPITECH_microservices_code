﻿using Microsoft.AspNetCore.Hosting;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Converters;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Processors;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WkHtmlToPdfDotNet;
using WkHtmlToPdfDotNet.Contracts;

namespace SpiTech.Transaction.Application.Services
{
    internal class HtmlPdfConverterService : IHtmlPdfConverterService
    {
        private readonly ILogger<HtmlPdfConverterService> logger;
        private readonly IWebHostEnvironment webHostEnvironment;
        private readonly IConverter converter;
        private readonly IViewToStringConverter viewToStringConverter;

        public HtmlPdfConverterService(ILogger<HtmlPdfConverterService> logger,
                                        IWebHostEnvironment webHostEnvironment,
                                        IConverter converter,
                                        IViewToStringConverter viewToStringConverter)
        {
            this.logger = logger;
            this.webHostEnvironment = webHostEnvironment;
            this.converter = converter;
            this.viewToStringConverter = viewToStringConverter;
        }

        public byte[] CreatePdf(string htmlFile, params object[] macroObjects)
        {
            var output = "";
            Func<string, string> htmlBodyTemplateMacroBinder = null;

            if (macroObjects != null && macroObjects.Any())
            {
                htmlBodyTemplateMacroBinder = t => TextTemplateMacroProcessor.Process(t, macroObjects);
            }

            output = HtmlTemplate(htmlFile, htmlBodyTemplateMacroBinder);

            string SpiTechImgPath = Path.Combine(webHostEnvironment.ContentRootPath, "Resources", "SpiTech_Logo.jpg");

            string htmlBody = EmailTemplateImageReplace(output, "data:image/jpg;base64," + Convert.ToBase64String(File.ReadAllBytes(SpiTechImgPath)));

            return CreatePdf(htmlBody);
        }

        public async Task<byte[]> CreatePdfFromView(string viewFile, object macroObject, PaperKind paperKind = PaperKind.A4)
        {
            //string eodFilePath = System.IO.Path.Combine("Resources", "InvoicePdfFormats", viewFile);
            var output = await viewToStringConverter.RenderViewToStringAsync(viewFile, macroObject);

            string SpiTechImgPath = Path.Combine(webHostEnvironment.ContentRootPath, "Resources", "SpiTech_Logo.jpg");

            string htmlBody = EmailTemplateImageReplace(output, "data:image/jpg;base64," + Convert.ToBase64String(File.ReadAllBytes(SpiTechImgPath)));

            return CreatePdf(htmlBody, paperKind);
        }

        public byte[] CreatePdfFromHtml(string html)
        {
            string SpiTechImgPath = Path.Combine(webHostEnvironment.ContentRootPath, "Resources", "SpiTech_Logo.jpg");

            string htmlBody = EmailTemplateImageReplace(html, "data:image/jpg;base64," + Convert.ToBase64String(File.ReadAllBytes(SpiTechImgPath)));

            return CreatePdf(htmlBody);
        }

        public byte[] CreatePdf(string htmlBody, PaperKind paperKind = PaperKind.A4)
        {
            var doc = new HtmlToPdfDocument()
            {
                GlobalSettings = {
                    ColorMode = ColorMode.Color,
                    Orientation = Orientation.Portrait,
                    PaperSize = paperKind,
                },
                Objects = {
                    new ObjectSettings() {
                        PagesCount = true,
                        HtmlContent = htmlBody,
                        WebSettings = { DefaultEncoding = "utf-8" },
                        HeaderSettings = { Spacing = 2.812 },
                        FooterSettings = { FontSize = 9, Right = "Page [page] of [toPage]", Line = true, Spacing = 2.812 }
                    }
                }
            };
            return converter.Convert(doc);
        }

        private string HtmlTemplate(string htmlTemplateFile, Func<string, string> htmlBodyTemplateMacroBinder)
        {
            string htmlBody = "";
            string filepath = htmlTemplateFile;

            if (!File.Exists(filepath))
            {
                throw new InvalidApplicationConfigurationException($"Filepath({filepath}) is not found in system for pdf creation",
                   $"Configure - {htmlTemplateFile}");
            }
            else
            {
                string template = File.ReadAllText(filepath);
                logger.Info($"template: {template}");

                if (htmlBodyTemplateMacroBinder == null)
                {
                    return template;
                }

                htmlBody = htmlBodyTemplateMacroBinder(template);
            }
            logger.Info($"htmlBody: {htmlBody}");
            return htmlBody;
        }
        private string EmailTemplateImageReplace(string emailTemplate, string imagePath)
        {
            emailTemplate = emailTemplate.Replace("[[SpiTechImgId]]", imagePath, StringComparison.InvariantCultureIgnoreCase);
            return emailTemplate;
        }
    }
}
