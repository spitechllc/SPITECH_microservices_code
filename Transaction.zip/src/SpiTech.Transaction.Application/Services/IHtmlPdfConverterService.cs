﻿using System.Threading.Tasks;
using WkHtmlToPdfDotNet;

namespace SpiTech.Transaction.Application.Services
{
    public interface IHtmlPdfConverterService
    {
        Task<byte[]> CreatePdfFromView(string viewFile, object macroObject, PaperKind paperKind = PaperKind.A4);
        byte[] CreatePdfFromHtml(string html);
        byte[] CreatePdf(string htmlFile, params object[] macroObjects);
        byte[] CreatePdf(string htmlBody, PaperKind paperKind = PaperKind.A4);
    }
}
