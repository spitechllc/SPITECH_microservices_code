﻿namespace SpiTech.Transaction.Domain
{
    public static class Constants
    {
        
    }
}
