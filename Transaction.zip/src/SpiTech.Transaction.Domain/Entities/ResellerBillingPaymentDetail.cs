﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("ResellerBillingPaymentDetail")]
    public class ResellerBillingPaymentDetail : BaseEntity
    {
        [Key]
        public int ResellerBillingPaymentDetailId { get; set; }
        public int ResellerBillingPaymentId { get; set; }
        public int ResellerBillingId { get; set; }
        public decimal Amount { get; set; }
        public int ResellerId { get; set; }
        public string AccountName { get; set; }
        public string AccountNo { get; set; }
        public string RoutingNo { get; set; }
        public string IdentificationNumber { get; set; }
        public bool IsChecking { get; set; }
        public bool MarkUnPaid { get; set; }
        public string Reason { get; set; }
    }
}