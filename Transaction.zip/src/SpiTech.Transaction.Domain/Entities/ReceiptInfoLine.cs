﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("ReceiptInfoLine")]
    public class ReceiptInfoLine : BaseEntity
    {
        [Key]
        public long ReceiptInfoLineId { get; set; }
        public long TransactionId { get; set; }
        public string ReceiptLine { get; set; }
    }
}
