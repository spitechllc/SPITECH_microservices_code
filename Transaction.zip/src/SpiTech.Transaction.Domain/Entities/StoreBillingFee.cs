﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("StoreBillingFee")]
    public class StoreBillingFee : BaseEntity
    {
        [Key]
        public int StoreBillingFeeId { get; set; }
        public int StoreId { get; set; }
        public string SiteId { get; set; }
        public int PaymentMethodId { get; set; }
        public int MinTransactionRange { get; set; }
        public int MaxTransactionRange { get; set; }
        public decimal TransactionFee { get; set; }
        public decimal TransactionPercentageFee { get; set; }
        public decimal MonthlySaasFee { get; set; }
        public bool IsDefault { get; set; }
    }
}