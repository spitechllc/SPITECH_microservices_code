﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("Site")]
    public class Site : BaseEntity
    {
        [ExplicitKey]
        public string SiteId { get; set; }
        public string SiteName { get; set; }
        public int? StoreId { get; set; }
        public string StoreName { get; set; } = null;
        public string SiteMPPAIdentifier { get; set; }
        public string MerchantId { get; set; }
        public string LocationId { get; set; }
        public bool? SiteMobileActive { get; set; }
        public string SiteAddress { get; set; }
        public string SettlementEmployee { get; set; }
        public bool? PartialAuthAllowed { get; set; }
        public int? PumpTimeout { get; set; }
        public DateTime? CurrentHeartBeatTime { get; set; }
    }
}
