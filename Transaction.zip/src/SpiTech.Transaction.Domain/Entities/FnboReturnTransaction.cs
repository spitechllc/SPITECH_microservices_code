﻿using SpiTech.ApplicationCore.Domain.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Domain.Entities
{
	[Table("FnboReturnTransaction")]

	public class FnboReturnTransaction : BaseEntity
	{
		[Key]
		public long Id { get; set; }
		public string TranGuid { get; set; }
		public string TransactionCode { get; set; }
		public string TypeOfRecord { get; set; }
		public int RecordTypeCode { get; set; }
		public string ACHReturnCode { get; set; }
		public string ReturnCodeStatus { get; set; }
		public int ReceivingDFIId { get; set; }
		public string DFIAccountNumber { get; set; }
		public decimal? Amount { get; set; }
		public string IdentificationNumber { get; set; }
		public string ReceivingCompanyName { get; set; }
		public string NachaAchFile { get; set; }
		public string HeaderRouteNumber { get; set; }
        public DateTime CreateDate { get; set; }
    }
}