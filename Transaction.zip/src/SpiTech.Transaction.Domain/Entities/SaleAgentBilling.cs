﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("SaleAgentBilling")]
    public class SaleAgentBilling : BaseEntity
    {
        [Key]
        public int SaleAgentBillingId { get; set; }
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public string SiteId { get; set; }
        public int SaleAgentId { get; set; }
        public string InvoiceNumber { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public int TransactionCount { get; set; }
        public decimal TransactionAmount { get; set; }
        public decimal DefineTransactionPercentageFee { get; set; }
        public decimal DefineMonthlySaasFee { get; set; }
        public decimal TransactionPercentageFee { get; set; }
        public decimal TotalFee { get; set; }
        public bool NeedReview { get; set; }
        public bool IsPaid { get; set; }
        public string InvoiceFileName { get; set; }
        public string InvoiceFilePath { get; set; }
        public string ProcessStatus { get; set; }
    }
}