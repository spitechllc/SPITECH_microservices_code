﻿using SpiTech.ApplicationCore.Domain.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("FnboReturnHeader")]
    public class FnboReturnHeader : BaseEntity
    {
        [Key]
        public long Id { get; set; }
        public string TranGuid { get; set; }
		public string TypeOfRecord { get; set; }
		public string FileName { get; set; }
		public string RecordTypeCode { get; set; }
		public string PriorityCode { get; set; }
		public string RoutingNumber { get; set; }
		public string SecCode { get; set; }
		public string FederalId { get; set; }
		public string FileCreationDate { get; set; }
        public string FileCreationTime { get; set; }
        public string BankName { get; set; }
        public string CompanyName { get; set; }
        public string DecryptFileName { get; set; }
        public string ReturnFilePath { get; set; }
        public string DecryptFilePath { get; set; }
    }
}
