﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("[SettlementDetail]")]
    public class SettlementDetail : BaseEntity
    {
        [ExplicitKey]
        public int SettlementDetailId { get; set; }
        public int SettlementRequestId { get; set; }
        public string TypeName { get; set; }
        public string GroupName { get; set; }
        public decimal TerminalTotalAmount { get; set; }
        public decimal MppaTotalAmount { get; set; }
        public int TerminalCounts { get; set; }
        public int MppaCounts { get; set; }
        public bool IsTotalAmountMatched { get; set; }
        public bool IsCountsMatched { get; set; }
    }
}
