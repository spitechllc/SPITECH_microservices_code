﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;
using System.Collections.Generic;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("BaiFile")]
    public class BaiFile : BaseEntity
    {
        [Key]
        public int BaiFileId { get; set; }
        public string BaiFileName { get; set; }
        public string SenderIdentification { get; set; }
        public string ReceiverIdentification { get; set; }
        public DateTime FileCreation { get; set; }
        public decimal TotalAmount { get; set; }
        public string UploadFileName { get; set; }
        public string UploadFilePath { get; set; }
        public bool IsArchived { get; set; }

        [Computed]
        public List<BaiFileDetail> BaiFileDetails { get; set; } = new List<BaiFileDetail>();
    }
}