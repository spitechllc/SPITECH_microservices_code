﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;
using System.Collections.Generic;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("SaleAgentBillingPayment")]
    public class SaleAgentBillingPayment : BaseEntity
    {
        [Key]
        public int SaleAgentBillingPaymentId { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public int BillGenerateBy { get; set; }
        public DateTime BillGenerateDate { get; set; }
        public decimal TotalAmount { get; set; }
        public string AccountName { get; set; }
        public string Bank { get; set; }
        public string AccountNo { get; set; }
        public string RoutingNo { get; set; }
        public bool IsChecking { get; set; }
        public string NachaFilePath { get; set; }
        public string NachaFileName { get; set; }
        public bool IsNachaUploaded { get; set; }
        public string NachaUploadError { get; set; }
        public string OffsetNachaFilePath { get; set; }
        public string OffsetNachaFileName { get; set; }
        public bool IsOffsetNachaUploaded { get; set; }
        public string OffsetNachaUploadError { get; set; }
        public string SftpConfig { get; set; }

        [Computed]
        public List<SaleAgentBillingPaymentDetail> SaleAgentBillingPaymentDetails { get; set; } = new List<SaleAgentBillingPaymentDetail>();
    }
}