﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("StoreBillingDetail")]
    public class StoreBillingDetail : BaseEntity
    {
        [Key]
        public int StoreBillingDetailId { get; set; }
        public int StoreBillingId { get; set; }
        public int PaymentMethodId { get; set; }
        public int MinTransactionRange { get; set; }
        public int MaxTransactionRange { get; set; }
        public decimal DefineTransactionFee { get; set; }
        public decimal DefineTransactionPercentageFee { get; set; }
        public decimal DefineMonthlySaasFee { get; set; }
        public int TransactionCount { get; set; }
        public decimal TransactionAmount { get; set; }
        public decimal TransactionFee { get; set; }
        public decimal TransactionPercentageFee { get; set; }
    }
}