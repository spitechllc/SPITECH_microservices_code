﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;
using System.Collections.Generic;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("[SettlementRequest]")]
    public class SettlementRequest : BaseEntity
    {
        [ExplicitKey]
        public int SettlementRequestId { get; set; }
        public string UMTI { get; set; }
        public string SiteId { get; set; }
        public string MerchantId { get; set; }
        public string SiteMPPAIdentifier { get; set; }
        public DateTime TimeDateStamp { get; set; }
        public DateTime BusinessDate { get; set; }
        public string SettlementPeriodId { get; set; }
        public decimal TerminalTotalAmount { get; set; }
        public decimal MppaTotalAmount { get; set; }
        public int TerminalCounts { get; set; }
        public int MppaCounts { get; set; }
        public decimal CashRewardAmount { get; set; }
        public decimal AchAmount { get; set; }
        public decimal CardAmount { get; set; }
        public decimal EodCashRewardAmount { get; set; }
        public decimal EodAchAmount { get; set; }
        public decimal EodCardAmount { get; set; }
        public string SoftwareVersion { get; set; }
        public bool IsTotalAmountMatched { get; set; }
        public bool IsCountsMatched { get; set; }
        public string Error { get; set; }
        public bool IsResponseError { get; set; }
        public bool IsReconciled { get; set; }
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public int AchPaymentStatusId { get; set; }
        public int CardPaymentStatusId { get; set; }
        public int CashRewardPaymentStatusId { get; set; }
        public bool NeedReview { get; set; }
        public string SettlementFileName { get; set; }
        public string SettlementFilePath { get; set; }
        public string ProcessStatus { get; set; }

        [Computed]
        public List<SettlementDetail> SettlementDetails { get; set; } = new List<SettlementDetail>();
    }
}
