﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("SaleAgentBillingPaymentDetail")]
    public class SaleAgentBillingPaymentDetail : BaseEntity
    {
        [Key]
        public int SaleAgentBillingPaymentDetailId { get; set; }
        public int SaleAgentBillingPaymentId { get; set; }
        public int SaleAgentBillingId { get; set; }
        public int StoreId { get; set; }
        public int SaleAgentId { get; set; }
        public decimal Amount { get; set; }
        public string AccountName { get; set; }
        public string AccountNo { get; set; }
        public string RoutingNo { get; set; }
        public string IdentificationNumber { get; set; }
        public bool IsChecking { get; set; }
        public bool MarkUnPaid { get; set; }
        public string Reason { get; set; }
    }
}