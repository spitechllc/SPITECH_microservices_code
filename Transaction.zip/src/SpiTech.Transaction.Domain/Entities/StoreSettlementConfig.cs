﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("StoreSettlementConfig")]
    public class StoreSettlementConfig : BaseEntity
    {
        [Key]
        public int StoreSettlementConfigId { get; set; }
        public int? StoreId { get; set; }
        public bool EnableACH { get; set; }
        public bool EnableCard { get; set; }
        public bool EnableCashReward { get; set; }
        public bool IsDefault { get; set; }
        public bool OnlyUseDefault { get; set; }
    }
}