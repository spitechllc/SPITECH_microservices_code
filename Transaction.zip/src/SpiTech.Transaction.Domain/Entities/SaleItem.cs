﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("SaleItem")]
    public class SaleItem : BaseEntity
    {
        [Key]
        public long SaleItemId { get; set; }
        public long TransactionId { get; set; }
        public string ItemId { get; set; }
        public bool EvaluateOnly { get; set; }
        public string ReverseSale { get; set; }
        public bool ItemStatus { get; set; }
        public bool PriceChangeEligible { get; set; }
        public string POSCode { get; set; }
        public string POSCodeModifier { get; set; }
        public string POSCodeFormat { get; set; }
        public string ProductCode { get; set; }
        public decimal OriginalAmount { get; set; }
        public decimal OriginalAmountUnitPrice { get; set; }
        public decimal AdjustedAmount { get; set; }
        public decimal AdjustedAmountUnitPrice { get; set; }
        public string UnitMeasure { get; set; }
        public decimal Quantity { get; set; }
        public string AdditionalProductInfo { get; set; }
        public string Description { get; set; }
        public string PriceTier { get; set; }
        public string RebateLabel { get; set; }
        public string ServiceLevel { get; set; }
        public string SellingUnits { get; set; }
        public int OutdoorPosition { get; set; }
    }
}
