﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("SettlementPaymentDetail")]
    public class SettlementPaymentDetail : BaseEntity
    {
        [Key]
        public int SettlementPaymentDetailId { get; set; }
        public int SettlementPaymentId { get; set; }
        public int SettlementRequestId { get; set; }
        public long TransactionId { get; set; }
        public int StoreId { get; set; }
        public decimal Amount { get; set; }
        public int AmountTypeId { get; set; }
        public string AccountName { get; set; }
        public string AccountNo { get; set; }
        public string RoutingNo { get; set; }
        public string IdentificationNumber { get; set; }
        public bool IsChecking { get; set; }
        public bool MarkUnPaid { get; set; }
        public string Reason { get; set; }
    }
}