﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;
using System.Collections.Generic;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("SettlementPayment")]
    public class SettlementPayment : BaseEntity
    {
        [Key]
        public int SettlementPaymentId { get; set; }
        public int? SettlementRequestId { get; set; }
        public DateTime BusinessDate { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal TotalRewardAmount { get; set; }
        public decimal TotalCardAmount { get; set; }
        public decimal TotalAchAmount { get; set; }
        public string AccountName { get; set; }
        public string IdentificationNumber { get; set; }
        public string Bank { get; set; }
        public string AccountNo { get; set; }
        public string RoutingNo { get; set; }
        public bool IsChecking { get; set; }
        public string NachaFilePath { get; set; }
        public string NachaFileName { get; set; }
        public bool IsNachaUploaded { get; set; }
        public string NachaUploadError { get; set; }
        public string OffsetNachaFilePath { get; set; }
        public string OffsetNachaFileName { get; set; }
        public bool IsOffsetNachaUploaded { get; set; }
        public string OffsetNachaUploadError { get; set; }
        public string SftpConfig { get; set; }

        [Computed]
        public List<SettlementPaymentDetail> SettlementPaymentDetails { get; set; } = new List<SettlementPaymentDetail>();
    }
}