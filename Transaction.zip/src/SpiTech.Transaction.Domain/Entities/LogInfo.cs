﻿using SpiTech.ApplicationCore.Domain.Entities;
using Renci.SshNet.Messages;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("LogInfo")]
    public class LogInfo: BaseEntity
    {
        [Key]
        public int Id { get; set; }
        public string Message { get; set; }
        public string Method { get; set; }
        public string Exception { get; set; }
    }
}
