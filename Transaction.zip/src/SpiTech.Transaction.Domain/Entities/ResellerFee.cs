﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("ResellerFee")]
    public class ResellerFee : BaseEntity
    {
        [Key]
        public int ResellerFeeId { get; set; }
        public int? ResellerId { get; set; }
        public int MinStoreRange { get; set; }
        public int MaxStoreRange { get; set; }
        public decimal ACHTransactionFee { get; set; }
        public decimal CardTransactionFee { get; set; }
        public decimal CashRewardTransactionFee { get; set; }
        public decimal ACHProcessingFee { get; set; }
        public decimal MonthlySaasFee { get; set; }
        public string CoreProcessingName { get; set; }
        public bool IsDefault { get; set; }
    }
}