﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;
using System.Collections.Generic;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("StoreBilling")]
    public class StoreBilling : BaseEntity
    {
        [Key]
        public int StoreBillingId { get; set; }
        public string GroupBillingIdentifier { get; set; }
        public string BillingNumber { get; set; }
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public string SiteId { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public int TransactionCount { get; set; }
        public decimal TransactionAmount { get; set; }
        public decimal TransactionFee { get; set; }
        public decimal TransactionPercentageFee { get; set; }
        public decimal MonthlySaasFee { get; set; }
        public decimal TotalFee { get; set; }
        public int BillGenerateBy { get; set; }
        public DateTime BillGenerateDate { get; set; }
        public bool NeedReview { get; set; }
        public bool IsPaid { get; set; }
        public string InvoiceFileName { get; set; }
        public string InvoiceFilePath { get; set; }
        public string ProcessStatus { get; set; }

        [Computed]
        public List<StoreBillingDetail> StoreBillingDetails { get; set; } = new List<StoreBillingDetail>();
    }
}