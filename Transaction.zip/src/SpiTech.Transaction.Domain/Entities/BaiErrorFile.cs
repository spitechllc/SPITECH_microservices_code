﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("BaiErrorFile")]
    public class BaiErrorFile : BaseEntity
    {
        [Key]
        public int BaiErrorFileId { get; set; }
        public string BaiFileName { get; set; }
        public string ErrorMessage { get; set; }
        public string ErrorStackTrace { get; set; }
    }
}