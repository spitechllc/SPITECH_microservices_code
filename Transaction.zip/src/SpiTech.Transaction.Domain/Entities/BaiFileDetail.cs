﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;
using System.Collections.Generic;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("BaiFileDetail")]
    public class BaiFileDetail : BaseEntity
    {
        [Key]
        public int BaiFileDetailId { get; set; }
        public int BaiFileId { get; set; }
        public decimal Amount { get; set; }
        public string FileIdentificationNumber { get; set; }
        public string CustomerAccountNumber { get; set; }
        public string SenderIdentification { get; set; }
        public string BankReferenceNumber { get; set; }
        public string CustomerReferenceNumber { get; set; }
        public string TypeCode { get; set; }
        public string TypeDescription { get; set; }
    }
}