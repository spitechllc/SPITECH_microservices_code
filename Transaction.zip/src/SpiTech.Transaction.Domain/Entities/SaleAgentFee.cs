﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("SaleAgentFee")]
    public class SaleAgentFee : BaseEntity
    {
        [Key]
        public int SaleAgentFeeId { get; set; }
        public int? SaleAgentId { get; set; }
        public int? StoreId { get; set; }
        public decimal TransactionPercentageFee { get; set; }
        public decimal MonthlySaasFee { get; set; }
        public bool IsDefault { get; set; }
    }
}