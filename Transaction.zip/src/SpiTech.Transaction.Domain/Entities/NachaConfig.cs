﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("NachaConfig")]
    public class NachaConfig : BaseEntity
    {
        [ExplicitKey]
        public string NachaConfigId { get; set; }
        public string AccountName { get; set; }
        public string Bank { get; set; }
        public string AccountNo { get; set; }
        public string RoutingNo { get; set; }
        public string ReceivingBankRoutingNo { get; set; }
        public bool IsNachaAccount { get; set; }
        public bool IsProdEnabled { get; set; }
    }
}
