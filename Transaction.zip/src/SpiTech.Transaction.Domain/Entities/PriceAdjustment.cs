﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Transaction.Domain.Entities
{
    [Table("PriceAdjustment")]
    public class PriceAdjustment : BaseEntity
    {
        [Key]
        public long PriceAdjustmentId { get; set; }
        public long SaleItemId { get; set; }
        public bool RewardApplied { get; set; }
        public string AdjustmentId { get; set; }
        public string ProgramId { get; set; }
        public bool DoNotRelieveTaxFlag { get; set; }
        public string PromotionReason { get; set; }
        public decimal Amount { get; set; }
        public bool UnitPrice { get; set; }
        public decimal Quantity { get; set; }
        public string RebateLabel { get; set; }
    }
}
