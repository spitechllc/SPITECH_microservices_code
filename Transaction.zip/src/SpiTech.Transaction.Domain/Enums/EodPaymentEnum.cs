﻿using System.Text.Json.Serialization;

namespace SpiTech.Transaction.Domain.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum EodPaymentStatusEnum
    {
        None = 0,
        NotPaid = 1,
        PartialPaid = 2,
        FullyPaid = 3,
        CashRewardNotPaid = 4,
        CardNotPaid = 5,
        AchNotPaid = 6,
    }
}
