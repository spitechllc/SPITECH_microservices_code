﻿using System.Text.Json.Serialization;

namespace SpiTech.Transaction.Domain.Enums
{

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum TransactionReconcileSortBy
    {
        None = 0,
        StoreId = 1,
        StoreName = 2,
        SiteId = 3,
        BusinessDate = 4,
        TerminalTotalAmount = 5,
        MppaTotalAmount = 6,
        CashRewardAmount = 7,
        AchAmount = 8,
        CardAmount = 9,
        IsTotalAmountMatched = 10
    }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum MonthlyTransactionSortBy
    {
        None = 0,
        StoreId = 1,
        StoreName = 2,
        SiteId = 3,
        TotalAmount = 4,
        TotalSuccessTransactions = 5,
        TotalSuccessAmount = 6,
        TotalCancelledTransactions = 7,
        TotalCancelledAmount = 8,
        TotalFailedTransactions = 9,
        TotalFailedAmount = 10,
        TotalCashBackRedeemed = 11
    }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum EodReportSortBy
    {
        None = 0,
        StoreId = 1,
        StoreName = 2,
        SiteId = 3,
        BusinessDate = 4,
        TerminalTotalAmount = 5,
        MppaTotalAmount = 6,
        CashRewardAmount = 7,
        AchAmount = 8,
        CardAmount = 9,
        TerminalCounts = 10,
        MppaCounts = 11,
        IsTotalAmountMatched = 12,
        IsResponseError = 12,
    }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum EodSettlementSortBy
    {
        None = 0,
        StoreId = 1,
        StoreName = 2,
        SiteId = 3,
        BusinessDate = 4,
        TerminalTotalAmount = 5,
        MppaTotalAmount = 6,
        CashRewardAmount = 7,
        AchAmount = 8,
        CardAmount = 9,
        IsTotalAmountMatched = 10,
        IsPaid = 11,
        NeedReview = 12,
        TerminalCounts = 13,
        MppaCounts = 14
    }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum StoreBillingSortBy
    {
        None = 0,
        StoreId = 1,
        StoreName = 2,
        SiteId = 3,
        TransactionAmount = 4,
        TransactionCount = 5,
        TransactionFee = 6,
        TransactionPercentageFee = 7,
        MonthlySaasFee = 8,
        TotalFee = 9,
        IsPaid = 10,
        NeedReview = 11,
        BillGenerateDate = 12
    }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum SaleAgentBillingSortBy
    {
        None = 0,
        StoreId = 1,
        StoreName = 2,
        SiteId = 3,
        TransactionAmount = 4,
        DefineTransactionPercentageFee = 5,
        DefineMonthlySaasFee = 6,
        TransactionPercentageFee = 7,
        TotalFee = 8,
        IsPaid = 9,
        NeedReview = 10,
        SaleAgentId = 11
    }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum ResellerBillingSortBy
    {
        None = 0,
        ResellerId = 1,
        ResellerName = 2,
        TransactionAmount = 3,
        DefineTransactionPercentageFee = 4,
        DefineMonthlySaasFee = 5,
        TransactionPercentageFee = 6,
        TotalFee = 7,
        IsPaid = 8,
        NeedReview = 9,
    }
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum NachaProcessingSortBy
    {
        None = 0,
        MID = 1,
        LegalName = 2,
        StoreId = 3,
        DBA = 4,
        TotalAmount = 5,
        MaxMV = 6,
        AvgMV = 7,
        MaxTransactionAmount = 8,
        TotalAchTransactions = 9,
        AvgTransaction = 10,
        TotalSales = 11,
        TotalSalesAmount = 12,
    }
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum NachaReturnSortBy
    {
        None = 0,
        MID = 1,
        LegalName = 2,
        StoreId = 3,
        DBA = 4,
        TruncAccount = 5,
        ReturnDate = 6,
        Amount = 7,
        ReturnReasonCode = 8,
        ReturnReasonDescription = 9,
    }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum ACHTransactionSortBy
    {
        None = 0,
        TransactionDate = 1,
        Store = 2,
        ACHMID = 3,
        POSId = 4,
        TotalPOSTransaction = 5,
        Amount = 6,
        Bank = 7,
        TransactionStatus = 8,
        PaymentStatus = 9,
    }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum ACHReturnSortBy
    {
        None = 0,
        ReturnDate = 1,
        TransactionDate = 2,
        MID = 3,
        StoreName = 4,
        POSId = 5,
        TotalPOSTransaction = 6,
        Amount = 7,
        Bank = 8,
        ReturnReasonCode = 9,
        ReturnReasonDescription = 10,
        ReturnFee = 11,
    }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum TransactionDetailReportSortBy
    {
        None = 0,
        TransactionId = 1,
        TransactionDate = 2,
        Amount = 3,
        TransactionStatus = 4,
    }
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum StoreDetailDashboardSortBy
    {
        None = 0,
        StoreName = 1,
        TotalSuccessAmount = 2,
        TotalSuccessTransactions = 3,
        TotalCardAmount = 4,
        TotalCardTransaction = 5,
        TotalACHAmount = 6,
        TotalACHTransactions = 7,
        TotalWalletAmount = 8,
        TotalWalletTransactions = 9,
        TotalCashBackEarned = 10,
        TotalCashBackRedeemed = 11,
    }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum ConsumerSortBy
    {
        None = 0,
        UserName = 1,
        TotalTransactions = 2,
        TotalAmount = 3,
        TotalStoreTransactions = 4,
        TotalAmountPump = 5,
        TotalAmountInCard = 6,
        TotalACHAmount = 7,
        TotalAmountInRewards = 8,
        TotalRewardsEarned = 9,
        DateOfLastTransaction = 10,
        MemberSince = 11
    }
}
