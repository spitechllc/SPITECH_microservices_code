﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Domain.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum FnboReturnFile
    {
        FileHeader=1,
        BatchHeader = 5,
        Transaction =6,
        AddendaRecord = 7,
        BatchFooter = 8,
        FileFooter=9,
    }
}
