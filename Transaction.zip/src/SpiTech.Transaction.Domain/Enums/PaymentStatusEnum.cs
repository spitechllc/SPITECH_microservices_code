﻿using System.Text.Json.Serialization;

namespace SpiTech.Transaction.Domain.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum PaymentStatusEnum
    {
        NotPaid = 0,
        Paid = 1,
        MarkAsPaid = 2,
    }
}
