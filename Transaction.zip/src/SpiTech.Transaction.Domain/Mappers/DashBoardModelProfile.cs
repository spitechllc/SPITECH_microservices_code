﻿using AutoMapper;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SpiTech.Service.Clients.Finance;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.Identity;
namespace SpiTech.Transaction.Domain.Mappers
{
   public class DashBoardModelProfile : Profile
    {
        public DashBoardModelProfile()
        {
            CreateMap<DashboardCashRewardModel, RewardDetailsDashboardModel>().ReverseMap();
            CreateMap<DashboardStoreRewardDetails, StoreRewardDetails>().ReverseMap();
            CreateMap<DashboardMonthWiseRewardDetails, MonthWiseRewardDetails>().ReverseMap();
            CreateMap<DashboardAllStoreDetails, DashboardStoreModel>().ReverseMap();
            CreateMap<DashboardAllStoreDetails, StoresSearchModel>().ReverseMap();
            CreateMap<DashboardFinanceUserWalletDetailModel, UserWalletDetailModel>().ReverseMap();
            CreateMap<DashboardUserIdentityModel, Service.Clients.Identity.UserModel>().ReverseMap();
            CreateMap<TenantMasterData, Service.Clients.Stores.TenantMasterList>().ReverseMap();
        }
    }
}
