﻿using AutoMapper;
using SpiTech.Transaction.Domain.Entities;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Domain.Mappers
{
    public class StoreBillingFeeProfile : Profile
    {
        public StoreBillingFeeProfile()
        {
            CreateMap<StoreBillingFee, StoreBillingFeeModel>().ReverseMap();
        }
    }
}
