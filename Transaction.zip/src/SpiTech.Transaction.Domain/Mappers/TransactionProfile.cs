﻿using AutoMapper;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Domain.Mappers
{
    public class TransactionProfile : Profile
    {
        public TransactionProfile()
        {
            CreateMap<Entities.Transaction, TransactionModel>().ReverseMap();
            CreateMap<Entities.Transaction, EventBus.DomainEvents.Models.Mppa.Transaction>().ReverseMap();
        }
    }
}
