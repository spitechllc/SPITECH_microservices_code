﻿using AutoMapper;
using SpiTech.Transaction.Domain.Entities;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Domain.Mappers
{
    public class PriceAdjustmentProfile : Profile
    {
        public PriceAdjustmentProfile()
        {
            CreateMap<PriceAdjustment, PriceAdjustmentModel>().ReverseMap();
            CreateMap<PriceAdjustment, EventBus.DomainEvents.Models.Mppa.PriceAdjustment>().ReverseMap();
        }
    }
}
