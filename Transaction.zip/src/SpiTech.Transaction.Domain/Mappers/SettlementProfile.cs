﻿using AutoMapper;
using SpiTech.Transaction.Domain.Entities;

namespace SpiTech.Transaction.Domain.Mappers
{
    public class SettlementProfile : Profile
    {
        public SettlementProfile()
        {
            CreateMap<SettlementRequest, EventBus.DomainEvents.Models.Mppa.SettlementRequest>().ReverseMap();
            CreateMap<SettlementDetail, EventBus.DomainEvents.Models.Mppa.SettlementDetail>().ReverseMap();
        }
    }
}
