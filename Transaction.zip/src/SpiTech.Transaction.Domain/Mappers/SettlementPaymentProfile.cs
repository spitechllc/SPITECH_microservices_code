﻿using AutoMapper;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Transaction.Domain.Entities;

namespace SpiTech.Transaction.Domain.Mappers
{
    public class SettlementPaymentProfile : Profile
    {
        public SettlementPaymentProfile()
        {
            CreateMap<SettlementPayment, SettlementPaymentModel>().ReverseMap();
            CreateMap<SettlementPaymentDetail, SettlementPaymentDetailModel>().ReverseMap();
        }
    }
}
