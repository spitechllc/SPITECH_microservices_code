﻿using AutoMapper;
using SpiTech.Transaction.Domain.Entities;
using SpiTech.Transaction.Domain.Models;

namespace SpiTech.Transaction.Domain.Mappers
{
    public class PaymentInfoProfile : Profile
    {
        public PaymentInfoProfile()
        {
            CreateMap<PaymentInfo, PaymentInfoModel>().ReverseMap();
            CreateMap<PaymentInfo, EventBus.DomainEvents.Models.Mppa.PaymentInfo>().ReverseMap();
        }
    }
}
