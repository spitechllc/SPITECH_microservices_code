﻿using AutoMapper;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using SpiTech.Transaction.Domain.Entities;

namespace SpiTech.Transaction.Domain.Mappers
{
    public class StoreBillingProfile : Profile
    {
        public StoreBillingProfile()
        {
            CreateMap<StoreBilling, StoreBillingModel>().ReverseMap();
        }
    }
}
