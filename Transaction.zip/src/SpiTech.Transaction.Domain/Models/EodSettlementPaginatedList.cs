﻿using SpiTech.ApplicationCore.Pagination;
using System;

namespace SpiTech.Transaction.Domain.Models
{
    public class EodSettlementPaginatedList : PaginatedList<EodSettlementReportModel>
    {
        public decimal TotalTerminalTotalAmount { get; set; }
        public decimal TotalMppaTotalAmount { get; set; }
        public decimal TotalCashRewardAmount { get; set; }
        public decimal TotalAchAmount { get; set; }
        public decimal TotalCardAmount { get; set; }
        public int TotalTerminalCounts { get; set; }
        public int TotalMppaCounts { get; set; }
    }

    public  class EodSettlementReportModel
    {
        public int SettlementRequestId { get; set; }
        public string SiteID { get; set; }
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        //public string StoreAddress { get; set; }
        //public string ProcessorId { get; set; }
        public DateTime BusinessDate { get; set; }
        public decimal TerminalTotalAmount { get; set; }
        public decimal MppaTotalAmount { get; set; }
        public decimal CashRewardAmount { get; set; }
        public decimal AchAmount { get; set; }
        public decimal CardAmount { get; set; }
        public int TerminalCounts { get; set; }
        public int MppaCounts { get; set; }
        public bool IsTotalAmountMatched { get; set; }
        public string Error { get; set; }
        public bool IsResponseError { get; set; }
        public int AchPaymentStatusId { get; set; }
        public int CardPaymentStatusId { get; set; }
        public int CashRewardPaymentStatusId { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        [Newtonsoft.Json.JsonIgnore]
        public int TotalRecord { get; set; }
    }

    public class EodSettlementReportAggregateModel
    {
        public decimal TotalTerminalTotalAmount { get; set; }
        public decimal TotalMppaTotalAmount { get; set; }
        public decimal TotalCashRewardAmount { get; set; }
        public decimal TotalAchAmount { get; set; }
        public decimal TotalCardAmount { get; set; }
        public int TotalTerminalCounts { get; set; }
        public int TotalMppaCounts { get; set; }
    }
}
