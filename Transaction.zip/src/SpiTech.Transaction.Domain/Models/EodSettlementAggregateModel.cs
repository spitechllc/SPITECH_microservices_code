﻿namespace SpiTech.Transaction.Domain.Models
{
    public class EodSettlementAggregateModel
    {
        public decimal TotalTerminalAmount { get; set; }
        public decimal TotalMppaAmount { get; set; }
        public int TotalTerminalCounts { get; set; }
        public int TotalMppaCounts { get; set; }
        public decimal TotalCashRewardAmount { get; set; }
        public decimal TotalAchAmount { get; set; }
        public decimal TotalCardAmount { get; set; }
    }
}
