﻿namespace SpiTech.Transaction.Domain.Models
{
    public class PriceAdjustmentModel
    {
        public long PriceAdjustmentId { get; set; }
        public long SaleItemId { get; set; }
        public bool RewardApplied { get; set; }
        public string AdjustmentId { get; set; }
        public string ProgramId { get; set; }
        public bool DoNotRelieveTaxFlag { get; set; }
        public string PromotionReason { get; set; }
        public decimal Amount { get; set; }
        public bool UnitPrice { get; set; }
        public decimal Quantity { get; set; }
        public string RebateLabel { get; set; }
    }
}
