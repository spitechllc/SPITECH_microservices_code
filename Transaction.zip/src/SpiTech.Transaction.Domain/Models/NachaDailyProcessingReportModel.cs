﻿namespace SpiTech.Transaction.Domain.Models
{
    public class NachaDailyProcessingReportModel
    {
        public int MID { get; set; }
        public string LegalName { get; set; }
        public int StoreId { get; set; }
        public string DBA { get; set; }
        public decimal TotalAmount { get; set; }
        public int MaxMV { get; set; }
        public decimal AvgMV { get; set; }
        public decimal MaxTransactionAmount { get; set; }
        public int TotalAchTransactions { get; set; }
        public decimal AvgTransaction { get; set; }
        public int TotalSales { get; set; }
        public decimal TotalSalesAmount => TotalAmount;

        [System.Text.Json.Serialization.JsonIgnore]
        [Newtonsoft.Json.JsonIgnore]
        public int TotalRecord { get; set; }
    }
}
