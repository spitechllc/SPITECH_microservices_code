﻿using System;

namespace SpiTech.Transaction.Domain.Models
{
    public class EodTransactionModel
    {
        public long TransactionId { get; set; }
        public string UMTI { get; set; }
        public string SiteId { get; set; }
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public int UserId { get; set; }
        public string SettlementPeriodId { get; set; }
        public int? PaymentMethodId { get; set; }
        public int? UserPaymentMethodId { get; set; }
        public decimal FinalAmount { get; set; }
        public decimal WalletAmount { get; set; }
        public decimal CardAmount { get; set; }
        public bool IsPaymentSuccess { get; set; }
        public int StatusId { get; set; }
        public int TransactionTypeId { get; set; }
        public DateTime TransactionDate { get; set; }
        public int? PaymentId { get; set; }
        public bool DisableEod { get; set; }
        public int? SettlementRequestId { get; set; }
        public int? AchPaymentStatusId { get; set; }
        public int? CardPaymentStatusId { get; set; }
        public int? CashRewardPaymentStatusId { get; set; }
        public bool MerchantPay { get; set; }
        public bool ConsumerPay { get; set; }
        public int? ConsumerPaid { get; set; }
        public int? MerchantPaid { get; set; }
    }
}
