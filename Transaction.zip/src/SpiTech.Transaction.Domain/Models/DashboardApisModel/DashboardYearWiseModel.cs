﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Domain.Models.DashboardApisModel
{
	public class DashboardYearWiseModel
	{

		public int years { get; set; }
		public decimal TotalyearAmount { get; set; }
        public decimal TotalyearAmountStoreCount { get; set; }
        public decimal TotalyearPumpAmount { get; set; }
        public decimal TotalyearPumpAmountStoreCount { get; set; }
        public decimal TotalyearStoreAmount { get; set; }
        public decimal TotalyearStoreAmountStoreCount { get; set; }
        public IEnumerable<DashboardMonthwiseModel> monthWiseDetails { get; set; }
	}

	public class DashboardMonthwiseModel
	{

		public string Months { get; set; }
        public int MonthId { get; set; }
        public decimal Amount { get; set; }
		public decimal PumpAmount { get; set; }
		public decimal StoreAmount { get; set; }

        public IEnumerable<DashboardStoreModel> monthWiseStoreTransactionModel { get; set; }
        public decimal MonthlyTotalStoreAmount { get; set; }
        public int MonthlyTotalStoreTransactions { get; set; }
        public decimal MonthlyTotalStoreCardAmount { get; set; }
        public int MonthlyTotalStoreCardTransactions { get; set; }
        public decimal MonthlyTotalStoreACHAmount { get; set; }
        public int MonthlyTotalStoreACHTransactions { get; set; }
        public decimal MonthlyTotalStoreWalletAmount { get; set; }
        public int MonthlyTotalStoreWalletTransactions { get; set; }
    }
}
