﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Domain.Models.DashboardApisModel
{
   public class DashboardConsumersModel
    {
        public decimal TotalConsumers { get; set; }
        public int TotalTransactions { get; set; }
        public int TotalAndroidUsers { get; set; }
        public int TotalIosUsers { get; set; }
        public int MonthlyTotalConsumers { get; set; }
        public decimal MonthlyTotalTransactions { get; set; }
        public decimal MonthlyTotalEarned { get; set; }
        public decimal MonthlyTotalRedeemed { get; set; }
        public int MonthlyTotalAndroidUsers { get; set; }
        public int MonthlyTotalIosUsers { get; set; }
        public int YearlyTotalConsumers { get; set; }
        public decimal YearlyTotalTransactions { get; set; }
        public int YearlyTotalAndroidUsers { get; set; }
        public int YearlyTotalIosUsers { get; set; }
        public int TotalConsumersWMOP { get; set; }
        public int TotalACHConsumers { get; set; }
        public int TotalCardConsumers { get; set; }
        public IEnumerable<DashboardUserModel> consumerModel { get; set; }
        public decimal TotalConsumerAmount { get; set; }
        public int TotalConsumerTransactions { get; set; }
        public decimal TotalConsumerAmountPump { get; set; }
        public decimal TotalConsumerAmountStore { get; set; }
        public int TotalConsumerStoreTransactions { get; set; }
        public decimal TotalConsumerCashRewardEarned { get; set; }
        public decimal TotalConsumerCashRewardRedeemed { get; set; }
        public decimal TotalConsumerBalanceAmount { get; set; }
    }
}