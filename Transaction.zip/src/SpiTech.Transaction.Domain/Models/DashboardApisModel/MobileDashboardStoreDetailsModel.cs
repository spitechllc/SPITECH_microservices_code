﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Domain.Models.DashboardApisModel
{
    public class MobileDashboardStoreDetailsModel
    {
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public MobileDashboardStoreTransactionModel storeTransactionModels { get; set; }
    }
    public class MobileDashboardStoreTransactionModel
    {
        public int StoreId { get; set; }
        public decimal TotalAmount { get; set; }
        public int TotalTransactions { get; set; }
        public int TotalConsumers { get; set; }
        public decimal TotalCurrentAmount { get; set; }
        public decimal TotalCurrentTransactions { get; set; }
        public int TotalCurrentConsumers { get; set; }
        public int MonthlyTransactionCount { get; set; }
        public decimal MonthlyTransactionAmount { get; set; }
        public int TotalMonthlyConsumers { get; set; }
        public int YearlyTransactionCount { get; set; }
        public decimal YearlyTransactionAmount { get; set; }
        public int TotalYearlyConsumers { get; set; }
        public decimal TotalCashBackEarned { get; set; }
        public decimal TotalCashBackRedeemed { get; set; }
        public decimal TotalCardAmount { get; set; }
        public int TotalCardTransactions { get; set; }
        public decimal TotalACHAmount { get; set; }
        public int TotalACHTransactions { get; set; }
        public decimal TotalWalletAmount { get; set; }
        public int TotalWalletTransactions { get; set; }
        public int TotalPumpConsumers { get; set; }
        public decimal TotalPumpAmount { get; set; }
        public int TotalStoreConsumers { get; set; }
        public decimal TotalStoreAmount { get; set; }
    }
}
