﻿using System;
using System.Collections.Generic;

namespace SpiTech.Transaction.Domain.Models.DashboardApisModel
{
    public class DashboardStoreModel
    {
        public string SiteId { get; set; }
        public int StoreId { get; set; }
        public DateTime Transactiondate { get; set; }
        public string StoreName { get; set; }
        public decimal TotalAmount { get; set; }
        public int TotalTransactions { get; set; }
        public decimal TotalSuccessAmount { get; set; }
        public decimal TotalSuccessTransactions { get; set; }
        public decimal TotalCancelledAmount { get; set; }
        public decimal TotalCancelledTransactions { get; set; }
        public decimal TotalFailedAmount { get; set; }
        public decimal TotalFailedTransactions { get; set; }
        public decimal TotalCardAmount { get; set; }
        public int TotalCardTransactions { get; set; }
        public decimal TotalACHAmount { get; set; }
        public int TotalACHTransactions { get; set; }
        public decimal TotalWalletAmount { get; set; }
        public int TotalWalletTransactions { get; set; }
        public decimal TotalCashBackEarned { get; set; }
        public decimal TotalCashBackRedeemed { get; set; }
        public IEnumerable<DashboardStoreModel> dayWiseStoreDetails { get; set; }
    }
}
