﻿namespace SpiTech.Transaction.Domain.Models.DashboardApisModel
{
    public class DashboardUserModel
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public decimal TotalAmount { get; set; }
        public int TotalTransactions { get; set; }
        public decimal TotalAmountPump { get; set; }
        public decimal TotalAmountStore { get; set; }
        public int TotalStoreTransactions { get; set; }
        public decimal TotalCashRewardEarned { get; set; }
        public decimal TotalCashRewardRedeemed { get; set; }
        public decimal TotalBalanceAmount { get; set; }
    }
}
