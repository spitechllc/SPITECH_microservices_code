﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Domain.Models.DashboardApisModel
{
    public class DashboardConsumersListModel
    {
        public IEnumerable<ConsumersList> consumersLists { get; set; }
    }

    public class ConsumersList
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public decimal? TotalTransactions { get; set; }
        public decimal? TotalAmount { get; set; }
        public decimal? TotalStoreTransactions { get; set; }
        public decimal? TotalAmountPump { get; set; }
        public decimal? TotalAmountStore { get; set; }
        public decimal? TotalAmountInCard { get; set; }
        public decimal? TotalACHAmount { get; set; }
        public decimal? TotalAmountInRewards { get; set; }
        public decimal? TotalRewardsEarned { get; set; }
        public decimal? TotalRewardsBalance { get; set; }
        public DateTime? DateOfLastTransaction { get; set; }
        public string DeviceType { get; set; }
        public DateTimeOffset? MemberSince { get; set; }
        public List<TenantMasterDatas> tenantMasterLists { get; set; }
    }
    public class TenantMasterDatas
    {
        public int TenantId { get; set; }
        public string TenantName { get; set; }
    }
}
