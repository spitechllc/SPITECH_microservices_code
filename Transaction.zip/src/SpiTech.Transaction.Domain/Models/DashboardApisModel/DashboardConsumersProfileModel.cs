﻿using SpiTech.Service.Clients.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Domain.Models.DashboardApisModel
{
    public class DashboardConsumersProfileModel
    {
        public int? ProfilesCurrentCreated { get; set; }
        public int? ProfilesLast7DaysCreated { get; set; }
        public int? ProfileWithTransactionCount { get; set; }
        public int? ProfileWithoutTransactionCount { get; set; }
        public int? usersProfilesWithoutMOPCount { get; set; }
        public int? repeatConsumerTranDataCount { get; set; }
        public IEnumerable<UserModel> consumerCurrentProfileData { get; set; }
        public IEnumerable<UserModel> consumerProfileLast7daysData { get; set; }
        public IEnumerable<DashboardProfileWithTransaction> profileWithTransaction { get; set; }
        public IEnumerable<DashboardProfileWithTransaction> profileWithoutTransaction { get; set; }
        public IEnumerable<User> usersProfileswithoutMOP { get; set; }
        public IEnumerable<UserModel> repeatConsumerTranData { get; set; }
    }
    public class DashboardProfileWithTransaction
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string StoreName { get; set; }
        public string FinalAmount { get; set; }
        public string DeviceType { get; set; }
        public DateTime? CreatedOn { get; set; }
    }
}
