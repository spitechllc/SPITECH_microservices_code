﻿using SpiTech.Service.Clients.Stores;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Domain.Models.DashboardApisModel
{
    public class DashboardTransactionModel
    {
        public decimal TotalAmount { get; set; }
        public int TotalTransactions { get; set; }
        public decimal TotalCurrentSuccessAmount { get; set; }
        public decimal TotalCurrentSuccessTransactions { get; set; }
        public int TotalCurrentConsumers { get; set; }
        public decimal TotalCurrentAvgTransactionAmount { get; set; }
        public decimal TotalSuccessAmount { get; set; }
        public decimal TotalSuccessTransactions { get; set; }
        public int TotalConsumers { get; set; }
        public decimal TotalAvgTransactionAmount { get; set; }
        public decimal TotalCashBackRedeemed { get; set; }
        public decimal TotalCancelledAmount { get; set; }
        public decimal TotalCancelledTransactions { get; set; }
        public decimal TotalFailedAmount { get; set; }
        public decimal TotalFailedTransactions { get; set; }
        public int MonthlyTransactionCount { get; set; }
        public decimal MonthlyTransactionAmount { get; set; }
        public decimal MonthlyAvgTransactionAmount { get; set; }
        public int TotalMonthlyConsumers { get; set; }
        public int YearlyTransactionCount { get; set; }
        public decimal YearlyTransactionAmount { get; set; }
        public decimal YearlyAvgTransactionAmount { get; set; }
        public int TotalYearlyConsumers { get; set; }
        public decimal PreviousMonthTransactionAmount { get; set; }
        public IEnumerable<DashboardStoreModel> storeTransactionModel { get; set; }
        public decimal TotalStoreAmount { get; set; }
        public int TotalStoreTransactions { get; set; }
        public decimal TotalStoreCardAmount { get; set; }
        public int TotalStoreCardTransactions { get; set; }
        public decimal TotalStoreACHAmount { get; set; }
        public int TotalStoreACHTransactions { get; set; }
        public decimal TotalStoreWalletAmount { get; set; }
        public int TotalStoreWalletTransactions { get; set; }
        public IEnumerable<DashboardYearWiseModel> yearWiseTransactionModel { get; set; }
        public decimal TotalYearWiseAmount { get; set; }
        public decimal TotalYearWiseAmountStoreCount { get; set; }
        public decimal TotalYearWisePumpAmount { get; set; }
        public decimal TotalYearWisePumpAmountStoreCount { get; set; }
        public decimal TotalYearWiseStoreAmount { get; set; }
        public decimal TotalYearWiseStoreAmountStoreCount { get; set; }
        public IEnumerable<DashboardMonthwiseModel> monthWiseTransactionModel { get; set; }
        public decimal TotalMonthWiseAmount { get; set; }
        public decimal TotalMonthWisePumpAmount { get; set; }
        public decimal TotalMonthWiseStoreAmount { get; set; }
        public IEnumerable<DashboardAllStoreDetails> allStoreTransactionModel { get; set; }
    }

    public class DashboardAllStoreDetails
    {
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public int TransactionCount { get; set; }
        public decimal Amount { get; set; }
        public List<TenantMasterData> tenantMasterLists { get; set; }
    }

    public class TenantMasterData
    {
        public int TenantId { get; set; }
        public string TenantName { get; set; }
    }
}
