﻿using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Transaction.Domain.Models.DashboardApisModel
{
    public class DashboardSaleItemsModel 
    {
        public string ItemId { get; set; }
        public string AdditionalProductInfo { get; set; }
        public decimal OriginalAmount { get; set; }
        public decimal TotalItemTransaction { get; set; }
    }
}
