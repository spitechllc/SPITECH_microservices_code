﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Domain.Models.DashboardApisModel
{
    public class DashboardFinanceUserWalletDetailModel
    {
        public int WalletId { get; set; }
        public int UserId { get; set; }
        public decimal TotalCreditAmount { get; set; }
        public decimal TotalRedeemAmount { get; set; }
        public decimal TotalAvailableAmount { get; set; }
        public decimal TotalTransferAmount { get; set; }
        public decimal TotalReceivedAmount { get; set; }
        public decimal TotalExpiredAmount { get; set; }
        public decimal TotalPromotionalAmount { get; set; }
    }
}
