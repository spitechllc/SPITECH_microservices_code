﻿using SpiTech.ApplicationCore.Domain.Nacha;
using System.Collections.Generic;

namespace SpiTech.Transaction.Domain.Models
{
    public class EodNachaProcessingModel: NachaProcessingModel
    {
    }
}
