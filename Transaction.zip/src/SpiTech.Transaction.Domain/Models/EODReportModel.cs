﻿using System.Collections.Generic;

namespace SpiTech.Transaction.Domain.Models
{
    public class EODReportModel
    {
        public IEnumerable<EODDetails> EODDetails { get; set; }
        public double TotalCashRewardAwarded { get; set; }
        public double TotalCashRewardRedeemed { get; set; }
        public int TotalSalesPOS { get; set; }
        public int TotalSalesMPPA { get; set; }
        public decimal TotalTransactionPOS { get; set; }
        public decimal TotalTransactionMPPA { get; set; }
        public int TotalACHSalesPOS { get; set; }
        public int TotalACHSalesMPPA { get; set; }
        public decimal TotalACHTransactionPOS { get; set; }
        public decimal TotalACHTransactionMPPA { get; set; }
        public int TotalCreditCardSalesPOS { get; set; }
        public int TotalCreditCardSalesMPPA { get; set; }
        public decimal TotalCreditCardTransactionPOS { get; set; }
        public decimal TotalCreditCardTransactionMPPA { get; set; }
        public IEnumerable<CreditCardDetails> CreditCardDetails { get; set; }
    }
    public class EODDetails
    {
        public int SettlementRequestId { get; set; }
        public string SiteID { get; set; }
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public string StoreAddress { get; set; }
        public string ProcessorId { get; set; }
        public string BusinessDate { get; set; }
        public string ClosingTime { get; set; }

    }
    public class CreditCardDetails
    {
        public string TypeName { get; set; }
        public int TotalPOSSales { get; set; }
        public decimal TotalPOSTransaction { get; set; }
        public int TotalMPPASales { get; set; }
        public decimal TotalMPPATransaction { get; set; }

    }
}
