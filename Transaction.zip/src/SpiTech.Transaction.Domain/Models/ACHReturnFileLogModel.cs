﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Domain.Models
{
    public class ACHReturnFileLogModel
    {
        public string GUID { get; set; }
        public int RecordTypeCode { get; set; }
        public string RecordType { get; set; }
        public string ACHReturnCode { get; set; }
        public string ReturnCodeStatus { get; set; }
        public string HeaderRouteNumber { get; set; }
        public string IdentificationNumber { get; set; }
        public string ACHLine { get; set; }
    }
}
