﻿using System;

namespace SpiTech.Transaction.Domain.Models
{
    public class ACHTransactionReportModel
    {
        public int TransactionId { get; set; }
        public DateTime TransactionDate { get; set; }
        public int StoreId { get; set; }
        public string Store { get; set; }
        public string StoreAddress { get; set; }
        public string StoreCity { get; set; }
        public string StoreState { get; set; }
        public decimal ACHMID { get; set; }
        public string POSStation { get; set; }
        public int TotalPOSTransaction { get; set; }
        public decimal Amount { get; set; }
        public decimal ACHAmount { get; set; }
        public string Bank { get; set; }
        public int UserPaymentMethodId { get; set; }
        public string TransactionStatus { get; set; }
        public string PaymentStatus { get; set; }
        public string POSTransNumber { get; set; }


        [System.Text.Json.Serialization.JsonIgnore]
        [Newtonsoft.Json.JsonIgnore]
        public int TotalRecord { get; set; }
    }
}
