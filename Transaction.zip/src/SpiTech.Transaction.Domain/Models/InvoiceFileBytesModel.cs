﻿namespace SpiTech.Transaction.Domain.Models
{
    public class InvoiceFileBytesModel
    {
        public byte[] Bytes { get; set; }
        public string File { get; set; }
    }
}
