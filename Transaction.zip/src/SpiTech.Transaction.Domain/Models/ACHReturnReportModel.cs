﻿using System;

namespace SpiTech.Transaction.Domain.Models
{
    public class ACHReturnReportModel
    {
        public string TranGuid { get; set; }
        public DateTime? ReturnDate { get; set; }
        public DateTime? TransactionDate { get; set; }
        public int MID { get; set; }
        public string StoreName { get; set; }
        public string POSId { get; set; }
        public int TotalPOSTransactions { get; set; }
        public decimal Amount { get; set; }
        public string Bank { get; set; }
        public string ReturnReasonCode { get; set; }
        public string ReturnReasonDescription { get; set; }
        public decimal ReturnFee { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        [Newtonsoft.Json.JsonIgnore]
        public int TotalRecord { get; set; }
    }
}
