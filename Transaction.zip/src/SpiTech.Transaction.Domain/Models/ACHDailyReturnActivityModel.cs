﻿using SpiTech.ApplicationCore.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Domain.Models
{
    public class ACHDailyReturnActivityModel 
    {
        public int MID { get; set; }
        public string LegalName { get; set; }
        public string DBA { get; set; }
        public DateTime? BatchDate { get; set; }
        public DateTime? ReturnDate { get; set; }
        public string Amount { get; set; }
        public string ReturnReasonCode { get; set; }
        public string ReturnReasonDescription { get; set; }
        public bool? IsRead { get; set; }
        public DateTime? CreatedOn { get; set; }
        [System.Text.Json.Serialization.JsonIgnore]
        [Newtonsoft.Json.JsonIgnore]
        public int TotalRecord { get; set; }
    }
}
