﻿using System;

namespace SpiTech.Transaction.Domain.Models
{
    public class NonBillResellerTransactionModel
    {
        public long TransactionId { get; set; }
        public string UMTI { get; set; }
        public string SiteId { get; set; }
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public int? PaymentMethodId { get; set; }
        public decimal FinalAmount { get; set; }
        public decimal WalletAmount { get; set; }
        public decimal CardAmount { get; set; }
        public int StatusId { get; set; }
        public string PaymentMethod { get; set; }
        public DateTime TransactionDate { get; set; }
        public int? SaleAgentBillingId { get; set; }
    }
}
