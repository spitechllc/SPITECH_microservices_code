﻿using SpiTech.ApplicationCore.Pagination;

namespace SpiTech.Transaction.Domain.Models
{
    public class MonthlyTransactionPaginatedList : PaginatedList<MonthlyTransactionModel>
    {
        public decimal TotalAmount { get; set; }
        public int TotalTransactions { get; set; }
        public decimal TotalSuccessAmount { get; set; }
        public decimal TotalSuccessTransactions { get; set; }
        public decimal TotalCashBackRedeemed { get; set; }
        public decimal TotalCashBackEarned { get; set; }
        public decimal TotalCancelledAmount { get; set; }
        public decimal TotalCancelledTransactions { get; set; }
        public decimal TotalFailedAmount { get; set; }
        public decimal TotalFailedTransactions { get; set; }
    }
}
