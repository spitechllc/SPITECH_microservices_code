﻿namespace SpiTech.Transaction.Domain.Models
{
    public class MonthlyTransactionModel
    {
        public string SiteID { get; set; }
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public decimal TotalAmount { get; set; }
        public int TotalTransactions { get; set; }
        public decimal TotalSuccessAmount { get; set; }
        public decimal TotalSuccessTransactions { get; set; }
        public decimal TotalCashBackRedeemed { get; set; }
        public decimal TotalCashBackEarned { get; set; }
        public decimal TotalCancelledAmount { get; set; }
        public decimal TotalCancelledTransactions { get; set; }
        public decimal TotalFailedAmount { get; set; }
        public decimal TotalFailedTransactions { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        [Newtonsoft.Json.JsonIgnore]
        public int TotalRecord { get; set; }
    }
}