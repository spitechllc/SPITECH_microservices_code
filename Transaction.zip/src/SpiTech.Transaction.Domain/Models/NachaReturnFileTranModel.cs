﻿using SpiTech.ApplicationCore.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Domain.Models
{
    public class NachaReturnFileTranModel 
    {
        public int ACHTranId { get; set; }
        public int? RecordTypeCode { get; set; }
        public int TransactionCode { get; set; }
        public string ACHReturnCode { get; set; }
        public string ReturnCodeStatus { get; set; }
        public int ReceivingDFI_ID { get; set; }
        public string DFIAccountNumber { get; set; }
        public string Amount { get; set; }
        public string IdentificationNumber { get; set; }
        public string ReceivingCompanyName { get; set; }
        public string NachaAchFile { get; set; }
        public string TypeOfRecord { get; set; }
        public string FileName { get; set; }
        public string HeaderRoutingNumber { get; set; }
        public string GUID { get; set; }
    }
}
