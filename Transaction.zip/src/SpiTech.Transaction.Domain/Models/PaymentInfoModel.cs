﻿namespace SpiTech.Transaction.Domain.Models
{
    public class PaymentInfoModel
    {
        public long PaymentInfoId { get; set; }
        public long TransactionId { get; set; }
        public string CardPANPrint { get; set; }
        public string CardISO { get; set; }
        public string CardCircuit { get; set; }
        public string PaymentMethod { get; set; }
        public string HostAuthNumber { get; set; }
        public string CardType { get; set; }
        public decimal PreAuthAmount { get; set; }
    }
}
