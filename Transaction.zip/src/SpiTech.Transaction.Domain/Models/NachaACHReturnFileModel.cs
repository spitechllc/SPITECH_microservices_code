﻿using SpiTech.ApplicationCore.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Domain.Models
{
    public class NachaACHReturnFileModel
    {
        public int? RecordTypeCode { get; set; }
        public int? ServiceClassCode { get; set; }
        public string RecordType { get; set; }
        public string ACHReturnCode { get; set; }
        public string ReturnCodeStatus { get; set; }
        public int? PriorityCode { get; set; }
        public string RoutingNumber { get; set; }
        public string OriginatingDFI_ID { get; set; }
        public string CompanyName { get; set; }
        public string CompanyIdentification { get; set; }
        public string CompanyEntryDesc { get; set; }
        public string CompanyDescDate { get; set; }
        public string SEC_Code { get; set; }
        public string AddendaTypeCode { get; set; }
        public string Addenda_PaymentRelatedInformation { get; set; }
        public int? Addenda_SequenceNumber { get; set; }
        public int? Addenda_EntryDetailSeqNo { get; set; }
        public string EffectiveEntryDate { get; set; }
        public string Reserved { get; set; }
        public int? OriginatorStatusCode { get; set; }
        public int? BatchNumber { get; set; }
        public string FileCreationDate { get; set; }
        public string FileCreationTime { get; set; }
        public string BankName { get; set; }
        public string TypeOfRecord { get; set; }
        public string FileName { get; set; }
        public string HeaderRouteNumber { get; set; }
        public string TotalDebitEntry { get; set; }
        public string TotalCreditEntry { get; set; }
        public string GUID  { get; set; }
    }
}
