﻿namespace SpiTech.Transaction.Domain.Models
{
    public class ReceiptInfoLineModel
    {
        public long ReceiptInfoLineId { get; set; }
        public long TransactionId { get; set; }
        public string ReceiptLine { get; set; }
    }
}
