﻿using System;
using System.Collections.Generic;

namespace SpiTech.Transaction.Domain.Models
{
    public class EodSettlementModel
    {
        public int SettlementRequestId { get; set; }
        public string UMTI { get; set; }
        public string SiteId { get; set; }
        public string MerchantId { get; set; }
        public string SiteMPPAIdentifier { get; set; }
        public DateTime TimeDateStamp { get; set; }
        public DateTime BusinessDate { get; set; }
        public string SettlementPeriodId { get; set; }
        public decimal TerminalTotalAmount { get; set; }
        public decimal MppaTotalAmount { get; set; }
        public int TerminalCounts { get; set; }
        public int MppaCounts { get; set; }
        public decimal CashRewardAmount { get; set; }
        public decimal AchAmount { get; set; }
        public decimal CardAmount { get; set; }
        public decimal EodCashRewardAmount { get; set; }
        public decimal EodAchAmount { get; set; }
        public decimal EodCardAmount { get; set; }
        public string SoftwareVersion { get; set; }
        public bool IsTotalAmountMatched { get; set; }
        public bool IsCountsMatched { get; set; }
        public string Error { get; set; }
        public bool IsResponseError { get; set; }
        public bool IsReconciled { get; set; }
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public int AchPaymentStatusId { get; set; }
        public int CardPaymentStatusId { get; set; }
        public int CashRewardPaymentStatusId { get; set; }
        public bool NeedReview { get; set; }
        public string SettlementFileName { get; set; }
        public string SettlementFilePath { get; set; }
        public string ProcessStatus { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        [Newtonsoft.Json.JsonIgnore]
        public int TotalRecord { get; set; }

        public List<TransactionDetailEOD> TransactionDetailsEod { get; set; }
    }

    public class TransactionDetailEOD
    {        
        public long TransactionId { get; set; }
        public long SettlementRequestId { get; set; }
        public string StoreName { get; set; }
        public DateTime TransactionDate { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string CheckBalance { get; set; }
        public string AccessToken { get; set; }
        public int MerchantId { get; set; }
        public decimal? FinalAmount { get; set; }
        public decimal? WalletAmount { get; set; }
        public decimal? CardAmount { get; set; }
        public decimal NewCardAmount { get; set; }
        public decimal NewAchAmount { get; set; }
        public string NewPaymentMethod { get; set;}
        public int PaymentMethodId { get; set; }
        public int UserPaymentMethodId { get; set; }
        public int AchPaymentStatusId { get; set; }
        public int CardPaymentStatusId { get; set; }
        public int CashRewardPaymentStatusId { get; set; }
        public bool MerchantPay { get; set; }
        public bool ConsumerPay { get; set; }
        public int? ConsumerPaid { get; set; }
        public int? MerchantPaid { get; set; }
        public decimal? ACHTotal { get; set; }
        public decimal? CardTotal { get; set; }
    }
}
