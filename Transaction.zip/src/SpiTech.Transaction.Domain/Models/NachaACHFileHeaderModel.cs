﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Domain.Models
{
    public class NachaACHFileHeaderModel
    {
        public int ACHReturnFileId { get; set; }
        public string TypeOfRecord { get; set; }
        public string FileName { get; set; }
        public int? RecordTypeCode { get; set; }
        public int? PriorityCode { get; set; }
        public string RoutingNumber { get; set; }
        public string SEC_Code { get; set; }
        public string FederalID { get; set; }
        public string FileCreationDate { get; set; }
        public string FileCreationTime { get; set; }
        public string BankName { get; set; }
        public string CompanyName { get; set; }
        public string GUID { get; set; }
    }

}
