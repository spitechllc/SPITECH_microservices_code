﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.Transaction.Application.Commands.GenerateStoreBilling;
using SpiTech.Transaction.Application.Commands.ProcessPaymentStoreBilling;
using SpiTech.Transaction.Application.Commands.UpdateStoreBillingNeedReview;
using SpiTech.Transaction.Application.Commands.UpdateStoreBillingUnPaid;
using SpiTech.Transaction.Application.Queries.GetAllStoreMonthlyInvoicePdf;
using SpiTech.Transaction.Application.Queries.GetStoreBilling;
using SpiTech.Transaction.Application.Queries.GetStoreBillingNacha;
using SpiTech.Transaction.Application.Queries.GetStoreBillingPreviewNacha;
using SpiTech.Transaction.Application.Queries.GetStoreMonthlyInvoicePdf;
using SpiTech.Transaction.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Transaction.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class StoreBillingController : ControllerBase
    {
        private readonly IMediator mediator;

        public StoreBillingController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        /// <summary>
        /// Returns store billing detail by filter
        /// </summary>
        /// <param name="query">Object of GetStoreBillingQuery</param>
        /// <returns>It will return in the form of StoreBillingPaginatedList</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreBilling_store-bills")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("store-bills")]
        public async Task<ActionResult<StoreBillingPaginatedList>> GetStoreBilling([FromQuery] GetStoreBillingQuery query)
        {
            return Ok(await mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to generate store monthly bill
        /// </summary>
        /// <param name="command">Object of GenerateStoreBillingCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreBilling_store-generate")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("store-generate")]
        public async Task<ActionResult<ResponseModel>> GenerateStoreBilling([FromBody] GenerateStoreBillingCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to process store monthly bill payment
        /// </summary>
        /// <param name="command">Object of ProcessPaymentStoreBillingCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreBilling_store-process-payment")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("store-process-payment")]
        public async Task<ActionResult<ResponseModel>> ProcessPayment([FromBody] ProcessPaymentStoreBillingCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to review store monthly billing
        /// </summary> 
        /// <param name="command">Object of UpdateStoreBillingNeedReviewCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreBilling_store-update-needreview")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("store-update-needreview")]
        public async Task<ActionResult<ResponseModel>> UpdateNeedReview([FromBody] UpdateStoreBillingNeedReviewCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to mark store monthly billing unpaid by id
        /// </summary>
        /// <param name="command">Object of UpdateStoreBillingUnPaidCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreBilling_store-update-unpaid")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("store-update-unpaid")]
        public async Task<ActionResult<ResponseModel>> UpdateUnPaid([FromBody] UpdateStoreBillingUnPaidCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        ///  Returns store billing nacha file to preview
        /// </summary>
        /// <param name="query">Object of GetStoreBillingPreviewNachaQuery</param>
        /// <returns>It will return in the form of NachaFileBytesModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreBilling_store-preview-nacha")]
        [ProducesResponseType(typeof(FileResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("store-preview-nacha")]
        public async Task<ActionResult> PreviewNacha([FromQuery] GetStoreBillingPreviewNachaQuery query)
        {
            NachaFileBytesModel response = await mediator.Send(query).ConfigureAwait(false);
            return response != null && response.Bytes != null ? File(response.Bytes, "text/plain", response.File) : NoContent();
        }

        /// <summary>
        ///  Returns store monthly billing nacha file to view
        /// </summary>
        /// <param name="query">Object of GetStoreBillingNachaQuery</param>
        /// <returns>It will return in the form of NachaFileBytesModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreBilling_store-view-nacha")]
        [ProducesResponseType(typeof(FileResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("store-view-nacha")]
        public async Task<ActionResult> ViewNachaFile([FromQuery] GetStoreBillingNachaQuery query)
        {
            NachaFileBytesModel response = await mediator.Send(query).ConfigureAwait(false);
            return response != null && response.Bytes != null ? File(response.Bytes, "text/plain", response.File) : NoContent();
        }

        /// <summary>
        ///  Returns  store monthly billing Invoice pdf to preview
        /// </summary>
        /// <param name="request">Object of GetStoreMonthlyInvoicePdfQuery</param>
        /// <returns>It will return in the form of NachaFileBytesModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreBilling_store-monthly-invoice-pdf")]
        [ProducesResponseType(typeof(FileResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("store-monthly-invoice-pdf")]
        public async Task<ActionResult> StoreMonthlyInvoicePdf([FromQuery] GetStoreMonthlyInvoicePdfQuery request)
        {
            InvoiceFileBytesModel response = await mediator.Send(request).ConfigureAwait(false);
            return response != null && response.Bytes != null ? File(response.Bytes, "application/pdf", response.File) : NoContent();
        }

        /// <summary>
        /// Returns all store monthly bill invoice pdf file by month and year
        /// </summary>
        /// <param name="request">Object of GetAllStoreMonthlyInvoicePdfQuery</param>
        /// <returns>It will return in the form of NachaFileBytesModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreBilling_store-all-monthly-invoice-pdf")]
        [ProducesResponseType(typeof(FileResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("store-all-monthly-invoice-pdf")]
        public async Task<ActionResult> AllStoreMonthlyInvoicePdf([FromQuery] GetAllStoreMonthlyInvoicePdfQuery request)
        {
            InvoiceFileBytesModel response = await mediator.Send(request).ConfigureAwait(false);
            return response != null && response.Bytes != null ? File(response.Bytes, "application/pdf", response.File) : NoContent();
        }
    }
}
