﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.Transaction.Application.Commands.GenerateResellerBilling;
using SpiTech.Transaction.Application.Commands.ProcessPaymentResellerBilling;
using SpiTech.Transaction.Application.Commands.UpdateResellerNeedReview;
using SpiTech.Transaction.Application.Commands.UpdateResellerUnPaid;
using SpiTech.Transaction.Application.Queries.GetAllResellerMonthlyInvoicePdf;
using SpiTech.Transaction.Application.Queries.GetResellerBilling;
using SpiTech.Transaction.Application.Queries.GetResellerMonthlyInvoicePdf;
using SpiTech.Transaction.Application.Queries.GetResellerNacha;
using SpiTech.Transaction.Application.Queries.GetResellerPreviewNacha;
using SpiTech.Transaction.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Transaction.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class ResellerBillingController : ControllerBase
    {
        private readonly IMediator mediator;

        public ResellerBillingController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        /// <summary>
        /// Api to generate reseller monthly billing
        /// </summary>
        /// <param name="command">Object of GenerateResellerBillingCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_ResellerBilling_reseller-generate")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("reseller-generate")]
        public async Task<ActionResult<ResponseModel>> GenerateBilling([FromBody] GenerateResellerBillingCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns List of resellers monthly bills
        /// </summary>
        /// <param name="query">Object of GetResellerBillingQuery</param>
        /// <returns>It will return in the form of ResellerBillingPaginatedList</returns>
        [Authorize(Roles = IdentityRoleType.SuperAdmin)]
        [ApiPermissionAuthorize(Permissions = "Transactionapi_ResellerBilling_reseller-bills")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("reseller-bills")]
        public async Task<ActionResult<ResellerBillingPaginatedList>> GetBilling([FromQuery] GetResellerBillingQuery query)
        {
            return Ok(await mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to process resellers monthly bill payment
        /// </summary>
        /// <param name="command">Object of ProcessPaymentResellerBillingCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [Authorize(Roles = IdentityRoleType.SuperAdmin)]
        [ApiPermissionAuthorize(Permissions = "Transactionapi_ResellerBilling_reseller-process-payment")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("reseller-process-payment")]
        public async Task<ActionResult<ResponseModel>> ProcessPayment([FromBody] ProcessPaymentResellerBillingCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to review reseller monthly bills
        /// </summary>
        /// <param name="command">Object of UpdateResellerNeedReviewCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_ResellerBilling_reseller-update-needreview")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("reseller-update-needreview")]
        public async Task<ActionResult<ResponseModel>> UpdateNeedReview([FromBody] UpdateResellerNeedReviewCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to mark reseller monthly bill unpaid
        /// </summary>
        /// <param name="command">Object of UpdateResellerUnPaidCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_ResellerBilling_reseller-update-unpaid")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("reseller-update-unpaid")]
        public async Task<ActionResult<ResponseModel>> UpdateUnPaid([FromBody] UpdateResellerUnPaidCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns reseller monthly bill nacha file to preview
        /// </summary>
        /// <param name="query">Object of GetResellerPreviewNachaQuery</param>
        /// <returns>It will return in the form of NachaFileBytesModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_ResellerBilling_reseller-preview-nacha")]
        [ProducesResponseType(typeof(FileResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("reseller-preview-nacha")]
        public async Task<ActionResult> PreviewNacha([FromQuery] GetResellerPreviewNachaQuery query)
        {
            NachaFileBytesModel response = await mediator.Send(query).ConfigureAwait(false);
            return response != null && response.Bytes != null ? File(response.Bytes, "text/plain", response.File) : NoContent();
        }

        /// <summary>
        /// Returns reseller monthly bill nacha file to view
        /// </summary>
        /// <param name="query">Object of GetResellerNachaQuery</param>
        /// <returns>It will return in the form of NachaFileBytesModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_ResellerBilling_reseller-view-nacha")]
        [ProducesResponseType(typeof(FileResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("reseller-view-nacha")]
        public async Task<ActionResult> ViewNachaFile([FromQuery] GetResellerNachaQuery query)
        {
            NachaFileBytesModel response = await mediator.Send(query).ConfigureAwait(false);
            return response != null && response.Bytes != null ? File(response.Bytes, "text/plain", response.File) : NoContent();
        }

        /// <summary>
        /// Returns reseller monthly bill invoice pdf file by billing id
        /// </summary>
        /// <param name="request">Object of GetResellerMonthlyInvoicePdfQuery</param>
        /// <returns>It will return in the form of InvoiceFileBytesModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_ResellerBilling_reseller-monthly-invoice-pdf")]
        [ProducesResponseType(typeof(FileResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("reseller-monthly-invoice-pdf")]
        public async Task<ActionResult> ResellerMonthlyInvoicePdf([FromQuery] GetResellerMonthlyInvoicePdfQuery request)
        {
            InvoiceFileBytesModel response = await mediator.Send(request).ConfigureAwait(false);
            return response != null && response.Bytes != null ? File(response.Bytes, "application/pdf", response.File) : NoContent();
        }

        /// <summary>
        /// Returns all reseller monthly bill invoice pdf file by month and year
        /// </summary>
        /// <param name="request">Object of GetAllResellerMonthlyInvoicePdfQuery</param>
        /// <returns>It will return in the form of InvoiceFileBytesModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_ResellerBilling_reseller-all-monthly-invoice-pdf")]
        [ProducesResponseType(typeof(FileResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("reseller-all-monthly-invoice-pdf")]
        public async Task<ActionResult> AllResellerMonthlyInvoicePdf([FromQuery] GetAllResellerMonthlyInvoicePdfQuery request)
        {
            InvoiceFileBytesModel response = await mediator.Send(request).ConfigureAwait(false);
            return response != null && response.Bytes != null ? File(response.Bytes, "application/pdf", response.File) : NoContent();
        }
    }
}