﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Transaction.Application.Commands.CreateSaleAgentFee;
using SpiTech.Transaction.Application.Commands.UpdateSaleAgentFee;
using SpiTech.Transaction.Application.Queries.GetDefaultSaleAgentFee;
using SpiTech.Transaction.Application.Queries.GetSaleAgentFeeByFilter;
using SpiTech.Transaction.Application.Queries.GetSaleAgentFeeById;
using SpiTech.Transaction.Application.Queries.GetSaleAgentFeeByStoreId;
using SpiTech.Transaction.Domain.Entities;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Transaction.Api.Controllers
{

    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class SaleAgentFeeController : ControllerBase
    {
        private readonly IMediator _mediator;

        public SaleAgentFeeController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Api to get sale agent default fee structure
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseModel in the form of SaleAgentFee</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SaleAgentFee_salesagent-default")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("salesagent-default")]
        public async Task<ActionResult<ResponseModel<SaleAgentFee>>> GetByStoreId()
        {
            var result = await _mediator.Send(new GetDefaultSaleAgentFeeQuery()).ConfigureAwait(false);
            return Ok(new ResponseModel<SaleAgentFee>(result));
        }

        /// <summary>
        /// Returns sale agent fee details by saleagent id
        /// </summary>
        /// <param name="storeId">Varriable of int</param>
        /// <returns>It will return ResponseList in the form of SaleAgentFee</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SaleAgentFee_salesagent-bystoreid")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("salesagent-bystoreid")]
        public async Task<ActionResult<ResponseList<SaleAgentFee>>> GetByStoreId([FromQuery] int storeId)
        {
            var result = await _mediator.Send(new GetSaleAgentFeeByStoreIdQuery() { StoreId = storeId }).ConfigureAwait(false);
            return Ok(new ResponseList<SaleAgentFee> { Data = result });
        }

        /// <summary>
        /// Returns sale agent fee details by fee id
        /// </summary>
        /// <param name="saleAgentFeeId">Varriable of int</param>
        /// <returns>It will return ResponseModel in the form of SaleAgentFee</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SaleAgentFee_saleAgentFeeId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("{saleAgentFeeId}")]
        public async Task<ActionResult<ResponseModel<SaleAgentFee>>> GetById([FromRoute] int saleAgentFeeId)
        {
            return Ok(new ResponseModel<SaleAgentFee>(await _mediator.Send(new GetSaleAgentFeeByIdQuery() { SaleAgentFeeId = saleAgentFeeId }).ConfigureAwait(false)));
        }

        /// <summary>
        /// Returns sale agent fee details by filter
        /// </summary>
        /// <param name="query">Object of GetSaleAgentFeeByFilterQuery</param>
        /// <returns>It will return ResponseModel in the form of SaleAgentFee</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SaleAgentFee_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet()]
        public async Task<ActionResult<ResponseModel<SaleAgentFee>>> GetByStoreIdAndAgentId([FromQuery] GetSaleAgentFeeByFilterQuery query)
        {
            return Ok(new ResponseModel<SaleAgentFee>(await _mediator.Send(query).ConfigureAwait(false)));
        }

        /// <summary>
        /// Api to create sale agent fee structure
        /// </summary>
        /// <param name="command">Object of CreateSaleAgentFeeCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SaleAgentFee_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost]
        public async Task<ActionResult<ResponseModel>> Post([FromBody] CreateSaleAgentFeeCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to update existing sale agent fee structure
        /// </summary>
        /// <param name="command">Object of UpdateSaleAgentFeeCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SaleAgentFee_Patch")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch]
        public async Task<ActionResult<ResponseModel>> Update([FromBody] UpdateSaleAgentFeeCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }
    }
}
