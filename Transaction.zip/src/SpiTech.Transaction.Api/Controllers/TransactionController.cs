﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Transaction.Application.Queries.GetGetTransactionCount;
using SpiTech.Transaction.Application.Queries.GetGetTransactionCountByFilters;
using SpiTech.Transaction.Application.Queries.GetLastTransactionByFilter;
using SpiTech.Transaction.Application.Queries.GetMonthlyTransactionsBySiteId;
using SpiTech.Transaction.Application.Queries.GetPaymentReconcile;
using SpiTech.Transaction.Application.Queries.GetReceiptInfo;
using SpiTech.Transaction.Application.Queries.GetSaleItemByFilter;
using SpiTech.Transaction.Application.Queries.GetStoreByTransactionIds;
using SpiTech.Transaction.Application.Queries.GetTransactionDetailReport;
using SpiTech.Transaction.Application.Queries.GetTransactionReconcile;
using SpiTech.Transaction.Application.Queries.GetTransactionsByDateRange;
using SpiTech.Transaction.Application.Queries.GetTransactionsBySettlementRequestId;
using SpiTech.Transaction.Application.Queries.GetTransactionsBySiteId;
using SpiTech.Transaction.Application.Queries.GetTransactionsByStoreBillingId;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Transaction.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class TransactionController : ControllerBase
    {
        private readonly IMediator _mediator;

        public TransactionController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// returns Collection of reconciled transactions
        /// </summary>
        /// <param name="request">Object of GetTransactionReconcileQuery</param>
        /// <returns>It will return in the form of TransactionReconcilePaginatedList</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_Transaction_TransactionReconcileReport")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("TransactionReconcileReport")]
        public async Task<ActionResult<TransactionReconcilePaginatedList>> TransactionReconcileReport([FromQuery] GetTransactionReconcileQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns collection of monthly transaction by site id
        /// </summary>
        /// <param name="request">Object of GetMonthlyTransactionsBySiteIdQuery</param>
        /// <returns>It will return in the form of MonthlyTransactionPaginatedList</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_Transaction_MonthlyTransactionBySiteId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("MonthlyTransactionBySiteId")]
        public async Task<ActionResult<MonthlyTransactionPaginatedList>> MonthlyTransactionBySiteId([FromQuery] GetMonthlyTransactionsBySiteIdQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns transaction receipt info
        /// </summary>
        /// <param name="model">Object of GetReceiptInfoQuery</param>
        /// <returns>It will return in the form of TransactionReceiptDataModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_Transaction_Receipt")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("Receipt")]
        public async Task<ActionResult<TransactionReceiptDataModel>> Receipt([FromQuery] GetReceiptInfoQuery model)
        {
            return Ok(new TransactionReceiptDataModel { ReceiptData = await _mediator.Send(model).ConfigureAwait(false) });
        }

        /// <summary>
        /// Returns list of sales items with transaction details
        /// </summary>
        /// <param name="model">Object of GetSaleItemByFilterQuery</param>
        /// <returns>It will return IEnumerable in the form of SaleItemModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_Transaction_TransactionDetailsWithSaleItems")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("TransactionDetailsWithSaleItems")]
        public async Task<ActionResult<IEnumerable<SaleItemModel>>> TransactionDetailsWithSaleItems([FromQuery] GetSaleItemByFilterQuery model)
        {
            return Ok(await _mediator.Send(model).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns list of transactions details by store billing id
        /// </summary>
        /// <param name="request">Object of GetTransactionsByStoreBillingIdQuery</param>
        /// <returns>It will return IEnumerable in the form of TransactionModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_Transaction_DetailsByStoreBillingId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("DetailsByStoreBillingId")]
        public async Task<ActionResult<IEnumerable<TransactionModel>>> TransactionsByStoreBillingId([FromQuery] GetTransactionsByStoreBillingIdQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        /// returns list of transaction details by site id
        /// </summary>
        /// <param name="request">Object of GetTransactionsBySiteIdQuery</param>
        /// <returns>It will return IEnumerable in the form of TransactionModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_Transaction_DetailsBySiteId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("DetailsBySiteId")]
        public async Task<ActionResult<IEnumerable<TransactionModel>>> TransactionsBySiteId([FromQuery] GetTransactionsBySiteIdQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        /// returns list of transaction for which payment is reconciled 
        /// </summary>
        /// <param name="request">Object of GetPaymentReconcileQuery</param>
        /// <returns>It will return PaginatedList in the form of TransactionModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_Transaction_PaymentReconcile")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("PaymentReconcile")]
        public async Task<ActionResult<PaginatedList<TransactionModel>>> GetPaymentReconcile([FromQuery] GetPaymentReconcileQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns count of transactions based on filters
        /// </summary>
        /// <param name="request">Object of GetGetTransactionCountByFiltersQuery</param>
        /// <returns>It will return in the form of TransactionModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_Transaction_TransactionCountByFilters")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("TransactionCountByFilters")]
        public async Task<ActionResult<TransactionCountModel>> TransactionCountByFilters([FromQuery] GetGetTransactionCountByFiltersQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        /// returns transaction count 
        /// </summary>
        /// <param name="request">Object of GetGetTransactionCountQuery</param>
        /// <returns>It will return in the form of TransactionModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_Transaction_TransactionCount")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("TransactionCount")]
        public async Task<ActionResult<TransactionCountModel>> GetTransactionCount([FromQuery] GetGetTransactionCountQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns list of transaction between date range
        /// </summary>
        /// <param name="request">Object of GetTransactionsByDateRangeQuery</param>
        /// <returns>It will return IEnumerable in the form of TransactionModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetTransactionsByDateRange")]
        [AllowAnonymous]
        public async Task<ActionResult<IEnumerable<TransactionModel>>> GetTransactionsByDateRange([FromQuery] GetTransactionsByDateRangeQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns store details by transaction ids
        /// </summary>
        /// <param name="request">Object of GetStoreByTransactionIdsQuery</param>
        /// <returns>It will return IEnumerable in the form of TransactionModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_Transaction_StoreByTransactionIds")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("StoreByTransactionIds")]
        public async Task<ActionResult<IEnumerable<TransactionModel>>> StoreByTransactionsIds([FromBody] GetStoreByTransactionIdsQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns list of last transaction details by filter
        /// </summary>
        /// <param name="request">Object of GetLastTransactionByFilterQuery</param>
        /// <returns>It will return ResponseList in the form of TransactionModel</returns>
        //[ApiPermissionAuthorize(Permissions = "Transactionapi_Transaction_LastTransactionByFilter")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("LastTransactionByFilter")]
        public async Task<ActionResult<ResponseList<TransactionModel>>> GetLastTransactionByFilter([FromBody] GetLastTransactionByFilterQuery request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }
        /// <summary>
        /// Method will return the transaction details
        /// </summary>
        /// <param name="request">Object of GetTransactionDetailReportQuery</param>
        /// <returns>It will return PaginatedList in the form of TransactionReportModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetTransactionDetailReport")]
        public async Task<ActionResult<PaginatedList<TransactionReportModel>>> GetTransactionDetailReport([FromQuery] GetTransactionDetailReportQuery request)
        {
              
            PaginatedList<TransactionReportModel> result = await _mediator.Send(request).ConfigureAwait(false);

            return Ok(result);
        }
    }
}
