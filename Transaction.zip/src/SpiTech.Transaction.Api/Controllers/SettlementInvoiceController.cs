﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.Transaction.Application.Commands.CheckBalance;
using SpiTech.Transaction.Application.Commands.ProcessStoreSettlement;
using SpiTech.Transaction.Application.Commands.UpdateEodNeedReview;
using SpiTech.Transaction.Application.Commands.UpdateEodUnPaid;
using SpiTech.Transaction.Application.Commands.UpdateTranEodUnPaid;
using SpiTech.Transaction.Application.Queries.GetEodInvoicePreViewPdf;
using SpiTech.Transaction.Application.Queries.GetEodPreviewNacha;
using SpiTech.Transaction.Application.Queries.GetEODReportBySiteId;
using SpiTech.Transaction.Application.Queries.GetEodSettlement;
using SpiTech.Transaction.Application.Queries.GetEodViewNacha;
using SpiTech.Transaction.Application.Queries.GetTransactionsBySettlementRequestId;
using SpiTech.Transaction.Domain.Models;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class SettlementInvoiceController : ControllerBase
    {
        private readonly IMediator mediator;

        public SettlementInvoiceController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        /// <summary>
        ///returns settlement invoice details by id
        /// </summary>
        /// <param name="request">Object of GetTransactionsBySettlementRequestIdQuery</param>
        /// <returns>It will return IEnumerable in the form of TransactionModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SettlementInvoice_DetailsBySettlementRequestId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("DetailsBySettlementRequestId")]
        public async Task<ActionResult<IEnumerable<TransactionModel>>> TransactionsBySettlementRequestId([FromQuery] GetTransactionsBySettlementRequestIdQuery request)
        {
            return Ok(await mediator.Send(request).ConfigureAwait(false));
        }

        /// <summary>
        /// returns eod settlement details by filter
        /// </summary>
        /// <param name="query">Object of GetEodSettlementQuery</param>
        /// <returns>It will return in the form of SettlementPaginatedList</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SettlementInvoice_eod-settlement-request")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("eod-settlement-request")]
        public async Task<ActionResult<SettlementPaginatedList>> EodSettlementRequest([FromQuery] GetEodSettlementQuery query)
        {
            return Ok(await mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to review eod settlement details
        /// </summary>
        /// <param name="command">Object of UpdateEodNeedReviewCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SettlementInvoice_update-eod-needreview")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("update-eod-needreview")]
        public async Task<ActionResult<ResponseModel>> UpdateEodNeedReview([FromBody] UpdateEodNeedReviewCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to update eod settlement unpaid by id
        /// </summary>
        /// <param name="command">Object of UpdateEodUnPaidCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SettlementInvoice_update-eod-unpaid")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("update-eod-unpaid")]
        public async Task<ActionResult<ResponseModel>> UpdateEodUnPaid([FromBody] UpdateEodUnPaidCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns eod settlement nacha file to preview
        /// </summary>
        /// <param name="query">Object of GetEodPreviewNachaQuery</param>
        /// <returns>It will return in the form of NachaFileBytesModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SettlementInvoice_eod-preview-nacha")]
        [ProducesResponseType(typeof(FileResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("eod-preview-nacha")]
        public async Task<ActionResult> EodPreviewNacha([FromBody] GetEodPreviewNachaQuery query)
        {
            NachaFileBytesModel response = await mediator.Send(query).ConfigureAwait(false);
            return response != null && response.Bytes != null ? File(response.Bytes, "text/plain", response.File) : NoContent();
        }

        /// <summary>
        /// Returns eod settlement nacha file to view
        /// </summary>
        /// <param name="query">Object of GetEodViewNachaQuery</param>
        /// <returns>It will return in the form of NachaFileBytesModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SettlementInvoice_eod-view-nacha")]
        [ProducesResponseType(typeof(FileResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("eod-view-nacha")]
        public async Task<ActionResult> EodViewNacha([FromQuery] GetEodViewNachaQuery query)
        {
            NachaFileBytesModel response = await mediator.Send(query).ConfigureAwait(false);
            return response != null && response.Bytes != null ? File(response.Bytes, "text/plain", response.File) : NoContent();
        }
        /// <summary>
        /// Api to create eod settlement details
        /// </summary>
        /// <param name="command">Object of ProcessStoreSettlementCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SettlementInvoice_eod-settlement")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("eod-settlement")]
        public async Task<ActionResult<ResponseModel>> EodSettlement([FromBody] ProcessStoreSettlementCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        [ApiPermissionAuthorize(Permissions = "Transactionapi_SettlementInvoice_eod-settlement")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("EodSettlementMerchantConsumer")]
        public async Task<ActionResult<ResponseModel>> EodSettlementMerchantConsumer([FromBody] ProcessStoreSettlementCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns  EOD Invoice pdf to preview
        /// </summary>
        /// <param name="request">Object of GetEodInvoicePreViewPdfQuery</param>
        /// <returns>It will return in the form of InvoiceFileBytesModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SettlementInvoice_preview-eod-invoice-pdf")]
        [ProducesResponseType(typeof(FileResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("preview-eod-invoice-pdf")]
        public async Task<ActionResult> PreViewEodInvoicePdfFile([FromQuery] GetEodInvoicePreViewPdfQuery request)
        {
            InvoiceFileBytesModel response = await mediator.Send(request).ConfigureAwait(false);
            return response != null && response.Bytes != null ? File(response.Bytes, "application/pdf", response.File) : NoContent();
        }

        /// <summary>
        /// Returns eod report by site id
        /// </summary>
        /// <param name="model">Object of GetEODReportBySiteIdQuery</param>
        /// <returns>It will return in the form of EodSettlementPaginatedList</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SettlementInvoice_EODReport")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("EODReport")]
        public async Task<ActionResult<EodSettlementPaginatedList>> EODReport([FromQuery] GetEODReportBySiteIdQuery model)
        {
            return Ok(await mediator.Send(model).ConfigureAwait(false));
        }

        [ApiPermissionAuthorize(Permissions = "Transactionapi_SettlementInvoice_update-eod-unpaid")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("update-tran-eod-unpaid")]
        public async Task<ActionResult<ResponseModel>> UpdateTranEodUnPaid([FromBody] UpdateTranEodUnPaidCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("CheckBalance")]
        public async Task<ActionResult<CheckBalanceModel>> CheckBalance(CheckBalanceCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }
    }
}
