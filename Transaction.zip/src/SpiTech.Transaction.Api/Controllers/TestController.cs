﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Converters;
using SpiTech.ApplicationCore.Domain;
using SpiTech.ApplicationCore.Domain.Configs;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.ApplicationCore.Nacha;
using SpiTech.ApplicationCore.Services;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Transaction.Domain;
using SpiTech.Transaction.Domain.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Transaction.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TestController : ControllerBase
    {
        private readonly IMediator mediator;
        private readonly INachaFileBuilder nachaFileBuilder;
        private readonly ISftpService sftpService;
        private readonly ILogger<TestController> logger;
        private readonly IViewToStringConverter viewToStringConverter;
        private readonly IIdentityServiceClient identityServiceClient;
        private readonly SftpConfigs sftpConfigs;
        private readonly IFnboEncryptService fnboEncryptService;
        private readonly IStorageService fnboStorageService;

        public TestController(IMediator mediator,
                            INachaFileBuilder nachaFileBuilder,
                            IStorageServiceFactory storageServiceFactory,
                            ISftpService sftpService,
                            ILogger<TestController> logger,
                            IViewToStringConverter viewToStringConverter,
                            IIdentityServiceClient identityServiceClient,
                            SftpConfigs sftpConfigs,
                            IFnboEncryptService fnboEncryptService)
        {
            this.mediator = mediator;
            this.nachaFileBuilder = nachaFileBuilder;
            this.sftpService = sftpService;
            this.logger = logger;
            this.viewToStringConverter = viewToStringConverter;
            this.identityServiceClient = identityServiceClient;
            this.sftpConfigs = sftpConfigs;
            this.fnboEncryptService = fnboEncryptService;
            this.fnboStorageService = storageServiceFactory.Get(ContainerType.FNBOReceivedNachaFile);
        }

        [HttpGet("TestSftpConnection")]
        public async Task<ActionResult<List<string>>> TestSftpConnection()
        {
            return Ok(await Task.FromResult(sftpService.TestConnection(this.sftpConfigs.Get(DomainConstant.SftpConfig.FNBO))));
        }

        [HttpGet("uploadFnbo")]
        public async Task<ActionResult<List<string>>> UploadFnbo()
        {

            var config = this.sftpConfigs.Get(DomainConstant.SftpConfig.FNBO);
            var file = "SETTLEMENT638152776483576420_20230324180048.txt";
            var bytes = await System.IO.File.ReadAllBytesAsync(file);
            Stream stream = new MemoryStream(bytes);

            await sftpService.UploadFile(stream, file, config);

            return Ok();
        }

        [HttpGet("downloadFnbo")]
        public async Task<ActionResult<List<string>>> DownloadFnbo()
        {
            var config = this.sftpConfigs.Get(DomainConstant.SftpConfig.FNBO);

            string[] encryptFiles = Directory.GetFiles(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "NachaFiles", "Decryptfiles"));
            foreach (string file in encryptFiles)
            {
                var encryptedFilePath = file;//Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "NachaFiles", "5752_20230308162907.txt.pgp");
                var bytes = await System.IO.File.ReadAllBytesAsync(encryptedFilePath);
                Stream stream = new MemoryStream(bytes);

                using (var decryptedStream = await fnboEncryptService.Decrypt(stream, config.DecryptKeyFile, config.DecryptPassword))
                {
                    var decryptedFilePath = encryptedFilePath.Replace(".pgp", "");

                    using (var fileStream = new FileStream(decryptedFilePath, FileMode.Create, FileAccess.Write))
                    {
                        decryptedStream.CopyTo(fileStream);
                    }
                }
            }


            var files = this.sftpService.GetFiles("/out/SpiTech_OSG_MF005752/", this.sftpConfigs.Get(DomainConstant.SftpConfig.FNBO));

            if (files != null && files.Any())
            {
                var unProcessedFileDetails = this.sftpService.DownloadFiles(files, this.sftpConfigs.Get(DomainConstant.SftpConfig.FNBO));

                foreach (var unProcessedFileDetail in unProcessedFileDetails)
                {
                    try
                    {
                        System.IO.File.WriteAllBytes(unProcessedFileDetail.FileName, unProcessedFileDetail.Bytes.ToArray());
                    }
                    catch (Exception ex)
                    {
                        logger.Error(ex, unProcessedFileDetail);
                    }

                    Stream stream = new MemoryStream(unProcessedFileDetail.Bytes.ToArray());

                    using (var decryptedStream = await fnboEncryptService.Decrypt(stream, config.DecryptKeyFile, config.DecryptPassword))
                    {
                        var encryptedFiledownloadPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "NachaFiles", "STOREBILL-" + DateTime.UtcNow.ToString("ddMMyyyyHHmmss") + ".txt");

                        using (var fileStream = new FileStream(encryptedFiledownloadPath, FileMode.Create, FileAccess.Write))
                        {
                            decryptedStream.CopyTo(fileStream);
                        }
                    }

                    try
                    {
                        var uploaded = await this.fnboStorageService.UploadBlob(unProcessedFileDetail.Bytes, unProcessedFileDetail.FileName, "text/plain");
                    }
                    catch (Exception ex)
                    {
                        logger.Error(ex, unProcessedFileDetail);
                    }
                }
            }

            return Ok();
        }

        [HttpGet("GenerateNachaFile")]
        public async Task<IActionResult> GenerateNachaFile(decimal settlementAmount, decimal billAmount, string identificationNumber)
        {
            try
            {
                var config = this.sftpConfigs.Get(DomainConstant.SftpConfig.FNBO);
                var nachaConfig = new NachaConfig()
                {
                    BankRoutingNo = "104000016",
                    RoutingNo = "104000016",
                    AccountNo = "1872360881",
                    BankName = "First National Bank",
                    ImmediateOriginName = "STRIDE BANK NA",
                    BatchCompanyName = "SpiTech LLC"
                };

                var masterAccount = new MasterAccountModel
                {
                    AccountName = "SpiTech LLC",
                    AccountNo = "9686411",
                    //IdentificationNumber = "SE" + DateTime.UtcNow.ToString("ddMMyyyy"),
                    AccountType = AccountType.Checking,
                    RoutingNo = "125603998"
                };

                var storeAccounts = new List<NachaModel>();
                long acctno = 9677628301;

                for (int i = 0; i < 30; i++)
                {
                    storeAccounts.Add(new NachaModel
                    {
                        ProcessingAccount = new NachaAccount
                        {
                            AccountName = "Spitech LLC1",
                            AccountNo = acctno.ToString(),
                            RoutingNo = "125589325",
                            AccountType = AccountType.Checking
                        },
                        Amount = settlementAmount++,
                        IdentificationNumber = $"s{identificationNumber}"// + DateTime.UtcNow.ToString("ddMMyyyy")
                    });

                    acctno++;
                }

                //var nachaFileBytesModel = nachaFileBuilder.GetBytes(nachaConfig
                //       , storeAccounts
                //       ,NachaProcessType.DailyStoreSettlement);

                //await this.storageService.UploadBlob(nachaFileBytesModel.Bytes, nachaFileBytesModel.File, "text/plain");
                //var blob = await this.storageService.GetFile(nachaFileBytesModel.File);

                //using (var stream = this.nachaFileBuilder.CreateStream(nachaConfig, storeAccounts, NachaProcessType.SETTLEMENT, TransactionCodeType.Credit))
                //{
                //    using (var encryptedStream = await fnboEncryptService.Encrypt(stream, config.EncryptKeyFile))
                //    {
                //        string encryptedFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "NachaFiles", "SETTLEMENT-" + DateTime.UtcNow.ToString("ddMMyyyyHHmmss") + ".txt.pgp");

                //        using (var fileStream = new FileStream(encryptedFilePath, FileMode.Create, FileAccess.Write))
                //        {
                //            encryptedStream.CopyTo(fileStream);
                //        }
                //    }
                //}

                await Task.Delay(2000);

                storeAccounts = new List<NachaModel>();

                acctno = 9677628301;

                for (int i = 0; i < 30; i++)
                {
                    storeAccounts.Add(new NachaModel
                    {
                        ProcessingAccount = new NachaAccount
                        {
                            AccountName = "Spitech LLC1",
                            AccountNo = "9677628308",
                            RoutingNo = "125589325",
                            AccountType = AccountType.Checking
                        },
                        Amount = billAmount++,
                        IdentificationNumber = $"s{identificationNumber}"// + DateTime.UtcNow.ToString("ddMMyyyy")
                    });

                    acctno++;
                }

                //masterAccount.IdentificationNumber = "BL" + DateTime.UtcNow.ToString("ddMMyyyy");
                masterAccount.AccountNo = "2872360881";

                //using (var stream = this.nachaFileBuilder.CreateStream(nachaConfig, storeAccounts, NachaProcessType.STOREBILL, TransactionCodeType.Debit))
                //{
                //    using (var encryptedStream = await fnboEncryptService.Encrypt(stream, config.EncryptKeyFile))
                //    {
                //        var encryptedFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "NachaFiles", "STOREBILL-" + DateTime.UtcNow.ToString("ddMMyyyyHHmmss") + ".txt.pgp");

                //        using (var fileStream = new FileStream(encryptedFilePath, FileMode.Create, FileAccess.Write))
                //        {
                //            encryptedStream.CopyTo(fileStream);
                //        }
                //    }
                //}
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return Ok();
        }

        //[HttpGet("UploadNachaFile")]
        //public async Task<IActionResult> UploadNachaFile()
        //{
        //    var nachaConfig = new ProcessingAccountModel();
        //    nachaConfig.ReceivingBankRoutingNo = "101000048";
        //    nachaConfig.ProcessingRoutingNo = "103100195";
        //    nachaConfig.ProcessingAccountNo = "1872360881";
        //    nachaConfig.ProcessingBankName = "FRB OF KANSAS CITY";
        //    nachaConfig.ProcessingAccountName = "STRIDE BANK NA";
        //    nachaConfig.AccountName = "111 SpiTech";
        //    nachaConfig.AccountNo = "9136411";
        //    nachaConfig.RoutingNo = "103103778";
        //    nachaConfig.IdentificationNumber = "P" + DateTime.UtcNow.ToString("ddMMyyyy");
        //    nachaConfig.AccountType = AccountType.Checking;

        //    var storeAccounts = new List<NachaAccountModel>();
        //    storeAccounts.Add(new NachaAccountModel
        //    {
        //        AccountName = "Spitech LLC",
        //        AccountNo = "8097628308",
        //        RoutingNo = "111014325",
        //        AccountType = AccountType.Checking,
        //        Amount = 1.5M,
        //        AmountType = AmountType.CreditDebit,
        //        IdentificationNumber = "S1" + DateTime.UtcNow.ToString("ddMMyyyy")
        //    });

        //    storeAccounts.Add(new NachaAccountModel
        //    {
        //        AccountName = "Spitech LLC",
        //        AccountNo = "8097628308",
        //        RoutingNo = "111014325",
        //        AccountType = AccountType.Checking,
        //        Amount = 2M,
        //        AmountType = AmountType.CashReward,
        //        IdentificationNumber = "S2" + DateTime.UtcNow.ToString("ddMMyyyy")
        //    });


        //    if (DateTime.Now.DayOfYear % 2 == 0)
        //    {
        //        this.nachaFileBuilder.UploadFileInSftp(nachaConfig, storeAccounts, NachaProcessType.DailyStoreSettlement);
        //        this.nachaFileBuilder.CreateFile(nachaConfig, storeAccounts, NachaProcessType.DailyStoreSettlement);
        //    }
        //    else
        //    {
        //        this.nachaFileBuilder.UploadFileInSftp(nachaConfig, storeAccounts, NachaProcessType.MonthlyBillingInvoice);
        //        this.nachaFileBuilder.CreateFile(nachaConfig, storeAccounts, NachaProcessType.MonthlyBillingInvoice);
        //    }

        //    return Ok();
        //}
    }
}
