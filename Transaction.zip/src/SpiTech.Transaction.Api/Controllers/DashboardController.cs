﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Transaction.Application.Queries.DashboardApis.GetDashboardCashRewardDetails;
using SpiTech.Transaction.Application.Queries.DashboardApis.GetDashboardConsumersDetails;
using SpiTech.Transaction.Application.Queries.DashboardApis.GetDashboardMonthWiseTransactionDetails;
using SpiTech.Transaction.Application.Queries.DashboardApis.GetDashboardTransactionDetails;
using SpiTech.Transaction.Application.Queries.DashboardApis.GetDashboardYearWiseTransactionDetails;
using SpiTech.Transaction.Application.Queries.DashboardApis.GetMobileDashboardDetails;
using SpiTech.Transaction.Application.Queries.DashboardApis.GetMobileDashboardYearWiseTransactionDetails;
using SpiTech.Transaction.Application.Queries.DashBoardApis.GetDashboardFailedTransactionDetails;
using SpiTech.Transaction.Application.Queries.DashBoardApis.GetDashboardSaleItemsDetails;
using SpiTech.Transaction.Application.Queries.GetDashboardConsumersList;
using SpiTech.Transaction.Application.Queries.GetDashboardConsumersProfileDetails;
using SpiTech.Transaction.Domain.Models.DashboardApisModel;
using System.Net;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class DashboardController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IUserAuthenticationProvider _authenticationprovider;
        private readonly ILogger<DashboardController> _logger;
 
        public DashboardController(IMediator mediator,
                                    IUserAuthenticationProvider authenticationProvider, 
                                    ILogger<DashboardController> logger)
        {
            _mediator = mediator;
            _authenticationprovider = authenticationProvider;
            _logger = logger;
        }

        /// <summary>
        /// Api to get transactiondetails for dashboard
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        //[ApiPermissionAuthorize(Permissions = "Transactionapi_DashBoard_TransactionDetails")]
        //[AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("TransactionDetails")]
        public async Task<ActionResult<ResponseModel<DashboardTransactionModel>>> GetTransactionDetails([FromBody] GetDashboardTransactionDetailsQuery query)
        {
            _logger.Warn($"TransactionDetails Call strat");
            var result = await _mediator.Send(query).ConfigureAwait(false);
            _logger.Warn($"TransactionDetails Call");
            return Ok(result);
        }
        /// <summary>
        /// Api to get cashreward details for dashboard
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_DashBoard_RewardDetails")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("RewardDetails")]
        public async Task<ActionResult<ResponseModel<DashboardCashRewardModel>>> GetDashboardCashRewardDetails([FromBody] GetDashboardCashRewardDetailsQuery query)
        {
            var result = await _mediator.Send(query).ConfigureAwait(false);
            return Ok(result);
        }

        /// <summary>
        /// Api to get consumers transaction details for dashboard
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_DashBoard_ConsumersDetails")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("ConsumersDetails")]
        public async Task<ActionResult<ResponseModel<DashboardConsumersModel>>> GetDashboardConsumersDetails([FromBody] GetDashboardConsumersDetailsQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }
        /// <summary>
        /// Api to get sale items details for dashboard
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_DashBoard_SaleItemsDetails")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("ItemsDetails")]
        public async Task<ActionResult<ResponseList<DashboardSaleItemsModel>>> GetDashboardSaleItemsDetails([FromBody] GetDashboardSaleItemsDetailsQuery query)
        {
          
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to get failed transactions details for dashboard
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_DashBoard_FailedTransactionDetails")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("FailedTransactionDetails")]
        public async Task<ActionResult<ResponseModel<DashboardTransactionModel>>> GetDashboardFailedTransactionDetails([FromBody] GetDashboardFailedTransactionDetailsQuery query)
        {
            
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Get User wise transaction detail list
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_DashBoard_ConsumersListUserWise")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetDashboardConsumersList")]
        public async Task<ActionResult<PaginatedList<ConsumersList>>> GetDashboardConsumersList([FromQuery] GetDashboardConsumersListQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }
        /// <summary>
        /// Api to get storewise transaction details for mobile dashboard
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_DashBoard_MobileDashboardDetails")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("MobileDashboardDetails")]
        public async Task<ActionResult<ResponseList<MobileDashboardStoreDetailsModel>>> GetMobileDashboardStoreWise([FromBody] GetMobileDashboardDetailsQuery query)
        {           
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }
        /// <summary>
        /// Get Dashboard Consumer Profile Details
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_DashBoard_ProfileDetails")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("ProfileDetails")]
        public async Task<ActionResult<ResponseModel<DashboardConsumersProfileModel>>> GetDashboardConsumerProfileDetails([FromQuery] GetDashboardConsumersProfileDetailsModel model)
        {
            return Ok(await _mediator.Send(new GetDashboardConsumersProfileDetailsQuery() { StartDate=model.StartDate,EndDate=model.EndDate}).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to get monthwise transaction details for dashboard
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_DashBoard_MonthwiseTransactionDetails")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("MonthwiseTransactionDetails")]
        public async Task<ActionResult<ResponseList<DashboardMonthwiseModel>>> GetMonthwiseTransactionDetails([FromBody] GetDashboardMonthWiseTransactionDetailsQuery query)
        {
            query.UserIdToken = _authenticationprovider.GetUserAuthentication().UserId;
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to get yearwise transaction details for dashboard
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_DashBoard_YearwiseTransactionDetails")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("YearwiseTransactionDetails")]
        public async Task<ActionResult<ResponseList<DashboardYearWiseModel>>> GetYearwiseTransactionDetails([FromBody] GetDashboardYearWiseTransactionDetailsQuery query)
        {
            
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }
        /// <summary>
        /// Api to get yearwise transaction details for Mobile dashboard
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_DashBoard_MobileDashboardYearwiseTransactionDetails")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("MobileDashboardYearwiseTransactionDetails")]
        public async Task<ActionResult<ResponseList<DashboardYearWiseModel>>> GetMobileDashboardYearwiseTransactionDetails([FromBody] GetMobileDashboardYearWiseTransactionDetailsQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }
    }
}