﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Transaction.Application.Commands.CreateStoreSettlementConfig;
using SpiTech.Transaction.Application.Commands.CreateStoreSettlementConfigFromDefault;
using SpiTech.Transaction.Application.Commands.UpdateStoreSettlementConfig;
using SpiTech.Transaction.Application.Queries.GetStoreSettlementConfigByStoreId;
using SpiTech.Transaction.Application.Queries.GetStoreSettlementConfigDefault;
using SpiTech.Transaction.Domain.Models;
using System.Net;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class StoreSettlementConfigController : ControllerBase
    {
        private readonly IMediator _mediator;

        public StoreSettlementConfigController(IMediator mediator)
        {
            _mediator = mediator;
        }
        /// <summary>
        /// Api to get default store settlement config 
        /// </summary>
        /// <param name="query">Object of GetStoreSettlementConfigDefaultQuery</param>
        /// <returns>It will return ResponseModel in the form of StoreSettlementConfigModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreSettlementConfig_store-default")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("store-default")]
        public async Task<ActionResult<ResponseModel<StoreSettlementConfigModel>>> GetDefault([FromQuery] GetStoreSettlementConfigDefaultQuery query)
        {
            var result = await _mediator.Send(query).ConfigureAwait(false);
            return Ok(new ResponseModel<StoreSettlementConfigModel> { Data = result });
        }

        /// <summary>
        /// Api to get store settlement config by store id
        /// </summary>
        /// <param name="query">Object of GetStoreSettlementConfigByStoreIdQuery</param>
        /// <returns>It will return ResponseModel in the form of StoreSettlementConfigModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreSettlementConfig_store-bystoreid")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("store-bystoreid")]
        public async Task<ActionResult<ResponseModel<StoreSettlementConfigModel>>> GetByStoreId([FromQuery] GetStoreSettlementConfigByStoreIdQuery query)
        {
            var result = await _mediator.Send(query).ConfigureAwait(false);
            return Ok(new ResponseModel<StoreSettlementConfigModel> { Data = result });
        }

        /// <summary>
        /// Api to create store settlement config 
        /// </summary>
        /// <param name="command">Object of CreateStoreSettlementConfigCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreSettlementConfig_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost]
        public async Task<ActionResult<ResponseModel>> Post([FromBody] CreateStoreSettlementConfigCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        ///  Api to clone default store settlement config 
        /// </summary>
        /// <param name="command">Object of CreateStoreSettlementConfigFromDefaultCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreSettlementConfig_store-default-clone")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("store-default-clone")]
        public async Task<ActionResult<ResponseModel>> Post([FromBody] CreateStoreSettlementConfigFromDefaultCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        ///  Api to update existing store settlement config 
        /// </summary>
        /// <param name="command">Object of UpdateStoreSettlementConfigCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreSettlementConfig_Patch")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch]
        public async Task<ActionResult<ResponseModel>> Update([FromBody] UpdateStoreSettlementConfigCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }
    }
}
