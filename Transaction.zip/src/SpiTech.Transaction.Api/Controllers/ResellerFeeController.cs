﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Transaction.Application.Commands.CreateResellerFee;
using SpiTech.Transaction.Application.Commands.CreateResellerFeeFromDefault;
using SpiTech.Transaction.Application.Commands.UpdateResellerFee;
using SpiTech.Transaction.Application.Queries.GetDefaultResellerFee;
using SpiTech.Transaction.Application.Queries.GetResellerFeeById;
using SpiTech.Transaction.Application.Queries.GetResellerFeeByResellerId;
using SpiTech.Transaction.Domain.Entities;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Transaction.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class ResellerFeeController : ControllerBase
    {
        private readonly IMediator _mediator;

        public ResellerFeeController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Api to get reseller default fee structure
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of ResellerFee</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_ResellerFee_reseller-default")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("reseller-default")]
        public async Task<ActionResult<ResponseList<ResellerFee>>> GetResellerDefault()
        {
            var result = await _mediator.Send(new GetDefaultResellerFeeQuery()).ConfigureAwait(false);
            return Ok(new ResponseList<ResellerFee>(result));
        }

        /// <summary>
        /// Returns reseller details by reseller id
        /// </summary>
        /// <param name="resellerId">Varriable of int</param>
        /// <returns>It will return ResponseList in the form of ResellerFee</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_ResellerFee_reseller-byresellerid")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("reseller-byresellerid")]
        public async Task<ActionResult<ResponseList<ResellerFee>>> GetByStoreId([FromQuery] int resellerId)
        {
            var result = await _mediator.Send(new GetResellerFeeByResellerIdQuery() { ResellerId = resellerId }).ConfigureAwait(false);
            return Ok(new ResponseList<ResellerFee> { Data = result });
        }

        /// <summary>
        /// Returns reseller fee details by fee id
        /// </summary>
        /// <param name="resellerFeeId">Varriable of int</param>
        /// <returns>It will return ResponseModel in the form of ResellerFee</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_ResellerFee_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("{resellerFeeId}")]
        public async Task<ActionResult<ResponseModel<ResellerFee>>> GetById([FromRoute] int resellerFeeId)
        {
            return Ok(new ResponseModel<ResellerFee>(await _mediator.Send(new GetResellerFeeByIdQuery() { ResellerFeeId = resellerFeeId }).ConfigureAwait(false)));
        }

        /// <summary>
        /// Api to create reseller fee structure
        /// </summary>
        /// <param name="command">Object of CreateResellerFeeCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_ResellerFee_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost]
        public async Task<ActionResult<ResponseModel>> Post([FromBody] CreateResellerFeeCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to update reseller existing fee structure
        /// </summary>
        /// <param name="command">Object of UpdateResellerFeeCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_ResellerFee_Patch")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch]
        public async Task<ActionResult<ResponseModel>> Update([FromBody] UpdateResellerFeeCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to clone reseller default fee structure
        /// </summary>
        /// <param name="command">Object of CreateResellerFeeFromDefaultCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_ResellerFee_reseller-default-clone")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("reseller-default-clone")]
        public async Task<ActionResult<ResponseModel>> Post([FromBody] CreateResellerFeeFromDefaultCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }
    }
}
