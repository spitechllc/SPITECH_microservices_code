﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Transaction.Application.Commands.CreateStoreBillingFee;
using SpiTech.Transaction.Application.Commands.CreateStoreBillingFeeFromDefault;
using SpiTech.Transaction.Application.Commands.UpdateStoreBillingFee;
using SpiTech.Transaction.Application.Queries.GetStoreBillingFeeById;
using SpiTech.Transaction.Application.Queries.GetStoreBillingFeeByStoreId;
using SpiTech.Transaction.Application.Queries.GetStoreBillingFeeDefault;
using SpiTech.Transaction.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Transaction.Api.Controllers
{

    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class StoreBillingFeeController : ControllerBase
    {
        private readonly IMediator _mediator;

        public StoreBillingFeeController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Api to get store default fee structure
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of StoreBillingFeeModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreBillingFee_store-default")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("store-default")]
        public async Task<ActionResult<ResponseList<StoreBillingFeeModel>>> GetDefault()
        {
            System.Collections.Generic.List<StoreBillingFeeModel> result = await _mediator.Send(new GetStoreBillingFeeDefaultQuery() { }).ConfigureAwait(false);
            return Ok(new ResponseList<StoreBillingFeeModel> { Data = result });
        }

        /// <summary>
        /// Returns store billing fee details by store id
        /// </summary>
        /// <param name="storeId">Varriable of int</param>
        /// <returns>It will return ResponseList in the form of StoreBillingFeeModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreBillingFee_store-bystoreid")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("store-bystoreid")]
        public async Task<ActionResult<ResponseList<StoreBillingFeeModel>>> GetByStoreId([FromQuery] int storeId)
        {
            System.Collections.Generic.List<StoreBillingFeeModel> result = await _mediator.Send(new GetStoreBillingFeeByStoreIdQuery() { StoreId = storeId }).ConfigureAwait(false);
            return Ok(new ResponseList<StoreBillingFeeModel> { Data = result });
        }

        /// <summary>
        /// Returns store billing fee details by fee id
        /// </summary>
        /// <param name="storebillingFeeId">Varriable of int</param>
        /// <returns>It will return ResponseModel in the form of StoreBillingFeeModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreBillingFee_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("{storebillingFeeId}")]
        public async Task<ActionResult<ResponseModel<StoreBillingFeeModel>>> GetById([FromRoute] int storebillingFeeId)
        {
            StoreBillingFeeModel result = await _mediator.Send(new GetStoreBillingFeeByIdQuery() { StoreBillingFeeId = storebillingFeeId }).ConfigureAwait(false);
            return Ok(new ResponseModel<StoreBillingFeeModel> { Data = result, Success = result != null });
        }

        /// <summary>
        /// Api to create store monthly billing fee structure
        /// </summary>
        /// <param name="command">Object of CreateStoreBillingFeeCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreBillingFee_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost]
        public async Task<ActionResult<ResponseModel>> Post([FromBody] CreateStoreBillingFeeCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to clone store billing default fee structure
        /// </summary>
        /// <param name="command">Object of CreateStoreBillingFeeFromDefaultCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreBillingFee_store-default-clone")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("store-default-clone")]
        public async Task<ActionResult<ResponseModel>> Post([FromBody] CreateStoreBillingFeeFromDefaultCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to update existing store billing fee structure
        /// </summary>
        /// <param name="command">Object of UpdateStoreBillingFeeCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_StoreBillingFee_Patch")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch]
        public async Task<ActionResult<ResponseModel>> Update([FromBody] UpdateStoreBillingFeeCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }
    }
}
