﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.ApplicationCore.Services;
using SpiTech.Transaction.Application.Queries.GetACHReturmReport;
using SpiTech.Transaction.Application.Queries.GetACHTransactionReport;
using SpiTech.Transaction.Application.Queries.GetDailyNachaProcessingReport;
using SpiTech.Transaction.Application.Queries.GetDailyNachaReturmReport;
using SpiTech.Transaction.Domain.Models;
using System.Net;
using System.Threading.Tasks;

namespace SpiTech.Transaction.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class NachReportsController : ControllerBase
    {
        private readonly IMediator _mediator;

        public NachReportsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Api to get daily nacha processing details
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_NachaReports_NachaDailyProcessingReport")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("NachaDailyProcessingReport")]
        public async Task<ActionResult<PaginatedList<NachaDailyProcessingReportModel>>> GetNachaDailyProcessingReport([FromQuery] GetDailyNachaProcessingReportQuery query)
        {           
            var result = await _mediator.Send(query).ConfigureAwait(false);
            return Ok(result);
        }
        /// <summary>
        /// Api to get daily nacha return details
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_NachaReports_NachaDailyReturnReport")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("NachaDailyReturnReport")]
        public async Task<ActionResult<PaginatedList<NachaDailyReturnReportModel>>> GetNachaDailyReturnReport([FromQuery] GetDailyNachaReturmReportQuery query)
        {           
            var result = await _mediator.Send(query).ConfigureAwait(false);
            return Ok(result);
        
        }

        /// <summary>
        /// Api to get daily ach processing details
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_NachaReports_ACHTransactionReport")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("ACHTransactionReport")]
        public async Task<ActionResult<PaginatedList<ACHTransactionReportModel>>> GetACHDailyTransactionReport([FromQuery] GetACHTransactionReportQuery query)
        {
          
            var result = await _mediator.Send(query).ConfigureAwait(false);
            return Ok(result);
        }

        /// <summary>
        /// Api to get ach return details
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_NachaReports_ACHReturnReport")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("ACHReturnReport")]
        public async Task<ActionResult<PaginatedList<ACHReturnReportModel>>> GetACHReturnReport([FromQuery] GetACHReturmReportQuery query)
        {
            var result = await _mediator.Send(query).ConfigureAwait(false);
            return Ok(result);

        }
    }
}