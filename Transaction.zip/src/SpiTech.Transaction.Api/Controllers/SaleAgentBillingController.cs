﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.Transaction.Application.Commands.GenerateSaleAgentBilling;
using SpiTech.Transaction.Application.Commands.ProcessPaymentSaleAgentBilling;
using SpiTech.Transaction.Application.Commands.UpdateSaleAgentNeedReview;
using SpiTech.Transaction.Application.Commands.UpdateSaleAgentUnPaid;
using SpiTech.Transaction.Application.Queries.GetAllSaleAgentMonthlyInvoicePdf;
using SpiTech.Transaction.Application.Queries.GetSaleAgentBilling;
using SpiTech.Transaction.Application.Queries.GetSaleAgentMonthlyInvoicePdf;
using SpiTech.Transaction.Application.Queries.GetSaleAgentNacha;
using SpiTech.Transaction.Application.Queries.GetSaleAgentPreviewNacha;
using SpiTech.Transaction.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Transaction.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class SaleAgentBillingController : ControllerBase
    {
        private readonly IMediator mediator;

        public SaleAgentBillingController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        /// <summary>
        /// Api to generate sale agent monthly billing
        /// </summary>
        /// <param name="command">Object of GenerateSaleAgentBillingCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SaleAgentBilling_saleagent-generate")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("saleagent-generate")]
        public async Task<ActionResult<ResponseModel>> GenerateBilling([FromBody] GenerateSaleAgentBillingCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        ///  Returns List of sale agent monthly bills
        /// </summary>
        /// <param name="query">Object of GetSaleAgentBillingQuery</param>
        /// <returns>It will return in the form of SaleAgentBillingPaginatedList</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SaleAgentBilling_saleagent-bills")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("saleagent-bills")]
        public async Task<ActionResult<SaleAgentBillingPaginatedList>> GetBilling([FromQuery] GetSaleAgentBillingQuery query)
        {
            return Ok(await mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        ///  Api to process sale agents monthly bill payment
        /// </summary>
        /// <param name="command">Object of ProcessPaymentSaleAgentBillingCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SaleAgentBilling_saleagent-process-payment")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("saleagent-process-payment")]
        public async Task<ActionResult<ResponseModel>> ProcessPayment([FromBody] ProcessPaymentSaleAgentBillingCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        ///  Api to review sale agent monthly bills
        /// </summary>
        /// <param name="command">Object of UpdateSaleAgentNeedReviewCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SaleAgentBilling_saleagent-update-needreview")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("saleagent-update-needreview")]
        public async Task<ActionResult<ResponseModel>> UpdateNeedReview([FromBody] UpdateSaleAgentNeedReviewCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to mark sale agent monthly bill unpaid
        /// </summary>
        /// <param name="command">object of UpdateSaleAgentUnPaidCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SaleAgentBilling_saleagent-update-unpaid")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("saleagent-update-unpaid")]
        public async Task<ActionResult<ResponseModel>> UpdateUnPaid([FromBody] UpdateSaleAgentUnPaidCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns sale agent monthly bill nacha file to preview
        /// </summary>
        /// <param name="query">Object of GetSaleAgentPreviewNachaQuery</param>
        /// <returns>It will return in the form of NachaFileBytesModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SaleAgentBilling_saleagent-preview-nacha")]
        [ProducesResponseType(typeof(FileResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("saleagent-preview-nacha")]
        public async Task<ActionResult> PreviewNacha([FromQuery] GetSaleAgentPreviewNachaQuery query)
        {
            NachaFileBytesModel response = await mediator.Send(query).ConfigureAwait(false);
            return response != null && response.Bytes != null ? File(response.Bytes, "text/plain", response.File) : NoContent();
        }

        /// <summary>
        /// Returns sale agent monthly bill nacha file to view
        /// </summary>
        /// <param name="query">Object of GetSaleAgentNachaQuery</param>
        /// <returns>It will return in the form of NachaFileBytesModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SaleAgentBilling_saleagent-view-nacha")]
        [ProducesResponseType(typeof(FileResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("saleagent-view-nacha")]
        public async Task<ActionResult> ViewNachaFile([FromQuery] GetSaleAgentNachaQuery query)
        {
            NachaFileBytesModel response = await mediator.Send(query).ConfigureAwait(false);
            return response != null && response.Bytes != null ? File(response.Bytes, "text/plain", response.File) : NoContent();
        }

        /// <summary>
        /// Returns sale agent monthly bill invoice pdf file by billing id
        /// </summary>
        /// <param name="request">Object of GetSaleAgentMonthlyInvoicePdfQuery</param>
        /// <returns>It will return in the form of InvoiceFileBytesModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SaleAgentBilling_saleagent-monthly-invoice-pdf")]
        [ProducesResponseType(typeof(FileResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("saleagent-monthly-invoice-pdf")]
        public async Task<ActionResult> SaleAgentMonthlyInvoicePdf([FromQuery] GetSaleAgentMonthlyInvoicePdfQuery request)
        {
            InvoiceFileBytesModel response = await mediator.Send(request).ConfigureAwait(false);
            return response != null && response.Bytes != null ? File(response.Bytes, "application/pdf", response.File) : NoContent();
        }

        /// <summary>
        /// Returns all sale agents monthly bill invoice pdf file by month and year
        /// </summary>
        /// <param name="request">Object of GetAllSaleAgentMonthlyInvoicePdfQuery</param>
        /// <returns>It will return in the form of InvoiceFileBytesModel</returns>
        [ApiPermissionAuthorize(Permissions = "Transactionapi_SaleAgentBilling_saleagent-all-monthly-invoice-pdf")]
        [ProducesResponseType(typeof(FileResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("saleagent-all-monthly-invoice-pdf")]
        public async Task<ActionResult> AllSaleAgentMonthlyInvoicePdf([FromQuery] GetAllSaleAgentMonthlyInvoicePdfQuery request)
        {
            InvoiceFileBytesModel response = await mediator.Send(request).ConfigureAwait(false);
            return response != null && response.Bytes != null ? File(response.Bytes, "application/pdf", response.File) : NoContent();
        }
    }
}
