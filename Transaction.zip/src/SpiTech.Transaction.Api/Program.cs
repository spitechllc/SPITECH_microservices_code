using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using SpiTech.Application.Logging;
using SpiTech.Application.Logging.Extensions;
using System;

namespace SpiTech.Transaction.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            LoggerExtensions.InitializeLogger();
            Logger.Information("Transaction API starting");
            try
            {
                CreateHostBuilder(args).Build().Run();
                Logger.Information($"Transaction Application started in environment: {Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")}");
            }
            catch (Exception e)
            {
                Logger.Error("Transaction API Host terminated unexpected", e);
                throw;
            }
            finally
            {
                Logger.Information("Transaction API stopped");
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            return Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseLogger();
                    webBuilder.UseStartup<Startup>();
                });
        }
    }
}

