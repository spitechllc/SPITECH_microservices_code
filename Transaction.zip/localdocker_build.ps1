echo "################################################DotNet Build########################################################"

#dotnet build

echo "##############################################DotNet Publish########################################################"

dotnet publish /p:Configuration=Release /p:EnvironmentName=Production  ./src/SpiTech.Transaction.Api/SpiTech.Transaction.Api.csproj

CD src/SpiTech.Transaction.Api/bin/Release/net5.0/publish/
del appsettings.Development.json
del appsettings.json
Rename-Item "appsettings.json.docker" "appsettings.json"
cd ..
cd ..
cd ..
cd ..
cd ..
cd ..
echo "##############################################Remove Container########################################################"
docker rm -f SpiTechtransactionapi

echo "##############################################Remove Image########################################################"

docker rmi -f SpiTechtransactionapi:debug

echo "################################################Docker Build########################################################"

docker build  -t SpiTechtransactionapi:debug -f ./localdockerfile .

echo "##################################################Docker Tag########################################################"

#docker tag SpiTech/transaction SpiTechregistry00.azurecr.io/SpiTech/transaction
echo "successfully tagged the image "

echo "#################################################Docker Push########################################################"

#docker push SpiTechregistry00.azurecr.io/SpiTech/transaction

docker run -it -p 9050:80 --name SpiTechtransactionapi SpiTechtransactionapi:debug

pause