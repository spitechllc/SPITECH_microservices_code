Drop TABLE [dbo].[SaleAgentBillingPaymentDetail];
GO
Drop TABLE [dbo].[SaleAgentBillingPayment];
GO
Drop TABLE [dbo].[SaleAgentBillingDetail];
GO
Drop TABLE [dbo].SaleAgentFee;
GO
CREATE TABLE [dbo].[PaymentStatus]
(
	  [PaymentStatusId] INT NOT NULL
	, [Name] NVARCHAR(50) NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_PaymentStatus] PRIMARY KEY ([PaymentStatusId] ASC)
)

GO

CREATE TABLE [dbo].[SaleAgentFee]
(
	  [SaleAgentFeeId] INT NOT NULL IDENTITY(1,1)
	, [SaleAgentId] INT NULL
	, [StoreId] INT NULL
	, [TransactionPercentageFee] DECIMAL(18,2) NOT NULL
	, [MonthlySaasFee] DECIMAL(18,2) NOT NULL
	, [IsDefault] BIT NOT NULL DEFAULT((0))
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_SaleAgentFee] PRIMARY KEY ([SaleAgentFeeId] ASC)
)
GO
CREATE TABLE [dbo].[SaleAgentBilling]
(
	  [SaleAgentBillingId] INT NOT NULL IDENTITY(1,1)
	, [StoreId] INT NOT NULL
	, [StoreName] VARCHAR(200) NULL
	, [SiteId] NVARCHAR(20) NOT NULL
	, [SaleAgentId] INT NOT NULL	
	, [InvoiceNumber] NVARCHAR(25) NOT NULL
	, [Month] INT NOT NULL
	, [Year] INT NOT NULL
	, [TransactionCount] INT NOT NULL
	, [TransactionAmount] DECIMAL(18,2) NOT NULL
	, [DefineTransactionPercentageFee] DECIMAL(18,2) NOT NULL
	, [DefineMonthlySaasFee] DECIMAL(18,2) NOT NULL
	, [TransactionPercentageFee] DECIMAL(18,2) NOT NULL
	, [TotalFee] DECIMAL(18,2) NOT NULL
	, [NeedReview] BIT NOT NULL DEFAULT((0))
	, [IsPaid] BIT NOT NULL DEFAULT((0))
    , [InvoiceFileName] NVARCHAR(100) NULL
    , [InvoiceFilePath] NVARCHAR(200) NULL
    , [ProcessStatus] NVARCHAR(1) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_SaleAgentBilling] PRIMARY KEY ([SaleAgentBillingId] ASC)
)
GO

CREATE TABLE [dbo].[SaleAgentBillingPayment]
(
	  [SaleAgentBillingPaymentId] INT NOT NULL IDENTITY(1,1)
	, [Month] INT NOT NULL
	, [Year] INT NOT NULL
	, [BillGenerateBy] INT NULL
	, [BillGenerateDate] DATETIME NULL
	, [TotalAmount] DECIMAL(18,2) NULL
	, [AccountName] NVARCHAR(22) NULL
	, [Bank] NVARCHAR(23) NULL
	, [AccountNo] NVARCHAR(17) NULL
	, [RoutingNo] NVARCHAR(9) NULL
	, [IsChecking] BIT NOT NULL
	, [NachaFilePath] NVARCHAR(2000) NULL
	, [NachaFileName] NVARCHAR(200) NULL
	, [IsNachaUploaded] BIT NOT NULL DEFAULT((0))
	, [NachaUploadError] NVARCHAR(max) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_SaleAgentBillingPayment] PRIMARY KEY ([SaleAgentBillingPaymentId] ASC)
)

GO

CREATE TABLE [dbo].[SaleAgentBillingPaymentDetail]
(
	  [SaleAgentBillingPaymentDetailId] INT NOT NULL IDENTITY(1,1)
	, [SaleAgentBillingPaymentId] INT NOT NULL
	, [SaleAgentBillingId] INT NOT NULL
	, [StoreId] INT NOT NULL
	, [SaleAgentId] INT NOT NULL
	, [Amount] DECIMAL(18,2) NOT NULL
	, [AccountName] NVARCHAR(22) NULL
	, [AccountNo] NVARCHAR(17) NULL
	, [RoutingNo] NVARCHAR(9) NULL
	, [IdentificationNumber] NVARCHAR(25) NULL
	, [IsChecking] BIT NOT NULL
	, [MarkUnPaid] BIT NOT NULL DEFAULT((0))
	, [Reason] NVARCHAR(500) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_SaleAgentBillingPaymentDetail] PRIMARY KEY ([SaleAgentBillingPaymentDetailId] ASC)
)
ALTER TABLE [dbo].[SaleAgentBillingPaymentDetail] ADD
  CONSTRAINT [FK_SaleAgentBillingPaymentDetail_SaleAgentBillingPayment] FOREIGN KEY([SaleAgentBillingPaymentId]) REFERENCES [dbo].[SaleAgentBillingPayment]([SaleAgentBillingPaymentId]);
  
ALTER TABLE [dbo].[SaleAgentBillingPaymentDetail] ADD
  CONSTRAINT [FK_SaleAgentBillingPaymentDetail_SaleAgentBilling] FOREIGN KEY([SaleAgentBillingId]) REFERENCES [dbo].[SaleAgentBilling]([SaleAgentBillingId]);

GO

CREATE TABLE [dbo].[ResellerFee]
(
	  [ResellerFeeId] INT NOT NULL IDENTITY(1,1)
	, [ResellerId] INT NULL
	, [MinStoreRange] INT NOT NULL
	, [MaxStoreRange] INT NOT NULL
	, [ACHTransactionFee] DECIMAL(18,2) NOT NULL
	, [CardTransactionFee] DECIMAL(18,2) NOT NULL
	, [CashRewardTransactionFee] DECIMAL(18,2) NOT NULL
	, [ACHProcessingFee] DECIMAL(18,2) NOT NULL
	, [MonthlySaasFee] DECIMAL(18,2) NOT NULL
	, [CoreProcessingName] NVARCHAR(2) NOT NULL
	, [IsDefault] BIT NOT NULL DEFAULT((0))
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_ResellerFee] PRIMARY KEY ([ResellerFeeId] ASC)
)


GO
CREATE TABLE [dbo].[ResellerBilling]
(
	  [ResellerBillingId] INT NOT NULL IDENTITY(1,1)
	, [ResellerId] INT NOT NULL
	, [ResellerName] NVARCHAR(200) NOT NULL	
	, [InvoiceNumber] NVARCHAR(25) NOT NULL
	, [Month] INT NOT NULL
	, [Year] INT NOT NULL	
	, [StoreCount] INT NOT NULL
	, [TransactionCount] INT NOT NULL
	, [TransactionAmount] DECIMAL(18,2) NOT NULL
	, [ACHTransactionAmount] DECIMAL(18,2) NOT NULL
	, [CardTransactionAmount] DECIMAL(18,2) NOT NULL
	, [CashRewardTransactionAmount] DECIMAL(18,2) NOT NULL
	, [DefineMinStoreRange] INT NOT NULL
	, [DefineMaxStoreRange] INT NOT NULL
	, [DefineACHTransactionFee] DECIMAL(18,2) NOT NULL
	, [DefineCardTransactionFee] DECIMAL(18,2) NOT NULL
	, [DefineCashRewardTransactionFee] DECIMAL(18,2) NOT NULL
	, [DefineACHProcessingFee] DECIMAL(18,2) NOT NULL
	, [DefineMonthlySaasFee] DECIMAL(18,2) NOT NULL
	, [DefineCoreProcessingName] NVARCHAR(2) NOT NULL
	, [ACHTransactionFee] DECIMAL(18,2) NOT NULL
	, [CardTransactionFee] DECIMAL(18,2) NOT NULL
	, [CashRewardTransactionFee] DECIMAL(18,2) NOT NULL
	, [ACHProcessingFee] DECIMAL(18,2) NOT NULL
	, [TotalFee] DECIMAL(18,2) NOT NULL
	, [NeedReview] BIT NOT NULL DEFAULT((0))
	, [IsPaid] BIT NOT NULL DEFAULT((0))
    , [InvoiceFileName] NVARCHAR(100) NULL
    , [InvoiceFilePath] NVARCHAR(200) NULL
    , [ProcessStatus] NVARCHAR(1) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_ResellerBilling] PRIMARY KEY ([ResellerBillingId] ASC)
)

GO

CREATE TABLE [dbo].[ResellerBillingPayment]
(
	  [ResellerBillingPaymentId] INT NOT NULL IDENTITY(1,1)
	, [Month] INT NOT NULL
	, [Year] INT NOT NULL
	, [BillGenerateBy] INT NULL
	, [BillGenerateDate] DATETIME NULL
	, [TotalAmount] DECIMAL(18,2) NULL
	, [AccountName] NVARCHAR(22) NULL
	, [Bank] NVARCHAR(23) NULL
	, [AccountNo] NVARCHAR(17) NULL
	, [RoutingNo] NVARCHAR(9) NULL
	, [IsChecking] BIT NOT NULL
	, [NachaFilePath] NVARCHAR(2000) NULL
	, [NachaFileName] NVARCHAR(200) NULL
	, [IsNachaUploaded] BIT NOT NULL DEFAULT((0))
	, [NachaUploadError] NVARCHAR(max) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_ResellerBillingPayment] PRIMARY KEY ([ResellerBillingPaymentId] ASC)
)

GO

CREATE TABLE [dbo].[ResellerBillingPaymentDetail]
(
	  [ResellerBillingPaymentDetailId] INT NOT NULL IDENTITY(1,1)
	, [ResellerBillingPaymentId] INT NOT NULL
	, [ResellerBillingId] INT NOT NULL
	, [ResellerId] INT NOT NULL
	, [Amount] DECIMAL(18,2) NOT NULL
	, [AccountName] NVARCHAR(22) NULL
	, [AccountNo] NVARCHAR(17) NULL
	, [RoutingNo] NVARCHAR(9) NULL
	, [IdentificationNumber] NVARCHAR(25) NULL
	, [IsChecking] BIT NOT NULL
	, [MarkUnPaid] BIT NOT NULL DEFAULT((0))
	, [Reason] NVARCHAR(500) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_ResellerBillingPaymentDetail] PRIMARY KEY ([ResellerBillingPaymentDetailId] ASC)
)
ALTER TABLE [dbo].[ResellerBillingPaymentDetail] ADD
  CONSTRAINT [FK_ResellerBillingPaymentDetail_ResellerBillingPayment] FOREIGN KEY([ResellerBillingPaymentId]) REFERENCES [dbo].[ResellerBillingPayment]([ResellerBillingPaymentId]);

ALTER TABLE [dbo].[ResellerBillingPaymentDetail] ADD
  CONSTRAINT [FK_ResellerBillingPaymentDetail_ResellerBilling] FOREIGN KEY([ResellerBillingId]) REFERENCES [dbo].[ResellerBilling]([ResellerBillingId]);


GO
GO

INSERT INTO [PaymentStatus](PaymentStatusId, Name)
VALUES 
(0, 'NotPaid'),
(1, 'Paid'),
(3, 'MarkAsPaid');
GO



Alter Table [dbo].[Transaction] ADD 
	  [DisableEod] BIT NOT NULL DEFAULT((0))
	, [DisableBilling] BIT NOT NULL DEFAULT((0))
	, [StacCaptureType] NVARCHAR(1) NULL
	, [SaleAgentBillingId] INT NULL
	, [ResellerBillingId] INT NULL;

GO


Alter Table [dbo].[SettlementRequest] ADD 
	  [EodCashRewardAmount] DECIMAL(18,2) NULL
	, [EodAchAmount] DECIMAL(18,2) NULL
	, [EodCardAmount] DECIMAL(18,2) NULL
	, [AchPaymentStatusId] Int NOT NULL DEFAULT((0))
	, [CardPaymentStatusId] Int NOT NULL DEFAULT((0))
	, [CashRewardPaymentStatusId] Int NOT NULL DEFAULT((0));

GO

update	[SettlementRequest] set EodCashRewardAmount=CashRewardAmount,EodAchAmount=AchAmount,EodCardAmount=CardAmount,ProcessStatus='C';

GO
----------------------------------13/03/2023--------------------------------
Alter Table [dbo].[ResellerBillingPayment] ADD 
	  [OffsetNachaFilePath] NVARCHAR(2000) NULL
	, [OffsetNachaFileName] NVARCHAR(200) NULL
	, [IsOffsetNachaUploaded] BIT NOT NULL CONSTRAINT DF_ResellerBillingPayment_IsNachaUploaded DEFAULT((0))
	, [OffsetNachaUploadError] NVARCHAR(max) NULL
	, [SftpConfig] NVARCHAR(100) NULL;

GO

Alter Table [dbo].[SaleAgentBillingPayment] ADD 
	  [OffsetNachaFilePath] NVARCHAR(2000) NULL
	, [OffsetNachaFileName] NVARCHAR(200) NULL
	, [IsOffsetNachaUploaded] BIT NOT NULL CONSTRAINT DF_SaleAgentBillingPayment_IsNachaUploaded DEFAULT((0))
	, [OffsetNachaUploadError] NVARCHAR(max) NULL
	, [SftpConfig] NVARCHAR(100) NULL;

GO

Alter Table [dbo].[SettlementPayment] ADD 
	  [SettlementRequestId] INT NULL
	, [TotalAchAmount] DECIMAL(18,2) NULL
	, [IdentificationNumber] NVARCHAR(25) NULL
	, [OffsetNachaFilePath] NVARCHAR(2000) NULL
	, [OffsetNachaFileName] NVARCHAR(200) NULL
	, [IsOffsetNachaUploaded] BIT NOT NULL CONSTRAINT DF_SettlementPayment_IsNachaUploaded DEFAULT((0))
	, [OffsetNachaUploadError] NVARCHAR(max) NULL
	, [SftpConfig] NVARCHAR(100) NULL;

GO

Alter Table [dbo].[SettlementPaymentDetail] ADD  [TransactionId] INT NULL;
GO

Update SettlementPaymentDetail set TransactionId = 0;

GO

Alter Table [dbo].[SettlementPaymentDetail] Alter COLUMN  [TransactionId] INT Not NULL;

GO

Alter Table [dbo].[StoreBillingPayment] ADD 
	  [OffsetNachaFilePath] NVARCHAR(2000) NULL
	, [OffsetNachaFileName] NVARCHAR(200) NULL
	, [IsOffsetNachaUploaded] BIT NOT NULL CONSTRAINT DF_StoreBillingPayment_IsNachaUploaded DEFAULT((0))
	, [OffsetNachaUploadError] NVARCHAR(max) NULL
	, [SftpConfig] NVARCHAR(100) NULL;

GO


CREATE TABLE [dbo].[StoreSettlementConfig]
(
	  [StoreSettlementConfigId] INT NOT NULL IDENTITY(1,1)
	, [StoreId] INT NULL
	, [EnableACH] BIT NOT NULL CONSTRAINT DF_StoreBillingFee_EnableACH DEFAULT((0))
	, [EnableCard] BIT NOT NULL CONSTRAINT DF_StoreBillingFee_EnableCard DEFAULT((0))
	, [EnableCashReward] BIT NOT NULL CONSTRAINT DF_StoreBillingFee_EnableCashReward DEFAULT((0))
	, [IsDefault] BIT NOT NULL CONSTRAINT DF_StoreBillingFee_IsDefault DEFAULT((0))
	, [IsActive] BIT NOT NULL CONSTRAINT DF_StoreBillingFee_IsActive DEFAULT((1))
	, [CreatedOn] DATETIME NULL CONSTRAINT DF_StoreBillingFee_CreatedOn DEFAULT(getutcdate())
	, [CreatedBy] NVARCHAR(256) NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] NVARCHAR(256) NULL
	, CONSTRAINT [PK_StoreSettlementConfig] PRIMARY KEY ([StoreSettlementConfigId] ASC)
)



GO

Insert Into StoreSettlementConfig(StoreId,EnableACH,EnableCard,EnableCashReward,IsDefault,IsActive,CreatedOn) 
Values(null,0,0,1,1,1,GetUtcdate());

GO
----------------------------------------------------------------------------
--27 Oct 2023
----------------------------------------------------------------------------

alter table [Transaction]
add AchPaymentStatusId int DEFAULT 0

alter table [Transaction]
add CardPaymentStatusId int NOT NULL DEFAULT 0

alter table [Transaction]
add CashRewardPaymentStatusId int NOT NULL DEFAULT 0


alter table [Transaction]
add MerchantProcess BIT DEFAULT 0

alter table [Transaction]
add ConsumerProcess BIT DEFAULT 0

EXEC sp_RENAME '[Transaction].MerchantProcess' , 'MerchantPay', 'COLUMN'

EXEC sp_RENAME '[Transaction].ConsumerProcess' , 'ConsumerPay', 'COLUMN'

ALTER TABLE [Transaction]
ADD MerchantPaid INT DEFAULT 0;

ALTER TABLE [Transaction]
ADD ConsumerPaid INT DEFAULT 0;