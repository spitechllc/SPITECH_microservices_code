CREATE TABLE [dbo].[Status]
(
	  [StatusId] INT NOT NULL
	, [Name] NVARCHAR(50) NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Status] PRIMARY KEY ([StatusId] ASC)
)

GO

CREATE TABLE [dbo].[PaymentStatus]
(
	  [PaymentStatusId] INT NOT NULL
	, [Name] NVARCHAR(50) NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_PaymentStatus] PRIMARY KEY ([PaymentStatusId] ASC)
)

GO


CREATE TABLE [dbo].[AmountType]
(
	  [AmountTypeId] INT NOT NULL
	, [Name] NVARCHAR(50) NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_AmountType] PRIMARY KEY ([AmountTypeId] ASC)
)


GO
CREATE TABLE [dbo].[NachaConfig]
(
	  [NachaConfigId] INT NOT NULL
	, [AccountName] [varchar](22) NOT NULL
	, [Bank] [varchar](23) NULL
	, [AccountNo] [varchar](17) NULL
	, [RoutingNo] [varchar](9) NULL
	, [ReceivingBankRoutingNo] [varchar](9) NULL
	, [IsProdEnabled] BIT NOT NULL DEFAULT((0))
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_NachaConfig] PRIMARY KEY ([NachaConfigId] ASC)
)

GO

CREATE TABLE [dbo].[Site]
(
	  [SiteId] NVARCHAR(20) NOT NULL
	, [SiteName] NVARCHAR(200) NULL
	, [StoreId] INT NULL
	, [StoreName] VARCHAR(50) NULL
	, [SiteMPPAIdentifier] NVARCHAR(20) NULL
	, [MerchantId] NVARCHAR(20) NULL
	, [LocationId] NVARCHAR(50) NULL
	, [SiteMobileActive] BIT NULL
	, [SiteAddress] NVARCHAR(500) NULL
	, [SettlementEmployee] NVARCHAR(50) NULL
	, [PartialAuthAllowed] BIT NULL
	, [PumpTimeout] INT NULL
	, [CurrentHeartBeatTime] DATETIME NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Site] PRIMARY KEY ([SiteId] ASC)
)

GO


CREATE TABLE [dbo].[StoreBillingFee]
(
	  [StoreBillingFeeId] INT NOT NULL IDENTITY(1,1)
	, [StoreId] INT NOT NULL
	, [SiteId] NVARCHAR(20) NOT NULL
	, [PaymentMethodId] INT NOT NULL
	, [MinTransactionRange] INT NOT NULL
	, [MaxTransactionRange] INT NOT NULL
	, [TransactionFee] DECIMAL(18,2) NOT NULL
	, [TransactionPercentageFee] DECIMAL(18,2) NOT NULL
	, [MonthlySaasFee] DECIMAL(18,2) NOT NULL
	, [IsDefault] BIT NOT NULL DEFAULT((0))
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_StoreBillingFee] PRIMARY KEY ([StoreBillingFeeId] ASC)
)


GO
CREATE TABLE [dbo].[StoreBilling]
(
	  [StoreBillingId] INT NOT NULL IDENTITY(1,1)
	, [GroupBillingIdentifier] NVARCHAR(25) NOT NULL
	, [BillingNumber] NVARCHAR(25) NOT NULL
	, [StoreId] INT NOT NULL
	, [StoreName] VARCHAR(200) NULL
	, [SiteId] NVARCHAR(20) NOT NULL
	, [Month] INT NOT NULL
	, [Year] INT NOT NULL
	, [TransactionCount] INT NOT NULL
	, [TransactionAmount] DECIMAL(18,2) NOT NULL
	, [TransactionFee] DECIMAL(18,2) NOT NULL
	, [TransactionPercentageFee] DECIMAL(18,2) NOT NULL
	, [MonthlySaasFee] DECIMAL(18,2) NOT NULL
	, [TotalFee] DECIMAL(18,2) NOT NULL
	, [BillGenerateBy] INT NULL
	, [BillGenerateDate] DATETIME NULL
	, [NeedReview] BIT NOT NULL DEFAULT((0))
	, [IsPaid] BIT NOT NULL DEFAULT((0))
    , [InvoiceFileName] NVARCHAR(100) NULL
    , [InvoiceFilePath] NVARCHAR(200) NULL
    , [ProcessStatus] NVARCHAR(1) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_StoreBilling] PRIMARY KEY ([StoreBillingId] ASC)
)


GO
CREATE TABLE [dbo].[StoreBillingDetail]
(
	  [StoreBillingDetailId] INT NOT NULL IDENTITY(1,1)
	, [StoreBillingId] INT NOT NULL
	, [PaymentMethodId] INT NOT NULL
	, [MinTransactionRange] INT NULL
	, [MaxTransactionRange] INT NULL
	, [DefineTransactionFee] DECIMAL(18,2) NOT NULL
	, [DefineTransactionPercentageFee] DECIMAL(18,2) NOT NULL
	, [DefineMonthlySaasFee] DECIMAL(18,2) NOT NULL
	, [TransactionCount] INT NOT NULL
	, [TransactionAmount] DECIMAL(18,2) NOT NULL
	, [TransactionFee] DECIMAL(18,2) NOT NULL
	, [TransactionPercentageFee] DECIMAL(18,2) NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_StoreBillingDetail] PRIMARY KEY ([StoreBillingDetailId] ASC)
)
ALTER TABLE [dbo].[StoreBillingDetail] ADD
  CONSTRAINT [FK_StoreBillingDetail_StoreBilling] FOREIGN KEY([StoreBillingId]) REFERENCES [dbo].[StoreBilling]([StoreBillingId]);

GO

CREATE TABLE [dbo].[StoreBillingPayment]
(
	  [StoreBillingPaymentId] INT NOT NULL IDENTITY(1,1)
	, [Month] INT NOT NULL
	, [Year] INT NOT NULL
	, [BillGenerateBy] INT NULL
	, [BillGenerateDate] DATETIME NULL
	, [TotalAmount] DECIMAL(18,2) NULL
	, [AccountName] NVARCHAR(22) NULL
	, [Bank] NVARCHAR(23) NULL
	, [AccountNo] NVARCHAR(17) NULL
	, [RoutingNo] NVARCHAR(9) NULL
	, [IsChecking] BIT NOT NULL
	, [NachaFilePath] NVARCHAR(2000) NULL
	, [NachaFileName] NVARCHAR(200) NULL
	, [IsNachaUploaded] BIT NOT NULL DEFAULT((0))
	, [NachaUploadError] NVARCHAR(max) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_StoreBillingPayment] PRIMARY KEY ([StoreBillingPaymentId] ASC)
)

GO

CREATE TABLE [dbo].[StoreBillingPaymentDetail]
(
	  [StoreBillingPaymentDetailId] INT NOT NULL IDENTITY(1,1)
	, [StoreBillingPaymentId] INT NOT NULL
	, [StoreBillingId] INT NOT NULL
	, [StoreId] INT NOT NULL
	, [Amount] DECIMAL(18,2) NOT NULL
	, [AccountName] NVARCHAR(22) NULL
	, [AccountNo] NVARCHAR(17) NULL
	, [RoutingNo] NVARCHAR(9) NULL
	, [IdentificationNumber] NVARCHAR(25) NULL
	, [IsChecking] BIT NOT NULL
	, [MarkUnPaid] BIT NOT NULL DEFAULT((0))
	, [Reason] NVARCHAR(500) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_StoreBillingPaymentDetail] PRIMARY KEY ([StoreBillingPaymentDetailId] ASC)
)
ALTER TABLE [dbo].[StoreBillingPaymentDetail] ADD
  CONSTRAINT [FK_StoreBillingPaymentDetail_StoreBillingPayment] FOREIGN KEY([StoreBillingPaymentId]) REFERENCES [dbo].[StoreBillingPayment]([StoreBillingPaymentId]);

ALTER TABLE [dbo].[StoreBillingPaymentDetail] ADD
  CONSTRAINT [FK_StoreBillingPaymentDetail_StoreBilling] FOREIGN KEY([StoreBillingId]) REFERENCES [dbo].[StoreBilling]([StoreBillingId]);


GO

CREATE TABLE [dbo].[SaleAgentFee]
(
	  [SaleAgentFeeId] INT NOT NULL IDENTITY(1,1)
	, [SaleAgentId] INT NULL
	, [StoreId] INT NULL
	, [TransactionPercentageFee] DECIMAL(18,2) NOT NULL
	, [MonthlySaasFee] DECIMAL(18,2) NOT NULL
	, [IsDefault] BIT NOT NULL DEFAULT((0))
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_SaleAgentFee] PRIMARY KEY ([SaleAgentFeeId] ASC)
)


CREATE TABLE [dbo].[SaleAgentBilling]
(
	  [SaleAgentBillingId] INT NOT NULL IDENTITY(1,1)
	, [StoreId] INT NOT NULL
	, [StoreName] VARCHAR(200) NULL
	, [SiteId] NVARCHAR(20) NOT NULL
	, [SaleAgentId] INT NOT NULL	
	, [InvoiceNumber] NVARCHAR(25) NOT NULL
	, [Month] INT NOT NULL
	, [Year] INT NOT NULL
	, [TransactionCount] INT NOT NULL
	, [TransactionAmount] DECIMAL(18,2) NOT NULL
	, [DefineTransactionPercentageFee] DECIMAL(18,2) NOT NULL
	, [DefineMonthlySaasFee] DECIMAL(18,2) NOT NULL
	, [TransactionPercentageFee] DECIMAL(18,2) NOT NULL
	, [TotalFee] DECIMAL(18,2) NOT NULL
	, [NeedReview] BIT NOT NULL DEFAULT((0))
	, [IsPaid] BIT NOT NULL DEFAULT((0))
    , [InvoiceFileName] NVARCHAR(100) NULL
    , [InvoiceFilePath] NVARCHAR(200) NULL
    , [ProcessStatus] NVARCHAR(1) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_SaleAgentBilling] PRIMARY KEY ([SaleAgentBillingId] ASC)
)
GO

CREATE TABLE [dbo].[SaleAgentBillingPayment]
(
	  [SaleAgentBillingPaymentId] INT NOT NULL IDENTITY(1,1)
	, [Month] INT NOT NULL
	, [Year] INT NOT NULL
	, [BillGenerateBy] INT NULL
	, [BillGenerateDate] DATETIME NULL
	, [TotalAmount] DECIMAL(18,2) NULL
	, [AccountName] NVARCHAR(22) NULL
	, [Bank] NVARCHAR(23) NULL
	, [AccountNo] NVARCHAR(17) NULL
	, [RoutingNo] NVARCHAR(9) NULL
	, [IsChecking] BIT NOT NULL
	, [NachaFilePath] NVARCHAR(2000) NULL
	, [NachaFileName] NVARCHAR(200) NULL
	, [IsNachaUploaded] BIT NOT NULL DEFAULT((0))
	, [NachaUploadError] NVARCHAR(max) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_SaleAgentBillingPayment] PRIMARY KEY ([SaleAgentBillingPaymentId] ASC)
)

GO

CREATE TABLE [dbo].[SaleAgentBillingPaymentDetail]
(
	  [SaleAgentBillingPaymentDetailId] INT NOT NULL IDENTITY(1,1)
	, [SaleAgentBillingPaymentId] INT NOT NULL
	, [SaleAgentBillingId] INT NOT NULL
	, [StoreId] INT NOT NULL
	, [SaleAgentId] INT NOT NULL
	, [Amount] DECIMAL(18,2) NOT NULL
	, [AccountName] NVARCHAR(22) NULL
	, [AccountNo] NVARCHAR(17) NULL
	, [RoutingNo] NVARCHAR(9) NULL
	, [IdentificationNumber] NVARCHAR(25) NULL
	, [IsChecking] BIT NOT NULL
	, [MarkUnPaid] BIT NOT NULL DEFAULT((0))
	, [Reason] NVARCHAR(500) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_SaleAgentBillingPaymentDetail] PRIMARY KEY ([SaleAgentBillingPaymentDetailId] ASC)
)
ALTER TABLE [dbo].[SaleAgentBillingPaymentDetail] ADD
  CONSTRAINT [FK_SaleAgentBillingPaymentDetail_SaleAgentBillingPayment] FOREIGN KEY([SaleAgentBillingPaymentId]) REFERENCES [dbo].[SaleAgentBillingPayment]([SaleAgentBillingPaymentId]);
  
ALTER TABLE [dbo].[SaleAgentBillingPaymentDetail] ADD
  CONSTRAINT [FK_SaleAgentBillingPaymentDetail_SaleAgentBilling] FOREIGN KEY([SaleAgentBillingId]) REFERENCES [dbo].[SaleAgentBilling]([SaleAgentBillingId]);

GO

CREATE TABLE [dbo].[ResellerFee]
(
	  [ResellerFeeId] INT NOT NULL IDENTITY(1,1)
	, [ResellerId] INT NULL
	, [MinStoreRange] INT NOT NULL
	, [MaxStoreRange] INT NOT NULL
	, [ACHTransactionFee] DECIMAL(18,2) NOT NULL
	, [CardTransactionFee] DECIMAL(18,2) NOT NULL
	, [CashRewardTransactionFee] DECIMAL(18,2) NOT NULL
	, [ACHProcessingFee] DECIMAL(18,2) NOT NULL
	, [MonthlySaasFee] DECIMAL(18,2) NOT NULL
	, [CoreProcessingName] NVARCHAR(2) NOT NULL
	, [IsDefault] BIT NOT NULL DEFAULT((0))
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_ResellerFee] PRIMARY KEY ([ResellerFeeId] ASC)
)


GO
CREATE TABLE [dbo].[ResellerBilling]
(
	  [ResellerBillingId] INT NOT NULL IDENTITY(1,1)
	, [ResellerId] INT NOT NULL
	, [ResellerName] NVARCHAR(200) NOT NULL	
	, [InvoiceNumber] NVARCHAR(25) NOT NULL
	, [Month] INT NOT NULL
	, [Year] INT NOT NULL	
	, [StoreCount] INT NOT NULL
	, [TransactionCount] INT NOT NULL
	, [TransactionAmount] DECIMAL(18,2) NOT NULL
	, [ACHTransactionAmount] DECIMAL(18,2) NOT NULL
	, [CardTransactionAmount] DECIMAL(18,2) NOT NULL
	, [CashRewardTransactionAmount] DECIMAL(18,2) NOT NULL
	, [DefineMinStoreRange] INT NOT NULL
	, [DefineMaxStoreRange] INT NOT NULL
	, [DefineACHTransactionFee] DECIMAL(18,2) NOT NULL
	, [DefineCardTransactionFee] DECIMAL(18,2) NOT NULL
	, [DefineCashRewardTransactionFee] DECIMAL(18,2) NOT NULL
	, [DefineACHProcessingFee] DECIMAL(18,2) NOT NULL
	, [DefineMonthlySaasFee] DECIMAL(18,2) NOT NULL
	, [DefineCoreProcessingName] NVARCHAR(2) NOT NULL
	, [ACHTransactionFee] DECIMAL(18,2) NOT NULL
	, [CardTransactionFee] DECIMAL(18,2) NOT NULL
	, [CashRewardTransactionFee] DECIMAL(18,2) NOT NULL
	, [ACHProcessingFee] DECIMAL(18,2) NOT NULL
	, [TotalFee] DECIMAL(18,2) NOT NULL
	, [NeedReview] BIT NOT NULL DEFAULT((0))
	, [IsPaid] BIT NOT NULL DEFAULT((0))
    , [InvoiceFileName] NVARCHAR(100) NULL
    , [InvoiceFilePath] NVARCHAR(200) NULL
    , [ProcessStatus] NVARCHAR(1) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_ResellerBilling] PRIMARY KEY ([ResellerBillingId] ASC)
)

GO

CREATE TABLE [dbo].[ResellerBillingPayment]
(
	  [ResellerBillingPaymentId] INT NOT NULL IDENTITY(1,1)
	, [Month] INT NOT NULL
	, [Year] INT NOT NULL
	, [BillGenerateBy] INT NULL
	, [BillGenerateDate] DATETIME NULL
	, [TotalAmount] DECIMAL(18,2) NULL
	, [AccountName] NVARCHAR(22) NULL
	, [Bank] NVARCHAR(23) NULL
	, [AccountNo] NVARCHAR(17) NULL
	, [RoutingNo] NVARCHAR(9) NULL
	, [IsChecking] BIT NOT NULL
	, [NachaFilePath] NVARCHAR(2000) NULL
	, [NachaFileName] NVARCHAR(200) NULL
	, [IsNachaUploaded] BIT NOT NULL DEFAULT((0))
	, [NachaUploadError] NVARCHAR(max) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_ResellerBillingPayment] PRIMARY KEY ([ResellerBillingPaymentId] ASC)
)

GO

CREATE TABLE [dbo].[ResellerBillingPaymentDetail]
(
	  [ResellerBillingPaymentDetailId] INT NOT NULL IDENTITY(1,1)
	, [ResellerBillingPaymentId] INT NOT NULL
	, [ResellerBillingId] INT NOT NULL
	, [ResellerId] INT NOT NULL
	, [Amount] DECIMAL(18,2) NOT NULL
	, [AccountName] NVARCHAR(22) NULL
	, [AccountNo] NVARCHAR(17) NULL
	, [RoutingNo] NVARCHAR(9) NULL
	, [IdentificationNumber] NVARCHAR(25) NULL
	, [IsChecking] BIT NOT NULL
	, [MarkUnPaid] BIT NOT NULL DEFAULT((0))
	, [Reason] NVARCHAR(500) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_ResellerBillingPaymentDetail] PRIMARY KEY ([ResellerBillingPaymentDetailId] ASC)
)
ALTER TABLE [dbo].[ResellerBillingPaymentDetail] ADD
  CONSTRAINT [FK_ResellerBillingPaymentDetail_ResellerBillingPayment] FOREIGN KEY([ResellerBillingPaymentId]) REFERENCES [dbo].[ResellerBillingPayment]([ResellerBillingPaymentId]);

ALTER TABLE [dbo].[ResellerBillingPaymentDetail] ADD
  CONSTRAINT [FK_ResellerBillingPaymentDetail_ResellerBilling] FOREIGN KEY([ResellerBillingId]) REFERENCES [dbo].[ResellerBilling]([ResellerBillingId]);


GO

CREATE TABLE [dbo].[Transaction]
(
	  [TransactionId] BIGINT NOT NULL
	, [UMTI] NVARCHAR(50) NOT NULL
	, [SiteId] NVARCHAR(20) NULL
	, [StoreId] INT NULL
	, [StoreName] VARCHAR(200) NULL
	, [MerchantId] NVARCHAR(20) NULL
	, [UserId] INT NULL
	, [DeviceToken] NVARCHAR(255) NULL
	, [AppType] NVARCHAR(20) NULL
	, [FuelingPositionId] INT NULL
	, [HostMPPAIdentifier] NVARCHAR(20) NULL
	, [SiteMPPAIdentifier] NVARCHAR(20) NULL
	, [POSTransNumber] NVARCHAR(100) NULL
	, [SettlementPeriodId] NVARCHAR(100) NULL
	, [PaymentMethodId] INT NULL
	, [UserPaymentMethodId] INT NULL
	, [PreauthConfirmationNo] VARCHAR(50) NULL
	, [PreauthAmount] DECIMAL(18,2) NULL
	, [PreauthWalletAmount] DECIMAL(18,2) NULL
	, [PreauthCardAmount] DECIMAL(18,2) NULL	
	, [ConsumerIP] VARCHAR(20) NULL
	, [FinalAmount] DECIMAL(18,2) NULL
	, [WalletAmount] DECIMAL(18,2) NULL
	, [CardAmount] DECIMAL(18,2) NULL
	, [IsPaymentSuccess] BIT NULL
	, [StatusId] INT NOT NULL
	, [TransactionTypeId] INT NULL
	, [ReceiptNo] NVARCHAR(100) NULL
	, [PaymentUniqueIdentityfier] NVARCHAR(50) NULL
	, [TransactionInfo] NVARCHAR(1000) NULL
	, [CardType] NVARCHAR(50) NULL
	, [PaymentMethod] NVARCHAR(20) NULL
	, [CardPrint] NVARCHAR(20) NULL
	, [WorkstationId] NVARCHAR(50) NULL
	, [CommanderTimeDateStamp] VARCHAR(50) NULL
	, [TransactionDate] DATETIME NULL
	, [PumpReserveDate] DATETIME NULL
	, [BeginFuelingDate] DATETIME NULL
	, [PreAuthDate] DATETIME NULL
	, [FinalizeDate] DATETIME NULL
	, [ReceiptDate] DATETIME NULL
	, [CancelDate] DATETIME NULL
	, [PaymentId] INT NULL
	, [PaymentErrorMessage] VARCHAR(MAX) NULL
	, [MppaErrorMessage] NVARCHAR(MAX) NULL
	, [HostAuthNumber] NVARCHAR(50) NULL
	, [SettlementRequestId] INT NULL
	, [IsReconciled] BIT NULL
	, [ReconciledDate] DATETIME NULL
	, [StoreBillingId] INT NULL	
	, [DisableEod] BIT NOT NULL DEFAULT((0))
	, [DisableBilling] BIT NOT NULL DEFAULT((0))
	, [StacCaptureType] NVARCHAR(1) NULL
	, [SaleAgentBillingId] INT NULL
	, [ResellerBillingId] INT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Transaction] PRIMARY KEY ([TransactionId] ASC)
)

ALTER TABLE [dbo].[Transaction] ADD
  CONSTRAINT [FK_Transaction_Status] FOREIGN KEY([StatusId]) REFERENCES [dbo].[Status]([StatusId]);


ALTER TABLE [dbo].[Transaction] ADD
  CONSTRAINT [FK_Transaction_StoreBilling] FOREIGN KEY([StoreBillingId]) REFERENCES [dbo].[StoreBilling]([StoreBillingId]);

GO
CREATE TABLE [dbo].[PaymentInfo]
(
	  [PaymentInfoId] BIGINT NOT NULL IDENTITY(1,1)
	, [TransactionId] BIGINT NOT NULL
	, [CardPANPrint] VARCHAR(100) NULL
	, [CardISO] VARCHAR(100) NULL
	, [CardCircuit] VARCHAR(100) NULL
	, [PaymentMethod] VARCHAR(100) NULL
	, [HostAuthNumber] VARCHAR(100) NULL
	, [CardType] VARCHAR(50) NULL
	, [PreAuthAmount] DECIMAL(18,2) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_PaymentInfo] PRIMARY KEY ([PaymentInfoId] ASC)
)

ALTER TABLE [dbo].[PaymentInfo] ADD
  CONSTRAINT [FK_PaymentInfo_Transaction] FOREIGN KEY([TransactionId]) REFERENCES [dbo].[Transaction]([TransactionId]);

GO
CREATE TABLE [dbo].[ReceiptInfoLine]
(
	  [ReceiptInfoLineId] BIGINT NOT NULL IDENTITY(1,1)
	, [TransactionId] BIGINT NOT NULL
	, [ReceiptLine] VARCHAR(MAX) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_ReceiptInfoLine] PRIMARY KEY ([ReceiptInfoLineId] ASC)
)

ALTER TABLE [dbo].[ReceiptInfoLine] ADD
  CONSTRAINT [FK_ReceiptInfoLine_Transaction] FOREIGN KEY([TransactionId]) REFERENCES [dbo].[Transaction]([TransactionId]);


GO
CREATE TABLE [dbo].[SaleItem]
(
	  [SaleItemId] BIGINT NOT NULL IDENTITY(1,1)
	, [TransactionId] BIGINT NOT NULL
	, [ItemId] VARCHAR(20) NULL
	, [EvaluateOnly] BIT NOT NULL DEFAULT((0))
	, [ReverseSale] VARCHAR(100) NULL
	, [ItemStatus] BIT NULL
	, [PriceChangeEligible] BIT NULL
	, [POSCode] VARCHAR(100) NULL
	, [POSCodeModifier] VARCHAR(100) NULL
	, [POSCodeFormat] VARCHAR(100) NULL
	, [ProductCode] VARCHAR(100) NULL
	, [OriginalAmount] DECIMAL(18,3) NULL
	, [OriginalAmountUnitPrice] DECIMAL(18,3) NULL
	, [AdjustedAmount] DECIMAL(18,3) NULL
	, [AdjustedAmountUnitPrice] DECIMAL(18,3) NULL
	, [UnitMeasure] VARCHAR(100) NULL
	, [Quantity] DECIMAL(18,3) NULL
	, [AdditionalProductInfo] VARCHAR(500) NULL
	, [Description] VARCHAR(500) NULL
	, [PriceTier] VARCHAR(100) NULL
	, [RebateLabel] VARCHAR(100) NULL
	, [ServiceLevel] VARCHAR(100) NULL
	, [SellingUnits] VARCHAR(100) NULL
	, [OutdoorPosition] INT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_SaleItem] PRIMARY KEY ([SaleItemId] ASC)
)
ALTER TABLE [dbo].[SaleItem] ADD
  CONSTRAINT [FK_SaleItem_Transaction] FOREIGN KEY([TransactionId]) REFERENCES [dbo].[Transaction]([TransactionId]);

GO
CREATE TABLE [dbo].[PriceAdjustment]
(
	  [PriceAdjustmentId] BIGINT NOT NULL IDENTITY(1,1)
	, [SaleItemId] BIGINT NOT NULL
	, [RewardApplied] BIT NULL
	, [AdjustmentId] VARCHAR(100) NULL
	, [ProgramId] VARCHAR(100) NULL
	, [DoNotRelieveTaxFlag] BIT NULL
	, [PromotionReason] VARCHAR(100) NULL
	, [Amount] DECIMAL(18,3) NULL
	, [UnitPrice] DECIMAL(18,3) NULL
	, [Quantity] DECIMAL(18,3) NULL
	, [RebateLabel] VARCHAR(100) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_PriceAdjustment] PRIMARY KEY ([PriceAdjustmentId] ASC)
)

ALTER TABLE [dbo].[PriceAdjustment] ADD
  CONSTRAINT [FK_PriceAdjustment_SaleItem] FOREIGN KEY([SaleItemId]) REFERENCES [dbo].[SaleItem]([SaleItemId]);

GO

CREATE TABLE [dbo].[SettlementRequest]
(
	  [SettlementRequestId] INT NOT NULL
	, [UMTI] NVARCHAR(50) NOT NULL
	, [SiteId] NVARCHAR(20) NOT NULL
	, [StoreId] INT NULL
	, [StoreName] VARCHAR(200) NULL
	, [MerchantId] NVARCHAR(20) NOT NULL
	, [SiteMPPAIdentifier] NVARCHAR(20) NULL
	, [TimeDateStamp] DATETIME NULL
	, [SettlementPeriodID] NVARCHAR(50) NULL
	, [BusinessDate] DATETIME NULL
	, [TerminalTotalAmount] DECIMAL(18,2) NULL
	, [MppaTotalAmount] DECIMAL(18,2) NULL
	, [TerminalCounts] INT NULL
	, [MppaCounts] INT NULL
	, [SoftwareVersion] NVARCHAR(50) NULL
	, [CashRewardAmount] DECIMAL(18,2) NULL
	, [AchAmount] DECIMAL(18,2) NULL
	, [CardAmount] DECIMAL(18,2) NULL
	, [EodCashRewardAmount] DECIMAL(18,2) NULL
	, [EodAchAmount] DECIMAL(18,2) NULL
	, [EodCardAmount] DECIMAL(18,2) NULL
	, [IsTotalAmountMatched] BIT NOT NULL
	, [IsCountsMatched] BIT NOT NULL
	, [Error] VARCHAR(1000) NULL
	, [IsResponseError] BIT NOT NULL
	, [IsReconciled] BIT NOT NULL
	, [AchPaymentStatusId] Int NOT NULL DEFAULT((0))
	, [CardPaymentStatusId] Int NOT NULL DEFAULT((0))
	, [CashRewardPaymentStatusId] Int NOT NULL DEFAULT((0))
	, [NeedReview] BIT NOT NULL DEFAULT((0))
    , [SettlementFileName] NVARCHAR(100) NULL
    , [SettlementFilePath] NVARCHAR(200) NULL
    , [ProcessStatus] NVARCHAR(1) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_SettlementRequest] PRIMARY KEY ([SettlementRequestId] ASC)
)
ALTER TABLE [dbo].[SettlementRequest] ADD
  CONSTRAINT [FK_SettlementRequest_Site] FOREIGN KEY([SiteId]) REFERENCES [dbo].[Site]([SiteId]) ON UPDATE CASCADE;

GO

CREATE TABLE [dbo].[SettlementDetail]
(
	  [SettlementDetailId] INT NOT NULL 
	, [SettlementRequestId] INT NOT NULL
	, [TypeName] NVARCHAR(50) NULL
	, [GroupName] NVARCHAR(50) NULL
	, [TerminalTotalAmount] DECIMAL(18,2) NULL
	, [MppaTotalAmount] DECIMAL(18,2) NULL
	, [TerminalCounts] INT NULL
	, [MppaCounts] INT NULL
	, [IsTotalAmountMatched] BIT NOT NULL
	, [IsCountsMatched] BIT NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_SettlementDetail] PRIMARY KEY ([SettlementDetailId] ASC)
)
ALTER TABLE [dbo].[SettlementDetail] ADD
  CONSTRAINT [FK_SettlementDetail_SettlementRequest] FOREIGN KEY([SettlementRequestId]) REFERENCES [dbo].[SettlementRequest]([SettlementRequestId]);

GO

CREATE TABLE [dbo].[SettlementPayment]
(
	  [SettlementPaymentId] INT NOT NULL IDENTITY(1,1)
	, [BusinessDate] DATETIME NOT NULL
	, [TotalAmount] DECIMAL(18,2) NULL
	, [TotalRewardAmount] DECIMAL(18,2) NULL
	, [TotalCardAmount] DECIMAL(18,2) NULL
	, [AccountName] NVARCHAR(22) NULL
	, [Bank] NVARCHAR(23) NULL
	, [AccountNo] NVARCHAR(17) NULL
	, [RoutingNo] NVARCHAR(9) NULL
	, [IsChecking] BIT NOT NULL
	, [NachaFilePath] NVARCHAR(2000) NULL
	, [NachaFileName] NVARCHAR(200) NULL
	, [IsNachaUploaded] BIT NOT NULL DEFAULT((0))
	, [NachaUploadError] NVARCHAR(max) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_SettlementPayment] PRIMARY KEY ([SettlementPaymentId] ASC)
)

GO

CREATE TABLE [dbo].[SettlementPaymentDetail]
(
	  [SettlementPaymentDetailId] INT NOT NULL IDENTITY(1,1)
	, [SettlementPaymentId] INT NOT NULL
	, [SettlementRequestId] INT NOT NULL
	, [StoreId] INT NOT NULL
	, [Amount] DECIMAL(18,2) NOT NULL
	, [AmountTypeId] Int NOT NULL
	, [AccountName] NVARCHAR(22) NULL
	, [AccountNo] NVARCHAR(17) NULL
	, [RoutingNo] NVARCHAR(9) NULL
	, [IdentificationNumber] NVARCHAR(25) NULL
	, [IsChecking] BIT NOT NULL
	, [MarkUnPaid] BIT NOT NULL DEFAULT((0))
	, [Reason] NVARCHAR(500) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_SettlementPaymentDetail] PRIMARY KEY ([SettlementPaymentDetailId] ASC)
)

ALTER TABLE [dbo].[SettlementPaymentDetail] ADD
  CONSTRAINT [FK_SettlementPaymentDetail_SettlementPayment] FOREIGN KEY([SettlementPaymentId]) REFERENCES [dbo].[SettlementPayment]([SettlementPaymentId]);

ALTER TABLE [dbo].[SettlementPaymentDetail] ADD
  CONSTRAINT [FK_SettlementPaymentDetail_SettlementRequest] FOREIGN KEY([SettlementRequestId]) REFERENCES [dbo].[SettlementRequest]([SettlementRequestId]);
GO

GO

CREATE TABLE [dbo].[BaiFile]
(
	  [BaiFileId] INT NOT NULL IDENTITY(1,1)
	, [BaiFileName] NVARCHAR(200) NOT NULL
	, [SenderIdentification] NVARCHAR(100) NULL
	, [ReceiverIdentification] NVARCHAR(100) NULL
	, [FileCreation] DATETIME NOT NULL
	, [TotalAmount] DECIMAL(18,2) NOT NULL
	, [UploadFilePath] NVARCHAR(2000) NOT NULL
	, [UploadFileName] NVARCHAR(200) NOT NULL
	, [IsArchived] BIT NOT NULL DEFAULT((0))
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_BaiFile] PRIMARY KEY ([BaiFileId] ASC)
)

GO

CREATE TABLE [dbo].[BaiFileDetail]
(
	  [BaiFileDetailId] INT NOT NULL IDENTITY(1,1)
	, [BaiFileId] INT NOT NULL
	, [Amount] DECIMAL(18,2) NOT NULL
	, [FileIdentificationNumber] NVARCHAR(100) NULL
	, [CustomerAccountNumber] NVARCHAR(100) NULL
	, [SenderIdentification] NVARCHAR(100) NULL
	, [BankReferenceNumber] NVARCHAR(100) NULL
	, [CustomerReferenceNumber] NVARCHAR(100) NULL
	, [TypeCode] NVARCHAR(100) NULL
	, [TypeDescription] NVARCHAR(200) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_BaiFileDetail] PRIMARY KEY ([BaiFileDetailId] ASC)
)
ALTER TABLE [dbo].[BaiFileDetail] ADD
  CONSTRAINT [FK_BaiFileDetail_BaiFile] FOREIGN KEY([BaiFileId]) REFERENCES [dbo].[BaiFile]([BaiFileId]);

GO

CREATE TABLE [dbo].[BaiErrorFile]
(
	  [BaiErrorFileId] INT NOT NULL IDENTITY(1,1)
	, [BaiFileName] NVARCHAR(200) NOT NULL
	, [ErrorMessage] NVARCHAR(2000) NULL
	, [ErrorStackTrace] NVARCHAR(max) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_BaiErrorFile] PRIMARY KEY ([BaiErrorFileId] ASC)
)


GO




CREATE TABLE [dbo].[FnboReturnHeader](
	 [Id] [bigint] IDENTITY(1,1)
	,[TranGuid] VARCHAR(36) NOT NULL
	,[TypeOfRecord] VARCHAR(20) NULL
	,[FileName] [nvarchar](200) NULL
	,[RecordTypeCode] INT NULL
	,[PriorityCode] INT NULL
	,[RoutingNumber] VARCHAR(20) NULL
	,[SecCode] VARCHAR(5) NULL
	,[FederalId] VARCHAR(15) NULL
	,[FileCreationDate] VARCHAR(10) NULL
	,[FileCreationTime] VARCHAR(4) NULL
	,[BankName] VARCHAR(50) NULL
	,[CompanyName] VARCHAR(50) NULL	
    ,[ReturnFilePath] NVARCHAR(500) NULL
	,[DecryptFileName] [nvarchar](200) NULL
    ,[DecryptFilePath] NVARCHAR(500) NULL	
	,[IsActive] BIT NOT NULL CONSTRAINT DF_FnboReturnHeader_IsActive DEFAULT((1))
	,[CreatedOn] DATETIME NULL CONSTRAINT DF_FnboReturnHeader_CreatedOn DEFAULT(GETUTCDATE())
	,[CreatedBy] VARCHAR(256) NULL
	,[UpdatedOn] DATETIME NULL
	,[UpdatedBy] VARCHAR(256) NULL
	,[TenantId] INT Not NULL CONSTRAINT DF_FnboReturnHeader_TenantId Default ((0))
	,[ClientId] VARCHAR(50) NULL
	CONSTRAINT [PK_FnboReturnHeader] PRIMARY KEY ([Id] ASC)
	)

GO

CREATE TABLE [dbo].[FnboReturnTransaction](
	 [Id] [bigint] IDENTITY(1,1) NOT NULL
	,[TranGuid] VARCHAR(36) NOT NULL
	,[TransactionCode] INT NULL
	,[TypeOfRecord] VARCHAR(20) NULL
	,[RecordTypeCode] INT NULL
	,[ACHReturnCode] VARCHAR(20) NULL
	,[ReturnCodeStatus] VARCHAR(40) NULL
	,[ReceivingDFIId] INT NULL
	,[DFIAccountNumber] VARCHAR(20) NULL
	,[Amount] VARCHAR(10) NULL
	,[IdentificationNumber] VARCHAR(15) NULL
	,[ReceivingCompanyName] VARCHAR(50) NULL
	,[NachaAchFile] VARCHAR(200) NULL
	,[CreateDate] DATETIME NULL
	,[HeaderRouteNumber] VARCHAR(20) NULL
	,[IsActive] BIT NOT NULL CONSTRAINT DF_FnboReturnTransaction_IsActive DEFAULT((1))
	,[CreatedOn] DATETIME NULL CONSTRAINT DF_FnboReturnTransaction_CreatedOn DEFAULT(GETUTCDATE())
	,[CreatedBy] VARCHAR(256) NULL
	,[UpdatedOn] DATETIME NULL
	,[UpdatedBy] VARCHAR(256) NULL
	,[TenantId] INT Not NULL CONSTRAINT DF_FnboReturnTransaction_TenantId Default ((0))
	,[ClientId] VARCHAR(50) NULL
	CONSTRAINT [PK_FnboReturnTransaction] PRIMARY KEY ([Id] ASC)
)
GO

CREATE TABLE [dbo].[FnboReturnOther](
	 [Id] [bigint] IDENTITY(1,1) NOT NULL
	,[TranGuid] VARCHAR(36) NOT NULL
	,[RecordTypeCode] INT NULL
	,[ServiceClassCode] INT NULL
	,[RecordType] VARCHAR(30) NULL
	,[ACHReturnCode] VARCHAR(20) NULL
	,[ReturnCodeStatus] VARCHAR(40) NULL
	,[PriorityCode] INT NULL
	,[RoutingNumber] VARCHAR(20) NULL
	,[CompanyName] VARCHAR(50) NULL
	,[CompanyIdentification] VARCHAR(50) NULL
	,[CompanyEntryDesc] VARCHAR(20) NULL
	,[CompanyDescDate] VARCHAR(10) NULL
	,[OriginatingDFIID] VARCHAR(10) NULL
	,[SECCode] VARCHAR(5) NULL
	,[AddendaTypeCode] VARCHAR(10) NULL
	,[AddendaPaymentRelatedInformation] VARCHAR(100) NULL
	,[AddendaSequenceNumber] INT NULL
	,[AddendaEntryDetailSeqNo] INT NULL
	,[EffectiveEntryDate] VARCHAR(15) NULL
	,[Reserved] VARCHAR(10) NULL
	,[TotalDebitEntry] VARCHAR(12) NULL
	,[TotalCreditEntry] VARCHAR(12) NULL
	,[BankName] VARCHAR(50) NULL
	,[HeaderRouteNumber] VARCHAR(20) NULL
	,[IsActive] BIT NOT NULL CONSTRAINT DF_FnboReturnOther_IsActive DEFAULT((1))
	,[CreatedOn] DATETIME NULL CONSTRAINT DF_FnboReturnOther_CreatedOn DEFAULT(GETUTCDATE())
	,[CreatedBy] VARCHAR(256) NULL
	,[UpdatedOn] DATETIME NULL
	,[UpdatedBy] VARCHAR(256) NULL
	,[TenantId] INT Not NULL CONSTRAINT DF_FnboReturnOther_TenantId Default ((0))
	,[ClientId] VARCHAR(50) NULL
	CONSTRAINT [PK_FnboReturnOther] PRIMARY KEY ([Id] ASC)
)

ALTER TABLE [dbo].[FnboReturnOther] ALTER COLUMN ServiceClassCode varchar(10);

CREATE TABLE [LogInfo] (
   [Id] int IDENTITY(1,1) NOT NULL,
   [Message] nvarchar(max) NULL,
   [Method] nvarchar(max) NULL,
   [Exception] nvarchar(max) NULL,
   [IsActive] [bit] NOT NULL,
   [CreatedOn] [datetime] NULL,
   [CreatedBy] [varchar](256) NULL,
   [UpdatedOn] [datetime] NULL,
   [UpdatedBy] [varchar](256) NULL,
   CONSTRAINT [PK_LogInfo]
     PRIMARY KEY CLUSTERED ([Id] ASC)
)





ALTER TABLE [Transaction]
ADD MerchantPaid INT DEFAULT 0;

ALTER TABLE [Transaction]
ADD ConsumerPaid INT DEFAULT 0;