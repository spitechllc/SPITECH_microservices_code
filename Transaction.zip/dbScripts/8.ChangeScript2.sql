CREATE TYPE [dbo].[UdtIntKeys] AS TABLE(
	[KeyValue] int NOT NULL,
	PRIMARY KEY CLUSTERED 
(
	[KeyValue] ASC
)WITH (IGNORE_DUP_KEY = OFF)
)
GO


----------------------------------13/03/2023--------------------------------
Alter Table [dbo].[ResellerBillingPayment] ADD 
	  [OffsetNachaFilePath] NVARCHAR(2000) NULL
	, [OffsetNachaFileName] NVARCHAR(200) NULL
	, [IsOffsetNachaUploaded] BIT NOT NULL CONSTRAINT DF_ResellerBillingPayment_IsNachaUploaded DEFAULT((0))
	, [OffsetNachaUploadError] NVARCHAR(max) NULL
	, [SftpConfig] NVARCHAR(100) NULL;

GO

Alter Table [dbo].[SaleAgentBillingPayment] ADD 
	  [OffsetNachaFilePath] NVARCHAR(2000) NULL
	, [OffsetNachaFileName] NVARCHAR(200) NULL
	, [IsOffsetNachaUploaded] BIT NOT NULL CONSTRAINT DF_SaleAgentBillingPayment_IsNachaUploaded DEFAULT((0))
	, [OffsetNachaUploadError] NVARCHAR(max) NULL
	, [SftpConfig] NVARCHAR(100) NULL;

GO

Alter Table [dbo].[SettlementPayment] ADD 
	  [SettlementRequestId] INT NULL
	, [TotalAchAmount] DECIMAL(18,2) NULL
	, [IdentificationNumber] NVARCHAR(25) NULL
	, [OffsetNachaFilePath] NVARCHAR(2000) NULL
	, [OffsetNachaFileName] NVARCHAR(200) NULL
	, [IsOffsetNachaUploaded] BIT NOT NULL CONSTRAINT DF_SettlementPayment_IsNachaUploaded DEFAULT((0))
	, [OffsetNachaUploadError] NVARCHAR(max) NULL
	, [SftpConfig] NVARCHAR(100) NULL;

GO

Alter Table [dbo].[SettlementPaymentDetail] ADD  [TransactionId] INT NULL;
GO

Update SettlementPaymentDetail set TransactionId = 0;

GO

Alter Table [dbo].[SettlementPaymentDetail] Alter COLUMN  [TransactionId] INT Not NULL;

GO

Alter Table [dbo].[StoreBillingPayment] ADD 
	  [OffsetNachaFilePath] NVARCHAR(2000) NULL
	, [OffsetNachaFileName] NVARCHAR(200) NULL
	, [IsOffsetNachaUploaded] BIT NOT NULL CONSTRAINT DF_StoreBillingPayment_IsNachaUploaded DEFAULT((0))
	, [OffsetNachaUploadError] NVARCHAR(max) NULL
	, [SftpConfig] NVARCHAR(100) NULL;

GO


CREATE TABLE [dbo].[StoreSettlementConfig]
(
	  [StoreSettlementConfigId] INT NOT NULL IDENTITY(1,1)
	, [StoreId] INT NULL
	, [EnableACH] BIT NOT NULL CONSTRAINT DF_StoreBillingFee_EnableACH DEFAULT((0))
	, [EnableCard] BIT NOT NULL CONSTRAINT DF_StoreBillingFee_EnableCard DEFAULT((0))
	, [EnableCashReward] BIT NOT NULL CONSTRAINT DF_StoreBillingFee_EnableCashReward DEFAULT((0))
	, [IsDefault] BIT NOT NULL CONSTRAINT DF_StoreBillingFee_IsDefault DEFAULT((0))
	, [IsActive] BIT NOT NULL CONSTRAINT DF_StoreBillingFee_IsActive DEFAULT((1))
	, [CreatedOn] DATETIME NULL CONSTRAINT DF_StoreBillingFee_CreatedOn DEFAULT(getutcdate())
	, [CreatedBy] NVARCHAR(256) NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] NVARCHAR(256) NULL
	, CONSTRAINT [PK_StoreSettlementConfig] PRIMARY KEY ([StoreSettlementConfigId] ASC)
)



GO

Insert Into StoreSettlementConfig(StoreId,EnableACH,EnableCard,EnableCashReward,IsDefault,IsActive,CreatedOn) 
Values(null,0,0,1,1,1,GetUtcdate());

GO
----------------------------------------------------------------------------

