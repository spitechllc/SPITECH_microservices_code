/*IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_PaymentInfo_TransactionId')   
    DROP INDEX IX_PaymentInfo_TransactionId ON [dbo].[PaymentInfo];   
GO  
GO  

CREATE NONCLUSTERED INDEX IX_PaymentInfo_TransactionId 
    ON [dbo].[PaymentInfo] (TransactionId);   
GO

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_ReceiptInfoLine_TransactionId')   
    DROP INDEX IX_ReceiptInfoLine_TransactionId ON [dbo].[ReceiptInfoLine];   
GO  

CREATE NONCLUSTERED INDEX IX_ReceiptInfoLine_TransactionId 
    ON [dbo].[ReceiptInfoLine] (TransactionId);   
GO

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_SaleItem_TransactionId')   
    DROP INDEX IX_SaleItem_TransactionId ON [dbo].[SaleItem];   
GO  

CREATE NONCLUSTERED INDEX IX_SaleItem_TransactionId 
    ON [dbo].[SaleItem] (TransactionId);   
GO

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Site_StoreId')   
    DROP INDEX IX_Site_StoreId ON [dbo].[Site];   
GO  

CREATE NONCLUSTERED INDEX IX_Site_StoreId
    ON [dbo].[Site] (StoreId);   
GO

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_StoreBillingFee_StoreId')   
    DROP INDEX IX_StoreBillingFee_StoreId ON [dbo].[StoreBillingFee];   
GO  

CREATE NONCLUSTERED INDEX IX_StoreBillingFee_StoreId
    ON [dbo].[StoreBillingFee] (StoreId);   
GO

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_StoreBilling_SiteId')   
    DROP INDEX IX_StoreBilling_SiteId ON [dbo].[StoreBilling];   
GO  

CREATE NONCLUSTERED INDEX IX_StoreBilling_SiteId
    ON [dbo].[StoreBilling] (SiteId);   
GO

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Transaction_SiteId')   
    DROP INDEX IX_Transaction_SiteId ON [dbo].[Transaction];   
GO  

CREATE NONCLUSTERED INDEX IX_Transaction_SiteId
    ON [dbo].[Transaction] (SiteId);   
GO

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Transaction_TransactionDate')   
    DROP INDEX IX_Transaction_TransactionDate ON [dbo].[Transaction];   
GO  

CREATE NONCLUSTERED INDEX IX_Transaction_TransactionDate
    ON [dbo].[Transaction] (TransactionDate);   
GO
*/