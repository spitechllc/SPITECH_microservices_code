INSERT INTO [Status](StatusId, Name)
VALUES 
(1, 'Inprogress'),
(2, 'Success'),
(3, 'Fail'),
(4, 'Canceled');
GO

INSERT INTO [AmountType](AmountTypeId, Name)
VALUES 
(1, 'CreditDebit'),
(2, 'ACH'),
(3, 'CashReward');
GO

INSERT INTO [PaymentStatus](PaymentStatusId, Name)
VALUES 
(0, 'NotPaid'),
(1, 'Paid'),
(3, 'MarkAsPaid');
GO

INSERT INTO [NachaConfig](NachaConfigId, AccountName, Bank, AccountNo, RoutingNo,ReceivingBankRoutingNo, IsProdEnabled)
VALUES 
(1, 'STRIDE BANK NA','FRB OF KANSAS CITY','1872360881','103100195','101000048', 0);
GO

GO