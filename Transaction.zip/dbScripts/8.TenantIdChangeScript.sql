
------------------------start script 25 jan 2023----------------
alter table [dbo].[BaiErrorFile] add [TenantId] INT Not NULL CONSTRAINT DF_BaiErrorFile_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[BaiFile] add [TenantId] INT Not NULL CONSTRAINT DF_BaiFile_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[BaiFileDetail] add [TenantId] INT Not NULL CONSTRAINT DF_BaiFileDetail_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[PaymentInfo] add [TenantId] INT Not NULL CONSTRAINT DF_PaymentInfo_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[PriceAdjustment] add [TenantId] INT Not NULL CONSTRAINT DF_PriceAdjustment_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[ReceiptInfoLine] add [TenantId] INT Not NULL CONSTRAINT DF_ReceiptInfoLine_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[ResellerBilling] add [TenantId] INT Not NULL CONSTRAINT DF_ResellerBilling_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[ResellerBillingPayment] add [TenantId] INT Not NULL CONSTRAINT DF_ResellerBillingPayment_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[ResellerBillingPaymentDetail] add [TenantId] INT Not NULL CONSTRAINT DF_ResellerBillingPaymentDetail_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[ResellerFee] add [TenantId] INT Not NULL CONSTRAINT DF_ResellerFee_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[SaleAgentBilling] add [TenantId] INT Not NULL CONSTRAINT DF_SaleAgentBilling_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[SaleAgentBillingPayment] add [TenantId] INT Not NULL CONSTRAINT DF_SaleAgentBillingPayment_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[SaleAgentBillingPaymentDetail] add [TenantId] INT Not NULL CONSTRAINT DF_SaleAgentBillingPaymentDetail_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[SaleAgentFee] add [TenantId] INT Not NULL CONSTRAINT DF_SaleAgentFee_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[SaleItem] add [TenantId] INT Not NULL CONSTRAINT DF_SaleItem_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[SettlementDetail] add [TenantId] INT Not NULL CONSTRAINT DF_SettlementDetail_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[SettlementPayment] add [TenantId] INT Not NULL CONSTRAINT DF_SettlementPayment_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[SettlementPaymentDetail] add [TenantId] INT Not NULL CONSTRAINT DF_SettlementPaymentDetail_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[SettlementRequest] add [TenantId] INT Not NULL CONSTRAINT DF_SettlementRequest_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[Site] add [TenantId] INT Not NULL CONSTRAINT DF_Site_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[StoreBilling] add [TenantId] INT Not NULL CONSTRAINT DF_StoreBilling_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[StoreBillingDetail] add [TenantId] INT Not NULL CONSTRAINT DF_StoreBillingDetail_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[StoreBillingFee] add [TenantId] INT Not NULL CONSTRAINT DF_StoreBillingFee_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[StoreBillingPayment] add [TenantId] INT Not NULL CONSTRAINT DF_StoreBillingPayment_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[StoreBillingPaymentDetail] add [TenantId] INT Not NULL CONSTRAINT DF_StoreBillingPaymentDetail_TenantId Default ((0)), [ClientId] Varchar(50) NULL
alter table [dbo].[Transaction] add [TenantId] INT Not NULL CONSTRAINT DF_Transaction_TenantId Default ((0)), [ClientId] Varchar(50) NULL

alter table [dbo].[AmountType]  alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[AmountType]  alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[BaiErrorFile] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[BaiErrorFile] alter column  [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[BaiFile] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[BaiFile] alter column  [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[BaiFileDetail] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[BaiFileDetail] alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[PaymentInfo] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[PaymentInfo] alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[PaymentStatus]  alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[PaymentStatus]  alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[PriceAdjustment] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[PriceAdjustment] alter column  [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[ReceiptInfoLine]alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[ReceiptInfoLine] alter column  [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[ResellerBilling] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[ResellerBilling] alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[ResellerBillingPayment] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[ResellerBillingPayment] alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[ResellerBillingPaymentDetail]  alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[ResellerBillingPaymentDetail] alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[ResellerBilling] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[ResellerBilling] alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[ResellerBillingPayment] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[ResellerBillingPayment] alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[ResellerBillingPaymentDetail] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[ResellerBillingPaymentDetail]  alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[ResellerFee] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[ResellerFee] alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[SaleAgentBilling] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[SaleAgentBilling] alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[SaleAgentBillingPayment] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[SaleAgentBillingPayment] alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[SaleAgentBillingPaymentDetail] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[SaleAgentBillingPaymentDetail]  alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[SaleAgentFee] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[SaleAgentFee] alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[SaleItem] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[SaleItem]  alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[SettlementDetail] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[SettlementDetail]  alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[SettlementPayment] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[SettlementPayment] alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[SettlementPaymentDetail] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[SettlementPaymentDetail] alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[SettlementRequest] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[SettlementRequest] alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[Site] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[Site]  alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[Status] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[Status]  alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[StoreBilling] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[StoreBilling] alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[StoreBillingDetail] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[StoreBillingDetail] alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[StoreBillingFee] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[StoreBillingFee]  alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[StoreBillingPayment] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[StoreBillingPayment] alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[StoreBillingPaymentDetail] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[StoreBillingPaymentDetail] alter column [UpdatedBy] NVARCHAR(256) NULL
alter table [dbo].[Transaction] alter column [CreatedBy] NVARCHAR(256) NULL
alter table [dbo].[Transaction] alter column [UpdatedBy] NVARCHAR(256) NULL


Update [dbo].[BaiErrorFile] Set [TenantId] = 1
Update [dbo].[BaiFile] Set [TenantId] = 1
Update [dbo].[BaiFileDetail] Set [TenantId] = 1
Update [dbo].[PaymentInfo] Set [TenantId] = 1
Update [dbo].[PriceAdjustment] Set [TenantId] = 1
Update [dbo].[ReceiptInfoLine] Set [TenantId] = 1
Update [dbo].[ResellerBilling] Set [TenantId] = 1
Update [dbo].[ResellerBillingPayment] Set [TenantId] = 1
Update [dbo].[ResellerBillingPaymentDetail] Set [TenantId] = 1
Update [dbo].[ResellerFee] Set [TenantId] = 1
Update [dbo].[SaleAgentBilling] Set [TenantId] = 1
Update [dbo].[SaleAgentBillingPayment] Set [TenantId] = 1
Update [dbo].[SaleAgentBillingPaymentDetail] Set [TenantId] = 1
Update [dbo].[SaleAgentFee] Set [TenantId] = 1
Update [dbo].[SaleItem] Set [TenantId] = 1
Update [dbo].[SettlementDetail] Set [TenantId] = 1
Update [dbo].[SettlementPayment] Set [TenantId] = 1
Update [dbo].[SettlementPaymentDetail] Set [TenantId] = 1
Update [dbo].[SettlementRequest] Set [TenantId] = 1
Update [dbo].[Site] Set [TenantId] = 1
Update [dbo].[StoreBilling] Set [TenantId] = 1
Update [dbo].[StoreBillingDetail] Set [TenantId] = 1
Update [dbo].[StoreBillingFee] Set [TenantId] = 1
Update [dbo].[StoreBillingPayment] Set [TenantId] = 1
Update [dbo].[StoreBillingPaymentDetail] Set [TenantId] = 1
Update [dbo].[Transaction] Set [TenantId] = 1

------------------------end script 25 jan 2023----------------