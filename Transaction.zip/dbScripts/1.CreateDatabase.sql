USE [master]
IF NOT EXISTS(SELECT * FROM sys.databases WHERE name = 'SpiTech_Transactions')
  BEGIN
    CREATE DATABASE [SpiTech_Transactions]
 END
GO
       
 USE [SpiTech_Transactions]
    
GO

