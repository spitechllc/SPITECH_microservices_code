#!/bin/bash
cd ..
echo "################################################DotNet Build########################################################"

dotnet build

echo "##############################################DotNet Publish########################################################"

dotnet publish

echo "################################################Docker Build########################################################"

docker build -f Deployment/dockerfile -t prod/transaction .

echo "##################################################Docker Tag########################################################"

docker tag prod/transaction prodregistry00.azurecr.io/prod/transaction
echo "successfully tagged the image "

echo "#################################################Docker Push########################################################"

docker push prodregistry00.azurecr.io/prod/transaction

