﻿namespace SpiTech.Marketing.Domain.Configs
{
    public class AppDownload
    {
        public string android { get; set; }
        public string ios { get; set; }
        public string SpiTech { get; set; }
    }
}
