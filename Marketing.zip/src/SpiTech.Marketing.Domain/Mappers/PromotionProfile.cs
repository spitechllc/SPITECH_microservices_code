﻿using AutoMapper;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Models;

namespace SpiTech.Marketing.Domain.Mappers
{
    public class PromotionProfile : Profile
    {
        public PromotionProfile()
        {
            CreateMap<Promotion, PromotionModel>().ReverseMap();
        }
    }
}
