﻿using AutoMapper;
using SpiTech.Marketing.Domain.Models;

namespace SpiTech.Marketing.Domain.Mappers
{
    public class CashBackEventProfile : Profile
    {
        public CashBackEventProfile()
        {
            CreateMap<Entities.CashBackEvent, CashBackEventModel>().ReverseMap();
        }
    }
}
