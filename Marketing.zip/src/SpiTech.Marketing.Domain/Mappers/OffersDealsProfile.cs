﻿using AutoMapper;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Models;

namespace SpiTech.Marketing.Domain.Mappers
{
    public class OfferProfile : Profile
    {
        public OfferProfile()
        {
            CreateMap<Offer, OfferModel>().ReverseMap();
        }
    }
}
