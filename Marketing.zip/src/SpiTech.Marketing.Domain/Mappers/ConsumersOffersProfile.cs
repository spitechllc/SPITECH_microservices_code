﻿using AutoMapper;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Models;

namespace SpiTech.Marketing.Domain.Mappers
{
    public class ConsumerOfferProfile : Profile
    {
        public ConsumerOfferProfile()
        {
            CreateMap<ConsumerOffer, ConsumerOfferModel>().ReverseMap();
            CreateMap<ConsumerOfferModel, ConsumerOfferSearchResult>().ReverseMap();
        }
    }
}
