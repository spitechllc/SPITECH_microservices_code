﻿using AutoMapper;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Models;

namespace SpiTech.Marketing.Domain.Mappers
{
    public class LoyaltyProfile : Profile
    {
        public LoyaltyProfile()
        {
            CreateMap<Loyalty, LoyaltyModel>().ReverseMap();
        }
    }
}
