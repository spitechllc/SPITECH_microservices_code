﻿namespace SpiTech.Marketing.Domain
{
    public static class Contants
    {
        public static class PromotionEvents
        {
            public const string Transaction = "Transaction";
            public const string Payment = "Payment";
        }

        public static class LoyaltyEvents
        {
            public const string PaymentMethod = "PaymentMethod";
        }

        public static class LoyaltyCriteria
        {
            public const string ACH = "ACH";
            public const string Credit = "Credit";
        }

        public static class PromotionCriteria
        {
            public const string TransactionSequenceNo = "TransactionSequenceNo";
            public const string AddCard = "AddCard";
        }

        public static class LoyaltyVelocity
        {
            public const string TokenProductClub = "";
            public const string TokenDeactive = "";
            public const string DeActive = "reward/de-activate";
            public const string Activation = "reward/activatePromo";
            public const string SignUp = "program/10945/register";
            public const string ProductClub = "myClub";
            public const string PromotionsVL = "promotions";
            public const string GlobalCampaign = "globalCampaign";
            public const string LoyaltyKey = "Authorization";
            public const string RewardsQueue = "getRewardQueue";
            public const string CurrencyBalance = "currencyBalance";
            public const string GetLocation = "getLocations";
            public const string CurrencyOption = "currencyRedemptionOptions";
        }
    }
}
