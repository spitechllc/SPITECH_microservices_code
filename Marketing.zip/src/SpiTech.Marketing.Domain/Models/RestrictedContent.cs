﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Domain.Models
{
    public class restrictedContent
    {
        public string alcohol { get; set; }
        public string tobacco { get; set; }
        public string lottery { get; set; }
    }
}
