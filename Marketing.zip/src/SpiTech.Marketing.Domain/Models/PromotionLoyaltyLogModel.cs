﻿using System;

namespace SpiTech.Marketing.Domain.Models
{
    public class PromotionLoyaltyLogModel
    {
        public Guid PromotionLoyaltyLogId { get; set; }
        public string EventName { get; set; }
        public int EventModuleTypeId { get; set; }
        public int EventTypeId { get; set; }
        public int UserId { get; set; }
        public decimal? TransactionAmount { get; set; }
        public int? StoreId { get; set; }
        public long? TransactionId { get; set; }
        public string TransactionDesc { get; set; }
        public int? TransactionSequenceNo { get; set; }
        public bool? ConsentCashReward { get; set; }
        public int? UserPaymentMethodId { get; set; }
        public int? PaymentMethodId { get; set; }
        public string EventPayload { get; set; }
        public bool IsSuccess { get; set; }
        public string ErrorMessage { get; set; }
        public DateTime? CreatedOn { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        [Newtonsoft.Json.JsonIgnore]
        public int TotalRecord { get; set; }
    }
}
