﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Domain.Models
{
    public class LifeTimeSavingResponseModel
    {
        public int Code { get; set; }
        public bool Status { get; set; }
        public string Message { get; set; }
        public LifeTimePayload payload { get; set; }
    }

    public class LifeTimePayload
    {
        public double lifeTimeSavings { get; set; }
    }
}
