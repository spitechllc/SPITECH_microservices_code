﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Domain.Models
{
    public class RewardResponseModel
    {
        public int Code { get; set; }
        public bool Status { get; set; }
        public string Message { get; set; }
        public RewardsPayload payload { get; set; }
    }
    public class RewardData
    {
        public int RewardTypeId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public object Image { get; set; }
        public string RewardType { get; set; }
        public string ExpirationDate { get; set; }
        public object FreeItemCount { get; set; }
        public bool Redeemable { get; set; }
        public string ImagePath { get; set; }
        public string SecondaryImagePath { get; set; }
        public string NotificationImagePath { get; set; }
        public string EmailNotificationImagePath { get; set; }
        public object ValidStores { get; set; }
        public object ConversionTargetCurrencyId { get; set; }
        public List<string> attributes { get; set; }
    }

    public class RewardsPayload
    {
        public int rewardCount { get; set; }
        public List<RewardData> data { get; set; }
    }
}
