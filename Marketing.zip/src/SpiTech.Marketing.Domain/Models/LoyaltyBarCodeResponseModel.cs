﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Domain.Models
{
    public class LoyaltyBarCodeResponseModel
    {
        public int code { get; set; }
        public bool status { get; set; }
        public string message { get; set; }
        public LoyaltyBarCodeModel payload { get; set; }
    }
    public class LoyaltyBarCodeModel
    {
        public string BarCode { get; set; }
        public string BarCodeTitle { get; set; }
        public string BarCodeDescription { get; set; }
        public string LoyaltyId { get; set; }
        public string LoyaltyIdMessage { get; set; }
    }
}
