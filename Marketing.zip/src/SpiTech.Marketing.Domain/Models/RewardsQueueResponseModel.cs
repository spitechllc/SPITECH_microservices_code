﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Domain.Models
{
    public class RewardsQueueResponseModel
    {
        public int Code { get; set; }
        public bool Status { get; set; }
        public string Message { get; set; }
        public List<RewardsQueueModel> payload { get; set; }
    }
    public class RewardsQueueModel
    {
        public int RewardId { get; set; }
        public string RewardType { get; set; }
        public object RewardOptions { get; set; }
        public RewardDetail RewardDetail { get; set; }
        public string HeaderText { get; set; }
        public string TitleText { get; set; }
        public string Description { get; set; }
    }

    public class RewardDetail
    {
        public object ClubName { get; set; }
        public object Image { get; set; }
        public string RewardTitle { get; set; }
        public object RewardSize { get; set; }
        public string ImagePath { get; set; }
        public string SecondaryImagePath { get; set; }
        public string NotificationImagePath { get; set; }
        public string EmailNotificationImagePath { get; set; }
        public string Description { get; set; }
        public object LongDescription { get; set; }
    }
}
