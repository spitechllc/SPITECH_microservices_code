﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Domain.Models
{
    public class LoyaltyLoginResponseModel
    {
        public int code { get; set; }
        public bool status { get; set; }
        public string message { get; set; }
        public Payload payload { get; set; }
    }

    public class Payload
    {
        public string LoyaltyId { get; set; }
        public string AuthToken { get; set; }
        public string LoyaltyIdBarcode { get; set; }
        public string PhoneNumber { get; set; }
        public string ZipCode { get; set; }
        public RestrictedContent restrictedContent { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string BarcodeTitle { get; set; }
        public string BarcodeDescription { get; set; }
        public string UserIdentity { get; set; }
        public object IdentityVerified { get; set; }
    }
    public class RestrictedContent
    {
        public string Alcohol { get; set; }
        public string Tobacco { get; set; }
        public string Lottery { get; set; }
    }
}
