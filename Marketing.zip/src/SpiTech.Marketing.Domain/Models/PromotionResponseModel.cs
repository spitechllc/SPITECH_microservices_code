﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Domain.Models
{
    public class PromotionResponseModel
    {
        public int Code { get; set; }
        public bool Status { get; set; }
        public string Message { get; set; }
        public PromotionPayload payload { get; set; }
    }

    public class Attributes
    {
        [JsonProperty("Days Of Week")]
        public string DaysOfWeek { get; set; }
    }

    public class PromotionVelocityModel
    {
        public int PromotionId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string StartDateTime { get; set; }
        public object EndDateTime { get; set; }
        public string ImagePath { get; set; }
        public object OfferType { get; set; }
        public object IsActivated { get; set; }
        public object ThirdPartyVendorId { get; set; }
        public object ValidStores { get; set; }
        public string FeaturedImagePath { get; set; }
        public string EmailNotificationImagePath { get; set; }
        public string PromoType { get; set; }
        public string IsFeatured { get; set; }
        public Attributes attributes { get; set; }
    }

    public class PromotionPayload
    {
        public int RewardCount { get; set; }
        public List<PromotionVelocityModel> data { get; set; }
        public int EarnedPoints { get; set; }
    }
}
