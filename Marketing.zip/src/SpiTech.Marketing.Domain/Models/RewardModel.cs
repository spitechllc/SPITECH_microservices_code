﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Domain.Models
{
    public class RewardModel
    {
        public int RewardTypeId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public object Image { get; set; }
        public string RewardType { get; set; }
        public string ExpirationDate { get; set; }
        public string FreeItemCount { get; set; }
        public bool Redeemable { get; set; }
        public string ImagePath { get; set; }
        public string SecondaryImagePath { get; set; }
        public string NotificationImagePath { get; set; }
        public string EmailNotificationImagePath { get; set; }
        public string ValidStores { get; set; }
        public string ConversionTargetCurrencyId { get; set; }
        public List<string> Attributes { get; set; }
    }
}
