﻿using System;

namespace SpiTech.Marketing.Domain.Models
{
    public class ConsumerOfferSearchResult
    {
        public int UserId { get; set; }
        public int OfferId { get; set; }
        public bool IsUsed { get; set; }
        public string OfferDeal { get; set; } = null;
        public string Description { get; set; } = null;
        public string Store { get; set; } = null;
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
