﻿namespace SpiTech.Marketing.Domain.Models
{
    public class ConsumerOfferModel
    {
        public int ConsumerOfferId { get; set; }
        public int UserId { get; set; }
        public int OfferId { get; set; }
        public bool IsUsed { get; set; }
    }
}
