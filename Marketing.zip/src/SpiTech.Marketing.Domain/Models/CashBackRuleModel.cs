﻿using System;

namespace SpiTech.Marketing.Domain.Models
{
    public class CashBackRuleModel
    {
        public int CashBackEventId { get; set; }
        public string EventName { get; set; }
        public int CashBackCriteriaId { get; set; }
        public int CreditTypeId { get; set; }
        public string CreditType { get; set; }
        public string CriteriaName { get; set; }
        public string Criteria { get; set; }
        public bool IsPercentage { get; set; }
        public decimal Value { get; set; }
        public string Description { get; set; }
        public int DisplayOrder { get; set; }
        public int ExpireDays { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
