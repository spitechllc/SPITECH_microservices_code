﻿namespace SpiTech.Marketing.Domain.Models
{
    public class CashBackEventModel
    {
        public int CashBackEventId { get; set; }
        public int CreditTypeId { get; set; }
        public string CreditType { get; set; }
        public string EventName { get; set; }
        public string Description { get; set; }
        public bool IsActive { get; set; }
    }
}
