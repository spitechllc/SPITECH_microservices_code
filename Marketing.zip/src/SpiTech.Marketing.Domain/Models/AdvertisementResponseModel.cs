﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Domain.Models
{
    public class AdvertisementResponseModel
    {
        public int Code { get; set; }
        public bool Status { get; set; }
        public string Message { get; set; }
        public AdvertisementPayload payload { get; set; }
    }
    public class AdvertisementModel
    {
        public int AdvertisementId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public object StartDateTime { get; set; }
        public object EndDateTime { get; set; }
        public string Url { get; set; }
        public string ImagePath { get; set; }
        public bool AdStatus { get; set; }
        public string AdButtonText { get; set; }
        public string IsFeatured { get; set; }
        public string SecondaryImagePath { get; set; }
        public string AgeRestricted { get; set; }
        public object ValidStores { get; set; }
    }

    public class AdvertisementPayload
    {
        public List<AdvertisementModel> promos { get; set; }
    }
}
