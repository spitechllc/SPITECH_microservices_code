﻿namespace SpiTech.Marketing.Domain.Models
{
    public class LoyaltyModel
    {
        public int LoyaltyId { get; set; }
        public int CashBackEventId { get; set; }
        public int CashBackCriteriaId { get; set; }
        public string Criteria { get; set; }
        public bool IsPercentage { get; set; }
        public decimal Value { get; set; }
        public int ExpireDays { get; set; }
        public bool IsActive { get; set; }
        public string EventName { get; set; }
        public string CriteriaName { get; set; }
        public string Description { get; set; }
        public int DisplayOrder { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        [Newtonsoft.Json.JsonIgnore]
        public int TotalRecord { get; set; }
    }
}