﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Domain.Models
{
    public class LoyaltyRegisterResponseModel
    {
        public string code { get; set; }
        public bool status { get; set; }
        public string message { get; set; }
        public payload payload { get; set; }
    }

    public class payload
    {
        public string loyaltyId { get; set; }
        public string authToken { get; set; }
        public string loyaltyIdBarcode { get; set; }
        public string phoneNumber { get; set; }
        public string zipCode { get; set; }
        public string barcodeTitle { get; set; }
        public string barcodeDescription { get; set; }
    }
}
