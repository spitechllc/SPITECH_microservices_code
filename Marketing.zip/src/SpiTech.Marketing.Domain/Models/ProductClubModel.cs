﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Domain.Models
{
    public class ProductClubResponseModel
    {
        public int Code { get; set; }
        public bool Status { get; set; }
        public string Message { get; set; }
        public ProductClubPayload Payload { get; set; }
    }

    public class ProductClubModel
    {
        public int ProductClubId { get; set; }
        public string Title { get; set; }
        public int Threshold { get; set; }
        public string Description { get; set; }
        public int Availed { get; set; }
        public object Image { get; set; }
        public int ClubReward { get; set; }
        public int Status { get; set; }
        public string HomeImagePath { get; set; }
        public string ImagePath { get; set; }
        public int DisplayOrder { get; set; }
        public string RedemptionImagePath { get; set; }
        public string TertiaryImagePath { get; set; }
        public string EmailNotificationImagePath { get; set; }
        public object SecondaryImagePath { get; set; }
        public object ValidStores { get; set; }
    }
    public class ProductClubPayload
    {
        public int RewardCount { get; set; }
        public List<ProductClubModel> data { get; set; }
        public int EarnedPoints { get; set; }
    }


    public class Datum
    {
        public int ProductClubId { get; set; }
        public string Title { get; set; }
        public int Threshold { get; set; }
        public string Description { get; set; }
        public int availed { get; set; }
        public object image { get; set; }
        public int clubReward { get; set; }
        public int status { get; set; }
        public string homeImagePath { get; set; }
        public string imagePath { get; set; }
        public int displayOrder { get; set; }
        public string redemptionImagePath { get; set; }
        public string tertiaryImagePath { get; set; }
        public string emailNotificationImagePath { get; set; }
        public object secondaryImagePath { get; set; }
        public object validStores { get; set; }
    }

    public class Payload1
    {
        public int rewardCount { get; set; }
        public List<Datum> data { get; set; }
        public int earnedPoints { get; set; }
    }

    public class Root
    {
        public int Code { get; set; }
        public bool Status { get; set; }
        public string Message { get; set; }
        public Payload1 Payload { get; set; }
    }
}
