﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Domain.Models
{
    public class LocationResponseModel
    {
        public int Code { get; set; }
        public bool Status { get; set; }
        public string Message { get; set; }
        public LocationPayload payload { get; set; }
    }
    public class Location
    {
        public string Id { get; set; }
        public string Brand { get; set; }
        public string BrandLogoURL { get; set; }
        public string Name { get; set; }
        public string Lat { get; set; }
        public string Lon { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public string Attributes { get; set; }
        public string Distance { get; set; }
        public string LoyaltyParticipating { get; set; }
    }
    public class LocationPayload
    {
        public List<Location> locations { get; set; }
    }
}
