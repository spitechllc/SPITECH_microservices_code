﻿namespace SpiTech.Marketing.Domain.Models
{
    public class UserModel
    {
        public int UserId { get; set; }
    }
}
