﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Domain.Models
{
    public class GlobalCampaignResponseModel
    {
        public int code { get; set; }
        public bool status { get; set; }
        public string message { get; set; }
        public PayloadGlobalCompaign payload { get; set; }
    }
    public class WeekAttributes
    {
        [JsonProperty("Days Of Week")]
        public string DaysOfWeek { get; set; }
    }

    public class GlobalCampaignModel
    {
        public int Id { get; set; }
        public int Type { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string ValidStores { get; set; }
        public string StartDateTime { get; set; }
        public string EndDateTime { get; set; }
        public string Url { get; set; }
        public string ImagePath { get; set; }
        public string TermsAndCondition { get; set; }
        public string HowToRedeem { get; set; }
        public string IsActivated { get; set; }
        public bool Redeemable { get; set; }
        public bool AdStatus { get; set; }
        public string AdButtonText { get; set; }
        public string PromoType { get; set; }
        public string IsFeatured { get; set; }
        public object FlashOfferLimitType { get; set; }
        public object OfferType { get; set; }
        public object RedemptionsRemaining { get; set; }
        public object MaxAllowedRedemtions { get; set; }
        public int? TotalRedemptions { get; set; }
        public string FeaturedImagePath { get; set; }
        public string EmailNotificationImagePath { get; set; }
        public int DisplayOrder { get; set; }
        public string ThirdPartyVendorId { get; set; }
        public WeekAttributes attributes { get; set; }
        public string ageRestricted { get; set; }
        public string ageRestrictedContents { get; set; }
    }

    public class PayloadGlobalCompaign
    {
        public List<GlobalCampaignModel> data { get; set; }
    }
}
