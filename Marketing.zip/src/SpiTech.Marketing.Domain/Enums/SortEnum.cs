﻿using System.Text.Json.Serialization;

namespace SpiTech.Marketing.Domain.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum ConsumerOfferSortBy
    {
        None = 0,
        OfferId = 1,
        OfferDeal = 2,
        Store = 3,
        StartDate = 4,
        EndDate = 5
    }
}
