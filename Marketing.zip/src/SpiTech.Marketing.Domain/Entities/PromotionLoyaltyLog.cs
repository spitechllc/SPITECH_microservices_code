﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.Marketing.Domain.Entities
{
    [Table("PromotionLoyaltyLog")]
    public class PromotionLoyaltyLog : BaseEntity
    {
        [ExplicitKey]
        public Guid PromotionLoyaltyLogId { get; set; }
        public string EventName { get; set; }
        public int EventModuleTypeId { get; set; }
        public int EventTypeId { get; set; }
        public int UserId { get; set; }
        public decimal? TransactionAmount { get; set; }
        public int? StoreId { get; set; }
        public long? TransactionId { get; set; }
        public string TransactionDesc { get; set; }
        public int? TransactionSequenceNo { get; set; }
        public bool? ConsentCashReward { get; set; }
        public int? UserPaymentMethodId { get; set; }
        public int? PaymentMethodId { get; set; }
        public string EventPayload { get; set; }
        public bool IsSuccess { get; set; }
        public string ErrorMessage { get; set; }
    }
}
