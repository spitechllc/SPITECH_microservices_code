﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Marketing.Domain.Entities
{
    [Table("Loyalty")]
    public class Loyalty : BaseEntity
    {
        [Key]
        public int LoyaltyId { get; set; }
        public int CashBackEventId { get; set; }
        public int CashBackCriteriaId { get; set; }
        public string Criteria { get; set; }
        public bool IsPercentage { get; set; }
        public decimal Value { get; set; }
        public int ExpireDays { get; set; }
        public string Description { get; set; }
        public int DisplayOrder { get; set; }
    }
}