﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Marketing.Domain.Entities
{
    [Table("ConsumerOffer")]
    public class ConsumerOffer : BaseEntity
    {
        [Key]
        public int ConsumerOfferId { get; set; }
        public int UserId { get; set; }
        public int OfferId { get; set; }
        public bool IsUsed { get; set; }
    }
}