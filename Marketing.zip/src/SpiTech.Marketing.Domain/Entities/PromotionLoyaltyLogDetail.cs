﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.Marketing.Domain.Entities
{
    [Table("PromotionLoyaltyLogDetail")]
    public class PromotionLoyaltyLogDetail : BaseEntity
    {
        [ExplicitKey]
        public Guid PromotionLoyaltyLogDetailId { get; set; }
        public Guid PromotionLoyaltyLogId { get; set; }
        public int? CreditTypeId { get; set; }
        public int? CreditIdentifier { get; set; }
        public decimal CreditAmount { get; set; }
        public DateTime? ExpireDate { get; set; }
    }
}
