﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Marketing.Domain.Entities
{
    [Table("CashBackEvent")]
    public class CashBackEvent : BaseEntity
    {
        [Key]
        public int CashBackEventId { get; set; }
        public int CreditTypeId { get; set; }
        public string EventName { get; set; }
        public string Description { get; set; }
    }
}
