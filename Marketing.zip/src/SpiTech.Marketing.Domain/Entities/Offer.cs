﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.Marketing.Domain.Entities
{
    [Table("Offer")]
    public class Offer : BaseEntity
    {
        [Key]
        public int OfferId { get; set; }
        public int CompanyId { get; set; }
        public int Region { get; set; }
        public int StoreId { get; set; }
        public string Store { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string OfferDeal { get; set; }
        public string UPCCode { get; set; }
        public string Description { get; set; }
        public string ImageUrl { get; set; }
        public bool QRCode { get; set; }
        public bool SingleUse { get; set; }
    }
}