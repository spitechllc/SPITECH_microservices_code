﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Marketing.Domain.Entities
{
    [Table("CashBackCriteria")]
    public class CashBackCriteria : BaseEntity
    {
        [Key]
        public int CashBackCriteriaId { get; set; }
        public int CashBackEventId { get; set; }
        public string CriteriaName { get; set; }
        public string Description { get; set; }
        public bool HasValue { get; set; }
        public string ValueType { get; set; }
    }
}
