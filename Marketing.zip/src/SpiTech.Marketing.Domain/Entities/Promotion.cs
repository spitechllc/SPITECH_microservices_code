﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.Marketing.Domain.Entities
{
    [Table("Promotion")]
    public class Promotion : BaseEntity
    {
        [Key]
        public int PromotionId { get; set; }
        public int CashBackEventId { get; set; }
        public int CashBackCriteriaId { get; set; }
        public string Criteria { get; set; }
        public bool IsPercentage { get; set; }
        public decimal Value { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Description { get; set; }
        public int DisplayOrder { get; set; }
    }
}