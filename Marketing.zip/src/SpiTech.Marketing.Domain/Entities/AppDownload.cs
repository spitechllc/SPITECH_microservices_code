﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Marketing.Domain.Entities
{
    [Table("AppDownload")]
    public class AppDownload : BaseEntity
    {
        [Key]
        public int AppDownloadId { get; set; }
        public string Code { get; set; }
        public string RequestHeader{ get; set; }
        public string RequestUrl { get; set; }
        public string ResponseUrl { get; set; }
    }
}