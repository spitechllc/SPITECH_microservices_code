﻿using SpiTech.ApplicationCore.Domain.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Domain.Entities
{
    [Table("DeActivate")]
    public class DeActivate : BaseEntity
    {
        [Key]
        public long Id { get; set; }
        public int Code { get; set; }
        public bool Status { get; set; }
        public string Message { get; set; }
        public string Payload { get; set; }
    }
}
