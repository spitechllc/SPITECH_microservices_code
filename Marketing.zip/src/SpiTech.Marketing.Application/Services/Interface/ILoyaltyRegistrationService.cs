﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Services.Interface
{
    public interface ILoyaltyRegistrationService
    {
        Task<HttpResponseMessage> SendRequest(HttpMethod method, string entity,
            HttpContent content = null, string additional = null, string query = "");
    }
}
