﻿using SpiTech.Marketing.Application.Services.Interface;
using SpiTech.Marketing.Domain.Configs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Services
{
    public class LoyaltyVelocityService : ILoyaltyVelocityService
    {
        private readonly LoyaltyConsumerConfiguration _loyaltyConsumerConfig;

        public LoyaltyVelocityService(LoyaltyConsumerConfiguration loyaltyConsumerConfig)
        {
            _loyaltyConsumerConfig = loyaltyConsumerConfig;
        }

        public async Task<HttpResponseMessage> SendRequest(HttpMethod method, string entity, HttpContent content = null, string additional = null, string token = null, string query = "")
        {
            using System.Net.Http.HttpClient httpClient = new();
            await SetClient(httpClient, $"{entity}{(string.IsNullOrEmpty(additional) ? string.Empty : $"/{additional}")}", query, token);

            return method == HttpMethod.Get ? await httpClient.GetAsync(httpClient.BaseAddress)
                 : method == HttpMethod.Delete ? await httpClient.DeleteAsync(httpClient.BaseAddress)
                 : method == HttpMethod.Post ? await httpClient.PostAsync(httpClient.BaseAddress, content)
                 : method == HttpMethod.Put ? await httpClient.PutAsync(httpClient.BaseAddress, content)
                 : await PatchClient(httpClient, content);
        }

        private async Task<HttpResponseMessage> PatchClient(System.Net.Http.HttpClient httpClient, HttpContent content)
        {
            HttpRequestMessage request = new(new HttpMethod("PATCH"), httpClient.BaseAddress) { Content = content };
            return await httpClient.SendAsync(request);
        }

        private async Task SetClient(System.Net.Http.HttpClient client, string entity, string query, string token)
        {
            string url = _loyaltyConsumerConfig.BaseUrl;
            string baseurl = url;
            client.BaseAddress = new Uri(baseurl + entity + (string.IsNullOrEmpty(query) ? string.Empty : "?" + query));
            if (!string.IsNullOrWhiteSpace(token))
            {
                client.DefaultRequestHeaders.Add("Authorization", token);
            }
        }
    }
}
