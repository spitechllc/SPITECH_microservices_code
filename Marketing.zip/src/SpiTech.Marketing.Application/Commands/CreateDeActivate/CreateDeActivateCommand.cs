﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Commands.CreateDeActivate
{
    public class CreateDeActivateModel : IRequest<ResponseModel<DeActivateModel>>
    {
        public int offerPromoId { get; set; }
        
    }
    public class CreateDeActivateCommand : CreateDeActivateModel
    {
        public string HeaderToken { get; set; }
    }
}
