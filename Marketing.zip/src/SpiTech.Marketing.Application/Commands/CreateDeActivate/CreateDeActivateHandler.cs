﻿using AutoMapper;
using MediatR;
using Newtonsoft.Json;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Marketing.Domain.Configs;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static SpiTech.Marketing.Domain.Contants;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Marketing.Application.Services.Interface;

namespace SpiTech.Marketing.Application.Commands.CreateDeActivate
{
    public class CreateDeActivateHandler : IRequestHandler<CreateDeActivateCommand, ResponseModel<DeActivateModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateDeActivateHandler> _logger;
        private readonly IMapper _mapper;
        private readonly ILoyaltyVelocityService _deActivateService;
        private readonly IEventDispatcher _eventDispatcher;

        public CreateDeActivateHandler(IUnitOfWork context,
                                   ILogger<CreateDeActivateHandler> logger,
                                   IMapper mapper,
                                   ILoyaltyVelocityService deActivateService,
                                   IEventDispatcher eventDispatcher
                                   )
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _deActivateService = deActivateService;
            _eventDispatcher = eventDispatcher;
        }

        public async Task<ResponseModel<DeActivateModel>> Handle(CreateDeActivateCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            bool status = false;
            string token = command.HeaderToken;
            ResponseModel<DeActivateModel> responseModel = new() { Success = false };
            string requestvalue = LoyaltyVelocity.DeActive;
            string strjson = ApplicationCore.Helpers.JsonObjectConverter.Serialize(command);
            HttpContent content = new StringContent(strjson, null, "application/json");
            HttpResponseMessage exchageres = await _deActivateService.SendRequest(HttpMethod.Post, requestvalue, content, null, token, null);

            DeActivateModel objModel = new DeActivateModel();
            if (exchageres.IsSuccessStatusCode)
            {
                string loyaltyDetails = await exchageres.Content.ReadAsStringAsync();

                objModel = JsonConvert.DeserializeObject<DeActivateModel>(loyaltyDetails);
                responseModel.Success = true;
                responseModel.Message = "Success";
                responseModel.Data = objModel;
                if (responseModel.Data.Status == false)
                {
                    return responseModel;
                }
                try
                {
                    await _context.DeActivates.Add(new Domain.Entities.DeActivate()
                    {
                        Code = responseModel.Data.Code,
                        Status = responseModel.Data.Status,
                        Message = responseModel.Data.Message,
                        Payload = Convert.ToString(responseModel.Data.payload)
                    });
                    _context.Commit();
                    status = true;
                }
                catch (Exception ex)
                {
                    _context.Rollback();
                    _logger.Error(ex);
                    throw;
                }

            }
            else
            {
                string errorres = await exchageres.Content.ReadAsStringAsync();

                responseModel.Success = false;
                responseModel.Message = errorres;
                throw new ValidationException();
            }
            _logger.TraceExitMethod(nameof(Handle), status);
            return responseModel;
        }

        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress(),
                IsError = isError,
                ErrorMessage = errorMessage
            });
        }
    }
}
