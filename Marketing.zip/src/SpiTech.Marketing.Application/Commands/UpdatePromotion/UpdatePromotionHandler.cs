﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.Marketing.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Commands.UpdatePromotion
{
    public class UpdatePromotionHandler : IRequestHandler<UpdatePromotionCommand, bool>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdatePromotionHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public UpdatePromotionHandler(IUnitOfWork context,
                                   ILogger<UpdatePromotionHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<bool> Handle(UpdatePromotionCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            Domain.Entities.CashBackCriteria valuetype = await _context.CashBackCriterias.GetCriteriaById(command.CashBackCriteriaId);
            if (valuetype != null)
            {
                if (valuetype.HasValue)
                {
                    bool isvalid = false;
                    if (valuetype.ValueType == "int")
                    {
                        isvalid = int.TryParse(command.Criteria, out int result);
                    }
                    if (!isvalid)
                    {
                        throw new ValidationException(new ValidationFailure("Criteria", $"Invalid Criteria"));
                    }
                }

            }

            bool status = false;
            try
            {
                status = await _context.Promotions.Update(new Domain.Entities.Promotion()
                {
                    PromotionId = command.PromotionId,
                    CashBackEventId = command.CashBackEventId,
                    CashBackCriteriaId = command.CashBackCriteriaId,
                    Criteria = command.Criteria,
                    IsPercentage = command.IsPercentage,
                    Value = command.Value,
                    StartDate = command.StartDate,
                    EndDate = command.EndDate,
                    DisplayOrder = command.DisplayOrder,
                    Description = command.Description,
                });
                _context.Commit();
            }
            catch (Exception ex)
            {
                _context.Rollback();
                _logger.Error(ex);
                throw;
            }

            _logger.TraceExitMethod(nameof(Handle), status);

            await Task.FromResult(status);
            return status;
        }
    }
}
