﻿using FluentValidation;

namespace SpiTech.Marketing.Application.Commands.UpdatePromotion
{
    public class UpdatePromotionValidator : AbstractValidator<UpdatePromotionCommand>
    {
        public UpdatePromotionValidator()
        {
            RuleFor(x => x.PromotionId).GreaterThan(0).WithMessage("PromotionId is required");
            RuleFor(x => x.CashBackEventId).GreaterThan(0).WithMessage("Event is required");
            RuleFor(x => x.CashBackCriteriaId).GreaterThan(0).WithMessage("Criteria is required");
            RuleFor(x => x.StartDate).NotNull().NotEmpty().WithMessage("StartDate is required");
            RuleFor(x => x.EndDate).NotNull().NotEmpty().WithMessage("EndDate is required");

            RuleFor(s => s.Description).MaximumLength(1000);
            RuleFor(s => s.Criteria).MaximumLength(100);
        }
    }


}
