﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.Marketing.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Commands.CreateLoyalty
{
    public class CreateLoyaltyHandler : IRequestHandler<CreateLoyaltyCommand, int>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateLoyaltyHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public CreateLoyaltyHandler(IUnitOfWork context,
                                   ILogger<CreateLoyaltyHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<int> Handle(CreateLoyaltyCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            Domain.Entities.CashBackCriteria valuetype = await _context.CashBackCriterias.GetCriteriaById(command.CashBackCriteriaId);
            if (valuetype != null)
            {
                if (valuetype.HasValue)
                {
                    bool isvalid = false;
                    if (valuetype.ValueType == "int")
                    {
                        isvalid = int.TryParse(command.Criteria, out int result);
                    }
                    if (!isvalid)
                    {
                        throw new ValidationException(new ValidationFailure("Criteria", $"Invalid Criteria"));
                    }
                }

            }

            int loyaltyId = 0;
            try
            {
                loyaltyId = await _context.Loyalties.Add(new Domain.Entities.Loyalty
                {
                    CashBackEventId = command.CashBackEventId,
                    CashBackCriteriaId = command.CashBackCriteriaId,
                    Criteria = command.Criteria,
                    IsPercentage = command.IsPercentage,
                    Value = command.Value,
                    ExpireDays = command.ExpireDays,
                    Description = command.Description,
                    DisplayOrder = command.DisplayOrder,
                });
                _context.Commit();
            }
            catch (Exception ex)
            {
                _context.Rollback();
                _logger.Error(ex);
                throw;
            }
            _logger.TraceExitMethod(nameof(Handle), loyaltyId);

            await Task.FromResult(loyaltyId);
            return loyaltyId;
        }
    }
}
