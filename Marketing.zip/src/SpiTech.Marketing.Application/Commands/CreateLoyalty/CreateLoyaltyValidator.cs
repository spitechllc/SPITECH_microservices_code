﻿using FluentValidation;

namespace SpiTech.Marketing.Application.Commands.CreateLoyalty
{
    public class CreateLoyaltyValidator : AbstractValidator<CreateLoyaltyCommand>
    {
        public CreateLoyaltyValidator()
        {
            RuleFor(x => x.CashBackEventId).GreaterThan(0).WithMessage("Event is required");
            RuleFor(x => x.CashBackCriteriaId).GreaterThan(0).WithMessage("Criteria is required");
            RuleFor(s => s.Description).MaximumLength(1000);
            RuleFor(s => s.Criteria).MaximumLength(100);
        }
    }


}