﻿using MediatR;

namespace SpiTech.Marketing.Application.Commands.CreateLoyalty
{
    public class CreateLoyaltyCommand : IRequest<int>
    {
        public int CashBackEventId { get; set; }
        public int CashBackCriteriaId { get; set; }
        public string Criteria { get; set; }
        public bool IsPercentage { get; set; }
        public decimal Value { get; set; }
        public int ExpireDays { get; set; }
        public string Description { get; set; }
        public int DisplayOrder { get; set; }
    }
}
