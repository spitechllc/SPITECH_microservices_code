﻿using FluentValidation;

namespace SpiTech.Marketing.Application.Commands.RetryCashbackProcess
{
    public class RetryCashbackProcessValidator : AbstractValidator<RetryCashbackProcessCommand>
    {
        public RetryCashbackProcessValidator()
        {
            RuleFor(x => x.PromotionLoyaltyLogIds).NotNull().NotEmpty();
        }
    }
}
