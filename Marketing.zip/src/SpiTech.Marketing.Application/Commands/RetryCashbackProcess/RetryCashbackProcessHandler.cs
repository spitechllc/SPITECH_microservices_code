﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents.Events;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.Marketing.Application.Commands.PromotionLoyaltyEventProcess;
using SpiTech.Marketing.Application.UnitOfWorks;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Commands.RetryCashbackProcess
{
    public class RetryCashbackProcessHandler : IRequestHandler<RetryCashbackProcessCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<RetryCashbackProcessHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public RetryCashbackProcessHandler(IUnitOfWork context,
                                   ILogger<RetryCashbackProcessHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<ResponseModel> Handle(RetryCashbackProcessCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel response = new();

            if (command.PromotionLoyaltyLogIds != null && command.PromotionLoyaltyLogIds.Any())
            {
                foreach (System.Guid promotionLoyaltyLogId in command.PromotionLoyaltyLogIds)
                {
                    Domain.Entities.PromotionLoyaltyLog proccessEvent = await _context.PromotionLoyaltyLogs.GetPromotionLoyaltyLogByFilter(promotionLoyaltyLogId.ToString(), false);

                    if (proccessEvent != null)
                    {
                        IEvent eventObject = null;

                        if (proccessEvent.EventTypeId == (int)EventBus.DomainEvents.Enums.EventType.FinalizeRequestEvent)
                        {
                            eventObject = Newtonsoft.Json.JsonConvert.DeserializeObject<FinalizeRequestEvent>(proccessEvent.EventPayload);
                        }
                        else if (proccessEvent.EventTypeId == (int)EventBus.DomainEvents.Enums.EventType.PaymentMethodAddedEvent)
                        {
                            eventObject = Newtonsoft.Json.JsonConvert.DeserializeObject<PaymentMethodAddedEvent>(proccessEvent.EventPayload);
                        }

                        if (eventObject != null)
                        {
                            await _mediator.Send(new PromotionLoyaltyEventProcessCommand()
                            {
                                Event = eventObject
                            });
                        }

                        response.Success = true;
                    }
                }
            }

            _logger.TraceExitMethod(nameof(Handle), response);
            return await Task.FromResult(response);
        }
    }
}
