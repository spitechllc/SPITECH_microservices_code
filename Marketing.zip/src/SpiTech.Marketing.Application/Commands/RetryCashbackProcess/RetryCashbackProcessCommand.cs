﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using System;

namespace SpiTech.Marketing.Application.Commands.RetryCashbackProcess
{
    public class RetryCashbackProcessCommand : IRequest<ResponseModel>
    {
        public Guid[] PromotionLoyaltyLogIds { get; set; }
    }
}
