﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Commands.UpdateOffer
{
    public class UpdateOfferHandler : IRequestHandler<UpdateOfferCommand, bool>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateOfferHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IStorageService storageService;

        public UpdateOfferHandler(IUnitOfWork context,
                                   ILogger<UpdateOfferHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper,
                                   IStorageServiceFactory storageServiceFactory)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            storageService = storageServiceFactory.Get(ContainerType.OfferImage);
        }

        public async Task<bool> Handle(UpdateOfferCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            try
            {
                IEnumerable<OfferModel> offerDetails = _mapper.Map<IEnumerable<OfferModel>>(await _context.Offers.GetOfferByFilter(command.OfferId, command.StoreId, "", "", null, null, null, null));
                if (command.ChangeImageUrl)
                {
                    if (!string.IsNullOrEmpty(command.ImageUrl))
                    {

                        if (!((command.ImageUrl.Length % 4 == 0) && Regex.IsMatch(command.ImageUrl, @"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.None)))
                        {
                            throw new ValidationException(new ValidationFailure("ImageUrl", $"Invalid base64"));
                        }
                    }
                }
                bool OfferId = await _context.Offers.Update(new Domain.Entities.Offer
                {
                    OfferId = command.OfferId,
                    CompanyId = command.CompanyId,
                    Region = command.Region,
                    StoreId = command.StoreId,
                    Store = command.Store,
                    StartDate = command.StartDate,
                    EndDate = command.EndDate,
                    OfferDeal = command.OfferDeal,
                    UPCCode = command.UPCCode,
                    Description = command.Description,
                    QRCode = command.QRCode,
                    SingleUse = command.SingleUse,
                    IsActive = command.IsActive

                });
                string filename = "";
                string Azurefileurl = "";

                #region upload file over Azure
                if (command.ChangeImageUrl)
                {
                    if (!string.IsNullOrEmpty(command.ImageUrl))
                    {
                        filename = OfferId + "_" + UniqueIdGenerator.Generate() + "_OfferImage.jpeg";
                        Azurefileurl = await SaveImage(command.ImageUrl, filename);

                        if (!string.IsNullOrEmpty(Azurefileurl))
                        {
                            await _context.Offers.UpdateImageUrl(Azurefileurl, command.OfferId);
                        }
                    }

                    else
                    {
                        await _context.Offers.UpdateImageUrl("", command.OfferId);
                    }
                }
                else
                {
                    await _context.Offers.UpdateImageUrl(command.ImageUrl, command.OfferId);
                }
                #endregion
                _context.Commit();

                _logger.TraceExitMethod(nameof(Handle), OfferId);

                return await Task.FromResult(OfferId);
            }
            catch
            {
                _context.Rollback();
                throw;
            }
        }

        private async Task<string> SaveImage(string base64image, string filename)
        {
            await storageService.UploadBlob(base64image, filename);
            Blob res = await storageService.GetFile(filename);
            return res != null ? res.StorageUri : string.Empty;
        }
    }
}