﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Commands.UpdateProfileVelocity
{
    public class RestrictedContent
    {
        public string Alcohol { get; set; }
        public string Lottery { get; set; }
        public string Tobacco { get; set; }
    }

    public class UpdateProfileModel
    {
        public RestrictedContent restrictedContent { get; set; }
    }
    public class UpdateProfileCommand : UpdateProfileModel, IRequest<ResponseModel>
    {
        public string ClientId { get; set; }
        public int? TenantId { get; set; }
        public string HeaderToken { get; set; }
    }
}
