﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Commands.UpdateProfileVelocity
{
    public class UpdateProfileVelocityHandler
    {
    }
}
