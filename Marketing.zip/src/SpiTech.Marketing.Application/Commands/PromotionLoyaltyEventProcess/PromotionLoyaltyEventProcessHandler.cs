﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events;
using SpiTech.EventBus.DomainEvents.Events.Marketings;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.Marketing.Application.Processors;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Commands.PromotionLoyaltyEventProcess
{
    public class PromotionLoyaltyEventProcessHandler :
        IRequestHandler<PromotionLoyaltyEventProcessCommand, bool>
    {
        private readonly ILoyaltyProcessor loyaltyProcessor;
        private readonly IPromotionProcessor promotionProcessor;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IStoreServiceClient storeapiclient;
        private readonly IUnitOfWork context;
        private readonly ILogger<PromotionLoyaltyEventProcessHandler> logger;

        public PromotionLoyaltyEventProcessHandler(
                                    ILoyaltyProcessor loyaltyProcessor,
                                    IPromotionProcessor promotionProcessor,
                                    IEventDispatcher eventDispatcher,
                                    IStoreServiceClient storeclient,
                                    IUnitOfWork context,
                                    ILogger<PromotionLoyaltyEventProcessHandler> logger)
        {
            this.loyaltyProcessor = loyaltyProcessor;
            this.promotionProcessor = promotionProcessor;
            this.eventDispatcher = eventDispatcher;
            storeapiclient = storeclient;
            this.context = context;
            this.logger = logger;
        }
        public async Task<bool> Handle(PromotionLoyaltyEventProcessCommand command, CancellationToken cancellationToken)
        {
            logger.Warn($"Start marketing service");
            string eventPayload = "";
            StoreInfoModel store = null;
            bool storeConsentCashReward = false;
            PromotionLoyaltyEvent promotionLoyaltyEvent = new()
            {
                PromotionLoyalties = new List<EventBus.DomainEvents.Models.Marketings.PromotionLoyaltyModel>()
            };

            try
            {
                Domain.Entities.PromotionLoyaltyLog proccessEvent = await context.PromotionLoyaltyLogs.GetPromotionLoyaltyLogByFilter(command.Event.MessageIdentifier.ToString(), true);

                if (proccessEvent != null)
                {
                    logger.Warn($"PromotionLoyaltyLogs has entry for MessageIdentifier-{command.Event.MessageIdentifier}");
                    return true;
                }

                logger.Warn($"PromotionLoyaltyLogs has no entry for MessageIdentifier-{command.Event.MessageIdentifier}");

                eventPayload = Newtonsoft.Json.JsonConvert.SerializeObject(command.Event);

                if (command.Event is FinalizeRequestEvent finalizeRequestEvent)
                {
                    //Get Site details to Check Site has Accepted promotion and loyalties
                    store = await storeapiclient.GetStoreInfoAsync(null, finalizeRequestEvent.Transaction.SiteId);

                    if (store != null)
                    {
                        if (store.ConsentCashReward != null && store.ConsentCashReward != false)
                        {
                            storeConsentCashReward = true;
                        }

                        await context.PromotionLoyaltyLogs.UpdateConsentCashReward(command.Event.MessageIdentifier.ToString(), storeConsentCashReward);
                    }

                    promotionLoyaltyEvent.UserId = finalizeRequestEvent.Transaction.UserId;
                }
                else if (command.Event is PaymentMethodAddedEvent paymentMethodAddedEvent)
                {
                    promotionLoyaltyEvent.UserId = paymentMethodAddedEvent.UserId;
                    storeConsentCashReward = true;
                    promotionLoyaltyEvent.NotificationTypeIdentifier = NotificationTypeIdentifierConstants.AddCardEvent;
                }

                EventBus.DomainEvents.Models.Marketings.PromotionLoyaltyModel promotion = await promotionProcessor.Process(command.Event);

                if (promotion != null)
                {
                    promotion.StoreId = store?.StoreId;
                    promotion.StoreName = store?.StoreName;
                    promotionLoyaltyEvent.PromotionLoyalties.Add(promotion);
                }

                EventBus.DomainEvents.Models.Marketings.PromotionLoyaltyModel loyalty = await loyaltyProcessor.Process(command.Event);

                if (loyalty != null)
                {

                    loyalty.StoreId = store?.StoreId;
                    loyalty.StoreName = store?.StoreName;
                    promotionLoyaltyEvent.PromotionLoyalties.Add(loyalty);
                }

                foreach (EventBus.DomainEvents.Models.Marketings.PromotionLoyaltyModel promotionLoyalty in promotionLoyaltyEvent.PromotionLoyalties)
                {
                    logger.Warn($"Start marketing service method PromotionLoyaltyLogDetail");

                    await context.PromotionLoyaltyLogDetails.Add(new Domain.Entities.PromotionLoyaltyLogDetail
                    {
                        PromotionLoyaltyLogDetailId = Guid.NewGuid(),
                        PromotionLoyaltyLogId = command.Event.MessageIdentifier,
                        CreditAmount = promotionLoyalty.CreditAmount,
                        CreditIdentifier = promotionLoyalty.CreditIdentifier,
                        CreditTypeId = (int)promotionLoyalty.CreditType,
                        ExpireDate = promotionLoyalty.ExpireDate
                    });

                    string strPromotionLoyaltyLogDetail = promotionLoyalty.CreditAmount + "||" + promotionLoyalty.CreditAmount + "||" + promotionLoyalty.CreditType + "||" +
                       promotionLoyalty.ExpireDate;
                    logger.Warn($"PromotionLoyaltyLogDetail table entry: {strPromotionLoyaltyLogDetail}");
                }

                if (storeConsentCashReward)
                {
                    logger.Warn($"Start storeConsentCashReward");

                    if (promotionLoyaltyEvent.PromotionLoyalties != null && promotionLoyaltyEvent.PromotionLoyalties.Any())
                    {
                        promotionLoyaltyEvent.PromotionLoyalties = promotionLoyaltyEvent.PromotionLoyalties.Where(a => a.CreditAmount > 0).ToList();

                        logger.Warn($"Start PromotionLoyalties");
                        if (promotionLoyaltyEvent.PromotionLoyalties.Any())
                        {

                            promotionLoyaltyEvent.CashbackEvent = eventPayload;
                            promotionLoyaltyEvent.CashbackEventType = command.Event.EventType;

                            logger.Warn($"Go to Finanace service Calling{promotionLoyaltyEvent.CashbackEvent}");
                            await eventDispatcher.Dispatch(promotionLoyaltyEvent);
                            logger.Warn($"Call to Finanace service{promotionLoyaltyEvent.CashbackEventType}");
                        }
                    }

                    await context.PromotionLoyaltyLogs.Update(command.Event.MessageIdentifier.ToString(), true, "");
                }

                context.Commit();
            }
            catch (Exception ex)
            {
                logger.Warn($"Erroe in markeint service-{ex}");

                logger.Error(ex);
                context.Rollback();

                await context.PromotionLoyaltyLogs.Update(command.Event.MessageIdentifier.ToString(), false, ex.Message);
                context.Commit();
                throw;
            }

            return true;
        }
    }
}
