﻿using MediatR;
using SpiTech.EventBus.DomainEvents.Events;

namespace SpiTech.Marketing.Application.Commands.PromotionLoyaltyEventProcess
{
    public class PromotionLoyaltyEventProcessCommand : IRequest<bool>
    {
        public IEvent Event { get; set; }
    }
}
