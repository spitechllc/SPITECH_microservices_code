﻿using MediatR;
using System;
using System.ComponentModel.DataAnnotations;

namespace SpiTech.Marketing.Application.Commands.CreateOffer
{
    public class CreateOfferCommand : IRequest<int>
    {
        [Required]
        public int CompanyId { get; set; }
        [Required]
        public int Region { get; set; }
        [Required]
        public int StoreId { get; set; }
        [Required]
        public string Store { get; set; }
        [Required]
        public DateTime StartDate { get; set; }
        [Required]
        public DateTime EndDate { get; set; }
        [Required]
        public string OfferDeal { get; set; }
        public string UPCCode { get; set; }
        public string Description { get; set; }
        public string ImageUrl { get; set; }
        public bool QRCode { get; set; }
        public bool SingleUse { get; set; }
    }
}
