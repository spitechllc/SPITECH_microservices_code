﻿using FluentValidation;

namespace SpiTech.Marketing.Application.Commands.CreateOffer
{
    public class CreateOfferValidator : AbstractValidator<CreateOfferCommand>
    {
        public CreateOfferValidator()
        {
            RuleFor(x => x.CompanyId).NotNull().NotEmpty().WithMessage("Company Id is required");
            RuleFor(x => x.Region).NotNull().NotEmpty().WithMessage("Region is required");
            RuleFor(x => x.StoreId).NotNull().NotEmpty().WithMessage("Store Id is required");
            RuleFor(x => x.StartDate).NotNull().NotEmpty().WithMessage("Start Date is required");
            RuleFor(x => x.EndDate).NotNull().NotEmpty().WithMessage("End Date is required");
            RuleFor(x => x.OfferDeal).NotNull().NotEmpty().WithMessage("Offer Deal is required");

            RuleFor(s => s.Store).MaximumLength(50);
            RuleFor(s => s.OfferDeal).MaximumLength(100);
            RuleFor(s => s.UPCCode).MaximumLength(30);
            RuleFor(s => s.Description).MaximumLength(500);
        }

    }
}
