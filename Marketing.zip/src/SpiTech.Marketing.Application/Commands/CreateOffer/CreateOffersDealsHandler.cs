﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.Marketing.Application.UnitOfWorks;
using System;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Commands.CreateOffer
{
    public class CreateOfferHandler : IRequestHandler<CreateOfferCommand, int>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateOfferHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IStorageService storageService;

        public CreateOfferHandler(IUnitOfWork context,
                                   ILogger<CreateOfferHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper,
                                   IStorageServiceFactory storageServiceFactory)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            storageService = storageServiceFactory.Get(ContainerType.OfferImage);
        }

        public async Task<int> Handle(CreateOfferCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            int offerId = 0;

            try
            {
                offerId = await _context.Offers.Add(new Domain.Entities.Offer
                {
                    CompanyId = command.CompanyId,
                    Region = command.Region,
                    StoreId = command.StoreId,
                    Store = command.Store,
                    StartDate = command.StartDate,
                    EndDate = command.EndDate,
                    OfferDeal = command.OfferDeal,
                    UPCCode = command.UPCCode,
                    Description = command.Description,
                    QRCode = command.QRCode,
                    SingleUse = command.SingleUse,

                });
                string filename = "";
                string Azurefileurl = "";

                #region upload file over Azure

                if (!string.IsNullOrEmpty(command.ImageUrl))
                {

                    if (!((command.ImageUrl.Length % 4 == 0) && Regex.IsMatch(command.ImageUrl, @"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.None)))
                    {
                        throw new ValidationException(new ValidationFailure("ImageUrl", $"Invalid base64"));
                    }
                    else
                    {
                        filename = offerId + "_" + UniqueIdGenerator.Generate() + "_OfferImage.jpeg";
                        Azurefileurl = await SaveImage(command.ImageUrl, filename);

                        if (!string.IsNullOrEmpty(Azurefileurl))
                        {
                            await _context.Offers.UpdateImageUrl(Azurefileurl, offerId);
                        }
                    }
                }
                #endregion
                _context.Commit();
            }
            catch (Exception ex)
            {
                _context.Rollback();
                _logger.Error(ex);
                throw;
            }

            _logger.TraceExitMethod(nameof(Handle), offerId);

            await Task.FromResult(offerId);
            return offerId;
        }

        private async Task<string> SaveImage(string base64image, string filename)
        {
            await storageService.UploadBlob(base64image, filename);
            Blob res = await storageService.GetFile(filename);
            return res != null ? res.StorageUri : string.Empty;
        }
    }
}
