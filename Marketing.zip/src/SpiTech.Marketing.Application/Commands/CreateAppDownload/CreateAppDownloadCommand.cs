﻿using MediatR;
using Microsoft.AspNetCore.Http;
using System;

namespace SpiTech.Marketing.Application.Commands.CreateAppDownload
{
    public class CreateAppDownloadCommand : IRequest<bool>
    {
        public HttpRequest Request { get; set; }
        public string Code { get; set; }
        public string ResponseUrl { get; set; }
    }
}
