﻿using FluentValidation;

namespace SpiTech.Marketing.Application.Commands.CreateAppDownload
{
    public class CreateAppDownloadValidator : AbstractValidator<CreateAppDownloadCommand>
    {
        public CreateAppDownloadValidator()
        {
           
        }
    }
}
