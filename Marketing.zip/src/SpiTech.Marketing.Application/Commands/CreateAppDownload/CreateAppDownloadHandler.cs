﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Http.Extensions;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Marketing.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Commands.CreateAppDownload
{
    public class CreateAppDownloadHandler : IRequestHandler<CreateAppDownloadCommand, bool>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateAppDownloadHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public CreateAppDownloadHandler(IUnitOfWork context,
                                   ILogger<CreateAppDownloadHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<bool> Handle(CreateAppDownloadCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            var appDownloadId = 0;

            try
            {
                appDownloadId = await _context.AppDownloads.Add(new Domain.Entities.AppDownload
                {
                    Code = command.Code,
                    RequestHeader = JsonConvert.SerializeObject(command.Request.Headers),
                    RequestUrl = command.Request.GetEncodedUrl(),
                    ResponseUrl = command.ResponseUrl,
                });

                _context.Commit();
            }
            catch (Exception ex)
            {
                _context.Rollback();
                _logger.Error(ex);
                throw;
            }
            _logger.TraceExitMethod(nameof(Handle), appDownloadId);

            await Task.FromResult(appDownloadId);

            return appDownloadId > 0;
        }
    }
}
