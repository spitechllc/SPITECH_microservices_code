﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Marketings;
using SpiTech.Marketing.Application.Queries.GetOfferByFilter;
using SpiTech.Marketing.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Commands.CreateConsumerOffer
{
    public class CreateConsumerOfferHandler : IRequestHandler<CreateConsumerOfferCommand, int>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateConsumerOfferHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher eventDispatcher;

        public CreateConsumerOfferHandler(IUnitOfWork context,
                                   ILogger<CreateConsumerOfferHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper,
                                   IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            this.eventDispatcher = eventDispatcher;
        }

        public async Task<int> Handle(CreateConsumerOfferCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            int ConsumerOfferId = 0;
            try
            {
                foreach (int userId in command.UserIds)
                {
                    ConsumerOfferId = await _context.ConsumerOffers.Add(new Domain.Entities.ConsumerOffer
                    {
                        OfferId = command.OfferId,
                        UserId = userId
                    });
                }
                _context.Commit();
            }
            catch (Exception ex)
            {
                _context.Rollback();
                _logger.Error(ex);
                throw;
            }
            _logger.TraceExitMethod(nameof(Handle), ConsumerOfferId);

            ApplicationCore.Pagination.PaginatedList<Domain.Models.OfferModel> offerdetails = await _mediator.Send(new GetOfferByFilterQuery { OfferId = command.OfferId });
            DispatchConsumerOfferSendEvent(command);

            await Task.FromResult(ConsumerOfferId);
            return ConsumerOfferId;
        }

        private async void DispatchConsumerOfferSendEvent(CreateConsumerOfferCommand command)
        {
            Domain.Entities.Offer offer = await _context.Offers.Get(command.OfferId);

            await eventDispatcher.Dispatch(new ConsumerOfferSendEvent
            {
                UserIds = command.UserIds,
                OfferId = command.OfferId,
                ProcessDate = DateTime.UtcNow,
                CompanyId = offer.CompanyId,
                Description = offer.Description,
                StartDate = offer.StartDate,
                EndDate = offer.EndDate,
                ImageUrl = offer.ImageUrl,
                OfferDeal = offer.OfferDeal,
                QRCode = offer.QRCode,
                Region = offer.Region,
                Store = offer.Store,
                StoreId = offer.StoreId,
                SingleUse = offer.SingleUse,
                UPCCode = offer.UPCCode,
            });
        }
    }
}
