﻿using MediatR;
using System.ComponentModel.DataAnnotations;

namespace SpiTech.Marketing.Application.Commands.CreateConsumerOffer
{
    public class CreateConsumerOfferCommand : IRequest<int>
    {
        [Required]
        public int[] UserIds { get; set; }
        [Required]
        public int OfferId { get; set; }
    }
}