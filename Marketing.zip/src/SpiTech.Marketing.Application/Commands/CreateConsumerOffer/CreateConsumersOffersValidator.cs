﻿using FluentValidation;

namespace SpiTech.Marketing.Application.Commands.CreateConsumerOffer
{
    public class CreateConsumerOfferValidator : AbstractValidator<CreateConsumerOfferCommand>
    {
        public CreateConsumerOfferValidator()
        {
            RuleFor(x => x.OfferId).NotNull().NotEmpty().WithMessage("Offer Id is required");
        }
    }
}
