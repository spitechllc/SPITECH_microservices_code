﻿using AutoMapper;
using MediatR;
using Newtonsoft.Json;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Marketing.Domain.Configs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using SpiTech.Marketing.Domain.Models;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Application.Services.Interface;
using static SpiTech.Marketing.Domain.Contants;
using SpiTech.ApplicationCore.Domain.Exceptions;

namespace SpiTech.Marketing.Application.Commands.CreateLoyaltyProgamRegister
{
    public class CreateLoyaltyRegisterHandler : IRequestHandler<CreateLoyaltyRegisterCommand, LoyaltyRegisterResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateLoyaltyRegisterHandler> _logger;
        private readonly ILoyaltyRegistrationService _loyaltyRegistrationService;
        private readonly LoyaltyConsumerConfiguration _loyaltyConsumerConfigurations;
        private readonly IMapper _mapper;

        public CreateLoyaltyRegisterHandler(IUnitOfWork context,
                                   ILogger<CreateLoyaltyRegisterHandler> logger,
                                   ILoyaltyRegistrationService loyaltyRegistrationService,
                                   LoyaltyConsumerConfiguration loyaltyConsumerConfigurations,
                                   IMapper mapper
                                   )
        {
            _context = context;
            _logger = logger;
            _loyaltyRegistrationService = loyaltyRegistrationService;
            _loyaltyConsumerConfigurations = loyaltyConsumerConfigurations;
            _mapper = mapper;
        }

        public async Task<LoyaltyRegisterResponseModel> Handle(CreateLoyaltyRegisterCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            bool status = false;
            LoyaltyRegisterResponseModel responseModel = new();
            string requestvalue = LoyaltyVelocity.SignUp;
            string strjson = ApplicationCore.Helpers.JsonObjectConverter.Serialize(command);
            HttpContent content = new StringContent(strjson, Encoding.UTF8, "application/json");
            HttpResponseMessage exchageres = await _loyaltyRegistrationService.SendRequest(HttpMethod.Put, requestvalue, content, null, null);

            LoyaltyRegisterResponseModel objModel = new LoyaltyRegisterResponseModel();
            if (exchageres.IsSuccessStatusCode)
            {
                string loyaltyDetails = await exchageres.Content.ReadAsStringAsync();

                objModel = JsonConvert.DeserializeObject<LoyaltyRegisterResponseModel>(loyaltyDetails);
                responseModel.code = objModel.code;
                responseModel.status = objModel.status;
                responseModel.message = objModel.message;
                responseModel.payload = objModel.payload;
                if (responseModel.status == false)
                {
                    return responseModel;
                }

                if (!string.IsNullOrEmpty(responseModel.payload.loyaltyId))
                {
                    try
                    {
                        await _context.LoyaltyRegisters.Add(new Domain.Entities.LoyaltyRegisterVL()
                        {
                            LoyaltyId = responseModel.payload.loyaltyId,
                            UserId = "",
                            MobileNo = command.phoneNumber,
                            FirstName = command.firstName,
                            LastName = command.lastName,
                            Email = command.email,
                            Password = command.password,
                            BirthDate = command.birthDate,
                            PhoneNumber = command.phoneNumber,
                            Platform = command.platform.ToString(),
                            ZipCode = command.zipCode,
                            Alcohol = command.restrictedContent.alcohol,
                            Tobacco = command.restrictedContent.tobacco,
                            Lottery = command.restrictedContent.lottery,
                            PromoCode = command.promoCode,
                            CommSms = command.communicationSubscription.sms,
                            CommEmail = command.communicationSubscription.email,
                            AuthToken = responseModel.payload.authToken
                        });
                        _context.Commit();
                        status = true;
                    }
                    catch (Exception ex)
                    {
                        _context.Rollback();
                        _logger.Error(ex);
                        throw;
                    }
                }
            }
            else
            {
                string errorres = await exchageres.Content.ReadAsStringAsync();

                responseModel.status = false;
                responseModel.message = errorres;
                throw new ValidationException();
            }
            _logger.TraceExitMethod(nameof(Handle), status);
            return responseModel;
        }
    }
}
