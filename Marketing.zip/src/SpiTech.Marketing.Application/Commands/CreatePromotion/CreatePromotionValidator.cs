﻿using FluentValidation;

namespace SpiTech.Marketing.Application.Commands.CreatePromotion
{
    public class CreatePromotionValidator : AbstractValidator<CreatePromotionCommand>
    {
        public CreatePromotionValidator()
        {
            RuleFor(x => x.CashBackEventId).GreaterThan(0).WithMessage("Event is required");
            RuleFor(x => x.CashBackCriteriaId).GreaterThan(0).WithMessage("Criteria is required");
            RuleFor(x => x.StartDate).NotNull().NotEmpty().WithMessage("StartDate is required");
            RuleFor(x => x.EndDate).NotNull().NotEmpty().WithMessage("EndDate is required");

            RuleFor(s => s.Description).MaximumLength(1000);
            RuleFor(s => s.Criteria).MaximumLength(100);
        }
    }


}
