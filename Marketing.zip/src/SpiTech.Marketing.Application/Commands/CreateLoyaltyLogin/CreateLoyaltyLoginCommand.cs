﻿using MediatR;
using SpiTech.Marketing.Domain.Models;

namespace SpiTech.Marketing.Application.Commands.CreateLoyaltyLogin
{
    public class LoyaltyLoginModel : IRequest<LoyaltyLoginResponseModel>
    {
        public string email { get; set; }
        public string userName { get; set; }
        public string password { get; set; }
    }

    public class CreateLoyaltyLoginCommand : LoyaltyLoginModel
    {

    }
}
