﻿using AutoMapper;
using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Marketing.Application.Services.Interface;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Commands.CreateLoyaltyLogin
{

    public class CreateLoyaltyLoginHandler : IRequestHandler<CreateLoyaltyLoginCommand, LoyaltyLoginResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateLoyaltyLoginHandler> _logger;
        private readonly ILoginService _loginService;


        public CreateLoyaltyLoginHandler(
                                    IUnitOfWork context, 
                                   ILoginService loginService,
                                   ILogger<CreateLoyaltyLoginHandler> logger)
        {
            _context = context;
            _logger = logger;
            _loginService = loginService;
        }

        /// <summary>
        /// LoyaltyLoginResponse 
        /// </summary>
        /// <param name="command">This is model parameter which have username email amd password</param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task<LoyaltyLoginResponseModel> Handle(CreateLoyaltyLoginCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            bool status = false;
            LoyaltyLoginResponseModel responseModel = new();

            string requestvalue = "program/10945/login";
            string strjson = ApplicationCore.Helpers.JsonObjectConverter.Serialize(command);
            HttpContent content = new StringContent(strjson, Encoding.UTF8, "application/json");
            HttpResponseMessage exchageres = await _loginService.SendRequest(HttpMethod.Post, requestvalue, content, null, null);

            LoyaltyLoginResponseModel objModel = new LoyaltyLoginResponseModel();
            if (exchageres.IsSuccessStatusCode)
            {
                string loginDetail = await exchageres.Content.ReadAsStringAsync();

                objModel = JsonConvert.DeserializeObject<LoyaltyLoginResponseModel>(loginDetail);
                responseModel.code = objModel.code;
                responseModel.status = objModel.status;
                responseModel.message = objModel.message;
                responseModel.payload = objModel.payload;

                if (!string.IsNullOrEmpty(responseModel.payload.LoyaltyId))
                {
                    try
                    {
                        await _context.LoyaltyLogins.Add(new Domain.Entities.LoyaltyLogin()
                        {
                            LoyaltyId = responseModel.payload.LoyaltyId,
                            UserName = command.userName,
                            Email = command.email,
                            Password = command.password,
                            AuthToken = responseModel.payload.AuthToken
                        });
                        _context.Commit();
                        status = true;
                    }
                    catch (Exception ex)
                    {
                        _context.Rollback();
                        _logger.Error(ex);
                        throw;
                    }
                }
            }
            else
            {
                string errorres = await exchageres.Content.ReadAsStringAsync();
                responseModel.status = false;
                responseModel.message = errorres;
                throw new ValidationException();
            }
            _logger.TraceExitMethod(nameof(Handle), status);
            return responseModel;
        }
    }
}
