﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.Marketing.Application.Commands.PromotionLoyaltyEventProcess;
using SpiTech.Marketing.Application.UnitOfWorks;
using System;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.EventConsumer
{
    public class PaymentMethodAddedEventConsumer : IConsumer<PaymentMethodAddedEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<PaymentMethodAddedEventConsumer> _logger;
        private readonly IUnitOfWork dbContext;

        public PaymentMethodAddedEventConsumer(IMediator mediator,
                                                ILogger<PaymentMethodAddedEventConsumer> logger,
                                                IUnitOfWork dbContext)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.dbContext = dbContext;
        }
        public async Task Consume(ConsumeContext<PaymentMethodAddedEvent> context)
        {
            _logger.TraceEnterMethod(nameof(Consume), context);
            try
            {
                await dbContext.Execute(async () =>
                    await dbContext.PromotionLoyaltyLogs.Add(new Domain.Entities.PromotionLoyaltyLog
                    {
                        PromotionLoyaltyLogId = context.Message.MessageIdentifier,
                        EventModuleTypeId = (int)context.Message.EventModuleType,
                        EventTypeId = (int)context.Message.EventType,
                        TransactionId = null,
                        TransactionAmount = null,
                        TransactionDesc = null,
                        EventName = context.Message.GetType().Name,
                        UserId = context.Message.UserId,
                        StoreId = null,
                        UserPaymentMethodId = context.Message.UserPaymentMethodId,
                        TransactionSequenceNo = null,
                        PaymentMethodId = context.Message.PaymentMethodId,
                        EventPayload = Newtonsoft.Json.JsonConvert.SerializeObject(context.Message),
                        IsActive = true,
                        IsSuccess = false
                    })
                );

                await _mediator.Send(new PromotionLoyaltyEventProcessCommand
                {
                    Event = context.Message
                });
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
            _logger.Warn($"ChangePaymentMethodEvent consumed successfully. UserPaymentMethodId : {context.Message.UserPaymentMethodId}");
        }
    }
}
