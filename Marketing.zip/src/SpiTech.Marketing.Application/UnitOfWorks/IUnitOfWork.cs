﻿using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Marketing.Application.Repositories;

namespace SpiTech.Marketing.Application.UnitOfWorks
{
    public interface IUnitOfWork : IBaseUnitOfWork
    {
        IAppDownloadRepository AppDownloads { get; }
        IOfferRepository Offers { get; }
        IConsumerOfferRepository ConsumerOffers { get; }
        ILoyaltyRepository Loyalties { get; }
        IPromotionRepository Promotions { get; }
        IPromotionLoyaltyLogRepository PromotionLoyaltyLogs { get; }
        IPromotionLoyaltyLogDetailRepository PromotionLoyaltyLogDetails { get; }
        ICashBackEventRepository CashBackEvents { get; }
        ICashBackCriteriaRepository CashBackCriterias { get; }
        ILoyaltyRegisterVLRepository LoyaltyRegisters { get; }
        ILoyaltyLoginRepository LoyaltyLogins { get; }
        IDeActivateRepository DeActivates { get; }
    }
}
