﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Repositories
{
    public interface ILoyaltyRepository : IRepository<Loyalty>
    {
        Task<List<LoyaltyModel>> GetAllLoyalty(int? Skip, int? Take, string SortBy, string SortOrder);
        Task<LoyaltyModel> GetLoyaltyById(int LoyaltyId);
        Task<Loyalty> GetLoyalty(string eventname, string criteria);
        Task<List<CashBackRuleModel>> GetCashBackRuleModels(int? loyaltyId = null);
    }
}
