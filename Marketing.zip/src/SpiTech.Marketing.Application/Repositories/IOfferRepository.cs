﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Repositories
{
    public interface IOfferRepository : IRepository<Offer>
    {
        Task<int> UpdateImageUrl(string url, int OfferId);
        Task<List<OfferModel>> GetOfferByFilter(int? OfferId, int? StoreId, string StoreName, string OfferDeal, int? Skip, int? Take, string SortBy, string SortOrder);
        Task<List<OfferModel>> SearchOfferByFilter(string StoreName, string description);
        Task<List<OfferModel>> GetInactiveOffersByFilter(int? OfferId, int? StoreId, string StoreName, string OfferDeal, int? PageIndex, int? PageSize, string SortBy, string SortOrder, int[] storeIds);
        Task<List<OfferModel>> GetOfferDealByFilter(int? OfferId, int? StoreId, string StoreName, string OfferDeal, int? Skip, int? Take, string SortBy, string SortOrder, int[] storeIds);
    }
}
