﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Repositories
{
    public interface IPromotionLoyaltyLogRepository : IRepository<PromotionLoyaltyLog>
    {
        Task<PromotionLoyaltyLog> GetPromotionLoyaltyLogByFilter(string promotionLoyaltyLogId, bool isSuccess);
        Task<bool> Update(string promotionLoyaltyLogId, bool isSuccess, string errorMessage);
        Task<bool> UpdateConsentCashReward(string promotionLoyaltyLogId, bool consentCashReward);
        Task<List<PromotionLoyaltyLogModel>> GetPromotionLoyaltyLogs(int pageIndex, int pageSize, int? userId, bool? isFailure, DateTime from, DateTime to);
    }
}
