﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Repositories
{
    public interface ILoyaltyRegisterVLRepository : IRepository<LoyaltyRegisterVL>
    {
        Task<bool> UpdateProfile(restrictedContent restrictedContent, string token, int requestedBy);
    }
}
