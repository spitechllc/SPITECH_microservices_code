﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Marketing.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Repositories
{
    public interface IDeActivateRepository : IRepository<DeActivate>
    {
    }
}
