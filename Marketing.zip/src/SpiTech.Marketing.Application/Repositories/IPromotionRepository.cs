﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Repositories
{
    public interface IPromotionRepository : IRepository<Promotion>
    {
        Task<Promotion> GetPromotion(string criteriaName, string criteria);
        Task<List<PromotionModel>> GetAllPromotion(int? Skip, int? Take, string SortBy, string SortOrder);
        Task<PromotionModel> GetPromotionById(int PromotionId);
        Task<List<CashBackRuleModel>> GetCashBackRuleModels(string TenantName, int? promotionId = null);
    }
}
