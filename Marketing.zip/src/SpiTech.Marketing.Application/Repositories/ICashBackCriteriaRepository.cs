﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Marketing.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Repositories
{
    public interface ICashBackCriteriaRepository : IRepository<CashBackCriteria>
    {
        Task<IEnumerable<CashBackCriteria>> GetCriteriaByEventId(int eventId);
        Task<CashBackCriteria> GetCriteriaById(int criteriaId);
    }
}
