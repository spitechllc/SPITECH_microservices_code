﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Repositories
{
    public interface ICashBackEventRepository : IRepository<CashBackEvent>
    {
        Task<IEnumerable<CashBackEventModel>> GetEvent(int credittypeid);
    }
}
