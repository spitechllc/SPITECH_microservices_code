﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Marketing.Domain.Entities;

namespace SpiTech.Marketing.Application.Repositories
{
    public interface IAppDownloadRepository : IRepository<AppDownload>
    {
    }
}
