﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Enums;
using SpiTech.Marketing.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Repositories
{
    public interface IConsumerOfferRepository : IRepository<ConsumerOffer>
    {

        Task<List<ConsumerOfferSearchResult>> GetAllActiveConsumerOffer(int? offerId, int? UserId, ConsumerOfferSortBy? sortBy, SortOrderEnum? sortOrder);
        Task<List<ConsumerOfferSearchResult>> GetAllScheduledConsumerOffer();
    }
}
