﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.EventBus.DomainEvents.Models.Marketings;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain;
using System;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Processors
{
    internal class PromotionProcessor : IPromotionProcessor
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<PromotionProcessor> logger;
        private readonly IMediator mediator;
        private readonly IMapper mapper;

        public PromotionProcessor(IUnitOfWork context,
                                ILogger<PromotionProcessor> logger,
                                IMediator mediator,
                                IMapper mapper)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            this.mapper = mapper;
        }

        public async Task<PromotionLoyaltyModel> Process(IEvent promotionLoyaltyEvent)
        {
            logger.TraceEnterMethod(nameof(Process), promotionLoyaltyEvent);

            PromotionLoyaltyModel model = null;

            if (promotionLoyaltyEvent is FinalizeRequestEvent finalizeRequestEvent)
            {
                model = await ProcessFinalizeRequestEvent(finalizeRequestEvent);
            }
            else if (promotionLoyaltyEvent is PaymentMethodAddedEvent paymentMethodAddedEvent)
            {
                model = await ProcessChangePaymentMethodEvent(paymentMethodAddedEvent);
            }

            logger.TraceExitMethod(nameof(Process), model);
            return await Task.FromResult(model);
        }

        private async Task<PromotionLoyaltyModel> ProcessChangePaymentMethodEvent(PaymentMethodAddedEvent paymentMethodAddedEvent)
        {
            logger.Warn($"Promotion ProcessChangePaymentMethodEvent");

            PromotionLoyaltyModel model = new()
            {
                CreditType = CreditType.Promotion,
                PaymentMethodId = paymentMethodAddedEvent.PaymentMethodId,
                UserPaymentMethodId = paymentMethodAddedEvent.UserPaymentMethodId,
            };

            logger.Warn($"Promotion from GetPromotion para1 - {Contants.PromotionCriteria.AddCard}");
            logger.Warn($"Promotion from GetPromotion para2 - {paymentMethodAddedEvent.UserPaymentMethodCount}");
            logger.Warn($"Promotion from GetPromotion para3 - {DateTime.UtcNow}");

            Domain.Entities.Promotion promotion = await context.Promotions.GetPromotion(Contants.PromotionCriteria.AddCard, paymentMethodAddedEvent.UserPaymentMethodCount.ToString());

            if (promotion != null)
            {
                logger.Warn($"Promotion from GetPromotion - {promotion}");

                model.CreditIdentifier = promotion.PromotionId;
                model.CreditAmount = MathExtension.ToMoney(promotion.Value);
                model.ExpireDate = promotion.EndDate;
                model.NotificationTypeIdentifier = NotificationTypeIdentifierConstants.AddCardEvent;

                logger.Warn($"Promotion Amount - {model.CreditAmount}");

            }
            else
            {
                logger.Warn($"Promotion not found for AddCard");
            }

            return await Task.FromResult(model);
        }

        private async Task<PromotionLoyaltyModel> ProcessFinalizeRequestEvent(FinalizeRequestEvent finalizeRequestEvent)
        {
            decimal amount = finalizeRequestEvent.Transaction.CardAmount;

            PromotionLoyaltyModel model = new()
            {
                CreditType = EventBus.DomainEvents.Enums.CreditType.Promotion,
                TransactionId = finalizeRequestEvent.Transaction.TransactionId,
                TransactionDesc = finalizeRequestEvent.Transaction.TransactionInfo,
                TransactionTypeId = finalizeRequestEvent.Transaction.TransactionTypeId,
                TransactionAmount = amount
            };

            if (amount > 0 && finalizeRequestEvent.Transaction.IsPaymentSuccess && finalizeRequestEvent.Transaction.StatusId == (int)Status.Success)
            {
                Domain.Entities.Promotion promotion = await context.Promotions.GetPromotion(Contants.PromotionCriteria.TransactionSequenceNo, finalizeRequestEvent.TransactionSequenceNo.ToString());

                if (promotion != null)
                {
                    model.CreditIdentifier = promotion.PromotionId;
                    model.CreditAmount = MathExtension.ToMoney(promotion.IsPercentage ? amount * promotion.Value / 100 : promotion.Value);
                    model.ExpireDate = promotion.EndDate;
                    model.NotificationTypeIdentifier = NotificationTypeIdentifierConstants.TransactionSequenceNo;
                    model.TransactionCount = Convert.ToInt32(promotion.Criteria==""?0: promotion.Criteria);
                }
                else
                {
                    logger.Info($"Promotion not found for TransactionSequenceNo-{finalizeRequestEvent.TransactionSequenceNo}");
                }
            }

            return model;
        }
    }
}
