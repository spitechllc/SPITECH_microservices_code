﻿using SpiTech.EventBus.DomainEvents.Events;
using SpiTech.EventBus.DomainEvents.Models.Marketings;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Processors
{
    public interface IPromotionProcessor
    {
        Task<PromotionLoyaltyModel> Process(IEvent promotionLoyaltyEvent);
    }
}
