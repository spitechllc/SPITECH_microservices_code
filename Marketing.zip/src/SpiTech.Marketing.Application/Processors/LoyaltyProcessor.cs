﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.EventBus.DomainEvents.Models.Marketings;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain;
using System;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Processors
{
    internal class LoyaltyProcessor : ILoyaltyProcessor
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<LoyaltyProcessor> logger;
        private readonly IMediator mediator;
        private readonly IMapper mapper;

        public LoyaltyProcessor(IUnitOfWork context,
                                ILogger<LoyaltyProcessor> logger,
                                IMediator mediator,
                                IMapper mapper)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            this.mapper = mapper;
        }

        public async Task<PromotionLoyaltyModel> Process(IEvent promotionLoyaltyEvent)
        {
            logger.TraceEnterMethod(nameof(Process), promotionLoyaltyEvent);

            PromotionLoyaltyModel model = null;

            if (promotionLoyaltyEvent is FinalizeRequestEvent finalizeRequestEvent)
            {
                model = await ProcessFinalizeRequestEvent(finalizeRequestEvent);
            }

            logger.TraceExitMethod(nameof(Process), model);
            return await Task.FromResult(model);
        }

        private async Task<PromotionLoyaltyModel> ProcessFinalizeRequestEvent(FinalizeRequestEvent finalizeRequestEvent)
        {
            decimal amount = finalizeRequestEvent.Transaction.CardAmount;

            PromotionLoyaltyModel model = new()
            {
                CreditType = CreditType.Loyalty,
                TransactionId = finalizeRequestEvent.Transaction.TransactionId,
                TransactionDesc = finalizeRequestEvent.Transaction.TransactionInfo,
                TransactionTypeId = finalizeRequestEvent.Transaction.TransactionTypeId,
                TransactionAmount = amount
            };

            if (amount > 0 && finalizeRequestEvent.Transaction.IsPaymentSuccess && finalizeRequestEvent.Transaction.StatusId == (int)Status.Success)
            {
                if (finalizeRequestEvent.Transaction.PaymentMethodId == (int)EnumPaymentMethod.ACH)
                {
                    Domain.Entities.Loyalty loyalty = await context.Loyalties.GetLoyalty(Contants.LoyaltyEvents.PaymentMethod, Contants.LoyaltyCriteria.ACH);

                    if (loyalty != null)
                    {
                        model.CreditIdentifier = loyalty.LoyaltyId;
                        model.CreditAmount = MathExtension.ToMoney(loyalty.IsPercentage ? amount * loyalty.Value / 100 : loyalty.Value);
                        model.ExpireDate = DateTime.UtcNow.AddDays(loyalty.ExpireDays);
                        model.NotificationTypeIdentifier= NotificationTypeIdentifierConstants.ACHTransaction;
                    }
                }

                if (finalizeRequestEvent.Transaction.PaymentMethodId == (int)EnumPaymentMethod.CreditCard)
                {
                    Domain.Entities.Loyalty loyalty = await context.Loyalties.GetLoyalty(Contants.LoyaltyEvents.PaymentMethod, Contants.LoyaltyCriteria.Credit);

                    if (loyalty != null)
                    {
                        model.CreditIdentifier = loyalty.LoyaltyId;
                        model.CreditAmount = MathExtension.ToMoney(loyalty.IsPercentage ? amount * loyalty.Value / 100 : loyalty.Value);
                        model.ExpireDate = DateTime.UtcNow.AddDays(loyalty.ExpireDays);
                        model.NotificationTypeIdentifier = NotificationTypeIdentifierConstants.CreditCardTransaction;
                    }
                }
            }

            return model;
        }
    }
}
