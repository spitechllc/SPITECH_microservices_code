﻿using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Marketing.Application.Services;
using SpiTech.Marketing.Application.Services.Interface;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Queries.GetLoyaltyBarcode
{
    public class GetLoyaltyBarcodeHandler : IRequestHandler<GetLoyaltyBarcodeQuery, LoyaltyBarCodeResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetLoyaltyBarcodeHandler> _logger;
        private readonly ILoyaltyVelocityService _loyaltyVelocityService;
        private readonly IEventDispatcher _eventDispatcher;
        public GetLoyaltyBarcodeHandler(ILoyaltyVelocityService loyaltyVelocityService,
                                    ILogger<GetLoyaltyBarcodeHandler> logger,
                                    IUnitOfWork context,
                                    IEventDispatcher eventDispatcher)
        {
            _loyaltyVelocityService = loyaltyVelocityService;
            _logger = logger;
            _context = context;
            _eventDispatcher = eventDispatcher;
        }

        public async Task<LoyaltyBarCodeResponseModel> Handle(GetLoyaltyBarcodeQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            string token = query.HeaderToken;
            LoyaltyBarCodeResponseModel responseModel = new();
            if (string.IsNullOrEmpty(token))
            {
                responseModel.message = "Invalid token";
                return responseModel;
            }
            string requestvalue = "loyaltybarcode";
            HttpResponseMessage productClub = await _loyaltyVelocityService.SendRequest(HttpMethod.Get, requestvalue, null, null, token, null);
            if (productClub.IsSuccessStatusCode)
            {
                string responseData = await productClub.Content.ReadAsStringAsync();
                LoyaltyBarCodeResponseModel objModel = new LoyaltyBarCodeResponseModel();
                objModel = JsonConvert.DeserializeObject<LoyaltyBarCodeResponseModel>(responseData);
                responseModel.code = objModel.code;
                responseModel.status = objModel.status;
                responseModel.message = objModel.message;
                responseModel.payload = objModel.payload;
                if (responseModel.status == true)
                {
                    try
                    {
                        _context.Commit();
                        responseModel.status = true;
                    }
                    catch (Exception ex)
                    {
                        responseModel.status = false;
                        _logger.Error(ex, ex.Message, "Handle Loyalty Bar Code");
                        _context.Rollback();
                    }
                }
            }
            return responseModel;
        }
    }

}
