﻿using MediatR;
using SpiTech.Marketing.Domain.Models;

namespace SpiTech.Marketing.Application.Queries.GetLoyaltyBarcode
{
    public class GetLoyaltyBarcodeModel
    {
        public string HeaderToken { get; set; }
    }
    public class GetLoyaltyBarcodeQuery : GetLoyaltyBarcodeModel, IRequest<LoyaltyBarCodeResponseModel>
    {

    }
}
