﻿using MediatR;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Queries.GetLifeTimeSaving
{
    public class GetLifeTimeSavingModel
    {
        public string HeaderToken { get; set; }
    }
    public class GetLifeTimeSavingQuery : GetLifeTimeSavingModel, IRequest<LifeTimeSavingResponseModel>
    {

    }
}
