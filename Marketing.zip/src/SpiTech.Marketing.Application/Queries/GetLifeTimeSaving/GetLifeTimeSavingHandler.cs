﻿using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Marketing.Application.Services.Interface;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static SpiTech.Marketing.Domain.Contants;

namespace SpiTech.Marketing.Application.Queries.GetLifeTimeSaving
{
    public class GetLifeTimeSavingHandler : IRequestHandler<GetLifeTimeSavingQuery, LifeTimeSavingResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetLifeTimeSavingHandler> _logger;
        private readonly ILoyaltyVelocityService _lifeTimeSavingsService;
        private readonly IEventDispatcher _eventDispatcher;
        public GetLifeTimeSavingHandler(ILoyaltyVelocityService lifeTimeSavingsService,
                                    ILogger<GetLifeTimeSavingHandler> logger,
                                    IUnitOfWork context,
                                    IEventDispatcher eventDispatcher)
        {
            _lifeTimeSavingsService = lifeTimeSavingsService;
            _logger = logger;
            _context = context;
            _eventDispatcher = eventDispatcher;
        }

        public async Task<LifeTimeSavingResponseModel> Handle(GetLifeTimeSavingQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            string token = LoyaltyVelocity.TokenProductClub;
            LifeTimeSavingResponseModel responseModel = new();
            string requestvalue = "myClub";
            HttpResponseMessage productClub = await _lifeTimeSavingsService.SendRequest(HttpMethod.Get, requestvalue, null, null, token, null);
            if (productClub.IsSuccessStatusCode)
            {
                string responseData = await productClub.Content.ReadAsStringAsync();
                LifeTimeSavingResponseModel objModel = new LifeTimeSavingResponseModel();
                objModel = JsonConvert.DeserializeObject<LifeTimeSavingResponseModel>(responseData);
                responseModel.Code = objModel.Code;
                responseModel.Status = objModel.Status;
                responseModel.Message = objModel.Message;
                responseModel.payload = objModel.payload;
            }
            return responseModel;
        }
    }
}
