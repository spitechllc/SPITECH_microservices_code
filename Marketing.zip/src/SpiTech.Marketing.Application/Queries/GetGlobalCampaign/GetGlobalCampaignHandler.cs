﻿using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Marketing.Application.Services.Interface;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static SpiTech.Marketing.Domain.Contants;

namespace SpiTech.Marketing.Application.Queries.GetGlobalCampaign
{
    public class GetGlobalCampaignHandler : IRequestHandler<GetGlobalCampaignQuery, GlobalCampaignResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetGlobalCampaignHandler> _logger;
        private readonly ILoyaltyVelocityService _globalCampaignService;
        private readonly IEventDispatcher _eventDispatcher;
        public GetGlobalCampaignHandler(ILoyaltyVelocityService globalCampaignService,
                                    ILogger<GetGlobalCampaignHandler> logger,
                                    IUnitOfWork context,
                                    IEventDispatcher eventDispatcher)
        {
            _globalCampaignService = globalCampaignService;
            _logger = logger;
            _context = context;
            _eventDispatcher = eventDispatcher;
        }

        public async Task<GlobalCampaignResponseModel> Handle(GetGlobalCampaignQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            string token = query.HeaderToken;
            GlobalCampaignResponseModel responseModel = new();
            if (string.IsNullOrEmpty(token))
            {
                responseModel.message = "Invalid token";
                return responseModel;
            }
            string requestvalue = LoyaltyVelocity.GlobalCampaign;
            HttpResponseMessage productClub = await _globalCampaignService.SendRequest(HttpMethod.Get, requestvalue, null, null, token, null);
            if (productClub.IsSuccessStatusCode)
            {
                string responseData = await productClub.Content.ReadAsStringAsync();
                GlobalCampaignResponseModel objModel = new GlobalCampaignResponseModel();
                objModel = JsonConvert.DeserializeObject<GlobalCampaignResponseModel>(responseData);
                responseModel.code = objModel.code;
                responseModel.status = objModel.status;
                responseModel.message = objModel.message;
                responseModel.payload = objModel.payload;

                #region Check and save data

                //if (objModel.payload.data.Count() > 0)
                //{
                //    try
                //    {
                //        foreach (var item in objModel.payload.data)
                //        {
                //            var globalCampaignDetail = await _context.GlobalCampaigns.GetGlobalCampaignById(item.Id);

                //            if (globalCampaignDetail == null)
                //            {
                //                Domain.Entities.GlobalCampaign model = new()
                //                {
                //                    GCId = item.Id,
                //                    Type = item.Type,
                //                    Title = item.Title,
                //                    Description = item.Description,
                //                    ValidStores = item.ValidStores,
                //                    StartDateTime = item.StartDateTime,
                //                    EndDateTime = item.EndDateTime,
                //                    Url = item.Url,
                //                    ImagePath = item.ImagePath,
                //                    TermsAndCondition = item.TermsAndCondition,
                //                    HowToRedeem = item.HowToRedeem,
                //                    IsActivated = item.IsActivated,
                //                    Redeemable = item.Redeemable,
                //                    AdStatus = item.AdStatus,
                //                    AdButtonText = item.AdButtonText,
                //                    PromoType = item.PromoType,
                //                    IsFeatured = item.IsFeatured,
                //                    TotalRedemptions = item.TotalRedemptions,
                //                    FeaturedImagePath = item.FeaturedImagePath,
                //                    EmailNotificationImagePath = item.EmailNotificationImagePath,
                //                    DisplayOrder = item.DisplayOrder,
                //                    ThirdPartyVendorId = Convert.ToInt32(item.ThirdPartyVendorId),
                //                    AgeRestricted = item.ageRestricted,
                //                };
                //                int resellerFeeId = await _context.GlobalCampaigns.Add(model);
                //            }
                //        }
                //        _context.Commit();
                //        responseModel.status = true;
                //    }
                //    catch (Exception ex)
                //    {
                //        responseModel.status = false;
                //        _logger.Error(ex, ex.Message, "GlobalCampaign");
                //        _context.Rollback();
                //    }
                //}
                #endregion
            }
            return responseModel;
        }
    }
}
