﻿using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Marketing.Application.Services.Interface;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static SpiTech.Marketing.Domain.Contants;

namespace SpiTech.Marketing.Application.Queries.GetLocation
{
    public class GetLocationHandler : IRequestHandler<GetLocationQuery, LocationResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetLocationHandler> _logger;
        private readonly ILoyaltyVelocityService _locationService;
        public GetLocationHandler(ILoyaltyVelocityService locationService,
                                    ILogger<GetLocationHandler> logger,
                                    IUnitOfWork context)
        {
            _locationService = locationService;
            _logger = logger;
            _context = context;
        }

        public async Task<LocationResponseModel> Handle(GetLocationQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            string token = query.HeaderToken;
            LocationResponseModel responseModel = new();
            if (string.IsNullOrEmpty(token))
            {
                responseModel.Message = "Invalid token";
                return responseModel;
            }
            string requestvalue = LoyaltyVelocity.GetLocation;
            GetLocationInputModel locationCommand = new GetLocationInputModel();
            locationCommand.type = query.type;
            locationCommand.id = query.id;
            string strjson = ApplicationCore.Helpers.JsonObjectConverter.Serialize(locationCommand);
            HttpContent content = new StringContent(strjson, Encoding.UTF8, "application/json");

            HttpResponseMessage location = await _locationService.SendRequest(HttpMethod.Post, requestvalue, content, null, token, null);
            if (location.IsSuccessStatusCode)
            {
                string responseData = await location.Content.ReadAsStringAsync();
                LocationResponseModel objModel = new LocationResponseModel();
                objModel = JsonConvert.DeserializeObject<LocationResponseModel>(responseData);
                responseModel.Code = objModel.Code;
                responseModel.Status = objModel.Status;
                responseModel.Message = objModel.Message;
                responseModel.payload = objModel.payload;
                if (objModel.payload.locations.Count() > 0)
                {
                    try
                    {
                        responseModel.Status = true;
                    }
                    catch (Exception ex)
                    {
                        responseModel.Status = false;
                        _logger.Error(ex, ex.Message, "Get location");
                        _context.Rollback();
                    }
                }
            }
            return responseModel;
        }
    }
}
