﻿using MediatR;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Queries.GetLocation
{
    public class GetLocationModel
    {
        public string type { get; set; }
        public int? id { get; set; }
    }
    public class GetLocationInputModel : GetLocationModel
    {
    }
    public class GetLocationQuery : GetLocationModel, IRequest<LocationResponseModel>
    {
        public string HeaderToken { get; set; }
    }
}
