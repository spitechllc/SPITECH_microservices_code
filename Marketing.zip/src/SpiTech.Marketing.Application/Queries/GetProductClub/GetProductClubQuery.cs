﻿using MediatR;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Queries.GetProductClub
{
    public class GetProductClubModel
    {
        public string HeaderToken { get; set; }
    }
    public class GetProductClubQuery : GetProductClubModel, IRequest<ProductClubResponseModel>
    {
    }
}
