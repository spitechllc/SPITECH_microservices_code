﻿using MediatR;
using Newtonsoft.Json;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static SpiTech.Marketing.Domain.Contants;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Marketing.Application.Services.Interface;

namespace SpiTech.Marketing.Application.Queries.GetProductClub
{
    public class GetProductClubHandler : IRequestHandler<GetProductClubQuery, ProductClubResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetProductClubHandler> _logger;
        private readonly ILoyaltyVelocityService _productClubService;
        private readonly IEventDispatcher _eventDispatcher;
        public GetProductClubHandler(ILoyaltyVelocityService productClubService,
                                    ILogger<GetProductClubHandler> logger,
                                    IUnitOfWork context,
                                    IEventDispatcher eventDispatcher)
        {
            _productClubService = productClubService;
            _logger = logger;
            _context = context;
            _eventDispatcher = eventDispatcher;
        }

        public async Task<ProductClubResponseModel> Handle(GetProductClubQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            string token = query.HeaderToken;
            ProductClubResponseModel responseModel = new();
            if (string.IsNullOrEmpty(token))
            {
                responseModel.Message = "Invalid token";
                return responseModel;
            }
            string requestvalue = LoyaltyVelocity.ProductClub;
            HttpResponseMessage productClub = await _productClubService.SendRequest(HttpMethod.Get, requestvalue, null, null, token, null);
            if (productClub.IsSuccessStatusCode)
            {
                string responseData = await productClub.Content.ReadAsStringAsync();
                ProductClubResponseModel objModel = new ProductClubResponseModel();
                objModel = JsonConvert.DeserializeObject<ProductClubResponseModel>(responseData);
                responseModel.Code = objModel.Code;
                responseModel.Status = objModel.Status;
                responseModel.Message = objModel.Message;
                responseModel.Payload = objModel.Payload;
                if (objModel.Payload.data.Count() > 0)
                {
                    //try
                    //{
                    //    foreach (var item in objModel.Payload.data)
                    //    {
                    //        var productClubDetail = await _context.ProductClubs.GetByProductClubId(item.ProductClubId);

                    //        if (productClubDetail == null)
                    //        {
                    //            Domain.Entities.ProductClub model = new()
                    //            {
                    //                ProductClubId = item.ProductClubId,
                    //                Title = item.Title,
                    //                Threshold = item.Threshold,
                    //                Description = item.Description,
                    //                Availed = item.Availed,
                    //                Image = Convert.ToString(item.Image),
                    //                ClubReward = item.ClubReward,
                    //                Status = item.Status,
                    //                HomeImagePath = item.HomeImagePath,
                    //                ImagePath = item.ImagePath,
                    //                DisplayOrder = item.DisplayOrder,
                    //                RedemptionImagePath = item.RedemptionImagePath,
                    //                TertiaryImagePath = item.TertiaryImagePath,
                    //                EmailNotificationImagePath = item.EmailNotificationImagePath,
                    //                SecondaryImagePath = item.ImagePath,
                    //                ValidStores = item.ImagePath
                    //            };
                    //            int resellerFeeId = await _context.ProductClubs.Add(model);
                    //        }
                    //    }
                    //    _context.Commit();
                    //    responseModel.Status = true;
                    //}
                    //catch (Exception ex)
                    //{
                    //    responseModel.Status = false;
                    //    _logger.Error(ex, ex.Message, "Handle GetProductClubQuery");
                    //    _context.Rollback();
                    //    await DispatchActivityLogEvent(_authenticationProvider.GetUserAuthentication()?.UserId ?? 0, (int)ActivityType.CreateResellerFee, "ResellerFee Creation from Default Failed.", true, ex.Message);
                    //}
                }
            }
            return responseModel;
        }

        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, bool? isError, string errorMessage)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress(),
                IsError = isError,
                ErrorMessage = errorMessage

            });
        }
    }
}
