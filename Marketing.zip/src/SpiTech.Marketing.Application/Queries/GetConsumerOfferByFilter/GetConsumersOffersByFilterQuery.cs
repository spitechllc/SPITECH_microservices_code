﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Marketing.Domain.Enums;
using SpiTech.Marketing.Domain.Models;

namespace SpiTech.Marketing.Application.Queries.GetConsumerOfferByFilter
{
    public class GetConsumerOfferByFilterQuery : IRequest<ResponseList<ConsumerOfferSearchResult>>
    {
        public int? OffereId { get; set; }
        public int? UserId { get; set; }
        public ConsumerOfferSortBy? SortBy { get; set; }
        public SortOrderEnum? SortOrder { get; set; }
    }
}
