﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Queries.GetLoyaltyById
{
    public class GetLoyaltyByIdHandler : IRequestHandler<GetLoyaltyByIdQuery, LoyaltyModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetLoyaltyByIdHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetLoyaltyByIdHandler(IUnitOfWork context,
                                   ILogger<GetLoyaltyByIdHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<LoyaltyModel> Handle(GetLoyaltyByIdQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            LoyaltyModel loyaltylist = _mapper.Map<LoyaltyModel>(await _context.Loyalties.GetLoyaltyById(query.LoyaltyId));

            _logger.TraceExitMethod(nameof(Handle), query);
            return loyaltylist;
        }


    }
}
