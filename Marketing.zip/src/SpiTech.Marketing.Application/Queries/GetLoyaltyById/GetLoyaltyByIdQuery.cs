﻿using MediatR;
using SpiTech.Marketing.Domain.Models;

namespace SpiTech.Marketing.Application.Queries.GetLoyaltyById
{
    public class GetLoyaltyByIdQuery : IRequest<LoyaltyModel>
    {
        public int LoyaltyId { get; set; }
    }
}
