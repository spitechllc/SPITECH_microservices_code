﻿using MediatR;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Marketing.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.Marketing.Application.Queries.GetCashBackEvent
{
    public class GetCashBackEventQuery : IRequest<IEnumerable<CashBackEventModel>>
    {
        public CreditType creditType { get; set; }
    }
}
