﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Queries.GetCashBackEvent
{
    public class GetCashBackEventHandler : IRequestHandler<GetCashBackEventQuery, IEnumerable<CashBackEventModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetCashBackEventHandler> _logger;
        private readonly IMapper _mapper;
        public GetCashBackEventHandler(IUnitOfWork context,
                                    ILogger<GetCashBackEventHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<IEnumerable<CashBackEventModel>> Handle(GetCashBackEventQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<CashBackEventModel> result = await _context.CashBackEvents.GetEvent((int)request.creditType);

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
