﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Marketing.Domain.Models;

namespace SpiTech.Marketing.Application.Queries.GetScheduledConsumersOffer
{
    public class GetScheduledConsumerOfferQuery : IRequest<ResponseList<ConsumerOfferSearchResult>>
    {
    }
}
