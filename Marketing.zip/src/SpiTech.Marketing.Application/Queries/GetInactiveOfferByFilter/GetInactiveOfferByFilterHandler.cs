﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Queries.GetInactiveOfferByFilter
{
    public class GetInactiveOfferByFilterHandler : IRequestHandler<GetInactiveOfferByFilterQuery, PaginatedList<OfferModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetInactiveOfferByFilterHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider _authenticationProvider;
        private readonly IStoreServiceClient _storeServiceClient;
        public GetInactiveOfferByFilterHandler(IUnitOfWork context,
                                   ILogger<GetInactiveOfferByFilterHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper,
                                   IUserAuthenticationProvider authenticationProvider,
                                   IStoreServiceClient storeServiceClient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _authenticationProvider = authenticationProvider;
            _storeServiceClient = storeServiceClient;
        }

        public async Task<PaginatedList<OfferModel>> Handle(GetInactiveOfferByFilterQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            ICollection<StoresSearchModel> allstoreDetails = new List<StoresSearchModel>();

            GetStoresForDashboardQuery request = new GetStoresForDashboardQuery();
            request.StateId = 0;
            request.StoreGroupIds = new List<int>();
            request.UserId = _authenticationProvider.GetUserAuthentication().UserId;

            allstoreDetails = (await _storeServiceClient.GetStoresForDashboard(request)).Data ?? new List<StoresSearchModel>();

            int[] StoreIds = new List<int>().ToArray();

            if (allstoreDetails != null)
            {
                StoreIds = allstoreDetails.Select(t => t.StoreId).Distinct().ToArray();
            }

            System.Collections.Generic.List<OfferModel> offerslist = await _context.Offers.GetInactiveOffersByFilter(query.OfferId, query.StoreId, query.StoreName, query.OfferDeal, query.PageIndex, query.PageSize, query.sortable?.SortBy, query.sortable?.SortOrder, StoreIds);

            _logger.TraceExitMethod(nameof(Handle), query);
            return new PaginatedList<OfferModel>
            {
                Data = offerslist,
                PageIndex = query.PageIndex ?? 0,
                PageSize = query.PageSize ?? 0,
                TotalCount = offerslist?.FirstOrDefault()?.TotalRecord ?? 0
            };
        }
    }
}
