﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Marketing.Domain.Models;

namespace SpiTech.Marketing.Application.Queries.GetInactiveOfferByFilter
{
    public class GetInactiveOfferByFilterQuery : IRequest<PaginatedList<OfferModel>>
    {
        public int? OfferId { get; set; }
        public int? StoreId { get; set; }
        public string StoreName { get; set; }
        public string OfferDeal { get; set; }
        public int? PageIndex { get; set; }
        public int? PageSize { get; set; }
        public Sortable sortable { get; set; }
    }
}
