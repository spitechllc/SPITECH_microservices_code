﻿using MediatR;
using SpiTech.Marketing.Domain.Models;

namespace SpiTech.Marketing.Application.Queries.GetPromotionById
{
    public class GetPromotionByIdQuery : IRequest<PromotionModel>
    {
        public int PromotionId { get; set; }
    }
}
