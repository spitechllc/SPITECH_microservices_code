﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Queries.GetPromotionById
{
    public class GetPromotionByIdHandler : IRequestHandler<GetPromotionByIdQuery, PromotionModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetPromotionByIdHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetPromotionByIdHandler(IUnitOfWork context,
                                   ILogger<GetPromotionByIdHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<PromotionModel> Handle(GetPromotionByIdQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            PromotionModel promotionlist = _mapper.Map<PromotionModel>(await _context.Promotions.GetPromotionById(query.PromotionId));

            _logger.TraceExitMethod(nameof(Handle), query);
            return promotionlist;
        }
    }
}
