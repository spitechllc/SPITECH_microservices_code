﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Marketing.Domain.Models;

namespace SpiTech.Marketing.Application.Queries.GetRules
{
    public class GetRulesQuery : IRequest<ResponseList<CashBackRuleModel>>
    {
        public string TenantName { get; set; }
        public int? CreditIdentifier { get; set; }
        public EventBus.DomainEvents.Enums.CreditType? CreditType { get; set; }
    }
}
