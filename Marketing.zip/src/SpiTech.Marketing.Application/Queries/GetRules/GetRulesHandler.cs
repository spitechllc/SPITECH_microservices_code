﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Queries.GetRules
{
    public class GetRulesHandler : IRequestHandler<GetRulesQuery, ResponseList<CashBackRuleModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetRulesHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetRulesHandler(IUnitOfWork context,
                                   ILogger<GetRulesHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<ResponseList<CashBackRuleModel>> Handle(GetRulesQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            ResponseList<CashBackRuleModel> responseList = new();
            List<CashBackRuleModel> data = new();

            if (!query.CreditType.HasValue || query.CreditType == EventBus.DomainEvents.Enums.CreditType.Promotion)
            {
                List<CashBackRuleModel> promotions = await _context.Promotions.GetCashBackRuleModels(query.TenantName,query.CreditIdentifier);
                if (promotions != null)
                {
                    data.AddRange(promotions);
                }
            }

            if (!query.CreditType.HasValue || query.CreditType == EventBus.DomainEvents.Enums.CreditType.Loyalty)
            {
                List<CashBackRuleModel> loyalties = await _context.Loyalties.GetCashBackRuleModels(query.CreditIdentifier);

                if (loyalties != null)
                {
                    foreach (CashBackRuleModel rule in loyalties)
                    {
                        rule.StartDate = System.DateTime.UtcNow;
                        rule.EndDate = System.DateTime.UtcNow.AddDays(rule.ExpireDays);
                    }

                    data.AddRange(loyalties);
                }
            }
            responseList.Data = data.OrderBy(t => t.DisplayOrder);
            _logger.TraceExitMethod(nameof(Handle), query);
            return responseList;
        }
    }
}
