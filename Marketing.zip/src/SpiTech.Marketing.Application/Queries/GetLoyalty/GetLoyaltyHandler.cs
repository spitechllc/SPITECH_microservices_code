﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Queries.GetLoyalty
{
    public class GetLoyaltyHandler : IRequestHandler<GetLoyaltyQuery, PaginatedList<LoyaltyModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetLoyaltyHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetLoyaltyHandler(IUnitOfWork context,
                                   ILogger<GetLoyaltyHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<PaginatedList<LoyaltyModel>> Handle(GetLoyaltyQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            System.Collections.Generic.List<LoyaltyModel> loyaltylist = await _context.Loyalties.GetAllLoyalty(query.PageIndex, query.PageSize, query.sortable?.SortBy, query.sortable?.SortOrder);
            var count = loyaltylist.Count;
            _logger.TraceExitMethod(nameof(Handle), query);
            return new PaginatedList<LoyaltyModel>
            {
                Data = loyaltylist,
                PageIndex = query.PageIndex ?? 0,
                PageSize = query.PageSize ?? 0,
                TotalCount = count
            };
        }
    }
}
