﻿using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Marketing.Application.Services.Interface;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Queries.GetAdvertisement
{
    public class GetAdvertisementHandler : IRequestHandler<GetAdvertisementQuery, AdvertisementResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetAdvertisementHandler> _logger;
        private readonly ILoyaltyVelocityService _advertisementService;
        public GetAdvertisementHandler(ILoyaltyVelocityService advertisementService,
                                    ILogger<GetAdvertisementHandler> logger,
                                    IUnitOfWork context)
        {
            _advertisementService = advertisementService;
            _logger = logger;
            _context = context;
        }

        public async Task<AdvertisementResponseModel> Handle(GetAdvertisementQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            string token = query.HeaderToken;
            AdvertisementResponseModel responseModel = new();
            if (string.IsNullOrEmpty(token))
            {
                responseModel.Message = "Invalid token";
                return responseModel;
            }
            string requestvalue = "advertisements";
            HttpResponseMessage productClub = await _advertisementService.SendRequest(HttpMethod.Get, requestvalue, null, null, token, null);
            if (productClub.IsSuccessStatusCode)
            {
                string responseData = await productClub.Content.ReadAsStringAsync();
                AdvertisementResponseModel objModel = new AdvertisementResponseModel();
                objModel = JsonConvert.DeserializeObject<AdvertisementResponseModel>(responseData);
                responseModel.Code = objModel.Code;
                responseModel.Status = objModel.Status;
                responseModel.Message = objModel.Message;
                responseModel.payload = objModel.payload;

                //if (responseModel.Status == true)
                //{
                //    try
                //    {
                //        foreach (var item in responseModel.payload.promos)
                //        {
                //            var exist = await _context.Advertisements.GetAdvertisementById(item.AdvertisementId);
                //            if (exist == null)
                //            {
                //                Domain.Entities.Advertisement model = new()
                //                {
                //                    AdvertisementId = item.AdvertisementId,
                //                    Title = item.Title,
                //                    Description = item.Description,
                //                    StartDateTime = item.StartDateTime.ToString() ?? "",
                //                    EndDateTime = Convert.ToString(item.EndDateTime),
                //                    Url = item.Url,
                //                    ImagePath = item.ImagePath,
                //                    AdStatus = item.AdStatus,
                //                    AdButtonText = item.AdButtonText,
                //                    IsFeatured = item.IsFeatured,
                //                    SecondaryImagePath = item.SecondaryImagePath,
                //                    AgeRestricted = item.AgeRestricted,
                //                    ValidStores = Convert.ToString(item.ValidStores)
                //                };
                //                int advertise = await _context.Advertisements.Add(model);
                //            }
                //        }
                //        _context.Commit();
                //        responseModel.Status = true;
                //    }
                //    catch (Exception ex)
                //    {
                //        responseModel.Status = false;
                //        _logger.Error(ex, ex.Message, "Handle GetAdvertisementHandler");
                //        _context.Rollback();
                //    }
                //}
            }
            return responseModel;
        }
    }
}
