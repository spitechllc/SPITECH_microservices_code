﻿using MediatR;
using SpiTech.Marketing.Domain.Entities;
using System.Collections.Generic;

namespace SpiTech.Marketing.Application.Queries.GetCashBackCriteriaByEventId
{
    public class GetCashBackCriteriaByEventIdQuery : IRequest<IEnumerable<CashBackCriteria>>
    {
        public int EventId { get; set; }
    }
}
