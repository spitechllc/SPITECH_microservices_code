﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Entities;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Queries.GetCashBackCriteriaByEventId
{
    public class GetCashBackCriteriaByEventIdHandler : IRequestHandler<GetCashBackCriteriaByEventIdQuery, IEnumerable<CashBackCriteria>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetCashBackCriteriaByEventIdHandler> _logger;
        private readonly IMapper _mapper;
        public GetCashBackCriteriaByEventIdHandler(IUnitOfWork context,
                                    ILogger<GetCashBackCriteriaByEventIdHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<IEnumerable<CashBackCriteria>> Handle(GetCashBackCriteriaByEventIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<CashBackCriteria> result = await _context.CashBackCriterias.GetCriteriaByEventId(request.EventId);

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
