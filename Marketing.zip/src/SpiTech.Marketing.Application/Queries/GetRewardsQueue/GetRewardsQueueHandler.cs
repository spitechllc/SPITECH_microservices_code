﻿using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Marketing.Application.Services.Interface;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static SpiTech.Marketing.Domain.Contants;

namespace SpiTech.Marketing.Application.Queries.GetRewardsQueue
{
    public class GetRewardsQueueHandler : IRequestHandler<GetRewardsQueueQuery, RewardsQueueResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetRewardsQueueHandler> _logger;
        private readonly ILoyaltyVelocityService _rewardsQueueService;
        private readonly IEventDispatcher _eventDispatcher;
        public GetRewardsQueueHandler(ILoyaltyVelocityService rewardsQueueService,
                                    ILogger<GetRewardsQueueHandler> logger,
                                    IUnitOfWork context,
                                    IEventDispatcher eventDispatcher)
        {
            _rewardsQueueService = rewardsQueueService;
            _logger = logger;
            _context = context;
            _eventDispatcher = eventDispatcher;
        }

        public async Task<RewardsQueueResponseModel> Handle(GetRewardsQueueQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            string token = query.HeaderToken;
            RewardsQueueResponseModel responseModel = new();
            if (string.IsNullOrEmpty(token))
            {
                responseModel.Message = "Invalid token";
                return responseModel;
            }
            string requestvalue = LoyaltyVelocity.RewardsQueue;
            HttpResponseMessage productClub = await _rewardsQueueService.SendRequest(HttpMethod.Get, requestvalue, null, null, token, null);
            if (productClub.IsSuccessStatusCode)
            {
                string responseData = await productClub.Content.ReadAsStringAsync();
                RewardsQueueResponseModel objModel = new RewardsQueueResponseModel();
                objModel = JsonConvert.DeserializeObject<RewardsQueueResponseModel>(responseData);
                responseModel.Code = objModel.Code;
                responseModel.Status = objModel.Status;
                responseModel.Message = objModel.Message;
                responseModel.payload = objModel.payload;
                if (objModel.payload.Count() > 0)
                {
                    try
                    {
                        responseModel.Status = true;
                    }
                    catch (Exception ex)
                    {
                        responseModel.Status = false;
                        _logger.Error(ex, ex.Message, "Handle Rewards Queue Service");
                        _context.Rollback();
                    }
                }
            }
            return responseModel;
        }

    }
}
