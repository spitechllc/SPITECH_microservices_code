﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Queries.SearchOffersDealsByFilter
{
    public class SearchOfferByFilterHandler : IRequestHandler<SearchOfferByFilterQuery, ResponseList<OfferModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<SearchOfferByFilterHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public SearchOfferByFilterHandler(IUnitOfWork context,
                                   ILogger<SearchOfferByFilterHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<ResponseList<OfferModel>> Handle(SearchOfferByFilterQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            IEnumerable<OfferModel> offerslist = _mapper.Map<IEnumerable<OfferModel>>(await _context.Offers.SearchOfferByFilter(query.StoreName, query.description));

            _logger.TraceExitMethod(nameof(Handle), query);
            return new ResponseList<OfferModel> { Data = offerslist.ToList() };
        }


    }
}
