﻿
using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Marketing.Domain.Models;

namespace SpiTech.Marketing.Application.Queries.SearchOffersDealsByFilter
{
    public class SearchOfferByFilterQuery : IRequest<ResponseList<OfferModel>>
    {
        public string StoreName { get; set; }
        public string description { get; set; }
    }
}
