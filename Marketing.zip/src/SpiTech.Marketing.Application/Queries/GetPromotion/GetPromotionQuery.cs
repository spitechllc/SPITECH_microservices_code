﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Marketing.Domain.Models;

namespace SpiTech.Marketing.Application.Queries.GetPromotion
{
    public class GetPromotionQuery : IRequest<PaginatedList<PromotionModel>>
    {
        public int? PageIndex { get; set; }
        public int? PageSize { get; set; }
        public Sortable sortable { get; set; }
    }
}
