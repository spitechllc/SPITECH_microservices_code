﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Queries.GetPromotion
{
    public class GetPromotionHandler : IRequestHandler<GetPromotionQuery, PaginatedList<PromotionModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetPromotionHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetPromotionHandler(IUnitOfWork context,
                                   ILogger<GetPromotionHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<PaginatedList<PromotionModel>> Handle(GetPromotionQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            System.Collections.Generic.List<PromotionModel> promotionlist = await _context.Promotions.GetAllPromotion(query.PageIndex, query.PageSize, query.sortable?.SortBy, query.sortable?.SortOrder);

            _logger.TraceExitMethod(nameof(Handle), query);
            return new PaginatedList<PromotionModel>
            {
                Data = promotionlist,
                PageIndex = query.PageIndex ?? 0,
                PageSize = query.PageSize ?? 0,
                TotalCount = promotionlist[0].TotalRecord
            };
        }


    }
}
