﻿using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Marketing.Application.Services.Interface;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static SpiTech.Marketing.Domain.Contants;

namespace SpiTech.Marketing.Application.Queries.GetPromotionVelocity
{
    public class GetPromotionVelocityHandler : IRequestHandler<GetPromotionVelocityQuery, PromotionResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetPromotionVelocityHandler> _logger;
        private readonly ILoyaltyVelocityService _loyaltyVelocityService;

        public GetPromotionVelocityHandler(IUnitOfWork context,
            ILogger<GetPromotionVelocityHandler> logger,
            ILoyaltyVelocityService loyaltyVelocityService)
        {
            _context = context;
            _logger = logger;
            _loyaltyVelocityService = loyaltyVelocityService;
        }

        public async Task<PromotionResponseModel> Handle(GetPromotionVelocityQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            string token = query.HeaderToken;
            PromotionResponseModel responseModel = new();
            if (string.IsNullOrEmpty(token))
            {
                responseModel.Message = "Invalid token";
                return responseModel;
            }
            string requestvalue = LoyaltyVelocity.PromotionsVL;
            HttpResponseMessage promotionVelocity = await _loyaltyVelocityService.SendRequest(HttpMethod.Get, requestvalue, null, null, token, null);
            if (promotionVelocity.IsSuccessStatusCode)
            {
                string responseData = await promotionVelocity.Content.ReadAsStringAsync();
                PromotionResponseModel objModel = new PromotionResponseModel();
                objModel = JsonConvert.DeserializeObject<PromotionResponseModel>(responseData);
                responseModel.Code = objModel.Code;
                responseModel.Status = objModel.Status;
                responseModel.Message = objModel.Message;
                responseModel.payload = objModel.payload;
            }
            return responseModel;
        }
    }
}
