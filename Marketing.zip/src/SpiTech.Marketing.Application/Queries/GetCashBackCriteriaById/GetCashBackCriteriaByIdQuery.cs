﻿using MediatR;
using SpiTech.Marketing.Domain.Entities;

namespace SpiTech.Marketing.Application.Queries.GetCashBackCriteriaById
{
    public class GetCashBackCriteriaByIdQuery : IRequest<CashBackCriteria>
    {
        public int CriteriaId { get; set; }
    }
}
