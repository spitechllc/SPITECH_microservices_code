﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Queries.GetCashBackCriteriaById
{
    public class GetCashBackCriteriaByIdHandler : IRequestHandler<GetCashBackCriteriaByIdQuery, CashBackCriteria>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetCashBackCriteriaByIdHandler> _logger;
        private readonly IMapper _mapper;
        public GetCashBackCriteriaByIdHandler(IUnitOfWork context,
                                    ILogger<GetCashBackCriteriaByIdHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<CashBackCriteria> Handle(GetCashBackCriteriaByIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            CashBackCriteria result = await _context.CashBackCriterias.GetCriteriaById(request.CriteriaId);

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
