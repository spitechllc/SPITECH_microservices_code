﻿using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents;
using SpiTech.Marketing.Application.Services.Interface;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Queries.GetReward
{
    public class GetRewardHandler : IRequestHandler<GetRewardQuery, RewardResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetRewardHandler> _logger;
        private readonly ILoyaltyVelocityService _rewardService;
        private readonly IEventDispatcher _eventDispatcher;
        public GetRewardHandler(ILoyaltyVelocityService rewardService,
                                    ILogger<GetRewardHandler> logger,
                                    IUnitOfWork context,
                                    IEventDispatcher eventDispatcher)
        {
            _rewardService = rewardService;
            _logger = logger;
            _context = context;
            _eventDispatcher = eventDispatcher;
        }

        public async Task<RewardResponseModel> Handle(GetRewardQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);
            string token = query.HeaderToken;
            RewardResponseModel responseModel = new();
            if (string.IsNullOrEmpty(token))
            {
                responseModel.Message = "Invalid token";
                return responseModel;
            }
            string requestvalue = "rewards";
            HttpResponseMessage rewardsClub = await _rewardService.SendRequest(HttpMethod.Get, requestvalue, null, null, token, null);
            if (rewardsClub.IsSuccessStatusCode)
            {
                string responseData = await rewardsClub.Content.ReadAsStringAsync();
                RewardResponseModel objModel = new RewardResponseModel();
                objModel = JsonConvert.DeserializeObject<RewardResponseModel>(responseData);
                responseModel.Code = objModel.Code;
                responseModel.Status = objModel.Status;
                responseModel.Message = objModel.Message;
                responseModel.payload = objModel.payload;

                if (objModel.payload.data.Count() > 0)
                {
                    try
                    {
                        responseModel.Status = objModel.Status;
                    }
                    catch (Exception ex)
                    {
                        responseModel.Status = false;
                        _logger.Error(ex, ex.Message, "Handle GetRewards");
                        _context.Rollback();
                    }
                }
            }
            return responseModel;
        }

    }
}
