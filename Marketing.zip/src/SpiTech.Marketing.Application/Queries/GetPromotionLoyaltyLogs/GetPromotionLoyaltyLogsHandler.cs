﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Models;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Application.Queries.GetPromotionLoyaltyLogs
{
    public class GetPromotionLoyaltyLogsHandler : IRequestHandler<GetPromotionLoyaltyLogsQuery, PaginatedList<PromotionLoyaltyLogModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetPromotionLoyaltyLogsHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetPromotionLoyaltyLogsHandler(IUnitOfWork context,
                                   ILogger<GetPromotionLoyaltyLogsHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<PaginatedList<PromotionLoyaltyLogModel>> Handle(GetPromotionLoyaltyLogsQuery query, CancellationToken cancel)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            System.Collections.Generic.List<PromotionLoyaltyLogModel> result = await _context.PromotionLoyaltyLogs.GetPromotionLoyaltyLogs(query.PageIndex,
                query.PageSize,
                query.UserId,
                query.IsFailure,
                query.From,
                query.To);

            PaginatedList<PromotionLoyaltyLogModel> responseList = new()
            {
                Data = result,
                PageIndex = query.PageIndex,
                PageSize = query.PageSize,
                TotalCount = result?.FirstOrDefault().TotalRecord ?? 0
            };

            _logger.TraceExitMethod(nameof(Handle), responseList);

            return responseList;
        }
    }
}
