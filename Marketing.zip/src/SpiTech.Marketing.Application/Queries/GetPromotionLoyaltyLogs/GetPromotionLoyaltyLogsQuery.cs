﻿using MediatR;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Marketing.Domain.Models;
using System;

namespace SpiTech.Marketing.Application.Queries.GetPromotionLoyaltyLogs
{
    public class GetPromotionLoyaltyLogsQuery : IRequest<PaginatedList<PromotionLoyaltyLogModel>>
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public int? UserId { get; set; }
        public bool? IsFailure { get; set; }
        public DateTime From { get; set; }
        public DateTime To { get; set; }
    }
}
