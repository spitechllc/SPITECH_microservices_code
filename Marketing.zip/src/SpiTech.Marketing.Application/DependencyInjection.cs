﻿using FluentValidation;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.ApplicationCore.AppSettingsConfigLoader;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Marketings;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.EventBus.DomainEvents.ServiceCollection;
using SpiTech.Marketing.Application.EventConsumer;
using SpiTech.Marketing.Application.Processors;
using SpiTech.Marketing.Application.Services;
using SpiTech.Marketing.Application.Services.Interface;
using SpiTech.Marketing.Domain.Configs;
using SpiTech.Marketing.Domain.Mappers;
using System.Reflection;

namespace SpiTech.Marketing.Application
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddConfig<LoyaltyConsumerConfiguration>(configuration);
            services.AddConfig<AppDownload>(configuration);
            services
                .AddMediatR(Assembly.GetExecutingAssembly()).AddAutoMapper(typeof(ConsumerOfferProfile))
                .AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());
            // services.AddTransient<IMarketingServices, MarketingServices>();

            services.AddTransient<IPromotionProcessor, PromotionProcessor>();
            services.AddTransient<ILoyaltyProcessor, LoyaltyProcessor>();
            services.AddTransient<ILoyaltyRegistrationService, LoyaltyRegistrationService>();
            services.AddTransient<ILoginService, LoginService>();
            services.AddTransient<ILoyaltyVelocityService, LoyaltyVelocityService>();
            

            // MassTransit-RabbitMQ Configuration
            services.RegisterMessageQueue(configuration, config =>
            {
                config.AddConsumer<FinalizeRequestEventConsumer>();
                config.AddConsumer<PaymentMethodAddedEventConsumer>();
            }, (ctx, cfg) =>
            {
                cfg.ConfigurePublishEvent<ConsumerOfferSendEvent>();
                cfg.ConfigurePublishEvent<PromotionLoyaltyEvent>();

                cfg.BindConsumer<FinalizeRequestEvent, FinalizeRequestEventConsumer>(ctx, EventBusConstants.MarketingService);
                cfg.BindConsumer<PaymentMethodAddedEvent, PaymentMethodAddedEventConsumer>(ctx, EventBusConstants.MarketingService);

            });

            return services;
        }
    }
}