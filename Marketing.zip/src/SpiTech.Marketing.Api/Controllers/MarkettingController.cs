﻿using ChoETL;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Marketing.Application.Commands.CreateAppDownload;
using SpiTech.Marketing.Domain.Configs;
using System.Globalization;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Api.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    public class MarkettingController : Controller
    {
        private readonly ILogger<MarkettingController> _logger;
        private readonly AppDownload appDownload;
        private readonly MediatR.IMediator _mediator;
        public MarkettingController(AppDownload appDownload, SpiTech.Application.Logging.Interfaces.ILogger<MarkettingController> logger, IMediator mediator)
        {
            this.appDownload = appDownload;
            _logger = logger;
            _mediator = mediator;
        }
        /// <summary>
        /// Appdownload is provide a link to download the SpiTech application based on scanning device type.
        /// </summary>
        /// <param name="code">Varriable of string</param>
        [AllowAnonymous]
        [HttpGet("Appdownload")]
        public async Task Appdownload([FromQuery] string code)
        {
            _logger.TraceEnterMethod("AppDownload", HttpContext.Request.Headers);

            string useragent = HttpContext.Request.Headers.GetValue("User-Agent", true, CultureInfo.InvariantCulture);

            _logger.Trace("AppDownload", useragent);

            var redirectUrl = appDownload.android;

            var createAppDownloadCommand = new CreateAppDownloadCommand
            {
                Code = code,
                Request = Request,
            };

            if (useragent.Contains("iPhone", System.StringComparison.InvariantCultureIgnoreCase) 
                || useragent.Contains("IPad", System.StringComparison.InvariantCultureIgnoreCase)
                || useragent.Contains("IOS", System.StringComparison.InvariantCultureIgnoreCase)
                || useragent.Contains("Macintosh", System.StringComparison.InvariantCultureIgnoreCase))
            {
                redirectUrl = appDownload.ios;
            }

            createAppDownloadCommand.ResponseUrl = redirectUrl;
            await _mediator.Send(createAppDownloadCommand);

            _logger.TraceExitMethod("AppDownload", HttpContext.Request);

            HttpContext.Response.Redirect(redirectUrl);
            //Redirect(redirectUrl);
        }

        //[AllowAnonymous]
        ////[ApiPermissionAuthorize(Permissions = "Marketingapi_Marketting_Appdownload")]
        //[HttpGet("Appdownload")]
        //public void Appdownload([FromQuery] string code)
        //{
        //    string useragent = HttpContext.Request.Headers["User-Agent"].ToString();

        //    if (useragent.Contains("android"))
        //    {
        //        HttpContext.Response.Redirect("https://SpiTech.com/");
        //    }
        //    else if (useragent.Contains("android"))
        //    {
        //        HttpContext.Response.Redirect("https://SpiTech.com/");
        //    }
        //    else
        //    {
        //        HttpContext.Response.Redirect("https://apps.apple.com/us/app/SpiTech/id1570455705");
        //    }
        //}
    }
}
