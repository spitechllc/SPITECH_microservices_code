﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Marketing.Application.Commands.RetryCashbackProcess;
using SpiTech.Marketing.Application.Queries.GetPromotionLoyaltyLogs;
using SpiTech.Marketing.Application.Queries.GetRules;
using SpiTech.Marketing.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Marketing.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class CashBackController : ControllerBase
    {
        private readonly IMediator _mediator;

        public CashBackController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Api returns list of rules through which a consumer can avail cash back 
        /// </summary>
        /// <param name="query">Object of GetRulesQuery</param>
        /// <returns>It will return ResponseList in the form CashBackRuleModel</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_CashBack_rules")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("rules")]
        public async Task<ActionResult<ResponseList<CashBackRuleModel>>> GetRules([FromQuery] GetRulesQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Api returns list of events with corresponding data through which cash back is credited to consumers wallet
        /// </summary>
        /// <param name="query">Object of GetPromotionLoyaltyLogsQuery</param>
        /// <returns>It will return PaginatedList in the form PromotionLoyaltyLogModel</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_CashBack_PromotionLoyaltyLog")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("PromotionLoyaltyLog")]
        public async Task<ActionResult<PaginatedList<PromotionLoyaltyLogModel>>> GetPromotionLoyaltyLogs([FromQuery] GetPromotionLoyaltyLogsQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to retry cash back process if cash back is not successfully credited to consumer's wallet
        /// </summary>
        /// <param name="command">Object of RetryCashbackProcessCommand</param>
        /// <returns>It will return in the form ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_CashBack_retry")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("retry")]
        public async Task<ActionResult<ResponseModel>> RetryCashbackProcess([FromBody] RetryCashbackProcessCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }
    }
}
