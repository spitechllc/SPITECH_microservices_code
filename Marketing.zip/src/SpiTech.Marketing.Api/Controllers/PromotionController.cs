﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Marketing.Application.Commands.CreatePromotion;
using SpiTech.Marketing.Application.Commands.UpdatePromotion;
using SpiTech.Marketing.Application.Queries.GetPromotion;
using SpiTech.Marketing.Application.Queries.GetPromotionById;
using SpiTech.Marketing.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Marketing.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class PromotionController : ControllerBase
    {
        private readonly IMediator _mediator;

        public PromotionController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Method will create new Promotion
        /// </summary>
        /// <param name="command">Object of CreatePromotionCommand</param>
        /// <returns>It will return in the form of int</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_Promotion_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost]
        public async Task<ActionResult<int>> Post([FromBody] CreatePromotionCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will update existing Promotion
        /// </summary>
        /// <param name="command">Object of UpdatePromotionCommand</param>
        /// <returns>It will return in the form of bool</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_Promotion_Patch")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch]
        public async Task<ActionResult<bool>> Update([FromBody] UpdatePromotionCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will return list of Promotions
        /// </summary>
        /// <param name="query">Object of GetPromotionQuery</param>
        /// <returns>It will return PaginatedList in the form of PromotionModel</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_Promotion_GetPromotion")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetPromotion")]
        public async Task<ActionResult<PaginatedList<PromotionModel>>> GetPromotion([FromQuery] GetPromotionQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will return list of Promotion by Promotion Id.
        /// </summary>
        /// <param name="query">Object of GetPromotionByIdQuery</param>
        /// <returns>It will return in the form of PromotionModel</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_Promotion_GetById")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetById")]
        public async Task<ActionResult<PromotionModel>> GetPromotionById([FromQuery] GetPromotionByIdQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }
    }
}
