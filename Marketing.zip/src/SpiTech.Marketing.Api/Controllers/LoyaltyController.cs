﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Marketing.Application.Commands.CreateLoyalty;
using SpiTech.Marketing.Application.Commands.UpdateLoyalty;
using SpiTech.Marketing.Application.Queries.GetCashBackCriteriaByEventId;
using SpiTech.Marketing.Application.Queries.GetCashBackCriteriaById;
using SpiTech.Marketing.Application.Queries.GetCashBackEvent;
using SpiTech.Marketing.Application.Queries.GetLoyalty;
using SpiTech.Marketing.Application.Queries.GetLoyaltyById;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Models;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Marketing.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class LoyaltyController : ControllerBase
    {
        private readonly IMediator _mediator;

        public LoyaltyController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Method will create new Loyalty
        /// </summary>
        /// <param name="command">Object of CreateLoyaltyCommand</param>
        /// <returns>It will return in the form of int</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_Loyalty_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost]
        public async Task<ActionResult<int>> Post([FromBody] CreateLoyaltyCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will update existing Loyalty
        /// </summary>
        /// <param name="command">Object of UpdateLoyaltyCommand</param>
        /// <returns>It will return in the form of bool</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_Loyalty_Patch")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch]
        public async Task<ActionResult<bool>> Update([FromBody] UpdateLoyaltyCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will return list of Loyalty availble
        /// </summary>
        /// <param name="query">Object of GetLoyaltyQuery</param>
        /// <returns>It will return PaginatedList in the form of LoyaltyModel</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_Loyalty_GetLoyalty")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetLoyalty")]
        public async Task<ActionResult<PaginatedList<LoyaltyModel>>> GetLoyalty([FromQuery] GetLoyaltyQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will return Loyalty details by Loyalty Id.
        /// </summary>
        /// <param name="query">Object of GetLoyaltyByIdQuery</param>
        /// <returns>It will return in the form of LoyaltyModel</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_Loyalty_GetById")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetById")]
        public async Task<ActionResult<LoyaltyModel>> GetLoyaltyById([FromQuery] GetLoyaltyByIdQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns collection of events in which cash back is given to consumers
        /// </summary>
        /// <param name="creditType">Object of CreditType</param>
        /// <returns>It will return IEnumerable in the form of CashBackEvent</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_Loyalty_GetCashBackEvent")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetCashBackEvent")]
        public async Task<ActionResult<IEnumerable<CashBackEvent>>> GetCashBackEvent([FromQuery] CreditType creditType)
        {
            return Ok(await _mediator.Send(new GetCashBackEventQuery() { creditType = creditType }).ConfigureAwait(false));
        }

        /// <summary>
        /// Api returns collection of events criteria under which cash back can be given to consumer
        /// </summary>
        /// <param name="query">Object of GetCashBackCriteriaByEventIdQuery</param>
        /// <returns>It will return IEnumerable in the form of CashBackCriteria</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_Loyalty_CashBackCrietriaByEventId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("CashBackCrietriaByEventId")]
        public async Task<ActionResult<IEnumerable<CashBackCriteria>>> GetCashBackCriteria([FromQuery] GetCashBackCriteriaByEventIdQuery query)
        {
            return Ok(await _mediator.Send(query));
        }

        /// <summary>
        /// Api returns cash back criteria details by id
        /// </summary>
        /// <param name="query">Object of GetCashBackCriteriaByIdQuery</param>
        /// <returns>It will return in the form of CashBackCriteria</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_Loyalty_CashBackCrietriaByEventId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("CashBackCrietriaById")]
        public async Task<ActionResult<CashBackCriteria>> GetCashBackCriteriaById([FromQuery] GetCashBackCriteriaByIdQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }
    }
}