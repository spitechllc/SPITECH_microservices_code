﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Marketing.Application.Commands.CreateConsumerOffer;
using SpiTech.Marketing.Application.Queries.GetConsumerOfferByFilter;
using SpiTech.Marketing.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Marketing.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class ConsumerOfferController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<ConsumerOfferController> _logger;
        public ConsumerOfferController(IMediator mediator, ILogger<ConsumerOfferController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

    }
}
