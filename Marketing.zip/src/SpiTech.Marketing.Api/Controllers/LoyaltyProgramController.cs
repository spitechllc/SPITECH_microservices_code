﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Marketing.Application.Commands.CreateDeActivate;
using SpiTech.Marketing.Application.Commands.CreateLoyaltyLogin;
using SpiTech.Marketing.Application.Commands.CreateLoyaltyProgamRegister;
using SpiTech.Marketing.Application.Queries.GetAdvertisement;
using SpiTech.Marketing.Application.Queries.GetGlobalCampaign;
using SpiTech.Marketing.Application.Queries.GetLifeTimeSaving;
using SpiTech.Marketing.Application.Queries.GetLocation;
using SpiTech.Marketing.Application.Queries.GetLoyaltyBarcode;
using SpiTech.Marketing.Application.Queries.GetProductClub;
using SpiTech.Marketing.Application.Queries.GetPromotion;
using SpiTech.Marketing.Application.Queries.GetPromotionVelocity;
using SpiTech.Marketing.Application.Queries.GetReward;
using SpiTech.Marketing.Application.Queries.GetRewardsQueue;
using SpiTech.Marketing.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.Marketing.Domain.Contants;
using Location = SpiTech.Marketing.Domain.Models.Location;

namespace SpiTech.Marketing.Api.Controllers
{
    [Route("api/Program")]
    [ApiController]
    public class LoyaltyProgramController : ControllerBase
    {
        private readonly IMediator _mediator;
        public string HeaderToken = "";
        public LoyaltyProgramController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Loyalty Register This API is used to register loyalty members in the SA(save around) 
        /// system for a loyalty program.
        /// </summary>
        /// <param name="model">Object of CreateLoyaltyRegisterModel</param>
        /// <returns>It will return in the form of int</returns>
        //[ApiPermissionAuthorize(Permissions = "RegisterLoyalty")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("10945/register")]
        public async Task<ActionResult<int>> Post([FromBody] CreateLoyaltyRegisterCommand command)
        {
            string strToken = HttpContext.Request.Headers["Athorization"];
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Loyalty login
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("10945/login")]
        public async Task<ActionResult<int>> Login([FromBody] CreateLoyaltyLoginCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// It will return in the form of PromotionVelocityModel
        /// </summary>
        /// <returns></returns>
        //[ApiPermissionAuthorize(Permissions = "Marketing_LoyaltyProgram_Promotions")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("promotions")]
        public async Task<ActionResult<PromotionVelocityModel>> GetPromotion()
        {
            GetPromotionVelocityQuery query = new GetPromotionVelocityQuery();
            HeaderToken = HttpContext.Request.Headers[LoyaltyVelocity.LoyaltyKey].ToString();
            query.HeaderToken = HeaderToken;
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Loyalty Barcode This API is used to get a loyalty member barcode
        /// </summary>
        /// <returns></returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetLoyaltyBarCode")]
        public async Task<ActionResult<LoyaltyBarCodeModel>> GetLoyaltyBarCode()
        {
            GetLoyaltyBarcodeQuery query = new();
            HeaderToken = HttpContext.Request.Headers[LoyaltyVelocity.LoyaltyKey].ToString();
            query.HeaderToken = HeaderToken;
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// advertisements
        /// </summary>
        /// <returns></returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("advertisements")]
        public async Task<ActionResult<AdvertisementModel>> Advertisements()
        {
            GetAdvertisementQuery query = new();
            HeaderToken = HttpContext.Request.Headers[LoyaltyVelocity.LoyaltyKey].ToString();
            query.HeaderToken = HeaderToken;
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// It will return in the form of GetLifeTimeSavingModel
        /// </summary>
        /// <returns></returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("getLifeTimeSavings")]
        public async Task<ActionResult<GetLifeTimeSavingModel>> LifeTimeSavings()
        {
            GetLifeTimeSavingQuery query = new();
            query.HeaderToken = HttpContext.Request.Headers[LoyaltyVelocity.LoyaltyKey].ToString(); ;
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// API will deactivate the offer for a member
        /// </summary>
        /// <param name="model">Object of CreateDeActivateModel</param>
        /// <returns>It will return in the form of int</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("De-Activate")]
        public async Task<ActionResult<int>> DeActivation([FromBody] CreateDeActivateModel model)
        {
            CreateDeActivateCommand command = new();            
            command.HeaderToken= HttpContext.Request.Headers[LoyaltyVelocity.LoyaltyKey].ToString(); 
            command.offerPromoId = model.offerPromoId;
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// GetProductClub
        /// </summary>
        /// <returns></returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("myClub")]
        public async Task<ActionResult<ProductClubModel>> GetProductClub()
        {
            GetProductClubQuery query = new();
            query.HeaderToken = HttpContext.Request.Headers[LoyaltyVelocity.LoyaltyKey].ToString(); ;
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }
        /// <summary>
        /// Get Location Detail
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("getLocations")]
        public async Task<ActionResult<Location>> Location(GetLocationModel model)
        {
            GetLocationQuery query= new();
            query.HeaderToken = HttpContext.Request.Headers[LoyaltyVelocity.LoyaltyKey].ToString(); ;
            query.type = model.type;
            query.id = model.id;
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }
        /// <summary>
        /// Get RewardsQueue 
        /// </summary>
        /// <returns></returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("getRewardQueue")]
        public async Task<ActionResult<RewardsQueueResponseModel>> RewardsQueue()
        {
            GetRewardsQueueQuery query = new();
            query.HeaderToken = HttpContext.Request.Headers[LoyaltyVelocity.LoyaltyKey].ToString();
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// GlobalCampaign This API is used to return advertisements, offers, and promotions details for a loyalty member.
        /// </summary>
        /// <returns></returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("globalCampaign")]
        public async Task<ActionResult<GetGlobalCampaignModel>> GetGlobalCampaign()
        {
            GetGlobalCampaignQuery query= new();
            query.HeaderToken = HttpContext.Request.Headers[LoyaltyVelocity.LoyaltyKey].ToString();
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Get Reward
        /// </summary>
        /// <returns></returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("rewards")]
        public async Task<ActionResult<RewardModel>> GetReward()
        {
            GetRewardQuery query = new();
            query.HeaderToken = HttpContext.Request.Headers[LoyaltyVelocity.LoyaltyKey].ToString();
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }
    }
}
