﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Marketing.Application.Commands.CreateOffer;
using SpiTech.Marketing.Application.Commands.UpdateOffer;
using SpiTech.Marketing.Application.Queries.GetInactiveOfferByFilter;
using SpiTech.Marketing.Application.Queries.GetOfferByFilter;
using SpiTech.Marketing.Application.Queries.SearchOffersDealsByFilter;
using SpiTech.Marketing.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Marketing.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class OfferController : ControllerBase
    {
        private readonly IMediator _mediator;

        public OfferController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Method will create new offer
        /// </summary>
        /// <param name="command">Object of CreateOfferCommand</param>
        /// <returns>It will retrun in the form of Int</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_Offer_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost]
        public async Task<ActionResult<int>> Post([FromBody] CreateOfferCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will update existing offer
        /// </summary>
        /// <param name="command">Object of UpdateOfferCommand</param>
        /// <returns>It will retrun in the form of bool</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_Offer_Patch")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPatch]
        public async Task<ActionResult<bool>> Update([FromBody] UpdateOfferCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Method will return list of offers available
        /// </summary>
        /// <param name="query">Object of GetOfferByFilterQuery</param>
        /// <returns>It will retrun PaginatedList in the form of OfferModel</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_Offer_ByFilter")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("ByFilter")]
        public async Task<ActionResult<PaginatedList<OfferModel>>> GetOffer([FromQuery] GetOfferByFilterQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns Collection of available offer based on filters
        /// </summary>
        /// <param name="query">Object of SearchOfferByFilterQuery</param>
        /// <returns>It will retrun ResponseList in the form of OfferModel</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_Offer_SearchByFilter")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("SearchByFilter")]
        public async Task<ActionResult<ResponseList<OfferModel>>> SearchOffer([FromQuery] SearchOfferByFilterQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Api return inactive offers list
        /// </summary>
        /// <param name="query">Object of GetInactiveOfferByFilterQuery</param>
        /// <returns>It will retrun PaginatedList in the form of OfferModel</returns>
        [ApiPermissionAuthorize(Permissions = "Marketingapi_Offer_InactiveOfferByFilter")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("InactiveOfferByFilter")]
        public async Task<ActionResult<PaginatedList<OfferModel>>> GetInactiveOffer([FromQuery] GetInactiveOfferByFilterQuery query)
        {
            return Ok(await _mediator.Send(query).ConfigureAwait(false));
        }
    }
}
