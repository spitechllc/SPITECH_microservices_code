﻿using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Marketing.Application.Repositories;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Infrastructure.Repositories;
using System.Data;

namespace SpiTech.Marketing.Infrastructure.UnitOfWorks
{
    public sealed class UnitOfWork : BaseUnitOfWork, IUnitOfWork
    {
        public UnitOfWork(string connectionString,
                         System.IServiceProvider serviceProvider,
                        IsolationLevel isolationLevel = IsolationLevel.ReadCommitted)
                        : base(connectionString, serviceProvider, isolationLevel)
        {
        }

        private IAppDownloadRepository _appDownloads = null;
        private IOfferRepository _offers = null;
        private IConsumerOfferRepository _consumerOffers = null;
        private ILoyaltyRepository _loyalties = null;
        private IPromotionRepository _promotions = null;
        private IPromotionLoyaltyLogRepository _promotionLoyaltyLogs = null;
        private IPromotionLoyaltyLogDetailRepository _promotionLoyaltyLogDetails = null;
        private ICashBackEventRepository _cashBackEvents = null;
        private ICashBackCriteriaRepository _cashBackCriterias = null;
        private ILoyaltyRegisterVLRepository _LoyaltyRegisters = null;
        private ILoyaltyLoginRepository _loyaltyLogins = null;
        private IDeActivateRepository _deActivates = null;

         

        public IAppDownloadRepository AppDownloads => _appDownloads ??= new AppDownloadRepository(this, serviceProvider);

        public IOfferRepository Offers => _offers ??= new OfferRepository(this, serviceProvider);

        public IConsumerOfferRepository ConsumerOffers => _consumerOffers ??= new ConsumerOfferRepository(this, serviceProvider);

        public ILoyaltyRepository Loyalties => _loyalties ??= new LoyaltyRepository(this, serviceProvider);

        public IPromotionRepository Promotions => _promotions ??= new PromotionRepository(this, serviceProvider);

        public IPromotionLoyaltyLogRepository PromotionLoyaltyLogs => _promotionLoyaltyLogs ??= new PromotionLoyaltyLogRepository(this, serviceProvider);

        public IPromotionLoyaltyLogDetailRepository PromotionLoyaltyLogDetails => _promotionLoyaltyLogDetails ??= new PromotionLoyaltyLogDetailRepository(this, serviceProvider);

        public ICashBackEventRepository CashBackEvents => _cashBackEvents ??= new CashBackEventRepository(this, serviceProvider);

        public ICashBackCriteriaRepository CashBackCriterias => _cashBackCriterias ??= new CashBackCriteriaRepository(this, serviceProvider);

        public ILoyaltyRegisterVLRepository LoyaltyRegisters => _LoyaltyRegisters ??= new LoyaltyRegisterVLRepository(this, serviceProvider);
         
        public ILoyaltyLoginRepository LoyaltyLogins => _loyaltyLogins ??= new LoyaltyLoginRepository(this, serviceProvider);

        public IDeActivateRepository DeActivates => _deActivates??= new  DeActivateRepository(this, serviceProvider);


        public override void ResetRepositories()
        {
            _appDownloads = null;
            _offers = null;
            _consumerOffers = null;
            _loyalties = null;
            _promotions = null;
            _cashBackEvents = null;
            _cashBackCriterias = null;
            _promotionLoyaltyLogs = null;
            _promotionLoyaltyLogDetails = null;
            _LoyaltyRegisters = null;
            _loyaltyLogins = null;
            _deActivates = null;
        }
    }
}
