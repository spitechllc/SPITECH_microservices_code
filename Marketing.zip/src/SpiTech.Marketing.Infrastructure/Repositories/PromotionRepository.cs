﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Marketing.Application.Repositories;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Infrastructure.Repositories
{
    public class PromotionRepository : Repository<Promotion>, IPromotionRepository
    {
        public PromotionRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<List<PromotionModel>> GetAllPromotion(int? PageIndex, int? PageSize, string SortBy, string SortOrder)
        {
            StringBuilder sbquery = new();

            sbquery.Append($"Select  count(1) over() as TotalRecord, P.*,EventName,CriteriaName from Promotion P inner join CashBackEvent CB on P.CashBackEventId=CB.CashBackEventId inner join CashBackCriteria CC on P.CashBackCriteriaId=CC.CashBackCriteriaId");

            if (!string.IsNullOrEmpty(SortBy) && !string.IsNullOrEmpty(SortOrder))
            {
                sbquery.Append($" Order by {SortBy} {SortOrder}");
            }
            else
            {
                sbquery.Append($" Order by CreatedOn desc");
            }

            if (PageIndex.HasValue && PageSize.HasValue)
            {
                int skiprow = (PageIndex.Value - 1) * PageSize.Value;
                sbquery.Append($" OFFSET {skiprow} rows fetch next {PageSize.Value} rows only");
            }

            return (await DbConnection.QueryAsync<PromotionModel>(sbquery.ToString(), null, DbTransaction)).ToList();
        }

        public async Task<List<CashBackRuleModel>> GetCashBackRuleModels(string TenantName, int? promotionId = null)
        {
            StringBuilder sbquery = new();

            if (string.IsNullOrEmpty(TenantName))
            {
                sbquery.Append(@"Select CE.CashBackEventId, CE.EventName, CE.CreditTypeId, CT.[Name] AS CreditType,CC.CashBackCriteriaId, 
                            CC.CriteriaName, P.Criteria, P.IsPercentage, P.[Value], P.StartDate, P.EndDate, P.[Description], P.[DisplayOrder],P.[TenantName]
                            From [CashBackEvent] CE Inner Join [CashBackCriteria] CC ON CE.CashBackEventId = CC.CashBackEventId
                            Inner Join [CreditType] CT ON CE.CreditTypeId = CT.CreditTypeId
                            Inner Join [Promotion] P ON P.[CashBackCriteriaId] = CC.[CashBackCriteriaId] 
                            Where P.IsActive=1 and P.StartDate <= getUtcdate() and P.EndDate >= getUtcdate() and P.[TenantName] is null
                            Order by P.[DisplayOrder]");
            }
            else
            {
                sbquery.Append(@"Select CE.CashBackEventId, CE.EventName, CE.CreditTypeId, CT.[Name] AS CreditType,CC.CashBackCriteriaId, 
                            CC.CriteriaName, P.Criteria, P.IsPercentage, P.[Value], P.StartDate, P.EndDate, P.[Description], P.[DisplayOrder],P.[TenantName]
                            From [CashBackEvent] CE Inner Join [CashBackCriteria] CC ON CE.CashBackEventId = CC.CashBackEventId
                            Inner Join [CreditType] CT ON CE.CreditTypeId = CT.CreditTypeId
                            Inner Join [Promotion] P ON P.[CashBackCriteriaId] = CC.[CashBackCriteriaId] 
                            Where P.IsActive=1 and P.StartDate <= getUtcdate() and P.EndDate >= getUtcdate() and P.[TenantName] is not null
                            Order by P.[DisplayOrder]");
            }
           

            DynamicParameters dynamicParams = new();

            if (promotionId.HasValue && promotionId.Value > 0)
            {
                sbquery.Append($" and P.PromotionId=@promotionId");
                dynamicParams.Add("promotionId", promotionId);
            }

            return (await DbConnection.QueryAsync<CashBackRuleModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }

        public async Task<PromotionModel> GetPromotionById(int promotionId)
        {
            StringBuilder sbquery = new();
            DynamicParameters dynamicParams = new();

            sbquery.Append($"Select P.*,EventName,CriteriaName from Promotion P inner join CashBackEvent CB on P.CashBackEventId=CB.CashBackEventId inner join CashBackCriteria CC on P.CashBackCriteriaId=CC.CashBackCriteriaId where P.IsActive=1");

            if (promotionId > 0)
            {
                sbquery.Append($" and PromotionId=@promotionId");
                dynamicParams.Add("promotionId", promotionId);
            }

            return (await DbConnection.QueryAsync<PromotionModel>(sbquery.ToString(), dynamicParams, DbTransaction)).FirstOrDefault();

        }

        public async Task<Promotion> GetPromotion(string criteriaName, string criteria)
        {

            StringBuilder sbquery = new();
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("criteriaName", criteriaName);
            dynamicParams.Add("criteria", criteria);

            sbquery.Append($"Select P.* from Promotion P inner join CashBackCriteria CC on P.CashBackCriteriaId=CC.CashBackCriteriaId where P.IsActive=1 and CC.CriteriaName=@criteriaName and P.Criteria = @criteria and StartDate<=getutcdate() and EndDate>=getutcdate()");

            return await DbConnection.QueryFirstOrDefaultAsync<Promotion>(sbquery.ToString(), dynamicParams, DbTransaction);
        }
    }
}
