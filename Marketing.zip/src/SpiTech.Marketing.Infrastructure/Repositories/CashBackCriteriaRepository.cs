﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Marketing.Application.Repositories;
using SpiTech.Marketing.Domain.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Infrastructure.Repositories
{
    public class CashBackCriteriaRepository : Repository<CashBackCriteria>, ICashBackCriteriaRepository
    {
        public CashBackCriteriaRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<IEnumerable<CashBackCriteria>> GetCriteriaByEventId(int eventId)
        {
            string query = @$"select * from CashBackCriteria where CashBackEventId=@cashbackeventId ";
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("cashbackeventId", eventId);

            return (await DbConnection.QueryAsync<CashBackCriteria>(query, dynamicParams, DbTransaction)).ToList();
        }

        public async Task<CashBackCriteria> GetCriteriaById(int criteriaId)
        {
            string query = @$"select * from CashBackCriteria where CashBackCriteriaId=@cashbackcriteriaId ";
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("cashbackcriteriaId", criteriaId);

            return await DbConnection.QueryFirstOrDefaultAsync<CashBackCriteria>(query, dynamicParams, DbTransaction);
        }
    }
}
