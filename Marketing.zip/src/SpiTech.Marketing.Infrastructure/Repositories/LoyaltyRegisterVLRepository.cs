﻿using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Marketing.Application.Repositories;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Infrastructure.Repositories
{
    public class LoyaltyRegisterVLRepository : Repository<LoyaltyRegisterVL>, ILoyaltyRegisterVLRepository
    {
        public LoyaltyRegisterVLRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<bool> UpdateProfile(restrictedContent restrictedContent, string token, int requestedBy)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("Alcohol", restrictedContent.alcohol);
            dynamicParams.Add("Tobacco", restrictedContent.lottery);
            dynamicParams.Add("Lottery", restrictedContent.tobacco);
            dynamicParams.Add("requestedBy", requestedBy);
            dynamicParams.Add("AuthToken", token);

            string query = $"Update [dbo].[LoyaltyRegisterVL] Set Alcohol = @Alcohol, Tobacco = @Tobacco,Lottery = @Lottery, UpdatedOn = getutcdate(), UpdatedBy = @requestedBy   WHERE AuthToken = @AuthToken";
            int result = await DbConnection.ExecuteAsync(query, dynamicParams, DbTransaction);

            return result > 0;
        }
    }
}
