﻿using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Marketing.Application.Commands.CreateLoyaltyLogin;
using SpiTech.Marketing.Application.Repositories;
using SpiTech.Marketing.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Infrastructure.Repositories
{
    public class LoyaltyLoginRepository : Repository<LoyaltyLogin>, ILoyaltyLoginRepository
    {
        public LoyaltyLoginRepository(IBaseUnitOfWork dbContext, System.IServiceProvider serviceProvider) : base(dbContext, serviceProvider)
        {

        }
        public async Task<string> CheckVelocityUser(string userName)
        {
            DynamicParameters para = new();
            StringBuilder sbquery = new();
            sbquery.Append($"Select Email,UserName,Password from LoyaltyLogin where IsActive=1");

            if (!string.IsNullOrEmpty(userName))
            {
                para.Add("UserName", userName);
                sbquery.Append($" and Name=@userName");
            }
            return (await DbConnection.QueryAsync<LoyaltyLoginModel>(sbquery.ToString(), para, DbTransaction)).Select(x => x.userName).FirstOrDefault();
        }
    }
}
