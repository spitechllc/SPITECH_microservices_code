﻿using AutoMapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Marketing.Application.Repositories;
using SpiTech.Marketing.Domain.Entities;

namespace SpiTech.Marketing.Infrastructure.Repositories
{
    public class PromotionLoyaltyLogDetailRepository : Repository<PromotionLoyaltyLogDetail>, IPromotionLoyaltyLogDetailRepository
    {
        public PromotionLoyaltyLogDetailRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
    }
}
