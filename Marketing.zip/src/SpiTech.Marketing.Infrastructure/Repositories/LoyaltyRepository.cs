﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Marketing.Application.Repositories;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Infrastructure.Repositories
{
    public class LoyaltyRepository : Repository<Loyalty>, ILoyaltyRepository
    {
        public LoyaltyRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<List<LoyaltyModel>> GetAllLoyalty(int? PageIndex, int? PageSize, string SortBy, string SortOrder)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select count(1) over() as TotalRecord, L.*,EventName,CriteriaName from Loyalty L inner join CashBackEvent CB on L.CashBackEventId=CB.CashBackEventId inner join CashBackCriteria CC on L.CashBackCriteriaId=CC.CashBackCriteriaId where L.IsActive=1");

            if (!string.IsNullOrEmpty(SortBy) && !string.IsNullOrEmpty(SortOrder))
            {
                sbquery.Append($" Order by {SortBy} {SortOrder}");
            }
            else
            {
                sbquery.Append($" Order by CreatedOn desc");
            }

            if (PageIndex.HasValue && PageIndex.Value > 0 && PageSize.HasValue && PageSize.Value > 0)
            {
                int skiprow = (PageIndex.Value - 1) * PageSize.Value;
                sbquery.Append($" OFFSET {skiprow} rows fetch next {PageSize.Value} rows only");
            }

            return (await DbConnection.QueryAsync<LoyaltyModel>(sbquery.ToString(), null, DbTransaction)).ToList();
        }

        public async Task<List<CashBackRuleModel>> GetCashBackRuleModels(int? loyaltyId = null)
        {
            StringBuilder sbquery = new();
            sbquery.Append(@"Select CE.CashBackEventId, CE.EventName, CE.CreditTypeId, CT.[Name] AS CreditType, CC.CashBackCriteriaId, 
                            CC.CriteriaName, L.Criteria, L.IsPercentage, L.[Value], L.ExpireDays, L.[Description], L.[DisplayOrder]
                            From[CashBackEvent] CE Inner Join[CashBackCriteria] CC ON CE.CashBackEventId = CC.CashBackEventId
                            Inner Join [CreditType] CT ON CE.CreditTypeId = CT.CreditTypeId
                            Inner Join [Loyalty] L ON L.[CashBackCriteriaId] = CC.[CashBackCriteriaId] where L.IsActive=1  ");
            DynamicParameters dynamicParams = new();
            if (loyaltyId.HasValue && loyaltyId.Value > 0)
            {
                sbquery.Append($" and L.LoyaltyId=@LoyaltyId");

                dynamicParams.Add("LoyaltyId", loyaltyId);
            }

            return (await DbConnection.QueryAsync<CashBackRuleModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }

        public async Task<LoyaltyModel> GetLoyaltyById(int loyaltyId)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select L.*,EventName,CriteriaName from Loyalty L inner join CashBackEvent CB on L.CashBackEventId=CB.CashBackEventId inner join CashBackCriteria CC on L.CashBackCriteriaId=CC.CashBackCriteriaId where L.IsActive=1");
            DynamicParameters dynamicParams = new();

            if (loyaltyId > 0)
            {
                sbquery.Append($" and LoyaltyId=@LoyaltyId");
                dynamicParams.Add("LoyaltyId", loyaltyId);
            }

            return (await DbConnection.QueryAsync<LoyaltyModel>(sbquery.ToString(), dynamicParams, DbTransaction)).FirstOrDefault();
        }

        public async Task<Loyalty> GetLoyalty(string eventname, string criteria)
        {
            StringBuilder sbquery = new();
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("eventname", eventname);
            dynamicParams.Add("criteria", criteria);

            sbquery.Append($"Select L.* from Loyalty L inner join CashBackEvent CB on L.CashBackEventId=CB.CashBackEventId inner join CashBackCriteria CC on L.CashBackCriteriaId=CC.CashBackCriteriaId where L.IsActive=1 and CB.EventName=@eventname and CC.CriteriaName = @criteria");

            return await DbConnection.QueryFirstOrDefaultAsync<Loyalty>(sbquery.ToString(), dynamicParams, DbTransaction);
        }
    }
}
