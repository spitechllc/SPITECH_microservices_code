﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Marketing.Application.Repositories;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Infrastructure.Repositories
{
    public class CashBackEventRepository : Repository<CashBackEvent>, ICashBackEventRepository
    {
        public CashBackEventRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<IEnumerable<CashBackEventModel>> GetEvent(int credittypeid)
        {
            string query = @$"select CB.*,CT.Name as CreditType from CashBackEvent CB Inner Join [CreditType] CT on CB.CreditTypeId=CT.CreditTypeId where CB.CreditTypeId=@credittypeid";
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("credittypeid", credittypeid);

            return (await DbConnection.QueryAsync<CashBackEventModel>(query, dynamicParams, DbTransaction)).ToList();
        }
    }
}
