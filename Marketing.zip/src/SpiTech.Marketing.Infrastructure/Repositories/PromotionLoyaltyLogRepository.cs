﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Marketing.Application.Repositories;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Infrastructure.Repositories
{
    public class PromotionLoyaltyLogRepository : Repository<PromotionLoyaltyLog>, IPromotionLoyaltyLogRepository
    {
        public PromotionLoyaltyLogRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<List<PromotionLoyaltyLogModel>> GetPromotionLoyaltyLogs(int pageIndex, int pageSize, int? userId, bool? isFailure, DateTime from, DateTime to)
        {
            StringBuilder sbquery = new();
            DynamicParameters dynamicParams = new();

            dynamicParams.Add("from", from);
            dynamicParams.Add("to", to);

            sbquery.Append($"Select * from PromotionLoyaltyLog where CreatedOn>=@from and from<=@to ");

            if (userId.HasValue && userId.Value > 0)
            {
                dynamicParams.Add("userId", userId.Value);
                sbquery.Append($" userId=@userId");
            }

            if (isFailure.HasValue)
            {
                dynamicParams.Add("IsSuccess", !isFailure.Value);
                sbquery.Append($" IsSuccess=@IsSuccess");
            }

            if (pageIndex > 0 && pageSize > 0)
            {
                int skipRow = (pageIndex - 1) * pageSize;
                sbquery.Append($" OFFSET {skipRow} rows fetch next {pageSize} rows only");
            }

            return (await DbConnection.QueryAsync<PromotionLoyaltyLogModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }

        public async Task<PromotionLoyaltyLog> GetPromotionLoyaltyLogByFilter(string promotionLoyaltyLogId, bool isSuccess)
        {
            StringBuilder sbquery = new();
            DynamicParameters dynamicParams = new();

            dynamicParams.Add("promotionLoyaltyLogId", promotionLoyaltyLogId);
            dynamicParams.Add("isSuccess", isSuccess ? 1 : 0);

            sbquery.Append($"Select * from PromotionLoyaltyLog where PromotionLoyaltyLogId=@promotionLoyaltyLogId and IsSuccess=@isSuccess");

            return await DbConnection.QueryFirstOrDefaultAsync<PromotionLoyaltyLog>(sbquery.ToString(), dynamicParams, DbTransaction);
        }

        public async Task<bool> Update(string promotionLoyaltyLogId, bool isSuccess, string errorMessage)
        {
            StringBuilder sbquery = new();
            DynamicParameters dynamicParams = new();

            dynamicParams.Add("promotionLoyaltyLogId", promotionLoyaltyLogId);
            dynamicParams.Add("isSuccess", isSuccess ? 1 : 0);
            dynamicParams.Add("errorMessage", errorMessage);
            dynamicParams.Add("UpdatedBy", GetActionUserId());

            sbquery.Append($"Update PromotionLoyaltyLog set IsSuccess=@isSuccess, ErrorMessage= @errorMessage, UpdatedOn=GetUTCDate(), UpdatedBy=@UpdatedBy where PromotionLoyaltyLogId=@promotionLoyaltyLogId ");

            return (await DbConnection.ExecuteAsync(sbquery.ToString(), dynamicParams, DbTransaction)) > 0;
        }

        public async Task<bool> UpdateConsentCashReward(string promotionLoyaltyLogId, bool consentCashReward)
        {
            StringBuilder sbquery = new();
            DynamicParameters dynamicParams = new();

            dynamicParams.Add("promotionLoyaltyLogId", promotionLoyaltyLogId);
            dynamicParams.Add("consentCashReward", consentCashReward ? 1 : 0);
            dynamicParams.Add("UpdatedBy", GetActionUserId());

            sbquery.Append($"Update PromotionLoyaltyLog set consentCashReward=@consentCashReward, UpdatedOn=GetUTCDate(), UpdatedBy=@UpdatedBy where PromotionLoyaltyLogId=@promotionLoyaltyLogId ");

            return (await DbConnection.ExecuteAsync(sbquery.ToString(), dynamicParams, DbTransaction)) > 0;
        }
    }
}
