﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Marketing.Application.Repositories;
using SpiTech.Marketing.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Infrastructure.Repositories
{
    public class DeActivateRepository : Repository<DeActivate>, IDeActivateRepository
    {
        public DeActivateRepository(IBaseUnitOfWork dbContext, System.IServiceProvider serviceProvider) : base(dbContext, serviceProvider)
        {

        }
    }
}
