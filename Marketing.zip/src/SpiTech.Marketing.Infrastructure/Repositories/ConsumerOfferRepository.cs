﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Marketing.Application.Repositories;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Enums;
using SpiTech.Marketing.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Infrastructure.Repositories
{
    public class ConsumerOfferRepository : Repository<ConsumerOffer>, IConsumerOfferRepository
    {
        public ConsumerOfferRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<List<ConsumerOfferSearchResult>> GetAllActiveConsumerOffer(int? offerId, int? UserId, ConsumerOfferSortBy? sortBy, SortOrderEnum? sortOrder)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select C.ConsumerOfferId,C.UserId,C.OfferId,O.OfferDeal,O.Description,C.IsUsed,C.ScheduleDate,C.     ScheduleTime,C.Frequency,C.TimeZone,O.Store,O.StartDate,O.EndDate from ConsumerOffer C inner join Offer O on C.OfferId=O.OfferId where C.IsActive=1 and O.EndDate>=getdate()");
            DynamicParameters dynamicParams = new();

            if (offerId > 0)
            {
                sbquery.Append($" and OfferId=@OfferId");
                dynamicParams.Add("OfferId", offerId);
            }
            if (UserId > 0)
            {
                sbquery.Append($" and UserId=@UserId");
                dynamicParams.Add("UserId", UserId);
            }

            if (sortBy != null && sortOrder != null && sortBy.Value != ConsumerOfferSortBy.None && sortOrder.Value != SortOrderEnum.None)
            {
                if (sortBy.Value == ConsumerOfferSortBy.StartDate || sortBy.Value == ConsumerOfferSortBy.EndDate 
                    || sortBy.Value == ConsumerOfferSortBy.OfferDeal || sortBy.Value == ConsumerOfferSortBy.Store)
                {
                    sbquery.Append($" Order by O.{sortBy.Value} {sortOrder.Value} ");
                }
                else
                {
                    sbquery.Append($" Order by C.{sortBy.Value} {sortOrder.Value} ");
                }
            }
            else
            {
                sbquery.Append(" Order by C.ConsumerOfferId desc ");
            }

            return (await DbConnection.QueryAsync<ConsumerOfferSearchResult>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();

        }
        public async Task<List<ConsumerOfferSearchResult>> GetAllScheduledConsumerOffer()
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select C.ConsumerOfferId,C.UserId,C.OfferId,O.OfferDeal,O.Description,C.IsUsed,C.ScheduleDate,C.ScheduleTime,C.Frequency,C.TimeZone,O.Store,O.StartDate,O.EndDate from ConsumerOffer C inner join Offer O on C.OfferId=O.OfferId where C.IsActive=1 and convert(datetime,convert(varchar,C.ScheduleDate,103),103)<=convert(varchar,getdate(),103) and C.ScheduleTime <=CONVERT(VARCHAR(12),GETDATE(),114) and O.EndDate>=getdate()");


            return (await DbConnection.QueryAsync<ConsumerOfferSearchResult>(sbquery.ToString(), null, DbTransaction)).ToList();

        }
    }
}