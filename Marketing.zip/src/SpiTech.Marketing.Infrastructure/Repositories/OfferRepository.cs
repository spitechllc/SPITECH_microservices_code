﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Database;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Marketing.Application.Repositories;
using SpiTech.Marketing.Domain.Entities;
using SpiTech.Marketing.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Marketing.Infrastructure.Repositories
{
    public class OfferRepository : Repository<Offer>, IOfferRepository
    {
        public OfferRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<int> UpdateImageUrl(string imageUrl, int OfferId)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("ImageUrl", imageUrl);
            dynamicParams.Add("OfferId", OfferId);
            dynamicParams.Add("UpdatedBy", GetActionUserId());

            return await DbConnection.ExecuteAsync($"Update Offer set ImageUrl=@ImageUrl, UpdatedOn=GetUTCDate(), UpdatedBy=@UpdatedBy where OfferId=@OfferId", dynamicParams, DbTransaction);
        }

        public async Task<List<OfferModel>> GetOfferByFilter(int? OfferId, int? StoreId, string StoreName, string OfferDeal, int? PageIndex, int? PageSize, string SortBy, string SortOrder)
        {
            StringBuilder sbquery = new();
            DynamicParameters dynamicParams = new();

            sbquery.Append($"Select count(1) over() as TotalRecord, * from Offer where IsActive=1 and EndDate>=getdate()");

            if (OfferId > 0)
            {
                sbquery.Append($" and OfferId=@OfferId");
                dynamicParams.Add("OfferId", OfferId);
            }

            if (StoreId > 0)
            {
                sbquery.Append($" and StoreId=@StoreId");
                dynamicParams.Add("StoreId", StoreId);
            }

            if (!string.IsNullOrEmpty(OfferDeal) && OfferDeal.ToLower() != "null")
            {
                sbquery.Append($" and OfferDeal like @OfferDeal");
                dynamicParams.Add("OfferDeal", $"%{OfferDeal}%");
            }

            if (!string.IsNullOrEmpty(StoreName) && StoreName.ToLower() != "null")
            {
                sbquery.Append($" and Store like @Store");
                dynamicParams.Add("Store", $"%{StoreName}%");
            }

            if (!string.IsNullOrEmpty(SortBy) && !string.IsNullOrEmpty(SortOrder))
            {
                sbquery.Append($" Order by {SortBy} {SortOrder}");
            }
            else
            {
                sbquery.Append($" Order by OfferId desc");
            }

            if (PageIndex.HasValue && PageSize.HasValue)
            {
                int skiprow = (PageIndex.Value - 1) * PageSize.Value;
                sbquery.Append($" OFFSET {skiprow} rows fetch next {PageSize.Value} rows only");
            }

            return (await DbConnection.QueryAsync<OfferModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }

        public async Task<List<OfferModel>> SearchOfferByFilter(string StoreName, string description)
        {
            StringBuilder sbquery = new();
            DynamicParameters dynamicParams = new();
            sbquery.Append($"Select * from Offer where IsActive=1 and EndDate>=getdate()");

            if (!string.IsNullOrEmpty(StoreName))
            {
                sbquery.Append($" and Store like @Store");
                dynamicParams.Add("Store", $"%{StoreName}%");
            }

            if (!string.IsNullOrEmpty(description))
            {
                sbquery.Append($" and Description like @description");
                dynamicParams.Add("description", $"%{description}%");
            }
            sbquery.Append($" Order by OfferId desc");
            return (await DbConnection.QueryAsync<OfferModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }
        public async Task<List<OfferModel>> GetInactiveOffersByFilter(int? OfferId, int? StoreId, string StoreName, string OfferDeal, int? PageIndex, int? PageSize, string SortBy, string SortOrder, int[] StoreIds)
        {
            StringBuilder sbquery = new();
            DynamicParameters dynamicParams = new();

            sbquery.Append($"Select count(1) over() as TotalRecord, * from Offer where EndDate<getdate()");

            if (OfferId > 0)
            {
                sbquery.Append($" and OfferId=@OfferId");
                dynamicParams.Add("OfferId", OfferId);
            }

            if (StoreId > 0)
            {
                sbquery.Append($" and StoreId=@StoreId");
                dynamicParams.Add("StoreId", StoreId);
            }

            if (StoreIds.Any())
            {
                dynamicParams.Add("StoreIds", StoreIds.Cast<int>().ToArray().GetTableValuedParameter("[dbo].[UdtIntKeys]", "KeyValue"));
                sbquery.Append($" and(StoreId in (select KeyValue from @StoreIds))");
            }

            if (!string.IsNullOrEmpty(OfferDeal) && OfferDeal.ToLower() != "null")
            {
                sbquery.Append($" and OfferDeal like @OfferDeal");
                dynamicParams.Add("OfferDeal", $"%{OfferDeal}%");
            }

            if (!string.IsNullOrEmpty(StoreName) && StoreName.ToLower() != "null")
            {
                sbquery.Append($" and Store like @Store");
                dynamicParams.Add("Store", $"%{StoreName}%");
            }

            if (!string.IsNullOrEmpty(SortBy) && !string.IsNullOrEmpty(SortOrder))
            {
                sbquery.Append($" Order by {SortBy} {SortOrder}");
            }
            else
            {
                sbquery.Append($" Order by OfferId desc");
            }

            if (PageIndex.HasValue && PageSize.HasValue)
            {
                int skiprow = (PageIndex.Value - 1) * PageSize.Value;
                sbquery.Append($" OFFSET {skiprow} rows fetch next {PageSize.Value} rows only");
            }

            return (await DbConnection.QueryAsync<OfferModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }

        public async Task<List<OfferModel>> GetOfferDealByFilter(int? OfferId, int? StoreId, string StoreName, string OfferDeal, int? PageIndex, int? PageSize, string SortBy, string SortOrder, int[] StoreIds)
        {
            StringBuilder sbquery = new();
            DynamicParameters dynamicParams = new();

            sbquery.Append($"Select count(1) over() as TotalRecord, * from Offer where IsActive=1 and convert(varchar(10), EndDate, 102) = convert(varchar(10), getdate(), 102)");

            if (OfferId > 0)
            {
                sbquery.Append($" and OfferId=@OfferId");
                dynamicParams.Add("OfferId", OfferId);
            }

            if (StoreId > 0)
            {
                sbquery.Append($" and StoreId=@StoreId");
                dynamicParams.Add("StoreId", StoreId);
            }
            if (StoreIds.Any())
            {
                dynamicParams.Add("StoreIds", StoreIds.Cast<int>().ToArray().GetTableValuedParameter("[dbo].[UdtIntKeys]", "KeyValue"));
                sbquery.Append($" and(StoreId in (select KeyValue from @StoreIds))");
            }

            if (!string.IsNullOrEmpty(OfferDeal) && OfferDeal.ToLower() != "null")
            {
                sbquery.Append($" and OfferDeal like @OfferDeal");
                dynamicParams.Add("OfferDeal", $"%{OfferDeal}%");
            }

            if (!string.IsNullOrEmpty(StoreName) && StoreName.ToLower() != "null")
            {
                sbquery.Append($" and Store like @Store");
                dynamicParams.Add("Store", $"%{StoreName}%");
            }

            if (!string.IsNullOrEmpty(SortBy) && !string.IsNullOrEmpty(SortOrder))
            {
                sbquery.Append($" Order by {SortBy} {SortOrder}");
            }
            else
            {
                sbquery.Append($" Order by OfferId desc");
            }

            if (PageIndex.HasValue && PageSize.HasValue)
            {
                int skiprow = (PageIndex.Value - 1) * PageSize.Value;
                sbquery.Append($" OFFSET {skiprow} rows fetch next {PageSize.Value} rows only");
            }

            return (await DbConnection.QueryAsync<OfferModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }
    }
}
