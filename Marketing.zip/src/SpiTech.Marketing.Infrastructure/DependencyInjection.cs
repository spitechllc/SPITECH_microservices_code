﻿using AutoMapper;
using FluentValidation;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.Marketing.Application.UnitOfWorks;
using SpiTech.Marketing.Infrastructure.UnitOfWorks;
using System.Reflection;

namespace SpiTech.Marketing.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            string connectionString = configuration.GetConnectionString("Marketing");
            services
                .AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());

            services.AddScoped<IUnitOfWork, UnitOfWork>(serviceProvider => new UnitOfWork(connectionString, serviceProvider));

            return services;
        }
    }
}
