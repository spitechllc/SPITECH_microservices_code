INSERT INTO [CreditType](CreditTypeId, Name)
VALUES 
(1, 'Loyalty'),
(2, 'Promotion');
GO


SET IDENTITY_INSERT [dbo].[CashBackEvent] ON 
GO
INSERT [dbo].[CashBackEvent] ([CashBackEventId], [CreditTypeId], [EventName], [Description], [IsActive], [CreatedOn])
VALUES
(1, 1, N'PaymentMethod', N'PaymentMethod', 1, Getutcdate()),
(2, 2, N'Transaction', N'Transaction', 1,  Getutcdate()),
(3, 2, N'Payment', N'Payment', 1,  Getutcdate());
GO
SET IDENTITY_INSERT [dbo].[CashBackEvent] OFF
GO



SET IDENTITY_INSERT [dbo].[CashBackCriteria] ON 
GO
INSERT [dbo].[CashBackCriteria] ([CashBackCriteriaId], [CashBackEventId], [CriteriaName], [Description], [HasValue], [ValueType], [IsActive], [CreatedOn])
VALUES
(1, 1, N'ACH', N'ACH', 0, NULL, 1, Getutcdate()),
(2, 1, N'Credit', N'Credit', 0, NULL, 1, Getutcdate()),
(3, 2, N'TransactionSequenceNo', N'TransactionSequenceNo', 1, N'int', 1, Getutcdate()),
(4, 3, N'AddCard', N'Add Card', 1, N'int', 1, Getutcdate());
GO
SET IDENTITY_INSERT [dbo].[CashBackCriteria] OFF
GO



SET IDENTITY_INSERT [dbo].[Loyalty] ON 
GO
INSERT [dbo].[Loyalty] ([LoyaltyId], [CashBackEventId], [CashBackCriteriaId], [Description], [DisplayOrder], [Criteria], [IsPercentage], [Value], [ExpireDays], [IsActive], [CreatedOn])
VALUES
(1, 1, 1,'$0.02 Papi points earned for every $1 spent using ACH linked to the app',1, NULL, 1, 2, 365, 1, Getutcdate()),
(2, 1, 2,'$0.01 Papi Point earned for every $1 spent using a credit and or debit card linked to the app',2, NULL, 1, 1, 365, 1, Getutcdate());
GO
SET IDENTITY_INSERT [dbo].[Loyalty] OFF
GO



SET IDENTITY_INSERT [dbo].[Promotion] ON 
GO
INSERT [dbo].[Promotion] ([PromotionId], [CashBackEventId], [CashBackCriteriaId], [Description], [DisplayOrder], [Criteria], [IsPercentage], [Value], [StartDate], [EndDate], [IsActive], [CreatedOn])
VALUES
(1, 3, 4,'Earn $5 Cash Reward once app is downloaded and a payment of method is added to your profile',3, N'1', 0, 5, Getutcdate(), Getutcdate()+100, 1, Getutcdate()),
(2, 2, 3,'Earn an additional $5 Cash Reward after your 6th transaction using SpiTech',4, N'6', 0, 5, Getutcdate(), Getutcdate()+100, 1, Getutcdate()),
(3, 2, 3,'Earn and additional $5 Cash Reward after your 11th transaction using SpiTech',5, N'11', 0, 5, Getutcdate(), Getutcdate()+100, 1, Getutcdate());
GO
SET IDENTITY_INSERT [dbo].[Promotion] OFF
GO
