/*
IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_OffersDeals_StoreId')   
    DROP INDEX IX_OffersDeals_StoreId ON [dbo].[OffersDeals];   
GO  

CREATE NONCLUSTERED INDEX IX_OffersDeals_StoreId  
    ON [dbo].[OffersDeals] (StoreId);   
GO

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_OffersDeals_Store')   
    DROP INDEX IX_OffersDeals_Store ON [dbo].[OffersDeals];   
GO  

CREATE NONCLUSTERED INDEX IX_OffersDeals_Store 
    ON [dbo].[OffersDeals] (Store);   
GO

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_OffersDeals_Description')   
    DROP INDEX IX_OffersDeals_Description ON [dbo].[OffersDeals];   
GO  

CREATE NONCLUSTERED INDEX IX_OffersDeals_Description 
    ON [dbo].[OffersDeals] (Description);   
GO 

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_ConsumersOffers_OfferId')   
    DROP INDEX IX_ConsumersOffers_OfferId ON [dbo].[ConsumersOffers];
GO  

CREATE NONCLUSTERED INDEX IX_ConsumersOffers_OfferId 
    ON [dbo].[ConsumersOffers] (OfferId);   
GO

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_ConsumersOffers_UserId')   
    DROP INDEX IX_ConsumersOffers_UserId ON [dbo].[ConsumersOffers];   
GO  

CREATE NONCLUSTERED INDEX IX_ConsumersOffers_UserId 
    ON [dbo].[ConsumersOffers] (UserId);   
GO


IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Loyalty_Criteria')   
    DROP INDEX IX_Loyalty_Criteria ON [dbo].[Loyalty];
GO  

CREATE NONCLUSTERED INDEX IX_Loyalty_Criteria 
    ON [dbo].[Loyalty] (Criteria);   
GO

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Promotion_Criteria')   
    DROP INDEX IX_Promotion_Criteria ON [dbo].[Promotion];   
GO  

CREATE NONCLUSTERED INDEX IX_Promotion_Criteria
    ON [dbo].[Promotion] (Criteria);   
GO

IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_CashBackCriteria_Criteria')   
    DROP INDEX IX_CashBackCriteria_Criteria ON [dbo].[CashBackCriteria];   
GO  

CREATE NONCLUSTERED INDEX IX_CashBackCriteria_Criteria
    ON [dbo].[CashBackCriteria] (Criteria);   
GO


IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_CashBackEventId_CreditTypeId')   
    DROP INDEX IX_CashBackEventId_CreditTypeId ON [dbo].[CashBackEventId];
GO  

CREATE NONCLUSTERED INDEX IX_CashBackEventId_CreditTypeId 
    ON [dbo].[CashBackEventId] (CreditTypeId);   
GO


IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_CashBackEventId_EventName')   
    DROP INDEX IX_CashBackEventId_EventName ON [dbo].[CashBackEventId];
GO  

CREATE NONCLUSTERED INDEX IX_CashBackEventId_EventName 
    ON [dbo].[CashBackEventId] (EventName);   
GO
GO
*/