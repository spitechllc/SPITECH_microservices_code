CREATE TABLE [dbo].[CashBackCriteria]
(
	  [CashBackCriteriaId] INT NOT NULL IDENTITY(1,1)
	, [CashBackEventId] INT NOT NULL
	, [CriteriaName] VARCHAR(100) NOT NULL
	, [Description] VARCHAR(100) NULL
	, [HasValue] BIT NOT NULL
	, [ValueType] VARCHAR(50) NULL
	, [IsActive] BIT NOT NULL
	, [CreatedOn] DATETIME NOT NULL
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_CashBackCriteria] PRIMARY KEY ([CashBackCriteriaId] ASC)
)

GO
CREATE TABLE [dbo].[CreditType]
(
	  [CreditTypeId] INT NOT NULL
	, [Name] VARCHAR(100) NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_CreditType] PRIMARY KEY ([CreditTypeId] ASC)
)

GO
CREATE TABLE [dbo].[Offer]
(
	  [OfferId] INT NOT NULL IDENTITY(1,1)
	, [CompanyId] INT NOT NULL
	, [Region] INT NOT NULL
	, [StoreId] INT NOT NULL
	, [Store] VARCHAR(50) NULL
	, [StartDate] DATETIME NOT NULL
	, [EndDate] DATETIME NOT NULL
	, [OfferDeal] VARCHAR(100) NOT NULL
	, [UPCCode] VARCHAR(30) NOT NULL
	, [Description] VARCHAR(500) NULL
	, [ImageUrl] VARCHAR(500) NULL
	, [QRCode] BIT NULL
	, [SingleUse] BIT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NOT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_OffersDeals] PRIMARY KEY ([OfferId] ASC)
)

GO
CREATE TABLE [dbo].[ConsumerOffer]
(
	  [ConsumerOfferId] INT NOT NULL IDENTITY(1,1)
	, [UserId] INT NOT NULL
	, [OfferId] INT NOT NULL
	, [IsUsed] BIT NULL
	, [ScheduleDate] DATE NULL
	, [ScheduleTime] TIME NULL
	, [Frequency] VARCHAR(50) NULL
	, [TimeZone] VARCHAR(50) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [IsSent] BIT NULL DEFAULT((0))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_ConsumersOffers] PRIMARY KEY ([ConsumerOfferId] ASC)
)

ALTER TABLE [dbo].[ConsumerOffer] ADD
  CONSTRAINT [FK_ConsumerOffer_Offer] FOREIGN KEY([OfferId]) REFERENCES [dbo].[Offer](OfferId);

GO
CREATE TABLE [dbo].[CashBackEvent]
(
	  [CashBackEventId] INT NOT NULL IDENTITY(1,1)
	, [CreditTypeId] INT NOT NULL
	, [EventName] VARCHAR(100) NOT NULL
	, [Description] VARCHAR(100) NULL
	, [IsActive] BIT NOT NULL
	, [CreatedOn] DATETIME NOT NULL
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdateBy] INT NULL
	, CONSTRAINT [PK_CashBackEvent] PRIMARY KEY ([CashBackEventId] ASC)
)

ALTER TABLE [dbo].[CashBackEvent] ADD
  CONSTRAINT [FK_CashBackEvent_CreditType] FOREIGN KEY([CreditTypeId]) REFERENCES [dbo].[CreditType]([CreditTypeId]);

GO
CREATE TABLE [dbo].[Loyalty]
(
	  [LoyaltyId] INT NOT NULL IDENTITY(1,1)
	, [CashBackEventId] INT NOT NULL
	, [CashBackCriteriaId] INT NOT NULL
	, [Description] VARCHAR(1000) NULL
	, [DisplayOrder] INT NOT NULL
	, [Criteria] VARCHAR(100) NULL
	, [IsPercentage] BIT NOT NULL
	, [Value] DECIMAL(18,2) NULL
	, [ExpireDays] INT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Loyalty] PRIMARY KEY ([LoyaltyId] ASC)
)

ALTER TABLE [dbo].[Loyalty] ADD
  CONSTRAINT [FK_Loyalty_CashBackCriteria] FOREIGN KEY([CashBackCriteriaId]) REFERENCES [dbo].[CashBackCriteria]([CashBackCriteriaId]),
  CONSTRAINT [FK_Loyalty_CashBackEvent] FOREIGN KEY([CashBackEventId]) REFERENCES [dbo].[CashBackEvent]([CashBackEventId]);

GO
CREATE TABLE [dbo].[Promotion]
(
	  [PromotionId] INT NOT NULL IDENTITY(1,1)
	, [CashBackEventId] INT NOT NULL
	, [CashBackCriteriaId] INT NOT NULL
	, [Description] VARCHAR(1000) NULL
	, [DisplayOrder] INT NOT NULL
	, [Criteria] VARCHAR(100) NULL
	, [IsPercentage] BIT NOT NULL
	, [Value] DECIMAL(18,2) NULL
	, [StartDate] DATETIME NOT NULL
	, [EndDate] DATETIME NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Promotion] PRIMARY KEY ([PromotionId] ASC)
)

ALTER TABLE [dbo].[Promotion] ADD
  CONSTRAINT [FK_Promotion_CashBackCriteria] FOREIGN KEY([CashBackCriteriaId]) REFERENCES [dbo].[CashBackCriteria]([CashBackCriteriaId]),
  CONSTRAINT [FK_Promotion_CashBackEvent] FOREIGN KEY([CashBackEventId]) REFERENCES [dbo].[CashBackEvent]([CashBackEventId]);

GO
CREATE TABLE [dbo].[PromotionLoyaltyLog]
(
	  [PromotionLoyaltyLogId] UNIQUEIDENTIFIER NOT NULL
	, [EventName] VARCHAR(50) NOT NULL
	, [EventModuleTypeId] INT NOT NULL
	, [EventTypeId] INT NOT NULL
	, [UserId] INT NOT NULL
	, [TransactionAmount] DECIMAL(18,2) NULL
	, [StoreId] INT NULL
	, [TransactionId] BIGINT NULL
	, [TransactionDesc] VARCHAR(100) NULL
	, [TransactionSequenceNo] INT NULL
	, [ConsentCashReward] BIT NULL
	, [UserPaymentMethodId] INT NULL
	, [PaymentMethodId] INT NULL
	, [EventPayload] VARCHAR(Max) NULL
	, [IsSuccess] BIT NULL
	, [ErrorMessage] VARCHAR(500) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_PromotionLoyaltyLog] PRIMARY KEY ([PromotionLoyaltyLogId] ASC)
)

GO
CREATE TABLE [dbo].[PromotionLoyaltyLogDetail]
(
	  [PromotionLoyaltyLogDetailId] UNIQUEIDENTIFIER NOT NULL
	, [PromotionLoyaltyLogId] UNIQUEIDENTIFIER NOT NULL
	, [CreditTypeId] INT NOT NULL
	, [CreditIdentifier] INT NULL
	, [CreditAmount] DECIMAL(18,2) NOT NULL
	, [ExpireDate] DATETIME NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_PromotionLoyaltyLogDetail] PRIMARY KEY ([PromotionLoyaltyLogDetailId] ASC)
)


ALTER TABLE [dbo].[PromotionLoyaltyLogDetail] ADD
  CONSTRAINT [FK_PromotionLoyaltyLogDetail_CreditType] FOREIGN KEY([CreditTypeId]) REFERENCES [dbo].[CreditType]([CreditTypeId]),
  CONSTRAINT [FK_PromotionLoyaltyLogDetail_PromotionLoyaltyLog] FOREIGN KEY([PromotionLoyaltyLogId]) REFERENCES [dbo].[PromotionLoyaltyLog]([PromotionLoyaltyLogId]);

GO

CREATE TABLE [dbo].[AppDownload]
(
	  [AppDownloadId] INT NOT NULL IDENTITY(1,1)
	, [Code] VARCHAR(500) NOT NULL
	, [RequestHeader] VARCHAR(max) NULL
	, [RequestUrl] VARCHAR(1000) NULL
	, [ResponseUrl] VARCHAR(1000) NULL
	, [IsActive] BIT NOT NULL
	, [CreatedOn] DATETIME NOT NULL
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_AppDownload] PRIMARY KEY ([AppDownloadId] ASC)
)

GO


CREATE TABLE [dbo].[LoyaltyRegisterVL](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[LoyaltyId] [varchar](30) NOT NULL,
	[UserId] [varchar](10) NOT NULL,
	[MobileNo] [varchar](10) NOT NULL,
	[FirstName] [varchar](50) NOT NULL,
	[LastName] [varchar](50) NULL,
	[Email] [varchar](30) NULL,
	[Password] [nvarchar](20) NULL,
	[BirthDate] [varchar](12) NULL,
	[PhoneNumber] [varchar](10) NULL,
	[Platform] [smallint] NULL,
	[ZipCode] [varchar](10) NULL,
	[Alcohol] [varchar](20) NULL,
	[Tobacco] [varchar](20) NULL,
	[Lottery] [varchar](20) NULL,
	[PromoCode] [varchar](20) NULL,
	[CommSms] [varchar](50) NULL,
	[CommEmail] [varchar](50) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [varchar](256) NULL,
	[UpdatedOn] [datetime] NULL,
	[UpdatedBy] [varchar](256) NULL,
	[AuthToken] [nvarchar](max) NULL,
 CONSTRAINT [PK_LoyaltyRegistrationVL] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UC_LoyaltyRegistrationVL] UNIQUE NONCLUSTERED 
(
	[Email] ASC,
	[PhoneNumber] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[LoyaltyRegisterVL] ADD  CONSTRAINT [DF_LoyaltyRegisterVL_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[LoyaltyRegisterVL] ADD  CONSTRAINT [DF_LoyaltyRegisterVL_CreatedOn]  DEFAULT (getutcdate()) FOR [CreatedOn]
GO


CREATE TABLE [dbo].[LoyaltyLogin](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[LoyaltyId] [varchar](50) NULL,
	[Email] [varchar](50) NOT NULL,
	[UserName] [varchar](100) NOT NULL,
	[Password] [nvarchar](50) NULL,
	[AuthToken] [nvarchar](max) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [varchar](256) NULL,
	[UpdatedOn] [datetime] NULL,
	[UpdatedBy] [varchar](256) NULL,
 CONSTRAINT [PK_LoyaltyLogin] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[LoyaltyLogin] ADD  CONSTRAINT [DF_LoyaltyLogin_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[LoyaltyLogin] ADD  CONSTRAINT [DF_LoyaltyLogin_CreatedOn]  DEFAULT (getutcdate()) FOR [CreatedOn]
GO



CREATE TABLE [dbo].[DeActivate](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Code] [int] NULL,
	[Status] [bit] NULL,
	[Message] [varchar](100) NULL,
	[Payload] [varchar](100) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [varchar](256) NULL,
	[UpdatedOn] [datetime] NULL,
	[UpdatedBy] [varchar](256) NULL,
 CONSTRAINT [PK_DeActivate] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[DeActivate] ADD  CONSTRAINT [DF_DeActivate_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[DeActivate] ADD  CONSTRAINT [DF_DeActivate_CreatedOn]  DEFAULT (getutcdate()) FOR [CreatedOn]
GO
