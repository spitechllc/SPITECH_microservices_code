IF NOT EXISTS(SELECT * FROM sys.databases WHERE name = 'SpiTech_Marketing')
  BEGIN
    CREATE DATABASE [SpiTech_Marketing]
 END
GO
GO

USE [SpiTech_Marketing]