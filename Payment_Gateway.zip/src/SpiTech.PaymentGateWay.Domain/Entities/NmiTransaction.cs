﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.PaymentGateWay.Domain.Entities
{
    [Table("NmiTransaction")]
    public class NmiTransaction : BaseEntity
    {
        [ExplicitKey]
        public string TransactionIdentifier { get; set; }

        public DateTime? TransactionDate { get; set; }
        public int NmiTransactionFileId { get; set; }

        public string DbaName { get; set; }

        public int? MerchantMccCode { get; set; }

        public long? MId { get; set; }

        public string DebitOrCreditIndicator { get; set; }

        public double? TransactionAmount { get; set; }

        public string CardType { get; set; }

        public string CardType2 { get; set; }

        public string CardFirst6 { get; set; }

        public string CardLast4To5 { get; set; }

        public string CardHash { get; set; }

        public string NetworkIdentifierDebit { get; set; }

        public string PosDataCode { get; set; }

        public string PosEntryMode { get; set; }

        public string RecordIdentifier { get; set; }

        public string TerminalId { get; set; }

        public string TotalAuthorizedAmount { get; set; }

        public string AuthorizationNumber { get; set; }

        public double? AuthAmount { get; set; }

        public double? OriginalTransactionAmount { get; set; }

        public string RejectReason { get; set; }

        public int? MailOrderOrTelephoneOrderIndicator { get; set; }

        public string AchFlag { get; set; }

        public string Aci { get; set; }

        public int? AssociationNumber2 { get; set; }

        public int? AuthCurrencyCode { get; set; }

        public string Authsource { get; set; }

        public int? BanknetAuthDate { get; set; }

        public string BanknetReferenceNumber { get; set; }

        public int? BatchJulianDate { get; set; }

        public string BestInterChangeEligible { get; set; }

        public int? CardHolderIordMethod { get; set; }

        public string CarryOverIndicator { get; set; }

        public double? CashbackAmount { get; set; }

        public string CashbackAmountSign { get; set; }

        public int? CatIndicator { get; set; }

        public int? CurrencyCode { get; set; }

        public string DiscoverNetworkReferenceId { get; set; }

        public string DiscoverProcessingCode { get; set; }

        public string DiscoverTransactionType { get; set; }

        public string DownGradeReason1 { get; set; }

        public string DownGradeReason2 { get; set; }

        public string DownGradeReason3 { get; set; }

        public string DraftaFlag { get; set; }

        public int? EntryRunNumber { get; set; }

        public string ExtensionRecordIndicator { get; set; }

        public string ForeignCardIndicator { get; set; }

        public int? DdfMccCode { get; set; }

        public double? NetDeposit { get; set; }

        public string OnlineEntry { get; set; }

        public string ProductId { get; set; }

        public long? PurchaseId { get; set; }

        public int? ReimbursementAttribute { get; set; }

        public string ReversalFlag { get; set; }

        public int? SequenceNumberArea { get; set; }

        public int? SequenceNumberWithInEntryRun { get; set; }

        public int? SubmittedInterChange { get; set; }

        public string SwitchSettledIndicator { get; set; }

        public string SystemTraceAuditNumber { get; set; }

        public int? TransactionCode { get; set; }

        public string TransactionDataConditionCode { get; set; }

        public int? TransactionTypeIdentifier { get; set; }

        public string ValidationCode { get; set; }

        public string CardBrandFeeCode { get; set; }

        public string CommercialCardServiceIndicator { get; set; }

        public string InterchangeFeeAmount { get; set; }

        public string InterchangePercentrate { get; set; }

        public string InterchangePeritemRate { get; set; }

        public string MasterCardTransactionIntegrityClass { get; set; }

        public string MasterCardWalletIdentifier { get; set; }

        public double? McCashBackFee { get; set; }

        public string McCashBackFeeSign { get; set; }

        public string MerchantAssignedReferenceNumber { get; set; }

        public string NetDepositAdjustmentAmount { get; set; }

        public string NetDepositAdjustmentDc { get; set; }

        public string OperatorId { get; set; }

        public string RegulatedIndicator { get; set; }

        public string RequestedPaymentService { get; set; }

        public string TransactionFeeAmount { get; set; }

        public string TransactionFeeAmountInCardHolderBillingCurrency { get; set; }

        public string TransactionFeeDebitOrCreditIndicator { get; set; }

        public string VisaFeeProgramIndicator { get; set; }

        public string VisaIntegrityFee { get; set; }

        public string VisaSpecialConditionIndicator { get; set; }
    }
}
