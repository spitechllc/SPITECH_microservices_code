﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.PaymentGateWay.Domain.Entities
{
    [Table("NmiTransactionFile")]
    public class NmiTransactionFile : BaseEntity
    {
        [Key]
        public int NmiTransactionFileId { get; set; }
        public string Name { get; set; }
        public string FileId { get; set; }
        public DateTime FileCreationDate { get; set; }
        public string Bucket { get; set; }
        public string ContentType { get; set; }
        public string MediaLink { get; set; }
        public string SelfLink { get; set; }
        public long Size { get; set; }
    }
}
