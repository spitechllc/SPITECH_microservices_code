﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.PaymentGateWay.Domain.Entities
{
    [Table("PaymentStatus")]
    public class PaymentStatus : BaseEntity
    {
        [Key]
        public int PaymentStatusId { get; set; }
        public string PaymentStatusName { get; set; }
    }
}