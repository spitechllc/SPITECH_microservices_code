﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.PaymentGateWay.Domain.Entities
{
    [Table("WebhooksCreditCardDetails")]
    public class WebhooksCreditCardDetails : BaseEntity
    {
        [Key]
        public int WebhooksId { get; set; }
        public string EventId { get; set; }
        public int MerchantId { get; set; }
        public string MerchantName { get; set; }
        public int TransactionId { get; set; }
        public string TransactionType { get; set; }
        public string Condition { get; set; }
        public string ProccessorId { get; set; }
        public int PONumber { get; set; }
        public string OrderDescription { get; set; }
        public int OrderId { get; set; }
        public int customerid { get; set; }
        public int customertaxid { get; set; }
        public string Website { get; set; }
        public string Shipping { get; set; }
        public string Currency { get; set; }
        public decimal Tax { get; set; }
        public decimal Surcharge { get; set; }
        public decimal CashDiscount { get; set; }
        public decimal RequestedAmount { get; set; }
        public string AuthorizationCode { get; set; }
        public string SocialSecurityNumber { get; set; }
        public string CCNumber { get; set; }
        public string CCExp { get; set; }
        public string CCType { get; set; }
        public decimal Amount { get; set; }
        public string ActionType { get; set; }
        public DateTime Date { get; set; }
        public bool Success { get; set; }
        public string Ipaddress { get; set; }
        public string Source { get; set; }
        public string ApiMethod { get; set; }
        public string UserName { get; set; }
        public string ResponseText { get; set; }
        public string ResponseCode { get; set; }
        public string ProcessorResponseText { get; set; }
        public string ProcessorResponseCode { get; set; }
        public string DeviceLicenseNumber { get; set; }
        public string DeviceNickname { get; set; }
    }
}
