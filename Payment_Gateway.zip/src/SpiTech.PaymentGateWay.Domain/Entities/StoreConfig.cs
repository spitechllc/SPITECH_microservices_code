﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.PaymentGateWay.Domain.Entities
{
    [Table("StoreConfig")]
    public class StoreConfig : BaseEntity
    {
        [ExplicitKey]
        public int StoreId { get; set; }
        public string AccountName { get; set; }
        public string Bank { get; set; }
        public string AccountNo { get; set; }
        public string RoutingNo { get; set; }
        public bool IsChecking { get; set; }
        public bool IsMasterAccount { get; set; }
        public string PaymentProcessorId { get; set; }
        public string ACHProcessorId { get; set; }
        public bool? IsAchEnabled { get; set; }
    }
}
