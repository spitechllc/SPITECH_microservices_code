﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.PaymentGateWay.Domain.Entities
{
    [Table("PaymentMethod")]
    public class PaymentMethod : BaseEntity
    {
        [Key]
        public int PaymentMethodId { get; set; }
        public string PaymentMethodName { get; set; }
        public string PaymentType { get; set; }
    }
}