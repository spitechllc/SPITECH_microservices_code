﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.PaymentGateWay.Domain.Entities
{
    [Table("StorePaymentMethodConfigration")]
    public class StorePaymentMethodConfigration : BaseEntity
    {
        [Key]
        public int ConfigrationId { get; set; }
        public int StoreId { get; set; }
        public int PaymentGatewayConfigId { get; set; }
        public string SiteID { get; set; }
        public string AccountHolderName { get; set; }
        public string AccountNumber { get; set; }
        public string AccountType { get; set; }
        public string RoutingNumber { get; set; }
        public string BankName { get; set; }
        public string Token { get; set; }
        public string TransactionToken { get; set; }
        public bool IsDefault { get; set; }
        public bool IsRemoved { get; set; }
    }
}
