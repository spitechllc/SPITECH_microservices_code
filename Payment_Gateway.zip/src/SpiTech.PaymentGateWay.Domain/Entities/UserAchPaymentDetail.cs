﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.PaymentGateWay.Domain.Entities
{
    [Table("UserAchPaymentDetail")]
    public class UserAchPaymentDetail : BaseEntity
    {
        [Key]
        public int UserAchPaymentDetailId { get; set; }
        public int UserAchPaymentId { get; set; }
        public int PaymentId { get; set; }
        public int? StoreId { get; set; }
        public string StoreName { get; set; }
        public int UserId { get; set; }
        public decimal Amount { get; set; }
        public string AccountName { get; set; }
        public string AccountNo { get; set; }
        public string RoutingNo { get; set; }
        public string IdentificationNumber { get; set; }
        public bool IsChecking { get; set; }
        public bool MarkUnPaid { get; set; }
        public string Reason { get; set; }
    }
}