﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.PaymentGateWay.Domain.Entities
{
    [Table("WebHookDetail")]
    public class WebHookDetail : BaseEntity
    {
        [Key]
        public long WebHookDetailId { get; set; }
        public string Message { get; set; }
    }
}
