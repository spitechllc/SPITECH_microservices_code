﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.PaymentGateWay.Domain.Entities
{

    [Table("NMITransactionDetailsAction")]
    public class NMITransactionDetailsAction:BaseEntity
    {
        [Key]
        public int NMITransactionDetailsActionId { get; set; }
        public int NMITransactionDetailsId { get; set; }
        public decimal Amount { get; set; }

        public string ActionType { get; set; }

        public string ActionDate { get; set; }

        public bool Success { get; set; }

        public string IpAddress { get; set; }

        public byte ResponseCode { get; set; }

        public string ProcessorResponseText { get; set; }

        public string ProcessorResponseCode { get; set; }
    }
}
