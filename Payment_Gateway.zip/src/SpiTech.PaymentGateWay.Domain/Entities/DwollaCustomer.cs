﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.PaymentGateWay.Domain.Entities
{
    [Table("DwollaCustomer")]
    public class DwollaCustomer : BaseEntity
    {
        [Key]
        public int CustomerId { get; set; }
        public int UserId { get; set; }
        public int StoreId { get; set; }
        public string DwollaCustomerUrl { get; set; }
        public string DwollaCutomerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string IpAddress { get; set; }
        public string Type { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string PostalCode { get; set; }
        public DateTime DOB { get; set; }
        public string SSN { get; set; }

    }
}
