﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.PaymentGateWay.Domain.Entities
{

    [Table("NMITransactionDetails")]
    public class NMITransactionDetails:BaseEntity
    {
        [Key]
        public int NMITransactionDetailsId { get; set; }
        public long TransactionId { get; set; }

        public string TransactionType { get; set; }

        public string Condition { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public string PostalCode { get; set; }

        public string Country { get; set; }

        public string ProcessorId { get; set; }

        public decimal Tax { get; set; }

        public string Currency { get; set; }

        public string CcType { get; set; }
    }
}
