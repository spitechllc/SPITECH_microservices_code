﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Configs;
using System;

namespace SpiTech.PaymentGateWay.Domain.Entities
{
    [Table("PaymentGatewayConfig")]
    public class PaymentGatewayConfig : BaseEntity
    {
        [Key]
        public int PaymentGatewayConfigId { get; set; }
        public string GateWayName { get; set; }
        public bool IsProdEnabled { get; set; }
    }
}
