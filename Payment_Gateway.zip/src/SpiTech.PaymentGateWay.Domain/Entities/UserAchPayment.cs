﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;
using System.Collections.Generic;

namespace SpiTech.PaymentGateWay.Domain.Entities
{
    [Table("UserAchPayment")]
    public class UserAchPayment : BaseEntity
    {
        [Key]
        public int UserAchPaymentId { get; set; }
        public DateTime BusinessDate { get; set; }
        public decimal TotalAmount { get; set; }
        public int TotalRecord { get; set; }
        public string AccountName { get; set; }
        public string Bank { get; set; }
        public string AccountNo { get; set; }
        public string RoutingNo { get; set; }
        public bool IsChecking { get; set; }
        public string NachaFilePath { get; set; }
        public string NachaFileName { get; set; }
        public bool IsNachaUploaded { get; set; }
        public string NachaUploadError { get; set; }

        [Computed]
        public List<UserAchPaymentDetail> UserAchPaymentDetails { get; set; } = new List<UserAchPaymentDetail>();
    }
}