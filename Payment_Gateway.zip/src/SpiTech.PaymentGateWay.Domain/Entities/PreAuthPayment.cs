﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.PaymentGateWay.Domain.Entities
{
    [Table("PreAuthPayment")]
    public class PreAuthPayment : BaseEntity
    {
        [Key]
        public int PreAuthPaymentId { get; set; }
        public string PreAuthConfirmationNo { get; set; }
        public int UserPaymentMethodId { get; set; }
        public int PaymentGatewayConfigId { get; set; }
        public int PaymentMethodId { get; set; }
        public int UserId { get; set; }
        public long? TransactionId { get; set; }
        public int? StoreId { get; set; }
        public string SiteId { get; set; }
        public string StoreName { get; set; }
        public decimal Amount { get; set; }
        public int TransactionType { get; set; }
        public string Description { get; set; }
        public DateTime PreAuthDate { get; set; }
        public string CardNumber { get; set; }
        public string CardType { get; set; }
        public string AccountNumber { get; set; }
        public string AccountType { get; set; }
        public string BankName { get; set; }
        public string ConsumerIP { get; set; }
        public bool Success { get; set; }
        public decimal CardAmount { get; set; }
        public string CardResponse { get; set; }
        public string CardPreAuthConfirmationNo { get; set; }
        public int? CardPreAuthPaymentStatusId { get; set; }
        public decimal WalletAmount { get; set; }
        public string WalletResponse { get; set; }
        public string WalletPreAuthConfirmationNo { get; set; }
        public int? WalletPreAuthPaymentStatusId { get; set; }
        public bool IsPaymentRequired { get; set; }
    }
}
