﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.PaymentGateWay.Domain.Entities
{
    [Table("SaleAgentConfig")]
    public class SaleAgentConfig : BaseEntity
    {
        [ExplicitKey]
        public int SaleAgentId { get; set; }
        public string AccountName { get; set; }
        public string Bank { get; set; }
        public string AccountNo { get; set; }
        public string RoutingNo { get; set; }
        public bool IsChecking { get; set; }
    }
}
