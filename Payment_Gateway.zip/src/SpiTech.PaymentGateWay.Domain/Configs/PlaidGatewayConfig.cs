﻿using System.Collections.Generic;

namespace SpiTech.PaymentGateWay.Domain.Configs
{
    public class PlaidGatewayConfigs : List<PlaidGatewayConfig>
    {
    }
    public class PlaidGatewayConfig
    {
        public string BaseUrl { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public bool IsProd { get; set; }
    }
}
