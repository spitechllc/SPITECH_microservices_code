﻿namespace SpiTech.PaymentGateWay.Domain.Configs
{
    public class AppSetting
    {
        public string GateWayPath { get; set; }
    }
}
