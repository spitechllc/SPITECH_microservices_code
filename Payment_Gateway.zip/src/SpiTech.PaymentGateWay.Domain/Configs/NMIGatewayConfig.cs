﻿using System.Collections.Generic;

namespace SpiTech.PaymentGateWay.Domain.Configs
{
    public class NMIGatewayConfigs : List<NMIGatewayConfig>
    {
    }

    public class NMIGatewayConfig
    {
        public string BaseUrl { get; set; }
        public string PublicSecurityKeys { get; set; }
        public string PrivateSecurityKeys { get; set; }
        public bool IsProd { get; set; }
    }
}