﻿namespace SpiTech.PaymentGateWay.Domain.Configs
{
    public class EncryptionDecryptionKey
    {
        public string EncryptDecryptKey { get; set; }
    }
}
