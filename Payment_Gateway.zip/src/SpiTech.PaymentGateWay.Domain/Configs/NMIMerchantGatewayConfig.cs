﻿using System.Collections.Generic;

namespace SpiTech.PaymentGateWay.Domain.Configs
{
    public class NMIMerchantGatewayConfigs : List<NMIMerchantGatewayConfig>
    {
    }

    public class NMIMerchantGatewayConfig
    {
        public string BaseUrl { get; set; }
        public string PublicSecurityKeys { get; set; }
        public string PrivateSecurityKeys { get; set; }
        public bool IsProd { get; set; }
    }
}