﻿namespace SpiTech.PaymentGateWay.Domain.Configs
{
    public class GcsConfig
    {
        public string AuthKeyFile { get; set; }
        public string AuroraBucketName { get; set; }
        public bool Enabled { get; set; }
    }
}
