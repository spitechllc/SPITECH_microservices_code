﻿using System.Collections.Generic;

namespace SpiTech.PaymentGateWay.Domain.Configs
{
    public class DwollaGatewayConfigs : List<DwollaGatewayConfig>
    {
    }

    public class DwollaGatewayConfig
    {
        public string BaseUrl { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public bool IsProd { get; set; }
    }
}
