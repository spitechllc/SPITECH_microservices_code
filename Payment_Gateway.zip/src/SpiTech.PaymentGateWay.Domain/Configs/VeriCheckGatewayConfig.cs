﻿using System.Collections.Generic;

namespace SpiTech.PaymentGateWay.Domain.Configs
{
    public class VeriCheckGatewayConfigs : List<VeriCheckGatewayConfig>
    {
    }

    public class VeriCheckGatewayConfig
    {
        public string BaseUrl { get; set; }
        public string PublicSecurityKeys { get; set; }
        public string PrivateSecurityKeys { get; set; }
        public bool IsProd { get; set; }
    }
}