﻿using System;
using System.Collections.Specialized;
using System.Globalization;
using System.Text;
using System.Web;

namespace SpiTech.PaymentGateWay.Domain
{
    public class CommonUtility
    {
        public static DateTime GetDate(string strdate)
        {
            string[] inputformate = { "M/d/yyyy h:mm:ss tt", "MM/dd/yyyy h:mm:ss tt", "yyyy-MM-dd", "yyyy-M-d" };
            DateTime.TryParseExact(strdate, inputformate, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date);
            return date;
        }
    }

    public static class StringExtensions
    {
        /// <summary>
        ///     Parses a query string into a  using  encoding.
        /// </summary>
        /// <param name="query">The query string to parse.</param>
        /// <returns>A  of query parameters and values.</returns>
        public static NameValueCollection ParseQueryString(this String query)
        {
            return HttpUtility.ParseQueryString(query);
        }

        /// <summary>
        ///     Parses a query string into a  using the specified .
        /// </summary>
        /// <param name="query">The query string to parse.</param>
        /// <param name="encoding">The  to use.</param>
        /// <returns>A  of query parameters and values.</returns>
        public static NameValueCollection ParseQueryString(this String query, Encoding encoding)
        {
            return HttpUtility.ParseQueryString(query, encoding);
        }
    }
}
