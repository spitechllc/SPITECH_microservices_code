﻿using System;

namespace SpiTech.PaymentGateWay.Domain.Models
{
    public class DwollaTransactionStatusModel
    {

        public class Rootobject
        {
            public _Links _links { get; set; }
            public string id { get; set; }
            public string status { get; set; }
            public Amount amount { get; set; }
            public DateTime created { get; set; }
            public Clearing clearing { get; set; }
        }

        public class _Links
        {
            public Cancel cancel { get; set; }
            public Source source { get; set; }
            public FundingTransfer fundingtransfer { get; set; }
            public DestinationFundingSource destinationfundingsource { get; set; }
            public Self self { get; set; }
            public SourceFundingSource sourcefundingsource { get; set; }
            public Destination destination { get; set; }
        }

        public class Cancel
        {
            public string href { get; set; }
            public string type { get; set; }
            public string resourcetype { get; set; }
        }

        public class Source
        {
            public string href { get; set; }
            public string type { get; set; }
            public string resourcetype { get; set; }
        }

        public class FundingTransfer
        {
            public string href { get; set; }
            public string type { get; set; }
            public string resourcetype { get; set; }
        }

        public class DestinationFundingSource
        {
            public string href { get; set; }
            public string type { get; set; }
            public string resourcetype { get; set; }
        }

        public class Self
        {
            public string href { get; set; }
            public string type { get; set; }
            public string resourcetype { get; set; }
        }

        public class SourceFundingSource
        {
            public string href { get; set; }
            public string type { get; set; }
            public string resourcetype { get; set; }
        }

        public class Destination
        {
            public string href { get; set; }
            public string type { get; set; }
            public string resourcetype { get; set; }
        }

        public class Amount
        {
            public string value { get; set; }
            public string currency { get; set; }
        }

        public class Clearing
        {
            public string source { get; set; }
        }

    }
}
