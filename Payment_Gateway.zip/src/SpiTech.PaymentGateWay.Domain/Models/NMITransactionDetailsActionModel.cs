﻿using Dapper.Contrib.Extensions;

namespace SpiTech.PaymentGateWay.Domain.Models
{

   
    public class NMITransactionDetailsActionModel
    {      
        public int NMITransactionDetailsId { get; set; }
        public decimal Amount { get; set; }

        public string ActionType { get; set; }

        public string ActionDate { get; set; }

        public bool Success { get; set; }

        public string IpAddress { get; set; }

        public byte ResponseCode { get; set; }

        public string ProcessorResponseText { get; set; }

        public string ProcessorResponseCode { get; set; }
    }
}
