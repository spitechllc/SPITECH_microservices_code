﻿using SpiTech.PaymentGateWay.Domain.Configs;

namespace SpiTech.PaymentGateWay.Domain.Models
{
    public class ACHAuthorizationModel
    {
        public string AccessToken { get; set; }
        public string BankName { get; set; }
        public int UserPaymentMethodId { get; set; }
        public int PaymentGateway { get; set; }
        public int UserId { get; set; }
        public AppSetting AppSetting { get; set; }
    }
}
