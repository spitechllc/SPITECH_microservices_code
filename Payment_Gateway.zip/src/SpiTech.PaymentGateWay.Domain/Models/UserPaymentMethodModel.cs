﻿namespace SpiTech.PaymentGateWay.Domain.Models
{
    public class UserPaymentMethodModel
    {
        public int UserPaymentMethodId { get; set; }
        public int PaymentMethodId { get; set; }
        public int PaymentGatewayConfigId { get; set; }
        public int? UserId { get; set; }
        public string CardName { get; set; }
        public string CardExpDate { get; set; }
        public string CardNumber { get; set; }
        public string CardType { get; set; }
        public string AccountNumber { get; set; }
        public string AccountType { get; set; }
        public string BankName { get; set; }
        public string CustId { get; set; }
        public string Operation { get; set; }
        public string Source { get; set; }
        public string NickName { get; set; }
        public string RoutingNumber { get; set; }
        public bool IsDefault { get; set; }
        public bool IsRemoved { get; set; }
        public bool IsFraud { get; set; }
    }
}
