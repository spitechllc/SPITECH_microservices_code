﻿namespace SpiTech.PaymentGateWay.Domain.Models
{
    public class ResellerConfigModel
    {
        public int ResellerId { get; set; }
        public string AccountName { get; set; }
        public string Bank { get; set; }
        public string AccountNo { get; set; }
        public string RoutingNo { get; set; }
        public bool IsChecking { get; set; }
        public bool IsActive { get; set; }
    }
}
