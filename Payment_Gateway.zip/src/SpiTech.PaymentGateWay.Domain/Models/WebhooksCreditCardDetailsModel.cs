﻿namespace SpiTech.PaymentGateWay.Domain.Models
{
    public class WebhooksCreditCardDetailsModel
    {

        public class Rootobject
        {
            public string event_id { get; set; }
            public string event_type { get; set; }
            public Event_Body event_body { get; set; }
        }

        public class Event_Body
        {
            public Merchant merchant { get; set; }
            public Features features { get; set; }
            public string transaction_id { get; set; }
            public string transaction_type { get; set; }
            public string condition { get; set; }
            public string processor_id { get; set; }
            public string ponumber { get; set; }
            public string order_description { get; set; }
            public string order_id { get; set; }
            public string customerid { get; set; }
            public string customertaxid { get; set; }
            public string website { get; set; }
            public string shipping { get; set; }
            public string currency { get; set; }
            public string tax { get; set; }
            public string surcharge { get; set; }
            public string cash_discount { get; set; }
            public string tip { get; set; }
            public string requested_amount { get; set; }
            public string shipping_carrier { get; set; }
            public string tracking_number { get; set; }
            public string shipping_date { get; set; }
            public string partial_payment_id { get; set; }
            public string partial_payment_balance { get; set; }
            public string platform_id { get; set; }
            public string authorization_code { get; set; }
            public string social_security_number { get; set; }
            public string drivers_license_number { get; set; }
            public string drivers_license_state { get; set; }
            public string drivers_license_dob { get; set; }
            public Billing_Address billing_address { get; set; }
            public Shipping_Address shipping_address { get; set; }
            public Card card { get; set; }
            public Action action { get; set; }
        }

        public class Merchant
        {
            public string id { get; set; }
            public string name { get; set; }
        }

        public class Features
        {
            public bool is_test_mode { get; set; }
        }

        public class Billing_Address
        {
            public string first_name { get; set; }
            public string last_name { get; set; }
            public string address_1 { get; set; }
            public string address_2 { get; set; }
            public string company { get; set; }
            public string city { get; set; }
            public string state { get; set; }
            public string postal_code { get; set; }
            public string country { get; set; }
            public string email { get; set; }
            public string phone { get; set; }
            public string cell_phone { get; set; }
            public string fax { get; set; }
        }

        public class Shipping_Address
        {
            public string first_name { get; set; }
            public string last_name { get; set; }
            public string address_1 { get; set; }
            public string address_2 { get; set; }
            public string company { get; set; }
            public string city { get; set; }
            public string state { get; set; }
            public string postal_code { get; set; }
            public string country { get; set; }
            public string email { get; set; }
            public string phone { get; set; }
            public string fax { get; set; }
        }

        public class Card
        {
            public string cc_number { get; set; }
            public string cc_exp { get; set; }
            public string cavv { get; set; }
            public string cavv_result { get; set; }
            public string xid { get; set; }
            public string eci { get; set; }
            public string avs_response { get; set; }
            public string csc_response { get; set; }
            public string cardholder_auth { get; set; }
            public string cc_start_date { get; set; }
            public string cc_issue_number { get; set; }
            public string card_balance { get; set; }
            public string card_available_balance { get; set; }
            public string entry_mode { get; set; }
            public string cc_bin { get; set; }
            public string cc_type { get; set; }
        }

        public class Action
        {
            public string amount { get; set; }
            public string action_type { get; set; }
            public string date { get; set; }
            public string success { get; set; }
            public string ip_address { get; set; }
            public string source { get; set; }
            public string api_method { get; set; }
            public string username { get; set; }
            public string response_text { get; set; }
            public string response_code { get; set; }
            public string processor_response_text { get; set; }
            public string processor_response_code { get; set; }
            public string device_license_number { get; set; }
            public string device_nickname { get; set; }
        }

    }
}
