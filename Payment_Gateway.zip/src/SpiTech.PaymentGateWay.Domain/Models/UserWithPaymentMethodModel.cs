﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Domain.Models
{
    public class UserWithPaymentMethodModel
    {
        public int UserId { get; set; }
        public int PaymentMethodId { get; set; }
    }
}
