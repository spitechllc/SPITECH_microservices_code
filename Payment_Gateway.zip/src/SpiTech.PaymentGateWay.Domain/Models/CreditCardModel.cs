﻿using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.Service.Clients.Identity;

namespace SpiTech.PaymentGateWay.Domain.Models
{
    public class CreditCardModel
    {
        public string AccessToken { get; set; }
        public string Token { get; set; }
        public int PaymentMethod { get; set; }
        public int PaymentGateway { get; set; }
        public UserModel User { get; set; }
        public AppSetting AppSetting { get; set; }
        public string TenantName { get; set; }
    }
}