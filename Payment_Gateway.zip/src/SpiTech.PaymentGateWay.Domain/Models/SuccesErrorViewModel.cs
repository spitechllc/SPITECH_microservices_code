﻿using SpiTech.PaymentGateWay.Domain.Configs;

namespace SpiTech.PaymentGateWay.Domain.Models
{
    public class SuccesErrorViewModel
    {
        public AppSetting AppSetting { get; set; }
        public string ErrorMessage { get; set; }
        public string SuccessMessage { get; set; }
    }
}
