﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Domain.Models
{
    public class NMITransactionsDetailsModel
    {

        public nm_responseTransaction[] transaction { get; set; }


    }

    //public partial class nm_response
    //{
    //    public nm_responseTransaction nm_responseTransaction { get; set; }
    //}
    public class nm_responseTransaction
    {
        public long transaction_id { get; set; }

        public string transaction_type { get; set; }

        public string condition { get; set; }

        public string city { get; set; }

        public string state { get; set; }

        public string postal_code { get; set; }

        public string country { get; set; }

        public string processor_id { get; set; }

        public decimal tax { get; set; }

        public string currency { get; set; }

        public string cc_type { get; set; }

        public int storeid { get; set; }

        public string storename { get; set; }

        public object action { get; set; }
    }   

    public class nm_responseTransactionAction
    {

        public decimal amount { get; set; }

        public string action_type { get; set; }

        public string date { get; set; }

        public byte success { get; set; }

        public string ip_address { get; set; }

        public byte response_code { get; set; }

        public string processor_response_text { get; set; }

        public string processor_response_code { get; set; }

    }



}

