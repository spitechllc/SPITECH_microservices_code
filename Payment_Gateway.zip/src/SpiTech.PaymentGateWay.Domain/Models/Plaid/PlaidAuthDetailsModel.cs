﻿namespace SpiTech.PaymentGateWay.Domain.Models.Plaid
{
    public class PlaidAuthDetailsModel
    {
        public Account[] accounts { get; set; }
        public Item item { get; set; }
        public Numbers numbers { get; set; }
        public string request_id { get; set; }
    }

    public class Item
    {
        public string[] available_products { get; set; }
        public string[] billed_products { get; set; }
        public string consent_expiration_time { get; set; }
        public string error { get; set; }
        public string institution_id { get; set; }
        public string item_id { get; set; }
        public string optional_products { get; set; }
        public string[] products { get; set; }
        public string update_type { get; set; }
        public string webhook { get; set; }
    }

    public class Numbers
    {
        public Ach[] ach { get; set; }
        public string[] bacs { get; set; }
        public string[] eft { get; set; }
        public string[] international { get; set; }
    }

    public class Ach
    {
        public string account { get; set; }
        public string account_id { get; set; }
        public string routing { get; set; }
        public string wire_routing { get; set; }
    }

    public class Account
    {
        public string account_id { get; set; }
        public Balances balances { get; set; }
        public string mask { get; set; }
        public string name { get; set; }
        public string official_name { get; set; }
        public string subtype { get; set; }
        public string type { get; set; }
    }

    public class Balances
    {
        public string available { get; set; }
        public string current { get; set; }
        public string iso_currency_code { get; set; }
        public string limit { get; set; }
        public string unofficial_currency_code { get; set; }
    }
   
}
