﻿using System;

namespace SpiTech.PaymentGateWay.Domain.Models.Plaid
{
    public class PlaidLinkTokenResponse
    {
        public DateTime expiration { get; set; }
        public string link_token { get; set; }
        public string request_id { get; set; }
    }
}
