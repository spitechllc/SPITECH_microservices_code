﻿namespace SpiTech.PaymentGateWay.Domain.Models.Plaid
{
    public class PlaidProcessorTokenResponse
    {
        public string processor_token { get; set; }
        public string request_id { get; set; }
    }
}
