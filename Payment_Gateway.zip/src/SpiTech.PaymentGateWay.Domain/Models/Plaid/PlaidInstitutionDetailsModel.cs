﻿namespace SpiTech.PaymentGateWay.Domain.Models.Plaid
{
    public class PlaidInstitutionDetailsModel
    {
        public Institution institution { get; set; }
        public string request_id { get; set; }


        public class Institution
        {
            public string[] country_codes { get; set; }
            public string institution_id { get; set; }
            public string name { get; set; }
            public bool oauth { get; set; }
            public string[] products { get; set; }
            public string[] routing_numbers { get; set; }
        }

    }
}