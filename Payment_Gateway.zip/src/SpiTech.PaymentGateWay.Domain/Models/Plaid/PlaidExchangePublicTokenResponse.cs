﻿namespace SpiTech.PaymentGateWay.Domain.Models.Plaid
{
    public class PlaidExchangePublicTokenResponse
    {
        public string access_token { get; set; }
        public string item_id { get; set; }
        public string request_id { get; set; }
    }
}
