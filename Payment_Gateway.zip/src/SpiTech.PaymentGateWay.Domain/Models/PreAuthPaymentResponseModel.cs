﻿using SpiTech.EventBus.DomainEvents.Enums;

namespace SpiTech.PaymentGateWay.Domain.Models
{
    public class PreAuthPaymentResponseModel
    {
        public string PreAuthConfirmationNo { get; set; }
        public int PaymentMethodId { get; set; }
        public int UserPaymentMethodId { get; set; }
        public int UserId { get; set; }
        public long? TransactionId { get; set; }
        public decimal Amount { get; set; }
        public decimal CardAmount { get; set; }
        public decimal WalletAmount { get; set; }
        public string CardNumber { get; set; }
        public string CardType { get; set; }
        public string AccountNumber { get; set; }
        public string AccountType { get; set; }
        public bool Success { get; set; }
        public string CardNumberPrint => !string.IsNullOrEmpty(CardNumber) ? CardNumber : AccountNumber;
        public string CardTypePrint => !string.IsNullOrEmpty(CardType) ? CardType : AccountType;
        public string PaymentType => PaymentMethodId == (int)EnumPaymentMethod.ACH
                    ? "Cash"
                    : PaymentMethodId == (int)EnumPaymentMethod.CreditCard
                    ? "Credit"
                    : PaymentMethodId == (int)EnumPaymentMethod.CashReward ? "Credit" : "";
    }
}
