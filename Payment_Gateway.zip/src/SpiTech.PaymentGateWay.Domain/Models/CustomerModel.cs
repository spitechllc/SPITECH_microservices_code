﻿using SpiTech.PaymentGateWay.Domain.Configs;
using System.ComponentModel.DataAnnotations;

namespace SpiTech.PaymentGateWay.Domain.Models
{
    public class CustomerModel
    {
        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        [Required]
        public string Email { get; set; }
        public string IpAddress { get; set; }

        [Required]
        public string Address { get; set; }

        [Required]
        public string City { get; set; }

        [Required]
        public string State { get; set; }

        [Required]
        public string PostalCode { get; set; }

        [Required]
        public string Dob { get; set; }

        [Required]
        public string SSN { get; set; }

        //[Required]

        public int UserId { get; set; }
        public int StoreId { get; set; }

        public string AccessToken { get; set; }
        public string Token { get; set; }

        public AppSetting AppSetting { get; set; }

    }
}
