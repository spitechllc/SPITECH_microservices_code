﻿namespace SpiTech.PaymentGateWay.Domain.Models
{
    public class StoreConfigDecryptModel
    {
        public int StoreId { get; set; }
        public string AccountName { get; set; }
        public string Bank { get; set; }
        public string MaskAccountNo { get; set; }
        public string AccountNo { get; set; }
        public string RoutingNo { get; set; }
        public bool IsChecking { get; set; }
        public bool IsMasterAccount { get; set; }
        public string PaymentProcessorId { get; set; }
        public string ACHProcessorId { get; set; }
        public bool IsActive { get; set; }
        public bool? IsAchEnabled { get; set; }

    }
}
