﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Domain.Models
{

    public class NMIMerchantResponseModel
    {
        public int id { get; set; }
        public string processor_id { get; set; }
        public string platform { get; set; }
        public object descriptor { get; set; }
        public object descriptor_phone { get; set; }
        public string default_industry_classification { get; set; }
        public string max_transaction_amount { get; set; }
        public string max_monthly_volume { get; set; }
        public bool enable_duplicate_checking { get; set; }
        public bool allow_duplicate_checking_override { get; set; }
        public int duplicate_checking_seconds { get; set; }
        public string precheck_method { get; set; }
        public string currencies { get; set; }
        public string processor_description { get; set; }
        public int mcc { get; set; }
        public string processor_config_1 { get; set; }
        public string processor_config_2 { get; set; }
        public bool processor_config_3 { get; set; }
        public object processor_config_4 { get; set; }
        public object processor_config_5 { get; set; }
        public object processor_config_6 { get; set; }
        public object processor_config_7 { get; set; }
        public object processor_config_8 { get; set; }
        public object processor_config_9 { get; set; }
        public object processor_config_10 { get; set; }
        public object processor_config_11 { get; set; }
        public object processor_config_12 { get; set; }
        public object processor_config_13 { get; set; }
        public object processor_config_14 { get; set; }
        public object processor_config_15 { get; set; }
        public object processor_config_16 { get; set; }
        public object processor_config_17 { get; set; }
        public object processor_config_18 { get; set; }
        public object processor_config_19 { get; set; }
        public object processor_config_20 { get; set; }
        public string status { get; set; }
        public string required_fields { get; set; }
        public string payment_types { get; set; }
    
    }
}
