﻿using CsvHelper.Configuration.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Domain.Models
{
    public class NmiTransactionModel
    {
        [Name("transactionidentifier")]
        public string TransactionIdentifier { get; set; }

        [Name("transactiondate")]
        public DateTime? TransactionDate { get; set; }

        [Name("dbaname")]
        public string DbaName { get; set; }

        [Name("merchantmcccode")]
        public int? MerchantMccCode { get; set; }

        [Name("mid")]
        public long? MId { get; set; }

        [Name("debitorcreditindicator")]
        public string DebitOrCreditIndicator { get; set; }

        [Name("transactionamount")]
        public double? TransactionAmount { get; set; }

        [Name("cardtype")]
        public string CardType { get; set; }

        [Name("cardtype2")]
        public string CardType2 { get; set; }

        [Name("cardfirst6")]
        public string CardFirst6 { get; set; }

        [Name("cardlast4to5")]
        public string CardLast4To5 { get; set; }

        [Name("cardhash")]
        public string CardHash { get; set; }

        [Name("networkidentifierdebit")]
        public string NetworkIdentifierDebit { get; set; }

        [Name("posdatacode")]
        public string PosDataCode { get; set; }

        [Name("posentrymode")]
        public string PosEntryMode { get; set; }

        [Name("recordidentifier")]
        public string RecordIdentifier { get; set; }

        [Name("terminalid")]
        public string TerminalId { get; set; }

        [Name("totalauthorizedamount")]
        public string TotalAuthorizedAmount { get; set; }

        [Name("authorizationnumber")]
        public string AuthorizationNumber { get; set; }

        [Name("authamount")]
        public double? AuthAmount { get; set; }

        [Name("originaltransactionamount")]
        public double? OriginalTransactionAmount { get; set; }

        [Name("rejectreason")]
        public string RejectReason { get; set; }

        [Name("mailorderortelephoneorderindicator")]
        public int? MailOrderOrTelephoneOrderIndicator { get; set; }

        [Name("achflag")]
        public string AchFlag { get; set; }

        [Name("aci")]
        public string Aci { get; set; }

        [Name("associationnumber2")]
        public int? AssociationNumber2 { get; set; }

        [Name("authcurrencycode")]
        public int? AuthCurrencyCode { get; set; }

        [Name("authsource")]
        public string Authsource { get; set; }

        [Name("banknetauthdate")]
        public int? BanknetAuthDate { get; set; }

        [Name("banknetreferencenumber")]
        public string BanknetReferenceNumber { get; set; }

        [Name("batchjuliandate")]
        public int? BatchJulianDate { get; set; }

        [Name("bestinterchangeeligible")]
        public string BestInterChangeEligible { get; set; }

        [Name("cardholderiordmethod")]
        public int? CardHolderIordMethod { get; set; }

        [Name("carryoverindicator")]
        public string CarryOverIndicator { get; set; }

        [Name("cashbackamount")]
        public double? CashbackAmount { get; set; }

        [Name("cashbackamountsign")]
        public string CashbackAmountSign { get; set; }

        [Name("catindicator")]
        public int? CatIndicator { get; set; }

        [Name("currencycode")]
        public int? CurrencyCode { get; set; }

        [Name("discovernetworkreferenceid")]
        public string DiscoverNetworkReferenceId { get; set; }

        [Name("discoverprocessingcode")]
        public string DiscoverProcessingCode { get; set; }

        [Name("discovertransactiontype")]
        public string DiscoverTransactionType { get; set; }

        [Name("downgradereason1")]
        public string DownGradeReason1 { get; set; }

        [Name("downgradereason2")]
        public string DownGradeReason2 { get; set; }

        [Name("downgradereason3")]
        public string DownGradeReason3 { get; set; }

        [Name("draftaflag")]
        public string DraftaFlag { get; set; }

        [Name("entryrunnumber")]
        public int? EntryRunNumber { get; set; }

        [Name("extensionrecordindicator")]
        public string ExtensionRecordIndicator { get; set; }

        [Name("foreigncardindicator")]
        public string ForeignCardIndicator { get; set; }

        [Name("ddfmcccode")]
        public int? DdfMccCode { get; set; }

        [Name("netdeposit")]
        public double? NetDeposit { get; set; }

        [Name("onlineentry")]
        public string OnlineEntry { get; set; }

        [Name("productid")]
        public string ProductId { get; set; }

        [Name("purchaseid")]
        public long? PurchaseId { get; set; }

        [Name("reimbursementattribute")]
        public int? ReimbursementAttribute { get; set; }

        [Name("reversalflag")]
        public string ReversalFlag { get; set; }

        [Name("sequencenumberarea")]
        public int? SequenceNumberArea { get; set; }

        [Name("sequencenumberwithinentryrun")]
        public int? SequenceNumberWithInEntryRun { get; set; }

        [Name("submittedinterchange")]
        public int? SubmittedInterChange { get; set; }

        [Name("switchsettledindicator")]
        public string SwitchSettledIndicator { get; set; }

        [Name("systemtraceauditnumber")]
        public string SystemTraceAuditNumber { get; set; }

        [Name("transactioncode")]
        public int? TransactionCode { get; set; }

        [Name("transactiondataconditioncode")]
        public string TransactionDataConditionCode { get; set; }

        [Name("transactiontypeidentifier")]
        public int? TransactionTypeIdentifier { get; set; }

        [Name("validationcode")]
        public string ValidationCode { get; set; }

        [Name("cardbrandfeecode")]
        public string CardBrandFeeCode { get; set; }

        [Name("commercialcardserviceindicator")]
        public string CommercialCardServiceIndicator { get; set; }

        [Name("interchangefeeamount")]
        public string InterchangeFeeAmount { get; set; }

        [Name("interchangepercentrate")]
        public string InterchangePercentrate { get; set; }

        [Name("interchangeperitemrate")]
        public string InterchangePeritemRate { get; set; }

        [Name("mastercardtransactionintegrityclass")]
        public string MasterCardTransactionIntegrityClass { get; set; }

        [Name("mastercardwalletidentifier")]
        public string MasterCardWalletIdentifier { get; set; }

        [Name("mccashbackfee")]
        public double? McCashBackFee { get; set; }

        [Name("mccashbackfeesign")]
        public string McCashBackFeeSign { get; set; }

        [Name("merchantassignedreferencenumber")]
        public string MerchantAssignedReferenceNumber { get; set; }

        [Name("netdepositadjustmentamount")]
        public string NetDepositAdjustmentAmount { get; set; }

        [Name("netdepositadjustmentdc")]
        public string NetDepositAdjustmentDc { get; set; }

        [Name("operatorid")]
        public string OperatorId { get; set; }

        [Name("regulatedindicator")]
        public string RegulatedIndicator { get; set; }

        [Name("requestedpaymentservice")]
        public string RequestedPaymentService { get; set; }

        [Name("transactionfeeamount")]
        public string TransactionFeeAmount { get; set; }

        [Name("transactionfeeamountincardholderbillingcurrency")]
        public string TransactionFeeAmountInCardHolderBillingCurrency { get; set; }

        [Name("transactionfeedebitorcreditindicator")]
        public string TransactionFeeDebitOrCreditIndicator { get; set; }

        [Name("visafeeprogramindicator")]
        public string VisaFeeProgramIndicator { get; set; }

        [Name("visaintegrityfee")]
        public string VisaIntegrityFee { get; set; }

        [Name("visaspecialconditionindicator")]
        public string VisaSpecialConditionIndicator { get; set; }
    }
}
