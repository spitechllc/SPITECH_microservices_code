﻿namespace SpiTech.PaymentGateWay.Domain.Models
{
    public class PaymentMethodModel
    {
        public int PaymentMethodId { get; set; }
        public string PaymentMethodName { get; set; }
        public string PaymentType { get; set; }
    }
}
