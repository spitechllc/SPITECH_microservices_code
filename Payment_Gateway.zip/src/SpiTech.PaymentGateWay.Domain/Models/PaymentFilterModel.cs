﻿using System;

namespace SpiTech.PaymentGateWay.Domain.Models
{
    public class PaymentFilterModel
    {
        public int PreAuthPaymentId { get; set; }
        public int UserPaymentMethodId { get; set; }
        public string PaymentType { get; set; }
        public int PaymentMethodId { get; set; }
        public int UserId { get; set; }
        public int StoreId { get; set; }
        public string PreAuthStatus { get; set; }
        public string SiteId { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string PhoneNumber { get; set; }
        public string Street1 { get; set; }
        public string Street2 { get; set; }
        public string PreAuthConfirmationNo { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zipcode { get; set; }
        public string CardNumber { get; set; }
        public string CardExpiry { get; set; }
        public double Amount { get; set; }
        public string Description { get; set; }
        public string Email { get; set; }
        public string CompanyAccount { get; set; }
        public string CompanyName { get; set; }
        public DateTime PaymentDate { get; set; }
        public string Custom1 { get; set; }
        public string Custom2 { get; set; }
        public string Custom3 { get; set; }
        public string CardType { get; set; }
        public string AccountType { get; set; }
        public string BankName { get; set; }
        public string AccountNumber { get; set; }
        public string ConsumerIP { get; set; }

        // payment 

        public int PaymentId { get; set; }

        public long TransactionId { get; set; }
        public double PayAmount { get; set; }
        public string PayDescription { get; set; }

        public string FailureReason { get; set; }

        public bool FinalPayment { get; set; }


        [Newtonsoft.Json.JsonIgnore]
        [System.Text.Json.Serialization.JsonIgnore]
        public int TotalRecord { get; set; }
    }
}
