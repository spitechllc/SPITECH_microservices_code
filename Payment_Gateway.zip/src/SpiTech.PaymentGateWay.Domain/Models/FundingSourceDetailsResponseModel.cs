﻿using System;

namespace SpiTech.PaymentGateWay.Domain.Models
{
    public class FundingSourceDetailsResponseModel
    {

        public class Rootobject
        {
            public _Links _links { get; set; }
            public string id { get; set; }
            public string status { get; set; }
            public string type { get; set; }
            public string bankAccountType { get; set; }
            public string name { get; set; }
            public DateTime created { get; set; }
            public bool removed { get; set; }
            public string[] channels { get; set; }
            public string bankName { get; set; }
            public string fingerprint { get; set; }
        }

        public class _Links
        {
            public TransferFromBalance transferfrombalance { get; set; }
            public Self self { get; set; }
            public TransferToBalance transfertobalance { get; set; }
            public TransferSend transfersend { get; set; }
            public Remove remove { get; set; }
            public Customer customer { get; set; }
            public TransferReceive transferreceive { get; set; }
        }

        public class TransferFromBalance
        {
            public string href { get; set; }
            public string type { get; set; }
            public string resourcetype { get; set; }
        }

        public class Self
        {
            public string href { get; set; }
            public string type { get; set; }
            public string resourcetype { get; set; }
        }

        public class TransferToBalance
        {
            public string href { get; set; }
            public string type { get; set; }
            public string resourcetype { get; set; }
        }

        public class TransferSend
        {
            public string href { get; set; }
            public string type { get; set; }
            public string resourcetype { get; set; }
        }

        public class Remove
        {
            public string href { get; set; }
            public string type { get; set; }
            public string resourcetype { get; set; }
        }

        public class Customer
        {
            public string href { get; set; }
            public string type { get; set; }
            public string resourcetype { get; set; }
        }

        public class TransferReceive
        {
            public string href { get; set; }
            public string type { get; set; }
            public string resourcetype { get; set; }
        }

    }
}
