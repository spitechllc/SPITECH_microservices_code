﻿using SpiTech.EventBus.DomainEvents.Enums;

namespace SpiTech.PaymentGateWay.Domain.Models
{
    public class TransactionResponseModel
    {
        public string AuthConfirmationNo { get; set; }
        public string Response { get; set; }
        public EnumPaymentStatus? Status { get; set; }
    }
}
