﻿using System;

namespace SpiTech.PaymentGateWay.Domain.FilterOptions
{
    public class PaymentFilter
    {
        public int UserId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        //public string StoreName { get; set; }
        public bool? IsPaymentRequired { get; set; }
        public int TransactionId { get; set; }
        public string confirmationNumber { get; set; }
        public int? PageIndex { get; set; }
        public int? PageSize { get; set; }
    }
}
