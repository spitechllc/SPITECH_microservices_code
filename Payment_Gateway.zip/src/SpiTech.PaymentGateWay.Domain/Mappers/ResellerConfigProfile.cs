﻿using AutoMapper;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Domain.Mappers
{
    public class ResellerConfigProfile : Profile
    {
        public ResellerConfigProfile()
        {
            CreateMap<ResellerConfig, ResellerConfigModel>().ReverseMap();
        }
    }
}
