﻿using AutoMapper;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Domain.Mappers
{
    public class PaymentMethodProfile : Profile
    {
        public PaymentMethodProfile()
        {
            CreateMap<PaymentMethod, PaymentMethodModel>().ReverseMap();
        }
    }
}
