﻿using AutoMapper;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Domain.Mappers
{
    public class StoreConfigProfile : Profile
    {
        public StoreConfigProfile()
        {
            CreateMap<StoreConfig, StoreConfigModel>().ReverseMap();
            CreateMap<StoreConfig, StoreConfigDecryptModel>().ReverseMap();
        }
    }
}
