﻿using AutoMapper;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Domain.Mappers
{
    public class NmiTransactionProfile : Profile
    {
        public NmiTransactionProfile()
        {
            CreateMap<NmiTransaction, NmiTransactionModel>().ReverseMap();
        }
    }
}
