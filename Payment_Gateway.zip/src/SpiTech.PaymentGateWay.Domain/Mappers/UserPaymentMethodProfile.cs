﻿using AutoMapper;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Domain.Mappers
{
    public class UserPaymentMethodProfile : Profile
    {
        public UserPaymentMethodProfile()
        {
            CreateMap<UserPaymentMethod, UserPaymentMethodModel>().ReverseMap();
        }
    }
}
