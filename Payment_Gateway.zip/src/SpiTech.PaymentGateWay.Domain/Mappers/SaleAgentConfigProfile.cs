﻿using AutoMapper;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Domain.Mappers
{
    public class SaleAgentConfigProfile : Profile
    {
        public SaleAgentConfigProfile()
        {
            CreateMap<SaleAgentConfig, SaleAgentConfigModel>().ReverseMap();
        }
    }
}
