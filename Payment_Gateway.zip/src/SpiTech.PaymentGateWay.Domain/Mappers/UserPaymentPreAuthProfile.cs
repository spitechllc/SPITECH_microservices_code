﻿using AutoMapper;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Domain.Mappers
{
    public class PreAuthPaymentsProfile : Profile
    {
        public PreAuthPaymentsProfile()
        {
            CreateMap<PreAuthPayment, PreAuthPaymentModel>().ReverseMap();
            CreateMap<PreAuthPaymentResponseModel, PreAuthPaymentModel>().ReverseMap();
            CreateMap<PreAuthPayment, PreAuthPaymentResponseModel>().ReverseMap();
        }
    }
}
