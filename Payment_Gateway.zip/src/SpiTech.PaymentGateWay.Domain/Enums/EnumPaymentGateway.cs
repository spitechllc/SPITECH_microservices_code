﻿namespace SpiTech.PaymentGateWay.Domain.Enums
{
    public enum EnumPaymentGateway
    {
        None = 0,
        NMI = 1,
        PlaidWithDwolla = 2,
        PlaidWithStride = 3,
        PlaidWithNMI = 4,
        NMIPowerBI =5
    }
}
