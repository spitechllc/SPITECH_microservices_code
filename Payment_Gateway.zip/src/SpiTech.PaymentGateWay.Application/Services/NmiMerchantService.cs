﻿using MediatR;
using SpiTech.PaymentGateWay.Application.Queries.GetPaymentGatewayConfig;
using SpiTech.PaymentGateWay.Application.Services.Interfaces;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Enums;
using System;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Services
{
    public class NmiMerchantService : INmiMerchantService
    {
        private readonly IMediator mediator;
        private readonly NMIMerchantGatewayConfigs nmiGatewayConfigs;

        public NmiMerchantService(IMediator mediator, NMIMerchantGatewayConfigs nmiGatewayConfigs)
        {
            this.mediator = mediator;
            this.nmiGatewayConfigs = nmiGatewayConfigs;
        }

        public async Task<HttpResponseMessage> SendRequest(HttpMethod method, string entity, HttpContent content = null, string additional = null, string query = "")
        {
            using System.Net.Http.HttpClient httpClient = new();
            await SetClientAsync(httpClient, $"{entity}{(string.IsNullOrEmpty(additional) ? string.Empty : $"/{additional}")}", query);
            return method == HttpMethod.Get ? await httpClient.GetAsync(httpClient.BaseAddress)
                 : method == HttpMethod.Delete ? await httpClient.DeleteAsync(httpClient.BaseAddress)
                 : method == HttpMethod.Post ? await httpClient.PostAsync(httpClient.BaseAddress, content)
                 : method == HttpMethod.Put ? await httpClient.PutAsync(httpClient.BaseAddress, content)
                 : await PatchClient(httpClient, content);
        }

        private async Task<HttpResponseMessage> PatchClient(System.Net.Http.HttpClient httpClient, HttpContent content)
        {
            HttpRequestMessage request = new(new HttpMethod("PATCH"), httpClient.BaseAddress) { Content = content };
            return await httpClient.SendAsync(request);
        }

        private async Task SetClientAsync(System.Net.Http.HttpClient client, string entity, string query)
        {
            Domain.Entities.PaymentGatewayConfig nmiPaymentGatewayConfig = (await mediator.Send(new GetPaymentGatewayConfigQuery { })).Data.FirstOrDefault(t => t.PaymentGatewayConfigId == (int)EnumPaymentGateway.NMI);

            NMIMerchantGatewayConfig nmiGatewayConfig = nmiGatewayConfigs.FirstOrDefault(t => t.IsProd == nmiPaymentGatewayConfig.IsProdEnabled);

            string baseurl = nmiGatewayConfig.BaseUrl;
            client.BaseAddress = new Uri(baseurl + entity + (string.IsNullOrEmpty(query) ? "security_key=" + nmiGatewayConfig.PrivateSecurityKeys : "?" + query + "&security_key=" + nmiGatewayConfig.PrivateSecurityKeys));
        }
    }
}
