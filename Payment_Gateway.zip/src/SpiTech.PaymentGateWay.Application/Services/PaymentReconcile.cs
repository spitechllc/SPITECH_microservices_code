﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents;
using SpiTech.PaymentGateWay.Application.Services.Interfaces;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Services
{
    public class PaymentReconcile : IPaymentReconcile
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<PaymentReconcile> _logger;
        private readonly IMapper _mapper;
        private readonly IMediator _mediator;

        private readonly IEventDispatcher eventDispatcher;
        public PaymentReconcile(
                                IUnitOfWork context,
                                ILogger<PaymentReconcile> logger,
                                IMapper mapper,
                                IMediator mediator,
                                IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _mediator = mediator;
            this.eventDispatcher = eventDispatcher;

        }
        public async Task GetAllTransactionForReconcile(CancellationToken stoppingToken)
        {

            await GetRecocileList(1, 50);


        }


        private async Task GetRecocileList(int pageindex, int pagesize)
        {
            //int LastTransactionId = 0;
            //var reconcile = (await _context.PaymentReconciles.GetAll()).FirstOrDefault();
            //if (reconcile != null && reconcile.Id > 0)
            //{
            //    LastTransactionId = reconcile.EndTransactionid;
            //}
            //var res = await _transactionApiClient.PaymentReconcileAsync(pageindex, pagesize, LastTransactionId);


            //foreach (var item in res.Data)
            //{
            //    var payment = await _context.Payments.GetPaymentByTransactionId(item.TransactionId);

            //    if (payment == null)
            //    {
            //        //Save payment 

            //       await  SavePayment(item);
            //    }
            //    else if (payment.Success != item.IsPaymentSuccess)
            //    {
            //        // Send Notitfication

            //       await SendNotification(payment);
            //    }
            //}
            //if (pageindex < res.TotalPages)
            //{
            //    await GetRecocileList(pageindex + 1, 50);
            //}

            await Task.CompletedTask;
        }

        private async Task SendNotification(Payment payment)
        {
            //var preauth = await _context.PreAuthPayments.Get(payment.PreAuthPaymentId);
            //string storeName = "";
            //if (preauth != null)
            //{
            //    storeName = string.IsNullOrEmpty(preauth.Custom2) ? preauth.CompanyName : preauth.Custom2;
            //}

            //await this.eventDispatcher.Dispatch(
            //  new PaymentStatusEvent
            //  {
            //      Amount = (decimal)payment.Amount,
            //      TransactionId = payment.TransactionId,
            //      UMTI = payment.UMTI,
            //      UserId = payment.UserId,
            //      // PreauthConfirmationNo = payment.ConfirmationNumber,
            //      ProcessDate = DateTime.UtcNow,
            //      IsSuccess = payment.Success,
            //      ErrorMessage = payment.FailureReason,
            //      StoreName = storeName
            //  });
            await Task.CompletedTask;
        }
    }
}
