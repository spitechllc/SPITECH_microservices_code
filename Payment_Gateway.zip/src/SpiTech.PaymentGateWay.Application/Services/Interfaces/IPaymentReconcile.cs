﻿using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Services.Interfaces
{
    public interface IPaymentReconcile
    {
        Task GetAllTransactionForReconcile(CancellationToken stoppingToken);
    }
}
