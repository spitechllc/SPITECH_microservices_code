﻿using System.Net.Http;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Services.Interfaces
{
    public interface INmiService
    {
        Task<HttpResponseMessage> SendRequest(HttpMethod method, string entity, HttpContent content = null,
      string additional = null, string query = "");
    }
}
