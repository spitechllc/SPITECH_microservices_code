﻿using Microsoft.Extensions.DependencyInjection;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.BackgroudSerices;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Services
{
    public class AuroraGcsJobService : SchedulerJobService
    {
        private IAuroraGcsService auroraGcsService;
        private readonly ILogger<ScopeJobService> _logger;

        public AuroraGcsJobService(ILogger<ScopeJobService> logger, IServiceProvider serviceProvider) : base(logger, serviceProvider)
        {
            _logger = logger;
        }

        protected override void CreateScope(IServiceScope serviceScope)
        {
            auroraGcsService = serviceScope.ServiceProvider.GetRequiredService<IAuroraGcsService>();
        }

        protected override Task ExecuteScheduleTaskAsync(CancellationToken stoppingToken)
        {
            return auroraGcsService.ProcessFiles(stoppingToken);
        }

        protected override Task<string> GetScheduleCron(IServiceScope serviceScope)
        {
            return Task.FromResult("00 2 * * *");//"00 2 * * *"  9PM CST
        }
    }
}