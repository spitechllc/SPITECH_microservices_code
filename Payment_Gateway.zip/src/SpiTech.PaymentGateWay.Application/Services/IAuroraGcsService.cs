﻿using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Services
{
    public interface IAuroraGcsService
    {
        Task<bool> ProcessFiles(CancellationToken stoppingToken);
    }
}