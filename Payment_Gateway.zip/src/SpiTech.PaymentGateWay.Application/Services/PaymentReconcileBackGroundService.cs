﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.PaymentGateWay.Application.Services.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Services
{
    public class PaymentReconcileBackGroundService : BackgroundService
    {
        private readonly IServiceScope serviceScope;
        private readonly IPaymentReconcile _paymentReconcile;
        private readonly ILogger<PaymentReconcileBackGroundService> _logger;



        public PaymentReconcileBackGroundService(
                                          ILogger<PaymentReconcileBackGroundService> logger,
                                          IServiceScopeFactory scopeFactory
                                          )
        {
            _logger = logger;
            serviceScope = scopeFactory.CreateScope();
            _paymentReconcile = serviceScope.ServiceProvider.GetService<IPaymentReconcile>();
        }
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            await _paymentReconcile.GetAllTransactionForReconcile(stoppingToken);
        }
    }
}
