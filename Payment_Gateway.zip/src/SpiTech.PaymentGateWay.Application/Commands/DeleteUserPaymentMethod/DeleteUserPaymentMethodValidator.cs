﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Commands.DeleteUserPaymentMethod
{
    public class DeleteUserPaymentMethodValidator : AbstractValidator<DeleteUserPaymentMethodCommand>
    {
        public DeleteUserPaymentMethodValidator()
        {
            RuleFor(x => x.UserPaymentMethodId).GreaterThan(0)
                .WithMessage("UserPaymentMethodId is required");
        }
    }
}
