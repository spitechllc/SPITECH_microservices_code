﻿using AutoMapper;
using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.PaymentGateWay.Application.Services.Interfaces;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.DeleteUserPaymentMethod
{
    public class DeleteUserPaymentMethodHandler : IRequestHandler<DeleteUserPaymentMethodCommand, ResponseModel>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<DeleteUserPaymentMethodHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider _authenticationProvider;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly INmiService nmiService;
        public DeleteUserPaymentMethodHandler(IUnitOfWork context,
                                    ILogger<DeleteUserPaymentMethodHandler> logger,
                                    IMapper mapper,
                                    IUserAuthenticationProvider authenticationProvider,
                                    IEventDispatcher eventDispatcher,
                                    INmiService nmiService)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _authenticationProvider = authenticationProvider;
            _eventDispatcher = eventDispatcher;
            this.nmiService = nmiService;
        }
        public async Task<ResponseModel> Handle(DeleteUserPaymentMethodCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            string responseText = string.Empty;
            bool isSuccess = false;

            UserPaymentMethod paymentmethod = await _context.UserPaymentMethods.Get(command.UserPaymentMethodId);

            if (paymentmethod != null && paymentmethod.UserPaymentMethodId > 0)
            {
                if(paymentmethod.UserId>0)
                {
                    _authenticationProvider.ValidateUserAccess((int)paymentmethod.UserId);
                }
                try
                {                  
                   
                        responseText = await DeleteNMICustomerValt(paymentmethod);

                        if (string.IsNullOrEmpty(responseText))
                        {
                            paymentmethod.IsRemoved = false;
                        }
                        else
                        {
                            paymentmethod.IsRemoved = true;
                        }

                       await _context.Execute(async () =>
                        {
                            isSuccess = await _context.UserPaymentMethods.
                                 InActivePaymentMethod(command.UserPaymentMethodId, paymentmethod.IsRemoved);
                        });

                        if (paymentmethod.PaymentMethodId == 1)
                        {

                            responseText = isSuccess ? "Card Deleted" : "Unable to process. Please try later.";
                        }
                        else if (paymentmethod.PaymentMethodId == 2)
                        {
                            responseText = isSuccess ? "Account deleted" : "Unable to process. Please try later.";
                        }

                        System.Collections.Generic.List<UserPaymentMethod> userpaymentmethod = await _context.UserPaymentMethods.GetByUserId((int)paymentmethod.UserId, 0);

                    if (userpaymentmethod != null && userpaymentmethod.Count == 1)
                    {
                        userpaymentmethod.FirstOrDefault().IsDefault = true;
                        await _context.UserPaymentMethods.Update(userpaymentmethod.FirstOrDefault());
                        _context.Commit();
                    }

                    PaymentMethodRemovedEvent paymentevent = new()
                    {
                        UserPaymentMethodId = paymentmethod.UserPaymentMethodId,
                        PaymentMethodId = paymentmethod.PaymentMethodId,
                        UserId = paymentmethod.UserId ?? 0,
                        CardExpDate = paymentmethod.CardExpDate,
                        CardNumber = paymentmethod.CardNumber,
                        CardType = paymentmethod.CardType,
                        AccountNumber = paymentmethod.AccountNumber,
                        AccountType = paymentmethod.AccountType,
                        BankName = paymentmethod.BankName,
                        CustId = paymentmethod.CustId,
                        Operation = paymentmethod.Operation,
                        Source = paymentmethod.Source,
                        Token = paymentmethod.Token,
                        IsDefault = paymentmethod.IsDefault
                    };

                    await _eventDispatcher.Dispatch(paymentevent);
                    await DispatchActivityLogEvent((int)paymentmethod.UserId, (int)ActivityType.DeletePaymentMethod, "User Payment Method Removed.");
                    return new ResponseModel { Success = true, Message = responseText };
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                    return new ResponseModel { Success = false, Message = "Unable to process. Please try later." };
                }
            }
            else
            {
                return new ResponseModel { Success = false, Message = "Incorrect payment method Id" };
            }
        }
        private async Task<string> DeleteNMICustomerValt(UserPaymentMethod userPaymentMethod)
        {
            string responseText = string.Empty;
            try
            {
                string query = $"customer_vault=delete_customer&customer_vault_id={userPaymentMethod.TransactionToken}";

                HttpResponseMessage Res = await nmiService.SendRequest(HttpMethod.Post, "",
                    null, null, query);

                if (Res.IsSuccessStatusCode)
                {
                    string strres = await Res.Content.ReadAsStringAsync();
                    System.Collections.Specialized.NameValueCollection Response = strres.ParseQueryString();

                    if (Response["response"] == "1")
                    {
                        
                        responseText = "Card Deleted";

                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }

            return responseText;
        }

        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress()
            });
        }
    }
}
