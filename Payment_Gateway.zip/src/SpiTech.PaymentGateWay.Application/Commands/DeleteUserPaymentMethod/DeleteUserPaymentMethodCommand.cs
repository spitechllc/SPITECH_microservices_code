﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Commands.DeleteUserPaymentMethod
{
    public class DeleteUserPaymentMethodCommand : IRequest<ResponseModel>
    {
        public int UserPaymentMethodId { get; set; }
    }
}
