﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Configs;
using System;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.SaveSaleAgentConfig
{
    public class SaveSaleAgentConfigHandler : IRequestHandler<SaveSaleAgentConfigCommand, ResponseModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<SaveSaleAgentConfigHandler> logger;
        private readonly IMapper mapper;
        private readonly EncryptionDecryptionKey encryptionDecryptionKey;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IEventDispatcher _eventDispatcher;
        public SaveSaleAgentConfigHandler(IUnitOfWork context,
                                    ILogger<SaveSaleAgentConfigHandler> logger,
                                    IMapper mapper,
                                    EncryptionDecryptionKey encryptionDecryptionKey, IUserAuthenticationProvider userAuthenticationProvider, IEventDispatcher eventDispatcher)
        {
            this.context = context;
            this.logger = logger;
            this.mapper = mapper;
            this.encryptionDecryptionKey = encryptionDecryptionKey;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _eventDispatcher = eventDispatcher;
        }

        public async Task<ResponseModel> Handle(SaveSaleAgentConfigCommand command, CancellationToken cancellationToken)
        {
            ResponseModel responseModel = new() { };
            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);


                Domain.Entities.SaleAgentConfig saleAgentConfig = await context.SaleAgentConfigs.Get(command.SaleAgentId);

                if (saleAgentConfig == null)
                {
                    await context.Execute(async () =>
                    {
                        var saleAgentConfig = new Domain.Entities.SaleAgentConfig
                        {
                            SaleAgentId = command.SaleAgentId,
                            Bank = command.Bank,
                            AccountName = command.AccountName,
                            IsChecking = command.IsChecking,
                            IsActive = command.IsActive,
                            RoutingNo = command.RoutingNo.Trim()
                        };

                        var accountNo = command.AccountNo.Trim();
                        if (Regex.IsMatch(accountNo, @"^\d+$"))
                        {
                            saleAgentConfig.AccountNo = EncryptionDecryptionHelper.Encrypt(accountNo, encryptionDecryptionKey.EncryptDecryptKey);
                        }
                        else
                        {
                            throw new ValidationException(new FluentValidation.Results.ValidationFailure("AccountNo", "Invalid AccountNo"));
                        }

                        await context.SaleAgentConfigs.Add(saleAgentConfig);
                    });
                }
                else
                {
                    await context.Execute(async () =>
                    {
                        saleAgentConfig.Bank = command.Bank;
                        saleAgentConfig.AccountName = command.AccountName;
                        saleAgentConfig.IsChecking = command.IsChecking;
                        saleAgentConfig.IsActive = command.IsActive;
                        saleAgentConfig.RoutingNo = command.RoutingNo.Trim();

                        var accountNo = command.AccountNo.Trim();
                        if (Regex.IsMatch(accountNo, @"^\d+$"))
                        {
                            saleAgentConfig.AccountNo = EncryptionDecryptionHelper.Encrypt(accountNo, encryptionDecryptionKey.EncryptDecryptKey);
                        }

                        await context.SaleAgentConfigs.Update(saleAgentConfig);
                    });
                }
                responseModel.Success = true;
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.AddSaleAgentConfig, "SaleAgent Account Details Added.");
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new ResponseModel() { Success = false, Message = ex.Message };
            }

            return responseModel;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress()
            });
        }
    }
}
