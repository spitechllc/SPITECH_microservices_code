﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.Commands.PreAuthPayment;
using SpiTech.PaymentGateWay.Application.Commands.ProcessPayment;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.Payments
{
    public class PaymentHandler : IRequestHandler<PaymentCommand, ResponseModel<PaymentResponseModel>>
    {
        private readonly ILogger<PaymentHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public PaymentHandler(ILogger<PaymentHandler> logger,
                                    IMediator mediator, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _logger = logger;
            _mediator = mediator;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<ResponseModel<PaymentResponseModel>> Handle(PaymentCommand request, CancellationToken cancellationToken)
        {
            this.userAuthenticationProvider.ValidateUserAccess(request.UserId);

            ResponseModel<PreAuthPaymentResponseModel> preauth = await _mediator.Send(new PreAuthPaymentCommand
            {
                UserId = request.UserId,
                CardAmount = request.CardAmount,
                WalletAmount = request.WalletAmount,
                PaymentType = request.PaymentType,
                UserPaymentMethodId = request.UserPaymentMethodId,
                Description = request.Description,
                StoreId = request.StoreId,
                StoreName = request.StoreName,
                ConsumerIP = request.ConsumerIP,
                IsPaymentRequired = request.IsPaymentRequired,
                TransactionId = request.TransactionId,
                SiteId = request.SiteId,
            });

            if (preauth.Success)
            {
                ResponseModel<PaymentResponseModel> finalize = await _mediator.Send(new ProcessPaymentCommand
                {
                    TransactionId = request.TransactionId,
                    UserId = request.UserId,
                    Amount = request.CardAmount + request.WalletAmount,
                    PaymentDescription = request.Description,
                    ConsumerIP = request.ConsumerIP,
                    PreAuthConfirmationNo = preauth.Data.PreAuthConfirmationNo,
                });
                return finalize.Success
                    ? new ResponseModel<PaymentResponseModel> { Success = true, Message = finalize.Message, Data = finalize.Data }
                    : new ResponseModel<PaymentResponseModel> { Success = false, Message = finalize.Message };
            }
            else
            {
                return new ResponseModel<PaymentResponseModel> { Success = false, Message = preauth.Message };
            }
        }
    }
}
