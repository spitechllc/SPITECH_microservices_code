﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Commands.Payments
{
    public class PaymentValidator : AbstractValidator<PaymentCommand>
    {
        public PaymentValidator()
        {
            RuleFor(x => x.CardAmount).GreaterThan(0).When(m => m.WalletAmount == 0).WithMessage("Either CardAmount or WalletAmount" +
                " must be greater than 0");

            RuleFor(x => x.WalletAmount).GreaterThan(0).When(m => m.CardAmount == 0).WithMessage("Either CardAmount or WalletAmount" +
            " must be greater than 0");

            RuleFor(x => x.UserPaymentMethodId).GreaterThan(0).WithMessage("UserPaymentMethodId must be greater than 0");
        }
    }
}
