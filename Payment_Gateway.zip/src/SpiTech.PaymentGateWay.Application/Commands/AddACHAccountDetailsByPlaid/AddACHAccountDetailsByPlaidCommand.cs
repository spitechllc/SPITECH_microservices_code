﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models.Plaid;

namespace SpiTech.PaymentGateWay.Application.Commands.AddACHAccountDetailsByPlaid
{
    public class AddACHAccountDetailsByPlaidCommand : IRequest<ResponseModel<PlaidAuthDetailsModel>>
    {
        public string AccessToken { get; set; }

    }
}