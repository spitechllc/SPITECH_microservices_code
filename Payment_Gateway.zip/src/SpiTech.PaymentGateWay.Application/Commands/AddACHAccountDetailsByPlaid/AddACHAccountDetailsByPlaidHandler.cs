﻿using AutoMapper;
using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.Queries.GetPaymentGatewayConfig;
using SpiTech.PaymentGateWay.Application.Services.Interfaces;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Enums;
using SpiTech.PaymentGateWay.Domain.Models.Plaid;
using System;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.AddACHAccountDetailsByPlaid
{
    public class AddACHAccountDetailsByPlaidHandler : IRequestHandler<AddACHAccountDetailsByPlaidCommand, ResponseModel<PlaidAuthDetailsModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<AddACHAccountDetailsByPlaidHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IMediator _mediator;
        private readonly IPlaidService _plaidService;
        private readonly PlaidGatewayConfigs _plaidGatewayConfigs;

        public AddACHAccountDetailsByPlaidHandler(IUnitOfWork context,
                                    ILogger<AddACHAccountDetailsByPlaidHandler> logger,
                                    IMapper mapper,
                                    IMediator mediator,
                                    IPlaidService plaidService,
                                    PlaidGatewayConfigs plaidGatewayConfigs)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _mediator = mediator;
            _plaidService = plaidService;
            _plaidGatewayConfigs = plaidGatewayConfigs;
        }
        public async Task<ResponseModel<PlaidAuthDetailsModel>> Handle(AddACHAccountDetailsByPlaidCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            ResponseModel<PlaidAuthDetailsModel> responseModel = new() { Success = false };

            Domain.Entities.PaymentGatewayConfig plaidPaymentGatewayConfig = (await _mediator.Send(new GetPaymentGatewayConfigQuery { })).Data.FirstOrDefault(t => (t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithDwolla || t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithStride || t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithNMI) && t.IsActive == true);

            PlaidGatewayConfig _plaidGatewayConfig = _plaidGatewayConfigs.FirstOrDefault(t => t.IsProd == plaidPaymentGatewayConfig.IsProdEnabled);


            PlaidAuthDetailsModel objModel = new();
            var model = new
            {
                client_id = _plaidGatewayConfig.ClientId,
                secret = _plaidGatewayConfig.ClientSecret,
                access_token = command.AccessToken
            };
            string requestvalue = "auth/get";
            string strjson = JsonConvert.SerializeObject(model);
            HttpContent content = new StringContent(strjson, Encoding.UTF8, "application/json");
            HttpResponseMessage exchageres = await _plaidService.SendRequest(HttpMethod.Post, requestvalue, content, null, null);
            try
            {
            
            if (exchageres.IsSuccessStatusCode)
            {
                string accountDetails = await exchageres.Content.ReadAsStringAsync();
                    _logger.Trace("AccountDetailsFromPlaid",accountDetails);
                    objModel = JsonConvert.DeserializeObject<PlaidAuthDetailsModel>(accountDetails);
                responseModel.Success = true;
                responseModel.Message = "Success";
                responseModel.Data = objModel;
            }
            else
            {
                string errorres = await exchageres.Content.ReadAsStringAsync();

                responseModel.Success = false;
                responseModel.Message = errorres;
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("Error", errorres));

            }
                _logger.TraceExitMethod(exchageres.ToString());
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }
            return responseModel;
        }
    }
}
