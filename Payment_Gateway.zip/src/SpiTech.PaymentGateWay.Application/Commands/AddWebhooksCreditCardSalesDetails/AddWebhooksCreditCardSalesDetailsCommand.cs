﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Commands.AddWebhooksCreditCardSalesDetails
{
    public class AddWebhooksCreditCardSalesDetailsCommand : IRequest<ResponseModel<string>>
    {
        public string webhooksCreditCardDetails { get; set; }
    }
}
