﻿using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Models;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.AddWebhooksCreditCardSalesDetails
{
    public class AddWebhooksCreditCardSalesDetailsHandler : IRequestHandler<AddWebhooksCreditCardSalesDetailsCommand, ResponseModel<string>>
    {
        private readonly IMediator _mediator;
        private readonly IUnitOfWork _context;
        private readonly ILogger<AddWebhooksCreditCardSalesDetailsHandler> _logger;

        public AddWebhooksCreditCardSalesDetailsHandler(IMediator mediator, IUnitOfWork context, ILogger<AddWebhooksCreditCardSalesDetailsHandler> logger)
        {
            _context = context;
            _mediator = mediator;
            _logger = logger;
        }
        public async Task<ResponseModel<string>> Handle(AddWebhooksCreditCardSalesDetailsCommand request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            ResponseModel<string> responseModel = new() { Success = false };
            int webhooksCreditCardDetailsId = 0;

            if (!string.IsNullOrEmpty(request.webhooksCreditCardDetails))
            {
                try
                {
                    WebhooksCreditCardDetailsModel.Rootobject webhooksCreditCardDetails = JsonConvert.DeserializeObject<WebhooksCreditCardDetailsModel.Rootobject>(request.webhooksCreditCardDetails);
                    if (webhooksCreditCardDetails.event_type == "transaction.sale.success")
                    {
                        await _context.Execute(async () =>
                                {
                                    webhooksCreditCardDetailsId = await _context.WebhooksCreditCardDetails.Add(new Domain.Entities.WebhooksCreditCardDetails
                                    {
                                        EventId = webhooksCreditCardDetails.event_id,
                                        MerchantId = Convert.ToInt32(webhooksCreditCardDetails.event_body.merchant.id),
                                        MerchantName = webhooksCreditCardDetails.event_body.merchant.name,
                                        TransactionId = Convert.ToInt32(webhooksCreditCardDetails.event_body.transaction_id),
                                        TransactionType = webhooksCreditCardDetails.event_body.transaction_type,
                                        Condition = webhooksCreditCardDetails.event_body.condition,
                                        ProccessorId = webhooksCreditCardDetails.event_body.processor_id,
                                        PONumber = Convert.ToInt32(webhooksCreditCardDetails.event_body.ponumber),
                                        OrderDescription = webhooksCreditCardDetails.event_body.order_description,
                                        OrderId = Convert.ToInt32(webhooksCreditCardDetails.event_body.order_id),
                                        customerid = Convert.ToInt32(webhooksCreditCardDetails.event_body.customerid),
                                        customertaxid = Convert.ToInt32(webhooksCreditCardDetails.event_body.customertaxid),
                                        Website = webhooksCreditCardDetails.event_body.website,
                                        Shipping = webhooksCreditCardDetails.event_body.shipping,
                                        Currency = webhooksCreditCardDetails.event_body.currency,
                                        Tax = Convert.ToDecimal(webhooksCreditCardDetails.event_body.tax),
                                        Surcharge = Convert.ToDecimal(webhooksCreditCardDetails.event_body.surcharge),
                                        CashDiscount = Convert.ToDecimal(webhooksCreditCardDetails.event_body.cash_discount),
                                        RequestedAmount = Convert.ToDecimal(webhooksCreditCardDetails.event_body.requested_amount),
                                        AuthorizationCode = webhooksCreditCardDetails.event_body.authorization_code,
                                        SocialSecurityNumber = webhooksCreditCardDetails.event_body.social_security_number,
                                        CCNumber = webhooksCreditCardDetails.event_body.card.cc_number,
                                        CCExp = webhooksCreditCardDetails.event_body.card.cc_exp,
                                        CCType = webhooksCreditCardDetails.event_body.card.cc_type,
                                        Amount = Convert.ToDecimal(webhooksCreditCardDetails.event_body.action.amount),
                                        ActionType = webhooksCreditCardDetails.event_body.action.action_type,
                                        Date = Convert.ToDateTime(webhooksCreditCardDetails.event_body.action.date),
                                        Success = Convert.ToBoolean(webhooksCreditCardDetails.event_body.action?.success),
                                        Ipaddress = webhooksCreditCardDetails.event_body.action.ip_address,
                                        Source = webhooksCreditCardDetails.event_body.action.source,
                                        ApiMethod = webhooksCreditCardDetails.event_body.action.api_method,
                                        UserName = webhooksCreditCardDetails.event_body.action.username,
                                        ResponseText = webhooksCreditCardDetails.event_body.action.response_text,
                                        ResponseCode = webhooksCreditCardDetails.event_body.action.response_code,
                                        ProcessorResponseText = webhooksCreditCardDetails.event_body.action.processor_response_text,
                                        ProcessorResponseCode = webhooksCreditCardDetails.event_body.action.processor_response_code,
                                        DeviceLicenseNumber = webhooksCreditCardDetails.event_body.action.device_license_number,
                                        DeviceNickname = webhooksCreditCardDetails.event_body.action.device_nickname,
                                    });
                                });

                        if (webhooksCreditCardDetailsId > 0)
                        {
                            responseModel.Success = true;
                            responseModel.Data = webhooksCreditCardDetailsId.ToString();
                        }
                    }
                    else
                    {
                        responseModel.Success = false;
                        responseModel.Data = webhooksCreditCardDetails.event_type;
                        _logger.Warn(webhooksCreditCardDetails.event_type);
                    }

                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }

            }
            _logger.TraceExitMethod(nameof(Handle), responseModel);

            return responseModel;
        }
    }
}
