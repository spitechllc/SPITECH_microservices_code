﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Commands.SaveResellerConfig
{
    public class SaveResellerConfigValidator : AbstractValidator<SaveResellerConfigCommand>
    {
        public SaveResellerConfigValidator()
        {
            RuleFor(x => x.ResellerId).GreaterThan(0);
            //RuleFor(x => x.Bank).NotNull().NotEmpty().MaximumLength(23);
            RuleFor(x => x.AccountNo).NotNull().NotEmpty().MinimumLength(5).MaximumLength(17);
            RuleFor(x => x.RoutingNo).NotNull().NotEmpty().MinimumLength(5).MaximumLength(9);
        }
    }
}
