﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Commands.SaveResellerConfig
{
    public class SaveResellerConfigCommand : IRequest<ResponseModel>
    {
        public int ResellerId { get; set; }
        public string AccountName { get; set; }
        public string Bank { get; set; }
        public string AccountNo { get; set; }
        public string RoutingNo { get; set; }
        public bool IsChecking { get; set; }
        public bool IsActive { get; set; }
    }
}
