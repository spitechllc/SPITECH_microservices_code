﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Configs;
using System;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.SaveResellerConfig
{
    public class SaveResellerConfigHandler : IRequestHandler<SaveResellerConfigCommand, ResponseModel>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<SaveResellerConfigHandler> logger;
        private readonly IMapper mapper;
        private readonly EncryptionDecryptionKey encryptionDecryptionKey;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IEventDispatcher _eventDispatcher;
        public SaveResellerConfigHandler(IUnitOfWork context,
                                    ILogger<SaveResellerConfigHandler> logger,
                                    IMapper mapper,
                                    EncryptionDecryptionKey encryptionDecryptionKey, IUserAuthenticationProvider userAuthenticationProvider, IEventDispatcher eventDispatcher)
        {
            this.context = context;
            this.logger = logger;
            this.mapper = mapper;
            this.encryptionDecryptionKey = encryptionDecryptionKey;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _eventDispatcher = eventDispatcher;
        }

        public async Task<ResponseModel> Handle(SaveResellerConfigCommand command, CancellationToken cancellationToken)
        {
            ResponseModel responseModel = new() { };
            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);

                Domain.Entities.ResellerConfig resellerConfig = await context.ResellerConfigs.Get(command.ResellerId);

                if (resellerConfig == null)
                {
                    await context.Execute(async () =>
                    {
                        var resellerConfig = new Domain.Entities.ResellerConfig
                        {
                            ResellerId = command.ResellerId,
                            Bank = command.Bank,
                            AccountName = command.AccountName,
                            IsChecking = command.IsChecking,
                            IsActive = command.IsActive,
                            RoutingNo = command.RoutingNo.Trim()
                        };

                        var accountNo = command.AccountNo.Trim();
                        if (Regex.IsMatch(accountNo, @"^\d+$"))
                        {
                            resellerConfig.AccountNo = EncryptionDecryptionHelper.Encrypt(accountNo, encryptionDecryptionKey.EncryptDecryptKey);
                        }
                        else
                        {
                            throw new ValidationException(new FluentValidation.Results.ValidationFailure("AccountNo", "Invalid AccountNo"));
                        }

                        await context.ResellerConfigs.Add(resellerConfig);
                    });
                }
                else
                {
                    await context.Execute(async () =>
                    {
                        resellerConfig.Bank = command.Bank;
                        resellerConfig.AccountName = command.AccountName;
                        resellerConfig.IsChecking = command.IsChecking;
                        resellerConfig.IsActive = command.IsActive;
                        resellerConfig.RoutingNo = command.RoutingNo.Trim();

                        var accountNo = command.AccountNo.Trim();
                        if (Regex.IsMatch(accountNo, @"^\d+$"))
                        {
                            resellerConfig.AccountNo = EncryptionDecryptionHelper.Encrypt(accountNo, encryptionDecryptionKey.EncryptDecryptKey);
                        }

                        await context.ResellerConfigs.Update(resellerConfig);
                    });
                }
                responseModel.Success = true;
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.AddResellerConfig, "Reseller Account Details Added.");
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new ResponseModel() { Success = false, Message = ex.Message };
            }

            return responseModel;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress()
            });
        }
    }
}
