﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Commands.UnMarkFraudAccount
{
    public class UnMarkFraudAccountCommand : IRequest<ResponseModel>
    {
        public int UserPaymentMethodID { get; set; }
    }
}
