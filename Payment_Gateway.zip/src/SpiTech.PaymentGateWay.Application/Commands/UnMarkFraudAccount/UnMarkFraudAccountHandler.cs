﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.UnMarkFraudAccount
{
    public class UnMarkFraudAccountHandler : IRequestHandler<UnMarkFraudAccountCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UnMarkFraudAccountHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IEventDispatcher _eventDispatcher;

        public UnMarkFraudAccountHandler(IUnitOfWork context,
                                ILogger<UnMarkFraudAccountHandler> logger,
                                IMapper mapper, IUserAuthenticationProvider userAuthenticationProvider, IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _eventDispatcher = eventDispatcher;
        }
        public async Task<ResponseModel> Handle(UnMarkFraudAccountCommand command, CancellationToken cancellationToken)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Handle), command);
                bool success = false;
                string message = "Fail";

                List<UserPaymentMethod> result = await _context.UserPaymentMethods.GetAllFraudAccount(command.UserPaymentMethodID);
                this.userAuthenticationProvider.ValidateUserAccess((int)result.FirstOrDefault().UserId);
                if (result != null && result.FirstOrDefault().IsFraud==true)
                {
                    result.FirstOrDefault().IsFraud = false;
                    await _context.Execute(async () =>
                    {
                        success = await _context.UserPaymentMethods.Update(result.FirstOrDefault());
                    });
                                      
                }

                _logger.TraceExitMethod(nameof(Handle), success);

                return new ResponseModel() { Success = success, Message = message };
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return new ResponseModel() { Success = false, Message = ex.Message };
            }
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress()
            });
        }
    }
}
