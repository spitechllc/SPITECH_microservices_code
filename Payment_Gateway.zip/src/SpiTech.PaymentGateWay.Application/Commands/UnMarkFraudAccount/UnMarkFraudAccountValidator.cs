﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Commands.UnMarkFraudAccount
{
    public class UnMarkFraudAccountValidator : AbstractValidator<UnMarkFraudAccountCommand>
    {
        public UnMarkFraudAccountValidator()
        {
            RuleFor(x => x.UserPaymentMethodID).GreaterThan(0).WithMessage("UserPaymentMethodID Required");
        }
    }
}
