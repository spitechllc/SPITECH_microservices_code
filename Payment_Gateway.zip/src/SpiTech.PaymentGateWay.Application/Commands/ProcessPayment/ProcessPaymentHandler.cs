﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.PaymentGateWay.Application.Commands.ProcessPaymentNMIACH;
using SpiTech.PaymentGateWay.Application.Commands.ProcessPaymentNMICapture;
using SpiTech.PaymentGateWay.Application.Commands.ProcessPaymentNMIVoid;
using SpiTech.PaymentGateWay.Application.Queries.GetPaymentGatewayConfig;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Enums;
using SpiTech.PaymentGateWay.Domain.Models;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.ProcessPayment
{
    public class ProcessPaymentHandler : IRequestHandler<ProcessPaymentCommand, ResponseModel<PaymentResponseModel>>
    {
        private readonly ILogger<ProcessPaymentHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IUnitOfWork _context;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IFinanceServiceClient financeApiClient;
        private readonly IMapper mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public ProcessPaymentHandler(ILogger<ProcessPaymentHandler> logger,
                                    IMediator mediator,
                                    IUnitOfWork context,
                                    IEventDispatcher eventDispatcher,
                                    IFinanceServiceClient financeApiClient,
                                    IMapper mapper, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _logger = logger;
            _mediator = mediator;
            _context = context;
            this.eventDispatcher = eventDispatcher;
            this.financeApiClient = financeApiClient;
            this.mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<ResponseModel<PaymentResponseModel>> Handle(ProcessPaymentCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            this.userAuthenticationProvider.ValidateUserAccess(command.UserId);
            TransactionResponseModel walletResponse = null;
            TransactionResponseModel cardResponse = new();
            PreAuthPaymentModel preAuthPayment = new();
            decimal finalCardAmount = 0;
            decimal finalWalletAmount = 0;

            ResponseModel<PaymentResponseModel> responseModel = new() { Success = false, Message = "Payment fail" };

            preAuthPayment = await _context.PreAuthPayments.GetByConfirmationNumber(command.PreAuthConfirmationNo);

            if (preAuthPayment == null || !preAuthPayment.Success)
            {
                responseModel.Message = "PreAuthConfirmationNo is Invalid";
                return responseModel;
            }

            if (command.Amount > preAuthPayment.Amount)
            {
                responseModel.Message = "Amount should not be greater than PreAuthPayment amount";
                return responseModel;
            }
           
                Payment payment = await _context.Payments.GetByPreAuthPaymentId(preAuthPayment.PreAuthPaymentId);

            if (payment != null)
            {
                responseModel.Message = "PreAuthConfirmationNo is Invalid";
                return responseModel;
            }

            if (command.Amount <= 0)
            {
                walletResponse = await VoidWalletTransaction(preAuthPayment.WalletPreAuthConfirmationNo);
                cardResponse = await VoidCardTransaction(preAuthPayment);
            }
            else
            {
                if (preAuthPayment.PaymentMethodId == (int)EnumPaymentMethod.ACH)
                {
                    StoreConfig result = await _context.StoreConfigs.Get(preAuthPayment.StoreId);
                    if(result.IsAchEnabled==false || result.IsAchEnabled==null)
                    {
                        responseModel.Message = "ACH payment is not enabled";
                        return responseModel;
                    }
                }
               
                finalWalletAmount = preAuthPayment.WalletAmount > 0
                    ? preAuthPayment.WalletAmount > command.Amount ? command.Amount : preAuthPayment.WalletAmount
                    : 0;

                finalCardAmount = command.Amount > finalWalletAmount ? command.Amount - finalWalletAmount : 0;

                walletResponse = await ProcessWalletPayment(preAuthPayment, command, finalWalletAmount);

                cardResponse = await ProcessCardPayment(preAuthPayment, command, finalCardAmount);
            }
            
            payment = await SavePayment(preAuthPayment, command, finalCardAmount, finalWalletAmount, walletResponse, cardResponse, payment);

            if (payment != null)
            {
                responseModel.Data = mapper.Map<PaymentResponseModel>(payment);
                responseModel.Data.PaymentMethodId = preAuthPayment.PaymentMethodId;
                responseModel.Data.PreAuthConfirmationNo = preAuthPayment.PreAuthConfirmationNo;
                responseModel.Success = payment.Success;
                responseModel.Message = payment.Success ? "" : "Payment Fail";

                await eventDispatcher.Dispatch(
                  new PaymentStatusEvent
                  {
                      Amount = payment.Amount,
                      CardAmount = payment.CardAmount,
                      WalletAmount = payment.WalletAmount,
                      TransactionId = payment.TransactionId ?? 0,
                      UserId = payment.UserId,
                      PreauthConfirmationNo = command.PreAuthConfirmationNo,
                      ProcessDate = DateTime.UtcNow,
                      IsSuccess = responseModel.Success,
                      ErrorMessage = responseModel.Message,
                      StoreName = preAuthPayment.StoreName
                  });
                await DispatchActivityLogEvent(command.UserId, (int)ActivityType.ProcessPayment, "User Payment Processed.");
                if (!payment.Success)
                {
                    await eventDispatcher.Dispatch(new PaymentFailedEvent
                    {
                        Amount = payment.Amount,
                        CardAmount = payment.CardAmount,
                        WalletAmount = payment.WalletAmount,
                        TransactionId = payment.TransactionId ?? 0,
                        UserId = payment.UserId,
                        IsSuccess = responseModel.Success,
                        IsPaymentRequired = preAuthPayment.IsPaymentRequired,
                        StoreName = preAuthPayment.StoreName,
                        StoreId = preAuthPayment.StoreId ?? 0
                    });

                    if (preAuthPayment.IsPaymentRequired)
                    {
                        await eventDispatcher.Dispatch(new PaymentFailureSupportTeamEvent
                        {
                            Amount = payment.Amount,
                            CardAmount = payment.CardAmount,
                            WalletAmount = payment.WalletAmount,
                            TransactionId = payment.TransactionId ?? 0,
                            UserId = payment.UserId,
                            IsSuccess = responseModel.Success,
                            IsPaymentRequired = preAuthPayment.IsPaymentRequired,
                            StoreName = preAuthPayment.StoreName,
                            StoreId = preAuthPayment.StoreId ?? 0
                        });
                    }
                }
            }

            return responseModel;
        }

        private async Task<TransactionResponseModel> ProcessWalletPayment(PreAuthPaymentModel preauthpayment, ProcessPaymentCommand command, decimal finalWalletAmount)
        {
            TransactionResponseModel walletResponse = null;
            try
            {
                if (finalWalletAmount > 0 && !string.IsNullOrEmpty(preauthpayment.WalletPreAuthConfirmationNo))
                {
                    Service.Clients.Finance.ResponseModel processWalletPaymentResponse = await financeApiClient.ProcessPaymentAsync(new Service.Clients.Finance.WalletProcessPaymentCommand
                    {
                        Amount = (double)finalWalletAmount,
                        AuthNumber = preauthpayment.WalletPreAuthConfirmationNo,
                        TransactionId = command.TransactionId ?? 0
                    });
                    walletResponse = new TransactionResponseModel
                    {
                        Status = EnumPaymentStatus.Success,
                        Response = processWalletPaymentResponse.Message
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                walletResponse = new TransactionResponseModel { Response = "Unable to process wallet payment", Status = EnumPaymentStatus.Fail };
            }

            return walletResponse;
        }

        private async Task<TransactionResponseModel> ProcessCardPayment(PreAuthPaymentModel preauthPayment,
                                                                        ProcessPaymentCommand command,
                                                                        decimal finalCardAmount)
        {
            TransactionResponseModel response = null;

            try
            {
                if (finalCardAmount > 0)
                {
                    response = new TransactionResponseModel { Response = "", Status = EnumPaymentStatus.Success };

                    if (preauthPayment.PaymentMethodId == (int)EnumPaymentMethod.CreditCard)
                    {
                        ResponseModel cardResponse = await _mediator.Send(new ProcessPaymentNMICommand
                        {
                            Amount = finalCardAmount,
                            PreAuthconfirmationNo = preauthPayment.CardPreAuthConfirmationNo
                        });

                        response.AuthConfirmationNo = GetConfirmationNumber(cardResponse);
                        response.Status = EnumPaymentStatus.Success;
                        response.Response = cardResponse.Message;
                    }
                    else if (preauthPayment.PaymentMethodId == (int)EnumPaymentMethod.ACH)
                    {
                        StoreConfig result = await _context.StoreConfigs.Get(preauthPayment.StoreId);
                        if (result.IsAchEnabled == false || result.IsAchEnabled == null)
                        {
                            response.Response = "ACH payment is not enabled";
                            response.Status = EnumPaymentStatus.Fail;
                            return response;
                        }

                        PaymentGatewayConfig achPaymentGatewayConfig = (await _mediator.Send(new GetPaymentGatewayConfigQuery { })).Data.FirstOrDefault(t => t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithNMI && t.IsActive == true);

                        if (achPaymentGatewayConfig != null && achPaymentGatewayConfig.PaymentGatewayConfigId > 0)
                        {
                            
                            response.Status = EnumPaymentStatus.Initiated;
                            response.Response = "Payment Successful";
                        }


                    }
                    else
                    {
                        response = new TransactionResponseModel { Status = EnumPaymentStatus.Fail, Response = "Invalid PaymentMethodId" };
                    }
                }
                else
                {
                    if (preauthPayment.PaymentMethodId == (int)EnumPaymentMethod.CreditCard
                        && preauthPayment.CardAmount != 0
                        && !string.IsNullOrEmpty(preauthPayment.CardPreAuthConfirmationNo))
                    {
                        return await VoidCardTransaction(preauthPayment);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                response = new TransactionResponseModel { Response = "Unable to process Card payment", Status = EnumPaymentStatus.Fail };
            }

            return response;
        }

        private string GetConfirmationNumber(ResponseModel cardResponse)
        {
            string cardConfirmationNumber = "";
            try
            {
                if (cardResponse != null && !string.IsNullOrEmpty(cardResponse.Message))
                {
                    System.Collections.Specialized.NameValueCollection cardResponseQuery = cardResponse.Message.ParseQueryString();
                    cardConfirmationNumber = cardResponseQuery["transactionid"].ToString();
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }

            return cardConfirmationNumber;
        }

        private async Task<TransactionResponseModel> VoidWalletTransaction(string walletPreAuthConfirmationNo)
        {
            try
            {
                TransactionResponseModel response = null;

                if (!string.IsNullOrEmpty(walletPreAuthConfirmationNo))
                {
                    Service.Clients.Finance.ResponseModel voidWalletPaymentResponse = await financeApiClient.VoidPaymentAsync(new Service.Clients.Finance.WalletVoidPaymentModel
                    {
                        AuthNumber = walletPreAuthConfirmationNo
                    });

                    response = new TransactionResponseModel
                    {
                        Response = voidWalletPaymentResponse.Message,
                        Status = EnumPaymentStatus.Void
                    };
                }

                return response;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return new TransactionResponseModel { Response = "Unable to void payment", Status = EnumPaymentStatus.Fail };
            }
        }

        private async Task<TransactionResponseModel> VoidCardTransaction(PreAuthPaymentModel preauthpayment)
        {
            try
            {
                TransactionResponseModel response = null;

                if (preauthpayment.PaymentMethodId == (int)EnumPaymentMethod.CreditCard && !string.IsNullOrEmpty(preauthpayment.CardPreAuthConfirmationNo))
                {
                    ResponseModel voidCardPaymentResponse = await _mediator.Send(new ProcessPaymentNMIVoidCommand
                    {
                        PreAuthconfirmationNo = preauthpayment.CardPreAuthConfirmationNo
                    });

                    response = new TransactionResponseModel
                    {
                        AuthConfirmationNo = GetConfirmationNumber(voidCardPaymentResponse),
                        Response = voidCardPaymentResponse.Message,
                        Status = EnumPaymentStatus.Void
                    };
                }

                return response;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return new TransactionResponseModel { Response = "Unable to void Card Payment", Status = EnumPaymentStatus.Fail };
            }
        }

        private async Task<Payment> SavePayment(PreAuthPaymentModel preauthPayment,
            ProcessPaymentCommand command,
            decimal cardAmount,
            decimal walletAmount,
            TransactionResponseModel walletResponse,
            TransactionResponseModel cardResponse,
            Payment payment)
        {
            if (payment == null)
            {
                payment = new Payment()
                {
                    PreAuthPaymentId = preauthPayment.PreAuthPaymentId,
                    UserId = command.UserId,
                    TransactionId = command.TransactionId,
                    Description = command.PaymentDescription,
                    Amount = command.Amount,
                    WalletAmount = walletAmount,
                    CardAmount = cardAmount,
                    CardResponse = cardResponse?.Response,
                    WalletResponse = walletResponse?.Response,
                    Success = (cardResponse == null || cardResponse.Status != EnumPaymentStatus.Fail) && (walletResponse == null || walletResponse?.Status != EnumPaymentStatus.Fail),
                    WalletPaymentStatusId = (int?)walletResponse?.Status,
                    CardPaymentStatusId = (int?)cardResponse?.Status,
                    CardConfirmationNumber = cardResponse?.AuthConfirmationNo,
                    CardPayRetryCount = 1,
                    CardPayLastRetry = DateTime.UtcNow,
                    IsActive = true
                };
            }

            try
            {
                payment.PaymentId = await _context.Payments.Add(payment);
                _context.Commit();
            }
            catch (Exception ex)
            {
                _context.Rollback();
                _logger.Error(ex);
                throw;
            }

            return payment;
        }

        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ""//ApplicationCore.Helpers.IPAddressHelper.GetIPAddress()
            });
        }
    }
}
