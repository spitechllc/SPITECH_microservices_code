﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Commands.ProcessPayment
{
    public class ProcessPaymentCommand : IRequest<ResponseModel<PaymentResponseModel>>
    {
        public long? TransactionId { get; set; }
        public int UserId { get; set; }
        public decimal Amount { get; set; }
        public string PaymentDescription { get; set; }
        public string PreAuthConfirmationNo { get; set; }
        public string ConsumerIP { get; set; }
    }
}
