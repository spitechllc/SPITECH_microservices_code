﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Commands.ProcessPayment
{
    public class ProcessPaymentValidator : AbstractValidator<ProcessPaymentCommand>
    {
        public ProcessPaymentValidator()
        {
            RuleFor(x => x.UserId).GreaterThan(0).WithMessage("UserId must be greater than 0");
            RuleFor(x => x.PreAuthConfirmationNo).NotNull().NotEmpty().WithMessage("PreAuthConfirmationNo is required");
        }
    }
}
