﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Commands.AddNickName
{
    public class AddNickNameCommand : IRequest<ResponseModel<UserPaymentMethodModel>>
    {
        public int UserPaymentMethodID { get; set; }
        public string NickName { get; set; }
    }
}
