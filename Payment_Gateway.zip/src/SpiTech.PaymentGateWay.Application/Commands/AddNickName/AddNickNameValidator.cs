﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Commands.AddNickName
{
    public class AddNickNameValidator : AbstractValidator<AddNickNameCommand>
    {
        public AddNickNameValidator()
        {
            RuleFor(x => x.NickName).NotEmpty().NotNull().WithMessage("Nick Name Required");
            RuleFor(x => x.NickName).MaximumLength(100);
            RuleFor(x => x.UserPaymentMethodID).GreaterThan(0).WithMessage("UserPaymentMethodID Required");
        }
    }
}
