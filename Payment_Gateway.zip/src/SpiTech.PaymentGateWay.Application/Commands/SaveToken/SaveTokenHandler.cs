﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.PaymentGateWay.Application.Queries.GetPaymentGatewayConfig;
using SpiTech.PaymentGateWay.Application.Services.Interfaces;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain;
using SpiTech.PaymentGateWay.Domain.Enums;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.SaveToken
{
    public class SaveTokenHandler : IRequestHandler<SaveTokenCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<SaveTokenHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IMediator _mediator;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly INmiService nmiService;
        public SaveTokenHandler(IUnitOfWork context,
                                    ILogger<SaveTokenHandler> logger,
                                    IMapper mapper,
                                    IEventDispatcher eventDispatcher,
                                    INmiService nmiService,
                                    IMediator mediator, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
            this.nmiService = nmiService;
            _mediator = mediator;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<ResponseModel> Handle(SaveTokenCommand command, CancellationToken cancellationToken)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Handle), command);
                DateTime? CardExpDate = null;
                this.userAuthenticationProvider.ValidateUserAccess(command.UserId);
                if (!string.IsNullOrEmpty(command.CardExpDate))
                {
                    CardExpDate = DateTime.ParseExact(command.CardExpDate, "MMyy", CultureInfo.InvariantCulture);
                }

                bool setIsDefault = true;
                System.Collections.Generic.List<Domain.Entities.UserPaymentMethod> paymentmethods = await _context.UserPaymentMethods.GetByUserId(command.UserId, 0);

                if (paymentmethods != null && paymentmethods.Count > 0)
                {
                    setIsDefault = false;
                }

                ResponseModel<string> transactiontoken = await CreateNMICustomerValt(command);

                if (transactiontoken.Success)
                {
                    int UserPaymentMethodId = 0;

                    await _context.Execute(async () =>
                    {
                        UserPaymentMethodId = await _context.UserPaymentMethods.Add(new Domain.Entities.UserPaymentMethod
                        {
                            PaymentMethodId = command.PaymentMethodId,
                            UserId = command.UserId,
                            CardName = command.CardName,
                            CardExpDate = CardExpDate,
                            CardNumber = command.CardNumber,
                            CardType = command.CardType,
                            AccountNumber = command.AccountNumber,
                            AccountType = command.AccountType,
                            CustId = command.CustId,
                            Operation = command.Operation,
                            Source = command.Source,
                            Token = command.Token,
                            IsDefault = setIsDefault,
                            CreatedBy = command.UserId,
                            CreatedOn = DateTime.Now,
                            PaymentGatewayConfigId = command.PaymentGatewayId,
                            TransactionToken = transactiontoken.Message
                        });
                    });

                    PaymentMethodAddedEvent paymentevent = new()
                    {
                        UserPaymentMethodId = UserPaymentMethodId,
                        UserPaymentMethodCount = await _context.UserPaymentMethods.GetPaymentMethodCount(command.UserId),
                        PaymentMethodId = command.PaymentMethodId,
                        UserId = command.UserId,
                        CardExpDate = CardExpDate,
                        CardNumber = command.CardNumber,
                        CardType = command.CardType,
                        AccountNumber = command.AccountNumber,
                        AccountType = command.AccountType,
                        CustId = command.CustId,
                        Operation = command.Operation,
                        Source = command.Source,
                        Token = command.Token,
                        IsDefault = setIsDefault
                    };
                    await _eventDispatcher.Dispatch(paymentevent);
                    await DispatchActivityLogEvent(command.UserId, (int)ActivityType.AddPaymentMethod, "User Credit Card Added.");
                    _logger.TraceExitMethod(nameof(Handle), UserPaymentMethodId);

                    return new ResponseModel() { Success = true, Message = "Success" };
                }
                else
                {
                    _logger.Warn(nameof(Handle), transactiontoken);
                    return new ResponseModel() { Success = false, Message = transactiontoken.Message };
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return new ResponseModel() { Success = false, Message = ex.Message };
            }
        }

        private async Task<ResponseModel<string>> CreateNMICustomerValt(SaveTokenCommand command)
        {
            _logger.TraceEnterMethod(nameof(CreateNMICustomerValt), command);
            ResponseModel<string> resModel = new() { Success = false };
            string customer_vault_id = string.Empty;
            string query = string.Empty;
            Domain.Entities.PaymentGatewayConfig nmiPaymentGatewayConfig = (await _mediator.Send(new GetPaymentGatewayConfigQuery { })).Data.FirstOrDefault(t => t.PaymentGatewayConfigId == (int)EnumPaymentGateway.NMI);
            query = nmiPaymentGatewayConfig.IsProdEnabled
                ? $"type=validate&customer_vault=add_customer&payment_token={command.Token}&billing_id=123456"
                : $"customer_vault=add_customer&payment_token={command.Token}";


            HttpResponseMessage Res = await nmiService.SendRequest(HttpMethod.Post, "",
                null, null, query);

            if (Res.IsSuccessStatusCode)
            {
                string strres = await Res.Content.ReadAsStringAsync();
                System.Collections.Specialized.NameValueCollection Response = strres.ParseQueryString();

                if (Response["response"] == "1")
                {
                    if (Response["cvvresponse"] != "N" && Response["cvvresponse"] != "P" && Response["cvvresponse"] != "S" && Response["cvvresponse"] != "U")
                    {
                        resModel.Success = true;
                        resModel.Message = Response["customer_vault_id"];
                    }
                    else if (Response["cvvresponse"] == "P")
                    {
                        resModel.Success = false;
                        resModel.Message = "CVV Not Processed Or CVV Was Not Provided.";
                    }
                    else if (Response["cvvresponse"] == "N")
                    {
                        resModel.Success = false;
                        resModel.Message = "CVV Does Not Match.";
                    }
                    else if (Response["cvvresponse"] == "S")
                    {
                        resModel.Success = false;
                        resModel.Message = "CVV Not Processed";
                    }
                    else if (Response["cvvresponse"] == "U")
                    {
                        resModel.Success = false;
                        resModel.Message = "CVV Issuer Is Not Certified.";
                    }
                    else
                    {
                        resModel.Success = false;
                        resModel.Message = Response["cvvresponse"];
                    }

                }
                else if (Response["response"] == "2")
                {
                    resModel.Success = false;
                    resModel.Message = "Invalid Expiration or CVV";
                }
                else
                {
                    resModel.Success = false;
                    resModel.Message = "Incorrect Information";
                }
            }
            _logger.TraceExitMethod(nameof(Handle), resModel);
            return resModel;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress()
            });
        }
    }
}
