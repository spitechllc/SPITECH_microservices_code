﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Commands.SaveToken
{
    public class SaveTokenCommand : IRequest<ResponseModel>
    {
        public int PaymentMethodId { get; set; }
        public int PaymentGatewayId { get; set; }
        public int UserId { get; set; }
        public string CardExpDate { get; set; }
        public string CardName { get; set; }
        public string CardNumber { get; set; }
        public string CardType { get; set; }
        public string AccountNumber { get; set; }
        public string AccountType { get; set; }
        public int BankName { get; set; }
        public string CustId { get; set; }
        public string Operation { get; set; }
        public string Source { get; set; }
        public string Token { get; set; }
    }
}
