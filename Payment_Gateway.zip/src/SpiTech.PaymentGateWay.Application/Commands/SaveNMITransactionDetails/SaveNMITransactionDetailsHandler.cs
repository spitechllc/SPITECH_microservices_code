﻿using AutoMapper;
using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.PaymentGateWay.Application.Services.Interfaces;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain;
using SpiTech.PaymentGateWay.Domain.Models;
using System;
using System.Collections;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;

namespace SpiTech.PaymentGateWay.Application.Commands.SaveNMITransactionDetails
{
    public class SaveNMITransactionDetailsHandler : IRequestHandler<SaveNMITransactionDetailsCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<SaveNMITransactionDetailsHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IMediator _mediator;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly INmiTransactionService nmiService;
        public SaveNMITransactionDetailsHandler(IUnitOfWork context,
                                    ILogger<SaveNMITransactionDetailsHandler> logger,
                                    IMapper mapper,
                                    IEventDispatcher eventDispatcher,
                                    INmiTransactionService nmiService,
                                    IMediator mediator, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
            this.nmiService = nmiService;
            _mediator = mediator;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<ResponseModel> Handle(SaveNMITransactionDetailsCommand command, CancellationToken cancellationToken)
        {

            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel responseModel = new() { Success = false };

            string query = "";

            try
            {
                HttpResponseMessage response = await nmiService.SendRequest(HttpMethod.Get, "", null, null, query);
                NMITransactionsDetailsModel objModel = new();
                if (response.IsSuccessStatusCode)
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    System.Collections.Specialized.NameValueCollection result = responseContent.ParseQueryString();
                    string resContent = responseContent.Substring(39, responseContent.Length - 39);
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(resContent);
                    var json = JsonConvert.SerializeXmlNode(xmlDoc, Newtonsoft.Json.Formatting.None, true);
                    objModel = JsonConvert.DeserializeObject<NMITransactionsDetailsModel>(json);
                    foreach (var item in objModel.transaction)
                    {

                        int nmiTransactionDetailsId = await _context.NmiTransactionDetails.Add(new Domain.Entities.NMITransactionDetails
                        {
                            CcType = item.cc_type,
                            City = item.city,
                            Condition = item.condition,
                            Country = item.country,
                            Currency = item.currency,
                            PostalCode = item.postal_code,
                            ProcessorId = item.processor_id,
                            State = item.state,
                            Tax = item.tax,
                            TransactionId = item.transaction_id,
                            TransactionType = item.transaction_type,
                            IsActive = true
                        });
                        string[] arr = ((IEnumerable)item.action).Cast<object>()
                             .Select(x => x.ToString())
                             .ToArray(); 
                       
                       
                    }
                   

                    string jsonXml = JsonConvert.SerializeObject(objModel);
                    XmlDocument xmlContent = JsonConvert.DeserializeXmlNode("{\"nm_response \":" + jsonXml + "}", "nm_response");

                    responseModel = new ResponseModel
                    {
                        Message = "Success",
                        Success = true
                    };

                }
                return responseModel;
            }
            catch (Exception ex)
            {
                
                _logger.Error(ex);
                return new ResponseModel() { Success = false, Message = ex.Message };
            }


        }


    }
}
