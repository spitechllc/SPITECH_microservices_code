﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Commands.SaveNMITransactionDetails
{
    public class SaveNMITransactionDetailsCommand : IRequest<ResponseModel>
    {
      
    }
}
