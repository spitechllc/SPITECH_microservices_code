﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Commands.CreatePaymentMethodConfiguration
{
    public class CreatePaymentMethodConfigurationCommand : IRequest<ResponseModel>
    {
        public int StoreId { get; set; }
        public int PaymentGatewayConfigId { get; set; }
        public string SiteID { get; set; }
        public string SiteKey { get; set; }
        public string APIKey { get; set; }
        public bool GatewayLiveMode { get; set; }
    }
}
