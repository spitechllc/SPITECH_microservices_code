﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.Queries.GetPaymentMethodConfigurationFilter;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.CreatePaymentMethodConfiguration
{
    public class CreatePaymentMethodConfigurationHandler :
        IRequestHandler<CreatePaymentMethodConfigurationCommand, ResponseModel>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<CreatePaymentMethodConfigurationHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IMediator _mediator;
        public CreatePaymentMethodConfigurationHandler(IUnitOfWork context,
                                             ILogger<CreatePaymentMethodConfigurationHandler> logger,
                                             IMapper mapper,
                                             IMediator mediator
                                    )
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _mediator = mediator;

        }
        public async Task<ResponseModel> Handle(CreatePaymentMethodConfigurationCommand command, CancellationToken cancellationToken)
        {

            Domain.Models.StorePaymentMethodConfigrationModel result = await _mediator.Send(new GetPaymentMethodConfigurationFilterQuery
            {
                StoreId = command.StoreId,
                PaymentGatewayConfigId = command.PaymentGatewayConfigId
            });
            Domain.Entities.StorePaymentMethodConfigration model = new()
            {
                StoreId = command.StoreId,
                PaymentGatewayConfigId = command.PaymentGatewayConfigId,
                SiteID = command.SiteID
            };

            try
            {
                if (result == null)
                {
                    await _context.StorePaymentMethodConfigrations.Add(model);
                }
                else
                {
                    model.ConfigrationId = result.ConfigrationId;
                    await _context.StorePaymentMethodConfigrations.Update(model);
                }
                _context.Commit();
            }
            catch (Exception)
            {
                _context.Rollback();
                throw;
            }
            return new ResponseModel { Success = true, Message = "Success" };

        }
    }
}
