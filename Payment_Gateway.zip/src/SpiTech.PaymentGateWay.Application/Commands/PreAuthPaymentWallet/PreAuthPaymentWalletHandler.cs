﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.Service.Clients.Finance;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.PreAuthPaymentWallet
{
    public class PreAuthPaymentWalletHandler : IRequestHandler<PreAuthPaymentWalletCommand, WalletPreauthDebitModelResponseModel>
    {
        private readonly IFinanceServiceClient _financeApiClient;
        private readonly ILogger<PreAuthPaymentWalletHandler> _logger;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public PreAuthPaymentWalletHandler(IFinanceServiceClient financeApiClient,
            ILogger<PreAuthPaymentWalletHandler> logger, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _financeApiClient = financeApiClient;
            _logger = logger;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<WalletPreauthDebitModelResponseModel> Handle(PreAuthPaymentWalletCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            this.userAuthenticationProvider.ValidateUserAccess(command.UserId);
            WalletPreauthDebitModelResponseModel res = null;

            try
            {
                res = await _financeApiClient.PreAuthPaymentAsync(new WalletPreauthPaymentCommand
                {
                    Amount = (double)command.WalletAmount,
                    DebitType = command.PaymentType,
                    TransactionDesc = command.Description,
                    UserId = command.UserId,
                    StoreId = (int)command.StoreId,
                    StoreName = command.StoreName,
                });
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }

            _logger.TraceExitMethod(nameof(Handle), res);
            return res;

        }
    }
}
