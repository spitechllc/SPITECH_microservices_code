﻿using MediatR;
using SpiTech.Service.Clients.Finance;

namespace SpiTech.PaymentGateWay.Application.Commands.PreAuthPaymentWallet
{
    public class PreAuthPaymentWalletCommand : IRequest<WalletPreauthDebitModelResponseModel>
    {
        public decimal WalletAmount { get; set; }
        public DebitType PaymentType { get; set; }
        public string Description { get; set; }
        public int UserId { get; set; }
        public int? StoreId { get; set; }
        public string StoreName { get; set; }
    }
}
