﻿using System;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.Extensions.Localization;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.PaymentGateWay.Application.Commands.AddACHAccountDetailsByPlaid;
using SpiTech.PaymentGateWay.Application.Commands.GetPlaidInstituteDetailsById;
using SpiTech.PaymentGateWay.Application.Queries.GetPaymentGatewayConfig;
using SpiTech.PaymentGateWay.Application.Services.Interfaces;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Enums;
using SpiTech.PaymentGateWay.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models.Plaid;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;

namespace SpiTech.PaymentGateWay.Application.Commands.AddPaymentSourceDwolla
{
    public class AddPaymentSourceDwollaHandler : IRequestHandler<AddPaymentSourceDwollaCommand, ResponseModel<ACHAuthorizationModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<AddPaymentSourceDwollaHandler> _logger;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IMediator _mediator;
        private readonly IPlaidService plaidService;
        private readonly PlaidGatewayConfigs plaidGatewayConfigs;
        private readonly IUserAuthenticationProvider _authenticationProvider;
        private readonly IStoreServiceClient storeServiceClient;
        private readonly INmiService nmiService;
        private readonly IStringLocalizer<AddPaymentSourceDwollaHandler> _localizer;
        private readonly EncryptionDecryptionKey encryptionDecryptionKey;

        public AddPaymentSourceDwollaHandler(IPlaidService plaidService,
                                             PlaidGatewayConfigs plaidGatewayConfigs,
                                             IMediator mediator,
                                             IUserAuthenticationProvider authenticationProvider,
                                             ILogger<AddPaymentSourceDwollaHandler> logger,
                                             IUnitOfWork context,
                                             IEventDispatcher eventDispatcher,
                                             INmiService nmiService,
                                             IStoreServiceClient storeServiceClient,
                                             IStringLocalizer<AddPaymentSourceDwollaHandler> localizer, EncryptionDecryptionKey encryptionDecryptionKey)
        {
            this.plaidService = plaidService;
            this.plaidGatewayConfigs = plaidGatewayConfigs;
            _mediator = mediator;
            _authenticationProvider = authenticationProvider;
            _logger = logger;
            _context = context;
            _eventDispatcher = eventDispatcher;
            this.nmiService = nmiService;
            this.storeServiceClient = storeServiceClient;
            _localizer = localizer;
            this.encryptionDecryptionKey = encryptionDecryptionKey;
        }
        public async Task<ResponseModel<ACHAuthorizationModel>> Handle(AddPaymentSourceDwollaCommand request,
            CancellationToken cancellationToken)
        {
            _authenticationProvider.ValidateUserAccess(request.UserId);
            string name = string.Empty;
            string processortoken = string.Empty;
            string cardName = string.Empty;
            string accountType = string.Empty;
            string accountNumber = string.Empty;
            string routingNumber = string.Empty;
            string bankName = string.Empty;
            string transactionToken = string.Empty;

            ResponseModel<PlaidAuthDetailsModel> plaidAccountDetails = new() { Success = false };
            ResponseModel<PlaidInstitutionDetailsModel> plaidInstitutionDetails = new() { Success = false };

            string access_token = await PlaidExchangeToken(request);

            //get account detail from plaid
            if (!string.IsNullOrEmpty(access_token))
            {
                plaidAccountDetails = await _mediator.Send(new AddACHAccountDetailsByPlaidCommand() { AccessToken = access_token });
            }

            //********** NMI Customer vault generation process is commented for getting user acceptance/confirmation

            if (plaidAccountDetails != null && plaidAccountDetails.Success)
            {
                if (plaidAccountDetails.Data.accounts != null)
                {
                    cardName = plaidAccountDetails?.Data.accounts.FirstOrDefault().name;
                    accountType = plaidAccountDetails?.Data.accounts.FirstOrDefault().subtype;
                    accountNumber = plaidAccountDetails?.Data.numbers.ach.FirstOrDefault().account;
                    routingNumber = plaidAccountDetails?.Data.numbers.ach.FirstOrDefault().routing;

                    plaidInstitutionDetails = await _mediator.Send(new GetPlaidInstituteDetailsByIdCommand() { InstitutionId = plaidAccountDetails.Data.item.institution_id });
                    bankName = plaidInstitutionDetails.Success ? plaidInstitutionDetails.Data.institution.name : string.Empty;
                }
                else
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure(_localizer["AccountDetails"].Value, _localizer["Not able to get account details from plaid"].Value));
                }
            }
            else
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure(_localizer["AccountDetails"].Value, _localizer["Not able to get account details from plaid"].Value));
            }

            try
            {
                _logger.TraceEnterMethod(nameof(Handle), request);

                bool setIsDefault = true;
                System.Collections.Generic.List<UserPaymentMethod> paymentmethods = await _context.UserPaymentMethods.GetByUserId(request.UserId, 0);

                if (paymentmethods != null && paymentmethods.Count > 0)
                {
                    setIsDefault = false;
                }

                int UserPaymentMethodId = 0;

                if (plaidAccountDetails == null || !plaidAccountDetails.Success)
                {
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure(_localizer["AccountDetail"].Value, _localizer["Not able to get account details from plaid"].Value));
                }

                await _context.Execute(async () =>
                {
                    UserPaymentMethodId = await _context.UserPaymentMethods.Add(new Domain.Entities.UserPaymentMethod
                    {
                        PaymentMethodId = request.PaymentMethodId,
                        UserId = request.UserId,
                        CardName = cardName,
                        AccountType = accountType,
                        AccountNumber = EncryptionDecryptionHelper.Encrypt(accountNumber.Trim(), encryptionDecryptionKey.EncryptDecryptKey),
                        RoutingNumber = routingNumber.Trim(),
                        BankName = bankName,
                        Token = access_token,
                        IsDefault = setIsDefault,
                        CreatedBy = request.UserId,
                        CreatedOn = DateTime.Now,
                        PaymentGatewayConfigId = request.PaymentGatewayId,
                        TransactionToken = access_token,
                        IsFraud = false,
                        IsActive = false
                    });
                });

                ACHAuthorizationModel model = new ACHAuthorizationModel() { UserPaymentMethodId = UserPaymentMethodId, UserId = request.UserId, BankName = bankName };

                _logger.TraceExitMethod(nameof(Handle), UserPaymentMethodId);
                return UserPaymentMethodId > 0
                    ? new ResponseModel<ACHAuthorizationModel>() { Success = true, Message = "Success", Data = model }
                    : new ResponseModel<ACHAuthorizationModel>() { Success = false, Message = "Fail" };

            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }

        private async Task<string> PlaidExchangeToken(AddPaymentSourceDwollaCommand request)
        {
            string access_token = string.Empty;
            Domain.Entities.PaymentGatewayConfig plaidPaymentGatewayConfig = (await _mediator.Send(new GetPaymentGatewayConfigQuery { })).Data.FirstOrDefault(t => (t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithDwolla || t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithStride || t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithNMI) && t.IsActive == true);

            PlaidGatewayConfig plaidGatewayConfig = plaidGatewayConfigs.FirstOrDefault(t => t.IsProd == plaidPaymentGatewayConfig.IsProdEnabled);

            var model = new
            {
                client_id = plaidGatewayConfig.ClientId,
                secret = plaidGatewayConfig.ClientSecret,
                public_token = request.PublicToken
            };
            string strjson = JsonConvert.SerializeObject(model);
            HttpContent content = new StringContent(strjson, Encoding.UTF8, "application/json");
            HttpResponseMessage exchageres = await plaidService.SendRequest(HttpMethod.Post, "item/public_token/exchange", content, null, null);

            if (exchageres.IsSuccessStatusCode)
            {
                string strres = await exchageres.Content.ReadAsStringAsync();
                PlaidExchangePublicTokenResponse token = JsonConvert.DeserializeObject<PlaidExchangePublicTokenResponse>(strres);
                access_token = token.access_token;
            }
            return access_token;
        }

        private async Task<string> PlaidProcessorToken(AddPaymentSourceDwollaCommand request, string access_token)
        {
            string processor_token = string.Empty;

            Domain.Entities.PaymentGatewayConfig plaidPaymentGatewayConfig = (await _mediator.Send(new GetPaymentGatewayConfigQuery { })).Data.FirstOrDefault(t => (t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithDwolla || t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithStride || t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithNMI) && t.IsActive == true);

            PlaidGatewayConfig plaidGatewayConfig = plaidGatewayConfigs.FirstOrDefault(t => t.IsProd == plaidPaymentGatewayConfig.IsProdEnabled);

            var model = new
            {
                client_id = plaidGatewayConfig.ClientId,
                secret = plaidGatewayConfig.ClientSecret,
                access_token = access_token,
                account_id = request.accountID,
                processor = "dwolla"
            };
            string strjson = JsonConvert.SerializeObject(model);
            HttpContent content = new StringContent(strjson, Encoding.UTF8, "application/json");
            HttpResponseMessage exchageres = await plaidService.SendRequest(HttpMethod.Post, "processor/token/create", content, null, null);

            if (exchageres.IsSuccessStatusCode)
            {
                string strres = await exchageres.Content.ReadAsStringAsync();
                PlaidProcessorTokenResponse token = JsonConvert.DeserializeObject<PlaidProcessorTokenResponse>(strres);
                processor_token = token.processor_token;
            }
            else
            {
                string errorres = await exchageres.Content.ReadAsStringAsync();
                object errormsg = JsonConvert.DeserializeObject(errorres);
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("Error", errorres));

            }
            return processor_token;
        }



    }
}
