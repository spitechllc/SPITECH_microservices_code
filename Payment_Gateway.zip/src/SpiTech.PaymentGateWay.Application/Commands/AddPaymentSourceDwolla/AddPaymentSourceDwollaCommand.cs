﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Commands.AddPaymentSourceDwolla
{
    public class AddPaymentSourceDwollaCommand : IRequest<ResponseModel<ACHAuthorizationModel>>
    {
        public int PaymentMethodId { get; set; }
        public int PaymentGatewayId { get; set; }
        public string PublicToken { get; set; }
        public string accountID { get; set; }
        public int UserId { get; set; }
        public int StoreId { get; set; }
        public string UserName { get; set; }
    }
}
