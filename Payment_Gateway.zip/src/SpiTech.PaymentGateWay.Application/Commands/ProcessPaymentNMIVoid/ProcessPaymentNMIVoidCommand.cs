﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Commands.ProcessPaymentNMIVoid
{
    public class ProcessPaymentNMIVoidCommand : IRequest<ResponseModel>
    {
        public string PreAuthconfirmationNo { get; set; }
    }
}
