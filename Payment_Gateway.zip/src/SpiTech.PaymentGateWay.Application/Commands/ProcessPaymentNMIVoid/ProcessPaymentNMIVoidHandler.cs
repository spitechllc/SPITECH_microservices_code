﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.Services.Interfaces;
using SpiTech.PaymentGateWay.Domain;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.ProcessPaymentNMIVoid
{
    public class ProcessPaymentNMIVoidHandler : IRequestHandler<ProcessPaymentNMIVoidCommand, ResponseModel>
    {
        private readonly INmiService nmiService;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly ILogger<ProcessPaymentNMIVoidHandler> _logger;

        public ProcessPaymentNMIVoidHandler(INmiService nmiService,
            IMediator mediator, IMapper mapper, ILogger<ProcessPaymentNMIVoidHandler> logger)
        {
            this.nmiService = nmiService;
            _mediator = mediator;
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<ResponseModel> Handle(ProcessPaymentNMIVoidCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            ResponseModel responseModel = new() { Success = false, Message = "" };
            string query = @$"type=void&transactionid={command.PreAuthconfirmationNo}&void_reason=user_cancel&payment=creditcard";

            HttpResponseMessage response = await nmiService.SendRequest(HttpMethod.Post, "", null, null, query);

            if (response.IsSuccessStatusCode)
            {
                string responseContent = await response.Content.ReadAsStringAsync();
                System.Collections.Specialized.NameValueCollection result = responseContent.ParseQueryString();

                responseModel = result["response"] == "1"
                    ? new ResponseModel
                    {
                        Message = responseContent,
                        Success = true
                    }
                    : new ResponseModel
                    {
                        Message = responseContent,
                        Success = false
                    };
            }

            return responseModel;

        }
    }
}
