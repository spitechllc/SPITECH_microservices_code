﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Entities;
using System;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.MarkFraudAccount
{
    public class MarkFraudAccountHandler : IRequestHandler<MarkFraudAccountCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<MarkFraudAccountHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IEventDispatcher _eventDispatcher;

        public MarkFraudAccountHandler(IUnitOfWork context,
                                ILogger<MarkFraudAccountHandler> logger,
                                IMapper mapper, IUserAuthenticationProvider userAuthenticationProvider, IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _eventDispatcher = eventDispatcher;
        }
        public async Task<ResponseModel> Handle(MarkFraudAccountCommand command, CancellationToken cancellationToken)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Handle), command);
                bool success = false;
                string message = "Fail";

                UserPaymentMethod result = await _context.UserPaymentMethods.Get(command.UserPaymentMethodID);
                this.userAuthenticationProvider.ValidateUserAccess((int)result.UserId);
                if (result != null)
                {
                    result.IsFraud = true;
                    await _context.Execute(async () =>
                    {
                        success = await _context.UserPaymentMethods.Update(result);
                    });
                                      
                }

                _logger.TraceExitMethod(nameof(Handle), success);

                return new ResponseModel() { Success = success, Message = message };
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return new ResponseModel() { Success = false, Message = ex.Message };
            }
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress()
            });
        }
    }
}
