﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Commands.MarkFraudAccount
{
    public class MarkFraudAccountValidator : AbstractValidator<MarkFraudAccountCommand>
    {
        public MarkFraudAccountValidator()
        {
            RuleFor(x => x.UserPaymentMethodID).GreaterThan(0).WithMessage("UserPaymentMethodID Required");
        }
    }
}
