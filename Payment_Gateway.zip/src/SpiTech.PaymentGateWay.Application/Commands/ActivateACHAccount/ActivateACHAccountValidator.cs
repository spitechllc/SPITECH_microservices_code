﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Commands.ActivateACHAccount
{
    public class ActivateACHAccountValidator : AbstractValidator<ActivateACHAccountCommand>
    {
        public ActivateACHAccountValidator()
        {
            RuleFor(x => x.UserPaymentMethodId).GreaterThan(0)
                .WithMessage("UserPaymentMethodId is required");
        }
    }
}
