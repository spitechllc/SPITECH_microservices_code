﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Commands.ActivateACHAccount
{
    public class ActivateACHAccountCommand:IRequest<ResponseModel>
    {
        public int UserPaymentMethodId { get; set; }
        public int UserId { get; set; }
    }
    //public class ActivateACHAccountCommand : ActivateACHAccountModel,ITenantCommand<ResponseModel>
    //{
    //    public int? TenantId { get; set; }
    //    public string ClientId { get; set; }
    //}
}
