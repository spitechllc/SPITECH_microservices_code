﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Commands.SaveStoreConfig
{
    public class SaveStoreConfigCommand : IRequest<ResponseModel>
    {
        public int StoreId { get; set; }
        public string AccountName { get; set; }
        public string Bank { get; set; }
        public string AccountNo { get; set; }
        public string RoutingNo { get; set; }
        public bool IsChecking { get; set; }
        public bool IsMasterAccount { get; set; }
        public string PaymentProcessorId { get; set; }
        public string ACHProcessorId { get; set; }
        public bool? IsAchEnabled { get; set; }
        public bool IsActive { get; set; }
    }
}
