﻿using AutoMapper;
using MediatR;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Configs;
using System;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.SaveStoreConfig
{
    public class SaveStoreConfigHandler : IRequestHandler<SaveStoreConfigCommand, ResponseModel>
    {
        private readonly IUnitOfWork context;
        private readonly SpiTech.Application.Logging.Interfaces.ILogger<SaveStoreConfigHandler> logger;
        private readonly IMapper mapper;
        private readonly EncryptionDecryptionKey encryptionDecryptionKey;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IEventDispatcher _eventDispatcher;
        public SaveStoreConfigHandler(IUnitOfWork context,
                                    SpiTech.Application.Logging.Interfaces.ILogger<SaveStoreConfigHandler> logger,
                                    IMapper mapper, EncryptionDecryptionKey encryptionDecryptionKey, IUserAuthenticationProvider userAuthenticationProvider, IEventDispatcher eventDispatcher)
        {
            this.context = context;
            this.logger = logger;
            this.mapper = mapper;
            this.encryptionDecryptionKey = encryptionDecryptionKey;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _eventDispatcher = eventDispatcher;
        }

        public async Task<ResponseModel> Handle(SaveStoreConfigCommand command, CancellationToken cancellationToken)
        {
            ResponseModel responseModel = new() { };
            try
            {
                logger.TraceEnterMethod(nameof(Handle), command);


                Domain.Entities.StoreConfig storeConfig = await context.StoreConfigs.Get(command.StoreId);

                if (storeConfig == null)
                {
                    await context.Execute(async () =>
                    {
                        var storeConfig = new Domain.Entities.StoreConfig
                        {
                            StoreId = command.StoreId,
                            PaymentProcessorId = command.PaymentProcessorId,
                            AccountName = command.AccountName,
                            Bank = command.Bank,
                            IsMasterAccount = command.IsMasterAccount,
                            IsChecking = command.IsChecking,
                            IsActive = command.IsActive,
                            ACHProcessorId = command.ACHProcessorId,
                            IsAchEnabled = command.IsAchEnabled,
                            RoutingNo = command.RoutingNo.Trim()
                        };

                        var accountNo = command.AccountNo.Trim();
                        if (Regex.IsMatch(accountNo, @"^\d+$"))
                        {
                            storeConfig.AccountNo = EncryptionDecryptionHelper.Encrypt(accountNo, encryptionDecryptionKey.EncryptDecryptKey);
                        }
                        else
                        {
                            throw new ValidationException(new FluentValidation.Results.ValidationFailure("AccountNo", "Invalid AccountNo"));
                        }

                        await context.StoreConfigs.Add(storeConfig);
                    });
                }
                else
                {
                    await context.Execute(async () =>
                    {
                        storeConfig.PaymentProcessorId = command.PaymentProcessorId;
                        storeConfig.PaymentProcessorId = command.PaymentProcessorId;
                        storeConfig.AccountName = command.AccountName;
                        storeConfig.Bank = command.Bank;
                        storeConfig.IsMasterAccount = command.IsMasterAccount;
                        storeConfig.IsChecking = command.IsChecking;
                        storeConfig.IsActive = command.IsActive;
                        storeConfig.ACHProcessorId = command.ACHProcessorId;
                        storeConfig.IsAchEnabled = command.IsAchEnabled;
                        storeConfig.RoutingNo = command.RoutingNo.Trim();

                        var accountNo = command.AccountNo.Trim();
                        if (Regex.IsMatch(accountNo, @"^\d+$"))
                        {
                            storeConfig.AccountNo = EncryptionDecryptionHelper.Encrypt(accountNo, encryptionDecryptionKey.EncryptDecryptKey);
                        }

                        await context.StoreConfigs.Update(storeConfig);
                    });
                }
                responseModel.Success = true;
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.AddStoreConfig, "Store Account Details Added.");
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return new ResponseModel() { Success = false, Message = ex.Message };
            }

            return responseModel;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress()
            });
        }
    }
}
