﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents.Enums;

namespace SpiTech.PaymentGateWay.Application.Commands.ProcessPaymentNMIACH
{
    public class ProcessPaymentNMIACHCommand : IRequest<ResponseModel>
    {
        public decimal CardAmount { get; set; }
        public decimal WalletAmount { get; set; }
        public int UserPaymentMethodId { get; set; }
        public int? StoreId { get; set; }
    }
}
