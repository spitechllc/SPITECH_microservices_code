﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.Services.Interfaces;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain;
using SpiTech.PaymentGateWay.Domain.Entities;
using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.ProcessPaymentNMIACH
{
    public class ProcessPaymentNMIACHHandler : IRequestHandler<ProcessPaymentNMIACHCommand, ResponseModel>
    {
        private readonly INmiService nmiService;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly ILogger<ProcessPaymentNMIACHHandler> _logger;
        private readonly IUnitOfWork _context;

        public ProcessPaymentNMIACHHandler(INmiService nmiService,
            IMediator mediator, IMapper mapper, ILogger<ProcessPaymentNMIACHHandler> logger, IUnitOfWork context)
        {
            this.nmiService = nmiService;
            _mediator = mediator;
            _mapper = mapper;
            _logger = logger;
            _context = context;
        }

        public async Task<ResponseModel> Handle(ProcessPaymentNMIACHCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            ResponseModel responseModel = new() { Success = false, Message = "Payment fail" };

            UserPaymentMethod walletUserPaymentMethod = null;
            UserPaymentMethod userPaymentMethod = null;

            if (command.WalletAmount > 0)
            {
                walletUserPaymentMethod = userPaymentMethod = await _context.UserPaymentMethods.Get(1);
            }

            if (command.CardAmount > 0)
            {
                userPaymentMethod = await _context.UserPaymentMethods.Get(command.UserPaymentMethodId);
            }

            if (userPaymentMethod == null || userPaymentMethod.UserPaymentMethodId == 0)
            {
                return new ResponseModel
                {
                    Success = false,
                    Message = "Account not found"
                };
            }

            string processorId = "";

            StoreConfig storeConfig = await _context.StoreConfigs.Get(command.StoreId);

            if (storeConfig != null && storeConfig.IsActive && !string.IsNullOrWhiteSpace(storeConfig.PaymentProcessorId))
            {
                processorId = $"&processor_id={storeConfig.PaymentProcessorId}ach";
            }

            string query = @$"type=sale&amount={command.CardAmount}&customer_vault_id={userPaymentMethod.TransactionToken}{processorId}&payment=check&sec_code=WEB";

            try
            {
                HttpResponseMessage response = await nmiService.SendRequest(HttpMethod.Post, "", null, null, query);

                if (response.IsSuccessStatusCode)
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    System.Collections.Specialized.NameValueCollection result = responseContent.ParseQueryString();

                    responseModel = result["response"] == "1"
                        ? new ResponseModel
                        {
                            Message = responseContent,
                            Success = true
                        }
                        : new ResponseModel
                        {
                            Message = responseContent,
                            Success = false
                        };
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }

            return responseModel;
        }
    }
}
