﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Commands.UpdatePreAuthPayment
{
    public class UpdatePreAuthPaymentCommand : IRequest<ResponseModel>
    {
        public Domain.Entities.PreAuthPayment PreAuthPayment { get; set; }
    }
}
