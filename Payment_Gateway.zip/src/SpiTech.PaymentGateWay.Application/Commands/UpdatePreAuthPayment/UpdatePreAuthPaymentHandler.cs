﻿using AutoMapper;
using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using System;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.UpdatePreAuthPayment
{
    public class UpdatePreAuthPaymentHandler : IRequestHandler<UpdatePreAuthPaymentCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdatePreAuthPaymentHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IEventDispatcher _eventDispatcher;

        public UpdatePreAuthPaymentHandler(IUnitOfWork context,
            ILogger<UpdatePreAuthPaymentHandler> logger,
            IMapper mapper, IUserAuthenticationProvider userAuthenticationProvider, IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _eventDispatcher = eventDispatcher;
        }
        public async Task<ResponseModel> Handle(UpdatePreAuthPaymentCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            this.userAuthenticationProvider.ValidateUserAccess(command.PreAuthPayment.UserId);
            try
            {
                Domain.Entities.PreAuthPayment PreAuthPaymentPre =await _context.PreAuthPayments.Get(command.PreAuthPayment.PreAuthPaymentId);
                string strPreData = JsonConvert.SerializeObject(PreAuthPaymentPre);
                bool id = await _context.PreAuthPayments.Update(command.PreAuthPayment);
                _logger.TraceExitMethod(nameof(Handle), id);
                _context.Commit();
                string strPostData = JsonConvert.SerializeObject(command.PreAuthPayment);
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.UpdatePreAuthPayment, "PreAuthPayment Updated", strPreData, strPostData);
            }
            catch (Exception)
            {
                _context.Rollback();
            }

            return new ResponseModel { Success = true, Message = "Success" };
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, string preData, string postData)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress(),
                ActivityPreData = preData,
                ActivityPostData = postData
            });
        }
    }
}
