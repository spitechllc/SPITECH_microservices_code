﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Commands.UpdateMerchantNMI
{
    public class UpdateMerchantNMICommand : IRequest<ResponseModel<NMIMerchantResponseModel>>
    {
        public int Id { get; set; }
        public string Platform { get; set; }
        public string industryclassification { get; set; }
        public double max_monthly_volume { get; set; }
        public bool enable_duplicate_checking { get; set; }
        public bool allow_duplicate_checking_override { get; set; }
        public int duplicate_checking_seconds { get; set; }
        public string processor_description { get; set; }
        public string mccNumber { get; set; }
    }
}
