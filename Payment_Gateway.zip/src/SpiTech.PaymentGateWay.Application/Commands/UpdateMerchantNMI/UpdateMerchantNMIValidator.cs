﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Commands.UpdateMerchantNMI
{
    public class UpdateMerchantNMIValidator : AbstractValidator<UpdateMerchantNMICommand>
    {
        public UpdateMerchantNMIValidator()
        {
            //RuleFor(x => x.Token).NotNull().Length(1, 50);
            //RuleFor(x => x.AccountNumber).GreaterThan(0);
            //RuleFor(x => x.AccountType).NotNull().Length(1,30);
            //RuleFor(x => x.CustId).NotNull().Length(1,50);
            //RuleFor(x => x.RoutingNumber).GreaterThan(0);
        }
    }
}
