﻿using AutoMapper;
using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.PaymentGateWay.Application.Queries.GetPaymentGatewayConfig;
using SpiTech.PaymentGateWay.Application.Services.Interfaces;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Enums;
using SpiTech.PaymentGateWay.Domain.Models;
using System;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using SpiTech.ApplicationCore.Domain.Exceptions;

namespace SpiTech.PaymentGateWay.Application.Commands.CreateMerchantNMI
{
    public class CreateMerchantNMIHandler : IRequestHandler<CreateMerchantNMICommand, ResponseModel<NMIMerchantResponseModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateMerchantNMIHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IMediator _mediator;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly INmiMerchantService _nmiMerchantService;
        public CreateMerchantNMIHandler(IUnitOfWork context,
                                    ILogger<CreateMerchantNMIHandler> logger,
                                    IMapper mapper,
                                    IEventDispatcher eventDispatcher,
                                    INmiMerchantService nmiMerchantService,
                                    IMediator mediator, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
            _nmiMerchantService = nmiMerchantService;
            _mediator = mediator;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<ResponseModel<NMIMerchantResponseModel>> Handle(CreateMerchantNMICommand command, CancellationToken cancellationToken)
        {
            ResponseModel<NMIMerchantResponseModel> responseModel = new() { Success = false };
            try
            {
                _logger.TraceEnterMethod(nameof(Handle), command);
               
                string customer_vault_id = string.Empty;
                string query = string.Empty;
                Domain.Entities.PaymentGatewayConfig nmiPaymentGatewayConfig = (await _mediator.Send(new GetPaymentGatewayConfigQuery { })).Data.FirstOrDefault(t => t.PaymentGatewayConfigId == (int)EnumPaymentGateway.NMI);

                NMIMerchantResponseModel objModel = new();

                var model = new
                {
                    Platform = command.Platform,
                    industryclassification = command.industryclassification,
                    max_monthly_volume = command.max_monthly_volume,
                    enable_duplicate_checking=command.enable_duplicate_checking,
                    allow_duplicate_checking_override=command.allow_duplicate_checking_override,
                    duplicate_checking_seconds=command.duplicate_checking_seconds,
                    processor_description=command.processor_description,
                    mcc=command.mccNumber
                };

                string strjson = JsonConvert.SerializeObject(model);
                HttpContent content = new StringContent(strjson, Encoding.UTF8, "application/json");

                HttpResponseMessage res = await _nmiMerchantService.SendRequest(HttpMethod.Post, "",
                    content, null, "");

                if (res.IsSuccessStatusCode)
                {
                    string merchantDetails = await res.Content.ReadAsStringAsync();
                    objModel = JsonConvert.DeserializeObject<NMIMerchantResponseModel>(merchantDetails);
                    responseModel.Success = true;
                    responseModel.Message = "Success";
                    responseModel.Data = objModel;
                }
                else
                {
                    string errorres = await res.Content.ReadAsStringAsync();
                    responseModel.Success = false;
                    responseModel.Message = errorres;
                    throw new ValidationException(new FluentValidation.Results.ValidationFailure("Error", errorres));

                }
                _logger.TraceExitMethod(nameof(Handle), responseModel);
                return responseModel;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                return new ResponseModel<NMIMerchantResponseModel>() { Success = false, Message = ex.Message };
            }
        }
    }
}
