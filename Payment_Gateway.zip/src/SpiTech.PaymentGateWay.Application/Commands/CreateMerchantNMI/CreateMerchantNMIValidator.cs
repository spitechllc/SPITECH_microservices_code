﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Commands.CreateMerchantNMI
{
    public class CreateMerchantNMIValidator : AbstractValidator<CreateMerchantNMICommand>
    {
        public CreateMerchantNMIValidator()
        {
            //RuleFor(x => x.Token).NotNull().Length(1, 50);
            //RuleFor(x => x.AccountNumber).GreaterThan(0);
            //RuleFor(x => x.AccountType).NotNull().Length(1,30);
            //RuleFor(x => x.CustId).NotNull().Length(1,50);
            //RuleFor(x => x.RoutingNumber).GreaterThan(0);
        }
    }
}
