﻿using MediatR;

namespace SpiTech.PaymentGateWay.Application.Commands.CreateWebHookDetail
{
    public class CreateWebHookDetailCommand : IRequest<bool>
    {
        public string Message { get; set; }
    }
}
