﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.CreateWebHookDetail
{
    public class CreateWebHookDetailHandler : IRequestHandler<CreateWebHookDetailCommand, bool>
    {
        private readonly IMediator _mediator;
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateWebHookDetailHandler> _logger;

        public CreateWebHookDetailHandler(IMediator mediator, IUnitOfWork context, ILogger<CreateWebHookDetailHandler> logger)
        {
            _context = context;
            _mediator = mediator;
            _logger = logger;
        }
        public async Task<bool> Handle(CreateWebHookDetailCommand request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            var result = false;

            try
            {
                var webHookDetailId = await _context.WebHookDetails.Insert(new Domain.Entities.WebHookDetail
                {
                    Message = request.Message
                });
                _context.Commit();
                result = true;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                _context.Rollback();
            }

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
