﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.Services.Interfaces;
using SpiTech.PaymentGateWay.Domain;
using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.ProcessPaymentNMICapture
{
    public class ProcessPaymentNMIHandler : IRequestHandler<ProcessPaymentNMICommand, ResponseModel>
    {
        private readonly INmiService nmiService;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly ILogger<ProcessPaymentNMIHandler> _logger;

        public ProcessPaymentNMIHandler(INmiService nmiService,
            IMediator mediator, IMapper mapper, ILogger<ProcessPaymentNMIHandler> logger)
        {
            this.nmiService = nmiService;
            _mediator = mediator;
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<ResponseModel> Handle(ProcessPaymentNMICommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            ResponseModel responseModel = new() { Success = false, Message = "Card payment fail" };

            string query = @$"type=capture&amount={command.Amount}&transactionid={command.PreAuthconfirmationNo}";

            try
            {
                HttpResponseMessage response = await nmiService.SendRequest(HttpMethod.Post, "", null, null, query);

                if (response.IsSuccessStatusCode)
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    System.Collections.Specialized.NameValueCollection result = responseContent.ParseQueryString();

                    responseModel = result["response"] == "1"
                        ? new ResponseModel
                        {
                            Message = responseContent,
                            Success = true
                        }
                        : new ResponseModel
                        {
                            Message = responseContent,
                            Success = false
                        };
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }

            return responseModel;
        }
    }
}
