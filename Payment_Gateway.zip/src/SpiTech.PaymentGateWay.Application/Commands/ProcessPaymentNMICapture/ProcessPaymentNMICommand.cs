﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Commands.ProcessPaymentNMICapture
{
    public class ProcessPaymentNMICommand : IRequest<ResponseModel>
    {
        public string PreAuthconfirmationNo { get; set; }
        public decimal Amount { get; set; }
    }
}
