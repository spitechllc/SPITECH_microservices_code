﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Commands.PreAuthPayment
{
    public class PreAuthPaymentCommand : IRequest<ResponseModel<PreAuthPaymentResponseModel>>
    {
        public long? TransactionId { get; set; }
        public int UserId { get; set; }
        public decimal CardAmount { get; set; }
        public decimal WalletAmount { get; set; }
        public PaymentType PaymentType { get; set; }
        public int UserPaymentMethodId { get; set; }
        public string Description { get; set; }
        public int? StoreId { get; set; }
        public string StoreName { get; set; }
        public string SiteId { get; set; }
        public string ConsumerIP { get; set; }
        public bool IsPaymentRequired { get; set; }
    }
}
