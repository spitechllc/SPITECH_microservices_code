﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.PaymentGateWay.Application.Commands.PreAuthPaymentWallet;
using SpiTech.PaymentGateWay.Application.Commands.ProcessPaymentNMIVoid;
using SpiTech.PaymentGateWay.Application.Queries.GetPaymentGatewayConfig;
using SpiTech.PaymentGateWay.Application.Services.Interfaces;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Enums;
using SpiTech.PaymentGateWay.Domain.Models;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.PreAuthPayment
{
    public class PreAuthPaymentHandler : IRequestHandler<PreAuthPaymentCommand, ResponseModel<PreAuthPaymentResponseModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<PreAuthPaymentHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IMediator _mediator;
        private readonly INmiService nmiService;
        private readonly IFinanceServiceClient financeApiClient;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IEventDispatcher _eventDispatcher;

        public PreAuthPaymentHandler(IUnitOfWork context,
                                    ILogger<PreAuthPaymentHandler> logger,
                                    IMapper mapper,
                                    IMediator mediator,
                                    INmiService nmiService,
                                    IFinanceServiceClient financeApiClient, IUserAuthenticationProvider userAuthenticationProvider, IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _mediator = mediator;
            this.nmiService = nmiService;
            this.financeApiClient = financeApiClient;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _eventDispatcher = eventDispatcher;
        }
        public async Task<ResponseModel<PreAuthPaymentResponseModel>> Handle(PreAuthPaymentCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            this.userAuthenticationProvider.ValidateUserAccess(command.UserId);
            UserPaymentMethod walletUserPaymentMethod = null;
            UserPaymentMethod userPaymentMethod = null;

            if (command.WalletAmount > 0)
            {
                walletUserPaymentMethod = userPaymentMethod = await _context.UserPaymentMethods.Get(1);
            }

            if (command.CardAmount > 0)
            {
                userPaymentMethod = await _context.UserPaymentMethods.Get(command.UserPaymentMethodId);
            }

            if (userPaymentMethod == null || userPaymentMethod.UserPaymentMethodId == 0)
            {
                return new ResponseModel<PreAuthPaymentResponseModel>
                {
                    Success = false,
                    Message = "Card is not found"
                };
            }
            if (userPaymentMethod == null || userPaymentMethod.IsFraud == true)
            {
                return new ResponseModel<PreAuthPaymentResponseModel>
                {
                    Success = false,
                    Message = "Account is blocked for transactions."
                };
            }

            TransactionResponseModel walletResponse = null;
            TransactionResponseModel cardResponse = null;

            if (command.WalletAmount > 0)
            {
                walletResponse = await PreauthWallet(command);
            }

            if ((walletResponse == null || walletResponse.Status == EnumPaymentStatus.Success) && command.CardAmount > 0)
            {
                if (userPaymentMethod.PaymentMethodId == (int)EnumPaymentMethod.CreditCard)
                {
                    cardResponse = await HandleCreditCard(command, command.CardAmount, userPaymentMethod.TransactionToken,userPaymentMethod.PaymentMethodId);
                }
                else if (userPaymentMethod.PaymentMethodId == (int)EnumPaymentMethod.ACH)
                {

                    StoreConfig result = await _context.StoreConfigs.Get(command.StoreId);
                    if (result.IsAchEnabled == false || result.IsAchEnabled == null)
                    {
                        return new ResponseModel<PreAuthPaymentResponseModel>
                        {
                            Success = false,
                            Message = "ACH payment is not enabled"
                        };
                    }
                    var paymentGatewayConfigs = await _context.PaymentGatewayConfigs.GetAll();
                    if (paymentGatewayConfigs.FirstOrDefault(t => t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithDwolla).IsActive || paymentGatewayConfigs.FirstOrDefault(t => t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithStride).IsActive || paymentGatewayConfigs.FirstOrDefault(t => t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithNMI).IsActive)
                    {
                        cardResponse = new TransactionResponseModel { Status = EnumPaymentStatus.Success };
                    }
                    else
                    {
                        cardResponse = new TransactionResponseModel { Status = EnumPaymentStatus.Fail, Response = "ACH payment inactive" };
                    }

                }
                else
                {
                    cardResponse= new TransactionResponseModel { Status = EnumPaymentStatus.Fail, Response = "Invalid PaymentMethodId" };
                }
                    
            }

            Domain.Entities.PreAuthPayment preauth = await SavePreAuthPayment(walletUserPaymentMethod?.CardType, userPaymentMethod, command, walletResponse, cardResponse);
            await DispatchActivityLogEvent(command.UserId, (int)ActivityType.PreAuth, "User Payment PreAuth.");
            return await GetResponse(preauth);
        }

        private async Task<TransactionResponseModel> PreauthWallet(PreAuthPaymentCommand command)
        {
            Service.Clients.Finance.WalletPreauthDebitModelResponseModel walletPreAuthResponse = await _mediator.Send(new PreAuthPaymentWalletCommand
            {
                UserId = command.UserId,
                Description = command.Description,
                PaymentType = (Service.Clients.Finance.DebitType)command.PaymentType,
                WalletAmount = command.WalletAmount,
                StoreId = command.StoreId,
                StoreName = command.StoreName,
            });

            TransactionResponseModel walletResponse = walletPreAuthResponse != null && walletPreAuthResponse.Success
                ? new TransactionResponseModel
                {
                    Status = EnumPaymentStatus.Success,
                    Response = "",
                    AuthConfirmationNo = walletPreAuthResponse?.Data?.AuthNumber
                }
                : new TransactionResponseModel
                {
                    Status = EnumPaymentStatus.Fail,
                    Response = walletPreAuthResponse?.Message ?? "Wallet Payment fail"
                };

            return walletResponse;
        }

        private async Task<ResponseModel> VoidWalletTransaction(string walletPreAuthConfirmationNo)
        {
            ResponseModel response = new() { Message = "", Success = true };

            if (!string.IsNullOrEmpty(walletPreAuthConfirmationNo))
            {
                Service.Clients.Finance.ResponseModel voidWalletPaymentResponse = await financeApiClient.VoidPaymentAsync(new Service.Clients.Finance.WalletVoidPaymentModel
                {
                    AuthNumber = walletPreAuthConfirmationNo
                });

                response.Message = voidWalletPaymentResponse.Message;
                response.Success = voidWalletPaymentResponse.Success;
            }

            return response;
        }

        private async Task<ResponseModel> VoidCardTransaction(string cardPreAuthConfirmationNo)
        {
            ResponseModel response = new() { Message = "", Success = true };

            if (!string.IsNullOrEmpty(cardPreAuthConfirmationNo))
            {
                response = await _mediator.Send(new ProcessPaymentNMIVoidCommand
                {
                    PreAuthconfirmationNo = cardPreAuthConfirmationNo
                });
            }

            return response;
        }

        private Task<ResponseModel<PreAuthPaymentResponseModel>> GetResponse(Domain.Entities.PreAuthPayment preAuthPayment)
        {
            string message = "";

            if (preAuthPayment == null)
            {
                return Task.FromResult(new ResponseModel<PreAuthPaymentResponseModel>
                {
                    Success = false,
                    Message = "Unable to do preauthorization"
                });
            }

            if (preAuthPayment != null && preAuthPayment.WalletPreAuthPaymentStatusId == (int)EnumPaymentStatus.Fail)
            {
                message = preAuthPayment?.WalletResponse;
            }
            else if (preAuthPayment != null && preAuthPayment.CardPreAuthPaymentStatusId == (int)EnumPaymentStatus.Fail)
            {
                message = preAuthPayment?.CardResponse;
            }

            ResponseModel<PreAuthPaymentResponseModel> result = new()
            {
                Success = preAuthPayment?.Success ?? false,
                Message = message
            };

            if (result.Success)
            {
                result.Data = _mapper.Map<PreAuthPaymentResponseModel>(preAuthPayment);
            }

            return Task.FromResult(result);
        }

        public async Task<TransactionResponseModel> HandleCreditCard(PreAuthPaymentCommand command, decimal ammount, string nMICustomerVaultId,int PaymentMethodId)
        {
            _logger.TraceEnterMethod(nameof(Handle), command, ammount);

            TransactionResponseModel transactionResponse = new() { Status = EnumPaymentStatus.Fail };

            string processorId = "";

            StoreConfig storeConfig = await _context.StoreConfigs.Get(command.StoreId);

            Domain.Entities.PaymentGatewayConfig nmiPaymentGatewayConfig = (await _mediator.Send(new GetPaymentGatewayConfigQuery { })).Data.FirstOrDefault(t => t.PaymentGatewayConfigId == (int)EnumPaymentGateway.NMI);


            if (nmiPaymentGatewayConfig.IsProdEnabled)
            {
                if (storeConfig != null && storeConfig.IsActive && !string.IsNullOrWhiteSpace(storeConfig.PaymentProcessorId))
                {
                    processorId = $"&processor_id={storeConfig.PaymentProcessorId}";
                }
            }

            string query = @$"type=auth&amount={ammount}&customer_vault_id={nMICustomerVaultId}{processorId}&orderid={command.TransactionId}&order_description={command.Description}";

            try
            {
                HttpResponseMessage response = await nmiService.SendRequest(HttpMethod.Post, "", null, null, query);

                if (response.IsSuccessStatusCode)
                {
                    string strResponse = await response.Content.ReadAsStringAsync();
                    System.Collections.Specialized.NameValueCollection preAuthResponse = strResponse.ParseQueryString();

                    transactionResponse = new TransactionResponseModel
                    {
                        AuthConfirmationNo = preAuthResponse["transactionid"],
                        Response = strResponse,
                        Status = preAuthResponse["response"] == "1" ? EnumPaymentStatus.Success : EnumPaymentStatus.Fail
                    };
                }
            }
            catch (Exception ex)
            {
                transactionResponse.Response = ex.Message;
                _logger.Error(ex);
            }

            return transactionResponse;
        }

        private async Task<Domain.Entities.PreAuthPayment> SavePreAuthPayment(
            string walletCardType,
            UserPaymentMethod userPaymentMethod,
            PreAuthPaymentCommand command,
            TransactionResponseModel walletResponse,
            TransactionResponseModel cardResponse)
        {
            string walletResponseMessage = walletResponse?.Response;

            if (command.CardAmount > 0 && cardResponse != null && cardResponse.Status != EnumPaymentStatus.Success && walletResponse != null && walletResponse.Status == EnumPaymentStatus.Success)
            {
                ResponseModel voidResponse = await VoidWalletTransaction(walletResponse.AuthConfirmationNo);

                if (voidResponse != null && voidResponse.Success)
                {
                    walletResponse.Status = EnumPaymentStatus.Void;
                    walletResponseMessage = "Void Wallet Amount";
                }
                else
                {
                    walletResponseMessage = "Unable to Void Wallet Amount";
                }
            }

            Domain.Entities.PreAuthPayment preAuthPayment = new()
            {
                PreAuthConfirmationNo = Guid.NewGuid().ToString("N"),
                PaymentGatewayConfigId = 1,
                UserPaymentMethodId = command.UserPaymentMethodId,
                PaymentMethodId = userPaymentMethod.PaymentMethodId,
                UserId = command.UserId,
                TransactionId = command.TransactionId,
                SiteId = command.SiteId,
                StoreId = command.StoreId,
                Amount = command.WalletAmount + command.CardAmount,
                Description = command.Description,
                TransactionType = (int)command.PaymentType,
                StoreName = command.StoreName,
                PreAuthDate = DateTime.UtcNow,
                CardNumber = userPaymentMethod.CardNumber,
                AccountNumber = userPaymentMethod.AccountNumber,
                BankName = userPaymentMethod.BankName,
                ConsumerIP = command.ConsumerIP,
                Success = (cardResponse == null || cardResponse.Status != EnumPaymentStatus.Fail) && (walletResponse == null || walletResponse?.Status != EnumPaymentStatus.Fail),
                CardAmount = command.CardAmount,
                CardResponse = cardResponse?.Response,
                CardPreAuthConfirmationNo = cardResponse?.AuthConfirmationNo,
                CardPreAuthPaymentStatusId = (int?)cardResponse?.Status,
                WalletAmount = command.WalletAmount,
                WalletResponse = walletResponseMessage,
                WalletPreAuthConfirmationNo = walletResponse?.AuthConfirmationNo,
                WalletPreAuthPaymentStatusId = (int?)walletResponse?.Status,
                IsPaymentRequired = command.IsPaymentRequired,
                CreatedOn = DateTime.UtcNow,
                IsActive = true,
            };

            if (command.WalletAmount > 0 && command.CardAmount > 0)
            {
                if (!string.IsNullOrEmpty(userPaymentMethod.CardType))
                {
                    preAuthPayment.CardType = $"{walletCardType},{userPaymentMethod.CardType}";
                }

                if (!string.IsNullOrEmpty(userPaymentMethod.AccountType))
                {
                    preAuthPayment.AccountType = $"{walletCardType},{userPaymentMethod.AccountType}";
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(userPaymentMethod.CardType))
                {
                    preAuthPayment.CardType = userPaymentMethod.CardType;
                }

                if (!string.IsNullOrEmpty(userPaymentMethod.AccountType))
                {
                    preAuthPayment.AccountType = userPaymentMethod.AccountType;
                }
            }

            try
            {
                preAuthPayment.PreAuthPaymentId = await _context.PreAuthPayments.Add(preAuthPayment);
                _context.Commit();
            }
            catch (Exception ex)
            {
                preAuthPayment = null;

                _logger.Error(ex, "PreAuthPayment Save Error");
                _context.Rollback();

                if (command.WalletAmount > 0 && walletResponse?.Status == EnumPaymentStatus.Success && !string.IsNullOrWhiteSpace(walletResponse?.AuthConfirmationNo))
                {
                    ResponseModel voidResponse = await VoidWalletTransaction(walletResponse?.AuthConfirmationNo);
                    if (voidResponse == null || !voidResponse.Success)
                    {
                        _logger.Error(new ApplicationCore.Domain.Exceptions.ExecutionException($"Unable to Void Wallet Amount with AuthConfirmationNo:{walletResponse?.AuthConfirmationNo}"), "PreAuthPayment Save Error");
                    }
                }

                if (command.CardAmount > 0 && cardResponse?.Status == EnumPaymentStatus.Success && !string.IsNullOrWhiteSpace(cardResponse?.AuthConfirmationNo))
                {
                    ResponseModel voidResponse = await VoidCardTransaction(cardResponse?.AuthConfirmationNo);
                    if (voidResponse == null || !voidResponse.Success)
                    {
                        _logger.Error(new ApplicationCore.Domain.Exceptions.ExecutionException($"Unable to Void Card Amount with AuthConfirmationNo:{walletResponse?.AuthConfirmationNo}"), "PreAuthPayment Save Error");
                    }
                }
            }

            return preAuthPayment;
        }

        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ""//ApplicationCore.Helpers.IPAddressHelper.GetIPAddress()
            });
        }
    }
}
