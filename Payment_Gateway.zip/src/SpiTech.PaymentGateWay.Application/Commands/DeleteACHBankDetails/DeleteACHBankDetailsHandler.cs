﻿using AutoMapper;
using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.PaymentGateWay.Application.Services.Interfaces;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;
using System;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.DeleteACHBankDetails
{
    public class DeleteACHBankDetailsHandler : IRequestHandler<DeleteACHBankDetailsCommand, ResponseModel>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<DeleteACHBankDetailsHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider _authenticationProvider;

        private readonly IEventDispatcher _eventDispatcher;
        private readonly INmiService nmiService;
        public DeleteACHBankDetailsHandler(IUnitOfWork context,
                                    ILogger<DeleteACHBankDetailsHandler> logger,
                                    IMapper mapper,
                                    IUserAuthenticationProvider authenticationProvider,
                                    IEventDispatcher eventDispatcher,
                                    INmiService nmiService)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _authenticationProvider = authenticationProvider;
            _eventDispatcher = eventDispatcher;
            this.nmiService = nmiService;
        }
        public async Task<ResponseModel> Handle(DeleteACHBankDetailsCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            string responseText = string.Empty;
            bool isSuccess = false;

            UserPaymentMethod paymentmethod = await _context.UserPaymentMethods.Get(command.UserPaymentMethodId);

            if (paymentmethod != null && paymentmethod.UserPaymentMethodId > 0)
            {
                if(paymentmethod.UserId>0)
                {
                    _authenticationProvider.ValidateUserAccess((int)paymentmethod.UserId);
                }
                try
                {      
                        await _context.Execute(async () =>
                        {
                            isSuccess = await _context.UserPaymentMethods.Delete(paymentmethod);
                        });
                   
                    
                       responseText = isSuccess ? "Account deleted" : "Unable to process. Please try later.";

                    return new ResponseModel { Success = true, Message = responseText };
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                    return new ResponseModel { Success = false, Message = "Unable to process. Please try later." };
                }
            }
            else
            {
                return new ResponseModel { Success = false, Message = "Incorrect payment method Id" };
            }
        }
      
    }
}
