﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Commands.DeleteACHBankDetails
{
    public class DeleteACHBankDetailsValidator : AbstractValidator<DeleteACHBankDetailsCommand>
    {
        public DeleteACHBankDetailsValidator()
        {
            RuleFor(x => x.UserPaymentMethodId).GreaterThan(0)
                .WithMessage("UserPaymentMethodId is required");
        }
    }
}
