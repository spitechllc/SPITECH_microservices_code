﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Commands.SaveACHDetails
{
    public class SaveACHDetailsCommand : IRequest<ResponseModel>
    {
        public int UserPaymentMethodId { get; set; }
        public int UserId { get; set; }
    }
}
