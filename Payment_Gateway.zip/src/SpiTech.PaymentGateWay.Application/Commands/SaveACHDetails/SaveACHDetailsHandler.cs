﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.PaymentGateWay.Application.Queries.GetPaymentGatewayConfig;
using SpiTech.PaymentGateWay.Application.Services.Interfaces;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Enums;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Commands.SaveACHDetails
{
    public class SaveACHDetailsHandler : IRequestHandler<SaveACHDetailsCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<SaveACHDetailsHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IMediator _mediator;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly INmiService nmiService;
        private readonly EncryptionDecryptionKey encryptionDecryptionKey;

        public SaveACHDetailsHandler(IUnitOfWork context,
                                    ILogger<SaveACHDetailsHandler> logger,
                                    IMapper mapper,
                                    IEventDispatcher eventDispatcher,
                                    INmiService nmiService,
                                    IMediator mediator, IUserAuthenticationProvider userAuthenticationProvider,
         EncryptionDecryptionKey encryptionDecryptionKey)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _eventDispatcher = eventDispatcher;
            this.nmiService = nmiService;
            _mediator = mediator;
            this.userAuthenticationProvider = userAuthenticationProvider;
            this.encryptionDecryptionKey = encryptionDecryptionKey;
        }

        public async Task<ResponseModel> Handle(SaveACHDetailsCommand command, CancellationToken cancellationToken)
        {

                    return new ResponseModel() { Success = true, Message = "Success" };
           
        }


        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ApplicationCore.Helpers.IPAddressHelper.GetIPAddress()
            });
        }

    }
}
