﻿using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.PaymentGateWay.Application.Repositories;

namespace SpiTech.PaymentGateWay.Application.UnitOfWorks
{
    public interface IUnitOfWork : IBaseUnitOfWork
    {
        IUserPaymentMethodRepository UserPaymentMethods { get; }
        IPaymentMethodRepository PaymentMethods { get; }
        IPreAuthPaymentRepository PreAuthPayments { get; }
        IPaymentRepository Payments { get; }
        IStorePaymentMethodConfigrationRepository StorePaymentMethodConfigrations { get; }
        IPaymentGatewayConfigRepository PaymentGatewayConfigs { get; }
        IDwollaCustomerRepository DwollaCustomers { get; }
        IStoreConfigRepository StoreConfigs { get; }
        IWebhooksCreditCardDetailsRepository WebhooksCreditCardDetails { get; }
        IWebHookDetailRepository WebHookDetails { get; }
        IUserAchPaymentRepository UserAchPayments { get; }
        IUserAchPaymentDetailRepository UserAchPaymentDetails { get; }
        INmiTransactionRepository NmiTransactions { get; }
        INmiTransactionFileRepository NmiTransactionFiles { get; }
        ISaleAgentConfigRepository SaleAgentConfigs { get; }
        INmiTransactionDetailsRepository NmiTransactionDetails { get; }
        INmiTransactionDetailsActionRepository NmiTransactionDetailsActions { get; }
        IResellerConfigRepository ResellerConfigs { get; }
    }
}
