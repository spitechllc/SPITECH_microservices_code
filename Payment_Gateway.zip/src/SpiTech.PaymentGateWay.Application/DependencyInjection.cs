﻿using FluentValidation;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.ApplicationCore.AppSettingsConfigLoader;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.ApplicationCore.Nacha;
using SpiTech.ApplicationCore.ServiceCollection;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.EventBus.DomainEvents.Events.Store;
using SpiTech.EventBus.DomainEvents.ServiceCollection;
using SpiTech.PaymentGateWay.Application.EventConsumers;
using SpiTech.PaymentGateWay.Application.Services;
using SpiTech.PaymentGateWay.Application.Services.Interfaces;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Mappers;
using System.Reflection;

namespace SpiTech.PaymentGateWay.Application
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddTransient<EncryptionDecryptionHelper>();
            services.AddConfig<EncryptionDecryptionKey>(configuration);
            services.AddConfig<PlaidGatewayConfigs>(configuration);
            services.AddConfig<DwollaGatewayConfigs>(configuration);
            services.AddConfig<NMIGatewayConfigs>(configuration);
            services.AddConfig<NMIMerchantGatewayConfigs>(configuration);
            services.AddConfig<NMIPowerBIGatewayConfigs>(configuration);
            services.AddConfig<AppSetting>(configuration);

            services.AddHostedService<AuroraGcsJobService>();
            services.AddTransient<IPaymentReconcile, PaymentReconcile>();
            services.AddHostedService<PaymentReconcileBackGroundService>();

            services
                .AddMediatR(Assembly.GetExecutingAssembly()).AddAutoMapper(typeof(PaymentMethodProfile))
                .AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());

            services.AddScoped<INmiService, NmiService>();
            services.AddScoped<INmiMerchantService, NmiMerchantService>();
            services.AddScoped<INmiTransactionService, NmiTransactionService>();

            services.AddScoped<IPlaidService, PlaidService>();

            // MassTransit-RabbitMQ Configuration
            services.RegisterMessageQueue(configuration, config =>
            {
                config.AddConsumer<StoreEventConsumer>();
                config.AddConsumer<MppaPaymentProcessEventConsumer>();
            }, (ctx, cfg) =>
            {
                cfg.ConfigurePublishEvent<PaymentMethodAddedEvent>();
                cfg.ConfigurePublishEvent<PaymentMethodRemovedEvent>();
                cfg.ConfigurePublishEvent<PaymentStatusEvent>();
                cfg.ConfigurePublishEvent<PaymentFailedEvent>();
                cfg.ConfigurePublishEvent<PaymentFailureSupportTeamEvent>();
                cfg.ConfigurePublishEvent<UserActivityLogEvent>();
                cfg.BindConsumer<MppaPaymentProcessEvent, MppaPaymentProcessEventConsumer>(ctx, EventBusConstants.PaymentService);
                cfg.BindConsumer<StoreEvent, StoreEventConsumer>(ctx, EventBusConstants.PaymentService);
            });

            return services;
        }
    }
}
