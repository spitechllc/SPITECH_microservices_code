﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.PaymentGateWay.Application.Commands.ProcessPayment;
using System;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.EventConsumers
{
    public class MppaPaymentProcessEventConsumer : IConsumer<MppaPaymentProcessEvent>
    {
        private readonly IMediator mediator;
        private readonly ILogger<MppaPaymentProcessEventConsumer> logger;
        private readonly IEventDispatcher eventDispatcher;

        public MppaPaymentProcessEventConsumer(IMediator mediator,
            ILogger<MppaPaymentProcessEventConsumer> logger,
            IEventDispatcher eventDispatcher)
        {
            this.mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.eventDispatcher = eventDispatcher;
        }

        public async Task Consume(ConsumeContext<MppaPaymentProcessEvent> context)
        {
            logger.TraceEnterMethod(nameof(Consume), context);

            ProcessPaymentCommand model = new()
            {
                TransactionId = context.Message.TransactionId,
                UserId = context.Message.UserId,
                Amount = context.Message.Amount,
                PaymentDescription = context.Message.PaymentDescription,
                PreAuthConfirmationNo = context.Message.PreAuthConfirmationNo,
            };

            ApplicationCore.Domain.Models.ResponseModel<Domain.Models.PaymentResponseModel> response = await mediator.Send(model);

            logger.Info($"MppaPaymentProcessEvent consumed successfully. UserId : {context.Message.UserId} - result:{response.Success}");
        }
    }
}
