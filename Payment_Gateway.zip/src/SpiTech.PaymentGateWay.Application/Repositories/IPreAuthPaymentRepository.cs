﻿using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.FilterOptions;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Repositories
{
    public interface IPreAuthPaymentRepository : IRepository<PreAuthPayment>
    {
        Task<IEnumerable<PreAuthPaymentModel>> GetPaymentHistoryByFilter(PaymentFilter filter,
            Paginable paginable, Sortable sortable);

        Task<PreAuthPaymentModel> GetByConfirmationNumber(string preAuthConfirmationNo);

        Task Update(int storeId, string siteId, string storeName);
    }
}
