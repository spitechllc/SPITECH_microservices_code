﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Repositories
{
    public interface INmiTransactionRepository : IRepository<NmiTransaction>
    {
        Task<bool> BulkUpdate(int nmiTransactionFileId, IEnumerable<NmiTransactionModel> nmiTransactions);
    }
}
