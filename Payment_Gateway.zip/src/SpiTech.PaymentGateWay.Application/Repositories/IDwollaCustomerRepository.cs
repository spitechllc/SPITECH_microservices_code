﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Repositories
{
    public interface IDwollaCustomerRepository : IRepository<DwollaCustomer>
    {
        Task<DwollaCustomer> GetById(int UserId, int StoreId);
    }
}
