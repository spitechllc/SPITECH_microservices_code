﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;

namespace SpiTech.PaymentGateWay.Application.Repositories
{
    public interface IUserAchPaymentDetailRepository : IRepository<UserAchPaymentDetail>
    {
    }
}
