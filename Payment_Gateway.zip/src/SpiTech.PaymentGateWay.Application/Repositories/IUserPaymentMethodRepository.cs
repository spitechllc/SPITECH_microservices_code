﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Repositories
{
    public interface IUserPaymentMethodRepository : IRepository<UserPaymentMethod>
    {
        Task<List<UserPaymentMethod>> GetByUserId(int userid, int paymentmethodid);
        Task<UserPaymentMethod> GetDefaultByUserId(int userid);
        Task<int> SetDefaultPaymentMethod(int userPaymentMethodId, int userid);
        Task<bool> UpdateNickName(int userPaymentMethodId, string nickName);
        Task<bool> InActivePaymentMethod(int userPaymentMethodId, bool isRemoveFromSource);
        Task<int> GetPaymentMethodCount(int userid);
        Task<UserPaymentMethod> GetDuplicateAccount(string accountNo, string routingNo, string accountType);
        Task<List<UserPaymentMethod>> GetAllFraudAccount(int userPaymentMethodId);
		Task<List<UserPaymentMethodModel>> Get(int[] userPaymentMethodIds);
        Task<List<UserWithPaymentMethodModel>> GetAllUserPaymentMethod();
        Task<List<UserPaymentMethod>> GetAllMopUser();
    }
}
