﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetDefaultPaymentMethodByUserId
{
    public class GetDefaultUserPaymentMethodByUserIdHandler :
        IRequestHandler<GetDefaultUserPaymentMethodByUserIdQuery, UserPaymentMethodModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<GetDefaultUserPaymentMethodByUserIdHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly EncryptionDecryptionKey encryptionDecryptionKey;

        public GetDefaultUserPaymentMethodByUserIdHandler(
                                             IUnitOfWork context,
                                             ILogger<GetDefaultUserPaymentMethodByUserIdHandler> logger,
                                             IMapper mapper, 
                                             IUserAuthenticationProvider userAuthenticationProvider, 
                                             EncryptionDecryptionKey encryptionDecryptionKey)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
            this.encryptionDecryptionKey = encryptionDecryptionKey;
        }

        public async Task<UserPaymentMethodModel> Handle(GetDefaultUserPaymentMethodByUserIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            this.userAuthenticationProvider.ValidateUserAccess(request.UserId);
            UserPaymentMethodModel result = _mapper.Map<UserPaymentMethodModel>(await _context.UserPaymentMethods.GetDefaultByUserId(request.UserId));

            if (result != null && !string.IsNullOrWhiteSpace(result.AccountNumber))
            {
                result.AccountNumber = EncryptionDecryptionHelper.Decrypt(result.AccountNumber, encryptionDecryptionKey.EncryptDecryptKey);
                result.AccountNumber = result.AccountNumber.Substring(result.AccountNumber.Length - 4).PadLeft(result.AccountNumber.Length, '*');
            }

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
