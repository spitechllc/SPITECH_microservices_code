﻿using MediatR;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Queries.GetDefaultPaymentMethodByUserId
{
    public class GetDefaultUserPaymentMethodByUserIdQuery : IRequest<UserPaymentMethodModel>
    {
        public int UserId { get; set; }
    }
}
