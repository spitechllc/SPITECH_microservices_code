﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetPaymentGatewayConfig
{
    public class GetPaymentGatewayConfigHandler : IRequestHandler<GetPaymentGatewayConfigQuery, ResponseList<PaymentGatewayConfig>>
    {
        private readonly ILogger<GetPaymentGatewayConfigHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        public GetPaymentGatewayConfigHandler(
                                    ILogger<GetPaymentGatewayConfigHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper)
        {
            _logger = logger;
            _context = context;
            _mapper = mapper;
        }

        public async Task<ResponseList<PaymentGatewayConfig>> Handle(GetPaymentGatewayConfigQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            System.Collections.Generic.IEnumerable<PaymentGatewayConfig> result = await _context.PaymentGatewayConfigs.GetAll();

            _logger.TraceExitMethod(nameof(Handle), result);
            return new ResponseList<PaymentGatewayConfig> { Data = result };
        }
    }
}
