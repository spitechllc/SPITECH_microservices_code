﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Entities;

namespace SpiTech.PaymentGateWay.Application.Queries.GetPaymentGatewayConfig
{
    public class GetPaymentGatewayConfigQuery : IRequest<ResponseList<PaymentGatewayConfig>>
    {
    }
}
