﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetPaymentByFilter
{
    public class GetPaymentByFilterHandler : IRequestHandler<GetPaymentByFilterQuery, PaginatedList<PaymentFilterModel>>
    {
        private readonly ILogger<GetPaymentByFilterHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetPaymentByFilterHandler(
                                    ILogger<GetPaymentByFilterHandler> logger,
                                    IUnitOfWork context, IUserAuthenticationProvider userAuthenticationProvider
                                    )
        {
            _logger = logger;
            _context = context;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<PaginatedList<PaymentFilterModel>> Handle(GetPaymentByFilterQuery request, CancellationToken cancellationToken)
        {
            if (request.filter.UserId > 0)
            {
                this.userAuthenticationProvider.ValidateUserAccess(request.filter.UserId);
            }

            System.Collections.Generic.List<PaymentFilterModel> list = await _context.Payments.GetByfilter(request.filter, request.sortable);

            int totalcount = 0;

            if (list != null && list.Count > 0)
            {
                totalcount = list.Select(x => x.TotalRecord).FirstOrDefault();
            }
            return new PaginatedList<PaymentFilterModel>
            {
                Data = list,
                PageIndex = request.filter.PageIndex.HasValue ? request.filter.PageIndex.Value : 0,
                PageSize = request.filter.PageSize.HasValue ? request.filter.PageSize.Value : 0,
                TotalCount = totalcount
            };
        }
    }
}
