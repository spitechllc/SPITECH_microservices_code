﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.PaymentGateWay.Domain.FilterOptions;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Queries.GetPaymentByFilter
{
    public class GetPaymentByFilterQuery : IRequest<PaginatedList<PaymentFilterModel>>
    {
        public PaymentFilter filter { get; set; }
        public Sortable sortable { get; set; }
    }
}
