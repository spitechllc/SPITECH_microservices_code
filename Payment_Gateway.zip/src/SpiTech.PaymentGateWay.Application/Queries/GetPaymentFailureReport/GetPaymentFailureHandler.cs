﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetPaymentFailureReport
{
    public class GetPaymentFailureHandler : IRequestHandler<GetPaymentFailureQuery, PaginatedList<PaymentReportModel>>
    {
        private readonly IMediator _mediater;
        private readonly ILogger<GetPaymentFailureHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetPaymentFailureHandler(IMediator mediater,
                                    ILogger<GetPaymentFailureHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _mediater = mediater;
            _logger = logger;
            _context = context;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<PaginatedList<PaymentReportModel>> Handle(GetPaymentFailureQuery request, CancellationToken cancellationToken)
        {
            if (request.filter.UserId > 0)
            {
                this.userAuthenticationProvider.ValidateUserAccess(request.filter.UserId);
            }

            System.Collections.Generic.List<PaymentReportModel> PaymentList = await _context.Payments.GetFailedPaymentByFilter(request.filter, request.sortable);
            int TotalRecord = 0;

            TotalRecord = PaymentList.Select(s => s.TotalRecord).FirstOrDefault();

            _logger.TraceExitMethod(nameof(Handle), request);
            return await Task.FromResult(new PaginatedList<PaymentReportModel>
            {
                Data = PaymentList.ToList(),
                TotalCount = TotalRecord,
                PageSize = request.filter.PageSize.HasValue ? request.filter.PageSize.Value : 0,
                PageIndex = request.filter.PageIndex.HasValue ? request.filter.PageIndex.Value : 0
            });
        }
    }
}
