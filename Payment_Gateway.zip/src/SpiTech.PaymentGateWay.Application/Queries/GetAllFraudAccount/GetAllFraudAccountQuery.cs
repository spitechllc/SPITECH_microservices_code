﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Queries.GetAllFraudAccount
{
    public class GetAllFraudAccountQuery : IRequest<ResponseList<UserPaymentMethodModel>>
    {
        public int? UserPaymentMethodId { get; set; }
    }
}
