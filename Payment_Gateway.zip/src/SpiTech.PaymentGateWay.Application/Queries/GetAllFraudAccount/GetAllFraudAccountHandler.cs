﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetAllFraudAccount
{
    public class GetAllFraudAccountHandler : IRequestHandler<GetAllFraudAccountQuery, ResponseList<UserPaymentMethodModel>>
    {

        private readonly IMediator _mediater;
        private readonly ILogger<GetAllFraudAccountHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        public GetAllFraudAccountHandler(IMediator mediater,
                                    ILogger<GetAllFraudAccountHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper
                                    )
        {
            _mediater = mediater;                                                                                                
            _logger = logger;
            _context = context;
            _mapper = mapper;
        }

        public async Task<ResponseList<UserPaymentMethodModel>> Handle(GetAllFraudAccountQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<UserPaymentMethodModel> result = _mapper.Map<IEnumerable<UserPaymentMethodModel>>(
               await _context.UserPaymentMethods.GetAllFraudAccount(request.UserPaymentMethodId??0));
            _logger.TraceExitMethod(nameof(Handle), result);
            return new ResponseList<UserPaymentMethodModel> { Data = result };
        }
    }
}