﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Queries.GetUserPaymentMethodByUserId
{
    public class GetUserPaymentMethodByUserIdQuery : IRequest<ResponseList<UserPaymentMethodModel>>
    {
        public int Userid { get; set; }
        public int PaymentMethodId { get; set; }
    }
}
