﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetUserPaymentMethodByUserId
{
    public class GetUserPaymentMethodByUserIdHandler : IRequestHandler<GetUserPaymentMethodByUserIdQuery,
        ResponseList<UserPaymentMethodModel>>
    {
        private readonly IMediator _mediater;
        private readonly ILogger<GetUserPaymentMethodByUserIdHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly EncryptionDecryptionKey encryptionDecryptionKey;

        public GetUserPaymentMethodByUserIdHandler(IMediator mediater,
                                    ILogger<GetUserPaymentMethodByUserIdHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper
                                    , IUserAuthenticationProvider userAuthenticationProvider, EncryptionDecryptionKey encryptionDecryptionKey)
        {
            _mediater = mediater;
            _logger = logger;
            _context = context;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
            this.encryptionDecryptionKey = encryptionDecryptionKey;
        }

        public async Task<ResponseList<UserPaymentMethodModel>> Handle(GetUserPaymentMethodByUserIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            this.userAuthenticationProvider.ValidateUserAccess(request.Userid);

            IEnumerable<UserPaymentMethodModel> result = _mapper.Map<IEnumerable<UserPaymentMethodModel>>(await _context.UserPaymentMethods.GetByUserId(request.Userid, request.PaymentMethodId));
            if (result != null)
            {
                foreach (var item in result)
                {
                    if (item != null && !string.IsNullOrWhiteSpace(item.AccountNumber))
                    {
                        item.AccountNumber = EncryptionDecryptionHelper.Decrypt(item.AccountNumber, encryptionDecryptionKey.EncryptDecryptKey);
                        item.AccountNumber = item.AccountNumber.Substring(item.AccountNumber.Length - 4).PadLeft(item.AccountNumber.Length, '*');
                    }
                }
            }
            _logger.TraceExitMethod(nameof(Handle), result);
            return new ResponseList<UserPaymentMethodModel> { Data = result };
        }
    }
}
