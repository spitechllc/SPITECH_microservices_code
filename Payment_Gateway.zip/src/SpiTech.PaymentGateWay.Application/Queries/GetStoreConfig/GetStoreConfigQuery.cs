﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Entities;

namespace SpiTech.PaymentGateWay.Application.Queries.GetStoreConfig
{
    public class GetStoreConfigQuery : IRequest<ResponseModel<StoreConfig>>
    {
        public int StoreId { get; set; }
    }
}
