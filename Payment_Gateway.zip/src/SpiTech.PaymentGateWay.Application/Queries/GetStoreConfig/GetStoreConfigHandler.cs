﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetStoreConfig
{
    public class GetStoreConfigHandler : IRequestHandler<GetStoreConfigQuery, ResponseModel<StoreConfig>>
    {

        private readonly IMediator _mediater;
        private readonly ILogger<GetStoreConfigHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly EncryptionDecryptionKey encryptionDecryptionKey;
        public GetStoreConfigHandler(IMediator mediater,
                                    ILogger<GetStoreConfigHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper,
                                    EncryptionDecryptionKey encryptionDecryptionKey
                                    )
        {
            _mediater = mediater;
            _logger = logger;
            _context = context;
            _mapper = mapper;
            this.encryptionDecryptionKey = encryptionDecryptionKey;
        }

        public async Task<ResponseModel<StoreConfig>> Handle(GetStoreConfigQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            StoreConfig result = await _context.StoreConfigs.Get(request.StoreId);

            if (result != null && !string.IsNullOrWhiteSpace(result.AccountNo))
            {
                result.AccountNo = EncryptionDecryptionHelper.Decrypt(result.AccountNo, encryptionDecryptionKey.EncryptDecryptKey);
                result.AccountNo = result.AccountNo.Substring(result.AccountNo.Length - 4).PadLeft(result.AccountNo.Length, '*');
            }

            _logger.TraceExitMethod(nameof(Handle), result);
            return new ResponseModel<StoreConfig> { Data = result, Success = result != null };
        }
    }
}
