﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Queries.GetStoreConfig
{
    public class GetStoreConfigQueryValidator : AbstractValidator<GetStoreConfigQuery>
    {
        public GetStoreConfigQueryValidator()
        {
            RuleFor(x => x.StoreId).GreaterThan(0);
        }
    }
}
