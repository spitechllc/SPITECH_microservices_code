﻿using AutoMapper;
using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.Services.Interfaces;
using SpiTech.PaymentGateWay.Domain;
using SpiTech.PaymentGateWay.Domain.Models;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using Formatting = Newtonsoft.Json.Formatting;

namespace SpiTech.PaymentGateWay.Application.Commands.GetTransactionDetailsNMI
{
    public class GetTransactionDetailsNMIHandler : IRequestHandler<GetTransactionDetailsNMICommand, ResponseModel<string>>
    {
        private readonly INmiTransactionService nmiService;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly ILogger<GetTransactionDetailsNMIHandler> _logger;

        private readonly ITransactionServiceClient _transactionapiclient;

        public GetTransactionDetailsNMIHandler(INmiTransactionService nmiService,
            IMediator mediator, IMapper mapper, ILogger<GetTransactionDetailsNMIHandler> logger, ITransactionServiceClient transactionapiclient)
        {
            this.nmiService = nmiService;
            _mediator = mediator;
            _mapper = mapper;
            _logger = logger;
            _transactionapiclient = transactionapiclient;
        }

        public async Task<ResponseModel<string>> Handle(GetTransactionDetailsNMICommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            ResponseModel<string> responseModel = new() { Success = false };

            string query = "";

            if (command.Startdate.HasValue)
            {
                DateTime sDate = (DateTime)command.Startdate;
                 query = @$"start_date=" + sDate.ToString("YYYYMMDDhhmmss");
            }
            if (command.Enddate.HasValue)
            {
                DateTime eDate = (DateTime)command.Enddate;
                query = @$"end_date=" + eDate.ToString("YYYYMMDDhhmmss");
            }
            if (command.TransactionId != null)
            {
                query = @$"transaction_id=" + command.TransactionId;
            }

            try
            {
                HttpResponseMessage response = await nmiService.SendRequest(HttpMethod.Get, "", null, null, query);
                NMITransactionsDetailsModel objModel = new();
                if (response.IsSuccessStatusCode)
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    System.Collections.Specialized.NameValueCollection result = responseContent.ParseQueryString();
                    string resContent = responseContent.Substring(39, responseContent.Length - 39);
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(resContent);
                    var json = JsonConvert.SerializeXmlNode(xmlDoc, Formatting.None, true);
                    objModel = JsonConvert.DeserializeObject<NMITransactionsDetailsModel>(json);
                   

                    string jsonXml = JsonConvert.SerializeObject(objModel);
                    XmlDocument xmlContent = JsonConvert.DeserializeXmlNode("{\"nm_response \":" + jsonXml + "}", "nm_response");
                 

                    responseModel = new ResponseModel<string>
                    {
                        Message = "Success",
                        Success = true,
                        Data = xmlContent.InnerXml.ToString()
                    };

                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }

            return responseModel;
        }
    }
}
