﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models;
using System;
using System.Xml;

namespace SpiTech.PaymentGateWay.Application.Commands.GetTransactionDetailsNMI
{
    public class GetTransactionDetailsNMICommand : IRequest<ResponseModel<string>>
    {
        public int?[] TransactionId { get; set; }
        public DateTime? Startdate { get; set; }
        public DateTime? Enddate { get; set; }
    }
}
