﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Queries.GetSaleAgentConfigs
{
    public class GetSaleAgentConfigsQuery : IRequest<ResponseList<SaleAgentConfigModel>>
    {
        public int[] SaleAgentIds { get; set; }
    }
}
