﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Queries.GetSaleAgentConfigs
{
    public class GetSaleAgentConfigsQueryValidator : AbstractValidator<GetSaleAgentConfigsQuery>
    {
        public GetSaleAgentConfigsQueryValidator()
        {
            RuleFor(x => x.SaleAgentIds).NotNull().NotEmpty();
        }
    }
}
