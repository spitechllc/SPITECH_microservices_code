﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Entities;

namespace SpiTech.PaymentGateWay.Application.Queries.GetDwollaCustomer
{
    public class GetDwollaCustomerQuery : IRequest<ResponseModel<DwollaCustomer>>
    {
        public int UserId { get; set; }
        public int StoreId { get; set; }
    }
}
