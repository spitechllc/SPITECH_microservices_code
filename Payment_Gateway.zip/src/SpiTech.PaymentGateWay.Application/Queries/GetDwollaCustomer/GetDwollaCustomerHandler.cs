﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.Queries.GetPaymentGatewayConfig;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Enums;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetDwollaCustomer
{
    public class GetDwollaCustomerHandler : IRequestHandler<GetDwollaCustomerQuery, ResponseModel<DwollaCustomer>>
    {
        private readonly IMediator _mediator;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly ILogger<GetDwollaCustomerHandler> _logger;
        private readonly IUnitOfWork _context;

        public GetDwollaCustomerHandler(
                                    ILogger<GetDwollaCustomerHandler> logger,
                                    IUnitOfWork context,
                                    IMediator mediator, IUserAuthenticationProvider userAuthenticationProvider
                                    )
        {
            _logger = logger;
            _context = context;
            _mediator = mediator;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<ResponseModel<DwollaCustomer>> Handle(GetDwollaCustomerQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            this.userAuthenticationProvider.ValidateUserAccess(request.UserId);
            ResponseModel<DwollaCustomer> response = new();
            Domain.Entities.PaymentGatewayConfig dwollaPaymentGatewayConfig = (await _mediator.Send(new GetPaymentGatewayConfigQuery { })).Data.FirstOrDefault(t => t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithNMI);

            if(dwollaPaymentGatewayConfig.IsActive)
            {
                DwollaCustomer users = new DwollaCustomer();
                users.DwollaCutomerId = "1";
                users.IsActive = true;
                response.Success = true;
                response.Data = users;
            }


            return response;
           
        }
    }
}