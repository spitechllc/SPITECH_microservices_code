﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Queries.GetMasterStoreConfig
{
    public class GetMasterStoreConfigQueryValidator : AbstractValidator<GetMasterStoreConfigQuery>
    {
        public GetMasterStoreConfigQueryValidator()
        {
        }
    }
}
