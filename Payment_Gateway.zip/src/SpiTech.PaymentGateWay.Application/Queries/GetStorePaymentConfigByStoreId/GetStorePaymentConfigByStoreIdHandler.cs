﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetStorePaymentConfigByStoreId
{
    public class GetStorePaymentConfigByStoreIdHandler :
        IRequestHandler<GetStorePaymentConfigByStoreIdQuery, ResponseList<StorePaymentMethodConfigrationModel>>
    {


        private readonly ILogger<GetStorePaymentConfigByStoreIdHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly EncryptionDecryptionKey encryptionDecryptionKey;

        public GetStorePaymentConfigByStoreIdHandler(
                                    ILogger<GetStorePaymentConfigByStoreIdHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper,
                                    EncryptionDecryptionKey encryptionDecryptionKey
                                    )
        {
            _mapper = mapper;
            _logger = logger;
            _context = context;
            this.encryptionDecryptionKey = encryptionDecryptionKey;
        }
        public async Task<ResponseList<StorePaymentMethodConfigrationModel>> Handle(
            GetStorePaymentConfigByStoreIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<StorePaymentMethodConfigrationModel> result = _mapper.Map<IEnumerable<StorePaymentMethodConfigrationModel>>
                 (await _context.StorePaymentMethodConfigrations.GetByFilterByStoreId(request.StoreId));
            if (result != null)
            {
                foreach (var item in result)
                {
                    if (item != null && !string.IsNullOrWhiteSpace(item.AccountNumber))
                    {
                        item.AccountNumber = EncryptionDecryptionHelper.Decrypt(item.AccountNumber, encryptionDecryptionKey.EncryptDecryptKey);
                        item.AccountNumber = item.AccountNumber.Substring(item.AccountNumber.Length - 4).PadLeft(item.AccountNumber.Length, '*');
                    }
                }
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return new ResponseList<StorePaymentMethodConfigrationModel> { Data = result };
        }
    }
}
