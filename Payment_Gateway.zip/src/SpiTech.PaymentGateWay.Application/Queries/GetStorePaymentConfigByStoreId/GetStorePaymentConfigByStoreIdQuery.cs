﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Queries.GetStorePaymentConfigByStoreId
{
    public class GetStorePaymentConfigByStoreIdQuery :
        IRequest<ResponseList<StorePaymentMethodConfigrationModel>>
    {
        public int StoreId { get; set; }
    }
}
