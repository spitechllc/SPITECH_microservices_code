﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetAllUserMOP
{
    public class GetAllUserMOPQuery : IRequest<ResponseList<UserPaymentMethod>>
    {
    }
}
