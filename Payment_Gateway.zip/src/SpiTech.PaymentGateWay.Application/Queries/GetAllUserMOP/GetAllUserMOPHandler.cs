﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.Queries.GetAllUserWithPaymentMethod;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetAllUserMOP
{
    public class GetAllUserMOPHandler : IRequestHandler<GetAllUserMOPQuery, ResponseList<UserPaymentMethod>>
    {

        private readonly IMediator _mediater;
        private readonly ILogger<GetAllUserMOPHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        public GetAllUserMOPHandler(IMediator mediater,
                                    ILogger<GetAllUserMOPHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper
                                    )
        {
            _mediater = mediater;
            _logger = logger;
            _context = context;
            _mapper = mapper;
        }

        public async Task<ResponseList<UserPaymentMethod>> Handle(GetAllUserMOPQuery request, CancellationToken cancellationToken)
        {
            _logger.Warn($"payment service GetAllUserMOPHandler step 1");
            _logger.TraceEnterMethod(nameof(Handle), request);
            IEnumerable<UserPaymentMethod> result = _mapper.Map<IEnumerable<UserPaymentMethod>>(await _context.UserPaymentMethods.GetAllMopUser());
            _logger.TraceExitMethod(nameof(Handle), result);
            _logger.Warn($"payment service GetAllUserMOPHandler result step 2:{result.Count()}");
            return new ResponseList<UserPaymentMethod> { Data = result };
        }
    }
}
