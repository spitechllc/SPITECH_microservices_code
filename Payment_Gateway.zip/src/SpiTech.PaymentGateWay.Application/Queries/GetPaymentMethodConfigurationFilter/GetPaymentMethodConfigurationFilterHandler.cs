﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetPaymentMethodConfigurationFilter
{
    public class GetPaymentMethodConfigurationFilterHandler :
        IRequestHandler<GetPaymentMethodConfigurationFilterQuery, StorePaymentMethodConfigrationModel>
    {
        private readonly ILogger<GetPaymentMethodConfigurationFilterHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly EncryptionDecryptionKey encryptionDecryptionKey;

        public GetPaymentMethodConfigurationFilterHandler(
                                    ILogger<GetPaymentMethodConfigurationFilterHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper,
                                    EncryptionDecryptionKey encryptionDecryptionKey
                                    )
        {
            _mapper = mapper;
            _logger = logger;
            _context = context;
            this.encryptionDecryptionKey = encryptionDecryptionKey;
        }
        public async Task<StorePaymentMethodConfigrationModel> Handle(
            GetPaymentMethodConfigurationFilterQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            StorePaymentMethodConfigrationModel result = _mapper.Map<StorePaymentMethodConfigrationModel>
                (await _context.StorePaymentMethodConfigrations.GetByFilter(request.StoreId,
                request.PaymentGatewayConfigId));

            if (result != null && !string.IsNullOrWhiteSpace(result.AccountNumber))
            {
                result.AccountNumber = EncryptionDecryptionHelper.Decrypt(result.AccountNumber, encryptionDecryptionKey.EncryptDecryptKey);
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
