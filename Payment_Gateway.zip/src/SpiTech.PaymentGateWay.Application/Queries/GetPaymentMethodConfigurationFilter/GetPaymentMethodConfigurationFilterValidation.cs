﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Queries.GetPaymentMethodConfigurationFilter
{
    public class GetPaymentMethodConfigurationFilterValidation :
        AbstractValidator<GetPaymentMethodConfigurationFilterQuery>
    {
        public GetPaymentMethodConfigurationFilterValidation()
        {
            RuleFor(x => x.StoreId).GreaterThan(0).WithMessage("StoreId must be greater than 0");
            RuleFor(x => x.PaymentGatewayConfigId).GreaterThan(0).WithMessage("PaymentGatewayConfigId must be greater than 0");
        }
    }
}
