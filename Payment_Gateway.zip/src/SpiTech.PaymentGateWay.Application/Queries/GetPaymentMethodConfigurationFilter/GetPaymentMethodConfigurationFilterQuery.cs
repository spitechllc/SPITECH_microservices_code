﻿using MediatR;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Queries.GetPaymentMethodConfigurationFilter
{
    public class GetPaymentMethodConfigurationFilterQuery : IRequest<StorePaymentMethodConfigrationModel>
    {
        public int StoreId { get; set; }
        public int PaymentGatewayConfigId { get; set; }
    }
}
