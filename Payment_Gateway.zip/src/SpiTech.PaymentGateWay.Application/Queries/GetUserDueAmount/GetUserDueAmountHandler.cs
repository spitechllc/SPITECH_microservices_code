﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetUserDueAmount
{
    public class GetUserDueAmountHandler : IRequestHandler<GetUserDueAmountQuery, decimal>
    {
        private readonly ILogger<GetUserDueAmountHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetUserDueAmountHandler(
                                    ILogger<GetUserDueAmountHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper
                                    , IUserAuthenticationProvider userAuthenticationProvider)
        {
            _logger = logger;
            _context = context;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<decimal> Handle(GetUserDueAmountQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            this.userAuthenticationProvider.ValidateUserAccess(request.UserId);

            decimal result = await _context.Payments.GetUserDueAmount(request.UserId);

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
