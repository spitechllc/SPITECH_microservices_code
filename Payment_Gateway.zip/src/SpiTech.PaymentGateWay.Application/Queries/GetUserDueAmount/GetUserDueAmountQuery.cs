﻿using MediatR;

namespace SpiTech.PaymentGateWay.Application.Queries.GetUserDueAmount
{
    public class GetUserDueAmountQuery : IRequest<decimal>
    {
        public int UserId { get; set; }
    }
}
