﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Entities;

namespace SpiTech.PaymentGateWay.Application.Queries.GetResellerConfig
{
    public class GetResellerConfigQuery : IRequest<ResponseModel<ResellerConfig>>
    {
        public int ResellerId { get; set; }
    }
}
