﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetResellerConfig
{
    public class GetResellerConfigHandler : IRequestHandler<GetResellerConfigQuery, ResponseModel<ResellerConfig>>
    {

        private readonly IMediator _mediater;
        private readonly ILogger<GetResellerConfigHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly EncryptionDecryptionKey encryptionDecryptionKey;
        public GetResellerConfigHandler(IMediator mediater,
                                    ILogger<GetResellerConfigHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper,
                                    EncryptionDecryptionKey encryptionDecryptionKey
                                    )
        {
            _mediater = mediater;
            _logger = logger;
            _context = context;
            _mapper = mapper;
            this.encryptionDecryptionKey = encryptionDecryptionKey;
        }

        public async Task<ResponseModel<ResellerConfig>> Handle(GetResellerConfigQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            ResellerConfig result = await _context.ResellerConfigs.Get(request.ResellerId);

            if (result != null && !string.IsNullOrWhiteSpace(result.AccountNo))
            {
                string acc = EncryptionDecryptionHelper.Decrypt(result.AccountNo, encryptionDecryptionKey.EncryptDecryptKey);
                result.AccountNo = acc.Substring(acc.Length - 4).PadLeft(acc.Length, '*');
            }

            _logger.TraceExitMethod(nameof(Handle), result);
            return new ResponseModel<ResellerConfig> { Data = result, Success = result != null };
        }
    }
}
