﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Queries.GetResellerConfig
{
    public class GetResellerConfigQueryValidator : AbstractValidator<GetResellerConfigQuery>
    {
        public GetResellerConfigQueryValidator()
        {
            RuleFor(x => x.ResellerId).GreaterThan(0);
        }
    }
}
