﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.Service.Clients.Identity;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetUserByUserId
{
    public class GetUserByUserIdHandler : IRequestHandler<GetUserByUserIdQuery, UserModel>
    {
        private readonly ILogger<GetUserByUserIdHandler> _logger;
        private readonly IIdentityServiceClient _identityApiClient;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetUserByUserIdHandler(
                                    ILogger<GetUserByUserIdHandler> logger,
                                    IIdentityServiceClient identityApiClient
                                    , IUserAuthenticationProvider userAuthenticationProvider)
        {
            _logger = logger;
            _identityApiClient = identityApiClient;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<UserModel> Handle(GetUserByUserIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            this.userAuthenticationProvider.ValidateUserAccess(request.UserId);
            UserModelResponseModel users = await _identityApiClient.GetUserByIdAsync(request.UserId);
            return await Task.FromResult(users?.Data);
        }
    }
}