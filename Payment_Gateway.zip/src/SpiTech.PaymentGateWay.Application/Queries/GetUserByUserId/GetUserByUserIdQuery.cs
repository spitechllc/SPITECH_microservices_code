﻿using MediatR;
using SpiTech.Service.Clients.Identity;

namespace SpiTech.PaymentGateWay.Application.Queries.GetUserByUserId
{
    public class GetUserByUserIdQuery : IRequest<UserModel>
    {
        public int UserId { get; set; }
    }
}
