﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetPaymentHistoryByFilter
{
    public class GetPaymentHistoryByFilterHandler : IRequestHandler<GetPaymentHistoryByFilterQuery, PaginatedList<PreAuthPaymentModel>>
    {
        private readonly IMediator _mediater;
        private readonly ILogger<GetPaymentHistoryByFilterHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetPaymentHistoryByFilterHandler(IMediator mediater,
                                    ILogger<GetPaymentHistoryByFilterHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _mediater = mediater;
            _logger = logger;
            _context = context;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<PaginatedList<PreAuthPaymentModel>> Handle(GetPaymentHistoryByFilterQuery query, CancellationToken cancellationToken)
        {

            _logger.TraceEnterMethod(nameof(Handle), query);

            if (query.filter.UserId > 0)
            {
                this.userAuthenticationProvider.ValidateUserAccess(query.filter.UserId);
            }

            System.Collections.Generic.IEnumerable<PreAuthPaymentModel> PaymentList = await _context.PreAuthPayments.GetPaymentHistoryByFilter(query.filter, query.paginable, query.sortable);
            int TotalRecord = 0;

            TotalRecord = PaymentList.Count();

            _logger.TraceExitMethod(nameof(Handle), query);
            return await Task.FromResult(new PaginatedList<PreAuthPaymentModel>
            {
                Data = PaymentList.ToList(),
                TotalCount = TotalRecord,
                PageSize = query.paginable.Take.Value
            });
        }
    }
}
