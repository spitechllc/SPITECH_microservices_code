﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.PaymentGateWay.Domain.FilterOptions;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Queries.GetPaymentHistoryByFilter
{
    public class GetPaymentHistoryByFilterQuery : IRequest<PaginatedList<PreAuthPaymentModel>>
    {
        public PaymentFilter filter { get; set; }
        public Paginable paginable { get; set; }
        public Sortable sortable { get; set; }
    }
}
