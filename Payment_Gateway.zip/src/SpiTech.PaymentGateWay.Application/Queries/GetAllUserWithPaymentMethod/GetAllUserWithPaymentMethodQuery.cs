﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetAllUserWithPaymentMethod
{
    public class GetAllUserWithPaymentMethodQuery : IRequest<ResponseList<UserWithPaymentMethodModel>>
    {
    }
}
