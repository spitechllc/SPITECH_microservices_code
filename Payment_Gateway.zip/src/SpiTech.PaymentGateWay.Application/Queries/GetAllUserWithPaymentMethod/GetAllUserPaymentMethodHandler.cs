﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetAllUserWithPaymentMethod
{
    public class GetAllUserPaymentMethodHandler : IRequestHandler<GetAllUserWithPaymentMethodQuery, ResponseList<Domain.Models.UserWithPaymentMethodModel>>
    {

        private readonly IMediator _mediater;
        private readonly ILogger<GetAllUserPaymentMethodHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        public GetAllUserPaymentMethodHandler(IMediator mediater,
                                    ILogger<GetAllUserPaymentMethodHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper
                                    )
        {
            _mediater = mediater;
            _logger = logger;
            _context = context;
            _mapper = mapper;
        }

        public async Task<ResponseList<Domain.Models.UserWithPaymentMethodModel>> Handle(GetAllUserWithPaymentMethodQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            IEnumerable<Domain.Models.UserWithPaymentMethodModel> result = _mapper.Map<IEnumerable<Domain.Models.UserWithPaymentMethodModel>>(await _context.UserPaymentMethods.GetAllUserPaymentMethod());
            _logger.TraceExitMethod(nameof(Handle), result);
            return new ResponseList<Domain.Models.UserWithPaymentMethodModel> { Data = result };
        }
    }
}
