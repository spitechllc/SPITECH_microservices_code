﻿using MediatR;

namespace SpiTech.PaymentGateWay.Application.Queries.GetPlaidLinkToken
{
    public class GetPlaidLinkTokenQuery : IRequest<string>
    {
        public string Id { get; set; }
    }
}
