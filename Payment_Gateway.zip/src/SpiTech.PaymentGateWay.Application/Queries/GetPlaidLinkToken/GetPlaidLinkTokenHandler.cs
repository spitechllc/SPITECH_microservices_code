﻿using MediatR;
using Newtonsoft.Json;
using SpiTech.PaymentGateWay.Application.Queries.GetPaymentGatewayConfig;
using SpiTech.PaymentGateWay.Application.Services.Interfaces;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Enums;
using SpiTech.PaymentGateWay.Domain.Models.Plaid;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetPlaidLinkToken
{
    public class GetPlaidLinkTokenHandler : IRequestHandler<GetPlaidLinkTokenQuery, string>
    {
        private readonly IPlaidService plaidService;
        private readonly IMediator mediator;

        private readonly PlaidGatewayConfigs plaidGatewayConfigs;

        public GetPlaidLinkTokenHandler(IPlaidService plaidService,
            PlaidGatewayConfigs plaidGatewayConfigs, IMediator mediator)
        {
            this.plaidService = plaidService;
            this.plaidGatewayConfigs = plaidGatewayConfigs;
            this.mediator = mediator;
        }
        public async Task<string> Handle(GetPlaidLinkTokenQuery request, CancellationToken cancellationToken)
        {
            Domain.Entities.PaymentGatewayConfig plaidPaymentGatewayConfig = (await mediator.Send(new GetPaymentGatewayConfigQuery { })).Data.FirstOrDefault(t => (t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithDwolla || t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithStride || t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithNMI) && t.IsActive == true);

            PlaidGatewayConfig plaidGatewayConfig = plaidGatewayConfigs.FirstOrDefault(t => t.IsProd == plaidPaymentGatewayConfig.IsProdEnabled);

            string linktoken = "";
            var model = new
            {
                client_id = plaidGatewayConfig.ClientId,
                secret = plaidGatewayConfig.ClientSecret,
                client_name = "Papi pay Dwolla client",
                country_codes = new List<string> { "US" },
                language = "en",
                user = new { client_user_id = request.Id },
                products = new List<string> { "auth" }
            };
            string strjson = JsonConvert.SerializeObject(model);
            HttpContent content = new StringContent(strjson, Encoding.UTF8, "application/json");

            HttpResponseMessage response = await plaidService.SendRequest(HttpMethod.Post, "link/token/create",
                content, null, null);
            if (response.IsSuccessStatusCode)
            {
                string strres = await response.Content.ReadAsStringAsync();
                PlaidLinkTokenResponse token = JsonConvert.DeserializeObject<PlaidLinkTokenResponse>(strres);
                linktoken = token.link_token;
            }
            return linktoken;
        }
    }
}
