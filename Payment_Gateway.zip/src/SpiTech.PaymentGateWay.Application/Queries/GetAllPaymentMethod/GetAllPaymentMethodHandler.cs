﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetAllPaymentMethod
{
    public class GetAllPaymentMethodHandler : IRequestHandler<GetAllPaymentMethodQuery, ResponseList<PaymentMethodModel>>
    {

        private readonly IMediator _mediater;
        private readonly ILogger<GetAllPaymentMethodHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        public GetAllPaymentMethodHandler(IMediator mediater,
                                    ILogger<GetAllPaymentMethodHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper
                                    )
        {
            _mediater = mediater;
            _logger = logger;
            _context = context;
            _mapper = mapper;
        }

        public async Task<ResponseList<PaymentMethodModel>> Handle(GetAllPaymentMethodQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<PaymentMethodModel> result = _mapper.Map<IEnumerable<PaymentMethodModel>>(
               await _context.PaymentMethods.GetAll());
            _logger.TraceExitMethod(nameof(Handle), result);
            return new ResponseList<PaymentMethodModel> { Data = result };
        }
    }
}
