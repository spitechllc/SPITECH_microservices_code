﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Queries.GetAllPaymentMethod
{
    public class GetAllPaymentMethodQuery : IRequest<ResponseList<PaymentMethodModel>>
    {
    }
}
