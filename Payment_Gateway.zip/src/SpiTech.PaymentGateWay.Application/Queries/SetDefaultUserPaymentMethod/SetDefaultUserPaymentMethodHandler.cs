﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.SetDefaultUserPaymentMethod
{
    public class SetDefaultUserPaymentMethodHandler : IRequestHandler<SetDefaultUserPaymentMethodCommand, ResponseModel>
    {

        private readonly IUnitOfWork _context;
        private readonly ILogger<SetDefaultUserPaymentMethodHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider authenticationProvider;

        public SetDefaultUserPaymentMethodHandler(
                                             IUnitOfWork context,
                                             ILogger<SetDefaultUserPaymentMethodHandler> logger,
                                             IMapper mapper,
                                             IUserAuthenticationProvider authenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.authenticationProvider = authenticationProvider;
        }

        public async Task<ResponseModel> Handle(SetDefaultUserPaymentMethodCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            int result = 0;

            await _context.Execute(async () =>
            {
                result = await _context.UserPaymentMethods.SetDefaultPaymentMethod(command.UserPaymentMethodId,
                authenticationProvider.GetUserAuthentication().UserId);
            });

            _logger.TraceEnterMethod(nameof(Handle), result);

            return result > 0
                ? new ResponseModel { Success = true, Message = "Success" }
                : new ResponseModel { Success = false, Message = "Fail" };
        }
    }
}
