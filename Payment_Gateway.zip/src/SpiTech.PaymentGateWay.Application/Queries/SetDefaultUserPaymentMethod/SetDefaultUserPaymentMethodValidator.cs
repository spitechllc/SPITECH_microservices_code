﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Queries.SetDefaultUserPaymentMethod
{
    public class SetDefaultUserPaymentMethodValidator : AbstractValidator<SetDefaultUserPaymentMethodCommand>
    {
        public SetDefaultUserPaymentMethodValidator()
        {
            RuleFor(x => x.UserPaymentMethodId).GreaterThan(0).WithMessage("UserPaymentMethodId must be greater than 0");
        }
    }
}
