﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Queries.SetDefaultUserPaymentMethod
{
    public class SetDefaultUserPaymentMethodCommand : IRequest<ResponseModel>
    {
        public int UserPaymentMethodId { get; set; }
    }
}
