﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Queries.GetSaleAgentConfig
{
    public class GetSaleAgentConfigQueryValidator : AbstractValidator<GetSaleAgentConfigQuery>
    {
        public GetSaleAgentConfigQueryValidator()
        {
            RuleFor(x => x.SaleAgentId).GreaterThan(0);
        }
    }
}
