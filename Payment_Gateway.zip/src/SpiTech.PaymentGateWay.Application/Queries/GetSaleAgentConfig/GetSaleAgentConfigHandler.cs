﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetSaleAgentConfig
{
    public class GetSaleAgentConfigHandler : IRequestHandler<GetSaleAgentConfigQuery, ResponseModel<SaleAgentConfig>>
    {

        private readonly IMediator _mediater;
        private readonly ILogger<GetSaleAgentConfigHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly EncryptionDecryptionKey encryptionDecryptionKey;
        public GetSaleAgentConfigHandler(IMediator mediater,
                                    ILogger<GetSaleAgentConfigHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper,
                                    EncryptionDecryptionKey encryptionDecryptionKey
                                    )
        {
            _mediater = mediater;
            _logger = logger;
            _context = context;
            _mapper = mapper;
            this.encryptionDecryptionKey = encryptionDecryptionKey;
        }

        public async Task<ResponseModel<SaleAgentConfig>> Handle(GetSaleAgentConfigQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            SaleAgentConfig result = await _context.SaleAgentConfigs.Get(request.SaleAgentId);

            if (result != null && !string.IsNullOrWhiteSpace(result.AccountNo))
            {
                string acc = EncryptionDecryptionHelper.Decrypt(result.AccountNo, encryptionDecryptionKey.EncryptDecryptKey);
                result.AccountNo = acc.Substring(acc.Length - 4).PadLeft(acc.Length, '*');
            }

            _logger.TraceExitMethod(nameof(Handle), result);
            return new ResponseModel<SaleAgentConfig> { Data = result, Success = result != null };
        }
    }
}
