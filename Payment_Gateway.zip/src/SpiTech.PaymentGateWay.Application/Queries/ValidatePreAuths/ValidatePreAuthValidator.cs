﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Queries.ValidatePreAuths
{
    public class ValidatePreAuthValidator
        : AbstractValidator<ValidatePreAuthQuery>
    {
        public ValidatePreAuthValidator()
        {
            RuleFor(x => x.PreAuthConfirmationNo).NotNull().WithMessage("ConfirmNumber is required");
        }
    }
}
