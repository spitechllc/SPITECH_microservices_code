﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Queries.ValidatePreAuths
{
    public class ValidatePreAuthQuery : IRequest<ResponseModel<PreAuthPaymentResponseModel>>
    {
        public string PreAuthConfirmationNo { get; set; }
    }
}
