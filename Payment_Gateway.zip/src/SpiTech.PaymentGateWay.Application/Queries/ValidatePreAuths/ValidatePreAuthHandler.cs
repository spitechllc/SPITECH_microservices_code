﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.ValidatePreAuths
{
    public class ValidatePreAuthHandler :
        IRequestHandler<ValidatePreAuthQuery, ResponseModel<PreAuthPaymentResponseModel>>
    {
        private readonly IMediator _mediater;
        private readonly ILogger<ValidatePreAuthHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public ValidatePreAuthHandler(IMediator mediater,
                                    ILogger<ValidatePreAuthHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _mediater = mediater;
            _logger = logger;
            _context = context;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<ResponseModel<PreAuthPaymentResponseModel>> Handle(ValidatePreAuthQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            PreAuthPaymentResponseModel result = _mapper.Map<PreAuthPaymentResponseModel>(await _context.PreAuthPayments.GetByConfirmationNumber(request.PreAuthConfirmationNo));

            this.userAuthenticationProvider.ValidateUserAccess(result.UserId);

            _logger.TraceExitMethod(nameof(Handle), result);

            return result != null && result.Success
                ? new ResponseModel<PreAuthPaymentResponseModel> { Message = "Success", Success = true, Data = result }
                : new ResponseModel<PreAuthPaymentResponseModel> { Message = "Invalid Confirmation Number", Success = false, Data = null };
        }
    }
}
