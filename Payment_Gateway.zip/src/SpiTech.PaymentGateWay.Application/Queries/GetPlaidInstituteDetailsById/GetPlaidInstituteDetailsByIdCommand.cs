﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models.Plaid;

namespace SpiTech.PaymentGateWay.Application.Commands.GetPlaidInstituteDetailsById
{
    public class GetPlaidInstituteDetailsByIdCommand : IRequest<ResponseModel<PlaidInstitutionDetailsModel>>
    {
        public string InstitutionId { get; set; }

    }
}