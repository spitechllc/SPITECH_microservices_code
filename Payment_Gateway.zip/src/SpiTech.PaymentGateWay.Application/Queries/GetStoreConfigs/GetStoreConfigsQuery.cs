﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Queries.GetStoreConfigs
{
    public class GetStoreConfigsQuery : IRequest<ResponseList<StoreConfigModel>>
    {
        public int[] StoreIds { get; set; }
    }
}
