﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetStoreConfigs
{
    public class GetStoreConfigsHandler : IRequestHandler<GetStoreConfigsQuery, ResponseList<StoreConfigModel>>
    {

        private readonly IMediator _mediater;
        private readonly ILogger<GetStoreConfigsHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly EncryptionDecryptionKey encryptionDecryptionKey;
        public GetStoreConfigsHandler(IMediator mediater,
                                    ILogger<GetStoreConfigsHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper,
                                    EncryptionDecryptionKey encryptionDecryptionKey
                                    )
        {
            _mediater = mediater;
            _logger = logger;
            _context = context;
            _mapper = mapper;
            this.encryptionDecryptionKey = encryptionDecryptionKey;
        }

        public async Task<ResponseList<StoreConfigModel>> Handle(GetStoreConfigsQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            System.Collections.Generic.IEnumerable<StoreConfigModel> result = await _context.StoreConfigs.GetByFilter(request.StoreIds);

            foreach (var item in result)
            {
                if (item != null && !string.IsNullOrWhiteSpace(item.AccountNo))
                {
                    item.AccountNo = EncryptionDecryptionHelper.Decrypt(item.AccountNo, encryptionDecryptionKey.EncryptDecryptKey);
                }
            }
            _logger.TraceExitMethod(nameof(Handle), result);
            return new ResponseList<StoreConfigModel> { Data = result };
        }
    }
}
