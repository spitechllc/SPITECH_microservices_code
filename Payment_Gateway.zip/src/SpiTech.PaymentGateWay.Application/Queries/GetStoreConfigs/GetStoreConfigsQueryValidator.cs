﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Queries.GetStoreConfigs
{
    public class GetStoreConfigsQueryValidator : AbstractValidator<GetStoreConfigsQuery>
    {
        public GetStoreConfigsQueryValidator()
        {
            RuleFor(x => x.StoreIds).NotNull().NotEmpty();
        }
    }
}
