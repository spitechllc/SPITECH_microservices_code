﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Queries.GetUserPaymentMethods
{
    public class GetUserPaymentMethodsQueryValidator : AbstractValidator<GetUserPaymentMethodsQuery>
    {
        public GetUserPaymentMethodsQueryValidator()
        {
            RuleFor(x => x.UserPaymentMethodIds).NotNull().NotEmpty();
        }
    }
}
