﻿using MediatR;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.PaymentGateWay.Application.Queries.GetUserPaymentMethods
{
    public class GetUserPaymentMethodsQuery : IRequest<List<UserPaymentMethodModel>>
    {
        public int[] UserPaymentMethodIds { get; set; }
    }
}
