﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetUserPaymentMethods
{
    public class GetUserPaymentMethodsHandler : IRequestHandler<GetUserPaymentMethodsQuery, List<UserPaymentMethodModel>>
    {

        private readonly IMediator _mediater;
        private readonly ILogger<GetUserPaymentMethodsHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly EncryptionDecryptionKey encryptionDecryptionKey;
        public GetUserPaymentMethodsHandler(IMediator mediater,
                                    ILogger<GetUserPaymentMethodsHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper,
                                    EncryptionDecryptionKey encryptionDecryptionKey
                                    )
        {
            _mediater = mediater;
            _logger = logger;
            _context = context;
            _mapper = mapper;
            this.encryptionDecryptionKey = encryptionDecryptionKey;
        }

        public async Task<List<UserPaymentMethodModel>> Handle(GetUserPaymentMethodsQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            _logger.Warn("Userpaymentmethods by user paymentmethod ids -- Start");
            var result = await _context.UserPaymentMethods.Get(request.UserPaymentMethodIds);

            if (result != null && result.Any())
            {
                foreach (var userPaymentMethodModel in result)
                {
                    if (userPaymentMethodModel !=null && !string.IsNullOrWhiteSpace(userPaymentMethodModel.AccountNumber))
                    {
                        userPaymentMethodModel.AccountNumber = EncryptionDecryptionHelper.Decrypt(userPaymentMethodModel.AccountNumber, encryptionDecryptionKey.EncryptDecryptKey);
                    }
                    //if (userPaymentMethodModel != null && !string.IsNullOrWhiteSpace(userPaymentMethodModel.RoutingNumber))
                    //{
                    //    userPaymentMethodModel.RoutingNumber = EncryptionDecryptionHelper.Decrypt(userPaymentMethodModel.RoutingNumber, encryptionDecryptionKey.EncryptDecryptKey);
                    //}
                }
            }
            _logger.Warn("Userpaymentmethods by user paymentmethod ids -- End");

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
