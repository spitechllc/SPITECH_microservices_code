﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Queries.GetResellerConfigs
{
    public class GetResellerConfigsQueryValidator : AbstractValidator<GetResellerConfigsQuery>
    {
        public GetResellerConfigsQueryValidator()
        {
            RuleFor(x => x.ResellerIds).NotNull().NotEmpty();
        }
    }
}
