﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Queries.GetResellerConfigs
{
    public class GetResellerConfigsQuery : IRequest<ResponseList<ResellerConfigModel>>
    {
        public int[] ResellerIds { get; set; }
    }
}
