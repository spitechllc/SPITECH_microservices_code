﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Application.Queries.GetDecryptStoreConfig
{
    public class GetDecryptStoreConfigHandler : IRequestHandler<GetDecryptStoreConfigQuery, ResponseModel<StoreConfigDecryptModel>>
    {

        private readonly IMediator _mediater;
        private readonly ILogger<GetDecryptStoreConfigHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly EncryptionDecryptionKey encryptionDecryptionKey;
        public GetDecryptStoreConfigHandler(IMediator mediater,
                                    ILogger<GetDecryptStoreConfigHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper,
                                    EncryptionDecryptionKey encryptionDecryptionKey
                                    )
        {
            _mediater = mediater;
            _logger = logger;
            _context = context;
            _mapper = mapper;
            this.encryptionDecryptionKey = encryptionDecryptionKey;
        }

        public async Task<ResponseModel<StoreConfigDecryptModel>> Handle(GetDecryptStoreConfigQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            StoreConfigDecryptModel storeConfigDecryptModel = null;

            StoreConfig result = await _context.StoreConfigs.Get(request.StoreId);

            if (result != null && !string.IsNullOrWhiteSpace(result.AccountNo))
            {
                storeConfigDecryptModel = _mapper.Map<StoreConfigDecryptModel>(result);

                storeConfigDecryptModel.AccountNo = EncryptionDecryptionHelper.Decrypt(storeConfigDecryptModel.AccountNo, encryptionDecryptionKey.EncryptDecryptKey);
                storeConfigDecryptModel.MaskAccountNo = result.AccountNo.Substring(storeConfigDecryptModel.AccountNo.Length - 4).PadLeft(storeConfigDecryptModel.AccountNo.Length, '*');
            }

            _logger.TraceExitMethod(nameof(Handle), storeConfigDecryptModel);
            return new ResponseModel<StoreConfigDecryptModel> { Data = storeConfigDecryptModel, Success = result != null };
        }
    }
}
