﻿using FluentValidation;

namespace SpiTech.PaymentGateWay.Application.Queries.GetDecryptStoreConfig
{
    public class GetDecryptStoreConfigQueryValidator : AbstractValidator<GetDecryptStoreConfigQuery>
    {
        public GetDecryptStoreConfigQueryValidator()
        {
            RuleFor(x => x.StoreId).GreaterThan(0);
        }
    }
}
