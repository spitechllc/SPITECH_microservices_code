﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Domain.Models;

namespace SpiTech.PaymentGateWay.Application.Queries.GetDecryptStoreConfig
{
    public class GetDecryptStoreConfigQuery : IRequest<ResponseModel<StoreConfigDecryptModel>>
    {
        public int StoreId { get; set; }
    }
}
