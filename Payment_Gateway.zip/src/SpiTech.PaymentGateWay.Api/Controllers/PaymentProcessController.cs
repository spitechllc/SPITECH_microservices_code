﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.PaymentGateWay.Application.Commands.Payments;
using SpiTech.PaymentGateWay.Application.Commands.PreAuthPayment;
using SpiTech.PaymentGateWay.Application.Commands.ProcessPayment;
using SpiTech.PaymentGateWay.Application.Queries.GetPaymentByFilter;
using SpiTech.PaymentGateWay.Application.Queries.GetPaymentFailureReport;
using SpiTech.PaymentGateWay.Application.Queries.GetUserDueAmount;
using SpiTech.PaymentGateWay.Application.Queries.ValidatePreAuths;
using SpiTech.PaymentGateWay.Domain.FilterOptions;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.PaymentGateWay.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class PaymentProcessController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IStringLocalizer<PaymentProcessController> _localizer;

        public PaymentProcessController(IMediator mediator, IStringLocalizer<PaymentProcessController> localizer)
        {
            _mediator = mediator;
            _localizer = localizer;
        }

        /// <summary>
        /// To do preauthorization for credit card payments
        /// </summary>
        /// <param name="model">Object of PreAuthPaymentCommand</param>
        /// <returns>It  will return ResponseModel in the form of PreAuthPaymentResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_PaymentProcess_PreAuth")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("PreAuth")]
        public async Task<ActionResult<ResponseModel<PreAuthPaymentResponseModel>>> PreAuth(PreAuthPaymentCommand model)
        {
            ResponseModel res = await _mediator.Send(model).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// To validate preauth confirmation no
        /// </summary>
        /// <param name="model">Object of ValidatePreAuthQuery</param>
        /// <returns>It  will return ResponseModel in the form of PreAuthPaymentResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_PaymentProcess_Validate")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("Validate")]
        public async Task<ActionResult<ResponseModel<PreAuthPaymentResponseModel>>> Validate([FromQuery] ValidatePreAuthQuery model)
        {
            ResponseModel<PreAuthPaymentResponseModel> res = await _mediator.Send(model).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// To process final payment 
        /// </summary>
        /// <param name="model">Object of ProcessPaymentCommand</param>
        /// <returns>It  will return ResponseModel in the form of PaymentResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_PaymentProcess_Finalize")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("Finalize")]
        public async Task<ActionResult<ResponseModel<PaymentResponseModel>>> Finalize(ProcessPaymentCommand model)
        {
            ResponseModel<PaymentResponseModel> res = await _mediator.Send(model).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// To do preauth and process payment
        /// </summary>
        /// <param name="model">Object of PaymentCommand</param>
        /// <returns>It  will return ResponseModel in the form of PaymentResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_PaymentProcess_Payment")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("Payment")]
        public async Task<ActionResult<ResponseModel<PaymentResponseModel>>> Payment(PaymentCommand model)
        {
            ResponseModel<PaymentResponseModel> res = await _mediator.Send(model).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// returns collection of past payment details
        /// </summary>
        /// <param name="filter">Object of PaymentFilter</param>
        /// <param name="sortable">Object of Sortable</param>
        /// <returns>It  will return PaginatedList in the form of PaymentFilterModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_PaymentProcess_PaymentHistory")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("PaymentHistory")]
        public async Task<ActionResult<PaginatedList<PaymentFilterModel>>> Get([FromQuery] PaymentFilter filter, [FromQuery] Sortable sortable)
        {
            return Ok(await _mediator.Send(new GetPaymentByFilterQuery
            {
                filter = filter,
                sortable = sortable
            }).ConfigureAwait(false));
        }

        /// <summary>
        /// Get Payment Due list by user Id.
        /// </summary>
        /// <param name="userId">Varriable of int</param>
        /// <returns>It will return in the form of decimal</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_PaymentProcess_PaymentDue")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("PaymentDue")]
        public async Task<ActionResult<decimal>> GetPaymentDue([FromQuery] int userId)
        {
            decimal result = await _mediator.Send(new GetUserDueAmountQuery { UserId = userId }).ConfigureAwait(false);

            return Ok(result);
        }

        /// <summary>
        /// Return Collection Of Failed Payment
        /// </summary>
        /// <param name="filter">Object of PaymentFilter</param>
        /// <param name="sortable">Object of Sortable</param>
        /// <returns>It will return PaginatedList in the form of PaymentReportModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "Paymentapi_PaymentProcess_FailedPaymentList")]
        [HttpGet("FailedPaymentList")]
        public async Task<ActionResult<PaginatedList<PaymentReportModel>>> GetFailedPaymentList([FromQuery] PaymentFilter filter, [FromQuery] Sortable sortable)
        {
            return Ok(await _mediator.Send(new GetPaymentFailureQuery
            {
                filter = filter,
                sortable = sortable
            }).ConfigureAwait(false));
        }
    }
}