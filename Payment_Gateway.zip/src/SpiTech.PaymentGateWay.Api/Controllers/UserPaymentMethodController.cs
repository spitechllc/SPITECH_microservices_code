﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.Queries.GetAllUserMOP;
using SpiTech.PaymentGateWay.Application.Queries.GetAllUserWithPaymentMethod;
using SpiTech.PaymentGateWay.Application.Queries.GetDecryptStoreConfig;
using SpiTech.PaymentGateWay.Application.Queries.GetUserPaymentMethodByUserId;
using SpiTech.PaymentGateWay.Application.Queries.GetUserPaymentMethods;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Net;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class UserPaymentMethodController : ControllerBase
    {
        private readonly IMediator _mediator;
        public UserPaymentMethodController(IMediator mediator)
        {
            _mediator = mediator;
        }
        /// <summary>
        /// returns collection of userpaymentmethods by user paymentmethod ids
        /// </summary>
        /// <param name="query">Object of GetUserPaymentMethodsQuery</param>
        /// <returns>It will return ResponseList in the form of UserPaymentMethodModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_UserPaymentMethod_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("Get")]
        public async Task<ActionResult<ResponseList<UserPaymentMethodModel>>> Get([FromBody] GetUserPaymentMethodsQuery query)
        {
            var result = await _mediator.Send(query).ConfigureAwait(false);
            return Ok(new ResponseList<UserPaymentMethodModel>(result));
        }

        /// <summary>
        /// Get all user which have payment method
        /// </summary>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_UserPaymentMethod_GetUserWithPaymentMethod")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("GetUserWithPaymentMethod")]
        public async Task<ActionResult<ResponseList<UserWithPaymentMethodModel>>> GetUserWithPaymentMethod()
        {
            return Ok(await _mediator.Send(new GetAllUserWithPaymentMethodQuery()).ConfigureAwait(false));
        }

        /// <summary>
        /// Get User PaymentMethod By User id
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_GetUserPaymentMethod_UserId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetUserPaymentMethod/{userId}")]
        public async Task<ActionResult<ResponseList<UserPaymentMethod>>> GetUserPaymentMethodByUId(int userId)
        {
            return Ok(await _mediator.Send(new GetUserPaymentMethodByUserIdQuery { Userid = userId }).ConfigureAwait(false));
        }

        [ApiPermissionAuthorize(Permissions = "Paymentapi_UserPaymentMethod_GetAllUserMOP")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("GetAllUserMOP")]
        public async Task<ActionResult<ResponseList<UserPaymentMethod>>> GetAllUserMOP()
        {
            return Ok(await _mediator.Send(new GetAllUserMOPQuery()).ConfigureAwait(false));
        }
    }
}
