﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.Commands.SaveStoreConfig;
using SpiTech.PaymentGateWay.Application.Queries.GetDecryptStoreConfig;
using SpiTech.PaymentGateWay.Application.Queries.GetMasterStoreConfig;
using SpiTech.PaymentGateWay.Application.Queries.GetStoreConfig;
using SpiTech.PaymentGateWay.Application.Queries.GetStoreConfigs;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.PaymentGateWay.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class StoreConfigController : ControllerBase
    {
        private readonly IMediator _mediator;

        public StoreConfigController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// to get store account details by store id
        /// </summary>
        /// <param name="storeId">Varriable of int</param>
        /// <returns>It will return ResponseModel in the form of StoreConfig</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_StoreConfig_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("{storeId}")]
        public async Task<ActionResult<ResponseModel<StoreConfig>>> Get([FromRoute] int storeId)
        {
            return Ok(await _mediator.Send(new GetStoreConfigQuery { StoreId = storeId }).ConfigureAwait(false));
        }

        /// <summary>
        /// to get master store account details
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of StoreConfigModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_StoreConfig_MasterStoreConfig")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("MasterStoreConfig")]
        public async Task<ActionResult<ResponseList<StoreConfigModel>>> GetMasterStoreConfig()
        {
            return Ok(await _mediator.Send(new GetMasterStoreConfigQuery()).ConfigureAwait(false));
        }

        /// <summary>
        /// to get all stores account details
        /// </summary>
        /// <param name="configsQuery">object of GetStoreConfigsQuery</param>
        /// <returns>It will return ResponseList in the form of StoreConfigModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_StoreConfig_AllStoreConfigs")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("AllStoreConfigs")]
        public async Task<ActionResult<ResponseList<StoreConfigModel>>> GetAll([FromBody] GetStoreConfigsQuery configsQuery)
        {
            return Ok(await _mediator.Send(configsQuery).ConfigureAwait(false));
        }

        /// <summary>
        /// To save store account details in system
        /// </summary>
        /// <param name="model">object of SaveStoreConfigCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_StoreConfig_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost()]
        public async Task<ActionResult<ResponseModel>> Save([FromBody] SaveStoreConfigCommand model)
        {
            return Ok(await _mediator.Send(model));
        }


        /// <summary>
        /// Store config account number show account
        /// </summary>
        /// <param name="storeId"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_StoreConfig_ShowAccount")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("showAccount/{storeId}")]
        public async Task<ActionResult<ResponseModel<StoreConfigDecryptModel>>> ShowAccount([FromRoute] int storeId)
        {
            return Ok(await _mediator.Send(new GetDecryptStoreConfigQuery { StoreId = storeId }).ConfigureAwait(false));
        }
    }
}