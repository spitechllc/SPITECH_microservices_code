﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using SpiTech.ApplicationCore.Authorizations;
using System;
using System.IO;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.PaymentGateWay.Api.Controllers
{

    [Route("api/[controller]")]
    public class ContentController : Controller
    {
        /// <summary>
        /// To retrieve all static files form system (i.e. js,css etc..)
        /// </summary>
        /// <param name="filename">Varriable of string</param>
        /// <returns>It will return a file</returns>
        [HttpGet("StaticFile/{filename}")]
        public ActionResult StaticFile(string filename)
        {
            string filepath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Staticfiles", filename);

            if (System.IO.File.Exists(filepath))
            {
                byte[] filedata = System.IO.File.ReadAllBytes(filepath);
                string contentType = GetMimeTypeForFileExtension(filepath);

                System.Net.Mime.ContentDisposition cd = new()
                {
                    FileName = filename,
                    Inline = true,
                };

                Response.Headers.Add("Content-Disposition", cd.ToString());

                return File(filedata, contentType);
            }

            return NotFound();
        }

        private string GetMimeTypeForFileExtension(string filePath)
        {
            const string DefaultContentType = "application/octet-stream";

            FileExtensionContentTypeProvider provider = new();

            if (!provider.TryGetContentType(filePath, out string contentType))
            {
                contentType = DefaultContentType;
            }

            return contentType;
        }
    }
}
