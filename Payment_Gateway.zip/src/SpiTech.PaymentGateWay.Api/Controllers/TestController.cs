﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.PaymentGateWay.Application.Services;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Configs;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Api.Controllers
{
    //[Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class TestController : Controller
    {
        private readonly IAuroraGcsService auroraGcsService;
        private readonly IMediator _mediator;
        private readonly IUnitOfWork context;
        private readonly EncryptionDecryptionKey encryptionDecryptionKey;

        public TestController(IAuroraGcsService auroraGcsService, IMediator mediator, IUnitOfWork context, EncryptionDecryptionKey encryptionDecryptionKey)
        {
            this.auroraGcsService = auroraGcsService;
            _mediator = mediator;
            this.context = context;
            this.encryptionDecryptionKey = encryptionDecryptionKey;
        }

        //[HttpGet]
        //public ActionResult GetGCS()
        //{
        //    this.auroraGcsService.ProcessFiles(default(CancellationToken));

        //    return Ok();
        //}

        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("EncryptUserAccountInfo")]
        public async Task<ActionResult<ResponseModel>> EncryptUserAccountInfo()
        {
            //var result = await context.UserPaymentMethods.GetAll();
            //var userPaymentMethods = result.Where(t => t.PaymentMethodId == 2);

            //foreach (var item in userPaymentMethods)
            //{
            //    if (!string.IsNullOrWhiteSpace(item.RoutingNumber))
            //    {
            //        item.RoutingNumber = EncryptionDecryptionHelper.Encrypt(item.RoutingNumber, encryptionDecryptionKey.EncryptDecryptKey);

            //        await context.UserPaymentMethods.Update(item);
            //        context.Commit();
            //    }
            //}

            return Ok();
        }

        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("EncryptStoreAccountInfo")]
        public async Task<ActionResult<ResponseModel>> EncryptStoreAccountInfo()
        {
            //var result = await context.StoreConfigs.GetAll();

            //foreach (var item in result)
            //{
            //    if (!string.IsNullOrWhiteSpace(item.RoutingNo) )
            //    {
            //        item.RoutingNo = EncryptionDecryptionHelper.Decrypt(item.RoutingNo, encryptionDecryptionKey.EncryptDecryptKey);

            //        await context.StoreConfigs.Update(item);
            //        context.Commit();
            //    }
            //}

            return Ok();
        }
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("EncryptSaleAgentAccountInfo")]
        public async Task<ActionResult<ResponseModel>> EncryptSaleAgentAccountInfo()
        {
            //var result = await context.SaleAgentConfigs.GetAll();

            //foreach (var item in result)
            //{
            //    if (!string.IsNullOrWhiteSpace(item.AccountNo))
            //    {
            //        item.AccountNo = EncryptionDecryptionHelper.Decrypt(item.AccountNo, encryptionDecryptionKey.EncryptDecryptKey);

            //        await context.SaleAgentConfigs.Update(item);
            //        context.Commit();
            //    }
            //}

            return Ok();
        }

        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("EncryptResellerAccountInfo")]
        public async Task<ActionResult> EncryptResellerAccountInfo()
        {
            //var result = await context.ResellerConfigs.GetAll();

            //foreach (var item in result)
            //{
            //    if (!string.IsNullOrWhiteSpace(item.AccountNo))
            //    {
            //        item.AccountNo = EncryptionDecryptionHelper.Encrypt(item.AccountNo, encryptionDecryptionKey.EncryptDecryptKey);

            //        await context.ResellerConfigs.Update(item);
            //        context.Commit();
            //    }

            //}

            return Ok();
        }
    }
}
