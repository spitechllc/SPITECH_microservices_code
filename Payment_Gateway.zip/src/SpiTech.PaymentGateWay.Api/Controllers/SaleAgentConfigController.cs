﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.Commands.SaveSaleAgentConfig;
using SpiTech.PaymentGateWay.Application.Queries.GetSaleAgentConfig;
using SpiTech.PaymentGateWay.Application.Queries.GetSaleAgentConfigs;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.PaymentGateWay.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class SaleAgentConfigController : ControllerBase
    {
        private readonly IMediator _mediator;

        public SaleAgentConfigController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// To get sale agent account details by saleagent id
        /// </summary>
        /// <param name="saleAgentId">Varriable of int</param>
        /// <returns>It will return ResponseModel in the form of SaleAgentConfig</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_SaleAgentConfig_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("{saleAgentId}")]
        public async Task<ActionResult<ResponseModel<SaleAgentConfig>>> Get([FromRoute] int saleAgentId)
        {
            return Ok(await _mediator.Send(new GetSaleAgentConfigQuery { SaleAgentId = saleAgentId }).ConfigureAwait(false));
        }

        /// <summary>
        /// to get all saleagent account details
        /// </summary>
        /// <param name="configsQuery">Object of GetSaleAgentConfigsQuery</param>
        /// <returns>It will return ResponseList in the form of SaleAgentConfigModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_SaleAgentConfig_AllSaleAgentConfigs")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("AllSaleAgentConfigs")]
        public async Task<ActionResult<ResponseList<SaleAgentConfigModel>>> GetAll([FromBody] GetSaleAgentConfigsQuery configsQuery)
        {
            return Ok(await _mediator.Send(configsQuery).ConfigureAwait(false));
        }

        /// <summary>
        /// To save saleagent account details in system
        /// </summary>
        /// <param name="model">Object of SaveSaleAgentConfigCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_SaleAgentConfig_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost()]
        public async Task<ActionResult<ResponseModel>> Save([FromBody] SaveSaleAgentConfigCommand model)
        {
            return Ok(await _mediator.Send(model));
        }
    }
}
