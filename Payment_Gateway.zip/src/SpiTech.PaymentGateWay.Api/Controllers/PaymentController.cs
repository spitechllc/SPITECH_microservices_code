﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.PaymentGateWay.Application.Commands.ActivateACHAccount;
using SpiTech.PaymentGateWay.Application.Commands.AddACHAccountDetailsByPlaid;
using SpiTech.PaymentGateWay.Application.Commands.AddNickName;
using SpiTech.PaymentGateWay.Application.Commands.AddPaymentSourceDwolla;
using SpiTech.PaymentGateWay.Application.Commands.CreateWebHookDetail;
using SpiTech.PaymentGateWay.Application.Commands.DeleteACHBankDetails;
using SpiTech.PaymentGateWay.Application.Commands.DeleteUserPaymentMethod;
using SpiTech.PaymentGateWay.Application.Commands.MarkFraudAccount;
using SpiTech.PaymentGateWay.Application.Commands.SaveACHDetails;
using SpiTech.PaymentGateWay.Application.Commands.SaveToken;
using SpiTech.PaymentGateWay.Application.Commands.UnMarkFraudAccount;
using SpiTech.PaymentGateWay.Application.Queries.GetAllFraudAccount;
using SpiTech.PaymentGateWay.Application.Queries.GetAllPaymentMethod;
using SpiTech.PaymentGateWay.Application.Queries.GetDefaultPaymentMethodByUserId;
using SpiTech.PaymentGateWay.Application.Queries.GetDwollaCustomer;
using SpiTech.PaymentGateWay.Application.Queries.GetPaymentGatewayConfig;
using SpiTech.PaymentGateWay.Application.Queries.GetPlaidLinkToken;
using SpiTech.PaymentGateWay.Application.Queries.GetUserByUserId;
using SpiTech.PaymentGateWay.Application.Queries.GetUserPaymentMethodByUserId;
using SpiTech.PaymentGateWay.Application.Queries.SetDefaultUserPaymentMethod;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Enums;
using SpiTech.PaymentGateWay.Domain.Models;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.PaymentGateWay.Api.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    public class PaymentController : Controller
    {
        private readonly IMediator _mediator;
        private readonly IUserAuthenticationProvider authenticationProvider;
        private readonly AppSetting appSetting;
        private readonly NMIGatewayConfigs nmiGatewayConfigs;
        private readonly ILogger<PaymentController> _logger;
        private readonly IStringLocalizer<PaymentController> _localizer;

        public PaymentController(IMediator mediator,
            NMIGatewayConfigs nmiGatewayConfigs,
            IUserAuthenticationProvider authenticationProvider,
            AppSetting appSetting,
            ILogger<PaymentController> logger, IStringLocalizer<PaymentController> localizer)
        {
            _mediator = mediator;
            this.nmiGatewayConfigs = nmiGatewayConfigs;
            this.authenticationProvider = authenticationProvider;
            this.appSetting = appSetting;
            _logger = logger;
            _localizer = localizer;
        }

        /// <summary>
        /// To get webhook details from NMI
        /// </summary>
        /// <param></param>
        /// <returns>It will return in the form of CreateWebHookDetailCommand</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("WebhookCreditCardSalesDetails")]
        [AllowAnonymous]
        public async Task<ActionResult> WebhookCreditCardSalesDetails()
        {
            try
            {
                CreateWebHookDetailCommand command = new();

                using (StreamReader reader = new StreamReader(Request.Body, Encoding.UTF8))
                {
                    command.Message = await reader.ReadToEndAsync();
                }

                await _mediator.Send(command).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
            }

            return Ok();
        }

        /// <summary>
        /// Returns success page for successfully added paymentmethod
        /// </summary>
        /// <param name="message">Varriable of string</param>
        /// <returns>It will return in the form of SuccesErrorViewModel</returns>
        [HttpGet("success")]
        [AllowAnonymous]
        public ActionResult Success([FromQuery] string message)
        {
            if (string.IsNullOrWhiteSpace(message))
            {
                message = "Payment method saved successfully";
            }
            else if (message == "null")
            {
                message = "Payment method saved successfully";
            }
            SuccesErrorViewModel model = new()
            {
                AppSetting = appSetting,
                SuccessMessage = _localizer[message].Value
            };
            return View(model);
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        [HttpGet("SuccessVerifone")]
        [AllowAnonymous]
        public ActionResult SuccessVerifone([FromQuery] string message)
        {
            if (string.IsNullOrWhiteSpace(message))
            {
                message = "Payment method saved successfully";
            }
            else if (message == "null")
            {
                message = "Payment method saved successfully";
            }
            SuccesErrorViewModel model = new()
            {
                AppSetting = appSetting,
                SuccessMessage = _localizer[message].Value
            };
            return View(model);
        }

        [HttpGet("SuccessVelocity")]
        [AllowAnonymous]
        public ActionResult SuccessVelocity([FromQuery] string message)
        {
            if (string.IsNullOrWhiteSpace(message))
            {
                message = "Payment method saved successfully";
            }
            else if (message == "null")
            {
                message = "Payment method saved successfully";
            }
            SuccesErrorViewModel model = new()
            {
                AppSetting = appSetting,
                SuccessMessage = _localizer[message].Value
            };
            return View(model);
        }
        [HttpGet("SuccessTheStation")]
        [AllowAnonymous]
        public ActionResult SuccessTheStation([FromQuery] string message)
        {
            if (string.IsNullOrWhiteSpace(message))
            {
                message = "Payment method saved successfully";
            }
            else if (message == "null")
            {
                message = "Payment method saved successfully";
            }
            SuccesErrorViewModel model = new()
            {
                AppSetting = appSetting,
                SuccessMessage = _localizer[message].Value
            };
            return View(model);
        }

        

        /// <summary>
        /// Returns error page for failed paymentmethod add process
        /// </summary>
        /// <param name="message">Varriable of string</param>
        /// <returns>It will return in the form of SuccesErrorViewModel</returns>
        [HttpGet("error")]
        [AllowAnonymous]
        public ActionResult Error([FromQuery] string message)
        {
            if (string.IsNullOrWhiteSpace(message))
            {
                message = "Some Error Occured";
            }
            else if (message == "null")
            {
                message = "Some Error Occured";
            }
            SuccesErrorViewModel model = new()
            {
                AppSetting = appSetting,
                ErrorMessage = _localizer[message].Value
            };
            return View(model);
        }

        /// <summary>
        /// Returns incoorect information page if not able to get account details from plaid
        /// </summary>
        /// <param></param>
        /// <returns>It will return in the form of SuccesErrorViewModel</returns>
        [HttpGet("incorrectinfo")]
        [AllowAnonymous]
        public ActionResult IncorrectInformation()
        {
            SuccesErrorViewModel model = new()
            {
                AppSetting = appSetting
            };
            return View(model);
        }

        /// <summary>
        /// Returns decline page if user declined account information submit to SpiTech
        /// </summary>
        /// <param name="message">Varriable of string</param>
        /// <returns>It will return in the form of SuccesErrorViewModel</returns>
        [HttpGet("achauthorizationdeclined")]
        [AllowAnonymous]
        public ActionResult ACHAuthorizationDeclined([FromQuery] string message)
        {
            if (string.IsNullOrWhiteSpace(message))
            {
                message = "ACH Authorization Process Declined.";
            }
            else if (message == "null")
            {
                message = "ACH Authorization Process Declined.";
            }
            SuccesErrorViewModel model = new()
            {
                AppSetting = appSetting,
                SuccessMessage = _localizer[message].Value
            };
            return View(model);
        }

        /// <summary>
        /// Used to add credit card details to system 
        /// </summary>
        /// <param name="paymentmethod">Object of EnumPaymentMethod</param>
        /// <returns>It will return in the form of CreditCardModel or AchCardModel and redirect to the view</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_Payment_AddCard")]
        [HttpGet("AddCard/{paymentmethod}")]
        public async Task<ActionResult> AddCard(EnumPaymentMethod paymentmethod)
        {
            int userid = authenticationProvider.GetUserAuthentication().UserId;
            Service.Clients.Identity.UserModel user = await _mediator.Send(new GetUserByUserIdQuery() { UserId = userid }).ConfigureAwait(false);

            if (user == null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("UserId", "Not able to get userid from token"));
            }

            if (EnumPaymentMethod.ACH == paymentmethod)
            {
                bool dwolla = false;

                PaymentGatewayConfig dwollaPaymentGatewayConfig = (await _mediator.Send(new GetPaymentGatewayConfigQuery { })).Data.FirstOrDefault(t => t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithDwolla && t.IsActive == true);

                if (dwollaPaymentGatewayConfig != null && dwollaPaymentGatewayConfig.PaymentGatewayConfigId > 0)
                {
                    dwolla = true;
                }
                else
                {
                    dwolla = false;
                }

                string linktoken = await _mediator.Send(new GetPlaidLinkTokenQuery { Id = userid.ToString() }).ConfigureAwait(false);

                AchCardModel model = new()
                {
                    PaymentGateway = (int)EnumPaymentGateway.PlaidWithDwolla,
                    PaymentMethod = (int)paymentmethod,
                    Token = linktoken,
                    User = user,
                    AppSetting = appSetting,
                    AccessToken = CustomTokenRetriever.FromHeaderAndQueryString(Request),
                    IsDwolla = dwolla
                };

                return View("/Views/Payment/DwollaAddCard.cshtml", model);
            }
            else if (EnumPaymentMethod.CreditCard == paymentmethod)
            {
                PaymentGatewayConfig nmiPaymentGatewayConfig = (await _mediator.Send(new GetPaymentGatewayConfigQuery { })).Data.FirstOrDefault(t => t.PaymentGatewayConfigId == (int)EnumPaymentGateway.NMI);

                NMIGatewayConfig nmiGatewayConfig = nmiGatewayConfigs.FirstOrDefault(t => t.IsProd == nmiPaymentGatewayConfig.IsProdEnabled);

                CreditCardModel model = new()
                {
                    PaymentGateway = (int)EnumPaymentGateway.NMI,
                    PaymentMethod = (int)paymentmethod,
                    Token = nmiGatewayConfig.PublicSecurityKeys,
                    User = user,
                    AppSetting = appSetting,
                    AccessToken = CustomTokenRetriever.FromHeaderAndQueryString(Request),
                    TenantName = "SpiTech"
                };

                return View("/Views/Payment/NMIAddCard.cshtml", model);
            }
            else
            {
                return View("/Views/Payment/PaymentMethodNotFound.cshtml");
            }
        }

        [ApiPermissionAuthorize(Permissions = "Paymentapi_Payment_AddCard")]
        [HttpGet("AddCardTenant/{paymentmethod}/{tenantName}")]
        public async Task<ActionResult> AddCard(EnumPaymentMethod paymentmethod, string tenantName)
        {
            int userid = authenticationProvider.GetUserAuthentication().UserId;
            Service.Clients.Identity.UserModel user = await _mediator.Send(new GetUserByUserIdQuery() { UserId = userid }).ConfigureAwait(false);

            if (user == null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure("UserId", "Not able to get userid from token"));
            }

            if (EnumPaymentMethod.ACH == paymentmethod)
            {
                bool dwolla = false;

                PaymentGatewayConfig dwollaPaymentGatewayConfig = (await _mediator.Send(new GetPaymentGatewayConfigQuery { })).Data.FirstOrDefault(t => t.PaymentGatewayConfigId == (int)EnumPaymentGateway.PlaidWithDwolla && t.IsActive == true);

                if (dwollaPaymentGatewayConfig != null && dwollaPaymentGatewayConfig.PaymentGatewayConfigId > 0)
                {
                    dwolla = true;
                }
                else
                {
                    dwolla = false;
                }

                string linktoken = await _mediator.Send(new GetPlaidLinkTokenQuery { Id = userid.ToString() }).ConfigureAwait(false);

                AchCardModel model = new()
                {
                    PaymentGateway = (int)EnumPaymentGateway.PlaidWithDwolla,
                    PaymentMethod = (int)paymentmethod,
                    Token = linktoken,
                    User = user,
                    AppSetting = appSetting,
                    AccessToken = CustomTokenRetriever.FromHeaderAndQueryString(Request),
                    IsDwolla = dwolla
                };

                return View("/Views/Payment/DwollaAddCard.cshtml", model);
            }
            else if (EnumPaymentMethod.CreditCard == paymentmethod)
            {
                PaymentGatewayConfig nmiPaymentGatewayConfig = (await _mediator.Send(new GetPaymentGatewayConfigQuery { })).Data.FirstOrDefault(t => t.PaymentGatewayConfigId == (int)EnumPaymentGateway.NMI);

                NMIGatewayConfig nmiGatewayConfig = nmiGatewayConfigs.FirstOrDefault(t => t.IsProd == nmiPaymentGatewayConfig.IsProdEnabled);

                CreditCardModel model = new()
                {
                    PaymentGateway = (int)EnumPaymentGateway.NMI,
                    PaymentMethod = (int)paymentmethod,
                    Token = nmiGatewayConfig.PublicSecurityKeys,
                    User = user,
                    AppSetting = appSetting,
                    AccessToken = CustomTokenRetriever.FromHeaderAndQueryString(Request),
                    TenantName = tenantName
                };

                return View("/Views/Payment/NMIAddCard.cshtml", model);
            }
            else
            {
                return View("/Views/Payment/PaymentMethodNotFound.cshtml");
            }
        }

        /// <summary>
        /// Generate and store token with stored creditcard details for future transactions
        /// </summary>
        /// <param name="command">Object of SaveTokenCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_Payment_SaveToken")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("SaveToken")]
        public async Task<ActionResult<ResponseModel>> SaveTokenCreditCard([FromBody] SaveTokenCommand command)
        {
            ResponseModel res = await _mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);

        }

        /// <summary>
        /// To get and store account details by plaid for ach account
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        //[Authorize(Roles = IdentityRoleType.ConsumerUser + " , " + IdentityRoleType.BusinessUser + " , " + IdentityRoleType.SuperAdmin)]
        //[ApiPermissionAuthorize(Permissions = "Paymentapi_Payment_TransactionToken")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("TransactionToken/{publicToken}")]
        public async Task<ActionResult> TransactionTokenACH(string publicToken)
        {

            if (string.IsNullOrWhiteSpace(publicToken))
            {
                return View("/Views/Payment/Error.cshtml");
            }
            int userid = authenticationProvider.GetUserAuthentication().UserId;
            // var query = tenantMapperService.Map<GetUserByUserIdModel, GetUserByUserIdQuery>(new GetUserByUserIdQuery() { UserId = userid });
            Service.Clients.Identity.UserModel user = await _mediator.Send(new GetUserByUserIdQuery() { UserId = userid }).ConfigureAwait(false);

            if (user == null)
            {
                throw new ValidationException(new FluentValidation.Results.ValidationFailure(_localizer["UserId"].Value, _localizer["Not able to get userid from token"].Value));
            }
            AddPaymentSourceDwollaCommand command = new();
            command.PaymentGatewayId = 2;
            command.PaymentMethodId = 2;
            command.PublicToken = publicToken;
            command.UserId = userid;
            command.UserName = user.UserName;
            ResponseModel<ACHAuthorizationModel> res = await _mediator.Send(command).ConfigureAwait(false);

            if (res.Success)
            {

                ACHAuthorizationModel model = new()
                {
                    PaymentGateway = (int)EnumPaymentGateway.NMI,
                    UserPaymentMethodId = res.Data.UserPaymentMethodId,
                    BankName = res.Data.BankName,
                    UserId = userid,
                    AppSetting = appSetting,
                    AccessToken = CustomTokenRetriever.FromHeaderAndQueryString(Request)
                };
                return View("/Views/Payment/ACHAuthorization.cshtml", model);
            }
            else
            {
                return View("/Views/Payment/Error.cshtml");
            }
        }

        /// <summary>
        /// To get all paymentmethods added in the system
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of PaymentMethodModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_Payment_PaymentMethod")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("PaymentMethod")]
        public async Task<ActionResult<ResponseList<PaymentMethodModel>>> PaymentMethod()
        {
            return Ok(await _mediator.Send(new GetAllPaymentMethodQuery()).ConfigureAwait(false));
        }

        /// <summary>
        /// To set default payment method for consumer
        /// </summary>
        /// <param name="userPaymentMethodId">Object of int</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_Payment_SetDefaultUserPaymentMethod")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("SetDefaultUserPaymentMethod/{userPaymentMethodId}")]
        public async Task<ActionResult<ResponseModel>> SetDefaultUserPaymentMethod([FromRoute] int userPaymentMethodId)
        {
            ResponseModel res = await _mediator.Send(new SetDefaultUserPaymentMethodCommand() { UserPaymentMethodId = userPaymentMethodId }).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// To get default payment method of consumer
        /// </summary>
        /// <param name="model">Object of GetDefaultUserPaymentMethodByUserIdQuery</param>
        /// <returns>It will return in the form of UserPaymentMethodModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_Payment_GetDefaultUserPaymentMethod")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetDefaultUserPaymentMethod")]
        public async Task<ActionResult<UserPaymentMethodModel>> GetDefaultUserPaymentMethod([FromQuery] GetDefaultUserPaymentMethodByUserIdQuery model)
        {
            return Ok(await _mediator.Send(model).ConfigureAwait(false));
        }

        /// <summary>
        /// To get payment methods of the consumer 
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of UserPaymentMethodModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_Payment_UserPaymentMethod")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("UserPaymentMethod")]
        public async Task<ActionResult<ResponseList<UserPaymentMethodModel>>> UserPaymentMethod()
        {
            return Ok(await _mediator.Send(new GetUserPaymentMethodByUserIdQuery() { Userid = authenticationProvider.GetUserAuthentication().UserId, PaymentMethodId = 0 }).ConfigureAwait(false));
        }

        /// <summary>
        /// To delete payment method of a particuler consumer
        /// </summary>
        /// <param name="Model">Object of DeleteUserPaymentMethodCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_Payment_DeleteUserPaymentMethod")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("DeleteUserPaymentMethod")]
        public async Task<ActionResult<ResponseModel>> DeleteUserPaymentMethod([FromQuery] DeleteUserPaymentMethodCommand Model)
        {
            ResponseModel res = await _mediator.Send(Model).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// To add nick name to the added card or account details
        /// </summary>
        /// <param name="command">Object of AddNickNameCommand</param>
        /// <returns>It will return ResponseModel in the form of UserPaymentMethodModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_Payment_AddNickName")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("AddNickName")]
        public async Task<ActionResult<ResponseModel<UserPaymentMethodModel>>> AddNickName([FromBody] AddNickNameCommand command)
        {
            ResponseModel res = await _mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);

        }

        /// <summary>
        /// To invoke plaid sdk on mobile app
        /// </summary>
        /// <param name="storeId">Varriable of int</param>
        /// <returns>It will return in the form of DwollaCustomer</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_Payment_DwollaCustomerByFilter")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("DwollaCustomerByFilter/{storeId}")]
        public async Task<ActionResult<DwollaCustomer>> GetDwollaCustomerByFilter([FromRoute] int storeId)
        {
            int userid = authenticationProvider.GetUserAuthentication().UserId;
            if (storeId > 0)
            {
                userid = 0;
            }
            var response = await _mediator.Send(new GetDwollaCustomerQuery() { UserId = userid, StoreId = storeId }).ConfigureAwait(false);
            if (!response.Success)
            {
                return NotFound("Coming Soon");
            }
            else
            {
                return Ok(response.Data);
            }

        }

        /// <summary>
        /// To get and store token for account details for future transactions
        /// </summary>
        /// <param name="command">Object of SaveACHDetailsCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_Payment_SaveTokenACH")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("SaveTokenACH")]
        public async Task<ActionResult<ResponseModel>> SaveTokenACH([FromBody] SaveACHDetailsCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));

        }
        /// <summary>
        /// To delete account details if consumer denied permission to add account
        /// </summary>
        /// <param name="command">Object of DeleteACHBankDetailsCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_Payment_DeleteACHBankDetails")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("DeleteACHBankDetails")]
        public async Task<ActionResult<ResponseModel>> DeleteACHBankDetails([FromBody] DeleteACHBankDetailsCommand command)
        {           
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// to activate account if consumer accept permission to add account
        /// </summary>
        /// <param name="command">Object of ActivateACHAccountCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_Payment_ActivateACHAccount")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("ActivateACHAccount")]
        public async Task<ActionResult<ResponseModel>> ActivateACHAccount([FromBody] ActivateACHAccountCommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// To get list of all payment methods mark as fraud
        /// </summary>
        /// <param name="command">Object of GetAllFraudAccountQuery</param>
        /// <returns>It will return ResponseList in the form of UserPaymentMethodModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_Payment_GetAllFraudAccount")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetAllFraudAccount")]
        public async Task<ActionResult<ResponseList<UserPaymentMethodModel>>> GetAllFraudAccount([FromBody] GetAllFraudAccountQuery command)
        {
            ResponseList<UserPaymentMethodModel> res = await _mediator.Send(command).ConfigureAwait(false);           
            return Ok(res);

        }

        /// <summary>
        /// to mark payment method as fraud
        /// </summary>
        /// <param name="command">Object of MarkFraudAccountCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_Payment_MarkFraudAccount")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("MarkFraudAccount")]
        public async Task<ActionResult<ResponseModel>> MarkFraudAccount([FromBody] MarkFraudAccountCommand command)
        {
            ResponseModel res = await _mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);

        }

        /// <summary>
        /// To unmark Payment method as fraud
        /// </summary>
        /// <param name="command">Object of UnMarkFraudAccountCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_Payment_UnMarkFraudAccount")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("UnMarkFraudAccount")]
        public async Task<ActionResult<ResponseModel>> UnMarkFraudAccount([FromBody] UnMarkFraudAccountCommand command)
        {
            ResponseModel res = await _mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);

        }
     
    }
}
