﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.Commands.CreatePaymentMethodConfiguration;
using SpiTech.PaymentGateWay.Application.Queries.GetPaymentGatewayConfig;
using SpiTech.PaymentGateWay.Application.Queries.GetPaymentMethodConfigurationFilter;
using SpiTech.PaymentGateWay.Application.Queries.GetStorePaymentConfigByStoreId;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.PaymentGateWay.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class PaymentMethodConfigurationController : ControllerBase
    {
        private readonly IMediator _mediator;
        public PaymentMethodConfigurationController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// to save store payment method configuration
        /// </summary>
        /// <param name="model">Object of CreatePaymentMethodConfigurationCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_PaymentMethod_PaymentMethodConfiguration")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("PaymentMethodConfiguration")]
        public async Task<ActionResult<ResponseModel>> PaymentMethodconfig(CreatePaymentMethodConfigurationCommand model)
        {
            return Ok(await _mediator.Send(model).ConfigureAwait(false));
        }

        /// <summary>
        /// returns store payment method by filter (i.e. storeid and paymentgateway config)
        /// </summary>
        /// <param name="model">Object of GetPaymentMethodConfigurationFilterQuery</param>
        /// <returns>It will return in the form of StorePaymentMethodConfigrationModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_PaymentMethod_GetStorePaymentMethod")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetStorePaymentMethod")]
        public async Task<ActionResult<StorePaymentMethodConfigrationModel>> StorePaymentMethod([FromQuery] GetPaymentMethodConfigurationFilterQuery model)
        {
            return Ok(await _mediator.Send(model).ConfigureAwait(false));
        }

        /// <summary>
        /// returns payment method by store id
        /// </summary>
        /// <param name="StoreId">Object of int</param>
        /// <returns>It will return ResponseList in the form of StorePaymentMethodConfigrationModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_PaymentMethod_StorePaymentMethodByStoreId")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("StorePaymentMethodByStoreId/{StoreId}")]
        public async Task<ActionResult<ResponseList<StorePaymentMethodConfigrationModel>>> StorePaymentMethod([FromRoute] int StoreId)
        {
            return Ok(await _mediator.Send(new GetStorePaymentConfigByStoreIdQuery { StoreId = StoreId }).ConfigureAwait(false));
        }

        /// <summary>
        /// returns payment gateway configuration details
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of PaymentGatewayConfig</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_PaymentMethod_PaymentGateway")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("PaymentGateway")]
        public async Task<ActionResult<ResponseList<PaymentGatewayConfig>>> GetPaymentGateway()
        {
            return Ok(await _mediator.Send(new GetPaymentGatewayConfigQuery { }).ConfigureAwait(false));
        }
    }
}
