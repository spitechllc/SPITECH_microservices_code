﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.Commands.GetTransactionDetailsNMI;
using SpiTech.PaymentGateWay.Application.Commands.SaveNMITransactionDetails;
using SpiTech.PaymentGateWay.Domain.Configs;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.PaymentGateWay.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class NMIController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IUserAuthenticationProvider authenticationProvider;
        private readonly AppSetting appSetting;
        private readonly NMIGatewayConfigs nmiGatewayConfigs;
        private readonly ILogger<NMIController> _logger;
        private readonly IStringLocalizer<NMIController> _localizer;

        public NMIController(IMediator mediator,
            NMIGatewayConfigs nmiGatewayConfigs,
            IUserAuthenticationProvider authenticationProvider,
            AppSetting appSetting,
            ILogger<NMIController> logger, IStringLocalizer<NMIController> localizer)
        {
            _mediator = mediator;
            this.nmiGatewayConfigs = nmiGatewayConfigs;
            this.authenticationProvider = authenticationProvider;
            this.appSetting = appSetting;
            _logger = logger;
            _localizer = localizer;
        }

        /// <summary>
        /// To get past transactions details from NMI
        /// </summary>
        /// <param name="command">Object of GetTransactionDetailsNMICommand</param>
        /// <returns>It will Return ResponseModel in the form of string</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_NMI_NMITransactionDetails")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("NMITransactionDetails")]
        public async Task<ActionResult<ResponseModel<string>>> NMITransactionDetails([FromQuery] GetTransactionDetailsNMICommand command)
        {
            return Ok(await _mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// To store Past transactions details from NMI in system
        /// </summary>
        /// <param></param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_NMI_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost]
        public async Task<ActionResult<ResponseModel>> SaveNMITransactionDetails()
        {
            return Ok(await _mediator.Send(new SaveNMITransactionDetailsCommand()).ConfigureAwait(false));
        }
    }
}
