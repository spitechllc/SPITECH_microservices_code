﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.PaymentGateWay.Application.Commands.SaveResellerConfig;
using SpiTech.PaymentGateWay.Application.Queries.GetResellerConfig;
using SpiTech.PaymentGateWay.Application.Queries.GetResellerConfigs;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.PaymentGateWay.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class ResellerConfigController : ControllerBase
    {
        private readonly IMediator _mediator;

        public ResellerConfigController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// To get reseller account details by resellerid
        /// </summary>
        /// <param name="resellerId">Varriable of int</param>
        /// <returns>It will return ResponseModel in the form of ResellerConfig</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_ResellerConfig_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("{resellerId}")]
        public async Task<ActionResult<ResponseModel<ResellerConfig>>> Get([FromRoute] int resellerId)
        {
            return Ok(await _mediator.Send(new GetResellerConfigQuery { ResellerId = resellerId }).ConfigureAwait(false));
        }

        /// <summary>
        /// to get all reseller account details
        /// </summary>
        /// <param name="configsQuery">Object of GetResellerConfigsQuery</param>
        /// <returns>It will return ResponseList in the form of ResellerConfigModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_ResellerConfig_AllResellerConfigs")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("AllResellerConfigs")]
        public async Task<ActionResult<ResponseList<ResellerConfigModel>>> GetAll([FromBody] GetResellerConfigsQuery configsQuery)
        {
            return Ok(await _mediator.Send(configsQuery).ConfigureAwait(false));
        }

        /// <summary>
        /// To save reseller account details in system
        /// </summary>
        /// <param name="model">object of SaveResellerConfigCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Paymentapi_ResellerConfig_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost()]
        public async Task<ActionResult<ResponseModel>> Save([FromBody] SaveResellerConfigCommand model)
        {
            return Ok(await _mediator.Send(model));
        }
    }
}
