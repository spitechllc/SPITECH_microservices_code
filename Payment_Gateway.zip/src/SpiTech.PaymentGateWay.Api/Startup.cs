using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using SpiTech.Application.Logging.Extensions;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.ApplicationCore.Security;
using SpiTech.ApplicationCore.ServiceCollection;
using SpiTech.PaymentGateWay.Application;
using SpiTech.PaymentGateWay.Infrastructure;
using SpiTech.Service.Clients;
using System;
using System.IO;
using System.Reflection;

namespace SpiTech.PaymentGateWay.Api
{
    public class Startup
    {
        public IConfiguration Configuration { get; }
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddLocalization(options => options.ResourcesPath = "Resources");
            services.AddControllersWithViews();

            services.AddApplicationCore(Configuration).AddInfrastructure(Configuration).AddApplication(Configuration);

            services.AddIdentityClient(Configuration).AddFinanceClient(Configuration).AddStoreClient(Configuration).AddTransactionClient(Configuration);

            services.AddAPIAuthentication(Configuration, "paymentapi");
            services.AddAPIAuthorization();

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "PaymentGateWay Api",
                    Version = "v1",
                    Description = "The Payment Gateway Microservice HTTP API.",
                });
                SwaggerGenSetup.Setup(options);
                string xmlfile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                string xmlpath = Path.Combine(AppContext.BaseDirectory, xmlfile);
                options.IncludeXmlComments(xmlpath);
            });
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseMiddleware(typeof(CustomResponseHeaderMiddleware));
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger().UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "SpiTech.PaymentGateWay.Api V1");
            });

            var supportedCultures = new[] { "en" };

            var requestLocalizationOptions = new RequestLocalizationOptions().SetDefaultCulture(supportedCultures[0]).AddSupportedCultures(supportedCultures).AddSupportedUICultures(supportedCultures);

            app.UseRequestLocalization(requestLocalizationOptions);

            app.UseStaticFiles();
            app.UseLogger();
            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();
            
            app.UseMiniProfiler();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}