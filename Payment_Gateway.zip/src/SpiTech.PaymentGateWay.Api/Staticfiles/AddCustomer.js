﻿$(document).on("click", "#customerButton", function () {
   
            var customerModel = {
                "userId": $('#hdnuserId').val(),
                "storeId": $('#hdnstoreId').val(),
                "firstName": $('#firstname').val(),
                "lastName": $('#lastname').val(),
                "email": $('#email').val(),
                "ipAddress": "",
                "address": $('#address').val(),
                "city": $('#city').val(),
                "state": $('#state').val(),
                "postalCode": $('#postalCode').val(),
                "dOB": $('#dob').val(),
                "ssn": $('#ssn').val()
               
            };

            $.ajax({
                type: "POST",
                url: window.location.origin+appSetting.gateWayPath + "/api/Payment/SaveCustomer",
                dataType: 'json',
                cors: true,
                secure: true,
                async: true,
                crossDomain: true,
                headers: {
                    "accept": "application/json",
                    "Access-Control-Allow-Origin": "*"
                },
                contentType: "application/json; charset=UTF-8",
                data: JSON.stringify(customerModel),
                beforeSend: function (xhr) {
                    xhr.setRequestHeader("Authorization", "Bearer  " + appSetting.accessToken);
                },
                success: function (res) {
                    if (!!res && res.success) {
                       // window.location.href = appSetting.gateWayPath + "/api/Payment/success";
                        if (customerModel.storeId > 0) { window.location.href = appSetting.gateWayPath + "/api/Payment/AddCardStore/" + customerModel.storeId + "?access_token=" + appSetting.accessToken;}
                        else {
                            window.location.href = appSetting.gateWayPath + "/api/Payment/AddCard/ACH?access_token=" + appSetting.accessToken;
                        }
                        
                    }
                    else {
                        console.log(res);
                        window.location.href = appSetting.gateWayPath + "/api/Payment/error";
                    }
                },
                error: function (xhr) {
                    console.log(xhr);
                    window.location.href = appSetting.gateWayPath + "/api/Payment/error";
                }
            });
        
   

    //setTimeout(function () {
    //    linkHandler.open();
    //}, 1000);
});