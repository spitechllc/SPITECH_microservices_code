﻿
if (window.addEventListener) {
    window.addEventListener("message",
        function (e) {
            var jsonData = e.data;
            if (typeof (jsonData) != "undefined") {
                if (typeof (jsonData) == "object" && jsonData.constructor.name == "Object") {
                    var source = jsonData.source;

                    console.log(jsonData);
                    if (typeof (source) != "undefined" && source == "iCheck") {

                        if (typeof (jsonData.error) != "undefined" && jsonData.error != null) {

                           // this.window.location.href = "/api/Payment/error";
                        }
                        else {
                            var model = {
                                "paymentMethodId": $('#hdnpaymentmethodid').val(),
                                "userId": $('#hdnUserid').val(),
                                "cardExpDate": jsonData.cardExpDate,
                                "cardNumber": jsonData.cardNumber,
                                "cardType": jsonData.cardType,
                                "accountNumber": jsonData.accountNumber,
                                "accountType": jsonData.accountType,
                                "routingNumber": jsonData.routingNumber,
                                "custId": jsonData.custId,
                                "operation": jsonData.operation,
                                "source": jsonData.source,
                                "token": jsonData.token
                            };

                            $.ajax({
                                type: "POST",
                                url: "/api/Payment/SaveToken",
                                contentType: "application/json",
                                data: JSON.stringify(model),
                                success: function (res) {
                                   // window.location.href = "/api/Payment/Success";
                                },
                                error: function (xhr) {
                                    // window.location.href ="/api/Payment/error"
                                }
                            });
                        }
                    }
                }
            }
        });
} else {
    window.attachEvent("onmessage",
        function (e) {
            console.log("Inside onmessage");
        });
}