﻿
    
//document.querySelector('#acceptButton').disabled = true;
//document.querySelector('#declineButton').disabled = false;

        //$('input[type=checkbox][name=termsCheckbox]').change(function () {
$(document).on("change", "#termsCheckbox", function () {
            if ($(this).is(':checked')) {
                document.querySelector('#acceptButton').disabled = false;
                document.querySelector('#declineButton').disabled = true;
            }
            else {
                document.querySelector('#acceptButton').disabled = true;
                document.querySelector('#declineButton').disabled = false;
            }
        });
   

    $(document).on("click", "#acceptButton", function () {   
        var ACHDetailsModel =
        {
            "userPaymentMethodId": $('#hdnuserpaymentmethodid').val(),
            "userId": $('#userid').val()
        };

        $.ajax({
            type: "POST",
            url: window.location.origin + appSetting.gateWayPath + "/api/Payment/ActivateACHAccount",
            dataType: 'json',
            cors: true,
            secure: true,
            async: true,
            crossDomain: true,
            headers: {
                "accept": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            contentType: "application/json; charset=UTF-8",
            data: JSON.stringify(ACHDetailsModel),
            beforeSend: function (xhr) {
                xhr.setRequestHeader("Authorization", "Bearer  " + appSetting.accessToken);
            },
            success: function (res) {
                if (!!res && res.success) {
                    window.location.href = appSetting.gateWayPath + "/api/Payment/success";
                }
                else {
                    console.log(res);
                    window.location.href = appSetting.gateWayPath + "/api/Payment/error";
                }
            },
            error: function (xhr) {
                console.log(xhr);
                window.location.href = appSetting.gateWayPath + "/api/Payment/error";
            }
        });
    });

    $(document).on("click", "#declineButton", function () {
        var ACHDetailsModel =
        {
            "userPaymentMethodId": $('#hdnuserpaymentmethodid').val(),
            "userId": $('#userid').val()
        };

        $.ajax({
            type: "POST",
            url: window.location.origin + appSetting.gateWayPath + "/api/Payment/DeleteACHBankDetails",
            dataType: 'json',
            cors: true,
            secure: true,
            async: true,
            crossDomain: true,
            headers: {
                "accept": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            contentType: "application/json; charset=UTF-8",
            data: JSON.stringify(ACHDetailsModel),
            beforeSend: function (xhr) {
                xhr.setRequestHeader("Authorization", "Bearer  " + appSetting.accessToken);
            },
            success: function (res) {
                if (!!res && res.success) {
                    window.location.href = appSetting.gateWayPath + "/api/Payment/achauthorizationdeclined";


                }
                else {
                    console.log(res);
                    window.location.href = appSetting.gateWayPath + "/api/Payment/error";
                }
            },
            error: function (xhr) {
                console.log(xhr);
                window.location.href = appSetting.gateWayPath + "/api/Payment/error";
            }
        });
    });
