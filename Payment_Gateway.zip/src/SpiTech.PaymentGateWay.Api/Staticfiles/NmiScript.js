﻿document.addEventListener('DOMContentLoaded', function () {
    CollectJS.configure({
        'callback': function (response) {
            //document.getElementById("paymentTokenInfo").innerHTML =
            //    '<b>Payment Token:</b> ' + response.token +
            //    '<br><b>Card:</b> ' + response.card.number +
            //    '<br><b>BIN/EIN:</b> ' + response.card.bin +
            //    '<br><b>Expiration:</b> ' + response.card.exp +
            //    '<br><b>Hash:</b> ' + response.card.hash +
            //    '<br><b>Card Type:</b> ' + response.card.type +
            //    '<br><b>Check Account Name:</b> ' + response.check.name +
            //    '<br><b>Check Account Number:</b> ' + response.check.account +
            //    '<br><b>Check Account Hash:</b> ' + response.check.hash +
            //    '<br><b>Check Routing Number:</b> ' + response.check.aba;

            if ($('#txtfname').val() == "") {
                alert("Please Enter First Name");
                return;
            }
            if ($('#txtlname').val() == "") {
                alert("Please Enter Last Name");
                return;
            }
            
            var model = {
                "paymentMethodId": $('#hdnpaymentmethodid').val(),
                "userId": $('#hdnUserid').val(),
                "cardname": $('#txtfname').val() + ' ' + $('#txtlname').val(),
                "cardExpDate": response.card.exp,
                "cardNumber": response.card.number,
                "cardType": response.card.type,
                "source": 'MNI',
                "token": response.token,
                "paymentGatewayId": $('#hdnpaymentgatewayid').val()
            };

            $.ajax({
                type: "POST",
                url: window.location.origin+appSetting.gateWayPath +"/api/Payment/SaveToken",
                dataType: 'json',
                cors: true,
                secure: true,
                async: true,
                crossDomain: true,
                headers: {
                    "accept": "application/json",
                    "Access-Control-Allow-Origin": "*"
                },
                contentType: "application/json; charset=UTF-8",
                data: JSON.stringify(model),
                beforeSend: function (xhr) {
                    xhr.setRequestHeader("Authorization", "Bearer  " + appSetting.accessToken);
                },
                success: function (res) {
                    if (!!res && res.success) {
                        if ($("#hdnTenantName").val() == "PapiPay") {
                            window.location.href = appSetting.gateWayPath + "/api/Payment/Success";
                        }
                        if ($("#hdnTenantName").val() == "Verifone") {
                            window.location.href = appSetting.gateWayPath + "/api/Payment/SuccessVerifone";
                        }
                        if ($("#hdnTenantName").val() == "Velocity") {
                            window.location.href = appSetting.gateWayPath + "/api/Payment/SuccessVelocity";
                        }
                        if ($("#hdnTenantName").val() == "THEStation") {
                            window.location.href = appSetting.gateWayPath + "/api/Payment/SuccessTheStation";
                        }
                        else {
                            window.location.href = appSetting.gateWayPath + "/api/Payment/Success";
                        }
                    } 
                    else {
                        window.location.href = appSetting.gateWayPath + "/api/Payment/error?message="+res.message;
                    }
                },
                error: function (xhr) {
                    console.log(xhr);
                    window.location.href = appSetting.gateWayPath + "/api/Payment/error";
                }
            });
        },
        variant: 'inline',
        googleFont: 'Abel',
        invalidCss: {
            color: '#B40E3E'
        },
        validCss: {
            color: '#14855F'
        },
        customCss: {
            'border-color': '#FFFFFF',
            'border-style': 'solid'
        },
        focusCss: {
            'border-color': '#1CC48B',
            'border-style': 'solid',
            'border-width': '3px'
        },
        fields: {
            cvv: {
                placeholder: 'CVV'
            },
            ccnumber: {
                placeholder: 'Credit Card'
            },
            ccexp: {
                placeholder: 'MM / YY'
            }
        }
    });

    $('#payButton').click(function () {
        var btn = $(this);
        var flag = false;
        $("#spnmsg").hide();
        if ($("#txtfname").val().trim() == "") {
            $("#spnmsg").text("First Name Required");
            $("#spnmsg").show();
            flag = true;
        }
        if ($("#txtlname").val().trim() == "") {
            $("#spnmsg").text("Last Name Required");
            $("#spnmsg").show();
            flag = true;
        }
        var reg_name_lastname = /^[a-zA-Z\s]*$/;
        if (!reg_name_lastname.test($('#txtlname').val()) || !reg_name_lastname.test($('#txtfname').val())) { 
            $("#spnmsg").text("First Name & Last Name Fields Allows Only Alphabate");
            $("#spnmsg").show();
            flag = true;
        }
        if ($("#txtfname").val().length > 20 || $("#txtlname").val().length > 20) {
            $("#spnmsg").text("First Name & Last Name Fields Allows Only 20 Characters");
            $("#spnmsg").show();
            flag = true;
        }
        if (flag) {
            return false;
        }
        $(btn).buttonLoader('start');
    });
});