﻿(async function () {
    var linkHandler = Plaid.create({
        // Make a request to your server to fetch a new link_token.
        token: appSetting.token,
        onLoad: function () {
            // The Link module finished loading.
        },
        onSuccess: function (public_token, metadata) {
            var paymentModel = {
                "paymentMethodId": $('#hdnpaymentmethodid').val(),
                "paymentGatewayId": $('#hdnpaymentgatewayid').val(),
                "storeId": $('#hdnStoreid').val(),
                "userId": $('#hdnUserid').val(),
                "publicToken": public_token,
                "accountID": metadata.account_id,
                "userName": $('#hdnusername').val(),
                "IsDwolla": $('#hdnisdwolla').val(),
            };

            $.ajax({
                type: "POST",
                url: window.location.origin+appSetting.gateWayPath + "/api/Payment/TransactionToken",
                dataType: 'json',
                cors: true,
                secure: true,
                async: true,
                crossDomain: true,
                headers: {
                    "accept": "application/json",
                    "Access-Control-Allow-Origin": "*"
                },
                contentType: "application/json; charset=UTF-8",
                data: JSON.stringify(paymentModel),
                beforeSend: function (xhr) {
                    xhr.setRequestHeader("Authorization", "Bearer  " + appSetting.accessToken);
                },
                success: function (res) {
                    if (!!res && res.success) {
                        window.location.href = appSetting.gateWayPath + "/api/Payment/Success";
                    }
                    else {
                        console.log(res);
                        window.location.href = appSetting.gateWayPath + "/api/Payment/error";
                    }
                },
                error: function (xhr) {
                    console.log(xhr);
                    window.location.href = appSetting.gateWayPath + "/api/Payment/error";
                }
            });
        },
        onExit: function (err, metadata) {
            if (err != null) {
            }
        },
    });

    setTimeout(function () {
        linkHandler.open();
    }, 1000);
})();