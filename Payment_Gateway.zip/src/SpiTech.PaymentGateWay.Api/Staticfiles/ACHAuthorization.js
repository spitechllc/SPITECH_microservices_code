﻿$(document).on("click", "#acceptButton", function () {
   
    //var achAuthorizationModel = {
    //    "UserId": $('#hdnuserid').val(),
    //    "UserPaymentMethodId": $('#hdnuserpaymentmethodid').val()               
    //};
    var terms = $('#termsCheckbox').val();
            //$.ajax({
            //    type: "POST",
            //    url: window.location.origin + appSetting.gateWayPath + "/api/Payment/SaveTokenACH",
            //    dataType: 'json',
            //    cors: true,
            //    secure: true,
            //    async: true,
            //    crossDomain: true,
            //    headers: {
            //        "accept": "application/json",
            //        "Access-Control-Allow-Origin": "*"
            //    },
            //    contentType: "application/json; charset=UTF-8",
            //    data: JSON.stringify(achAuthorizationModel),
            //    beforeSend: function (xhr) {
            //        xhr.setRequestHeader("Authorization", "Bearer  " + appSetting.accessToken);
            //    },
            //    success: function (res) {
            //        if (!!res && res.success) {
                        window.location.href = appSetting.gateWayPath + "/api/Payment/success";
                      
                        
                //    }
                //    else {
                //        console.log(res);
                //        window.location.href = appSetting.gateWayPath + "/api/Payment/error";
                //    }
                //},
                //error: function (xhr) {
                //    console.log(xhr);
                //    window.location.href = appSetting.gateWayPath + "/api/Payment/error";
                //}
           // });
        
   
});

$(document).on("click", "#declineButton", function () {

    var achAuthorizationModel = {
        "UserId": $('#hdnuserid').val(),
        "UserPaymentMethodId": $('#hdnuserpaymentmethodid').val()
    };

    $.ajax({
        type: "POST",
        url: window.location.origin + appSetting.gateWayPath + "/api/Payment/DeleteACHBankDetails",
        dataType: 'json',
        cors: true,
        secure: true,
        async: true,
        crossDomain: true,
        headers: {
            "accept": "application/json",
            "Access-Control-Allow-Origin": "*"
        },
        contentType: "application/json; charset=UTF-8",
        data: JSON.stringify(achAuthorizationModel),
        beforeSend: function (xhr) {
            xhr.setRequestHeader("Authorization", "Bearer  " + appSetting.accessToken);
        },
        success: function (res) {
            if (!!res && res.success) {
                window.location.href = appSetting.gateWayPath + "/api/Payment/success";
               

            }
            else {
                console.log(res);
                window.location.href = appSetting.gateWayPath + "/api/Payment/error";
            }
        },
        error: function (xhr) {
            console.log(xhr);
            window.location.href = appSetting.gateWayPath + "/api/Payment/error";
        }
    });

});