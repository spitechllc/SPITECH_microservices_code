﻿using AutoMapper;
using FluentValidation;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.ApplicationCore.AppSettingsConfigLoader;
using SpiTech.PaymentGateWay.Application.Services;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Infrastructure.Services;
using SpiTech.PaymentGateWay.Infrastructure.UnitOfWorks;
using System.Reflection;

namespace SpiTech.PaymentGateWay.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            string connectionString = configuration.GetConnectionString("PaymentGateWay");
            services
                .AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());

            services.AddScoped<IUnitOfWork, UnitOfWork>(serviceProvider => new UnitOfWork(connectionString, serviceProvider));

            services.AddConfig<GcsConfig>(configuration);
            services.AddScoped<IAuroraGcsService, AuroraGcsService>();
            return services;
        }
    }
}
