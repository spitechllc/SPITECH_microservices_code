﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.PaymentGateWay.Application.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Infrastructure.Repositories
{
    public class UserAchPaymentRepository : Repository<UserAchPayment>, IUserAchPaymentRepository
    {
        public UserAchPaymentRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<bool> UpdateNachaFilePath(int userAchPaymentId, string nachaFilePath, string nachaFileName)
        {
            DynamicParameters dynamicParams = new();

            dynamicParams.Add("UserAchPaymentId", userAchPaymentId);
            dynamicParams.Add("NachaFilePath", nachaFilePath);
            dynamicParams.Add("NachaFileName", nachaFileName);
            dynamicParams.Add("UpdatedBy", GetActionUserId());

            string query = $"Update [dbo].[UserAchPayment] Set NachaFilePath = @NachaFilePath, NachaFileName=@NachaFileName, UpdatedOn=getUtcdate(), UpdatedBy=@UpdatedBy   WHERE UserAchPaymentId = @UserAchPaymentId ";

            int result = await DbConnection.ExecuteAsync(query, dynamicParams, DbTransaction);

            return result > 0;
        }

        public async Task<bool> UpdateNachaFileUploadStatus(int userAchPaymentId, bool status, string error)
        {
            DynamicParameters dynamicParams = new();

            dynamicParams.Add("UserAchPaymentId", userAchPaymentId);
            dynamicParams.Add("IsNachaUploaded", status ? 1 : 0);
            dynamicParams.Add("NachaUploadError", error);
            dynamicParams.Add("UpdatedBy", GetActionUserId());

            string query = $"Update [dbo].[UserAchPayment] Set IsNachaUploaded = @IsNachaUploaded, NachaUploadError=@NachaUploadError, UpdatedOn=getUtcdate(), UpdatedBy=@UpdatedBy  WHERE UserAchPaymentId = @UserAchPaymentId ";

            int result = await DbConnection.ExecuteAsync(query, dynamicParams, DbTransaction);

            return result > 0;
        }
    }
}
