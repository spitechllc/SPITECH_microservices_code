﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.PaymentGateWay.Application.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.FilterOptions;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Infrastructure.Repositories
{
    public class PreAuthPaymentRepository : Repository<PreAuthPayment>, IPreAuthPaymentRepository
    {

        public PreAuthPaymentRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<PreAuthPaymentModel> GetByConfirmationNumber(string preAuthConfirmationNo)
        {
            DynamicParameters para = new();

            para.Add("preAuthConfirmationNo", preAuthConfirmationNo);

            return (await DbConnection.QueryAsync<PreAuthPaymentModel>(
                $@"select pa.*  from PreAuthPayment  pa                      
                      where pa.PreAuthConfirmationNo =@preAuthConfirmationNo and pa.IsActive=1",
                para, DbTransaction)).FirstOrDefault();
        }

        public async Task<IEnumerable<PreAuthPaymentModel>> GetPaymentHistoryByFilter(PaymentFilter filter,
            Paginable paginable, Sortable sortable)
        {

            //var list = await this.DbConnection.QueryAsync<PreAuthPaymentModel>("GetPaymentHistory", new
            //{
            //    UserPaymentMethodId = filter.UserPaymentMethodId,
            //    UserId = filter.UserId,
            //    PaymentDate = filter.PaymentDate == null ? "" : filter.PaymentDate,
            //    CardType = filter.CardType == null ? "" : filter.CardType,
            //    AccountType = filter.AccountType == null ? "" : filter.AccountType,
            //    SkipRow = paginable.Skip ?? 0,
            //    PageSize = paginable.Take ?? 0,
            //}, this.DbTransaction, null, CommandType.StoredProcedure);

            return await Task.FromResult(new List<PreAuthPaymentModel>());
        }

        public async Task Update(int storeId, string siteId, string storeName)
        {
            DynamicParameters dynamicParams = new();
            dynamicParams.Add("StoreId", storeId);
            dynamicParams.Add("SiteId", siteId);
            dynamicParams.Add("StoreName", storeName);

            await DbConnection.ExecuteAsync($"UpdateSite", dynamicParams, DbTransaction, commandType: System.Data.CommandType.StoredProcedure);
        }
    }
}
