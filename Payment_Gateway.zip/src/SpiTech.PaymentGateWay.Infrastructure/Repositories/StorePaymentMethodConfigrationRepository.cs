﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.PaymentGateWay.Application.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Infrastructure.Repositories
{
    public class StorePaymentMethodConfigrationRepository : Repository<StorePaymentMethodConfigration>, IStorePaymentMethodConfigrationRepository
    {
        public StorePaymentMethodConfigrationRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<StorePaymentMethodConfigration> GetByFilter(int StoreId, int PaymentGatewayConfigId)
        {
            string query = @$"select * from StorePaymentMethodConfigration
                             where StoreId =@StoreId 
                             and PaymentGatewayConfigId =@PaymentGatewayConfigId";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("StoreId", StoreId);
            dynamicParams.Add("PaymentGatewayConfigId", PaymentGatewayConfigId);

            return (await DbConnection.QueryAsync<StorePaymentMethodConfigration>(query, dynamicParams, DbTransaction)).FirstOrDefault();
        }

        public async Task<List<StorePaymentMethodConfigration>> GetByFilterByStoreId(int StoreId)
        {
            string query = @$"select * from StorePaymentMethodConfigration
                             where StoreId =@StoreId";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("StoreId", StoreId);

            return (await DbConnection.QueryAsync<StorePaymentMethodConfigration>(query, dynamicParams, DbTransaction)).ToList();
        }

        public async Task<StorePaymentMethodConfigration> GetByPreAuthConfirmation(string preAuthConfirmation)
        {
            StringBuilder sb = new();
            DynamicParameters para = new();
            para.Add("preAuthConfirmation", preAuthConfirmation);

            sb.Append(@"select pc.* 
                        from [dbo].[PreAuthPayment] pre
                        inner join [dbo].[UserPaymentMethod] up on pre.UserPaymentMethodId = up.UserPaymentMethodId
                        INNer jOIn StorePaymentMethodConfigration pc on pc.StoreId= pre.StoreId
                        and pc.PaymentGatewayConfigId = up.PaymentGatewayConfigId
                        Where pre.PreAuthConfirmationNo=@preAuthConfirmation"
                      );

            return (await DbConnection.QueryAsync<StorePaymentMethodConfigration>(sb.ToString(), para, DbTransaction)).FirstOrDefault();
        }
    }
}
