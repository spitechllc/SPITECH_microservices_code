﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.PaymentGateWay.Application.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Infrastructure.Repositories
{
    public class NmiTransactionDetailsRepository : Repository<NMITransactionDetails>, INmiTransactionDetailsRepository
    {
        public NmiTransactionDetailsRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<NMITransactionsDetailsModel> GetByFilter(int nmiTransactionFileId, IEnumerable<NmiTransactionModel> nmiTransactions)
        {
            NMITransactionsDetailsModel nm = new();
            int result = await DbConnection.ExecuteAsync("UpdateNmiTransactions", new { NmiTransactionFileId = nmiTransactionFileId, NmiTransactions = nmiTransactions.ToDataTable("NmiTransactionFileId") }, DbTransaction, commandType: System.Data.CommandType.StoredProcedure);

            return nm;
        }
    }
}
