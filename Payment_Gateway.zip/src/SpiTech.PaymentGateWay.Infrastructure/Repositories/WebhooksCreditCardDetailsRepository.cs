﻿using AutoMapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.PaymentGateWay.Application.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;

namespace SpiTech.PaymentGateWay.Infrastructure.Repositories
{
    public class WebhooksCreditCardDetailsRepository : Repository<WebhooksCreditCardDetails>, IWebhooksCreditCardDetailsRepository
    {
        public WebhooksCreditCardDetailsRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
    }
}
