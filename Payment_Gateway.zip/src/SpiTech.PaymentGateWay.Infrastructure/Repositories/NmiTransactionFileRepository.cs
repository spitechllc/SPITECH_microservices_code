﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.PaymentGateWay.Application.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Infrastructure.Repositories
{
    public class NmiTransactionFileRepository : Repository<NmiTransactionFile>, INmiTransactionFileRepository
    {
        public NmiTransactionFileRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<NmiTransactionFile> GetByFileId(string fileId)
        {
            StringBuilder sb = new();
            DynamicParameters para = new();
            para.Add("FileId", fileId);

            sb.Append("Select * from NmiTransactionFile where FileId = @FileId");

            return await DbConnection.QueryFirstOrDefaultAsync<NmiTransactionFile>(sb.ToString(), para, DbTransaction);
        }
    }
}
