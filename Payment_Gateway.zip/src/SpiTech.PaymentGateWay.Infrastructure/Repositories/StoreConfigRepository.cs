﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.PaymentGateWay.Application.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Infrastructure.Repositories
{
    public class StoreConfigRepository : Repository<StoreConfig>, IStoreConfigRepository
    {
        public StoreConfigRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<IEnumerable<StoreConfigModel>> GetByFilter(int[] storeIds)
        {
            string query = @$"select * from StoreConfig
                             where IsActive =1 and (StoreId in @storeIds) or IsMasterAccount = 1 ";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("storeIds", storeIds);

            return await DbConnection.QueryAsync<StoreConfigModel>(query, dynamicParams, DbTransaction);
        }

        public async Task<IEnumerable<StoreConfigModel>> GetMasterStoreConfigs()
        {
            string query = @$"select * from StoreConfig
                             where IsActive = 1 and IsMasterAccount = 1 ";

            return await DbConnection.QueryAsync<StoreConfigModel>(query, null, DbTransaction);
        }
    }
}
