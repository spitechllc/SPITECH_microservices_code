﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.PaymentGateWay.Application.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.FilterOptions;
using SpiTech.PaymentGateWay.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Infrastructure.Repositories
{
    public class PaymentRepository : Repository<Payment>, IPaymentRepository
    {
        public PaymentRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<List<Payment>> GetallFailurePayments()
        {
            StringBuilder sb = new();

            sb.Append(@" declare @maxretrycount int    
                        Select @maxretrycount = maxretrycount from PaymentConfigration where IsActive = 1; 
                        SELECT * from payment P where P.Success =0
                        WHERE P.nextretrydatetime < GETUTCDATE()
                        AND P.retrycount < @maxretrycount
                        ORDER BY P.retrycount ASC "
               );

            return (await DbConnection.QueryAsync<Payment>(sb.ToString(), null, DbTransaction)).ToList();
        }

        public async Task<List<PaymentFilterModel>> GetByfilter(PaymentFilter filter, Sortable sortable)
        {
            StringBuilder sb = new();

            DynamicParameters para = new();
            sb.Append(@" SELECT 
	               pre.[PreAuthPaymentId]
                  ,Count(1) over() as TotalRecord
                  ,pre.[UserPaymentMethodId]
                  ,pre.[StoreId]
                  ,pre.[UserId]
                  ,pre.[PreAuthStatus]
                  ,pre.[SiteId]
                  ,pre.[FirstName]
                  ,pre.[LastName]
                  ,pre.[PhoneNumber]
                  ,pre.[Street1]
                  ,pre.[Street2]
                  ,pre.[PreAuthConfirmationNo]
                  ,pre.[City]
                  ,pre.[State]
                  ,pre.[Zipcode]
                  ,pre.[CardNumber]
                  ,pre.[CardExpiry]
                  ,pre.[Amount]
                  ,pre.[Description]
                  ,pre.[Email]
                  ,pre.[CompanyAccount]
                  ,pre.[CompanyName]
                  ,pre.[PaymentDate]
                  ,pre.[Custom1]
                  ,pre.[Custom2]
                  ,pre.[Custom3]
                  ,pre.[CardType]
                  ,pre.[AccountType]
                  ,pre.[BankName]
                  ,pre.[AccountNumber]                  
                  ,pre.[ConsumerIP]
	              ,p.[PaymentId]      
                  ,p.[TransactionId]
                  ,p.[UMTI]      
                  ,p.[Amount] as PayAmount
                  ,p.[Description] PayDescription            
                  ,p.[FailureReason]      
                  ,p.[FinalPayment]
	 
	             FROM [dbo].[PreAuthPayment] pre
	             left join payment  p on pre.preauthPaymentId = p.preAuthPaymentId
	             where pre.IsActive= 1");



            if (filter != null)
            {
                if (filter.UserId > 0)
                {
                    sb.Append(" AND pre.UserId =@userid");
                    para.Add("userid", filter.UserId);
                }

                if (filter.StartDate.HasValue && filter.EndDate.HasValue)
                {
                    sb.Append(" AND cast( p.CreatedOn as date) between cast( @startdate as date) and cast( @enddate as date)");
                    para.Add("startdate", filter.StartDate.Value);
                    para.Add("enddate", filter.EndDate.Value);
                }

                if (filter.TransactionId > 0)
                {
                    sb.Append(" AND p.TransactionId =@TransactionId");
                    para.Add("TransactionId", filter.TransactionId);
                }

                if (!string.IsNullOrEmpty(filter.confirmationNumber))
                {
                    sb.Append(" AND pre.PreAuthConfirmationNo =@PreAuthConfirmationNo");
                    para.Add("PreAuthConfirmationNo", filter.confirmationNumber);
                }
            }

            if (!string.IsNullOrEmpty(sortable.SortBy) && !string.IsNullOrEmpty(sortable.SortOrder))
            {

                if (sortable.SortBy == "CreatedOn")
                {
                    sb.Append($" order by p.CreatedOn desc");
                }
                else
                {
                    sb.Append($" order by {sortable.SortBy}  {sortable.SortOrder}");
                }
            }
            else
            {
                sb.Append($" order by Pre.Createdon desc ");
            }

            if (filter != null && filter.PageIndex.HasValue && filter.PageSize.HasValue && filter.PageSize.Value > 0)
            {
                int skipvalue = (filter.PageIndex.Value - 1) * filter.PageSize.Value;
                sb.Append($" OFFSET {skipvalue} ROWS FETCH NEXT {filter.PageSize.Value} ROWS ONLY");
            }

            return (await DbConnection.QueryAsync<PaymentFilterModel>(sb.ToString(), para, DbTransaction)).ToList();
        }

        public async Task<Payment> GetByPreAuthPaymentId(int preauthpaymentid)
        {
            StringBuilder sb = new();
            DynamicParameters para = new();
            para.Add("preauthpaymentid", preauthpaymentid);

            sb.Append($"Select * from Payment where PreAuthPaymentId=@preauthpaymentid");

            return (await DbConnection.QueryAsync<Payment>(sb.ToString(), para, DbTransaction)).FirstOrDefault();
        }

        public async Task<decimal> GetUserDueAmount(int userId)
        {
            StringBuilder sb = new();
            DynamicParameters parameters = new();
            parameters.Add("userId", userId);

            sb.Append(@"SELECT Sum(PAY.Amount - ISNULL(PAY.WalletAmount, 0) - ISNULL(PAY.CardAmount, 0)) AS AmountDue
                        FROM     Payment AS PAY INNER JOIN
                        PreAuthPayment AS PA ON PAY.PreAuthPaymentId = PA.PreAuthPaymentId
                        WHERE  (PA.IsPaymentRequired = 1) AND (PA.UserId = @userId)");

            return await DbConnection.ExecuteScalarAsync<decimal>(sb.ToString(), parameters, DbTransaction);
        }

        public async Task<Payment> GetPaymentByTransactionId(long TransactionId)
        {
            StringBuilder sb = new();

            sb.Append($"Select * from Payment where TransactionId=@TransactionId");

            DynamicParameters para = new();

            para.Add("TransactionId", TransactionId);

            return (await DbConnection.QueryAsync<Payment>(sb.ToString(), para, DbTransaction)).FirstOrDefault();
        }

        public async Task<List<PaymentReportModel>> GetFailedPaymentByFilter(PaymentFilter filter, Sortable sortable)
        {
            try
            {
                StringBuilder sb = new();

                DynamicParameters para = new();
                sb.Append(@"Select Count(1) over() as TotalRecord 
                        ,* from(select  PA.PreAuthConfirmationNo   
                        , PA.UserPaymentMethodId   
                        , PA.PaymentGatewayConfigId   
                        , PA.PaymentMethodId   
                        , PA.StoreId   
                        , PA.SiteId   
                        , PA.PreAuthDate   
                        , PA.CardNumber   
                        , PA.CardType   
                        , PA.AccountNumber   
                        , PA.AccountType   
                        , PA.BankName   
                        , PA.ConsumerIP      
                        , PA.CardPreAuthConfirmationNo 
                        , PA.WalletPreAuthConfirmationNo   
                        , PA.IsPaymentRequired 
                        , PA.UserId as PreAuthUserId  
                        , PA.Amount as PreAuthAmount  
                        , PA.[Description] as PreAuthDescription  
                        , PA.Success as PreAuthSuccess  
                        , PA.CardAmount as PreAuthCardAmount  
                        , PA.CardResponse as PreAuthCardResponse  
                        , PA.WalletAmount as PreAuthWalletAmount  
                        , PA.WalletResponse as PreAuthWalletResponse  
                        , 0 as PaymentId   
                        , PA.PreAuthPaymentId   
                        , PA.UserId   
                        , PA.TransactionId   
                        , PA.[Description]   
                        , PA.Amount   
                        , PA.WalletAmount   
                        , PA.CardAmount   
                        , PA.CardResponse   
                        , PA.WalletResponse   
                        , PA.Success   
                        , '' CardConfirmationNumber   
                        , 0 CardPayRetryCount   
                        , null as CardPayLastRetry 
                        , PA.Createdon
                        from [PreAuthPayment] PA 
                        where PA.Success=0

						union

						select PA.PreAuthConfirmationNo   
                        , PA.UserPaymentMethodId   
                        , PA.PaymentGatewayConfigId   
                        , PA.PaymentMethodId   
                        , PA.StoreId   
                        , PA.SiteId   
                        , PA.PreAuthDate   
                        , PA.CardNumber   
                        , PA.CardType   
                        , PA.AccountNumber   
                        , PA.AccountType   
                        , PA.BankName   
                        , PA.ConsumerIP      
                        , PA.CardPreAuthConfirmationNo 
                        , PA.WalletPreAuthConfirmationNo   
                        , PA.IsPaymentRequired 
                        , PA.UserId as PreAuthUserId  
                        , PA.Amount as PreAuthAmount  
                        , PA.[Description] as PreAuthDescription  
                        , PA.Success as PreAuthSuccess  
                        , PA.CardAmount as PreAuthCardAmount  
                        , PA.CardResponse as PreAuthCardResponse  
                        , PA.WalletAmount as PreAuthWalletAmount  
                        , PA.WalletResponse as PreAuthWalletResponse  
                        , P.PaymentId   
                        , P.PreAuthPaymentId   
                        , P.UserId   
                        , P.TransactionId   
                        , P.[Description]   
                        , P.Amount   
                        , P.WalletAmount   
                        , P.CardAmount   
                        , P.CardResponse   
                        , P.WalletResponse   
                        , P.Success   
                        , P.CardConfirmationNumber   
                        , P.CardPayRetryCount   
                        , P.CardPayLastRetry  
                        , P.Createdon
                        from [PreAuthPayment] PA inner join [Payment] P on PA.PreAuthPaymentId=P.PreAuthPaymentId 
                        where P.Success=0)t where 1=1 ");

                if (filter != null)
                {
                    if (filter.UserId > 0)
                    {
                        sb.Append(" AND UserId =@userid");
                        para.Add("userid", filter.UserId);
                    }

                    if (filter.StartDate.HasValue && filter.EndDate.HasValue)
                    {
                        sb.Append(" AND cast( CreatedOn as date) between cast( @startdate as date) and cast( @enddate as date)");
                        para.Add("startdate", filter.StartDate.Value);
                        para.Add("enddate", filter.EndDate.Value);
                    }

                    //if (!string.IsNullOrEmpty(filter.StoreName))
                    //{
                    //    sb.Append(" AND PA.custom2 like '%@storename%'");
                    //    para.Add("storename", filter.StoreName);
                    //}
                    if (filter.IsPaymentRequired.HasValue)
                    {
                        sb.Append(" AND IsPaymentRequired =@IsPaymentRequired");
                        para.Add("IsPaymentRequired", filter.IsPaymentRequired.Value);
                    }

                    if (filter.TransactionId > 0)
                    {
                        sb.Append(" AND TransactionId =@TransactionId");
                        para.Add("TransactionId", filter.TransactionId);
                    }

                    if (!string.IsNullOrEmpty(filter.confirmationNumber))
                    {
                        sb.Append(" AND PreAuthConfirmationNo =@PreAuthConfirmationNo");
                        para.Add("PreAuthConfirmationNo", filter.confirmationNumber);
                    }
                }

                if (!string.IsNullOrEmpty(sortable.SortBy) && !string.IsNullOrEmpty(sortable.SortOrder))
                {

                    if (sortable.SortBy == "CreatedOn")
                    {
                        sb.Append($" order by CreatedOn desc");
                    }
                    else
                    {
                        sb.Append($" order by {sortable.SortBy}  {sortable.SortOrder}");
                    }
                }
                else
                {
                    sb.Append($" order by Createdon desc ");
                }
                if (filter != null && filter.PageIndex.HasValue && filter.PageSize.HasValue && filter.PageSize.Value > 0)
                {
                    int skipvalue = (filter.PageIndex.Value - 1) * filter.PageSize.Value;
                    sb.Append($" OFFSET {skipvalue} ROWS FETCH NEXT {filter.PageSize.Value} ROWS ONLY");
                }


                return (await DbConnection.QueryAsync<PaymentReportModel>(sb.ToString(), para, DbTransaction)).ToList();
            }
            catch (Exception) { return null; };
        }

        public async Task<IEnumerable<UserAchNachaProcessingModel>> GetUserAchNachaProcessingAccounts()
        {
            StringBuilder sb = new();

            sb.Append($@"SELECT UPM.AccountNumber as AccountNo, Case When UPM.AccountType='checking' then 1 else 0 end AS IsChecking, UPM.RoutingNumber as RoutingNo, UPM.UserId, P.PaymentId, PP.StoreId, PP.StoreName, P.CardAmount AS Amount, UPM.UserPaymentMethodId
                FROM        Payment AS P
                INNER JOIN  PreAuthPayment AS PP ON P.PreAuthPaymentId = PP.PreAuthPaymentId
                INNER JOIN  UserPaymentMethod AS UPM ON PP.UserPaymentMethodId = UPM.UserPaymentMethodId
                WHERE(PP.PaymentGatewayConfigId = 3) AND(P.CardPaymentStatusId = 1)");

            return (await DbConnection.QueryAsync<UserAchNachaProcessingModel>(sb.ToString(), null, DbTransaction)).ToList();
        }

        public async Task<bool> UpdatePaid(int[] paymentIds, bool success, string cardPaymentErrorMessage)
        {
            DynamicParameters dynamicParams = new();

            dynamicParams.Add("PaymentIds", paymentIds);
            dynamicParams.Add("CardPayErrorMessage", cardPaymentErrorMessage);
            dynamicParams.Add("CardPaymentStatusId", success ? (int)EnumPaymentStatus.Success : EnumPaymentStatus.Fail);
            dynamicParams.Add("UpdatedBy", GetActionUserId());

            string query = $"Update [dbo].[Payment] Set CardPaymentStatusId = @CardPaymentStatusId, CardPayRetryCount=(CardPayRetryCount+1), CardPayLastRetry=getutcdate(), CardPayErrorMessage=@CardPaymentErrorMessage,UpdatedOn=getutcdate(), UpdatedBy=@UpdatedBy WHERE PaymentId in @PaymentIds ";

            int result = await DbConnection.ExecuteAsync(query, dynamicParams, DbTransaction);

            return result > 0;
        }
    }
}
