﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.PaymentGateWay.Application.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Infrastructure.Repositories
{
    public class ResellerConfigRepository : Repository<ResellerConfig>, IResellerConfigRepository
    {
        public ResellerConfigRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<IEnumerable<ResellerConfigModel>> GetByFilter(int[] resellerIds)
        {
            string query = @$"select * from ResellerConfig where IsActive =1 and ResellerId in @resellerIds";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("resellerIds", resellerIds);

            return await DbConnection.QueryAsync<ResellerConfigModel>(query, dynamicParams, DbTransaction);
        }
    }
}
