﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.PaymentGateWay.Application.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Infrastructure.Repositories
{
    public class NmiTransactionDetailsActionRepository : Repository<NMITransactionDetailsAction>, INmiTransactionDetailsActionRepository
    {
        public NmiTransactionDetailsActionRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<List<NMITransactionDetailsActionModel>> GetActionByTransactionDetailId(int nmiTransactionDetailsId)
        {
            NMITransactionDetailsActionModel nmAction = new();
            
            
            return await Task.FromResult(new List<NMITransactionDetailsActionModel>()) ;
        }
    }
}
