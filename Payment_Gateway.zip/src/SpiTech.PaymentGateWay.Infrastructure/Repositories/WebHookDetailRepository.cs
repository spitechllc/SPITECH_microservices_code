﻿using AutoMapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.PaymentGateWay.Application.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;

namespace SpiTech.PaymentGateWay.Infrastructure.Repositories
{
    public class WebHookDetailRepository : Repository<WebHookDetail>, IWebHookDetailRepository
    {
        public WebHookDetailRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
    }
}
