﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.PaymentGateWay.Application.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Infrastructure.Repositories
{
    public class SaleAgentConfigRepository : Repository<SaleAgentConfig>, ISaleAgentConfigRepository
    {
        public SaleAgentConfigRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<IEnumerable<SaleAgentConfigModel>> GetByFilter(int[] saleAgentIds)
        {
            string query = @$"select * from SaleAgentConfig where IsActive =1 and SaleAgentId in @saleAgentIds";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("saleAgentIds", saleAgentIds);

            return await DbConnection.QueryAsync<SaleAgentConfigModel>(query, dynamicParams, DbTransaction);
        }
    }
}
