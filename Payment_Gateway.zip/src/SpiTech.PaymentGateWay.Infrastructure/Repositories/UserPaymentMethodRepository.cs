﻿using Dapper;
using SpiTech.ApplicationCore.Database;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.PaymentGateWay.Application.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Infrastructure.Repositories
{
    public class UserPaymentMethodRepository : Repository<UserPaymentMethod>, IUserPaymentMethodRepository
    {
        public UserPaymentMethodRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<int> GetPaymentMethodCount(int userid)
        {
            string query = @$"select count(1) from UserPaymentMethod where Userid =@UserId";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("UserId", userid);

            return await DbConnection.QueryFirstOrDefaultAsync<int>(query, dynamicParams, DbTransaction);
        }

        public async Task<List<UserPaymentMethodModel>> Get(int[] userPaymentMethodIds)
        {
            string query = @$"select * from UserPaymentMethod where userPaymentMethodId in (select KeyValue from @userPaymentMethodIds) ";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("userPaymentMethodIds", userPaymentMethodIds.GetTableValuedParameter("[dbo].[UdtIntKeys]", "KeyValue"));

            return (await DbConnection.QueryAsync<UserPaymentMethodModel>(query, dynamicParams, DbTransaction)).ToList();
        }
        public async Task<List<UserPaymentMethod>> GetByUserId(int userid, int paymentmethodid)
        {
            string query = @$"select * from UserPaymentMethod where Userid =@UserId and IsActive=1";

            DynamicParameters dynamicParams = new();
            dynamicParams.Add("UserId", userid);

            if (paymentmethodid > 0)
            {
                query += @" and PaymentMethodId=@PaymentMethodId";

                dynamicParams.Add("PaymentMethodId", paymentmethodid);
            }

            return (await DbConnection.QueryAsync<UserPaymentMethod>(query, dynamicParams, DbTransaction)).ToList();
        }

        public async Task<UserPaymentMethod> GetDefaultByUserId(int userid)
        {
            string query = $"SELECT * FROM UserPaymentMethod where Userid =@Userid and IsDefault = 1";
            DynamicParameters para = new();
            para.Add("Userid", userid);
            return (await DbConnection.QueryAsync<UserPaymentMethod>(query, para, DbTransaction)).FirstOrDefault();
        }

        public async Task<bool> UpdateNickName(int userPaymentMethodId, string nickName)
        {
            DynamicParameters para = new();
            para.Add("UserPaymentMethodId", userPaymentMethodId);
            para.Add("NickName", nickName);
            para.Add("UpdatedBy", GetActionUserId());

            return (await DbConnection.ExecuteAsync(@$"Update UserPaymentMethod
                                 set NickName=@NickName,  UpdatedOn=getUtcdate(), UpdatedBy=@UpdatedBy
                                 Where UserPaymentMethodId =@UserPaymentMethodId", para, DbTransaction)) > 0;
        }

        public async Task<bool> InActivePaymentMethod(int userPaymentMethodId, bool isRemoveFromSource)
        {
            DynamicParameters para = new();
            para.Add("UserPaymentMethodId", userPaymentMethodId);
            para.Add("IsRemoved", isRemoveFromSource ? 1 : 0);
            para.Add("UpdatedBy", GetActionUserId());

            return (await DbConnection.ExecuteAsync(@$"Update UserPaymentMethod
                                 set IsActive=0,  UpdatedOn=getUtcdate(), UpdatedBy=@UpdatedBy,IsRemoved=@IsRemoved 
                                 Where UserPaymentMethodId =@UserPaymentMethodId", para, DbTransaction)) > 0;
        }

        public async Task<int> SetDefaultPaymentMethod(int userPaymentMethodId, int userid)
        {
            DynamicParameters para = new();
            para.Add("Userid", userid);
            para.Add("UserPaymentMethodId", userPaymentMethodId);
            para.Add("UpdatedBy", GetActionUserId());

            return await DbConnection.ExecuteAsync($" Update UserPaymentMethod Set IsDefault=0,  UpdatedOn=getUtcdate(), UpdatedBy=@UpdatedBy where Userid =@Userid and IsDefault=1; Update UserPaymentMethod Set IsDefault=1 where UserPaymentMethodId =@UserPaymentMethodId ", para, DbTransaction);
        }
        public async Task<UserPaymentMethod> GetDuplicateAccount(string accountNo,string routingNo,string accountType)
        {
            string query = $"SELECT * FROM UserPaymentMethod where AccountNumber =@AccountNumber and RoutingNumber = @RoutingNumber and AccountType=@AccountType";
            DynamicParameters para = new();
            para.Add("AccountNumber", accountNo);
            para.Add("RoutingNumber", routingNo);
            para.Add("AccountType", accountType);
            return (await DbConnection.QueryAsync<UserPaymentMethod>(query, para, DbTransaction)).FirstOrDefault();
        }
        public async Task<List<UserPaymentMethod>> GetAllFraudAccount(int userPaymentMethodId)
        {
            string query = $"SELECT * FROM UserPaymentMethod where IsFraud=true";
            DynamicParameters para = new();
            if (userPaymentMethodId > 0)
            {
                query += @" and UserPaymentMethodId=@UserPaymentMethodId";

                para.Add("UserPaymentMethodId", userPaymentMethodId);
            }
            return (await DbConnection.QueryAsync<UserPaymentMethod>(query, para, DbTransaction)).ToList();
        }

        public async Task<List<UserWithPaymentMethodModel>> GetAllUserPaymentMethod()
        {
            string query = $"select distinct UserId from UserPaymentMethod where UserId is not null and IsActive=1";
            DynamicParameters para = new();

            return (await DbConnection.QueryAsync<UserWithPaymentMethodModel>(query, para, DbTransaction)).ToList();
        }

        public async Task<List<UserPaymentMethod>> GetAllMopUser()
        {
            string query = $"select * from UserPaymentMethod where UserId is not null and IsActive=1";
            DynamicParameters para = new();

            return (await DbConnection.QueryAsync<UserPaymentMethod>(query, para, DbTransaction)).ToList();
        }
    }
}
