﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.PaymentGateWay.Application.Repositories;
using SpiTech.PaymentGateWay.Domain.Entities;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Infrastructure.Repositories
{
    public class DwollaCustomerRepository : Repository<DwollaCustomer>, IDwollaCustomerRepository
    {

        public DwollaCustomerRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<DwollaCustomer> GetById(int UserId, int StoreId)
        {

            StringBuilder sbquery = new();
            sbquery.Append("select * from DwollaCustomer where IsActive=1");
            DynamicParameters para = new();
            if (UserId > 0)
            {
                sbquery.Append($" and UserId=@UserId");
                para.Add("UserId", UserId);
            }

            if (StoreId > 0)
            {
                sbquery.Append($" and StoreId=@StoreId");
                para.Add("StoreId", StoreId);
            }
            return (await DbConnection.QueryAsync<DwollaCustomer>(sbquery.ToString(), para, DbTransaction)).FirstOrDefault();
        }
    }
}
