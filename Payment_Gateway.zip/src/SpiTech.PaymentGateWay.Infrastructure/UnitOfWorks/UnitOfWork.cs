﻿using AutoMapper;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.PaymentGateWay.Application.Repositories;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Infrastructure.Repositories;
using System.Data;

namespace SpiTech.PaymentGateWay.Infrastructure.UnitOfWorks
{
    public sealed class UnitOfWork : BaseUnitOfWork, IUnitOfWork
    {
        public UnitOfWork(string connectionString,
                           System.IServiceProvider serviceProvider,
                          IsolationLevel isolationLevel = IsolationLevel.ReadCommitted)
                          : base(connectionString, serviceProvider, isolationLevel)
        {
        }

        private IUserPaymentMethodRepository _userPaymentMethods = null;
        private IPaymentMethodRepository _paymentMethods = null;
        private IPreAuthPaymentRepository _preAuthPayments = null;
        private IPaymentRepository _payments = null;
        private IStorePaymentMethodConfigrationRepository _storePaymentMethodConfigrations = null;
        private IPaymentGatewayConfigRepository _paymentGatewayConfigs = null;
        private IDwollaCustomerRepository _dwollaCustomers = null;
        private IStoreConfigRepository _storeConfigs = null;
        private IWebhooksCreditCardDetailsRepository _webhooksCreditCardDetails = null;
        private IWebHookDetailRepository _webHookDetails = null;
        private IUserAchPaymentRepository _userAchPayments = null;
        private IUserAchPaymentDetailRepository _userAchPaymentDetails = null;
        private INmiTransactionRepository _nmiTransactions = null;
        private INmiTransactionFileRepository _nmiTransactionFiles = null;
        private INmiTransactionDetailsRepository _nmiTransactionDetails = null;
        private INmiTransactionDetailsActionRepository _nmiTransactionDetailsActions = null;
        private ISaleAgentConfigRepository _saleAgentConfigs = null;
        private IResellerConfigRepository _resellerConfigs = null;

        public INmiTransactionRepository NmiTransactions => _nmiTransactions ??= new NmiTransactionRepository(this, serviceProvider);
        public INmiTransactionFileRepository NmiTransactionFiles => _nmiTransactionFiles ??= new NmiTransactionFileRepository(this, serviceProvider);
        public IUserAchPaymentRepository UserAchPayments => _userAchPayments ??= new UserAchPaymentRepository(this, serviceProvider);
        

        public IUserAchPaymentDetailRepository UserAchPaymentDetails => _userAchPaymentDetails ??= new UserAchPaymentDetailRepository(this, serviceProvider);
        

        public IUserPaymentMethodRepository UserPaymentMethods => _userPaymentMethods ??= new UserPaymentMethodRepository(this, serviceProvider);
        public IPaymentMethodRepository PaymentMethods => _paymentMethods ??= new PaymentMethodRepository(this, serviceProvider);
        public IPreAuthPaymentRepository PreAuthPayments => _preAuthPayments ??= new PreAuthPaymentRepository(this, serviceProvider);
        public IPaymentRepository Payments => _payments ??= new PaymentRepository(this, serviceProvider);
        public IStorePaymentMethodConfigrationRepository StorePaymentMethodConfigrations => _storePaymentMethodConfigrations ??= new StorePaymentMethodConfigrationRepository(this, serviceProvider);
        public IPaymentGatewayConfigRepository PaymentGatewayConfigs => _paymentGatewayConfigs ??= new PaymentGatewayConfigRepository(this, serviceProvider);
        public IDwollaCustomerRepository DwollaCustomers => _dwollaCustomers ??= new DwollaCustomerRepository(this, serviceProvider);
  public IStoreConfigRepository StoreConfigs => _storeConfigs ??= new StoreConfigRepository(this, serviceProvider);
        public IWebhooksCreditCardDetailsRepository WebhooksCreditCardDetails => _webhooksCreditCardDetails ??= new WebhooksCreditCardDetailsRepository(this, serviceProvider);
        public IWebHookDetailRepository WebHookDetails => _webHookDetails ??= new WebHookDetailRepository(this, serviceProvider);

        public ISaleAgentConfigRepository SaleAgentConfigs => _saleAgentConfigs ??= new SaleAgentConfigRepository(this, serviceProvider);
        public INmiTransactionDetailsRepository NmiTransactionDetails => _nmiTransactionDetails ??= new NmiTransactionDetailsRepository(this, serviceProvider);

        public INmiTransactionDetailsActionRepository NmiTransactionDetailsActions => _nmiTransactionDetailsActions ??= new NmiTransactionDetailsActionRepository(this, serviceProvider);
        public IResellerConfigRepository ResellerConfigs => _resellerConfigs ??= new ResellerConfigRepository(this, serviceProvider);

        

        public override void ResetRepositories()
        {
            _userPaymentMethods = null;
            _paymentMethods = null;
            _preAuthPayments = null;
            _payments = null;
            _storePaymentMethodConfigrations = null;
            _paymentGatewayConfigs = null;
            _dwollaCustomers = null;
            _storeConfigs = null;
            _webhooksCreditCardDetails = null;
            _userAchPayments = null;
            _userAchPaymentDetails = null;
            _nmiTransactions = null;
            _nmiTransactionFiles = null;
            _saleAgentConfigs = null;
            _webHookDetails = null;
            _nmiTransactionDetails = null;
            _nmiTransactionDetailsActions = null;
            _resellerConfigs = null;
        }
    }
}
