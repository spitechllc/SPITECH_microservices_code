﻿using AutoMapper;
using CsvHelper;
using Google.Apis.Auth.OAuth2;
using Google.Cloud.Storage.V1;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.PaymentGateWay.Application.Services;
using SpiTech.PaymentGateWay.Application.UnitOfWorks;
using SpiTech.PaymentGateWay.Domain.Configs;
using SpiTech.PaymentGateWay.Domain.Entities;
using SpiTech.PaymentGateWay.Domain.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.PaymentGateWay.Infrastructure.Services
{
    internal class AuroraGcsService : IAuroraGcsService
    {
        private readonly ILogger<AuroraGcsService> logger;
        private readonly GcsConfig gcsConfig;
        private readonly IMapper mapper;
        private readonly IUnitOfWork context;
        private readonly IStorageService storageService;

        public AuroraGcsService(ILogger<AuroraGcsService> logger,
                                GcsConfig gcsConfig,
                                IStorageServiceFactory storageServiceFactory,
                                IMapper mapper,
                                IUnitOfWork context)
        {
            this.logger = logger;
            this.gcsConfig = gcsConfig;
            this.mapper = mapper;
            this.context = context;
            //this.storageService = storageServiceFactory.Get(ContainerType.AuroraGCSBucket);
        }

        public async Task<bool> ProcessFiles(CancellationToken stoppingToken)
        {
            if (!gcsConfig.Enabled)
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(gcsConfig.AuroraBucketName))
            {
                return false;
            }

            try
            {
                string gcsKeyFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", gcsConfig.AuthKeyFile);
                GoogleCredential credential = null;

                using (FileStream jsonStream = new(gcsKeyFilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    credential = GoogleCredential.FromStream(jsonStream);
                }

                if (credential != null)
                {
                    StorageClient storageClient = StorageClient.Create(credential);
                    var listObjects = storageClient.ListObjects(gcsConfig.AuroraBucketName, "");

                    foreach (Google.Apis.Storage.v1.Data.Object obj in listObjects)
                    {
                        var nmiTransactionFile = new NmiTransactionFile
                        {
                            Bucket = obj.Bucket,
                            ContentType = obj.ContentType,
                            FileCreationDate = obj.TimeCreated.Value.ToUniversalTime(),
                            FileId = obj.Id,
                            SelfLink = obj.SelfLink,
                            Name = obj.Name,
                            MediaLink = obj.MediaLink,
                            Size = (long)(obj.Size ?? 0),
                            IsActive = true,
                        };

                        var dbNmiTransactionFile = await context.NmiTransactionFiles.GetByFileId(nmiTransactionFile.FileId);

                        if (dbNmiTransactionFile == null)
                        {
                            try
                            {
                                string fileName = obj.Name.Replace(":", "");
                                //using FileStream outputFile = File.OpenWrite(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "GCS", fileName));
                                using Stream stream = new MemoryStream();
                                storageClient.DownloadObject(gcsConfig.AuroraBucketName, obj.Name, stream);
                                stream.Position = 0;
                                using var streamReader = new StreamReader(stream);
                                using var csvReader = new CsvReader(streamReader, CultureInfo.InvariantCulture);

                                var nmiTransactions = csvReader.GetRecords<NmiTransactionModel>().Where(t => t.TransactionDate != null || (!string.IsNullOrWhiteSpace(t.TransactionIdentifier))).ToList();

                                var invalidNmiTransactions = csvReader.GetRecords<NmiTransactionModel>().Where(t => t.TransactionDate == null || (string.IsNullOrWhiteSpace(t.TransactionIdentifier))).ToList();

                                if (invalidNmiTransactions != null && invalidNmiTransactions.Any())
                                {
                                    logger.Warn("Invalid Nmi Transactions from AuroraGcsService", invalidNmiTransactions);
                                }

                                nmiTransactionFile.NmiTransactionFileId = await context.NmiTransactionFiles.Add(nmiTransactionFile);
                                await context.NmiTransactions.BulkUpdate(nmiTransactionFile.NmiTransactionFileId, nmiTransactions);
                                //var nmiTransactionEntities = this.mapper.Map<List<NmiTransaction>>(nmiTransactions);

                                //foreach (var nmiTransactionEntity in nmiTransactionEntities)
                                //{
                                //    nmiTransactionEntity.NmiTransactionFileId = nmiTransactionFile.NmiTransactionFileId;
                                //    await context.NmiTransactions.Add(nmiTransactionEntity);
                                //}
                                context.Commit();
                            }
                            catch (Exception ex)
                            {
                                logger.Error(ex);

                                context.Rollback();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }

            return true;
        }

    }
}
