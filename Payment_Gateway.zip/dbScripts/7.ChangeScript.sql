
------------------------------------------------14-11-2022-Start---------------------------------

CREATE TABLE [dbo].[ResellerConfig]
(
	  [ResellerId] INT NOT NULL
	, [AccountName] [varchar](22) NOT NULL
	, [Bank] [varchar](23) NULL
	, [AccountNo] [varchar](17) NULL
	, [RoutingNo] [varchar](9) NULL
	, [IsChecking] BIT NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_ResellerConfig] PRIMARY KEY ([ResellerId] ASC)
)

GO


------------------------------------------------14-11-2022-End---------------------------------



----------------------------------NMI Change 14Nov2022 --------------------------------------------------------
Create Table [dbo].[NMITransactionDetails]
(
 	  [NMITransactionDetailsId]  INT NOT NULL IDENTITY(1,1)
	, [TransactionId] INT NOT NULL
	, [TransactionType] [varchar](22) NOT NULL
	, [Condition] [varchar](10) NULL
	, [City] [varchar](50) NULL
	, [State] [varchar](22) NOT NULL
	, [PostalCode] [varchar](10) NULL
	, [Country] [varchar](17) NULL
	, [ProcessorId] [varchar](50) NULL
	, [Tax] decimal(18,2) NOT NULL
	, [Currency][varchar](50) NULL
	, [CcType] [varchar](50) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_NMITransactionDetails] PRIMARY KEY ([NMITransactionDetailsId] ASC)
)

Create Table [dbo].[NMITransactionDetailsAction]
(
 	  [NMITransactionDetailsActionId] INT NOT NULL IDENTITY(1,1)
	, [NMITransactionDetailsId] INT NOT NULL
	, [Amount] decimal(18,2) NOT NULL
	, [ActionType] [varchar](22) NOT NULL
	, [ActionDate] Datetime NULL
	, [Success] bit NULL
	, [IpAddress] [varchar](22) NOT NULL
	, [ResponseCode] [varchar](10) NULL
	, [ProcessorResponseText] [varchar](500) NULL
	, [ProcessorResponseCode] [varchar](100) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_NMITransactionDetailsAction] PRIMARY KEY ([NMITransactionDetailsActionId] ASC)
)	

	Update [dbo].[PaymentGatewayConfig] set [GateWayName]='NMIPowerBI' where [PaymentGatewayConfigId]=5

	--------------------------------------end change 14Nov2022-----------------------------------------------------

	--------------------start changes 12 dec22-------
	Alter table [dbo].[UserPaymentMethod] alter column [AccountNumber] varchar(100)
Alter table [dbo].[UserPaymentMethod] alter column [RoutingNumber] varchar(100)

Alter table [dbo].[SaleAgentConfig] alter column [AccountNo] varchar(100)
Alter table [dbo].[SaleAgentConfig] alter column [RoutingNo] varchar(100)

Alter table [dbo].[ResellerConfig] alter column [AccountNo] varchar(100)
Alter table [dbo].[ResellerConfig] alter column [RoutingNo] varchar(100)

Alter table [dbo].[StoreConfig] alter column [AccountNo] varchar(100)
Alter table [dbo].[StoreConfig] alter column [RoutingNo] varchar(100)
----------------------------------end change 12 dec 22--------------------------------------------

-------------------------start changes 21 mar 23--------------------

Alter table [dbo].[UserPaymentMethod] add [IsFraud] bit null CONSTRAINT DF_UserPaymentMethod_IsFraud DEFAULT((0))

----------------------------------end change 23 mar 23--------------------------------------------

-------------------------start changes 24 mar 23--------------------

Alter table [dbo].[PreAuthPayment] alter column [AccountNumber] nvarchar(100)

---------------------------end change 24 mar 23----------------------------------


-------------------------start changes 15 may 23--------------------

Alter table [dbo].[StoreConfig] add [ACHProcessorId] [varchar](50) NULL
alter table [dbo].[StoreConfig] add IsAchEnabled BIT NULL

----------------------------------end change 15 may 23--------------------------------------------
