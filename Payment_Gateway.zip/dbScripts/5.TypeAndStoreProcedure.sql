CREATE TYPE [dbo].[NmiTransactionType] AS TABLE
(
	  [TransactionIdentifier] VARCHAR(50) NOT NULL
	, [TransactionDate] DATETIME NULL
	, [DbaName] VARCHAR(50) NULL
	, [MerchantMccCode] INT NULL
	, [MId] BIGINT NULL
	, [DebitOrCreditIndicator] VARCHAR(50) NULL
	, [TransactionAmount] DECIMAL(18,2) NULL
	, [CardType] VARCHAR(50) NULL
	, [CardType2] VARCHAR(50) NULL
	, [CardFirst6] VARCHAR(50) NULL
	, [CardLast4To5] VARCHAR(50) NULL
	, [CardHash] VARCHAR(50) NULL
	, [NetworkIdentifierDebit] VARCHAR(50) NULL
	, [PosDataCode] VARCHAR(50) NULL
	, [PosEntryMode] VARCHAR(50) NULL
	, [RecordIdentifier] VARCHAR(50) NULL
	, [TerminalId] VARCHAR(50) NULL
	, [TotalAuthorizedAmount] VARCHAR(50) NULL
	, [AuthorizationNumber] VARCHAR(50) NULL
	, [AuthAmount] DECIMAL(18,2) NULL
	, [OriginalTransactionAmount] DECIMAL(18,2) NULL
	, [RejectReason] VARCHAR(100) NULL
	, [MailOrderOrTelephoneOrderIndicator] INT NULL
	, [AchFlag] VARCHAR(50) NULL
	, [Aci] VARCHAR(50) NULL
	, [AssociationNumber2] INT NULL
	, [AuthCurrencyCode] INT NULL
	, [Authsource] VARCHAR(50) NULL
	, [BanknetAuthDate] INT NULL
	, [BanknetReferenceNumber] VARCHAR(50) NULL
	, [BatchJulianDate] INT NULL
	, [BestInterChangeEligible] VARCHAR(50) NULL
	, [CardHolderIordMethod] INT NULL
	, [CarryOverIndicator] VARCHAR(50) NULL
	, [CashbackAmount] DECIMAL(18,2) NULL
	, [CashbackAmountSign] VARCHAR(50) NULL
	, [CatIndicator] INT NULL
	, [CurrencyCode] INT NULL
	, [DiscoverNetworkReferenceId] VARCHAR(50) NULL
	, [DiscoverProcessingCode] VARCHAR(50) NULL
	, [DiscoverTransactionType] VARCHAR(50) NULL
	, [DownGradeReason1] VARCHAR(50) NULL
	, [DownGradeReason2] VARCHAR(50) NULL
	, [DownGradeReason3] VARCHAR(50) NULL
	, [DraftaFlag] VARCHAR(50) NULL
	, [EntryRunNumber] INT NULL
	, [ExtensionRecordIndicator] VARCHAR(50) NULL
	, [ForeignCardIndicator] VARCHAR(50) NULL
	, [DdfMccCode] INT NULL
	, [NetDeposit] DECIMAL(18,2) NULL
	, [OnlineEntry] VARCHAR(50) NULL
	, [ProductId] VARCHAR(50) NULL
	, [PurchaseId] BIGINT NULL
	, [ReimbursementAttribute] INT NULL
	, [ReversalFlag] VARCHAR(50) NULL
	, [SequenceNumberArea] INT NULL
	, [SequenceNumberWithInEntryRun] INT NULL
	, [SubmittedInterChange] INT NULL
	, [SwitchSettledIndicator] VARCHAR(50) NULL
	, [SystemTraceAuditNumber] VARCHAR(50) NULL
	, [TransactionCode] INT NULL
	, [TransactionDataConditionCode] VARCHAR(50) NULL
	, [TransactionTypeIdentifier] INT NULL
	, [ValidationCode] VARCHAR(50) NULL
	, [CardBrandFeeCode] VARCHAR(50) NULL
	, [CommercialCardServiceIndicator] VARCHAR(50) NULL
	, [InterchangeFeeAmount] VARCHAR(50) NULL
	, [InterchangePercentrate] VARCHAR(50) NULL
	, [InterchangePeritemRate] VARCHAR(50) NULL
	, [MasterCardTransactionIntegrityClass] VARCHAR(50) NULL
	, [MasterCardWalletIdentifier] VARCHAR(50) NULL
	, [McCashBackFee] DECIMAL(18,2) NULL
	, [McCashBackFeeSign] VARCHAR(50) NULL
	, [MerchantAssignedReferenceNumber] VARCHAR(50) NULL
	, [NetDepositAdjustmentAmount] VARCHAR(50) NULL
	, [NetDepositAdjustmentDc] VARCHAR(50) NULL
	, [OperatorId] VARCHAR(50) NULL
	, [RegulatedIndicator] VARCHAR(50) NULL
	, [RequestedPaymentService] VARCHAR(50) NULL
	, [TransactionFeeAmount] VARCHAR(50) NULL
	, [TransactionFeeAmountInCardHolderBillingCurrency] VARCHAR(50) NULL
	, [TransactionFeeDebitOrCreditIndicator] VARCHAR(50) NULL
	, [VisaFeeProgramIndicator] VARCHAR(50) NULL
	, [VisaIntegrityFee] VARCHAR(50) NULL
	, [VisaSpecialConditionIndicator] VARCHAR(50) NULL
)

GO

CREATE PROCEDURE [dbo].[UpdateNmiTransactions]
	@NmiTransactionFileId INT,
	@NmiTransactions NmiTransactionType READONLY
AS
BEGIN
	MERGE NmiTransaction AS t
	USING (SELECT 
		  [TransactionIdentifier]
		, [TransactionDate]
		, [DbaName]
		, [MerchantMccCode]
		, [MId]
		, [DebitOrCreditIndicator]
		, [TransactionAmount]
		, [CardType]
		, [CardType2]
		, [CardFirst6]
		, [CardLast4To5]
		, [CardHash]
		, [NetworkIdentifierDebit]
		, [PosDataCode]
		, [PosEntryMode]
		, [RecordIdentifier]
		, [TerminalId]
		, [TotalAuthorizedAmount]
		, [AuthorizationNumber]
		, [AuthAmount]
		, [OriginalTransactionAmount]
		, [RejectReason]
		, [MailOrderOrTelephoneOrderIndicator]
		, [AchFlag]
		, [Aci]
		, [AssociationNumber2]
		, [AuthCurrencyCode]
		, [Authsource]
		, [BanknetAuthDate]
		, [BanknetReferenceNumber]
		, [BatchJulianDate]
		, [BestInterChangeEligible]
		, [CardHolderIordMethod]
		, [CarryOverIndicator]
		, [CashbackAmount]
		, [CashbackAmountSign]
		, [CatIndicator]
		, [CurrencyCode]
		, [DiscoverNetworkReferenceId]
		, [DiscoverProcessingCode]
		, [DiscoverTransactionType]
		, [DownGradeReason1]
		, [DownGradeReason2]
		, [DownGradeReason3]
		, [DraftaFlag]
		, [EntryRunNumber]
		, [ExtensionRecordIndicator]
		, [ForeignCardIndicator]
		, [DdfMccCode]
		, [NetDeposit]
		, [OnlineEntry]
		, [ProductId]
		, [PurchaseId]
		, [ReimbursementAttribute]
		, [ReversalFlag]
		, [SequenceNumberArea]
		, [SequenceNumberWithInEntryRun]
		, [SubmittedInterChange]
		, [SwitchSettledIndicator]
		, [SystemTraceAuditNumber]
		, [TransactionCode]
		, [TransactionDataConditionCode]
		, [TransactionTypeIdentifier]
		, [ValidationCode]
		, [CardBrandFeeCode]
		, [CommercialCardServiceIndicator]
		, [InterchangeFeeAmount]
		, [InterchangePercentrate]
		, [InterchangePeritemRate]
		, [MasterCardTransactionIntegrityClass]
		, [MasterCardWalletIdentifier]
		, [McCashBackFee]
		, [McCashBackFeeSign]
		, [MerchantAssignedReferenceNumber]
		, [NetDepositAdjustmentAmount]
		, [NetDepositAdjustmentDc]
		, [OperatorId]
		, [RegulatedIndicator]
		, [RequestedPaymentService]
		, [TransactionFeeAmount]
		, [TransactionFeeAmountInCardHolderBillingCurrency]
		, [TransactionFeeDebitOrCreditIndicator]
		, [VisaFeeProgramIndicator]
		, [VisaIntegrityFee]
		, [VisaSpecialConditionIndicator]
	FROM @NmiTransactions) AS s
	ON t.TransactionIdentifier = s.TransactionIdentifier
	WHEN MATCHED THEN
		UPDATE SET 
		  t.[TransactionIdentifier] = s.[TransactionIdentifier]
		, t.[TransactionDate] = s.[TransactionDate]
		, t.[DbaName] = s.[DbaName]
		, t.[MerchantMccCode] = s.[MerchantMccCode]
		, t.[MId] = s.[MId]
		, t.[DebitOrCreditIndicator] = s.[DebitOrCreditIndicator]
		, t.[TransactionAmount] = s.[TransactionAmount]
		, t.[CardType] = s.[CardType]
		, t.[CardType2] = s.[CardType2]
		, t.[CardFirst6] = s.[CardFirst6]
		, t.[CardLast4To5] = s.[CardLast4To5]
		, t.[CardHash] = s.[CardHash]
		, t.[NetworkIdentifierDebit] = s.[NetworkIdentifierDebit]
		, t.[PosDataCode] = s.[PosDataCode]
		, t.[PosEntryMode] = s.[PosEntryMode]
		, t.[RecordIdentifier] = s.[RecordIdentifier]
		, t.[TerminalId] = s.[TerminalId]
		, t.[TotalAuthorizedAmount] = s.[TotalAuthorizedAmount]
		, t.[AuthorizationNumber] = s.[AuthorizationNumber]
		, t.[AuthAmount] = s.[AuthAmount]
		, t.[OriginalTransactionAmount] = s.[OriginalTransactionAmount]
		, t.[RejectReason] = s.[RejectReason]
		, t.[MailOrderOrTelephoneOrderIndicator] = s.[MailOrderOrTelephoneOrderIndicator]
		, t.[AchFlag] = s.[AchFlag]
		, t.[Aci] = s.[Aci]
		, t.[AssociationNumber2] = s.[AssociationNumber2]
		, t.[AuthCurrencyCode] = s.[AuthCurrencyCode]
		, t.[Authsource] = s.[Authsource]
		, t.[BanknetAuthDate] = s.[BanknetAuthDate]
		, t.[BanknetReferenceNumber] = s.[BanknetReferenceNumber]
		, t.[BatchJulianDate] = s.[BatchJulianDate]
		, t.[BestInterChangeEligible] = s.[BestInterChangeEligible]
		, t.[CardHolderIordMethod] = s.[CardHolderIordMethod]
		, t.[CarryOverIndicator] = s.[CarryOverIndicator]
		, t.[CashbackAmount] = s.[CashbackAmount]
		, t.[CashbackAmountSign] = s.[CashbackAmountSign]
		, t.[CatIndicator] = s.[CatIndicator]
		, t.[CurrencyCode] = s.[CurrencyCode] 
		, t.[DiscoverNetworkReferenceId] = s.[DiscoverNetworkReferenceId]
		, t.[DiscoverProcessingCode] = s.[DiscoverProcessingCode]
		, t.[DiscoverTransactionType] = s.[DiscoverTransactionType]
		, t.[DownGradeReason1] = s.[DownGradeReason1]
		, t.[DownGradeReason2] = s.[DownGradeReason2]
		, t.[DownGradeReason3] = s.[DownGradeReason3]
		, t.[DraftaFlag] = s.[DraftaFlag]
		, t.[EntryRunNumber] = s.[EntryRunNumber]
		, t.[ExtensionRecordIndicator] = s.[ExtensionRecordIndicator]
		, t.[ForeignCardIndicator] = s.[ForeignCardIndicator]
		, t.[DdfMccCode] = s.[DdfMccCode]
		, t.[NetDeposit] = s.[NetDeposit]
		, t.[OnlineEntry] = s.[OnlineEntry]
		, t.[ProductId] = s.[ProductId]
		, t.[PurchaseId] = s.[PurchaseId]
		, t.[ReimbursementAttribute] = s.[ReimbursementAttribute]
		, t.[ReversalFlag] = s.[ReversalFlag]
		, t.[SequenceNumberArea] = s.[SequenceNumberArea]
		, t.[SequenceNumberWithInEntryRun] = s.[SequenceNumberWithInEntryRun]
		, t.[SubmittedInterChange] = s.[SubmittedInterChange]
		, t.[SwitchSettledIndicator] = s.[SwitchSettledIndicator]
		, t.[SystemTraceAuditNumber] = s.[SystemTraceAuditNumber]
		, t.[TransactionCode] = s.[TransactionCode]
		, t.[TransactionDataConditionCode] = s.[TransactionDataConditionCode]
		, t.[TransactionTypeIdentifier] = s.[TransactionTypeIdentifier]
		, t.[ValidationCode] = s.[ValidationCode]
		, t.[CardBrandFeeCode] = s.[CardBrandFeeCode]
		, t.[CommercialCardServiceIndicator] = s.[CommercialCardServiceIndicator]
		, t.[InterchangeFeeAmount] = s.[InterchangeFeeAmount]
		, t.[InterchangePercentrate] = s.[InterchangePercentrate]
		, t.[InterchangePeritemRate] = s.[InterchangePeritemRate]
		, t.[MasterCardTransactionIntegrityClass] = s.[MasterCardTransactionIntegrityClass]
		, t.[MasterCardWalletIdentifier] = s.[MasterCardWalletIdentifier]
		, t.[McCashBackFee] = s.[McCashBackFee] 
		, t.[McCashBackFeeSign] = s.[McCashBackFeeSign]
		, t.[MerchantAssignedReferenceNumber] = s.[MerchantAssignedReferenceNumber]
		, t.[NetDepositAdjustmentAmount] = s.[NetDepositAdjustmentAmount] 
		, t.[NetDepositAdjustmentDc] = s.[NetDepositAdjustmentDc]
		, t.[OperatorId] = s.[OperatorId]
		, t.[RegulatedIndicator] = s.[RegulatedIndicator]
		, t.[RequestedPaymentService] = s.[RequestedPaymentService]
		, t.[TransactionFeeAmount] = s.[TransactionFeeAmount]
		, t.[TransactionFeeAmountInCardHolderBillingCurrency] = s.[TransactionFeeAmountInCardHolderBillingCurrency]
		, t.[TransactionFeeDebitOrCreditIndicator] = s.[TransactionFeeDebitOrCreditIndicator]
		, t.[VisaFeeProgramIndicator] = s.[VisaFeeProgramIndicator]
		, t.[VisaIntegrityFee] = s.[VisaIntegrityFee]
		, t.[VisaSpecialConditionIndicator] = s.[VisaSpecialConditionIndicator]
		, t.[UpdatedOn] = GetUTCDATE()
		
	WHEN NOT MATCHED BY TARGET THEN
		INSERT (
		  [TransactionIdentifier]
		, [TransactionDate]
		, [NmiTransactionFileId]
		, [DbaName]
		, [MerchantMccCode]
		, [MId]
		, [DebitOrCreditIndicator]
		, [TransactionAmount]
		, [CardType]
		, [CardType2]
		, [CardFirst6]
		, [CardLast4To5]
		, [CardHash]
		, [NetworkIdentifierDebit]
		, [PosDataCode]
		, [PosEntryMode]
		, [RecordIdentifier]
		, [TerminalId]
		, [TotalAuthorizedAmount]
		, [AuthorizationNumber]
		, [AuthAmount]
		, [OriginalTransactionAmount]
		, [RejectReason]
		, [MailOrderOrTelephoneOrderIndicator]
		, [AchFlag]
		, [Aci]
		, [AssociationNumber2]
		, [AuthCurrencyCode]
		, [Authsource]
		, [BanknetAuthDate]
		, [BanknetReferenceNumber]
		, [BatchJulianDate]
		, [BestInterChangeEligible]
		, [CardHolderIordMethod]
		, [CarryOverIndicator]
		, [CashbackAmount]
		, [CashbackAmountSign]
		, [CatIndicator]
		, [CurrencyCode]
		, [DiscoverNetworkReferenceId]
		, [DiscoverProcessingCode]
		, [DiscoverTransactionType]
		, [DownGradeReason1]
		, [DownGradeReason2]
		, [DownGradeReason3]
		, [DraftaFlag]
		, [EntryRunNumber]
		, [ExtensionRecordIndicator]
		, [ForeignCardIndicator]
		, [DdfMccCode]
		, [NetDeposit]
		, [OnlineEntry]
		, [ProductId]
		, [PurchaseId]
		, [ReimbursementAttribute]
		, [ReversalFlag]
		, [SequenceNumberArea]
		, [SequenceNumberWithInEntryRun]
		, [SubmittedInterChange]
		, [SwitchSettledIndicator]
		, [SystemTraceAuditNumber]
		, [TransactionCode]
		, [TransactionDataConditionCode]
		, [TransactionTypeIdentifier]
		, [ValidationCode]
		, [CardBrandFeeCode]
		, [CommercialCardServiceIndicator]
		, [InterchangeFeeAmount]
		, [InterchangePercentrate]
		, [InterchangePeritemRate]
		, [MasterCardTransactionIntegrityClass]
		, [MasterCardWalletIdentifier]
		, [McCashBackFee]
		, [McCashBackFeeSign]
		, [MerchantAssignedReferenceNumber]
		, [NetDepositAdjustmentAmount]
		, [NetDepositAdjustmentDc]
		, [OperatorId]
		, [RegulatedIndicator]
		, [RequestedPaymentService]
		, [TransactionFeeAmount]
		, [TransactionFeeAmountInCardHolderBillingCurrency]
		, [TransactionFeeDebitOrCreditIndicator]
		, [VisaFeeProgramIndicator]
		, [VisaIntegrityFee]
		, [VisaSpecialConditionIndicator]
		, [IsActive]
		, [CreatedOn])
		VALUES (
		  s.[TransactionIdentifier]
		, s.[TransactionDate]
		, @NmiTransactionFileId
		, s.[DbaName]
		, s.[MerchantMccCode]
		, s.[MId]
		, s.[DebitOrCreditIndicator]
		, s.[TransactionAmount]
		, s.[CardType]
		, s.[CardType2]
		, s.[CardFirst6]
		, s.[CardLast4To5]
		, s.[CardHash]
		, s.[NetworkIdentifierDebit]
		, s.[PosDataCode]
		, s.[PosEntryMode]
		, s.[RecordIdentifier]
		, s.[TerminalId]
		, s.[TotalAuthorizedAmount]
		, s.[AuthorizationNumber]
		, s.[AuthAmount]
		, s.[OriginalTransactionAmount]
		, s.[RejectReason]
		, s.[MailOrderOrTelephoneOrderIndicator]
		, s.[AchFlag]
		, s.[Aci]
		, s.[AssociationNumber2]
		, s.[AuthCurrencyCode]
		, s.[Authsource]
		, s.[BanknetAuthDate]
		, s.[BanknetReferenceNumber]
		, s.[BatchJulianDate]
		, s.[BestInterChangeEligible]
		, s.[CardHolderIordMethod]
		, s.[CarryOverIndicator]
		, s.[CashbackAmount]
		, s.[CashbackAmountSign]
		, s.[CatIndicator]
		, s.[CurrencyCode]
		, s.[DiscoverNetworkReferenceId]
		, s.[DiscoverProcessingCode]
		, s.[DiscoverTransactionType]
		, s.[DownGradeReason1]
		, s.[DownGradeReason2]
		, s.[DownGradeReason3]
		, s.[DraftaFlag]
		, s.[EntryRunNumber]
		, s.[ExtensionRecordIndicator]
		, s.[ForeignCardIndicator]
		, s.[DdfMccCode]
		, s.[NetDeposit]
		, s.[OnlineEntry]
		, s.[ProductId]
		, s.[PurchaseId]
		, s.[ReimbursementAttribute]
		, s.[ReversalFlag]
		, s.[SequenceNumberArea]
		, s.[SequenceNumberWithInEntryRun]
		, s.[SubmittedInterChange]
		, s.[SwitchSettledIndicator]
		, s.[SystemTraceAuditNumber]
		, s.[TransactionCode]
		, s.[TransactionDataConditionCode]
		, s.[TransactionTypeIdentifier]
		, s.[ValidationCode]
		, s.[CardBrandFeeCode]
		, s.[CommercialCardServiceIndicator]
		, s.[InterchangeFeeAmount]
		, s.[InterchangePercentrate]
		, s.[InterchangePeritemRate]
		, s.[MasterCardTransactionIntegrityClass]
		, s.[MasterCardWalletIdentifier]
		, s.[McCashBackFee]
		, s.[McCashBackFeeSign]
		, s.[MerchantAssignedReferenceNumber]
		, s.[NetDepositAdjustmentAmount]
		, s.[NetDepositAdjustmentDc]
		, s.[OperatorId]
		, s.[RegulatedIndicator]
		, s.[RequestedPaymentService]
		, s.[TransactionFeeAmount]
		, s.[TransactionFeeAmountInCardHolderBillingCurrency]
		, s.[TransactionFeeDebitOrCreditIndicator]
		, s.[VisaFeeProgramIndicator]
		, s.[VisaIntegrityFee]
		, s.[VisaSpecialConditionIndicator]
		, 1
		, GETUTCDATE()
		);
END