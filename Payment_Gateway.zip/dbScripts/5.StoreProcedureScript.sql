Create Procedure [dbo].[UpdateSite]
@StoreId Int,
@SiteId nvarchar(20),
@StoreName nvarchar(200)
As
Begin
	DECLARE @OriginalSiteId nvarchar(20);
	DECLARE @OriginalStoreName nvarchar(20);
	
	if(@SiteId Is null or len(ltrim(rtrim(@SiteId)))=0)
		BEGIN
			return;
		END
		
	If(@StoreId=0)
	BEGIN
		return;
	END
	
	update [PreAuthPayment] set SiteId = @SiteId, StoreName = @StoreName  Where storeId = @storeId;
	update [StorePaymentMethodConfigration] set SiteId = @SiteId Where storeId = @storeId;
END