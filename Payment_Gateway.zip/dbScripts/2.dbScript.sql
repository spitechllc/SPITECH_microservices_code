SET XACT_ABORT ON;
GO

BEGIN TRANSACTION;
GO

CREATE TABLE [dbo].[StoreConfig]
(
	  [StoreId] INT NOT NULL
	, [AccountName] [varchar](22) NOT NULL
	, [Bank] [varchar](23) NULL
	, [AccountNo] [varchar](100) NULL
	, [RoutingNo] [varchar](100) NULL
	, [IsChecking] BIT NOT NULL
	, [IsMasterAccount] BIT NOT NULL
	, [PaymentProcessorId] [varchar](50) NULL
	, [ACHProcessorId] [varchar](50) NULL
	, [IsAchEnabled] BIT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_StoreConfig] PRIMARY KEY ([StoreId] ASC)
)

GO

CREATE TABLE [dbo].[ResellerConfig]
(
	  [ResellerId] INT NOT NULL
	, [AccountName] [varchar](22) NOT NULL
	, [Bank] [varchar](23) NULL
	, [AccountNo] [varchar](100) NULL
	, [RoutingNo] [varchar](100) NULL
	, [IsChecking] BIT NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_ResellerConfig] PRIMARY KEY ([ResellerId] ASC)
)

GO

CREATE TABLE [dbo].[SaleAgentConfig]
(
	  [SaleAgentId] INT NOT NULL
	, [AccountName] [varchar](22) NOT NULL
	, [Bank] [varchar](23) NULL
	, [AccountNo] [varchar](100) NULL
	, [RoutingNo] [varchar](100) NULL
	, [IsChecking] BIT NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_SaleAgentConfig] PRIMARY KEY ([SaleAgentId] ASC)
)

GO

CREATE TABLE [dbo].[DwollaBusinessCustomer](	  [BusinessId] INT NOT NULL IDENTITY(1,1)	, [StoreId] int NULL	, [FirstName] VARCHAR(50) NULL	, [LastName] VARCHAR(50) NULL	, [Email] VARCHAR(150) NULL	, [IpAddress] VARCHAR(50) NULL	, [Type] VARCHAR(50) NULL	, [Address] VARCHAR(50) NULL	, [City] VARCHAR(50) NULL	, [State] VARCHAR(50) NULL	, [PostalCode] VARCHAR(50) NULL	, [DOB] DATETIME NULL	, [SSN] VARCHAR(12) NULL	, [Phone] NVARCHAR(50) NULL	, [Website] VARCHAR(150) NULL	, [DwollaBusinessUrl] VARCHAR(500) NOT NULL	, [DwollaBusinessId] VARCHAR(150) NOT NULL	, [BusinessClassification] VARCHAR(150) NULL	, [BusinessType] VARCHAR(150) NULL	, [BusinessName] VARCHAR(150) NULL	, [EIN] VARCHAR(50) NULL	, [HaveBeneficialOwner] BIT NOT NULL DEFAULT((0))	, [BeneficialOwnersId] NVARCHAR(500)  NULL 	, [FundingSourceId] NVARCHAR(150)  NULL	, [Certifiedby] NVARCHAR(150)  NULL
	, [DocumentId] NVARCHAR(100) NULL
	, [DocumentUrl] NVARCHAR(150) NULL
	, [BusinessDocumentId] NVARCHAR(100) NULL
	, [BusinessDocumentUrl] NVARCHAR(150) NULL
	, [IsBeneficialOwnerCertified] BIT NULL	, [PassportNo] VARCHAR(50) NULL	, [PassportCountry] VARCHAR(2) NULL	, [IsActive] BIT NOT NULL DEFAULT((1))	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())	, [CreatedBy] INT NULL	, [UpdatedOn] DATETIME NULL	, [UpdatedBy] INT NULL	, CONSTRAINT [PK_DwollaBusinessCustomer] PRIMARY KEY ([BusinessId] ASC))
GO

CREATE TABLE [dbo].[DwollaCustomer]
(
	  [CustomerId] INT NOT NULL IDENTITY(1,1)
	, [UserId] INT  NULL
	, [StoreId] INT  NULL
	, [FirstName] [varchar](50) NULL
	, [LastName] [varchar](50) NULL
	, [Email] [varchar](50) NULL
	, [IpAddress] VARCHAR(25) NULL
	, [Type] [varchar](50) NULL
	, [Address] [varchar](50) NULL
	, [City] [varchar](50) NULL
	, [State] [varchar](50) NULL
	, [PostalCode] [varchar](50) NULL
	, [DOB] [datetime] NULL
	, [SSN] [varchar](4) NULL
	, [DwollaCustomerUrl] VARCHAR(500) NOT NULL
	, [DwollaCutomerId] VARCHAR(50) NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_DwollaCustomer] PRIMARY KEY ([CustomerId] ASC)
)

GO
CREATE TABLE [dbo].[PaymentGatewayConfig]
(
	  [PaymentGatewayConfigId] INT NOT NULL
	, [GateWayName] VARCHAR(100) NOT NULL
	, [IsProdEnabled] BIT NOT NULL DEFAULT((0))
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_PaymentGatewayConfig] PRIMARY KEY ([PaymentGatewayConfigId] ASC)
)

GO
CREATE TABLE [dbo].[PaymentMethod]
(
	  [PaymentMethodId] INT NOT NULL
	, [PaymentMethodName] VARCHAR(100) NOT NULL
	, [PaymentType] VARCHAR(50) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_PaymentMethod] PRIMARY KEY ([PaymentMethodId] ASC)
)

GO
CREATE TABLE [dbo].[PaymentStatus]
(
	  [PaymentStatusId] INT NOT NULL
	, [PaymentStatusName] VARCHAR(100) NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_PaymentStatus] PRIMARY KEY ([PaymentStatusId] ASC)
)

GO
CREATE TABLE [dbo].[StorePaymentMethodConfigration]
(
	  [ConfigrationId] INT NOT NULL IDENTITY(1,1)
	, [StoreId] INT NOT NULL
	, [PaymentGatewayConfigId] INT NOT NULL
	, [SiteID] VARCHAR(20) NOT NULL	
	, [AccountHolderName] varchar(50) NULL
	, [AccountNumber] VARCHAR(20) NULL
	, [AccountType] VARCHAR(10) NULL
	, [RoutingNumber] VARCHAR(10) NULL
	, [BankName] VARCHAR(50) NULL	
	, [Token] VARCHAR(500) NOT NULL
	, [TransactionToken] VARCHAR(500) NOT NULL
	, [IsDefault] BIT NOT NULL
	, [IsRemoved] BIT NOT NULL DEFAULT((0))
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_StorePaymentMethodConfigration] PRIMARY KEY ([ConfigrationId] ASC)
)

ALTER TABLE [dbo].[StorePaymentMethodConfigration] ADD
  CONSTRAINT [FK_StorePaymentMethodConfigration_PaymentGatewayConfig] FOREIGN KEY([PaymentGatewayConfigId]) REFERENCES [dbo].[PaymentGatewayConfig]([PaymentGatewayConfigId]);

GO
CREATE TABLE [dbo].[UserPaymentMethod]
(
	  [UserPaymentMethodId] INT NOT NULL IDENTITY(1,1)
	, [PaymentMethodId] INT NOT NULL
	, [UserId] INT NULL
	, [PaymentGatewayConfigId] INT NULL
	, [CardName] VARCHAR(100) NULL
	, [CardExpDate] DATETIME NULL
	, [CardNumber] VARCHAR(20) NULL
	, [CardType] VARCHAR(30) NULL
	, [AccountNumber] [varchar](100) NULL
	, [AccountType] VARCHAR(10) NULL
	, [BankName] VARCHAR(50) NULL	
	, [CustId] VARCHAR(30) NULL
	, [Operation] VARCHAR(200) NULL
	, [Source] VARCHAR(50) NULL
	, [Token] VARCHAR(500) NOT NULL
	, [TransactionToken] VARCHAR(500) NOT NULL	
	, [NickName] VARCHAR(50)	
	, [RoutingNumber] [varchar](100)
	, [IsDefault] BIT NOT NULL DEFAULT((0))
	, [IsRemoved] BIT NOT NULL DEFAULT((0))
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_UserPaymentMethod] PRIMARY KEY ([UserPaymentMethodId] ASC)
)

ALTER TABLE [dbo].[UserPaymentMethod] ADD
  CONSTRAINT [FK_UserPaymentMethod_PaymentMethod] FOREIGN KEY([PaymentMethodId]) REFERENCES [dbo].[PaymentMethod]([PaymentMethodId]);
 
ALTER TABLE [dbo].[UserPaymentMethod] ADD
  CONSTRAINT [FK_UserPaymentMethod_PaymentGatewayConfig] FOREIGN KEY([PaymentGatewayConfigId]) REFERENCES [dbo].[PaymentGatewayConfig]([PaymentGatewayConfigId]);

GO
CREATE TABLE [dbo].[PreAuthPayment]
(
	  [PreAuthPaymentId] INT NOT NULL IDENTITY(1,1)
	, [PreAuthConfirmationNo] VARCHAR(50) NULL
	, [UserPaymentMethodId] INT NOT NULL
	, [PaymentGatewayConfigId] INT NOT NULL
	, [PaymentMethodId] INT NOT NULL
	, [UserId] INT NOT NULL
	, [TransactionId] BIGINT NULL
	, [StoreId] INT NULL
	, [SiteId] VARCHAR(20) NULL
	, [StoreName] VARCHAR(100) NULL
	, [Amount] DECIMAL(18,2) NULL
	, [TransactionType] INT NULL
	, [Description] VARCHAR(500) NULL
	, [PreAuthDate] DATETIME NULL
	, [CardNumber] NVARCHAR(50) NULL
	, [CardType] VARCHAR(50) NULL
	, [AccountNumber] NVARCHAR(20) NULL
	, [AccountType] VARCHAR(50) NULL
	, [BankName] VARCHAR(50) NULL
	, [ConsumerIP] VARCHAR(50) NULL
	, [Success] BIT NULL DEFAULT((0))
	, [CardAmount] DECIMAL(18,2) NULL
	, [CardResponse] VARCHAR(MAX) NULL
	, [CardPreAuthConfirmationNo] VARCHAR(50) NULL
	, [CardPreAuthPaymentStatusId] INT NULL
	, [WalletAmount] DECIMAL(18,2) NULL
	, [WalletResponse] VARCHAR(1000) NULL
	, [WalletPreAuthConfirmationNo] VARCHAR(100) NULL
	, [WalletPreAuthPaymentStatusId] INT NULL
	, [IsPaymentRequired] BIT NULL DEFAULT((0))
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_PreAuthPayment] PRIMARY KEY ([PreAuthPaymentId] ASC)
)

ALTER TABLE [dbo].[PreAuthPayment] ADD
  CONSTRAINT [FK_PreAuthPayment_UserPaymentMethod] FOREIGN KEY([UserPaymentMethodId]) REFERENCES [dbo].[UserPaymentMethod]([UserPaymentMethodId]);
 
ALTER TABLE [dbo].[PreAuthPayment] ADD
  CONSTRAINT [FK_PreAuthPayment_PaymentGatewayConfig] FOREIGN KEY([PaymentGatewayConfigId]) REFERENCES [dbo].[PaymentGatewayConfig]([PaymentGatewayConfigId]);
 
ALTER TABLE [dbo].[PreAuthPayment] ADD
  CONSTRAINT [FK_PreAuthPayment_PaymentMethod] FOREIGN KEY([PaymentMethodId]) REFERENCES [dbo].[PaymentMethod]([PaymentMethodId]);
 
GO
CREATE TABLE [dbo].[Payment]
(
	  [PaymentId] INT NOT NULL IDENTITY(1,1)
	, [PreAuthPaymentId] INT NOT NULL
	, [UserId] INT NOT NULL
	, [TransactionId] BIGINT NULL
	, [Description] VARCHAR(500) NULL
	, [Amount] DECIMAL(18,2) NULL
	, [WalletAmount] DECIMAL(18,2) NULL
	, [CardAmount] DECIMAL(18,2) NULL
	, [CardResponse] VARCHAR(MAX) NULL
	, [WalletResponse] VARCHAR(MAX) NULL
	, [Success] BIT NOT NULL
	, [WalletPaymentStatusId] INT NULL
	, [CardPaymentStatusId] INT NULL
	, [CardConfirmationNumber] VARCHAR(50) NULL
	, [CardPayRetryCount] INT NULL
	, [CardPayLastRetry] DATETIME NULL
	, [CardPayErrorMessage] VARCHAR(MAX) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_Payment] PRIMARY KEY ([PaymentId] ASC)
)

ALTER TABLE [dbo].[Payment] ADD
  CONSTRAINT [FK_Payment_PreAuthPayment] FOREIGN KEY([PreAuthPaymentId]) REFERENCES [dbo].[PreAuthPayment]([PreAuthPaymentId]);
  
  
GO

CREATE TABLE [dbo].[WebhooksCreditCardDetails]
(
	[WebhooksId] [bigint] NOT NULL,
	[EventId] [nvarchar](100) NOT NULL,
	[MerchantId] [int] NULL,
	[MerchantName] [varchar](200) NULL,
	[TransactionId] [bigint] NOT NULL,
	[TransactionType] [nvarchar](5) NULL,
	[Condition] [nvarchar](100) NULL,
	[ProccessorId] [varchar](100) NULL,
	[PONumber] [int] NULL,
	[OrderDescription] [nvarchar](200) NULL,
	[OrderId] [int] NULL,
	[customerid] [int] NULL,
	[customertaxid] [int] NULL,
	[Website] [nvarchar](100) NULL,
	[Shipping] [nvarchar](100) NULL,
	[Currency] [nvarchar](50) NULL,
	[Tax] [decimal](18, 5) NULL,
	[Surcharge] [decimal](18, 5) NULL,
	[CashDiscount] [decimal](18, 5) NULL,
	[RequestedAmount] [decimal](18, 5) NULL,
	[AuthorizationCode] [nvarchar](100) NULL,
	[SocialSecurityNumber] [varchar](20) NULL,
	[CCNumber] [nvarchar](100) NULL,
	[CCExp] [varchar](20) NULL,
	[CCType] [varchar](100) NULL,
	[Amount] [decimal](18, 5) NULL,
	[ActionType] [nvarchar](100) NULL,
	[Date] [datetime] NULL,
	[Success] [bit] NULL,
	[Ipaddress] [nvarchar](20) NULL,
	[Source] [nvarchar](100) NULL,
	[ApiMethod] [nvarchar](100) NULL,
	[UserName] [nvarchar](50) NULL,
	[ResponseText] [nvarchar](500) NULL,
	[ResponseCode] [nvarchar](20) NULL,
	[ProcessorResponseText] [nvarchar](500) NULL,
	[ProcessorResponseCode] [nvarchar](20) NULL,
	[DeviceLicenseNumber] [nvarchar](50) NULL,
	[DeviceNickname] [varchar](50) NULL,
	[IsActive] BIT NOT NULL DEFAULT((1)),
	[CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate()),
	[CreatedBy] [int] NULL,
	[UpdatedOn] [datetime] NULL,
	[UpdatedBy] [int] NULL,
 CONSTRAINT [PK_Webhooks_CreditCardDetails] PRIMARY KEY ([WebhooksId] ASC))
GO

CREATE TABLE [dbo].[NmiTransactionFile]
(
	  [NmiTransactionFileId] INT NOT NULL IDENTITY(1,1)
	, [Name] VARCHAR(100) NOT NULL
	, [FileId] VARCHAR(100) NOT NULL
	, [FileCreationDate] DATETIME NOT NULL
	, [Bucket] VARCHAR(100) NOT NULL
	, [ContentType] VARCHAR(100) NOT NULL
	, [MediaLink] VARCHAR(500) NOT NULL
	, [SelfLink] VARCHAR(500) NOT NULL
	, [Size] BigInt NOT NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_NmiTransactionFile] PRIMARY KEY ([NmiTransactionFileId] ASC)
)
GO

CREATE TABLE [dbo].[NmiTransaction]
(
	  [TransactionIdentifier] VARCHAR(50) NOT NULL
	, [TransactionDate] DATETIME NULL
	, [NmiTransactionFileId] INT NOT NULL
	, [DbaName] VARCHAR(50) NULL
	, [MerchantMccCode] INT NULL
	, [MId] BIGINT NULL
	, [DebitOrCreditIndicator] VARCHAR(50) NULL
	, [TransactionAmount] DECIMAL(18,2) NULL
	, [CardType] VARCHAR(50) NULL
	, [CardType2] VARCHAR(50) NULL
	, [CardFirst6] VARCHAR(50) NULL
	, [CardLast4To5] VARCHAR(50) NULL
	, [CardHash] VARCHAR(50) NULL
	, [NetworkIdentifierDebit] VARCHAR(50) NULL
	, [PosDataCode] VARCHAR(50) NULL
	, [PosEntryMode] VARCHAR(50) NULL
	, [RecordIdentifier] VARCHAR(50) NULL
	, [TerminalId] VARCHAR(50) NULL
	, [TotalAuthorizedAmount] VARCHAR(50) NULL
	, [AuthorizationNumber] VARCHAR(50) NULL
	, [AuthAmount] DECIMAL(18,2) NULL
	, [OriginalTransactionAmount] DECIMAL(18,2) NULL
	, [RejectReason] VARCHAR(100) NULL
	, [MailOrderOrTelephoneOrderIndicator] INT NULL
	, [AchFlag] VARCHAR(50) NULL
	, [Aci] VARCHAR(50) NULL
	, [AssociationNumber2] INT NULL
	, [AuthCurrencyCode] INT NULL
	, [Authsource] VARCHAR(50) NULL
	, [BanknetAuthDate] INT NULL
	, [BanknetReferenceNumber] VARCHAR(50) NULL
	, [BatchJulianDate] INT NULL
	, [BestInterChangeEligible] VARCHAR(50) NULL
	, [CardHolderIordMethod] INT NULL
	, [CarryOverIndicator] VARCHAR(50) NULL
	, [CashbackAmount] DECIMAL(18,2) NULL
	, [CashbackAmountSign] VARCHAR(50) NULL
	, [CatIndicator] INT NULL
	, [CurrencyCode] INT NULL
	, [DiscoverNetworkReferenceId] VARCHAR(50) NULL
	, [DiscoverProcessingCode] VARCHAR(50) NULL
	, [DiscoverTransactionType] VARCHAR(50) NULL
	, [DownGradeReason1] VARCHAR(50) NULL
	, [DownGradeReason2] VARCHAR(50) NULL
	, [DownGradeReason3] VARCHAR(50) NULL
	, [DraftaFlag] VARCHAR(50) NULL
	, [EntryRunNumber] INT NULL
	, [ExtensionRecordIndicator] VARCHAR(50) NULL
	, [ForeignCardIndicator] VARCHAR(50) NULL
	, [DdfMccCode] INT NULL
	, [NetDeposit] DECIMAL(18,2) NULL
	, [OnlineEntry] VARCHAR(50) NULL
	, [ProductId] VARCHAR(50) NULL
	, [PurchaseId] BIGINT NULL
	, [ReimbursementAttribute] INT NULL
	, [ReversalFlag] VARCHAR(50) NULL
	, [SequenceNumberArea] INT NULL
	, [SequenceNumberWithInEntryRun] INT NULL
	, [SubmittedInterChange] INT NULL
	, [SwitchSettledIndicator] VARCHAR(50) NULL
	, [SystemTraceAuditNumber] VARCHAR(50) NULL
	, [TransactionCode] INT NULL
	, [TransactionDataConditionCode] VARCHAR(50) NULL
	, [TransactionTypeIdentifier] INT NULL
	, [ValidationCode] VARCHAR(50) NULL
	, [CardBrandFeeCode] VARCHAR(50) NULL
	, [CommercialCardServiceIndicator] VARCHAR(50) NULL
	, [InterchangeFeeAmount] VARCHAR(50) NULL
	, [InterchangePercentrate] VARCHAR(50) NULL
	, [InterchangePeritemRate] VARCHAR(50) NULL
	, [MasterCardTransactionIntegrityClass] VARCHAR(50) NULL
	, [MasterCardWalletIdentifier] VARCHAR(50) NULL
	, [McCashBackFee] DECIMAL(18,2) NULL
	, [McCashBackFeeSign] VARCHAR(50) NULL
	, [MerchantAssignedReferenceNumber] VARCHAR(50) NULL
	, [NetDepositAdjustmentAmount] VARCHAR(50) NULL
	, [NetDepositAdjustmentDc] VARCHAR(50) NULL
	, [OperatorId] VARCHAR(50) NULL
	, [RegulatedIndicator] VARCHAR(50) NULL
	, [RequestedPaymentService] VARCHAR(50) NULL
	, [TransactionFeeAmount] VARCHAR(50) NULL
	, [TransactionFeeAmountInCardHolderBillingCurrency] VARCHAR(50) NULL
	, [TransactionFeeDebitOrCreditIndicator] VARCHAR(50) NULL
	, [VisaFeeProgramIndicator] VARCHAR(50) NULL
	, [VisaIntegrityFee] VARCHAR(50) NULL
	, [VisaSpecialConditionIndicator] VARCHAR(50) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_NmiTransaction] PRIMARY KEY ([TransactionIdentifier] ASC)
)

ALTER TABLE [dbo].[NmiTransaction] ADD
  CONSTRAINT [FK_NmiTransaction_NmiTransactionFile] FOREIGN KEY([NmiTransactionFileId]) REFERENCES [dbo].[NmiTransactionFile]([NmiTransactionFileId]);
GO

CREATE TABLE [dbo].[UserAchPayment]
(
	  [UserAchPaymentId] INT NOT NULL IDENTITY(1,1)
	, [BusinessDate] DATETIME NULL
	, [TotalAmount] DECIMAL(18,2) NULL
	, [TotalRecord] INT NULL
	, [AccountName] NVARCHAR(22) NULL
	, [Bank] NVARCHAR(23) NULL
	, [AccountNo] NVARCHAR(17) NULL
	, [RoutingNo] NVARCHAR(9) NULL
	, [IsChecking] BIT NOT NULL
	, [NachaFilePath] NVARCHAR(2000) NULL
	, [NachaFileName] NVARCHAR(200) NULL
	, [IsNachaUploaded] BIT NOT NULL DEFAULT((0))
	, [NachaUploadError] NVARCHAR(max) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_UserAchPayment] PRIMARY KEY ([UserAchPaymentId] ASC)
)

GO

CREATE TABLE [dbo].[UserAchPaymentDetail]
(
	  [UserAchPaymentDetailId] INT NOT NULL IDENTITY(1,1)
	, [UserAchPaymentId] INT NOT NULL
	, [PaymentId] INT NOT NULL
	, [StoreId] INT NOT NULL
	, [StoreName] NVARCHAR(100) NULL
	, [UserId] INT NOT NULL
	, [Amount] DECIMAL(18,2) NOT NULL
	, [AccountName] NVARCHAR(22) NULL
	, [AccountNo] NVARCHAR(17) NULL
	, [RoutingNo] NVARCHAR(9) NULL
	, [IdentificationNumber] NVARCHAR(25) NULL
	, [IsChecking] BIT NOT NULL
	, [MarkUnPaid] BIT NOT NULL DEFAULT((0))
	, [Reason] NVARCHAR(500) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_UserAchPaymentDetail] PRIMARY KEY ([UserAchPaymentDetailId] ASC)
)
ALTER TABLE [dbo].[UserAchPaymentDetail] ADD
  CONSTRAINT [FK_UserAchPaymentDetail_UserAchPayment] FOREIGN KEY([UserAchPaymentId]) REFERENCES [dbo].[UserAchPayment]([UserAchPaymentId]);

ALTER TABLE [dbo].[UserAchPaymentDetail] ADD
  CONSTRAINT [FK_UserAchPaymentDetail_Payment] FOREIGN KEY([PaymentId]) REFERENCES [dbo].[Payment]([PaymentId]);
  
GO

CREATE TABLE [dbo].[WebHookDetail]
(
	[WebHookDetailId] [Bigint] NOT NULL  IDENTITY(1,1),
	[Message] [nvarchar](max) NULL,
	[IsActive] BIT NOT NULL DEFAULT((1)),
	[CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate()),
	[CreatedBy] [int] NULL,
	[UpdatedOn] [datetime] NULL,
	[UpdatedBy] [int] NULL,
 CONSTRAINT [PK_WebHookDetail_WebHookDetailId] PRIMARY KEY ([WebHookDetailId] ASC))

GO
Create Table [dbo].[NMITransactionDetails]
(
 	  [NMITransactionDetailsId]  INT NOT NULL IDENTITY(1,1)
	, [TransactionId] INT NOT NULL
	, [TransactionType] [varchar](22) NOT NULL
	, [Condition] [varchar](10) NULL
	, [City] [varchar](50) NULL
	, [State] [varchar](22) NOT NULL
	, [PostalCode] [varchar](10) NULL
	, [Country] [varchar](17) NULL
	, [ProcessorId] [varchar](50) NULL
	, [Tax] decimal(18,2) NOT NULL
	, [Currency][varchar](50) NULL
	, [CcType] [varchar](50) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_NMITransactionDetails] PRIMARY KEY ([NMITransactionDetailsId] ASC)
)
GO
Create Table [dbo].[NMITransactionDetailsAction]
(
 	  [NMITransactionDetailsActionId] INT NOT NULL IDENTITY(1,1)
	, [NMITransactionDetailsId] INT NOT NULL
	, [Amount] decimal(18,2) NOT NULL
	, [ActionType] [varchar](22) NOT NULL
	, [ActionDate] Datetime NULL
	, [Success] bit NULL
	, [IpAddress] [varchar](22) NOT NULL
	, [ResponseCode] [varchar](10) NULL
	, [ProcessorResponseText] [varchar](500) NULL
	, [ProcessorResponseCode] [varchar](100) NULL
	, [IsActive] BIT NOT NULL DEFAULT((1))
	, [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
	, [CreatedBy] INT NULL
	, [UpdatedOn] DATETIME NULL
	, [UpdatedBy] INT NULL
	, CONSTRAINT [PK_NMITransactionDetailsAction] PRIMARY KEY ([NMITransactionDetailsActionId] ASC)
)
	
	GO
	ALTER TABLE [dbo].[NMITransactionDetailsAction] ADD
  CONSTRAINT [FK_NMITransactionDetailsAction] FOREIGN KEY([NMITransactionDetailsId]) REFERENCES [dbo].[NMITransactionDetails]([NMITransactionDetailsId]);
  GO
COMMIT TRANSACTION;
GO
