USE [master]
IF NOT EXISTS(SELECT * FROM sys.databases WHERE name = 'SpiTech_PaymentGateWay')
  BEGIN
    CREATE DATABASE [SpiTech_PaymentGateWay]
 END
GO
       
 USE [SpiTech_PaymentGateWay]
    
GO

