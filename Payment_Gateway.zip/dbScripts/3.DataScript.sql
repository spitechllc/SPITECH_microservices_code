SET XACT_ABORT ON;
GO

BEGIN TRANSACTION;
GO
INSERT [PaymentMethod] ([PaymentMethodId], [PaymentMethodName], [PaymentType], [IsActive], [CreatedOn])
VALUES
(1, N'CreditCard', 'Credit', 1, GETUTCDATE()),
(2, N'ACH', 'Cash', 1, GETUTCDATE()),
(3, N'CashReward', 'Credit', 1, GETUTCDATE());
GO

INSERT [PaymentStatus] ([PaymentStatusId], [PaymentStatusName], [IsActive], [CreatedOn])
VALUES
(1, N'Initiated',  1, GETUTCDATE()),
(2, N'Processed',  1, GETUTCDATE()),
(3, N'Success',  1, GETUTCDATE()),
(4, N'Void',  1, GETUTCDATE()),
(5, N'Fail',  1, GETUTCDATE());
GO

GO
INSERT [dbo].[PaymentGatewayconfig] ([PaymentGatewayconfigId], [GateWayName], [IsProdEnabled], [IsActive], [CreatedOn])
VALUES
(1, N'NMI', 0, 1, GETUTCDATE()),
(2, N'PlaidWithDowlla', 0, 1, GETUTCDATE()),
(3, N'PlaidWithStride', 0, 1, GETUTCDATE()),
(4, N'PlaidWithNMI', 0, 1, GETUTCDATE()),
(5, N'VeriCheck', 0, 1, GETUTCDATE());
GO


SET IDENTITY_INSERT [dbo].[UserPaymentMethod] ON 
GO
INSERT INTO [dbo].[UserPaymentMethod]([UserPaymentMethodId],[PaymentMethodId],[UserId],[PaymentGatewayConfigId],[CardName],[CardExpDate],[CardNumber]
,[CardType],[AccountNumber],[AccountType],[CustId],[Operation],[Source],[Token],[TransactionToken],[IsDefault],[IsActive],[CreatedOn])
VALUES
(1,3,null,null,'CashReward','2035-12-01 00:00:00.000','0000','CashReward',null,null,null,null,null,'','',0,1,getutcdate());
GO
SET IDENTITY_INSERT [dbo].[UserPaymentMethod] OFF
GO

COMMIT TRANSACTION;
GO

