#!/bin/bash
cd ..
echo "################################################DotNet Build########################################################"

dotnet build

echo "##############################################DotNet Publish########################################################"

dotnet publish

echo "################################################Docker Build########################################################"

docker build -f Deployment/dockerfile -t prod/paymentgateway .

echo "##################################################Docker Tag########################################################"

docker tag prod/paymentgateway prodregistry00.azurecr.io/prod/paymentgateway
echo "successfully tagged the image "

echo "#################################################Docker Push########################################################"

docker push prodregistry00.azurecr.io/prod/paymentgateway

