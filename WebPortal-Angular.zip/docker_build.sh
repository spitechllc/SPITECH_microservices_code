#!/bin/bash
echo "################################################DotNet Build########################################################"

dotnet build

echo "##############################################DotNet Publish########################################################"

dotnet publish

echo "################################################Docker Build########################################################"

docker build -t SpiTech/webportal-angular .

echo "##################################################Docker Tag########################################################"

docker tag SpiTech/webportal-angular prodregistry00.azurecr.io/SpiTech/webportal-angular
echo "successfully tagged the image "

echo "#################################################Docker Push########################################################"

docker push PRODregistry00.azurecr.io/SpiTech/webportal-angular

