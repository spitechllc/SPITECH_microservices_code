import { NgModule } from '@angular/core';
import { SharedModule } from './../../../shared.module';
import { CarWashCodesComponent } from './car-wash-codes.component';
import { RouterModule, Routes } from '@angular/router';
import { AdminGuardGuard } from '../../auth/admin-guard.guard';

export const router: Routes = [
  {
    path: '',
    component: CarWashCodesComponent,
    canActivate: [AdminGuardGuard],
  },
];

@NgModule({
    declarations: [CarWashCodesComponent],
    imports: [SharedModule, RouterModule.forChild(router)]
})
export class CarWashCodesModule {}
