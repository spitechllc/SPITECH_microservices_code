import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarWashCodesComponent } from './car-wash-codes.component';

describe('CarWashCodesComponent', () => {
  let component: CarWashCodesComponent;
  let fixture: ComponentFixture<CarWashCodesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CarWashCodesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CarWashCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
