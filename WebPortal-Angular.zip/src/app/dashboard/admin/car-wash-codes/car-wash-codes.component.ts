import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';

@Component({
  selector: 'app-car-wash-codes',
  templateUrl: './car-wash-codes.component.html',
  styleUrls: ['./car-wash-codes.component.scss']
})
export class CarWashCodesComponent implements OnInit {

  displayedColumns: string[] = ['id', 'storename', 'carwashtype', 'date', 'codestatus', 'action'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);


  constructor() { }

  ngOnInit(): void {
  }

}


export interface PeriodicElement {
  id: string;
  storename: string;
  carwashtype: string;
  date: string;
  color: string;
  codestatus: string;
  action: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {id: '1', storename:'Gold Smith1', carwashtype: 'Soft Touch Free', date: '10 Jun 2021 -  15 sep 2021',color: "04ab09", codestatus: 'active', action: 'Edit'},
  {id: '2', storename:'Gold Smith1', carwashtype: 'Soft Touch Free', date: '10 Jun 2021 -  15 sep 2021',color: "149dcb", codestatus: 'expired', action: 'Edit'},
];
