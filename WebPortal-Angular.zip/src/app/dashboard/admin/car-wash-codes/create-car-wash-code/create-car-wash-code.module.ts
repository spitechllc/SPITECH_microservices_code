import { NgModule } from '@angular/core';
import { SharedModule } from './../../../../shared.module';
import { CreateCarWashCodeComponent } from './create-car-wash-code.component';
import { RouterModule, Routes } from '@angular/router';


export const router: Routes = [
  {path: '', component: CreateCarWashCodeComponent}
]


@NgModule({
    declarations: [CreateCarWashCodeComponent],
    imports: [
        SharedModule,
        RouterModule.forChild(router)
    ]
})
export class CreateCarWashCodeModule { }
