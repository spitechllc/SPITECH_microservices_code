import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-create-car-wash-code',
  templateUrl: './create-car-wash-code.component.html',
  styleUrls: ['./create-car-wash-code.component.scss'],
})
export class CreateCarWashCodeComponent implements OnInit {
  range = new FormGroup({
    start: new FormControl(),
    end: new FormControl(),
  });

  checked = true;

  constructor() {}

  ngOnInit(): void {}
}
