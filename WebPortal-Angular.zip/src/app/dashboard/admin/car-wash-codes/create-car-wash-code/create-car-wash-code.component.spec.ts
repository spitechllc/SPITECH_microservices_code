import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateCarWashCodeComponent } from './create-car-wash-code.component';

describe('CreateCarWashCodeComponent', () => {
  let component: CreateCarWashCodeComponent;
  let fixture: ComponentFixture<CreateCarWashCodeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateCarWashCodeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateCarWashCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
