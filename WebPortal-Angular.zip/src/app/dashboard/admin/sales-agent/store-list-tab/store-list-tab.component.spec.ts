import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StoreListTabComponent } from './store-list-tab.component';

describe('StoreListTabComponent', () => {
  let component: StoreListTabComponent;
  let fixture: ComponentFixture<StoreListTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StoreListTabComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StoreListTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
