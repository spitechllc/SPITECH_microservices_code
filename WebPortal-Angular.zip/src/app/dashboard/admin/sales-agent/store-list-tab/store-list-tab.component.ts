import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { debounce, indexOf } from 'lodash';
import { ToastrService } from 'ngx-toastr';
import { StoreService } from 'src/app/dashboard/api-service/storeService';
import { SubSink } from 'subsink';
import { StoreTable } from '../../store/store-tab/store-tab.component';

import { SaleAgentFeeComponent } from '../sale-agent-fee/sale-agent-fee.component';

@Component({
  selector: 'app-store-list-tab',
  templateUrl: './store-list-tab.component.html',
  styleUrls: ['./store-list-tab.component.scss'],
})
export class StoreListTabComponent implements OnInit {
  displayedColumns = ['storeId', 'siteId', 'storeName', 'action'];

  dataSource = new MatTableDataSource<StoreTable>([]);

  subs = new SubSink();
  saleAgentId: any = null;
  get storeIds() {
    return this.saleAgentForm.get('storeIds') as FormArray;
  }
  constructor(
    private activatedRoute: ActivatedRoute,
    private storeService: StoreService,
    private _location: Location,
    public dialog: MatDialog,
    private fb: FormBuilder,
    private toster: ToastrService
  ) {}
  saleAgentForm!: FormGroup;
  ngOnInit(): void {
    this.getSaleAgentId();
    this.createForm();
    this.getALLStore();
  }

  createForm() {
    this.saleAgentForm = this.fb.group({
      storeIds: [],
      saleAgentId: new FormControl(this.saleAgentId),
    });
  }
  storesId: any = [0];
  onChangeid(event: any) {
    if (event._selected == true) {
      this.storesId.push(event.value);
    }
    console.log(event);
    console.log(this.storeIds);
    if (event._selected == false) {
      const index: number = this.storesId.indexOf(event.value);
      if (index !== -1) {
        this.storesId.splice(index, 1);
      }
    }
  }
  updateSaleAgentStores() {
    this.storeService
      .updateSaleAgentStores({
        storeIds: this.storesId,
        saleAgentId: this.saleAgentId,
      })
      .subscribe((data) => {
        this.toster.success('Store Update in this Sales agent');
        this.getSalesDetails(this.saleAgentId);
      });
  }

  getSaleAgentId() {
    this.subs.add(
      this.activatedRoute.paramMap.subscribe((params) => {
        this.saleAgentId = params.get('saleAgentId');
        // console.log(this.saleAgentId);
        if (this.saleAgentId) {
          this.getSalesDetails(this.saleAgentId);
        }
      })
    );
  }
  length: any = null;
  salesAgentDetails: any = [];
  getSalesDetails(id: any) {
    this.storeService.getSalesAgentById(id).subscribe((data: any) => {
      this.salesAgentDetails = data.stores;

      this.saleAgentForm.patchValue({
        storeIds: data.storeIds,
      });

      if (data.stores == null) {
        this.length = 0;
      }
      if (data.stores) {
        this.length = 1;
        this.storesId = data.storeIds;
      }
      this.dataSource = new MatTableDataSource(data.stores);
    });
  }
  cancelBUtton() {
    this._location.back();
  }
  saleAgentFee(action: any, obj: any) {
    obj.action = action;
    const dialogRef = this.dialog.open(SaleAgentFeeComponent, {
      width: '430px',
      panelClass: 'popup',
      data: obj,
    });
    dialogRef.afterClosed().subscribe((data: any) => {});
  }
  suggestEventValue: any;
  storeDetails: any;
  lengthsite: any;
  dataNotFond: string = 'Data not found';
  StoreId: any;
  SiteId: any;
  onChange(event: any) {
    this.suggestEventValue = event;
  }
  serachBySiteId = debounce((event: any) => {
    if (!event.target.value) {
      this.StoreId = 0;
    }
    this.storeService
      .getStoreAutoCompleteBySiteId(event.target.value)
      .subscribe((data: any) => {
        this.lengthsite = data.data.length;

        this.storeDetails = data.data;
        this.SiteId = this.storeDetails.siteId;
        this.StoreId = this.storeDetails.storeId;
      });
  }, 1000);
  serachByStoreName = debounce((event: any) => {
    if (!event.target.value) {
      this.StoreId = 0;
    }
    this.storeName = event.target.value;
    this.getALLStore();
  }, 1000);
  onClickSiteIdd(event: any) {
    this.SiteId = event;
    this.StoreId = event;
  }

  storeName: string = '';
  StoreIds: number = 0;
  getSearchByStoreId = debounce(($event: any) => {
    if ($event.target.value == '') {
      this.getALLStore();
    } else {
      this.storeService
        .getStoreAutoCompleteByStoreId($event.target.value)
        .subscribe((data: any) => {
          this.storeDetails = data.data;
        });
    }
  }, 1000);
  getALLStore() {
    this.storeService
      .getStoreAutoCompleteByStoreName(this.storeName)
      .subscribe((data: any) => {
        this.storeDetails = data.data;
      });
  }

  storeNames: string = '';
  selectedValue: any = [];
  onChaneStorId(stoteId: any) {
    this.storeDetails.filter((element: any) => {
      if (element.storeId == stoteId) {
        this.storeNames = element.storeName;
        return element.storeName;
      }
    });
  }
}
