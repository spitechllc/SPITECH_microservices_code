import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SalesAgentComponent } from './sales-agent.component';
import { RouterModule, Routes } from '@angular/router';
import { AdminGuardGuard } from '../../auth/admin-guard.guard';
import { SharedModule } from 'src/app/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SalesAgentTabComponent } from './sales-agent-tab/sales-agent-tab.component';
import { AddEditsSaleAgentComponent } from './edits-sale-agent/add-edits-sale-agent.component';
import { SaleAgentConfigComponent } from './sale-agent-config/sale-agent-config.component';
import { StoreListTabComponent } from './store-list-tab/store-list-tab.component';
import { AddEditStoreComponent } from '../store/create-store/add-edit-store/add-edit-store.component';
import { RolePermissionGuard } from '../../auth/role-permission.guard';
import { SaleAgentFeeComponent } from './sale-agent-fee/sale-agent-fee.component';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { NgxMaskModule, IConfig } from 'ngx-mask';
import { SaleagentExcelExportComponent } from './saleagent-excel-export/saleagent-excel-export.component';
export const options: Partial<null | IConfig> | (() => Partial<IConfig>) = null;
export const router: Routes = [
  {
    path: '',
    component: SalesAgentComponent,
    canActivate: [AdminGuardGuard],
  },
  // { path: 'edit-sales-agent/:id', component: SalesAgentTabComponent },
  { path: 'edit-sales-agent/:saleAgentId', component: SalesAgentTabComponent },
  // {
  //   path: ':id/add-store/edit/:id',
  //   canActivate: [AdminGuardGuard],

  //   loadChildren: () =>
  //     import('../store/create-store/create-store.module').then(
  //       (m) => m.CreateStoreModule
  //     ),
  // },
  // {
  //   path: '/edit-store/:id',
  //   component: AddEditStoreComponent,
  // },
];

@NgModule({
  declarations: [
    SalesAgentComponent,
    SalesAgentTabComponent,
    AddEditsSaleAgentComponent,
    SaleAgentConfigComponent,
    StoreListTabComponent,
    SaleAgentFeeComponent,
    SaleagentExcelExportComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    NgxMaskModule.forRoot({
      showMaskTyped: true,
      // clearIfNotMatch : true
    }),
    MatAutocompleteModule,
    RouterModule.forChild(router),
  ],
})
export class SalesAgentModule {}
