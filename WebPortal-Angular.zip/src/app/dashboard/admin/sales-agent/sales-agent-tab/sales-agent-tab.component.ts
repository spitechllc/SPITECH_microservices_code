import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/dashboard/auth/auth.service';

@Component({
  selector: 'app-sales-agent-tab',
  templateUrl: './sales-agent-tab.component.html',
  styleUrls: ['./sales-agent-tab.component.scss'],
})
export class SalesAgentTabComponent implements OnInit {
  constructor(private auth: AuthService) {}
  claimIdArray: any;
  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
}
