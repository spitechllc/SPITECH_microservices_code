import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SalesAgentTabComponent } from './sales-agent-tab.component';

describe('SalesAgentTabComponent', () => {
  let component: SalesAgentTabComponent;
  let fixture: ComponentFixture<SalesAgentTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SalesAgentTabComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SalesAgentTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
