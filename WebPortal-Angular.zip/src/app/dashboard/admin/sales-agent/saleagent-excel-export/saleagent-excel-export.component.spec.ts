import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaleagentExcelExportComponent } from './saleagent-excel-export.component';

describe('SaleagentExcelExportComponent', () => {
  let component: SaleagentExcelExportComponent;
  let fixture: ComponentFixture<SaleagentExcelExportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SaleagentExcelExportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SaleagentExcelExportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
