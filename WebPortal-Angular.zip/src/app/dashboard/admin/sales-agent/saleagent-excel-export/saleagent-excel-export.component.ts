import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { ExcelService } from 'src/app/dashboard/api-service/excel-servive/excel.service';

@Component({
  selector: 'app-saleagent-excel-export',
  templateUrl: './saleagent-excel-export.component.html',
  styleUrls: ['./saleagent-excel-export.component.scss'],
})
export class SaleagentExcelExportComponent implements OnInit {
  constructor(
    private excelService: ExcelService,
    public dialogRef: MatDialogRef<SaleagentExcelExportComponent>,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: { data: any }
  ) {
    this.excelData = data;
    // console.log(this.excelData);
  }
  excelData: any;
  saleAgentId: boolean = true;
  firstName: boolean = true;

  lastName: boolean = true;

  createdOn: boolean = true;

  number: boolean = true;
  email: boolean = true;
  addressLine1: boolean = true;
  addressLine2: boolean = true;
  city: boolean = true;
  state: boolean = true;
  country: boolean = true;
  zipCode: boolean = true;
  ngOnInit(): void {}

  onClickChexBox(event: any) {
    if (event.source.value == 'saleAgentId' && event.checked == false) {
      this.saleAgentId = false;
    } else if (event.source.value == 'saleAgentId' && event.checked == true) {
      this.saleAgentId = true;
    }
    if (event.source.value == 'firstName' && event.checked == false) {
      this.firstName = false;
    } else if (event.source.value == 'firstName' && event.checked == true) {
      this.firstName = true;
    }

    if (event.source.value == 'lastName' && event.checked == false) {
      this.lastName = false;
    } else if (event.source.value == 'lastName' && event.checked == true) {
      this.lastName = true;
    }

    if (event.source.value == 'number' && event.checked == false) {
      this.number = false;
    } else if (event.source.value == 'number' && event.checked == true) {
      this.number = true;
    }
    if (event.source.value == 'email' && event.checked == false) {
      this.email = false;
    } else if (event.source.value == 'email' && event.checked == true) {
      this.email = true;
    }
    if (event.source.value == 'addressLine1' && event.checked == false) {
      this.addressLine1 = false;
    } else if (event.source.value == 'addressLine1' && event.checked == true) {
      this.addressLine1 = true;
    }
    if (event.source.value == 'addressLine2' && event.checked == false) {
      this.addressLine2 = false;
    } else if (event.source.value == 'addressLine2' && event.checked == true) {
      this.addressLine2 = true;
    }
    if (event.source.value == 'city' && event.checked == false) {
      this.city = false;
    } else if (event.source.value == 'city' && event.checked == true) {
      this.city = true;
    }
    if (event.source.value == 'state' && event.checked == false) {
      this.state = false;
    } else if (event.source.value == 'state' && event.checked == true) {
      this.state = true;
    }
    if (event.source.value == 'country' && event.checked == false) {
      this.country = false;
    } else if (event.source.value == 'country' && event.checked == true) {
      this.country = true;
    }
    if (event.source.value == 'zipCode' && event.checked == false) {
      this.zipCode = false;
    } else if (event.source.value == 'zipCode' && event.checked == true) {
      this.zipCode = true;
    }
  }
  excelExport() {
    const excelExportData = this.excelData.map((t: any) => {
      const dataObject: any = {};
      if (this.saleAgentId == true) {
        dataObject.saleAgentId = t.saleAgentId;
      }

      if (this.firstName == true) {
        dataObject.firstName = t.firstName;
      }
      if (this.lastName == true) {
        dataObject.lastName = t.lastName;
      }
      if (this.createdOn == true) {
        dataObject.createdOn = t.createdOn;
      }

      if (this.number == true) {
        t.phones.map((p: any) => {
          dataObject.number = p.number;
          return p.number;
        });
      }
      if (this.email == true) {
        t.emails.map((p: any) => {
          dataObject.email = p.email;
          return p.email;
        });
      }
      if (this.addressLine1 == true) {
        t.addresses.map((a: any) => {
          dataObject.addressLine1 = a.addressLine1;
          return a.addressLine1;
        });
      }
      if (this.addressLine2 == true) {
        t.addresses.map((a: any) => {
          dataObject.addressLine2 = a.addressLine2;
          return a.addressLine2;
        });
      }
      if (this.city == true) {
        t.addresses.map((a: any) => {
          dataObject.city = a.city;
          return a.city;
        });
      }
      if (this.state == true) {
        t.addresses.map((a: any) => {
          dataObject.state = a.state;
          return a.state;
        });
      }
      if (this.country == true) {
        t.addresses.map((a: any) => {
          dataObject.country = a.country;
          return a.country;
        });
      }
      if (this.zipCode == true) {
        t.addresses.map((a: any) => {
          dataObject.zipCode = a.zipCode;
          return a.zipCode;
        });
      }

      return dataObject;
    });

    this.excelService.exportAsExcelFile(
      excelExportData,
      'saleagent-exported-data'
    );
  }
}
