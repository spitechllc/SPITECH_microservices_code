import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditsSaleAgentComponent } from './add-edits-sale-agent.component';

describe('AddEditsSaleAgentComponent', () => {
  let component: AddEditsSaleAgentComponent;
  let fixture: ComponentFixture<AddEditsSaleAgentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditsSaleAgentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditsSaleAgentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
