import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { RxwebValidators } from '@rxweb/reactive-form-validators';
import { debounce } from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { StoreService } from 'src/app/dashboard/api-service/storeService';
import { SharedService } from 'src/app/dashboard/auth/shared.service';
import { SubSink } from 'subsink';
@Component({
  selector: 'app-add-edits-sale-agent',
  templateUrl: './add-edits-sale-agent.component.html',
  styleUrls: ['./add-edits-sale-agent.component.scss'],
})
export class AddEditsSaleAgentComponent implements OnInit {
  salesAgentForm!: FormGroup;
  get f() {
    return this.salesAgentForm.controls;
  }
  get phones() {
    return this.salesAgentForm.get('phones') as FormArray;
  }
  get addresses() {
    return this.salesAgentForm.get('addresses') as FormArray;
  }

  get emails() {
    return this.salesAgentForm.get('emails') as FormArray;
  }

  subs = new SubSink();
  submitted: boolean = false;
  salesAgentData: any = [];
  addressCategory: any = [];
  phonecategory: any = [];
  emailcategory: any = [];
  countries: any = [];
  state: any = [];
  saleAgentId: any = null;
  constructor(
    private fb: FormBuilder,
    private storeService: StoreService,
    private toster: ToastrService,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private _location: Location,
    public SharedService: SharedService
  ) {}

  ngOnInit(): void {
    this.createSalesAgentForm();

    this.getEmailCategoryLevel();
    this.phoneCategory();
    this.getAddressCategoryLevel();
    this.getCountry();
    this.getSaleAgentId();
    this.tenantData = this.SharedService.tenantData;
  }
  tenantData: any;

  getSaleAgentId() {
    this.subs.add(
      this.activatedRoute.paramMap.subscribe((params) => {
        this.saleAgentId = params.get('saleAgentId');
        if (this.saleAgentId) {
          this.getSalesDetails(this.saleAgentId);
        }
      })
    );
  }
  getSalesDetails(id: any) {
    this.spinner.show();
    this.storeService.getSalesAgentById(id).subscribe((data: any) => {
      // console.log(data);
      this.setFormValue(data);
      this.spinner.hide();
    });
  }

  setFormValue(data: any) {
    this.salesAgentForm.patchValue({
      firstName: data.firstName,
      lastName: data.lastName,
      // tenantId: data.tenantId,
    });

    data.addresses.forEach((element: any, index: any) => {
      if (index < data.addresses.length - 1) {
        this.addAnotherAddress();
      }
      if (element.countryId) {
        this.storeService
          .getStates(element.countryId)
          .subscribe((data: any) => {
            this.state = data.data;
          });
      } else {
        this.state = null;
      }
      this.addresses.controls[index].patchValue(element);
    });
    data.phones.forEach((element: any, index: any) => {
      if (index < data.phones.length - 1) {
        this.addAnotherPhone();
      }
      this.phones.controls[index].patchValue(element);
    });
    data.emails.forEach((element: any, index: any) => {
      if (index < data.emails.length - 1) {
        this.addAnotherEmail();
      }
      this.emails.controls[index].patchValue(element);
    });
  }

  getAddressCategoryLevel() {
    this.storeService.getCategoryLavelAddress(10).subscribe((data: any) => {
      this.addressCategory = data.data;
    });
  }
  phoneCategory() {
    this.storeService.getCategoryLevelPhone(11).subscribe((data: any) => {
      this.phonecategory = data.data;
    });
  }
  getEmailCategoryLevel() {
    this.storeService.getCategoryLevelEmail(12).subscribe((data: any) => {
      this.emailcategory = data.data;
    });
  }
  getCountry() {
    this.storeService.getCountry().subscribe((data: any) => {
      this.countries = data.data;
    });
  }

  onChangeCountry(countryId: number) {
    if (countryId) {
      this.storeService.getStates(countryId).subscribe((data: any) => {
        this.state = data.data;
      });
    } else {
      this.state = null;
    }
  }

  createSalesAgentForm() {
    this.salesAgentForm = this.fb.group({
      firstName: new FormControl('', Validators.required),
      lastName: new FormControl('', Validators.required),
      // tenantId: new FormControl(0),
      addresses: this.fb.array([this.createAddressForm()]),
      phones: this.fb.array([this.createPhoneForm()]),
      emails: this.fb.array([this.createEmailForm()]),
    });
  }
  createEmailForm() {
    return this.fb.group({
      emailId: 0,
      categoryTypeLevelId: new FormControl(null, Validators.required),
      email: new FormControl('', Validators.required),
      isActive: true,
    });
  }
  addAnotherEmail() {
    this.emails.push(this.createEmailForm());
    if (this.emailcategory.length == this.emails.length) {
      var DATA = document.getElementById('addemail');

      DATA!.style.display = 'none';
    }
  }
  removeEmail(i: any) {
    // let i = this.emails.length - 1;
    this.emails.removeAt(i);
    var DATA = document.getElementById('addemail');
    DATA!.style.display = '';
  }
  isControlExist(categoryTypeLevelId: any): boolean {
    for (var i = 0; i < this.emails.controls.length; i++) {
      if (
        this.emails.controls[i].value.categoryTypeLevelId == categoryTypeLevelId
      ) {
        return true;
      }
    }

    return false;
  }

  onCopyClick(emailIndex: any) {
    const emailCopy = this.emails.controls[emailIndex].value.email;

    if (!this.emails.controls[emailIndex].valid) {
      this.toster.error('Please enter a valid email before copy');
      return;
    }
    for (var i = 0; i < this.emails.controls.length; i++) {
      if (this.emails.controls[i].value.categoryTypeLevelId <= 0) {
        this.toster.error('Please remove blank category before copy');
        return;
      }
    }

    this.emailcategory.forEach((emailCat: any, index: any) => {
      if (!this.isControlExist(emailCat.id)) {
        if (this.emails.controls.length < this.emailcategory.length) {
          this.addAnotherEmail();
          this.emails.controls[this.emails.controls.length - 1].patchValue({
            categoryTypeLevelId: emailCat.id,
            email: emailCopy,
          });
        }
      } else {
        for (var i = 0; i < this.emails.controls.length; i++) {
          this.emails.controls[i].patchValue({
            email: emailCopy,
          });
        }
      }
    });
  }
  createPhoneForm() {
    return this.fb.group({
      phoneId: 0,
      categoryTypeLevelId: new FormControl(null, Validators.required),
      countryCode: new FormControl('+1', Validators.required),
      areaCode: new FormControl(''),
      number: new FormControl(
        '',
        Validators.compose([
          Validators.required,
          Validators.pattern('[- +()0-9]+'),
          RxwebValidators.unique(),
        ])
      ),
      isActive: true,
    });
  }
  countryCode: any;
  countryChange(value: any) {
    // console.log(value);
    this.countryCode = value;
  }
  addAnotherPhone() {
    this.phones.push(this.createPhoneForm());
  }

  removePhone(i: any) {
    // let i = this.phones.length - 1;
    this.phones.removeAt(i);
  }
  createAddressForm() {
    return this.fb.group({
      addressId: 0,
      categoryTypeLevelId: new FormControl(null, Validators.required),
      addressLine1: new FormControl('', Validators.required),
      addressLine2: new FormControl(''),
      countryId: new FormControl(null, Validators.required),
      country: new FormControl(''),
      stateId: new FormControl(null, Validators.required),
      state: new FormControl(''),
      city: new FormControl(''),
      longitude: new FormControl(null),
      latitude: new FormControl(null),
      zipCode: new FormControl(
        '',
        Validators.compose([
          Validators.required,
          Validators.pattern('[- +()0-9]+'),
        ])
      ),
      isActive: true,
      companyId: null,
      storeId: null,
      userId: null,
      saleAgentId: null,
    });
  }
  addAnotherAddress() {
    this.addresses.push(this.createAddressForm());
  }
  removeAddress(i: any) {
    // let i = this.addresses.length - 1;
    this.addresses.removeAt(i);
  }
  submit() {
    // console.log(this.addStoreForm.value);
    this.submitted = true;
    if (this.salesAgentForm.invalid) return;
    if (this.saleAgentId) {
      this.updateSaleAgent();
    }
    if (!this.saleAgentId) {
      this.createSaleAgent();
    }
  }

  createSaleAgent() {
    this.storeService.createSalesAgent(this.salesAgentForm.value).subscribe(
      (data: any) => {
        this.toster.success('Sales Agent Create Successfully');
        this.cancelBUtton();
      },
      (err) => {
        if (err.status == 401) {
          this.toster.error('Resource not found');
        }
        if (err.status == 500) {
          this.toster.error('Internal server error');
        }
      }
    );
  }

  updateSaleAgent() {
    this.storeService
      .updateSaleAgent({
        ...this.salesAgentForm.value,
        saleAgentId: this.saleAgentId,
      })
      .subscribe(
        (data: any) => {
          this.toster.success('Sale Agent Update Successfully');
          this.cancelBUtton();
        },
        (err) => {
          if (err.status == 401) {
            this.toster.error('Resource not found');
          }
          if (err.status == 500) {
            this.toster.error('Internal server error');
          }
        }
      );
  }
  cancelBUtton() {
    this._location.back();
  }
}
