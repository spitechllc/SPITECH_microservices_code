import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddEditSaleAgentComponent } from './add-edit-sale-agent.component';
import { RouterModule, Routes } from '@angular/router';
import { AdminGuardGuard } from 'src/app/dashboard/auth/admin-guard.guard';
import { SharedModule } from 'src/app/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TagInputModule } from 'ngx-chips';
import { RxReactiveFormsModule } from '@rxweb/reactive-form-validators';
import { NgxMaskModule, IConfig } from 'ngx-mask';
export const options: Partial<null | IConfig> | (() => Partial<IConfig>) = null;
export const router: Routes = [
  {
    path: '',
    component: AddEditSaleAgentComponent,
    canActivate: [AdminGuardGuard],
  },
  // {
  //   path: 'admin/sales-agent/edit-sales-agent/:id',
  //   component: AddEditSaleAgentComponent,
  //   canActivate: [AdminGuardGuard],
  // },
];

@NgModule({
  declarations: [AddEditSaleAgentComponent],
  imports: [
    SharedModule,
    FormsModule,
    TagInputModule,
    NgxMaskModule.forRoot({
      showMaskTyped: true,
      // clearIfNotMatch : true
    }),
    ReactiveFormsModule,
    RxReactiveFormsModule,
    RouterModule.forChild(router),
  ],
})
export class AddEditSaleAgentModule {}
