import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditSaleAgentComponent } from './add-edit-sale-agent.component';

describe('AddEditSaleAgentComponent', () => {
  let component: AddEditSaleAgentComponent;
  let fixture: ComponentFixture<AddEditSaleAgentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditSaleAgentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditSaleAgentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
