import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaleAgentFeeComponent } from './sale-agent-fee.component';

describe('SaleAgentFeeComponent', () => {
  let component: SaleAgentFeeComponent;
  let fixture: ComponentFixture<SaleAgentFeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SaleAgentFeeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SaleAgentFeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
