import { Component, Inject, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
import { TransactionService } from 'src/app/dashboard/api-service/trasation.service';
import { AuthService } from 'src/app/dashboard/auth/auth.service';

export interface UsersData {
  roleId: number;
  roleName: string;
}

@Component({
  selector: 'app-sale-agent-fee',
  templateUrl: './sale-agent-fee.component.html',
  styleUrls: ['./sale-agent-fee.component.scss'],
})
export class SaleAgentFeeComponent implements OnInit {
  local_data: any;
  roleId: any;
  submitted: boolean = false;
  get f() {
    return this.saleAgentFeeForm.controls;
  }
  constructor(
    private transationService: TransactionService,
    private formBuilder: FormBuilder,
    private toster: ToastrService,
    private activatedRoute: ActivatedRoute,
    private spinner: NgxSpinnerService,
    private auth: AuthService,
    public dialogRef: MatDialogRef<SaleAgentFeeComponent>,
    @Inject(MAT_DIALOG_DATA) public data: UsersData,
    private router: Router
  ) {
    // console.log(data);
    this.storeData = data;
    if (this.storeData) {
      this.getSaleAgentFee();
    }
  }
  storeData: any = {};
  claimIdArray: any;
  ngOnInit(): void {
    this.createForm();
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }

  saleAgentFeeForm!: FormGroup;
  createForm() {
    this.saleAgentFeeForm = this.formBuilder.group({
      saleAgentId: new FormControl(this.storeData.saleAgentId),
      storeId: new FormControl(this.storeData.storeId),
      transactionPercentageFee: new FormControl(null, Validators.required),
      monthlySaasFee: new FormControl(null, Validators.required),
      isDefault: false,
    });
  }
  saleAgentFeeId: any;
  defaultSaleAgentFeeData: any;
  getDefaultSaleAgentFee() {
    this.transationService
      .getDefaultSaleAgentFeeSetup()
      .subscribe((data: any) => {
        this.defaultSaleAgentFeeData = data.data;

        this.saleAgentFeeForm.patchValue({
          transactionPercentageFee:
            this.defaultSaleAgentFeeData.transactionPercentageFee,
          monthlySaasFee: this.defaultSaleAgentFeeData.monthlySaasFee,
        });
        // console.log(this.defaultSaleAgentFeeData, 'defaultSaleAgentFeeData');
      });
  }
  getSaleAgentFee() {
    this.transationService
      .getSaleAgentFeeBySaleAgentId(
        this.storeData.saleAgentId,
        this.storeData.storeId
      )
      .subscribe(
        (data: any) => {
          // console.log(data);
          this.saleAgentFeeId = data.data.saleAgentFeeId;
          this.saleAgentFeeForm.patchValue({
            transactionPercentageFee: data.data.transactionPercentageFee,
            monthlySaasFee: data.data.monthlySaasFee,
          });
        },
        (err) => {
          if (err.status == 400) {
            this.toster.error('Bad request');
          }
          if (err.status == 500) {
            this.toster.error('Internal server error');
          }
          if (err.status == 401) {
            this.toster.error('Reasource not found');
          }
        }
      );
  }

  addsaleAgentFee() {
    this.transationService
      .addSaleAgentFee(this.saleAgentFeeForm.value)
      .subscribe(
        (data: any) => {
          if (data.success == true) {
            this.toster.success('Add successfully sale agent fee');
            this.dialogRef.close([]);
          }
          if (data.success == false) {
            this.toster.error(data.message);
          }
        },
        (err) => {
          if (err.status == 400) {
            this.toster.error('Bad request');
          }
          if (err.status == 500) {
            this.toster.error('Internal server error');
          }
          if (err.status == 401) {
            this.toster.error('Reasource not found');
          }
        }
      );
  }

  updateSaleAgentFee() {
    this.transationService
      .updateSaleAgentFee({
        transactionPercentageFee: this.saleAgentFeeForm.get(
          'transactionPercentageFee'
        )?.value,
        monthlySaasFee: this.saleAgentFeeForm.get('monthlySaasFee')?.value,
        saleAgentFeeId: this.saleAgentFeeId,
        isActive: true,
      })
      .subscribe(
        (data: any) => {
          if (data.success == true) {
            this.toster.success('Sale agent fee update successfully');
            this.dialogRef.close([]);
          }
          if (data.success == false) {
            this.toster.error(data.message);
          }
        },
        (err) => {
          if (err.status == 400) {
            this.toster.error('Bad request');
          }
          if (err.status == 500) {
            this.toster.error('Internal server error');
          }
          if (err.status == 401) {
            this.toster.error('Reasource not found');
          }
        }
      );
  }
}
