import { Component, OnInit, ViewChild } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { debounce } from 'lodash';
import { NgxSpinner, NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ExcelService } from '../../api-service/excel-servive/excel.service';
import { StoreService } from '../../api-service/storeService';
import { AuthService } from '../../auth/auth.service';
import { SharedService } from '../../auth/shared.service';

import { UserTable } from '../user/user-tab/user-tab.component';
import { SaleagentExcelExportComponent } from './saleagent-excel-export/saleagent-excel-export.component';

@Component({
  selector: 'app-sales-agent',
  templateUrl: './sales-agent.component.html',
  styleUrls: ['./sales-agent.component.scss'],
})
export class SalesAgentComponent implements OnInit {
  displayedColumns = [
    'saleAgentId',
    'firstName',
    'lastName',
    'PhoneNumber',
    'EmailAddress',
    'isActive',
    'action',
  ];
  dataSource = new MatTableDataSource<UserTable>([]);
  @ViewChild(MatSort) sort: MatSort;
  salesAgentData: any = [];
  constructor(
    private fb: FormBuilder,
    private storeService: StoreService,
    private toster: ToastrService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private activateRoute: ActivatedRoute,
    private excelService: ExcelService,
    private auth: AuthService,
    public sharedService: SharedService,
    public dialog: MatDialog
  ) {}
  searchEvent: any;
  firstLastName: string = '';
  mobile: string = '';
  email: string = '';
  pageIndex: number = 1;
  pageSize: number = 50;
  storeName: string = '';
  sortBy = 'saleAgentId';
  sortOrder: string = 'desc';
  total: number = 0;
  paramsData: any;
  allSalesAgentData: any = [];
  claimIdArray: any;
  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.activateRoute.queryParamMap.subscribe((data: any) => {
      this.paramsData = data.params;
    });
    if (this.paramsData.data == 'true') {
      this.pageIndex = this.paramsData.pageIndex;
      this.pageSize = this.paramsData.pageSize;

      this.searchEvent = this.paramsData.searchEvent
        ? this.paramsData.searchEvent
        : 0;
      this.email = this.paramsData.email ? this.paramsData.email : '';
      this.storeName = this.paramsData.storeName
        ? this.paramsData.storeName
        : '';
      this.firstLastName = this.paramsData.firstLastName
        ? this.paramsData.firstLastName
        : '';
      this.mobile = this.paramsData.mobile ? this.paramsData.mobile : '';
      this.getSalesAgent();
    } else {
      this.getSalesAgent();
    }
  }

  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  phones: any;
  number: any;
  emails: any;
  addressline1: any;
  addressline2: any;
  city: any;
  state: any;
  exportAsExcel() {
    var pageSize = 0;
    var pageIndex = 0;

    this.storeService
      .saleAgent(
        this.firstLastName,
        this.mobile,
        this.email,
        this.storeName,
        pageIndex,
        pageSize,
        this.sortBy,
        this.sortOrder
      )
      .subscribe((data: any) => {
        // console.log(data);
        this.allSalesAgentData = data.data;
        const dialogRef = this.dialog.open(SaleagentExcelExportComponent, {
          width: '450px',
          panelClass: 'popup',
          data: this.allSalesAgentData,
        });
        // console.log(this.number);
        // if (this.allSalesAgentData.length > 0) {
        //   this.excelService.exportAsExcelFile(
        //     this.allSalesAgentData.map((s: any) => {
        //       return {
        //         SaleAgentId: s.saleAgentId,
        //         'First Name': s.firstName,
        //         'Last Name': s.lastName,
        //         'Mobile Number': s.phones.map((p: any) => {
        //           // console.log(p.number);
        //           this.number = p.number;
        //           return { MobileNumber: p.number };
        //         })
        //           ? this.number
        //           : '',
        //         Email: s.emails.map((e: any) => {
        //           this.emails = e.email;
        //           return { email: e.email };
        //         })
        //           ? this.emails
        //           : '',
        //         AddressLine1: s.addresses.map((a: any) => {
        //           this.addressline1 = a.addressLine1;
        //           this.city = a.city;
        //           this.state = a.state;
        //           this.addressline2 = a.addressLine2;
        //           return {};
        //         })
        //           ? this.addressline1
        //           : '',

        //         AddressLine2: this.addressline2,
        //         City: this.city,
        //         State: this.state,
        //       };
        //     }),
        //     'sales-agent'
        //   );
        // } else {
        //   this.toster.error('Data not found');
        // }
      });
  }

  onChange(event: any) {
    this.searchEvent = event;
    this.sortBy = '';
    this.sortOrder = '';
    if (event == 0) {
      this.firstLastName = '';
      this.email = '';
      this.storeName = '';
      this.mobile = '';
      this.searchEvent = 0;
      this.router.navigate(['/admin/sales-agent'], {
        queryParams: {
          pageIndex: this.pageIndex,
          pageSize: this.pageSize,

          searchEvent: (this.searchEvent = 0),
          data: 'true',
          firstLastName: (this.firstLastName = ''),
          email: (this.email = ''),
          storeName: (this.storeName = ''),
          mobile: (this.mobile = ''),
        },
        queryParamsHandling: 'merge',
      });

      this.getSalesAgent();
    }
  }
  filterByName = debounce(($event: any) => {
    this.firstLastName = $event.target.value;
    this.pageIndex = 1;
    this.router.navigate(['/admin/sales-agent'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        searchEvent: this.searchEvent,
        data: 'true',
        firstLastName: this.firstLastName,
        email: (this.email = ''),
        storeName: (this.storeName = ''),
        mobile: (this.mobile = ''),
      },
      queryParamsHandling: 'merge',
    });

    this.getSalesAgent();
  }, 1000);

  filterByMobile = debounce(($event: any) => {
    this.mobile = $event.target.value;
    this.pageIndex = 1;

    this.router.navigate(['/admin/sales-agent'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        searchEvent: this.searchEvent,
        data: 'true',
        mobile: this.mobile,
        firstLastName: (this.firstLastName = ''),
        email: (this.email = ''),
        storeName: (this.storeName = ''),
      },
      queryParamsHandling: 'merge',
    });

    this.getSalesAgent();
  }, 1000);

  filterByEmail = debounce(($event: any) => {
    this.email = $event.target.value;
    this.pageIndex = 1;
    this.total = 0;

    this.router.navigate(['/admin/sales-agent'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        searchEvent: this.searchEvent,
        data: 'true',
        email: this.email,
        mobile: (this.mobile = ''),
        firstLastName: (this.firstLastName = ''),

        storeName: (this.storeName = ''),
      },
      queryParamsHandling: 'merge',
    });

    this.getSalesAgent();
  }, 1000);

  // filter by store name

  filterByStoreName = debounce(($event: any) => {
    this.storeName = $event.target.value;
    this.pageIndex = 1;

    this.router.navigate(['/admin/sales-agent'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        data: 'true',
        searchEvent: this.searchEvent,
        storeName: this.storeName,
        mobile: (this.mobile = ''),
        firstLastName: (this.firstLastName = ''),
        email: (this.email = ''),
      },
      queryParamsHandling: 'merge',
    });

    this.getSalesAgent();
  }, 1000);

  // On sort header
  onHeaderSortChange(event: any) {
    this.sortBy = event.active;
    if (event.direction == '') {
      this.sortOrder = 'asc';
    } else {
      this.sortOrder = event.direction;
    }

    this.getSalesAgent();
  }

  // get sales agent
  getSalesAgent() {
    this.storeService
      .saleAgent(
        this.firstLastName,
        this.mobile,
        this.email,
        this.storeName,
        this.pageIndex,
        this.pageSize,
        this.sortBy,
        this.sortOrder
      )
      .subscribe(
        (data: any) => {
          this.salesAgentData = data.data;
          this.dataSource = new MatTableDataSource(this.salesAgentData);
          this.total = data.totalCount;

          this.spinner.hide();
          this.queryParams();
        },
        (err) => {
          if (err.error.errors.saleAgentId) {
            err.error.errors.saleAgentId.forEach((err: any) => {
              this.toster.error(err);
            });
          }
        }
      );
  }
  pageChanged(event: any) {
    // console.log(event);
    this.pageIndex = event.pageIndex + 1;

    this.pageSize = event.pageSize;

    this.queryParams();

    this.getSalesAgent();
  }
  queryParams() {
    this.router.navigate(['/admin/sales-agent'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        sortBy: this.sortBy,
        sortOrder: this.sortOrder,
        data: 'true',
      },
      queryParamsHandling: 'merge',
    });
  }
}
