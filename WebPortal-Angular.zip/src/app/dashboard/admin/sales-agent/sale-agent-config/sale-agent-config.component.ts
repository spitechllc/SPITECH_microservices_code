import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PaymentService } from 'src/app/dashboard/api-service/payment.srvice';
import { AuthService } from 'src/app/dashboard/auth/auth.service';
import { SubSink } from 'subsink';

@Component({
  selector: 'app-sale-agent-config',
  templateUrl: './sale-agent-config.component.html',
  styleUrls: ['./sale-agent-config.component.scss'],
})
export class SaleAgentConfigComponent implements OnInit {
  salesAgentConfigForm!: FormGroup;
  saleAgentId: any = null;
  subs = new SubSink();
  constructor(
    private fb: FormBuilder,
    private toster: ToastrService,
    private paymentService: PaymentService,
    private activatedRoute: ActivatedRoute,
    private _location: Location,
    private auth: AuthService
  ) {}
  get f() {
    return this.salesAgentConfigForm.controls;
  }
  submitted: boolean = false;
  claimIdArray: any;
  ngOnInit(): void {
    this.getSaleAgentId();
    this.createSalesAgentForm();
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  createSalesAgentForm() {
    this.salesAgentConfigForm = this.fb.group({
      saleAgentId: new FormControl(this.saleAgentId),
      accountName: new FormControl(''),
      bank: new FormControl(''),
      accountNo: new FormControl(''),
      routingNo: new FormControl(''),
      isChecking: true,
      isActive: true,
    });
  }
  getSaleAgentId() {
    this.subs.add(
      this.activatedRoute.paramMap.subscribe((params) => {
        this.saleAgentId = params.get('saleAgentId');
        // console.log(this.saleAgentId);
        if (this.saleAgentId) {
          this.getSaleConfig(this.saleAgentId);
        }
      })
    );
  }
  getSaleConfig(id: any) {
    this.paymentService.getSaleAgentConfig(id).subscribe((data: any) => {
      // console.log(data);
      this.salesAgentConfigForm.patchValue({
        saleAgentId: this.saleAgentId,
        accountName: data.data.accountName,
        bank: data.data.bank,
        accountNo: data.data.accountNo,
        routingNo: data.data.routingNo,
        isChecking: data.data.isChecking,
        isActive: data.data.isActive,
      });
    });
  }

  createUpdateSaleAgentConfig() {
    this.paymentService
      .createSalesAgentConfig(this.salesAgentConfigForm.value)
      .subscribe((data: any) => {
        console.log(data);
        if (data.success == false) {
          this.toster.error(data.message);
        }
        if (data.message == null) {
          this.toster.success('Sales Agent update successfully');
        }

        this.getSaleConfig(this.saleAgentId);
      });
  }
  cancelBUtton() {
    this._location.back();
  }
}
