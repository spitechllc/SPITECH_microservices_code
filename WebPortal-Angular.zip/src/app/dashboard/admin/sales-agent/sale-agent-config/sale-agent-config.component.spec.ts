import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaleAgentConfigComponent } from './sale-agent-config.component';

describe('SaleAgentConfigComponent', () => {
  let component: SaleAgentConfigComponent;
  let fixture: ComponentFixture<SaleAgentConfigComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SaleAgentConfigComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SaleAgentConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
