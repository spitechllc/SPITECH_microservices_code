import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { file } from '@rxweb/reactive-form-validators';
import { ToastrService } from 'ngx-toastr';
import { IdentityService } from '../../api-service/identityService';
import { StoreService } from '../../api-service/storeService';

@Component({
  selector: 'app-process-excel-data',
  templateUrl: './process-excel-data.component.html',
  styleUrls: ['./process-excel-data.component.scss'],
})
export class ProcessExcelDataComponent implements OnInit {
  processExcelForm!: FormGroup;
  submitted: boolean = false;
  constructor(
    private formBuilder: FormBuilder,
    private storeSevice: StoreService,
    private toster: ToastrService,
    private identity: IdentityService,
    private router: Router,
    private _location: Location
  ) {}
  get f() {
    return this.processExcelForm.controls;
  }
  ngOnInit(): void {
    this.createForm();
    this.getTenant();
  }
  clientData: any;
  displayedColumns = [
    'checkBox',
    'storeName',
    'siteId',
    'posName',
    'region',
    'company',
    'state',
    'city',
    'zipCode',
    'number',
    'email',
    'amenity',
    'accountName',
    'bank',
    'accountNo',
    'routingNo',
  ];
  dataSource = new MatTableDataSource<PromotionTable>([]);
  getTenant() {
    this.identity.getTantetId().subscribe((data: any) => {
      this.clientData = data.data;
    });
  }
  createForm() {
    this.processExcelForm = this.formBuilder.group({
      file: new FormControl(),
      ClientId: new FormControl(),
    });
  }

  uploadFile(event: any) {
    let files = event.target.files[0];
    // console.log(files);
    this.processExcelForm.patchValue({
      file: files,
    });
    this.processExcelForm.get('file')?.updateValueAndValidity();
    // if (
    //   files.type == 'application/vnd.openxmlformats-officedocument.spreadsheetm'
    // ) {
    //   // this.uploadFiles();
    // } else {
    //   this.toster.error('Please Select Excel File');
    // }
  }
  excelData: any[] = [];

  uploadFiles() {
    var formData: any = new FormData();
    formData.append('ExcelFile', this.processExcelForm.get('file')?.value);
    formData.append('TenantId', this.processExcelForm.get('ClientId')?.value);
    this.storeSevice.processExcel(formData).subscribe((data: any) => {
      this.excelData = data.data;
      // console.log(this.excelData);
      this.dataSource = new MatTableDataSource(this.excelData);
      this.toster.success('Excel  successfully uploded');
    });

    // this.stringServce.userUpload(formData).subscribe((data: any) => {
    //   if (data.statusCode == 1) {
    //     this.toster.success('Profile image successfully uploded');
    //     this.sharedService.updateProfileChanged(true);
    //     this.getUserDetails();
    //   }
    // });
  }
  submitExcelData() {
    this.storeSevice
      .submitExcelData({ storesData: this.excelData })
      .subscribe((data: any) => {
        this.toster.success('Excel  successfully submit');
      });
  }

  onCompany(element: any, event: KeyboardEvent) {
    const inputElement = event.target as HTMLInputElement;
    if (event.key == 'Enter') {
      element.company = inputElement.value;
      const index = this.excelData.findIndex(
        (item) => item.storeName == element.storeName
      );
      if (index > -1) {
        this.excelData[index].company = element.company;
      }
    }
  }
  onSiteId(element: any, event: KeyboardEvent) {
    const inputElement = event.target as HTMLInputElement;
    if (event.key == 'Enter') {
      element.siteId = inputElement.value;
      const index = this.excelData.findIndex(
        (item) => item.storeName == element.storeName
      );
      if (index > -1) {
        this.excelData[index].siteId = element.siteId;
      }
    }
  }
  onNumber(element: any, event: KeyboardEvent) {
    const inputElement = event.target as HTMLInputElement;
    if (event.key == 'Enter') {
      element.number = inputElement.value;
      const index = this.excelData.findIndex(
        (item) => item.storeName == element.storeName
      );
      if (index > -1) {
        this.excelData[index].number = element.number;
      }
    }
  }
  onEmail(element: any, event: KeyboardEvent) {
    const inputElement = event.target as HTMLInputElement;
    console.log(inputElement.value);
    if (event.key == 'Enter') {
      element.email = inputElement.value;
      const index = this.excelData.findIndex(
        (item) => item.storeName == element.storeName
      );
      if (index > -1) {
        this.excelData[index].email = element.email;
      }
    }
  }
  onAccountName(element: any, event: KeyboardEvent) {
    const inputElement = event.target as HTMLInputElement;
    if (event.key == 'Enter') {
      element.accountName = inputElement.value;
      const index = this.excelData.findIndex(
        (item) => item.storeName == element.storeName
      );
      if (index > -1) {
        this.excelData[index].accountName = element.accountName;
      }
    }
  }
  onBank(element: any, event: KeyboardEvent) {
    const inputElement = event.target as HTMLInputElement;
    if (event.key == 'Enter') {
      element.bank = inputElement.value;
      const index = this.excelData.findIndex(
        (item) => item.storeName == element.storeName
      );
      if (index > -1) {
        this.excelData[index].bank = element.bank;
      }
    }
  }
  isChecked: boolean = true;
  onClickCheckBox(element: any, event: any) {
    console.log(event.checked);
    const index = this.excelData.findIndex(
      (item) => item.storeName == element.storeName
    );

    if (event.checked) {
      if (index == -1) {
        this.excelData.push(element);
      }
    } else {
      if (index > -1) {
        this.excelData.splice(index, 1);
      }
    }
    // console.log(this.excelData);
  }
}
export interface PromotionTable {
  promotionId: Number;
  startDate: string;
  endDate: string;
  criteria: string;
  eventName: string;
}
