import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProcessExcelDataComponent } from './process-excel-data.component';

describe('ProcessExcelDataComponent', () => {
  let component: ProcessExcelDataComponent;
  let fixture: ComponentFixture<ProcessExcelDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProcessExcelDataComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProcessExcelDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
