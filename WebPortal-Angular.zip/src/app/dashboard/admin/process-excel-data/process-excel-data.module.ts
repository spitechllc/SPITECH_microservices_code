import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from 'src/app/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { ProcessExcelDataComponent } from './process-excel-data.component';

export const router: Routes = [
  {
    path: '',
    component: ProcessExcelDataComponent,
  },
];

@NgModule({
  declarations: [ProcessExcelDataComponent],
  imports: [
    CommonModule,
    CommonModule,
    SharedModule,
    MatCardModule,
    FormsModule,
    MatSnackBarModule,
    ReactiveFormsModule,
    RouterModule.forChild(router),
  ],
})
export class ProcessExcelDataModule {}
