import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReselerExcelExportComponent } from './reseler-excel-export.component';

describe('ReselerExcelExportComponent', () => {
  let component: ReselerExcelExportComponent;
  let fixture: ComponentFixture<ReselerExcelExportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReselerExcelExportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReselerExcelExportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
