import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResselerComponent } from './resseler.component';

describe('ResselerComponent', () => {
  let component: ResselerComponent;
  let fixture: ComponentFixture<ResselerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResselerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResselerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
