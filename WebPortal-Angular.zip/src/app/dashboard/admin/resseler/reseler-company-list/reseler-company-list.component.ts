import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatOptionSelectionChange } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSelectChange } from '@angular/material/select';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { debounce, indexOf } from 'lodash';
import { ToastrService } from 'ngx-toastr';
import { StoreService } from 'src/app/dashboard/api-service/storeService';
import { AuthService } from 'src/app/dashboard/auth/auth.service';
import { SubSink } from 'subsink';
import { StoreTable } from '../../store/store-tab/store-tab.component';

@Component({
  selector: 'app-reseler-company-list',
  templateUrl: './reseler-company-list.component.html',
  styleUrls: ['./reseler-company-list.component.scss'],
})
export class ReselerCompanyListComponent implements OnInit {
  displayedColumns = ['id', 'name'];

  dataSource = new MatTableDataSource<StoreTable>([]);

  subs = new SubSink();
  resellerId: any = null;
  suggestEventValue: any;
  comapanDetails: any;
  lengthsite: any;
  dataNotFond: string = 'Data not found';
  length: any = null;
  salesAgentDetails: any = [];
  claimIdArray: any;
  get companyIds() {
    return this.resellerCompanyForm.get('companyIds') as FormArray;
  }
  constructor(
    private activatedRoute: ActivatedRoute,
    private storeService: StoreService,
    private _location: Location,
    public dialog: MatDialog,
    private fb: FormBuilder,
    private toster: ToastrService,
    private auth: AuthService
  ) {}
  resellerCompanyForm!: FormGroup;
  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.getResellerId();
    this.createForm();
    this.getALLCompany();
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  createForm() {
    this.resellerCompanyForm = this.fb.group({
      companyIds: [],
      resellerId: new FormControl(this.resellerId),
    });
  }

  getResellerId() {
    this.subs.add(
      this.activatedRoute.paramMap.subscribe((params) => {
        this.resellerId = params.get('resellerId');
        if (this.resellerId) {
          this.getResellerDetails(this.resellerId);
        }
      })
    );
  }

  getResellerDetails(id: any) {
    this.storeService.getResellerById(id).subscribe((data: any) => {
      this.salesAgentDetails = data.companies;
      // console.log(this.resellerCompanyForm.get('companyIds'));
      this.resellerCompanyForm.patchValue({
        companyIds: data.companyIds,
      });
      if (data.companies == null) {
        this.length = 0;
      }
      if (data.companies) {
        this.length = 1;
        this.companiesId = data.companyIds;
      }
      this.dataSource = new MatTableDataSource(data.companies);
    });
  }
  cancelBUtton() {
    this._location.back();
  }

  onChange(event: any) {
    this.suggestEventValue = event;
  }

  serachByCompanyName = debounce((event: any) => {
    this.companyName = event.target.value;
    this.getALLCompany();
  }, 1000);

  companyName: string = '';
  StoreIds: number = 0;

  getALLCompany() {
    this.storeService
      .getAllCompanyAutoComplete(this.companyName)
      .subscribe((data: any) => {
        this.comapanDetails = data.data;
      });
  }

  CompanyNames: string = '';
  selectedValue: any = [];
  onChaneCompanyId(stoteId: any) {
    this.comapanDetails.filter((element: any) => {
      if (element.storeId == stoteId) {
        this.CompanyNames = element.companyName;
        return element.companyName;
      }
    });
  }
  companiesId: any = [];
  onChangeid(event: any) {
    if (event._selected == true) {
      this.companiesId.push(event.value);
    }
    if (event._selected == false) {
      const index: number = this.companiesId.indexOf(event.value);
      if (index !== -1) {
        this.companiesId.splice(index, 1);
      }
    }
  }
  updateResellerCompany() {
    this.storeService
      .updateResellersCompany({
        companyIds: this.companiesId,
        resellerId: this.resellerId,
      })
      .subscribe(
        (data) => {
          this.toster.success('Company Update in this Reseller');
          this.getResellerDetails(this.resellerId);
        },
        (err) => {
          if (err.error.errors.Company) {
            err.error.errors.Company.forEach((err: any) => {
              this.toster.error(err);
            });
          }
        }
      );
  }
}
