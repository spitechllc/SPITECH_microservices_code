import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReselerCompanyListComponent } from './reseler-company-list.component';

describe('ReselerCompanyListComponent', () => {
  let component: ReselerCompanyListComponent;
  let fixture: ComponentFixture<ReselerCompanyListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReselerCompanyListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReselerCompanyListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
