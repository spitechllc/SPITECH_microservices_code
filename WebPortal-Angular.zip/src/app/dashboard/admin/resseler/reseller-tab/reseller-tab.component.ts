import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/dashboard/auth/auth.service';

@Component({
  selector: 'app-reseller-tab',
  templateUrl: './reseller-tab.component.html',
  styleUrls: ['./reseller-tab.component.scss'],
})
export class ResellerTabComponent implements OnInit {
  constructor(private auth: AuthService) {}
  claimIdArray: any;
  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
}
