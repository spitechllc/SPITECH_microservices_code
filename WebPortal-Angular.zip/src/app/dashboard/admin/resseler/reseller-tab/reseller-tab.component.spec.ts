import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResellerTabComponent } from './reseller-tab.component';

describe('ResellerTabComponent', () => {
  let component: ResellerTabComponent;
  let fixture: ComponentFixture<ResellerTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResellerTabComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResellerTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
