import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PaymentService } from 'src/app/dashboard/api-service/payment.srvice';
import { TransactionService } from 'src/app/dashboard/api-service/trasation.service';
import { AuthService } from 'src/app/dashboard/auth/auth.service';
import { Location } from '@angular/common';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { SubSink } from 'subsink';
import { MatTableDataSource } from '@angular/material/table';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { MatSort } from '@angular/material/sort';
import { DefaultPopupComponent } from '../default-popup/default-popup.component';
import { MatDialog } from '@angular/material/dialog';
@Component({
  selector: 'app-reseller-biiling-fee',
  templateUrl: './reseller-biiling-fee.component.html',
  styleUrls: ['./reseller-biiling-fee.component.scss'],
})
export class ResellerBiilingFeeComponent implements OnInit {
  @ViewChild(MatSort) sort: MatSort;
  displayedColumns = [
    'resellerFeeId',
    'minStoreRange',
    'maxStoreRange',
    'achTransactionFee',
    'cardTransactionFee',
    'cashRewardTransactionFee',
    'achProcessingFee',
    'monthlySaasFee',
    'coreProcessingName',
    // 'isActive',
    'action',
  ];
  dataSource = new MatTableDataSource<TableDetails>([]);

  myModel = true;
  checked = true;
  storeId: any;
  storeDetails: any;
  paymentMethodDetails: any;
  claimIdArray: any;
  err: string = '';
  ResellerBillingForm!: FormGroup;
  paymentConfigurationDetails: any;
  submitted: boolean = false;
  paymentMethod: any;
  ResellerData: any = [];
  resellerFeeId: any;
  isActive: boolean = true;
  resellerId: number = 0;
  subs = new SubSink();
  constructor(
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private toster: ToastrService,
    private auth: AuthService,
    private dialog: MatDialog,
    private _location: Location,
    private paymentService: PaymentService,
    private transactionService: TransactionService
  ) {}
  get f() {
    return this.ResellerBillingForm.controls;
  }
  ngOnInit(): void {
    this.getResllerId();
    this.getResellerBilling();
    this.createForm();
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.getPaymentMethod();
  }
  getResllerId() {
    this.subs.add(
      this.activatedRoute.paramMap.subscribe((params: any) => {
        this.resellerId = params.get('resellerId');
        // console.log(this.resellerId);
      })
    );
  }
  // getDefaultBillingFee() {
  //   this.transactionService.getDefaultBillingFee().subscribe((data: any) => {
  //     this.dataSource = new MatTableDataSource(data.data);
  //   });
  // }

  onClickisActive(event: MatSlideToggleChange) {
    // console.log(event);
    this.isActive = event.checked;
  }

  createForm() {
    this.ResellerBillingForm = this.formBuilder.group({
      resellerId: new FormControl(this.resellerId),
      minStoreRange: new FormControl('', Validators.required),
      maxStoreRange: new FormControl('', Validators.required),
      achTransactionFee: new FormControl('', Validators.required),
      cardTransactionFee: new FormControl('', Validators.required),
      cashRewardTransactionFee: new FormControl('', Validators.required),
      achProcessingFee: new FormControl('', Validators.required),
      monthlySaasFee: new FormControl('', Validators.required),
      coreProcessingName: new FormControl(''),
      isDefault: false,
    });
  }
  getPaymentMethod() {
    this.paymentService.getPaymentMethod().subscribe((data: any) => {
      this.paymentMethod = data.data;
      // console.log(this.paymentMethod);
    });
  }

  getResellerBilling() {
    this.transactionService
      .getBillingFeeByResellerId(this.resellerId)
      .subscribe((data: any) => {
        this.ResellerData = data.data;
        this.dataSource = new MatTableDataSource(data.data);
        this.dataSource.sort = this.sort;
      });
  }

  onClickEdit(id: any) {
    console.log(id);
    this.resellerFeeId = id;
    this.transactionService
      .getResellerFeeByResellerFeeId(id)
      .subscribe((data: any) => {
        this.ResellerBillingForm.patchValue({
          resellerId: data.data.resellerId,
          minStoreRange: data.data.minStoreRange,
          maxStoreRange: data.data.maxStoreRange,
          achTransactionFee: data.data.achTransactionFee,
          cardTransactionFee: data.data.cardTransactionFee,
          cashRewardTransactionFee: data.data.cashRewardTransactionFee,
          achProcessingFee: data.data.achProcessingFee,
          monthlySaasFee: data.data.monthlySaasFee,
          coreProcessingName: data.data.coreProcessingName,
          isDefault: false,
        });
      });
  }

  formReset() {
    this.ResellerBillingForm.reset();
    this.resellerFeeId = 0;
    this.createForm();
  }
  defaultPopUp() {
    const dialogRef = this.dialog.open(DefaultPopupComponent, {
      width: '430px',
      panelClass: 'popup',
      data: this.resellerId,
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.getResellerBilling();
    });
  }
  submit() {
    if (!this.resellerFeeId) {
      this.saveStoreBilling();
    }
    if (this.resellerFeeId) {
      this.updateStoreBilling();
    }
  }
  mintransationerr: string = '';
  saveStoreBilling() {
    this.submitted = true;
    if (this.ResellerBillingForm.invalid) return;
    this.transactionService
      .createResllerBillingFee(this.ResellerBillingForm.value)
      .subscribe(
        (data: any) => {
          if (data.success == true) {
            this.toster.success('Store billing save successfully');
            this.getResellerBilling();
          }
          if (data.success == false) {
            this.toster.warning('Store billing not save status:false');
          }
        },
        (err) => {
          // console.log(err);
          if (err.error.errors.minStoreRange) {
            err.error.errors.minStoreRange.forEach((err: any) => {
              this.mintransationerr = err;
              // console.log(err);
              this.toster.error(err);
            });
          }
          if (err.error.errors.TransactionRange) {
            err.error.errors.TransactionRange.forEach((err: any) => {
              // console.log(err);
              this.toster.error(err);
            });
          }
        }
      );
  }
  updateStoreBilling() {
    this.transactionService
      .UpdateResllerBillingFee({
        ...this.ResellerBillingForm.value,
        resellerFeeId: this.resellerFeeId,
        isActive: this.isActive,
      })
      .subscribe(
        (data) => {
          this.toster.success('Update store billing Successfully');
          this.getResellerBilling();
        },
        (err) => {
          if (err.error.errors.minStoreRange) {
            err.error.errors.minStoreRange.forEach((err: any) => {
              this.mintransationerr = err;
              // console.log(this.mintransationerr);
              this.toster.error(err);
            });
          }
        }
      );
  }
  onClickBack() {
    this._location.back();
  }
}

export interface TableDetails {
  monthlySaasFee: string;
  transactionFee: string;
  Subscription: string;
  transactionPercentageFee: string;
  effectiveDate: string;
  resellerFeeId: string;
  storeName: string;
  action: string;
}
