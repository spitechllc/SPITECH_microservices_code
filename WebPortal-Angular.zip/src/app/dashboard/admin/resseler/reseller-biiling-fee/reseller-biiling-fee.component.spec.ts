import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResellerBiilingFeeComponent } from './reseller-biiling-fee.component';

describe('ResellerBiilingFeeComponent', () => {
  let component: ResellerBiilingFeeComponent;
  let fixture: ComponentFixture<ResellerBiilingFeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResellerBiilingFeeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResellerBiilingFeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
