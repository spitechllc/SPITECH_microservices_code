import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ResselerComponent } from './resseler.component';
import { AdminGuardGuard } from '../../auth/admin-guard.guard';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from 'src/app/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { NgxMaskModule, IConfig } from 'ngx-mask';
export const options: Partial<null | IConfig> | (() => Partial<IConfig>) = null;
import { ResellerTabComponent } from './reseller-tab/reseller-tab.component';
import { AddResellersComponent } from './add-resellers/add-resellers.component';
import { ReselerCompanyListComponent } from './reseler-company-list/reseler-company-list.component';
import { ResellerConfigComponent } from './reseller-config/reseller-config.component';
import { ResellerBiilingFeeComponent } from './reseller-biiling-fee/reseller-biiling-fee.component';
import { DefaultPopupComponent } from './default-popup/default-popup.component';
import { MatRadioModule } from '@angular/material/radio';
import { ReselerExcelExportComponent } from './reseler-excel-export/reseler-excel-export.component';
export const router: Routes = [
  {
    path: '',
    component: ResselerComponent,
    canActivate: [AdminGuardGuard],
  },
  {
    path: 'add-edit-reseller',
    component: AddResellersComponent,
  },
  { path: 'edit-reseller/:resellerId', component: ResellerTabComponent },
];
@NgModule({
  declarations: [
    ResellerTabComponent,
    ResselerComponent,
    AddResellersComponent,
    ReselerCompanyListComponent,
    ResellerConfigComponent,
    ResellerBiilingFeeComponent,

    DefaultPopupComponent,
      ReselerExcelExportComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    MatRadioModule,
    ReactiveFormsModule,
    NgxMaskModule.forRoot({
      showMaskTyped: true,
      // clearIfNotMatch : true
    }),
    MatAutocompleteModule,
    RouterModule.forChild(router),
  ],
})
export class ResselerModule {}
