import { Component, OnInit } from '@angular/core';

import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { debounce } from 'lodash';
import { NgxSpinner, NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ExcelService } from '../../api-service/excel-servive/excel.service';
import { StoreService } from '../../api-service/storeService';
import { AuthService } from '../../auth/auth.service';
import { ReselerExcelExportComponent } from './reseler-excel-export/reseler-excel-export.component';

@Component({
  selector: 'app-resseler',
  templateUrl: './resseler.component.html',
  styleUrls: ['./resseler.component.scss'],
})
export class ResselerComponent implements OnInit {
  displayedColumns = [
    'resellerId',
    'firstName',
    'lastName',
    'companyName',
    'PhoneNumber',
    'EmailAddress',
    'isActive',
    'action',
  ];
  dataSource = new MatTableDataSource<Reseller>([]);

  salesAgentData: any = [];
  searchEvent: any;
  name: string = '';
  mobile: string = '';
  email: string = '';
  companyName: string = '';
  pageIndex: number = 1;
  pageSize: number = 50;

  sortBy = 'resellerId';
  sortOrder: string = 'desc';
  total: number = 0;
  paramsData: any;
  allResellersData: any = [];
  claimIdArray: any;
  constructor(
    private fb: FormBuilder,
    private storeService: StoreService,
    private toster: ToastrService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private activateRoute: ActivatedRoute,
    private excelService: ExcelService,
    private auth: AuthService,
    public dialog: MatDialog
  ) {}

  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.activateRoute.queryParamMap.subscribe((data: any) => {
      this.paramsData = data.params;
    });
    if (this.paramsData.data == 'true') {
      this.pageIndex = this.paramsData.pageIndex;
      this.pageSize = this.paramsData.pageSize;

      this.searchEvent = this.paramsData.searchEvent
        ? this.paramsData.searchEvent
        : 0;
      this.email = this.paramsData.email ? this.paramsData.email : '';
      this.name = this.paramsData.name ? this.paramsData.name : '';
      this.companyName = this.paramsData.companyName
        ? this.paramsData.companyName
        : '';
      this.mobile = this.paramsData.mobile ? this.paramsData.mobile : '';
      this.getAllResellers();
    } else {
      this.getAllResellers();
    }
  }

  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  phones: any;
  number: any;
  emails: any;
  addressline1: any;
  addressline2: any;
  city: any;
  state: any;
  firstLastName: any;
  exportAsExcel() {
    var pageSize = 0;
    var pageIndex = 0;
    this.storeService
      .getAllReseller(
        this.name,
        this.mobile,
        this.email,
        this.companyName,
        pageIndex,
        pageSize,
        this.sortBy,
        this.sortOrder
      )
      .subscribe((data: any) => {
        this.allResellersData = data.data;
        const dialogRef = this.dialog.open(ReselerExcelExportComponent, {
          width: '450px',
          panelClass: 'popup',
          data: this.allResellersData,
        });
        // if (this.allResellersData.length > 0) {
        //   this.excelService.exportAsExcelFile(
        //     this.allResellersData.map((s: any) => {
        //       return {
        //         'Reseller Id': s.resellerId,
        //         'Company Name': s.companyName,
        //         'First Name': s.firstName,
        //         'Last Name': s.lastName,
        //         'Mobile Number': s.phones.map((p: any) => {
        //           // console.log(p.number);
        //           this.number = p.number;
        //           return { MobileNumber: p.number };
        //         })
        //           ? this.number
        //           : '',
        //         Email: s.emails.map((e: any) => {
        //           this.emails = e.email;
        //           return { email: e.email };
        //         })
        //           ? this.emails
        //           : '',
        //         AddressLine1: s.addresses.map((a: any) => {
        //           this.addressline1 = a.addressLine1;
        //           this.city = a.city;
        //           this.state = a.state;
        //           this.addressline2 = a.addressLine2;
        //           return {};
        //         })
        //           ? this.addressline1
        //           : '',

        //         AddressLine2: this.addressline2,
        //         City: this.city,
        //         State: this.state,
        //       };
        //     }),
        //     'sales-agent'
        //   );
        // } else {
        //   this.toster.error('Data not found');
        // }
      });
  }
  onHeaderSortChange(event: any) {
    this.sortBy = event.active;
    if (event.direction == '') {
      this.sortOrder = 'asc';
    } else {
      this.sortOrder = event.direction;
    }

    this.getAllResellers();
  }
  onChange(event: any) {
    this.searchEvent = event;
    this.sortBy = '';
    this.sortOrder = '';
    if (event == 0) {
      this.name = '';
      this.email = '';
      this.companyName = '';
      this.mobile = '';
      this.searchEvent = 0;
      this.router.navigate(['/admin/reseller'], {
        queryParams: {
          pageIndex: this.pageIndex,
          pageSize: this.pageSize,
          searchEvent: (this.searchEvent = 0),
          data: 'true',
          name: (this.name = ''),
          email: (this.email = ''),
          companyName: (this.companyName = ''),
          mobile: (this.mobile = ''),
        },
        queryParamsHandling: 'merge',
      });
      this.getAllResellers();
    }
  }
  filterByName = debounce(($event: any) => {
    this.name = $event.target.value;
    this.pageIndex = 1;
    this.router.navigate(['/admin/reseller'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        searchEvent: this.searchEvent,
        data: 'true',
        name: this.name,
        email: (this.email = ''),
        companyName: (this.companyName = ''),
        mobile: (this.mobile = ''),
      },
      queryParamsHandling: 'merge',
    });

    this.getAllResellers();
  }, 1000);

  filterByMobile = debounce(($event: any) => {
    this.mobile = $event.target.value;
    this.pageIndex = 1;
    this.router.navigate(['/admin/reseller'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        searchEvent: this.searchEvent,
        data: 'true',
        mobile: this.mobile,
        name: (this.name = ''),
        email: (this.email = ''),
        companyName: (this.companyName = ''),
      },
      queryParamsHandling: 'merge',
    });

    this.getAllResellers();
  }, 1000);

  filterByEmail = debounce(($event: any) => {
    this.email = $event.target.value;
    this.pageIndex = 1;
    this.total = 0;
    this.router.navigate(['/admin/reseller'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        searchEvent: this.searchEvent,
        data: 'true',
        email: this.email,
        mobile: (this.mobile = ''),
        name: (this.name = ''),
        companyName: (this.companyName = ''),
      },
      queryParamsHandling: 'merge',
    });
    this.getAllResellers();
  }, 1000);

  filterByCompanyName = debounce(($event: any) => {
    this.companyName = $event.target.value;
    this.pageIndex = 1;
    this.router.navigate(['/admin/reseller'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        data: 'true',
        searchEvent: this.searchEvent,
        companyName: this.companyName,
        mobile: (this.mobile = ''),
        name: (this.name = ''),
        email: (this.email = ''),
      },
      queryParamsHandling: 'merge',
    });
    this.getAllResellers();
  }, 1000);

  pageChanged(event: any) {
    this.pageIndex = event.pageIndex + 1;
    this.pageSize = event.pageSize;
    this.queryParams();
    this.getAllResellers();
  }
  queryParams() {
    this.router.navigate(['/admin/reseller'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        sortBy: this.sortBy,
        sortOrder: this.sortOrder,
        data: 'true',
      },
      queryParamsHandling: 'merge',
    });
  }
  getAllResellers() {
    this.storeService
      .getAllReseller(
        this.name,
        this.mobile,
        this.email,
        this.companyName,
        this.pageIndex,
        this.pageSize,
        this.sortBy,
        this.sortOrder
      )
      .subscribe((data: any) => {
        this.dataSource = new MatTableDataSource(data.data);
        this.total = data.totalCount;
      });
  }
}
export interface Reseller {
  resellerId: number;
  resellerName: string;
}
