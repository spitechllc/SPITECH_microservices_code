import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PaymentService } from 'src/app/dashboard/api-service/payment.srvice';
import { SubSink } from 'subsink';

@Component({
  selector: 'app-reseller-config',
  templateUrl: './reseller-config.component.html',
  styleUrls: ['./reseller-config.component.scss'],
})
export class ResellerConfigComponent implements OnInit {
  resellerConfigForm!: FormGroup;
  resellerId: any = null;
  subs = new SubSink();
  constructor(
    private fb: FormBuilder,
    private toster: ToastrService,
    private paymentService: PaymentService,
    private activatedRoute: ActivatedRoute,
    private _location: Location
  ) {}
  get f() {
    return this.resellerConfigForm.controls;
  }
  submitted: boolean = false;
  ngOnInit(): void {
    this.getResllerId();
    this.createSalesAgentForm();
  }

  createSalesAgentForm() {
    this.resellerConfigForm = this.fb.group({
      resellerId: new FormControl(this.resellerId),
      accountName: new FormControl('', Validators.required),
      bank: new FormControl('', Validators.required),
      accountNo: new FormControl('', Validators.required),
      routingNo: new FormControl('', Validators.required),
      isChecking: true,
      isActive: true,
    });
  }
  getResllerId() {
    this.subs.add(
      this.activatedRoute.paramMap.subscribe((params: any) => {
        this.resellerId = params.get('resellerId');
        // console.log(this.resellerId);
        if (this.resellerId) {
          this.getResllerconfig(this.resellerId);
        }
      })
    );
  }
  getResllerconfig(id: any) {
    this.paymentService.getResellerConfigById(id).subscribe((data: any) => {
      this.resellerConfigForm.patchValue({
        resellerId: this.resellerId,
        accountName: data.data.accountName,
        bank: data.data.bank,
        accountNo: data.data.accountNo,
        routingNo: data.data.routingNo,
        isChecking: data.data.isChecking,
        isActive: data.data.isActive,
      });
    });
  }

  UpdateResellerConfig() {
    this.paymentService
      .createUpdateResellerConfig(this.resellerConfigForm.value)
      .subscribe((data: any) => {
        if (data.success == false) {
          this.toster.error(data.message);
        }
        if (data.message == null) {
          this.toster.success('Sales Agent update successfully');
        }

        this.getResllerconfig(this.resellerId);
      });
  }
  cancelBUtton() {
    this._location.back();
  }
}
