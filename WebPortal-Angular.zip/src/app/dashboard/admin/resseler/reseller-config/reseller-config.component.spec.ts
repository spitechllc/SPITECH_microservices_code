import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResellerConfigComponent } from './reseller-config.component';

describe('ResellerConfigComponent', () => {
  let component: ResellerConfigComponent;
  let fixture: ComponentFixture<ResellerConfigComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResellerConfigComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResellerConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
