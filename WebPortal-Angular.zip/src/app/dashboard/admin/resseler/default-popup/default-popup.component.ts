import { TransactionService } from 'src/app/dashboard/api-service/trasation.service';
import { Component, Inject, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
export interface UsersData {
  roleId: number;
  roleName: string;
}
@Component({
  selector: 'app-default-popup',
  templateUrl: './default-popup.component.html',
  styleUrls: ['./default-popup.component.scss'],
})
export class DefaultPopupComponent implements OnInit {
  local_data: any;
  roleId: any;
  submitted: boolean = false;
  get f() {
    return this.defaultBillingFeeForm.controls;
  }
  constructor(
    private transactionService: TransactionService,
    private formBuilder: FormBuilder,
    private toster: ToastrService,
    private activatedRoute: ActivatedRoute,
    private spinner: NgxSpinnerService,
    public dialogRef: MatDialogRef<DefaultPopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: UsersData,
    private router: Router
  ) {
    this.resellerId = { ...data };
    console.log(this.resellerId);
    this.roleId = this.resellerId.roleId;
    // console.log(this.roleId)
    if (this.resellerId) {
      this.defaultBillingFeeForm = this.formBuilder.group({
        resellerId: new FormControl(this.resellerId[0]),
        coreProcessingName: new FormControl('', Validators.required),
      });
    }
  }
  defaultBillingFeeForm!: FormGroup;
  resellerId: any;
  dataLoaded: boolean = false;
  RoleId: any;
  ngOnInit(): void {
    this.dataLoaded = false;
  }

  updateCopyDefaultBillingFee() {
    this.submitted = true;
    if (this.defaultBillingFeeForm.invalid) return;
    this.transactionService
      .copyDefaultResellerBillingFee(this.defaultBillingFeeForm.value)
      .subscribe(
        (data: any) => {
          this.toster.success('Update default billing fee successfully');
          this.dialogRef.close([]);
        },
        (err) => {
          // console.log(err);
          if (err.error.errors.DefaultFees) {
            err.error.errors.DefaultFees.forEach((err: any) => {
              this.toster.error(err);
            });
          }
        }
      );
  }
}
