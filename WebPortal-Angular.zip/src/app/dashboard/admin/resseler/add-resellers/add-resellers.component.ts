import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { RxwebValidators } from '@rxweb/reactive-form-validators';
import { debounce } from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { StoreService } from 'src/app/dashboard/api-service/storeService';
import { SubSink } from 'subsink';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';

@Component({
  selector: 'app-add-resellers',
  templateUrl: './add-resellers.component.html',
  styleUrls: ['./add-resellers.component.scss'],
})
export class AddResellersComponent implements OnInit {
  resellerForm!: FormGroup;
  get f() {
    return this.resellerForm.controls;
  }
  get phones() {
    return this.resellerForm.get('phones') as FormArray;
  }
  get addresses() {
    return this.resellerForm.get('addresses') as FormArray;
  }

  get emails() {
    return this.resellerForm.get('emails') as FormArray;
  }

  subs = new SubSink();
  submitted: boolean = false;
  resellerData: any = [];
  addressCategory: any = [];
  phonecategory: any = [];
  emailcategory: any = [];
  countries: any = [];
  state: any = [];
  resellerId: any = null;
  constructor(
    private fb: FormBuilder,
    private storeService: StoreService,
    private toster: ToastrService,
    private spinner: NgxSpinnerService,
    private activatedRoute: ActivatedRoute,
    private _location: Location,
    private identityServer: IdentityService
  ) {}

  ngOnInit(): void {
    this.createResellerForm();
    this.getEmailCategoryLevel();
    this.phoneCategory();
    this.getAddressCategoryLevel();
    this.getCountry();
    this.getReseller();
    // this.getTenantId();
  }
  tenantData: any;
  getTenantId() {
    this.identityServer.getTantetId().subscribe((data: any) => {
      this.tenantData = data.data;
    });
  }
  countryCode: any;
  countryChange(value: any) {
    this.countryCode = value;
  }
  getReseller() {
    this.subs.add(
      this.activatedRoute.paramMap.subscribe((params) => {
        this.resellerId = params.get('resellerId');
        if (this.resellerId) {
          this.getsellerDetals(this.resellerId);
        }
      })
    );
  }
  getsellerDetals(id: any) {
    this.spinner.show();
    this.storeService.getResellerById(id).subscribe((data: any) => {
      this.setFormValue(data);
      this.spinner.hide();
    });
  }

  setFormValue(data: any) {
    this.resellerForm.patchValue({
      companyName: data.companyName,
      firstName: data.firstName,
      lastName: data.lastName,
      tenantId: data.tenantId,
    });

    data.addresses.forEach((element: any, index: any) => {
      if (index < data.addresses.length - 1) {
        this.addAnotherAddress();
      }
      if (element.countryId) {
        this.storeService
          .getStates(element.countryId)
          .subscribe((data: any) => {
            this.state = data.data;
          });
      } else {
        this.state = null;
      }
      this.addresses.controls[index].patchValue(element);
    });
    data.phones.forEach((element: any, index: any) => {
      if (index < data.phones.length - 1) {
        this.addAnotherPhone();
      }
      this.phones.controls[index].patchValue(element);
    });
    data.emails.forEach((element: any, index: any) => {
      if (index < data.emails.length - 1) {
        this.addAnotherEmail();
      }
      this.emails.controls[index].patchValue(element);
    });
  }

  getAddressCategoryLevel() {
    this.storeService.getCategoryLavelAddress(13).subscribe((data: any) => {
      this.addressCategory = data.data;
    });
  }
  phoneCategory() {
    this.storeService.getCategoryLevelPhone(14).subscribe((data: any) => {
      this.phonecategory = data.data;
    });
  }
  getEmailCategoryLevel() {
    this.storeService.getCategoryLevelEmail(15).subscribe((data: any) => {
      this.emailcategory = data.data;
    });
  }
  getCountry() {
    this.storeService.getCountry().subscribe((data: any) => {
      this.countries = data.data;
    });
  }

  onChangeCountry(countryId: number) {
    if (countryId) {
      this.storeService.getStates(countryId).subscribe((data: any) => {
        this.state = data.data;
      });
    } else {
      this.state = null;
    }
  }

  createResellerForm() {
    this.resellerForm = this.fb.group({
      companyName: new FormControl('', Validators.required),
      firstName: new FormControl('', Validators.required),
      lastName: new FormControl('', Validators.required),
      tenantId: new FormControl(0),
      addresses: this.fb.array([this.createAddressForm()]),
      phones: this.fb.array([this.createPhoneForm()]),
      emails: this.fb.array([this.createEmailForm()]),
    });
  }
  createEmailForm() {
    return this.fb.group({
      emailId: 0,
      categoryTypeLevelId: new FormControl(null, Validators.required),
      email: new FormControl('', Validators.required),
      isActive: true,
    });
  }
  addAnotherEmail() {
    this.emails.push(this.createEmailForm());
    if (this.emailcategory.length == this.emails.length) {
      var DATA = document.getElementById('addemail');

      DATA!.style.display = 'none';
    }
  }
  removeEmail(i: any) {
    // let i = this.emails.length - 1;
    this.emails.removeAt(i);
    var DATA = document.getElementById('addemail');
    DATA!.style.display = '';
  }
  isControlExist(categoryTypeLevelId: any): boolean {
    for (var i = 0; i < this.emails.controls.length; i++) {
      if (
        this.emails.controls[i].value.categoryTypeLevelId == categoryTypeLevelId
      ) {
        return true;
      }
    }

    return false;
  }

  onCopyClick(emailIndex: any) {
    const emailCopy = this.emails.controls[emailIndex].value.email;

    if (!this.emails.controls[emailIndex].valid) {
      this.toster.error('Please enter a valid email before copy');
      return;
    }
    for (var i = 0; i < this.emails.controls.length; i++) {
      if (this.emails.controls[i].value.categoryTypeLevelId <= 0) {
        this.toster.error('Please remove blank category before copy');
        return;
      }
    }

    this.emailcategory.forEach((emailCat: any, index: any) => {
      if (!this.isControlExist(emailCat.id)) {
        if (this.emails.controls.length < this.emailcategory.length) {
          this.addAnotherEmail();
          this.emails.controls[this.emails.controls.length - 1].patchValue({
            categoryTypeLevelId: emailCat.id,
            email: emailCopy,
          });
        }
      } else {
        for (var i = 0; i < this.emails.controls.length; i++) {
          this.emails.controls[i].patchValue({
            email: emailCopy,
          });
        }
      }
    });
  }

  createPhoneForm() {
    return this.fb.group({
      phoneId: 0,
      categoryTypeLevelId: new FormControl(null, Validators.required),
      countryCode: new FormControl('+1', Validators.required),
      areaCode: new FormControl(''),
      number: new FormControl(
        '',
        Validators.compose([
          Validators.required,
          Validators.pattern('[- +()0-9]+'),
          RxwebValidators.unique(),
        ])
      ),
      isActive: true,
    });
  }
  addAnotherPhone() {
    this.phones.push(this.createPhoneForm());
  }

  removePhone(i: any) {
    // let i = this.phones.length - 1;
    this.phones.removeAt(i);
  }
  createAddressForm() {
    return this.fb.group({
      addressId: 0,
      categoryTypeLevelId: new FormControl(null, Validators.required),
      addressLine1: new FormControl('', Validators.required),
      addressLine2: new FormControl(''),
      countryId: new FormControl(null, Validators.required),
      country: new FormControl(''),
      stateId: new FormControl(null, Validators.required),
      state: new FormControl(''),
      city: new FormControl(''),
      longitude: new FormControl(null),
      latitude: new FormControl(null),
      zipCode: new FormControl(
        '',
        Validators.compose([
          Validators.required,
          Validators.pattern('[- +()0-9]+'),
        ])
      ),
      isActive: true,
      companyId: null,
      storeId: null,
      userId: null,
      resellerId: null,
    });
  }
  addAnotherAddress() {
    this.addresses.push(this.createAddressForm());
  }
  removeAddress(i: any) {
    // let i = this.addresses.length - 1;
    this.addresses.removeAt(i);
  }
  submit() {
    // console.log(this.addStoreForm.value);
    this.submitted = true;
    if (this.resellerForm.invalid) return;
    if (this.resellerId) {
      this.updateReseller();
    }
    if (!this.resellerId) {
      this.createReseller();
    }
  }

  createReseller() {
    this.submitted = true;
    if (this.resellerForm.invalid) {
      return;
    }
    this.storeService
      .addResellers(this.resellerForm.value)
      .subscribe((data: any) => {
        this.toster.success('Reseller created successfully!');
        this.cancelBUtton();
      });
  }

  updateReseller() {
    this.submitted = true;
    if (this.resellerForm.invalid) {
      return;
    }
    this.storeService
      .updateResellers({
        ...this.resellerForm.value,
        resellerId: this.resellerId,
      })
      .subscribe((data: any) => {
        this.toster.success('Reseller updated successfully!');
        this.cancelBUtton();
      });
  }
  cancelBUtton() {
    this._location.back();
  }

  storeName: string = '';
  storeDetails: any;
  storeNames: any;

  serachByStoreName = debounce((event: any) => {
    if (event.target.value) {
      this.storeName = event.target.value;
      this.getALLStore();
    }
  }, 1000);
  getALLStore() {
    this.storeService
      .getStoreAutoCompleteByStoreName(this.storeName)
      .subscribe((data: any) => {
        this.storeDetails = data.data;
      });
  }

  onChaneStorId(storeId: any) {
    this.storeDetails.filter((element: any) => {
      if (element.storeId == storeId) {
        this.storeNames = element.storeName;
        return element.storeName;
      }
    });
  }
}
