import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddResellersComponent } from './add-resellers.component';

describe('AddResellersComponent', () => {
  let component: AddResellersComponent;
  let fixture: ComponentFixture<AddResellersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddResellersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddResellersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
