import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppNotificationMessageComponent } from './app-notification-message.component';

describe('AppNotificationMessageComponent', () => {
  let component: AppNotificationMessageComponent;
  let fixture: ComponentFixture<AppNotificationMessageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AppNotificationMessageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppNotificationMessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
