import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppNotificationMessageComponent } from './app-notification-message.component';
import { RouterModule, Routes } from '@angular/router';
import { AdminGuardGuard } from '../../auth/admin-guard.guard';
import { SharedModule } from 'src/app/shared.module';
import { ReactiveFormsModule } from '@angular/forms';

export const router: Routes = [
  {
    path: '',
    component: AppNotificationMessageComponent,
    canActivate: [AdminGuardGuard],
  },
];

@NgModule({
    declarations: [AppNotificationMessageComponent],
    imports: [
        CommonModule,
        SharedModule,
        ReactiveFormsModule,
        RouterModule.forChild(router),
    ]
})
export class AppNotificationMessageModule {}
