import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { NoficationService } from 'src/app/dashboard/api-service/nofication.service';

@Component({
  selector: 'app-edit-notification',
  templateUrl: './edit-notification.component.html',
  styleUrls: ['./edit-notification.component.scss'],
})
export class EditNotificationComponent implements OnInit {
  constructor(
    private notificationService: NoficationService,
    private fb: FormBuilder,
    private toster: ToastrService,
    private spinner: NgxSpinnerService,
    private _location: Location
  ) {}
  notificationTypeData: any;
  get f() {
    return this.notificationForm.controls;
  }
  submitted: boolean = false;
  notificationForm!: FormGroup;
  elementsData: any = {};
  ngOnInit(): void {
    this.updateForm();
    // console.log(history.state);
    this.elementsData = history.state;
    this.notificationForm.patchValue({
      notificationTypeId: this.elementsData.element.notificationTypeId,
      notificationTypeIdentifier:
        this.elementsData.element.notificationTypeIdentifier,
      displayTemplate: this.elementsData.element.displayTemplate,
      smsTemplate: this.elementsData.element.smsTemplate,
      emailSubject: this.elementsData.element.emailSubject,
      pushNotificationTemplate:
        this.elementsData.element.pushNotificationTemplate,
    });
  }
  updateForm() {
    this.notificationForm = this.fb.group({
      notificationTypeId: new FormControl(0),
      notificationTypeIdentifier: new FormControl('', Validators.required),
      displayTemplate: new FormControl(''),
      smsTemplate: new FormControl(''),
      emailSubject: new FormControl(''),
      pushNotificationTemplate: new FormControl(''),
    });
  }
  updateNotificationType() {
    this.submitted = true;
    if (this.notificationForm.invalid) return;
    this.notificationService
      .updateNotificationType(this.notificationForm.value)
      .subscribe(
        (data: any) => {
          this.toster.success('Update notification type');
          // this.getNotificationType();
          this.cancelBUtton();
        },
        (err) => {
          if (err.status == 500) {
            this.toster.error('Internal server error');
          }
          if (err.status == 401) {
            this.toster.error('Resource not found');
          }
          if (err.status == 400) {
            this.toster.error('Validation error');
          }
        }
      );
  }
  cancelBUtton() {
    this._location.back();
  }
}
