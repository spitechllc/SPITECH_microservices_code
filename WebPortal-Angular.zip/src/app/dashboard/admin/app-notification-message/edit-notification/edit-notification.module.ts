import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EditNotificationComponent } from './edit-notification.component';
import { AdminGuardGuard } from 'src/app/dashboard/auth/admin-guard.guard';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from 'src/app/shared.module';
import { ReactiveFormsModule } from '@angular/forms';

export const router: Routes = [
  {
    path: '',
    component: EditNotificationComponent,
    canActivate: [AdminGuardGuard],
  },
];

@NgModule({
  declarations: [EditNotificationComponent],
  imports: [
    CommonModule,
    SharedModule,
    ReactiveFormsModule,
    RouterModule.forChild(router),
  ],
})
export class EditNotificationModule {}
