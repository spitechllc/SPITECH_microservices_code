import { Component, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NgxSpinner, NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ExcelService } from '../../api-service/excel-servive/excel.service';
import { NoficationService } from '../../api-service/nofication.service';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-app-notification-message',
  templateUrl: './app-notification-message.component.html',
  styleUrls: ['./app-notification-message.component.scss'],
})
export class AppNotificationMessageComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  displayedColumns = [
    'notificationTypeId',
    'notificationTypeIdentifier',
    'notificationTypeName',
    'displayTemplate',
    'smsTemplate',
    'emailSubject',
    'pushNotificationTemplate',
    'action',
  ];
  dataSource = new MatTableDataSource<TableElement>([]);
  constructor(
    private notificationService: NoficationService,
    private fb: FormBuilder,
    private toster: ToastrService,
    private spinner: NgxSpinnerService,
    private excelService: ExcelService,
    private auth: AuthService
  ) {}
  notificationTypeData: any;
  claimIdArray: any;
  get f() {
    return this.notificationForm.controls;
  }
  submitted: boolean = false;
  allNotificationData: any = [];
  notificationForm!: FormGroup;
  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.getNotificationType();
    this.updateForm();
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  exportAsExcel() {
    var pageSize = 0;
    var pageIndex = 0;
    this.notificationService.getNotificationType().subscribe((data: any) => {
      this.allNotificationData = data.data;
      if (this.allNotificationData.length > 0) {
        this.excelService.exportAsExcelFile(
          this.allNotificationData,
          'app-notification-excel'
        );
      } else {
        this.toster.error('Data not found');
      }
    });
  }

  updateForm() {
    this.notificationForm = this.fb.group({
      notificationTypeId: new FormControl(0),
      notificationTypeIdentifier: new FormControl('', Validators.required),
      displayTemplate: new FormControl('', Validators.required),
      smsTemplate: new FormControl('', Validators.required),
      emailSubject: new FormControl('', Validators.required),
      pushNotificationTemplate: new FormControl('', Validators.required),
    });
  }

  updateNotificationType() {
    this.submitted = true;
    if (this.notificationForm.invalid) return;
    this.notificationService
      .updateNotificationType(this.notificationForm.value)
      .subscribe(
        (data: any) => {
          this.toster.success('Update notification type');
          this.getNotificationType();
        },
        (err) => {
          // if (err.status == 500) {
          //   this.toster.error('Internal server error');
          // }
          if (err.status == 401) {
            this.toster.error('Resource not found');
          }
          if (err.status == 400) {
            this.toster.error('Validation error');
          }
        }
      );
  }

  length: any;
  PageSize: number = 50;
  getNotificationType() {
    this.spinner.show();
    this.notificationService.getNotificationType().subscribe((data) => {
      this.notificationTypeData = data;
      this.dataSource = new MatTableDataSource(this.notificationTypeData.data);
      this.length = this.dataSource.data.length;
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
  pageNumber: any;
  pageIndex: number = 1;
  pageChanged(event: any) {
    this.pageIndex = event.pageIndex + 1;
    // number of the page you
    this.dataSource = new MatTableDataSource(this.notificationTypeData.data);
  }
  notificationTypeId: any;
  onClickEdit(element: any) {
    // console.log(element);
    this.spinner.show();
    if (element) {
      this.spinner.hide();
    }
    this.notificationTypeId = element.notificationTypeId;
    this.notificationForm.patchValue({
      notificationTypeId: element.notificationTypeId,
      notificationTypeIdentifier: element.notificationTypeIdentifier,
      displayTemplate: element.displayTemplate,
      smsTemplate: element.smsTemplate,
      emailSubject: element.emailSubject,
      pushNotificationTemplate: element.pushNotificationTemplate,
    });
  }
}

export interface TableElement {
  notificationTypeId: number;
  notificationTypeIdentifier: string;
  notificationTypeName: string;
  displayTemplate: string;
  smsTemplate: string;
  emailSubject: string;
  pushNotificationTemplate: string;
}
