import { NgModule } from '@angular/core';
import { SharedModule } from './../../../shared.module';
import { AppConfigurationComponent } from './app-configuration.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatSnackBarModule,
  MAT_SNACK_BAR_DEFAULT_OPTIONS,
} from '@angular/material/snack-bar';
import { AdminGuardGuard } from '../../auth/admin-guard.guard';

export const router: Routes = [
  {
    path: '',
    component: AppConfigurationComponent,
    canActivate: [AdminGuardGuard],
  },
];

@NgModule({
    declarations: [AppConfigurationComponent],
    imports: [
        SharedModule,
        FormsModule,
        MatSnackBarModule,
        ReactiveFormsModule,
        RouterModule.forChild(router),
    ],
    providers: [
        { provide: MAT_SNACK_BAR_DEFAULT_OPTIONS, useValue: { duration: 2500 } },
    ]
})
export class AppConfigurationModule {}
