import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { HelpSupportService } from '../../api-service/helpSupport.service';
import { TosterService } from '../../api-service/toster.service';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-app-configuration',
  templateUrl: './app-configuration.component.html',
  styleUrls: ['./app-configuration.component.scss'],
})
export class AppConfigurationComponent implements OnInit {
  constructor(
    private formbuilder: FormBuilder,
    private helpSupportService: HelpSupportService,
    private toster: ToastrService,
    private sppiner: NgxSpinnerService,
    private auth: AuthService
  ) {}
  appConfigurationForm!: FormGroup;
  appConfigId: number = 0;
  dataLoaded: boolean = false;
  dragging: boolean = false;
  loaded: boolean = false;
  imageLoaded: boolean = false;
  imageSrc: string = '';
  url: any;
  appconfigurationDetails: any;
  emailBanner: any;
  claimIdArray: any;
  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.createForm();
    this.getAppConfiguration();
    // this.helpSupportService.getAppConfiguration().subscribe((data: any) => {
    //   this.appconfigurationDetails = data;
    //   this.emailBanner = this.appconfigurationDetails.emailBanner;
    //   // console.log(this.emailBanner);
    //   this.appConfigId = this.appconfigurationDetails.appConfigId;
    //   // console.log(this.appconfigurationDetails);
    //   if (this.appConfigId !== '') {
    //     this.appConfigurationForm = this.formbuilder.group({
    //       appConfigId: new FormControl(this.appConfigId),
    //       supportNo: new FormControl(this.appconfigurationDetails.supportNo),
    //       supportEmail: new FormControl(
    //         this.appconfigurationDetails.supportEmail
    //       ),
    //       emailBannerbase64: new FormControl(''),
    //     });
    //     this.dataLoaded = true;
    //   }
    // });

    // this.getAppConfiguration();
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  createForm() {
    this.appConfigurationForm = this.formbuilder.group({
      supportNo: new FormControl(''),
      supportEmail: new FormControl(''),
      emailBannerbase64: new FormControl(''),
      changeEmailBanner: false,
    });
  }
  getAppConfiguration() {
    this.helpSupportService.getAppConfiguration().subscribe((data: any) => {
      this.sppiner.hide();
      this.appconfigurationDetails = data;
      this.appConfigId = this.appconfigurationDetails.appConfigId;
      this.emailBanner = this.appconfigurationDetails.emailBanner;
      this.setFormValue(this.appconfigurationDetails);
    });
  }
  setFormValue(data: any) {
    this.appConfigurationForm.patchValue({
      supportNo: data.supportNo,
      supportEmail: data.supportEmail,
      emailBannerbase64: data.emailBanner,
    });
  }

  uploadImage: boolean = true;
  handleInputChange(e: any) {
    var file = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];

    var pattern = /image-*/;
    var reader = new FileReader();

    if (!file.type.match(pattern)) {
      alert('invalid format');
      return;
    }

    this.loaded = false;

    reader.onload = this._handleReaderLoaded.bind(this);

    reader.readAsDataURL(file);
  }

  _handleReaderLoaded(e: any) {
    // console.log(e, "_handleReaderLoaded")
    var reader = e.target;
    this.url = e.target.result;
    if (this.url) {
      this.uploadImage = false;
    }
    this.imageSrc = reader.result.split(',')[1];

    this.appConfigurationForm.get('emailBannerbase64')?.setValue(this.imageSrc);
    this.appConfigurationForm.get('changeEmailBanner')?.setValue(true);
    // console.log(this.imageSrc, 'imgsrc');
    this.loaded = true;
  }
  createAppConfiguration() {
    this.helpSupportService
      .createAppConfiguration(this.appConfigurationForm.value)
      .subscribe(
        (data: any) => {},
        (err) => {
          if (err.error.errors.SupportEmail) {
            err.error.errors.SupportEmail.forEach((err: any) => {
              this.toster.error(err);
            });
          }
          if (err.error.errors.SupportNo) {
            err.error.errors.SupportNo.forEach((err: any) => {
              this.toster.error(err);
            });
          }

          if (err.error.errors.SupportDetails) {
            err.error.errors.SupportDetails.forEach((err: any) => {
              this.toster.error(err);
            });
          }
        }
      );
  }

  updateAppConfiguration() {
    this.helpSupportService
      .updateAppConfiguration({
        ...this.appConfigurationForm.value,
        appConfigId: this.appConfigId,
      })
      .subscribe(
        (data: any) => {
          if (data.success == false) {
            this.toster.error('Error in Update');
          }
          if (data.success == true) {
            this.toster.success('Update Successfully');
            this.helpSupportService.getAppConfiguration().subscribe((data) => {
              this.appconfigurationDetails = data;
              this.emailBanner = this.appconfigurationDetails.emailBanner;
            });
          }
        },
        (err) => {
          if (err.error.errors.SupportEmail) {
            err.error.errors.SupportEmail.forEach((err: any) => {
              this.toster.error(err);
            });
          }
          if (err.error.errors.SupportNo) {
            err.error.errors.SupportNo.forEach((err: any) => {
              this.toster.error(err);
            });
          }
        }
      );
  }
}
