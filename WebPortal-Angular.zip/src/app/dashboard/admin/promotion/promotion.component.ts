import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';

import { MatTableDataSource } from '@angular/material/table';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { MarketingService } from '../../api-service/marketing.service';
import { AuthService } from '../../auth/auth.service';
import * as _moment from 'moment';
import { MomentUtcDateAdapter } from '../../consumer/my-profile/my-profile.component';
import { MAT_MOMENT_DATE_FORMATS } from '@angular/material-moment-adapter';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
} from '@angular/material/core';
import { IdentityService } from '../../api-service/identityService';
import { SharedService } from '../../auth/shared.service';
export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/DD/YYYY',
  },
  display: {
    dateInput: 'MM/DD/YYYY',
    monthYearLabel: 'YYYY MMM',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'YYYY MMMM',
  },
};
@Component({
  selector: 'app-promotion',
  templateUrl: './promotion.component.html',
  styleUrls: ['./promotion.component.scss'],
  providers: [
    { provide: MAT_DATE_LOCALE, useValue: 'en-GB' },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
    { provide: DateAdapter, useClass: MomentUtcDateAdapter },
  ],
})
export class PromotionComponent implements OnInit {
  displayedColumns = [
    'promotionId',
    'eventName',
    'criteria',
    'startDate',
    'endDate',
    'displayOrder',
    'action',
  ];
  dataSource = new MatTableDataSource<PromotionTable>([]);
  promotionForm!: FormGroup;
  get f() {
    return this.promotionForm.controls;
  }
  submitted: boolean = false;
  cashBackEvent: any = [];
  CashBackCrietria: any;
  hasValue: any;
  checked: boolean = true;
  PromotionTableData: any = [];
  promotionObject: any = {};
  claimIdArray: any;
  SortBy = 'promotionId';
  constructor(
    private fb: FormBuilder,
    private marketingService: MarketingService,
    private toster: ToastrService,
    private auth: AuthService,
    private spinner: NgxSpinnerService,
    private identityServer: IdentityService
  ) {
    const moment = _moment;
    const utcDate = moment.utc();
    this.todayDates = utcDate;
  }
  todayDates: any;
  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.createForm();
    this.getCashBack();
    this.getPromotionTableData();
  }

  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  createForm() {
    this.promotionForm = this.fb.group(
      {
        cashBackEventId: new FormControl('', Validators.required),
        cashBackCriteriaId: new FormControl('', Validators.required),
        criteria: new FormControl(''),
        isPercentage: new FormControl(false),
        value: new FormControl('', Validators.required),
        startDate: new FormControl('', Validators.required),
        endDate: new FormControl('', Validators.required),
        displayOrder: new FormControl('', Validators.required),
        description: new FormControl(''),
      },
      { validator: this.dateLessThan('startDate', 'endDate') }
    );
  }
  dateLessThan(from: string, to: string) {
    return (group: FormGroup): { [key: string]: any } => {
      let f = group.controls[from];
      let t = group.controls[to];
      if (f.value > t.value && t.value) {
        this.toster.error('from Date  should be less than to Date ');
        return {
          dates: 'Date from should be less than Date to',
        };
      }
      return {};
    };
  }
  onClickStartDateUtc(event: any) {
    this.promotionForm.patchValue({
      startDate: event.target.value.utc().format('YYYY-MM-DD HH:mm:ss'),
    });
  }
  onClickEndDateUtc(event: any) {
    this.promotionForm.patchValue({
      endDate: event.target.value.utc().format('YYYY-MM-DD HH:mm:ss'),
    });
  }
  onHeaderSortChange(event: any) {
    this.SortBy = event.active;
    if (event.direction == '') {
      this.SortOrder = 'asc';
    } else {
      this.SortOrder = event.direction;
    }

    this.getPromotionTableData();
  }
  getPromotionTableData() {
    this.marketingService
      .getPromotion(this.PageIndex, this.PageSize, this.SortOrder, this.SortBy)
      .subscribe(
        (data: any) => {
          this.PromotionTableData = data;
          this.total = data.totalCount;
          this.dataSource = new MatTableDataSource(
            this.PromotionTableData.data
          );
        },
        (err) => {}
      );
  }
  getCashBack() {
    this.marketingService
      .getCashBackEvent('Promotion')
      .subscribe((data: any) => {
        this.cashBackEvent = data;
      });
  }
  onCheckBox(event: any) {
    this.promotionForm.patchValue({
      isPercentage: event.checked,
    });
  }
  onChangeCashBackCrietriaByEventId(value: number) {
    this.promotionForm.patchValue({
      cashBackEventId: value,
    });
    this.criteria(value);
  }

  criteria(value: any) {
    this.marketingService
      .getCashBackCrietriaByEventId(value)
      .subscribe((data: any) => {
        this.CashBackCrietria = data;
        this.CashBackCrietria.forEach((element: any) => {
          this.hasValue = element.hasValue;
          if (this.hasValue == true) {
            this.promotionForm.patchValue({});
          }
          if (this.hasValue == false) {
            this.promotionForm.patchValue({
              criteria: null,
            });
          }
        });
      });
  }

  onChageCriteria(event: any) {
    // console.log(event);
    this.promotionForm.patchValue({
      cashBackCriteriaId: event.value,
    });
  }
  promotionId: any;
  onClickEdit(promotionId: any) {
    this.promotionId = promotionId;
    this.marketingService
      .getPromotionById(promotionId)
      .subscribe((data: any) => {
        this.promotionObject = data;
        if (data.cashBackEventId) {
          this.marketingService
            .getCashBackCrietriaByEventId(data.cashBackEventId)
            .subscribe((data: any) => {
              this.CashBackCrietria = data;
              this.CashBackCrietria.forEach((element: any) => {
                this.hasValue = element.hasValue;

                if (this.hasValue == false) {
                  this.promotionForm.patchValue({
                    criteria: null,
                  });
                }
              });
            });
        }

        if (this.promotionObject.cashBackEventId) {
          this.marketingService
            .getCashBackCrietriaByEventId(this.promotionObject.cashBackEventId)
            .subscribe((data: any) => {
              this.CashBackCrietria = data;
            });
        }
        this.promotionForm.patchValue({
          cashBackEventId: this.promotionObject.cashBackEventId,
          cashBackCriteriaId: this.promotionObject.cashBackCriteriaId,
          criteria: this.promotionObject.criteria,
          isPercentage: this.promotionObject.isPercentage,
          value: this.promotionObject.value,
          startDate: this.promotionObject.startDate,
          endDate: this.promotionObject.endDate,
          displayOrder: this.promotionObject.displayOrder,
          description: this.promotionObject.description,
        });
      });
  }

  formReset() {
    this.promotionForm.reset();
    this.promotionId = 0;
    this.createForm();
  }

  submit() {
    this.submitted = true;
    if (!this.promotionId) {
      this.createPromotion();
    }
    if (this.promotionId) {
      this.updatePromotion();
    }
  }
  createPromotion() {
    this.marketingService.promotion(this.promotionForm.value).subscribe(
      (data: any) => {
        this.toster.success('Promotion created successfully!');
        this.getPromotionTableData();
      },
      (err) => {
        // console.log(err);
        if (err.status == 400) {
          this.toster.error('Validation error', '', {
            timeOut: 10000,
          });
        }
        if (err.error.errors.value) {
          err.error.errors.value.forEach((err: any) => {
            this.toster.error(err);
          });
        }
        if (err.error.errors.Event) {
          err.error.errors.Event.forEach((err: any) => {
            this.toster.error('Event is required', '', {
              timeOut: 10000,
            });
          });
        }
        if (err.error.errors.Criteria) {
          err.error.errors.Criteria.forEach((err: any) => {
            this.toster.error(err, '', {
              timeOut: 10000,
            });
          });
        }
        if (err.error.errors.IsPercentage) {
          err.error.errors.IsPercentage.forEach((err: any) => {
            this.toster.error(err, '', {
              timeOut: 10000,
            });
          });
        }
        if (err.error.errors.CashBackCriteriaId) {
          err.error.errors.CashBackCriteriaId.forEach((err: any) => {
            this.toster.error(err, '', {
              timeOut: 10000,
            });
          });
        }
      }
    );
  }
  updatePromotion() {
    this.marketingService
      .updatePromotion({
        ...this.promotionForm.value,
        promotionId: this.promotionId,
      })
      .subscribe(
        (data: any) => {
          this.toster.success('Promotion updated successfully!');
          this.getPromotionTableData();
        },
        (err) => {
          // console.log(err);
          if (err.status == 400) {
            this.toster.error('Validation errors ', '', {
              timeOut: 10000,
            });
          }
          if (err.error.errors.value) {
            err.error.errors.value.forEach((err: any) => {
              this.toster.error(err);
            });
          }
          if (err.error.errors.Event) {
            err.error.errors.Event.forEach((err: any) => {
              this.toster.error(err, '', {
                timeOut: 10000,
              });
            });
          }
          if (err.error.errors.Criteria) {
            err.error.errors.Criteria.forEach((err: any) => {
              this.toster.error(err, '', {
                timeOut: 10000,
              });
            });
          }
          if (err.error.errors.IsPercentage) {
            err.error.errors.IsPercentage.forEach((err: any) => {
              this.toster.error(err, '', {
                timeOut: 10000,
              });
            });
          }
          if (err.error.errors.CashBackCriteriaId) {
            err.error.errors.CashBackCriteriaId.forEach((err: any) => {
              this.toster.error(err, '', {
                timeOut: 10000,
              });
            });
          }
        }
      );
  }
  total: any;
  PageSize: number = 50;
  SortOrder = 'asc';
  PageIndex: number = 1;
  pageChanged(event: any) {
    this.PageIndex = event.pageIndex + 1;
    this.PageSize = event.pageSize;
    this.getPromotionTableData();
  }
}
export interface PromotionTable {
  promotionId: Number;
  startDate: string;
  endDate: string;
  criteria: string;
  eventName: string;
}
