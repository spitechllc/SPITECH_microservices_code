import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PromotionComponent } from './promotion.component';
import { SharedModule } from 'src/app/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';

export const router: Routes = [
  {
    path: '',
    component: PromotionComponent,
  },
];

@NgModule({
  declarations: [PromotionComponent],
  imports: [
    CommonModule,
    SharedModule,
    MatCardModule,
    FormsModule,
    MatSnackBarModule,
    ReactiveFormsModule,
    NgxMaterialTimepickerModule,
    RouterModule.forChild(router),
  ],
})
export class PromotionModule {}
