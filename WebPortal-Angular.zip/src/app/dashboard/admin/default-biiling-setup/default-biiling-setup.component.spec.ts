import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DefaultBiilingSetupComponent } from './default-biiling-setup.component';

describe('DefaultBiilingSetupComponent', () => {
  let component: DefaultBiilingSetupComponent;
  let fixture: ComponentFixture<DefaultBiilingSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DefaultBiilingSetupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DefaultBiilingSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
