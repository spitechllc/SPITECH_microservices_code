import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DefaultBiilingSetupComponent } from './default-biiling-setup.component';
import { RouterModule, Routes } from '@angular/router';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatCardModule } from '@angular/material/card';
import { SharedModule } from 'src/app/shared.module';

export const router: Routes = [
  {
    path: '',
    component: DefaultBiilingSetupComponent,
  },
];

@NgModule({
  declarations: [DefaultBiilingSetupComponent],
  imports: [
    CommonModule,
    SharedModule,
    MatCardModule,
    FormsModule,
    MatSnackBarModule,
    ReactiveFormsModule,
    NgxMaterialTimepickerModule,
    RouterModule.forChild(router),
  ],
})
export class DefaultBiilingSetupModule {}
