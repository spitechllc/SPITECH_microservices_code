import { Location } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { IdentityService } from '../../api-service/identityService';
import { PaymentService } from '../../api-service/payment.srvice';
import { StoreService } from '../../api-service/storeService';
import { TransactionService } from '../../api-service/trasation.service';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-default-biiling-setup',
  templateUrl: './default-biiling-setup.component.html',
  styleUrls: ['./default-biiling-setup.component.scss'],
})
export class DefaultBiilingSetupComponent implements OnInit {
  displayedColumns = [
    'paymentMethod',
    'monthlySaasFee',
    'transactionFee',
    'transactionPercentageFee',
    'minTransactionRange',
    'maxTransactionRange',
    'isActive',
    'action',
  ];
  dataSource = new MatTableDataSource<TableDetails>([]);
  @ViewChild(MatSort) sort: MatSort;
  myModel = true;
  checked = true;
  storeId: any;
  storeDetails: any;
  paymentMethodDetails: any;
  claimIdArray: any;
  err: string = '';
  storeBillingForm!: FormGroup;
  paymentConfigurationDetails: any;
  submitted: boolean = false;
  paymentMethod: any;
  storeBillingDetails: any = [];
  storeBillingFeeId: any;
  isActive: boolean = true;
  constructor(
    private storeService: StoreService,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private toster: ToastrService,
    private auth: AuthService,
    private _location: Location,
    private paymentService: PaymentService,
    private transactionService: TransactionService,
    private identityServer: IdentityService
  ) {}
  get f() {
    return this.storeBillingForm.controls;
  }
  ngOnInit(): void {
    this.activatedRoute.params.subscribe((data: any) => {
      this.storeId = data.storeId;
    });

    this.createForm();
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.getPaymentMethod();
    this.getDefaultBillingFee();
  }

  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  getDefaultBillingFee() {
    this.transactionService.getDefaultBillingFee().subscribe((data: any) => {
      this.dataSource = new MatTableDataSource(data.data);
      this.dataSource.sort = this.sort;
    });
  }

  onClickisActive(event: MatSlideToggleChange) {
    this.isActive = event.checked;
  }

  createForm() {
    this.storeBillingForm = this.formBuilder.group({
      storeId: new FormControl(0),
      siteId: new FormControl(''),
      paymentMethodId: new FormControl('', Validators.required),
      minTransactionRange: new FormControl('', Validators.required),
      maxTransactionRange: new FormControl('', Validators.required),
      transactionFee: new FormControl('', Validators.required),
      transactionPercentageFee: new FormControl('', Validators.required),
      monthlySaasFee: new FormControl('', Validators.required),
      isDefault: true,
    });
  }
  getPaymentMethod() {
    this.paymentService.getPaymentMethod().subscribe((data: any) => {
      this.paymentMethod = data.data;
      // console.log(this.paymentMethod);
    });
  }

  getStoreBilling() {
    this.transactionService
      .getStoreBillingFeeByStoreId(this.storeId)
      .subscribe((data: any) => {
        this.storeBillingDetails = data.data;

        this.dataSource = new MatTableDataSource(data.data);
      });
  }

  onClickStoreBilling(id: any) {
    // console.log(id);
    this.storeBillingFeeId = id;
    this.transactionService.getStoreBillingFeeBy(id).subscribe((data: any) => {
      this.storeBillingForm.patchValue({
        storeId: data.data.storeId,
        siteId: data.data.siteId,
        paymentMethodId: data.data.paymentMethodId,
        minTransactionRange: data.data.minTransactionRange,
        maxTransactionRange: data.data.maxTransactionRange,
        transactionFee: data.data.transactionFee,
        transactionPercentageFee: data.data.transactionPercentageFee,
        monthlySaasFee: data.data.monthlySaasFee,
      });
    });
  }

  formReset() {
    this.storeBillingForm.reset();
    this.storeBillingFeeId = 0;
    this.createForm();
  }

  submit() {
    if (!this.storeBillingFeeId) {
      this.saveStoreBilling();
    }
    if (this.storeBillingFeeId) {
      this.updateStoreBilling();
    }
  }
  mintransationerr: string = '';
  saveStoreBilling() {
    this.submitted = true;
    if (this.storeBillingForm.invalid) return;
    this.transactionService
      .addStoreBillingFee(this.storeBillingForm.value)
      .subscribe(
        (data: any) => {
          if (data.success == true) {
            this.toster.success('Store billing save successfully');
            this.getDefaultBillingFee();
          }
          if (data.success == false) {
            this.toster.warning('Store billing not save status:false');
          }
        },
        (err) => {
          // console.log(err);
          if (err.error.errors.MinTransactionRange) {
            err.error.errors.MinTransactionRange.forEach((err: any) => {
              this.mintransationerr = err;
              // console.log(err);
              this.toster.error(err);
            });
          }
          if (err.error.errors.TransactionRange) {
            err.error.errors.TransactionRange.forEach((err: any) => {
              // console.log(err);
              this.toster.error(err);
            });
          }
        }
      );
  }
  updateStoreBilling() {
    this.transactionService
      .updateStoreBillingFee({
        ...this.storeBillingForm.value,
        storeBillingFeeId: this.storeBillingFeeId,
        isActive: this.isActive,
      })
      .subscribe(
        (data) => {
          this.toster.success('Update store billing Successfully');
          this.getDefaultBillingFee();
        },
        (err) => {
          if (err.error.errors.MinTransactionRange) {
            err.error.errors.MinTransactionRange.forEach((err: any) => {
              this.mintransationerr = err;
              // console.log(this.mintransationerr);
              this.toster.error(err);
            });
          }
        }
      );
  }
  onClickBack() {
    this._location.back();
  }
}

export interface TableDetails {
  monthlySaasFee: string;
  transactionFee: string;
  Subscription: string;
  transactionPercentageFee: string;
  effectiveDate: string;
  storeBillingFeeId: string;
  storeName: string;
  action: string;
}
