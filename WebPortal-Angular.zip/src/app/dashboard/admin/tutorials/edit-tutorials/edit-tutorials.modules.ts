import { NgModule } from '@angular/core';
import { SharedModule } from './../../../../shared.module';
import { RouterModule, Routes } from '@angular/router';
import { TagInputModule } from 'ngx-chips';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EditTutorialsComponent } from './edit-tutorials.component';
// import { AgmCoreModule } from '@agm/core';


export const router: Routes = [
  {path: ':tutorialId', component: EditTutorialsComponent}
]


@NgModule({
    declarations: [EditTutorialsComponent],
    imports: [
        SharedModule,
        FormsModule,
        TagInputModule,
        ReactiveFormsModule,
        RouterModule.forChild(router)
    ]
})
export class EditTutorialStoreModule { }