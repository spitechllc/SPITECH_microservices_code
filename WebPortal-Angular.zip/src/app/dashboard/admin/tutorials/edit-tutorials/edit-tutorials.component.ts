import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { HelpSupportService } from 'src/app/dashboard/api-service/helpSupport.service';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
import { SharedService } from 'src/app/dashboard/auth/shared.service';

@Component({
  selector: 'app-edit-tutorials',
  templateUrl: './edit-tutorials.component.html',
  styleUrls: ['./edit-tutorials.component.scss'],
})
export class EditTutorialsComponent implements OnInit {
  checked = true;
  createTutorialForm!: FormGroup;
  dataLoaded: boolean = false;
  submitted: boolean = false;
  loading: boolean = false;
  get f() {
    return this.createTutorialForm.controls;
  }
  tutorialId: any;
  tutorialDetails: any;
  tenantData: any;
  constructor(
    private formBuilder: FormBuilder,
    private helpSupportService: HelpSupportService,
    private activatedRoute: ActivatedRoute,
    private toster: ToastrService,
    private router: Router,
    private _location: Location,
    private spinner: NgxSpinnerService
  ) {}

  ngOnInit(): void {
    this.getTutorialCategory();
    this.activatedRoute.params.subscribe((data: any) => {
      this.tutorialId = data.tutorialId;
    });
    if (this.tutorialId !== '') {
      const _id: number = this.tutorialId as number;
      this.helpSupportService.getTutorialById(_id).subscribe((data: any) => {
        this.tutorialDetails = data;
        this.setFormValue(this.tutorialDetails);
      });
    }
    this.createForm();
  }

  createForm() {
    this.createTutorialForm = this.formBuilder.group({
      TutorialId: new FormControl(),
      TutorialName: new FormControl('', Validators.required),
      ShortDescription: new FormControl('', Validators.required),
      Category: new FormControl(0, Validators.required),
      Thumbnailbase64: new FormControl(''),
      ChangeThumbnail: false,
      FileUrl: new FormControl(''),
    });
  }
  TutorialName: any;
  ShortDescription: any;
  Category: any;
  setValue() {
    // console.log();
    this.TutorialName = this.createTutorialForm.get('TutorialName')?.value;
    this.ShortDescription =
      this.createTutorialForm.get('ShortDescription')?.value;
    this.Category = this.createTutorialForm.get('Category')?.value;
  }
  thumbnil: any;
  setFormValue(data: any) {
    console.log(data.tenantId);
    this.thumbnil = data.thumbnail;
    this.createTutorialForm.patchValue({
      TutorialId: data.tutorialId,
      TutorialName: data.tutorialName,
      ShortDescription: data.shortDescription,
      Category: data.tutorialCategoryId,
      Thumbnailbase64: data.thumbnail,
      FileUrl: data.fileUrl,
    });
  }
  tutorailCatogryDetails: any;
  getTutorialCategory() {
    this.helpSupportService.getTutorialCategory().subscribe(
      (data: any) => {
        this.tutorailCatogryDetails = data.data;
      },
      (err) => {
        if (err.status == 500) {
          this.toster.error('Internal server error');
        }
      }
    );
  }
  submit() {
    this.updateTutorail();
  }
  updateTutorail() {
    var formData: any = new FormData();
    formData.append(
      'TutorialId',
      this.createTutorialForm.get('TutorialId')?.value
    );
    formData.append(
      'TutorialName',
      this.createTutorialForm.get('TutorialName')?.value
    );
    formData.append(
      'ShortDescription',
      this.createTutorialForm.get('ShortDescription')?.value
    );
    formData.append('Category', this.createTutorialForm.get('Category')?.value);
    formData.append(
      'Thumbnailbase64',
      this.createTutorialForm.get('Thumbnailbase64')?.value
    );
    formData.append(
      'ChangeThumbnail',
      this.createTutorialForm.get('ChangeThumbnail')?.value
    );

    formData.append('FileUrl', this.createTutorialForm.get('FileUrl')?.value);
    this.helpSupportService.updateTutorial(formData).subscribe(
      (data: any) => {
        if (data) {
          this.toster.success('Tutorial  Update Successfully');

          this.onClickBack();
        }
      },
      (err) => {
        err.error.errors.FileUrl.forEach((err: any) => {
          this.toster.error(err, '', {
            timeOut: 10000,
          });
        });
        err.error.errors.TutorialName.forEach((err: any) => {
          this.toster.error(err, '', {
            timeOut: 10000,
          });
        });
      }
    );
  }

  dragging: boolean = false;
  loaded: boolean = false;
  imageLoaded: boolean = false;
  imageSrc: string = '';
  url: any;
  uploadImage: boolean = true;
  handleInputChange(e: any) {
    // console.log(e, "input change")
    var file = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];

    var pattern = /image-*/;
    var reader = new FileReader();

    if (!file.type.match(pattern)) {
      alert('invalid format');
      return;
    }

    this.loaded = false;

    reader.onload = this._handleReaderLoaded.bind(this);

    reader.readAsDataURL(file);
  }

  _handleReaderLoaded(e: any) {
    // console.log(e, "_handleReaderLoaded")
    var reader = e.target;
    this.url = e.target.result;
    if (this.url) {
      this.uploadImage = false;
    }
    this.imageSrc = reader.result.split(',')[1];

    this.createTutorialForm.get('Thumbnailbase64')?.setValue(this.imageSrc);
    this.createTutorialForm.get('ChangeThumbnail')?.setValue(true);
    // console.log(this.imageSrc, 'imgsrc');
    this.loaded = true;
  }
  // uploadImageFile(event: any) {

  //   this.createTutorialForm.get('ChangeThumbnail')?.setValue(true);
  //   var file = (event.target as HTMLInputElement).files[0];
  //   this.createTutorialForm.patchValue({

  //     Thumbnailbase64: file,
  //   });
  //   // this.createTutorialForm.get('FileUrl').updateValueAndValidity();
  //   this.createTutorialForm.get('Thumbnailbase64').updateValueAndValidity();
  // }
  uploadFile(event: any) {
    // console.log(event, 'event');
    var file = (event.target as HTMLInputElement).files[0];
    this.createTutorialForm.patchValue({
      FileUrl: file,
      // Thumbnailbase64: file,
    });
    this.createTutorialForm.get('FileUrl').updateValueAndValidity();
    // this.createTutorialForm.get('Thumbnailbase64').updateValueAndValidity();
  }
  onClickBack() {
    this._location.back();
  }
}
