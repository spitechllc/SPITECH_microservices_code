import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditTutorialsComponent } from './edit-tutorials.component';

describe('EditTutorialsComponent', () => {
  let component: EditTutorialsComponent;
  let fixture: ComponentFixture<EditTutorialsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditTutorialsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditTutorialsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
