import { NgModule } from '@angular/core';
import { SharedModule } from './../../../shared.module';
import { TutorialsComponent } from './tutorials.component';
import { RouterModule, Routes } from '@angular/router';

import { MatSortHeader, MatSortModule } from '@angular/material/sort';
import { AdminGuardGuard } from '../../auth/admin-guard.guard';
// import { EditTutorialsComponent } from './edit-tutorials/edit-tutorials.component';

export const router: Routes = [
  { path: '', component: TutorialsComponent, canActivate: [AdminGuardGuard] },
];

@NgModule({
    declarations: [TutorialsComponent],
    imports: [SharedModule, RouterModule.forChild(router)]
})
export class TutorialsModule {}
