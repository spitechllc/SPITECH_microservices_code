import { NgModule } from '@angular/core';
import { SharedModule } from './../../../../shared.module';
import { CreateTutorialComponent } from './create-tutorial.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

export const router: Routes = [
  {path: '', component: CreateTutorialComponent}
]


@NgModule({
    declarations: [CreateTutorialComponent],
    imports: [
        SharedModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(router)
    ]
})
export class CreateTutorialModule { }