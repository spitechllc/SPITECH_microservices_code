import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { HelpSupportService } from 'src/app/dashboard/api-service/helpSupport.service';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';

@Component({
  selector: 'app-create-tutorial',
  templateUrl: './create-tutorial.component.html',
  styleUrls: ['./create-tutorial.component.scss'],
})
export class CreateTutorialComponent implements OnInit {
  constructor(
    private formBuilder: FormBuilder,
    private helpSupportService: HelpSupportService,
    private toster: ToastrService,
    private router: Router,
    private _location: Location
  ) {}

  checked = true;
  createTutorialForm!: FormGroup;
  submitted: boolean = false;
  loading: boolean = false;
  tenantData: any;
  get f() {
    return this.createTutorialForm.controls;
  }

  ngOnInit(): void {
    this.createTutorialForm = this.formBuilder.group({
      TutorialName: new FormControl('', Validators.required),
      ShortDescription: new FormControl(''),
      Category: new FormControl('', Validators.required),
      Thumbnailbase64: new FormControl(''),
      FileUrl: ['', Validators.required],
      TenantId: new FormControl(),
    });
    this.getTutorialCategory();
  }

  TutorialName: any;
  ShortDescription: any;
  Category: any;
  setValue() {
    this.TutorialName = this.createTutorialForm.get('TutorialName')?.value;
    this.ShortDescription =
      this.createTutorialForm.get('ShortDescription')?.value;
    this.Category = this.createTutorialForm.get('Category')?.value;
  }
  tutorailCatogryDetails: any;
  getTutorialCategory() {
    this.helpSupportService.getTutorialCategory().subscribe((data: any) => {
      this.tutorailCatogryDetails = data.data;
      this.createTutorialForm.reset();
    });
  }
  submit() {
    this.submitted = true;
    if (this.createTutorialForm.invalid) {
      return;
    }
    this.createTutorail();
  }
  createTutorail() {
    var formData: any = new FormData();
    formData.append(
      'TutorialName',
      this.createTutorialForm.get('TutorialName')?.value
    );
    formData.append(
      'ShortDescription',
      this.createTutorialForm.get('ShortDescription')?.value
    );
    formData.append('Category', this.createTutorialForm.get('Category')?.value);
    formData.append(
      'Thumbnailbase64',
      this.createTutorialForm.get('Thumbnailbase64')?.value
    );

    formData.append('FileUrl', this.createTutorialForm.get('FileUrl')?.value);
    this.helpSupportService.createTutorial(formData).subscribe(
      (data: any) => {
        this.toster.success('Tutorial  created successfully!');

        this.onClickBack();
      },
      (err) => {
        err.error.errors.FileUrl.forEach((err: any) => {
          this.toster.error(err, '', {
            timeOut: 10000,
          });
        });
        err.error.errors.TutorialName.forEach((err: any) => {
          this.toster.error(err, '', {
            timeOut: 10000,
          });
        });
      }
    );
  }

  dragging: boolean = false;
  loaded: boolean = false;
  imageLoaded: boolean = false;
  imageSrc: string = '';
  url: any;
  uploadImage: boolean = true;
  handleInputChange(e: any) {
    var file = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];

    var pattern = /image-*/;
    var reader = new FileReader();

    if (!file.type.match(pattern)) {
      alert('invalid format');
      return;
    }

    this.loaded = false;

    reader.onload = this._handleReaderLoaded.bind(this);

    reader.readAsDataURL(file);
  }

  _handleReaderLoaded(e: any) {
    var reader = e.target;
    this.url = e.target.result;
    if (this.url) {
      this.uploadImage = false;
    }
    this.imageSrc = reader.result.split(',')[1];

    this.createTutorialForm.get('Thumbnailbase64')?.setValue(this.imageSrc);
    // console.log(this.imageSrc, 'imgsrc');
    this.loaded = true;
  }
  uploadFile(event: any) {
    var file = (event.target as HTMLInputElement).files[0];
    this.createTutorialForm.patchValue({
      FileUrl: file,
      // Thumbnailbase64: file,
    });
    this.createTutorialForm.get('FileUrl').updateValueAndValidity();
    // this.createTutorialForm.get('Thumbnailbase64').updateValueAndValidity();
  }
  onClickBack() {
    this._location.back();
  }
}
