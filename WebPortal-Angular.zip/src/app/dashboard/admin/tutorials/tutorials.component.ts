import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';

import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { debounce } from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ExcelService } from '../../api-service/excel-servive/excel.service';
import { HelpSupportService } from '../../api-service/helpSupport.service';
import { AuthService } from '../../auth/auth.service';
import { SharedService } from '../../auth/shared.service';

@Component({
  selector: 'app-tutorials',
  templateUrl: './tutorials.component.html',
  styleUrls: ['./tutorials.component.scss'],
})
export class TutorialsComponent implements OnInit {
  displayedColumns = [
    'tutorialId',
    'tutorialName',
    'tutorialCategoryId',
    'shortDescription',
    'fileUrl',
    'action',
  ];
  dataSource = new MatTableDataSource<PeriodicElement>([]);
  dataArray: any;
  total: any;
  PageSize: number = 50;
  SortOrder = 'desc';
  tutorailsDetails: any;
  err: any;
  fileUrl: any;
  PageIndex: number = 1;
  SortBy = 'tutorialId';
  claimIdArray: any;
  authError: string = '';
  TutorialName: string = '';
  tutorialEvent: any;
  Category: number = 0;
  paramsData: any = {};
  tutorialData: any = [];
  constructor(
    private helpSupportService: HelpSupportService,
    private spinner: NgxSpinnerService,
    private auth: AuthService,
    private activateRoute: ActivatedRoute,
    private router: Router,
    private toster: ToastrService,
    private excelService: ExcelService,
    public sharedService: SharedService
  ) {}

  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.tenantData = this.sharedService.tenantData;
    this.activateRoute.queryParamMap.subscribe((data: any) => {
      this.paramsData = data.params;
    });
    if (this.paramsData.data == 'true') {
      this.PageIndex = this.paramsData.PageIndex;
      this.PageSize = this.paramsData.PageSize;
      this.tutorialEvent = this.paramsData.tutorialEvent
        ? this.paramsData.tutorialEvent
        : 0;
      this.TutorialName = this.paramsData.TutorialName
        ? this.paramsData.TutorialName
        : '';

      this.Category = this.paramsData.Category ? this.paramsData.Category : 0;
      if (this.Category > 0) {
        this.getTutorialCategory();
      }

      this.getTutorial();
    } else {
      this.getTutorial();
    }
  }
  tenantData: any;
  tenantId: number = 0;
  onClickTenant(value: any) {
    this.tenantId = value;
    this.getTutorial();
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }

  exportAsExcel() {
    var pageSize = 0;
    var pageIndex = 0;
    this.PageIndex = 0;
    this.helpSupportService
      .getTutorail(
        pageIndex,
        pageSize,
        this.SortOrder,
        this.SortBy,
        this.TutorialName,
        this.Category,
        this.tenantId
      )
      .subscribe((data: any) => {
        this.tutorialData = data.data;
        if (this.tutorialData.length > 0) {
          this.excelService.exportAsExcelFile(
            this.tutorialData.map((t: any) => {
              return {
                'Tutorial Id': t.tutorialId,
                'Tutorial Name': t.tutorialName,
                Category: t.category,
                Description: t.shortDescription,
              };
            }),
            'Tutorial'
          );
        } else {
          this.toster.error('Data not found');
        }
      });
  }

  onHeaderSortChange(event: any) {
    // console.log(event.active);
    this.SortBy = event.active;
    if (event.direction == '') {
      this.SortOrder = 'asc';
    } else {
      this.SortOrder = event.direction;
    }

    this.getTutorial();
  }
  getTutorial() {
    this.helpSupportService
      .getTutorail(
        this.PageIndex,
        this.PageSize,
        this.SortOrder,
        this.SortBy,
        this.TutorialName,
        this.Category,
        this.tenantId
      )
      .subscribe(
        (data: any) => {
          this.tutorailsDetails = data;

          // this.tutorailsDetails.data.forEach((element: any) => {
          //   this.fileUrl = element.fileUrl.split('.').pop();
          //   console.log(this.fileUrl);
          // });
          this.dataSource = new MatTableDataSource(this.tutorailsDetails.data);
          this.total = data.totalCount;
          this.spinner.hide();
          // this.spinner.hide();
          // console.log(this.dataSource)
        },
        (err) => {
          this.err = err.message;
          if (err.status == 500) {
            this.toster.error('Internal server error');
          }
        }
      );
  }

  onChange(event: any) {
    // console.log(event);
    this.tutorialEvent = event;
    if (this.tutorialEvent == 1) {
      this.getTutorialCategory();
    }
    if (this.tutorialEvent == 0) {
      this.Category = 0;
      this.TutorialName = '';
      this.getTutorial();
      this.queryParams();
    }
    this.router.navigate(['/admin/tutorials'], {
      queryParams: {
        tutorialEvent: this.tutorialEvent,
        data: 'true',
      },
      queryParamsHandling: 'merge',
    });
  }

  filterTutorialName = debounce(($event: any) => {
    // console.log($event);
    this.TutorialName = $event.target.value;
    this.PageIndex = 1;
    this.Category = 0;
    this.queryParams();
    this.getTutorial();
  }, 1000);
  tutorailCatogryDetails: any;
  getTutorialCategory() {
    this.helpSupportService.getTutorialCategory().subscribe((data: any) => {
      this.tutorailCatogryDetails = data.data;

      // console.log(this.tutorailCatogryDetails);
    });
  }
  filterCategory(event: any) {
    // console.log(event);
    this.Category = event;
    this.TutorialName = '';
    this.PageIndex = 1;
    this.queryParams();
    this.getTutorial();
  }
  pageChanged(event: any) {
    this.PageIndex = event.pageIndex + 1;
    this.PageSize = event.pageSize;
    this.queryParams();
    this.getTutorial();
  }

  queryParams() {
    this.router.navigate(['/admin/tutorials'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        TutorialName: this.TutorialName,
        Category: this.Category,
        data: 'true',
      },
      queryParamsHandling: 'merge',
    });
  }
}

export interface PeriodicElement {
  tutorialId: number;
  tutorialName: string;
  category: string;
  shortDescription: string;
  fileUrl: string;
  action: string;
}
