import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BusinessUserComponent } from './business-user.component';
import { SharedModule } from 'src/app/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { AdminGuardGuard } from '../../auth/admin-guard.guard';
import { ReactiveFormsModule } from '@angular/forms';
import { AddBusinessUserComponent } from './add-business-user/add-business-user.component';

export const router: Routes = [
  {
    path: '',
    component: BusinessUserComponent,
    canActivate: [AdminGuardGuard],
  },
];

@NgModule({
  declarations: [BusinessUserComponent, AddBusinessUserComponent],
  imports: [SharedModule, ReactiveFormsModule, RouterModule.forChild(router)],
})
export class BusinessUserModule {}
