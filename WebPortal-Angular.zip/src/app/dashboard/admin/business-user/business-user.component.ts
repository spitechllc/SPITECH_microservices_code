import { Component, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ExcelService } from '../../api-service/excel-servive/excel.service';
import { IdentityService } from '../../api-service/identityService';
import { AuthService } from '../../auth/auth.service';

import { AddBusinessUserComponent } from './add-business-user/add-business-user.component';

@Component({
  selector: 'app-business-user',
  templateUrl: './business-user.component.html',
  styleUrls: ['./business-user.component.scss'],
})
export class BusinessUserComponent implements OnInit {
  @ViewChild(MatSort) sort: MatSort;
  displayedColumns = [
    'firstName',
    'lastName',
    'mobileNumber',
    'businessAccountNumber',
    'businessName',
    'action',
  ];
  dataSource = new MatTableDataSource<TableElement>([]);
  claimIdArray: any;
  constructor(
    private spinner: NgxSpinnerService,
    private identityService: IdentityService,
    public dialog: MatDialog,
    private fb: FormBuilder,
    private toster: ToastrService,
    private excelService: ExcelService,
    private auth: AuthService
  ) {}
  emailPhone: any;
  emailPhoneForm!: FormGroup;
  submitted: boolean = false;
  businessUsersData: any = [];
  get f() {
    return this.emailPhoneForm.controls;
  }
  ngOnInit(): void {
    this.createForm();
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  exportAsExcel() {
    this.submitted = true;
    if (this.emailPhoneForm.invalid) return;
    this.spinner.show();
    this.identityService
      .getSearchEmailPhone(this.emailPhone)
      .subscribe((data: any) => {
        this.businessUsersData = data.data;
        if (this.businessUsersData.length > 0) {
          this.excelService.exportAsExcelFile(
            [this.businessUsersData],
            'business-user-excel'
          );
        } else {
          this.toster.error('Data not found');
        }
      });
  }

  createForm() {
    this.emailPhoneForm = this.fb.group({
      emailphone: new FormControl('', Validators.required),
    });
  }
  onChangePhoneEmail(event: any) {
    this.emailPhone = event?.target.value;
  }
  length: any;
  searchEmailPhone() {
    this.submitted = true;
    if (this.emailPhoneForm.invalid) return;
    this.spinner.show();
    this.identityService
      .getSearchEmailPhone(this.emailPhone)
      .subscribe((data: any) => {
        this.dataSource = new MatTableDataSource([data.data]);
        if (data.data == null) {
          this.length = 0;
          this.spinner.hide();
        } else if (data.success == true) {
          this.length = 1;
        }
        this.spinner.hide();
      });
  }
  UpdateBusinessUser(action: any, obj: any) {
    obj.action = action;
    const dialogRef = this.dialog.open(AddBusinessUserComponent, {
      width: '430px',
      panelClass: 'popup',
      data: obj,
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.searchEmailPhone();
    });
  }
}

export interface TableElement {
  siteId: number;
  company: string;
  storeName: string;
  status: boolean;

  color: string;
}
