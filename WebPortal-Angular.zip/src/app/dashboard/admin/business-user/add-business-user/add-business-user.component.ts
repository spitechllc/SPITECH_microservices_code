import { Component, Inject, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
export interface UsersData {
  roleId: number;
  roleName: string;
}
@Component({
  selector: 'app-add-business-user',
  templateUrl: './add-business-user.component.html',
  styleUrls: ['./add-business-user.component.scss'],
})
export class AddBusinessUserComponent implements OnInit {
  local_data: any;
  roleId: any;
  submitted: boolean = false;
  get f() {
    return this.addBusinessUserForm.controls;
  }
  constructor(
    private indentityService: IdentityService,
    private fb: FormBuilder,
    private toster: ToastrService,

    public dialogRef: MatDialogRef<AddBusinessUserComponent>,
    @Inject(MAT_DIALOG_DATA) public data: UsersData
  ) {
    // console.log(data);
    this.businessUserData = { ...data };
    this.createBusinessUserForm();
    this.addBusinessUserForm.patchValue({
      userId: this.businessUserData.userId,
    });
    // console.log(this.roleByIdDetails)
  }
  addBusinessUserForm!: FormGroup;
  businessUserData: any;
  ngOnInit(): void {}
  createBusinessUserForm() {
    const updateby = localStorage.getItem('displayName');
    this.addBusinessUserForm = this.fb.group({
      userId: 0,
      businessName: new FormControl('', Validators.required),
      businessAccountNumber: new FormControl('', Validators.required),
      isBusinessUser: true,
      updatedBy: new FormControl(updateby, Validators.required),
    });
  }
  updateBusinessUser() {
    this.indentityService
      .updateBusinessUser(this.addBusinessUserForm.value)
      .subscribe((data: any) => {
        if ((data.success = true)) {
          this.toster.success('Add Business User Sucessfully');
          this.dialogRef.close([]);
        }
      });
  }
}
