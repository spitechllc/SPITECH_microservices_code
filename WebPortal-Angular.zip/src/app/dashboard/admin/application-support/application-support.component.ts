import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { HelpSupportService } from '../../api-service/helpSupport.service';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-application-support',
  templateUrl: './application-support.component.html',
  styleUrls: ['./application-support.component.scss'],
})
export class ApplicationSupportComponent implements OnInit {
  displayedColumns = [
    'applicationSupportId',
    'versionNo',
    'applicationType',

    'versionUpdateDate',
    'applicationFeatures',
    'forcefullyUpdate',
    'action',
  ];
  dataSource = new MatTableDataSource<PromotionTable>([]);
  applicationSupportForm!: FormGroup;

  get f() {
    return this.applicationSupportForm.controls;
  }
  submitted: boolean = false;
  cashBackEvent: any = [];

  sortBy: string = '';
  sortOrder: string = '';
  claimIdArray: any;
  constructor(
    private fb: FormBuilder,
    private toster: ToastrService,
    private helpSupportService: HelpSupportService,
    private spinner: NgxSpinnerService,
    private auth: AuthService
  ) {}
  todayDates: any;
  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.createForm();
    this.getApplicationSupport();
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  createForm() {
    this.applicationSupportForm = this.fb.group({
      applicationSupportId: 0,
      versionNo: new FormControl('', Validators.required),
      applicationFeatures: new FormControl('', Validators.required),
      applicationType: new FormControl('', Validators.required),
      forcefullyUpdate: false,
    });
  }
  onChangeApplicationType(event: any) {
    this.applicationSupportForm.patchValue({
      applicationType: event,
    });
  }
  onHeaderSortChange(event: any) {
    this.sortBy = event.active;
    this.sortOrder = event.direction;
    this.getApplicationSupport();
  }
  getApplicationSupport() {
    this.helpSupportService
      .getApplicationSupport(
        this.pageIndex,
        this.pageSize,
        this.sortBy,
        this.sortOrder
      )
      .subscribe(
        (data: any) => {
          this.dataSource = new MatTableDataSource(data.data);
          this.total = data.totalCount;
        },
        (err) => {
          if (err.status == 500) {
            this.toster.error('Internal server error');
          }
        }
      );
  }
  submit() {
    this.submitted = true;
    if (this.applicationSupportForm.invalid) return;
    this.addApplicationSupport();
  }
  addApplicationSupport() {
    this.helpSupportService
      .addApplicationSupport(this.applicationSupportForm.value)
      .subscribe(
        (data: any) => {
          if (data.success == true) {
            this.toster.success('Update Application support successfully');
          }
          this.getApplicationSupport();
        },
        (err) => {
          if (err.status == 500) {
            this.toster.error('Internal server error');
          }
          if (err.status == 400) {
            this.toster.error('Bad request');
          }
          if (err.status == 401) {
            this.toster.error('Reasource not found');
          }
        }
      );
  }
  applicationSupportId: number = 0;
  onClickEdit(element: any) {
    // console.log(element.applicationType);
    this.applicationSupportId = element.applicationSupportId;
    this.applicationSupportForm.patchValue({
      applicationSupportId: element.applicationSupportId,
      versionNo: element.versionNo,
      applicationFeatures: element.applicationFeatures,
      applicationType: element.applicationType,
      forcefullyUpdate: element.forcefullyUpdate,
    });
  }

  formReset() {
    this.applicationSupportForm.reset();
    this.applicationSupportId = 0;
    this.createForm();
  }

  applicationType: any = [
    { id: 0, name: 'None' },
    { id: 1, name: 'IOS' },
    { id: 2, name: 'Android' },
  ];
  total: any;
  pageSize: number = 50;
  SortOrder = 'asc';
  pageIndex: number = 1;
  pageChanged(event: any) {
    this.pageIndex = event.pageIndex + 1;
    this.pageSize = event.pageSize;
  }
}
export interface PromotionTable {
  promotionId: Number;
  startDate: string;
  endDate: string;
  criteria: string;
  eventName: string;
}
