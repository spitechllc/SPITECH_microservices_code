import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApplicationSupportComponent } from './application-support.component';
import { RouterModule, Routes } from '@angular/router';
import { AdminGuardGuard } from '../../auth/admin-guard.guard';
import { SharedModule } from 'src/app/shared.module';
import { MatCardModule } from '@angular/material/card';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

export const router: Routes = [
  {
    path: '',
    component: ApplicationSupportComponent,
    canActivate: [AdminGuardGuard],
  },
];

@NgModule({
  declarations: [ApplicationSupportComponent],
  imports: [
    CommonModule,
    SharedModule,
    MatCardModule,
    FormsModule,

    ReactiveFormsModule,

    RouterModule.forChild(router),
  ],
})
export class ApplicationSupportModule {}
