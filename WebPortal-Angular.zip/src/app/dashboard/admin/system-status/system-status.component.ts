import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { debounce } from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ExcelService } from '../../api-service/excel-servive/excel.service';
import { StoreService } from '../../api-service/storeService';
import { AuthService } from '../../auth/auth.service';
import { SharedService } from '../../auth/shared.service';
import { StoreExcelExportComponent } from '../store/store-tab/store-excel-export/store-excel-export.component';

@Component({
  selector: 'app-system-status',
  templateUrl: './system-status.component.html',
  styleUrls: ['./system-status.component.scss'],
})
export class SystemStatusComponent implements OnInit {
  systemStatus!: boolean;
  companyName!: string;
  comapnyDetals: any;

  totalCount = 0;
  pageIndex = 1;
  pageSize = 50;
  sortBy = '';
  sortOrder: string = '';
  siteId: any;
  storeId: number = 0;
  storeName: string = '';
  heatBeat: number = 300;
  siteID: string = '';
  company: string = '';
  city: string = '';
  zipCode: string = '';
  storeObj: any = [];
  systemStatusDetails: any;
  total: any;
  show: boolean = false;

  displayedColumns = [
    'siteId',
    'CompanyName',
    'storeName',
    'lastHeartBeatTime',
    'createdOn',
    'status',
  ];
  dataSource = new MatTableDataSource<TableElement>([]);

  store: any;
  CompanyName: string = '';
  paramData: any;
  allStoreData: any = [];
  phones: any;
  number: any;
  emails: any;
  addressline1: any;
  addressline2: any;
  City: any;
  state: any;
  country: any;
  ZipCode: any;
  StateName: string = '';
  claimIdArray: any;
  constructor(
    private storeService: StoreService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private activetedRoute: ActivatedRoute,
    private toster: ToastrService,
    private excelService: ExcelService,
    private authService: AuthService,
    private sharedService: SharedService,
    private dialog: MatDialog
  ) {}
  roles: any = [];
  userDetails: any = {};
  userId: any;
  companyIds: any = [];
  ngOnInit(): void {
    const claim = this.authService.getClaims();
    this.claimIdArray = claim;
    this.roles = this.authService.getRols();
    // this.spinner.show();
    // this.storeService.getCompanyWithPagging().subscribe((data: any) => {
    //   this.totalCount = data.totalCount;
    //   this.pageSize = this.totalCount;

    //   if (this.totalCount) {
    //     this.storeService
    //       .getCompanyByWithPagging(
    //         this.pageIndex,
    //         this.pageSize,
    //         this.CompanyName
    //       )
    //       .subscribe((data: any) => {

    //         this.comapnyDetals = data.data;

    //         this.spinner.hide();
    //       });
    //   }
    // });
    this.activetedRoute.queryParamMap.subscribe((data: any) => {
      this.paramData = data.params;
    });
    if (this.paramData.data == 'true') {
      this.pageIndex = this.paramData.pageIndex;
      this.pageSize = this.paramData.pageSize;
      this.CompanyName = this.paramData.search;
      this.company = this.paramData.company ? this.paramData.company : '';
      this.storeName = this.paramData.storeName ? this.paramData.storeName : '';
      this.getStoreWithPaging();
    }
    // this.getStoreWithPaging();
    this.tenantData = this.sharedService.tenantData;
    this.sharedService.userDataStore.subscribe((data: any) => {
      this.userDetails = data;
      console.log(this.userDetails);
      this.userId = this.userDetails.userId;
    });
    if (this.roles.includes('SuperAdmin')) {
      this.getStoreWithPaging();
    } else if (this.roles.includes('StoreOwner')) {
      const pageIndex = 1;
      const pageSize = 50;
      this.storeService
        .getAllCompanyByStoreOwner(this.userId)
        .subscribe((data: any) => {
          this.companyIds.push(data.companyIds);
          this.storeService
            .getAllStoreByCompanyIds({
              companyIds: this.companyIds[0],
              pageIndex: pageIndex,
              pageSize: pageSize,
              sortBy: this.sortBy,
              sortOrder: this.sortOrder,
            })
            .subscribe((data: any) => {
              // console.log(data);
              // const stores = data.data
              // this.allStore = data.data;
              this.dataSource = new MatTableDataSource(data.data);
              // this.selectedStore.push(storeId);
              // this.dataSource = new MatTableDataSource(data.data);
            });
        });

      // this.getStoreWithPaging();
    }
  }
  tenantData: any;
  tenantId: number = 0;
  onClickTenant(value: any) {
    this.tenantId = value;
    this.getStoreWithPaging();
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  timeZoneName: any = [];
  time: any;
  timeZone() {
    this.storeService.getTimeZone().subscribe((data: any) => {
      this.timeZoneName = data.data;
    });
  }

  getTimeZone(id: any) {
    this.timeZoneName.filter((t: any) => {
      if (t.timeZoneId == id) {
        this.time = t.timeZoneName;
        return t.timeZoneName;
      }
    });
  }

  exportAsExcel() {
    var pageIndex = 0;
    var pageSize = 0;
    this.storeService
      .getStoreWithPaging(
        pageIndex,
        pageSize,
        this.sortOrder,
        this.sortBy,
        this.storeId,
        this.storeName,
        this.siteID,
        this.company,
        this.posStatus,
        this.heatBeat,
        this.city,
        this.zipCode,
        this.StateName,
        this.tenantId
      )
      .subscribe((data: any) => {
        // console.log(data);
        this.allStoreData = data.data;
        const dialogRef = this.dialog.open(StoreExcelExportComponent, {
          width: '450px',
          panelClass: 'popup',
          data: this.allStoreData,
        });
        // if (this.allStoreData.length > 0) {
        //   this.excelService.exportAsExcelFile(
        //     this.allStoreData.map((s: any) => {
        //       this.getTimeZone(s.timeZoneId);
        //       return {
        //         'Site Id': s.siteId,
        //         StoreId: s.storeId,
        //         'Store Name': s.storeName,
        //         'Company Name': s.company,
        //         CreatedOn: s.createdOn,
        //         'TimeZone Name': this.time,
        //         'Manger Name': s.mangerName,
        //         'Regional Manager Name': s.regionalManagerName,
        //         'Pos Name': s.posName,
        //         'Sale Agent Name': s.saleAgentName,
        //         'Mobile Number': s.phones.map((p: any) => {
        //           // console.log(p.number);
        //           this.number = p.number;
        //           return { MobileNumber: p.number };
        //         })
        //           ? this.number
        //           : '',
        //         Email: s.emails.map((e: any) => {
        //           this.emails = e.email;
        //           return { email: e.email };
        //         })
        //           ? this.emails
        //           : '',
        //         AddressLine1: s.addresses.map((a: any) => {
        //           this.addressline1 = a.addressLine1;
        //           this.city = a.city;
        //           this.state = a.state;
        //           (this.country = a.country), (this.zipCode = a.zipCode);
        //           this.addressline2 = a.addressLine2;
        //           return {};
        //         })
        //           ? this.addressline1
        //           : '',

        //         AddressLine2: this.addressline2,
        //         City: this.City,
        //         State: this.state,
        //         Country: this.country,
        //         'Zip Code': this.ZipCode,
        //       };
        //     }),
        //     'system-ststus'
        //   );
        // } else {
        //   this.toster.error('Data not found');
        // }
      });
  }

  getCompanyByWithPagging() {}
  onChangeStore(company: any) {
    let id = company.id;

    this.companyName = company.name;

    if (id) {
      this.storeService.getStoreByCompanyId(id).subscribe((data: any) => {
        this.store = data.data;
      });
    }
  }

  onChangeStoreId(storeDetails: any) {
    this.dataSource = new MatTableDataSource([storeDetails]);
    this.siteId = storeDetails.siteId;
    this.systemStatus = storeDetails.status;
  }
  posStatus: any;
  onChangePosStatus(event: any) {
    this.sortBy = '';
    this.sortOrder = '';
    this.company = '';
    this.storeName = '';
    // console.log(event);
    if (event == 0) {
      this.posStatus = '';
    } else if (event == 1) {
      this.posStatus = true;
    } else if (event == 2) {
      this.posStatus = false;
    }
    this.getStoreWithPaging();
  }

  onHeaderSortChange(event: any) {
    this.posStatus = '';
    if (event.active == 'createdOn') {
      this.sortBy = 'createdOn';
    } else {
      this.sortBy = event.active;
    }
    if (event.direction == '') {
      this.sortOrder = 'asc';
    } else {
      this.sortOrder = event.direction;
    }

    this.getStoreWithPaging();
  }
  filterByCompanyName = debounce((event) => {
    this.company = event.target.value;
    this.pageIndex = 1;
    this.total = 0;
    this.sortBy = '';
    this.sortOrder = '';
    this.storeName = '';
    this.router.navigate(['/admin/system-status'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        data: 'true',
        company: this.company,
      },
      queryParamsHandling: 'merge',
    });
    this.getStoreWithPaging();
    // debugger;
  }, 1000);

  filterByHeratBeat(event: any) {
    // console.log(event.target.value);
    this.sortBy = '';
    this.sortOrder = '';
    this.company = '';
    this.storeName = '';
    if (event.target.value == '') {
      this.heatBeat = 300;
    } else {
      this.heatBeat = event.target.value;
    }
    this.getStoreWithPaging();
  }
  filterByStoreName = debounce((event) => {
    this.storeName = event.target.value;
    this.pageIndex = 1;
    this.sortBy = '';
    this.sortOrder = '';
    this.company = '';
    this.router.navigate(['/admin/system-status'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        data: 'true',
        storeName: this.storeName,
      },
      queryParamsHandling: 'merge',
    });
    this.getStoreWithPaging();
  }, 1000);

  getStoreWithPaging() {
    this.spinner.show();

    this.storeService
      .getStoreWithPaging(
        this.pageIndex,
        this.pageSize,
        this.sortOrder,
        this.sortBy,
        this.storeId,
        this.storeName,
        this.siteID,
        this.company,
        this.posStatus,
        this.heatBeat,
        this.city,
        this.zipCode,
        this.StateName,
        this.tenantId
      )
      .subscribe(
        (data: any) => {
          this.dataSource = new MatTableDataSource(data.data);

          this.total = data.totalCount;
          this.spinner.hide();
        },
        (err) => {
          console.log(err.error.errors.SortBy);
          if (err.err.error.errors.storeId) {
            err.err.error.errors.storeId.forEach((err: any) => {
              this.toster.error(err);
            });
          }
          if (err.error.errors.SortBy) {
            err.error.errors.SortBy.forEach((err: any) => {
              console.log(err);
              this.toster.error(err);
            });
          }
        }
      );
  }
  // storeArray: any = [
  //   { storeId: 1, storeName: 'store', company: 'c', companyId: 2 },
  // ];
  pageChanged(event: PageEvent) {
    // console.log({ event });
    this.pageIndex = event.pageIndex + 1;
    this.pageSize = event.pageSize;
    this.router.navigate(['/admin/system-status'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        data: 'true',
      },
      queryParamsHandling: 'merge',
    });
    this.getStoreWithPaging();
  }
}

export interface TableElement {
  siteId: number;
  company: string;
  storeName: string;
  createdOn: string;
  status: boolean;

  color: string;
}
