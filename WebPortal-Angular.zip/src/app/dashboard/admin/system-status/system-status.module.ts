import { NgModule } from '@angular/core';
import { SharedModule } from './../../../shared.module';
import { SystemStatusComponent } from './system-status.component';
import { RouterModule, Routes } from '@angular/router';
import { AdminGuardGuard } from '../../auth/admin-guard.guard';

export const router: Routes = [
  {
    path: '',
    component: SystemStatusComponent,
    canActivate: [AdminGuardGuard],
  },
];

@NgModule({
    declarations: [SystemStatusComponent],
    imports: [SharedModule, RouterModule.forChild(router)]
})
export class SystemStatusModule {}
