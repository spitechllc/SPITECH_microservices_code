import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DefaultSaleAgentFeeSetupComponent } from './default-sale-agent-fee-setup.component';

describe('DefaultSaleAgentFeeSetupComponent', () => {
  let component: DefaultSaleAgentFeeSetupComponent;
  let fixture: ComponentFixture<DefaultSaleAgentFeeSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DefaultSaleAgentFeeSetupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DefaultSaleAgentFeeSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
