import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { IdentityService } from '../../api-service/identityService';
import { TransactionService } from '../../api-service/trasation.service';
import { AuthService } from '../../auth/auth.service';
@Component({
  selector: 'app-default-sale-agent-fee-setup',
  templateUrl: './default-sale-agent-fee-setup.component.html',
  styleUrls: ['./default-sale-agent-fee-setup.component.scss'],
})
export class DefaultSaleAgentFeeSetupComponent implements OnInit {
  checked = true;
  storeId: any;
  storeDetails: any;
  paymentMethodDetails: any;
  claimIdArray: any;
  err: string = '';
  defaultSaleAgentFeeForm!: FormGroup;
  paymentConfigurationDetails: any;
  submitted: boolean = false;
  paymentMethod: any;
  defaultSaleAgentFeeData: any;
  storeBillingFeeId: any;
  isActive: boolean = true;
  constructor(
    private fb: FormBuilder,
    private toster: ToastrService,
    private transactionService: TransactionService,
    private auth: AuthService,
    private identityServer: IdentityService
  ) {}
  get f() {
    return this.defaultSaleAgentFeeForm.controls;
  }

  ngOnInit(): void {
    this.getDefaultSaleAgentFee();
    this.createForm();
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
  }

  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  createForm() {
    this.defaultSaleAgentFeeForm = this.fb.group({
      transactionPercentageFee: new FormControl(null, Validators.required),
      monthlySaasFee: new FormControl(null, Validators.required),
      isDefault: true,
    });
  }
  getDefaultSaleAgentFee() {
    this.transactionService
      .getDefaultSaleAgentFeeSetup()
      .subscribe((data: any) => {
        this.defaultSaleAgentFeeData = data.data;
        this.saleAgentFeeId = this.defaultSaleAgentFeeData.saleAgentFeeId;
        this.defaultSaleAgentFeeForm.patchValue({
          transactionPercentageFee:
            this.defaultSaleAgentFeeData.transactionPercentageFee,
          monthlySaasFee: this.defaultSaleAgentFeeData.monthlySaasFee,
          isDefault: this.defaultSaleAgentFeeData.isDefault,
        });
      });
  }

  onClickisActive(event: any) {}
  saleAgentFeeId: any;
  submit() {
    this.submitted = true;
    if (this.defaultSaleAgentFeeForm.invalid) {
      return;
    }
    if (this.saleAgentFeeId > 0) {
      this.updateDefaultSaleAgentFee();
    } else {
      this.addDefaultSaleAgentFee();
    }
  }
  addDefaultSaleAgentFee() {
    this.transactionService
      .saveDefaultSaleAgentFeeSetup(this.defaultSaleAgentFeeForm.value)
      .subscribe((data: any) => {
        this.toster.success('Default Sale Agent fee setup save successfully');
        this.getDefaultSaleAgentFee();
      });
  }
  updateDefaultSaleAgentFee() {
    this.transactionService
      .updateDefaultSaleAgentFeeSetup({
        transactionPercentageFee: this.defaultSaleAgentFeeForm.get(
          'transactionPercentageFee'
        )?.value,
        monthlySaasFee:
          this.defaultSaleAgentFeeForm.get('monthlySaasFee')?.value,
        saleAgentFeeId: this.saleAgentFeeId,
        isActive: true,
      })
      .subscribe((data: any) => {
        this.toster.success('Default Sale Agent fee setup update successfully');
        this.getDefaultSaleAgentFee();
      });
  }
}
