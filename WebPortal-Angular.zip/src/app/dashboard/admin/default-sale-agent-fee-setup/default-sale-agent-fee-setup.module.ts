import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DefaultSaleAgentFeeSetupComponent } from './default-sale-agent-fee-setup.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from 'src/app/shared.module';
import { MatCardModule } from '@angular/material/card';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';
export const router: Routes = [
  {
    path: '',
    component: DefaultSaleAgentFeeSetupComponent,
  },
];

@NgModule({
  declarations: [DefaultSaleAgentFeeSetupComponent],
  imports: [
    CommonModule,
    SharedModule,
    MatCardModule,
    FormsModule,
    MatSnackBarModule,
    ReactiveFormsModule,
    NgxMaterialTimepickerModule,
    RouterModule.forChild(router),
  ],
})
export class DefaultSaleAgentFeeSetupModule {}
