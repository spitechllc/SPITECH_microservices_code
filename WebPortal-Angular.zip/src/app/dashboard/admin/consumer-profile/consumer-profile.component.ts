import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { debounce } from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ExcelService } from '../../api-service/excel-servive/excel.service';
import { IdentityService } from '../../api-service/identityService';
import { AuthService } from '../../auth/auth.service';
import { ConsumersProfileExcelExportComponent } from './consumers-profile-excel-export/consumers-profile-excel-export.component';
import { CreditDebitComponent } from './credit-debit/credit-debit.component';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-consumer-profile',
  templateUrl: './consumer-profile.component.html',
  styleUrls: ['./consumer-profile.component.scss'],
})
export class ConsumerProfileComponent implements OnInit {
  displayedColumns = [
    'userId',
    'firstName',
    'lastName',
    'Mobile',
    'Email',
    'lastTransactionDate',
    'createdDate',
    'device',
    'dob',
    'appName',
    'isActive',

    'action',
  ];
  dataSource = new MatTableDataSource<TableElement>([]);

  constructor(
    private spinner: NgxSpinnerService,
    private identityService: IdentityService,
    private router: Router,
    private auth: AuthService,
    private dailog: MatDialog,
    private activetedRoute: ActivatedRoute,
    private toster: ToastrService,
    private excelService: ExcelService,
    public dialog: MatDialog,
    private fb: FormBuilder,
    private indentityService: IdentityService
  ) {}

  isLoading = false;
  total: number = 0;
  searchEvent: any;
  firstName: string = '';
  mobile: string = '';
  email: string = '';
  Locked: any = null;
  pageIndex: number = 1;
  pageSize: number = 50;
  lastName: string = '';

  pageSizeOptions: number[] = [10, 25, 100, 200];
  loading: boolean = true;
  userId: number = 0;

  sortBy: string = 'userId';
  sortOrder = 'desc';
  claimIdArray: any;
  FirstNameOrEmailOrPhone: string = '';
  err: any;
  consumerData: any = [];
  IsActive: boolean = true;
  paramData: any;
  allConsumerData: any = [];
  ngOnInit(): void {
    this.createForm();
    this.getTenant();
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.activetedRoute.queryParamMap.subscribe((data: any) => {
      this.paramData = data.params;
    });
    if (this.paramData.data == 'true') {
      this.pageIndex = this.paramData.pageIndex;
      this.pageSize = this.paramData.pageSize;
      this.firstName = this.paramData.firstName ? this.paramData.firstName : '';
      this.lastName = this.paramData.lastName ? this.paramData.lastName : '';
      this.mobile = this.paramData.mobile ? this.paramData.mobile : '';
      this.email = this.paramData.email ? this.paramData.email : '';
      this.getConsumers();
    } else {
      this.getConsumers();
    }
  }
  appDetails: any = [];
  getTenant() {
    this.indentityService.getTenantMasterList().subscribe((data: any) => {
      this.appDetails = data;
    });
  }
  // appDetails: any = [
  //   { id: 1, tenantName: 'Velocity' },
  //   { id: 2, tenantName: 'Verifone' },
  //   { id: 3, tenantName: 'Spitech' },
  // ];
  consumerForm!: FormGroup;
  createForm() {
    this.consumerForm = this.fb.group({
      appIds: [[]],
    });
  }
  onClickApp(value: any) {
    const index = this.selctedAppIds.indexOf(value);
    if (index > -1) {
      this.selctedAppIds.splice(index, 1);
    } else {
      this.selctedAppIds.push(value);
    }
  }
  selctedAppIds: any = [];
  onClickSelectAllApp(event: any) {
    // this.showStoreNames = false;
    if (event.isUserInput) {
      if (event.source.selected) {
        this.selctedAppIds = this.appDetails.map((app: any) => app.id);
      } else {
        this.selctedAppIds = [];
      }
      this.consumerForm.get('appIds')?.patchValue(this.selctedAppIds);
      this.getConsumers();
    }
  }
  onClickTenant() {
    this.getConsumers();
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }

  exportAsExcel() {
    var pageSize = 0;
    var pageIndex = 0;
    this.identityService
      .getAllConsumerr(
        this.userId,
        this.firstName,
        this.lastName,
        this.email,
        this.mobile,
        this.Locked,
        pageIndex,
        pageSize,
        this.sortOrder,
        this.sortBy,
        this.consumerForm.get('appIds')?.value
      )
      .subscribe((data: any) => {
        this.allConsumerData = data.data;
        const dialogRef = this.dialog.open(
          ConsumersProfileExcelExportComponent,
          {
            width: '450px',
            panelClass: 'popup',
            data: this.allConsumerData,
          }
        );
      });
  }

  onChange(event: any) {
    this.searchEvent = event;
    this.sortBy = '';
    this.sortOrder = '';
    if (event == 0) {
      this.firstName = '';
      this.email = '';
      this.lastName = '';
      this.mobile = '';
      (this.userId = 0), (this.searchEvent = 0);
      this.router.navigate(['/consumer-profile'], {
        queryParams: {
          pageIndex: this.pageIndex,
          pageSize: this.pageSize,

          searchEvent: (this.searchEvent = 0),
          data: 'true',
          firstName: (this.firstName = ''),
          email: (this.email = ''),
          lastName: (this.lastName = ''),
          mobile: (this.mobile = ''),
        },
        queryParamsHandling: 'merge',
      });

      this.getConsumers();
    }
  }

  filterByuserId = debounce(($event: any) => {
    if ($event.target.value == '') {
      this.userId = 0;
    } else {
      this.userId = $event.target.value;
    }
    this.pageIndex = 1;

    this.router.navigate(['/consumer-profile'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        searchEvent: this.searchEvent,
        data: 'true',
        userId: this.userId,
        email: (this.email = ''),
        firstName: (this.firstName = ''),
        lastName: (this.lastName = ''),
        mobile: (this.mobile = ''),
      },
      queryParamsHandling: 'merge',
    });

    this.getConsumers();
  }, 1000);

  filterByName = debounce(($event: any) => {
    this.firstName = $event.target.value;
    this.pageIndex = 1;

    this.router.navigate(['/consumer-profile'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        searchEvent: this.searchEvent,
        data: 'true',

        firstName: this.firstName,
        userId: (this.userId = 0),
        lastName: (this.lastName = ''),
        mobile: (this.mobile = ''),
        email: (this.email = ''),
      },
      queryParamsHandling: 'merge',
    });

    this.getConsumers();
  }, 1000);

  filterByMobile = debounce(($event: any) => {
    this.mobile = $event.target.value;
    this.pageIndex = 1;

    this.router.navigate(['/consumer-profile'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        searchEvent: this.searchEvent,
        data: 'true',
        mobile: this.mobile,
        userId: (this.userId = 0),
        firstName: (this.firstName = ''),
        email: (this.email = ''),
        lastName: (this.lastName = ''),
      },
      queryParamsHandling: 'merge',
    });

    this.getConsumers();
  }, 1000);

  filterByEmail = debounce(($event: any) => {
    this.email = $event.target.value;
    this.pageIndex = 1;
    this.total = 0;

    this.router.navigate(['/consumer-profile'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        searchEvent: this.searchEvent,
        data: 'true',
        email: this.email,
        userId: (this.userId = 0),
        mobile: (this.mobile = ''),
        firstName: (this.firstName = ''),

        lastName: (this.lastName = ''),
      },
      queryParamsHandling: 'merge',
    });

    this.getConsumers();
  }, 1000);

  filterByLastName = debounce(($event: any) => {
    this.lastName = $event.target.value;
    this.pageIndex = 1;

    this.router.navigate(['/consumer-profile'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        data: 'true',
        searchEvent: this.searchEvent,
        lastName: this.lastName,
        userId: (this.userId = 0),
        mobile: (this.mobile = ''),
        firstName: (this.firstName = ''),
        email: (this.email = ''),
      },
      queryParamsHandling: 'merge',
    });

    this.getConsumers();
  }, 1000);
  onHeaderSortChange(event: any) {
    this.sortBy = event.active;
    this.sortOrder = event.direction;
    this.getConsumers();
  }
  getConsumers() {
    this.identityService
      .getAllConsumerr(
        this.userId,
        this.firstName,
        this.lastName,
        this.email,
        this.mobile,
        this.Locked,
        this.pageIndex,
        this.pageSize,
        this.sortOrder,
        this.sortBy,
        this.consumerForm.get('appIds')?.value
      )
      .subscribe(
        (data: any) => {
          this.consumerData = data;
          this.dataSource = new MatTableDataSource(this.consumerData.data);
          this.total = this.consumerData.totalCount;
        },
        (err) => {
          if (err.status == 400) {
            this.toster.error('Bad request status:400');
          }
          if (err.error.errors.UserId) {
            err.error.errors.UserId.forEach((err: any) => {
              this.toster.error(err);
            });
          }
        }
      );
  }
  onClickLockUnlock(value: any) {
    if (value == 0) {
      this.Locked = null;
    } else if (value == 1) {
      this.Locked = true;
    } else if (value == 2) {
      this.Locked = false;
    }
    this.getConsumers();
  }
  lockUnlock(userId: any) {
    this.identityService
      .lockUnlock({ userId: userId })
      .subscribe((data: any) => {
        this.toster.success('Unlock User Successfully');
        this.getConsumers();
      });
  }
  pageChanged(event: PageEvent) {
    this.pageIndex = event.pageIndex + 1;
    this.pageSize = event.pageSize;
    this.router.navigate(['/consumer-profile'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        data: 'true',
      },
      queryParamsHandling: 'merge',
    });
    this.getConsumers();
  }
}

export interface TableElement {
  userId: string;
  firstName: string;
  lastName: string;
  email: string;
  mobileNumber: string;
  createdOn: string;

  action: string;
}
