import { Component, Inject, LOCALE_ID, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
import { SubSink } from 'subsink';
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
} from '@angular/material/core';
import { MatDatepicker } from '@angular/material/datepicker';
import * as _moment from 'moment';
// tslint:disable-next-line:no-duplicate-imports
import { default as _rollupMoment, Moment } from 'moment';
import { DatePipe, formatDate } from '@angular/common';
import { StoreService } from 'src/app/dashboard/api-service/storeService';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from 'src/app/dashboard/auth/auth.service';
const moment = _rollupMoment || _moment;

// See the Moment.js docs for the meaning of these formats:
// https://momentjs.com/docs/#/displaying/format/
export const MY_FORMATS = {
  parse: {
    dateInput: 'MM-DD-YYYY',
  },
  display: {
    dateInput: 'MM-DD-YYYY',
    monthYearLabel: 'MMM  YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM  YYYY',
  },
};
@Component({
  selector: 'app-edit-consumer',
  templateUrl: './edit-consumer.component.html',
  styleUrls: ['./edit-consumer.component.scss'],
  providers: [DatePipe],
  // providers: [
  //   {
  //     provide: DateAdapter,
  //     useClass: MomentDateAdapter,
  //     deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
  //   },

  //   { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  // ],
})
export class EditConsumerComponent implements OnInit {
  consumerForm!: FormGroup;
  subs = new SubSink();
  userId: any = null;
  submitted: boolean = false;
  countries: any = [];
  state: any;
  claimIdArray: any;
  consumersDetails: any;
  get f() {
    return this.consumerForm.controls;
  }

  constructor(
    private fb: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private identityService: IdentityService,
    private toster: ToastrService,
    private datePipe: DatePipe,
    private storeService: StoreService,
    private spinner: NgxSpinnerService,
    private auth: AuthService
  ) {}

  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.createConsumerForm();
    this.getUserId();
    this.getCountry();
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  getCountry() {
    this.storeService.getCountry().subscribe((data: any) => {
      this.countries = data.data;
    });
  }
  onChangeCountry(countryId: any) {
    // console.log(countryId);
    if (countryId) {
      this.storeService.getStates(countryId).subscribe((data: any) => {
        this.state = data.data;
      });
    } else {
      this.state = null;
    }
  }
  getUserId() {
    this.subs.add(
      this.activatedRoute.paramMap.subscribe((params) => {
        this.userId = params.get('userId');
        // console.log(this.userId);
        if (this.userId) {
          this.getUserDetails(this.userId);
        }
      })
    );
  }

  getUserDetails(id: any) {
    this.spinner.show();
    this.subs.add(
      this.identityService.getConsumerById(id).subscribe(
        (data: any) => {
          this.consumersDetails = data.data;
          // console.log(data, 'user details');

          this.setFormValue(data.data);
          this.spinner.hide();
        },
        (err: any) => {
          if (err.status == 500) {
            this.toster.error('Internal server error Status:500');
            this.spinner.hide();
          }
        }
      )
    );
  }
  dob: any;
  date: any;
  setFormValue(data: any) {
    (this.dob = data.dob),
      (this.date = this.datePipe.transform(this.dob, 'MM-dd-yyyy'));
    this.consumerForm.patchValue({
      userId: data.userId,
      isActive: data.isActive,
      firstName: data.firstName,
      lastName: data.lastName,
      email: data.email,
      mobileCountryCode: data.mobileCountryCode,
      mobileNumber: data.mobileNumber,
      addressLine1: data.userProfile.addressLine1,
      addressLine2: data.userProfile.addressLine2,
      country: data.userProfile.country,
      countryCode: data.userProfile.countryCode,
      state: data.userProfile.state,
      city: data.userProfile.city,
      longitude: data.userProfile.longitude,
      latitude: data.userProfile.latitude,
      zipCode: data.userProfile.zipCode,
      companyId: data.userProfile.companyId,
      company: data.userProfile.company,
      storeId: data.userProfile.storeId,
      store: data.userProfile.store,
      photoUrlbase64: data.userProfile.photoUrlbase64,
      dob: this.dob,
      deviceToken: data.deviceToken,
      deviceType: data.deviceType,
      mobileAppType: data.mobileAppType,
      roleIds: data.roles,
    });
  }
  checked = true;
  createConsumerForm() {
    this.consumerForm = this.fb.group({
      userId: new FormControl(0),
      isActive: true,
      firstName: new FormControl(''),
      lastName: new FormControl(''),
      email: new FormControl(''),
      mobileCountryCode: new FormControl(''),
      mobileNumber: new FormControl(''),
      addressLine1: new FormControl(''),
      addressLine2: new FormControl(''),
      country: new FormControl(''),
      countryCode: new FormControl(''),
      state: new FormControl(''),
      city: new FormControl(''),
      longitude: new FormControl(''),
      latitude: new FormControl(''),
      zipCode: new FormControl(''),
      companyId: new FormControl(0),
      company: new FormControl(''),
      storeId: new FormControl(0),
      store: new FormControl(''),
      photoUrlbase64: new FormControl(''),
      dob: new FormControl('02-02-1996'),
      deviceToken: new FormControl(''),
      deviceType: new FormControl(0),
      mobileAppType: 'None',
      roleIds: [],
    });
  }
  dateEvent: any;
  onClickDate(event: any) {
    // console.log(event.target.value);
    this.dateEvent = event;
    this.date = this.datePipe.transform(
      this.dateEvent.target.value,
      'MM-dd-yyyy'
    );
  }
  updateConsumer() {
    this.submitted = true;
    this.identityService
      .updateConsumerProfile({
        ...this.consumerForm.value,
        dob: this.dateEvent ? this.date : this.date,
      })
      .subscribe((data: any) => {
        this.toster.success('Update profile successfully');
      });
  }
}
