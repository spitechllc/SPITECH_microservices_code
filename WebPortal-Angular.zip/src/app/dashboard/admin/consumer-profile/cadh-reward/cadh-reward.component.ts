import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { ActivatedRoute } from '@angular/router';
import { FinanceService } from 'src/app/dashboard/api-service/finance.service';
import { SubSink } from 'subsink';
import { CreditDebitComponent } from '../credit-debit/credit-debit.component';

@Component({
  selector: 'app-cadh-reward',
  templateUrl: './cadh-reward.component.html',
  styleUrls: ['./cadh-reward.component.scss'],
})
export class CadhRewardComponent implements OnInit {
  // displayedColumns: string[] = [
  //   'Name',
  //   'TotalPoints',
  //   'SharePoints',
  //   'RequestedPoints',
  // ];
  // dataSource = new MatTableDataSource(ELEMENT_DATA);

  constructor(
    public dialog: MatDialog,
    private financeService: FinanceService,
    private activatedRoute: ActivatedRoute,
    private _location: Location
  ) {}
  rewardDetails: any;
  subs = new SubSink();
  userId: any = null;
  PageSize: number = 50;
  PageIndex: number = 1;
  totalCount: any;
  ngOnInit(): void {
    this.getUserId();
  }
  getUserId() {
    this.subs.add(
      this.activatedRoute.paramMap.subscribe((params) => {
        this.userId = params.get('userId');

        if (this.userId) {
          this.getRewards();
          this.getWalletHistory();
          this.getRewardsData();
        }
      })
    );
  }
  getRewards() {
    this.financeService
      .getUserWalletList(this.userId)
      .subscribe((data: any) => {
        this.rewardDetails = data.data;
      });
  }
  rewadsData: any;
  getRewardsData() {
    this.financeService
      .getUserWalletData(this.userId)
      .subscribe((data: any) => {
        this.rewadsData = data.data;
      });
  }
  cashBack(action: any, obj: any) {
    obj.action = action;
    const dialogRef = this.dialog.open(CreditDebitComponent, {
      width: '500px',
      panelClass: 'popup',
      data: obj,
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.getRewards();
      this.getWalletHistory();
    });
  }
  walletHistoryData: any = [];
  length: any;
  getWalletHistory() {
    this.financeService
      .getWalletHistory(this.userId, this.PageIndex, this.PageSize)
      .subscribe((data: any) => {
        this.walletHistoryData = data.data;
        this.length = this.walletHistoryData.length;
        // console.log(this.length);
        this.totalCount = data.totalCount;
      });
  }

  pageChanged(event: PageEvent) {
    this.PageIndex = event.pageIndex + 1;
    this.PageSize = event.pageSize;
    this.getWalletHistory();
  }

  onClickBack() {
    this._location.back();
  }
}
