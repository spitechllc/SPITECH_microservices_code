import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CadhRewardComponent } from './cadh-reward.component';

describe('CadhRewardComponent', () => {
  let component: CadhRewardComponent;
  let fixture: ComponentFixture<CadhRewardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CadhRewardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CadhRewardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
