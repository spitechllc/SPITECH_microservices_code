import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConsumerProfileComponent } from './consumer-profile.component';
import { SharedModule } from 'src/app/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { EditConsumerComponent } from './edit-consumer/edit-consumer.component';
import { CreditDebitComponent } from './credit-debit/credit-debit.component';
import { UpdateConsumerComponent } from './update-consumer/update-consumer.component';
import { ConsumerTransactionHistoryComponent } from './consumer-transaction-history/consumer-transaction-history.component';
import { CadhRewardComponent } from './cadh-reward/cadh-reward.component';
import { MatCardModule } from '@angular/material/card';
import { NgxMaskModule, IConfig } from 'ngx-mask';
import { ConsumersProfileExcelExportComponent } from './consumers-profile-excel-export/consumers-profile-excel-export.component';
import { PaymentmethodComponent } from './paymentmethod/paymentmethod.component';
export const options: Partial<null | IConfig> | (() => Partial<IConfig>) = null;
export const router: Routes = [
  { path: '', component: ConsumerProfileComponent },
  { path: 'edit-consumer/:userId', component: EditConsumerComponent },
];

@NgModule({
  declarations: [
    ConsumerProfileComponent,
    EditConsumerComponent,
    CreditDebitComponent,
    UpdateConsumerComponent,
    ConsumerTransactionHistoryComponent,
    CadhRewardComponent,
    ConsumersProfileExcelExportComponent,
    PaymentmethodComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    ReactiveFormsModule,
    MatCardModule,
    FormsModule,
    NgxMaskModule.forRoot({
      showMaskTyped: true,
      // clearIfNotMatch : true
    }),
    RouterModule.forChild(router),
  ],
})
export class ConsumerProfileModule {}
