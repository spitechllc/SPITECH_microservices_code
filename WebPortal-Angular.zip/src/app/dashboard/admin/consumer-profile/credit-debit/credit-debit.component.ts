import { Component, Inject, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { FinanceService } from 'src/app/dashboard/api-service/finance.service';
export interface userData {
  userId: string;
}
@Component({
  selector: 'app-credit-debit',
  templateUrl: './credit-debit.component.html',
  styleUrls: ['./credit-debit.component.scss'],
})
export class CreditDebitComponent implements OnInit {
  cashBackEarn!: FormGroup;
  cashBackReedem!: FormGroup;
  userData: any = {};
  submitted: boolean = false;

  get cf() {
    return this.cashBackEarn.controls;
  }
  get df() {
    return this.cashBackReedem.controls;
  }
  constructor(
    public dialogRef: MatDialogRef<CreditDebitComponent>,
    @Inject(MAT_DIALOG_DATA) public data: userData,
    private fb: FormBuilder,
    private financeService: FinanceService,
    private toster: ToastrService
  ) {
    // console.log(data);
    this.userData = data;
    // console.log(this.userData.userId);
  }

  ngOnInit(): void {
    this.cashBachEarnForm();
    this.cashBackReedemForm();
  }

  cashBachEarnForm() {
    this.cashBackEarn = this.fb.group({
      userId: new FormControl(this.userData[0].userId),
      creditAmount: new FormControl(
        null,
        Validators.compose([
          Validators.required,
          Validators.pattern('[- +()0-9]+'),
        ])
      ),
      creditReason: new FormControl('', Validators.required),
    });
  }
  cashBackReedemForm() {
    this.cashBackReedem = this.fb.group({
      userId: new FormControl(this.userData[0].userId),
      debitAmount: new FormControl(
        null,
        Validators.compose([
          Validators.required,
          Validators.pattern('[- +()0-9]+'),
          ,
        ])
      ),
      debitReason: new FormControl('', Validators.required),
    });
  }

  creditCashEarn() {
    this.submitted = true;
    if (this.cashBackEarn.invalid) {
      return;
    }
    this.financeService
      .cashBackCredit(this.cashBackEarn.value)
      .subscribe((data: any) => {
        this.toster.success('Succesfully credit amount');
        this.dialogRef.close([]);
      });
  }

  debitCashBackReedim() {
    this.submitted = true;
    if (this.cashBackReedem.invalid) {
      return;
    }
    this.financeService
      .cashBackDebit(this.cashBackReedem.value)
      .subscribe((data: any) => {
        this.toster.success('Succesfully debit amount');
        this.dialogRef.close([]);
      });
  }
}
