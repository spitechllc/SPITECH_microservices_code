import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsumerTransactionHistoryComponent } from './consumer-transaction-history.component';

describe('ConsumerTransactionHistoryComponent', () => {
  let component: ConsumerTransactionHistoryComponent;
  let fixture: ComponentFixture<ConsumerTransactionHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsumerTransactionHistoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsumerTransactionHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
