import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { debounce } from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ReportsService } from 'src/app/dashboard/api-service/report.service';
import { ReceiptDataComponent } from 'src/app/dashboard/consumer/history/receipt-data/receipt-data.component';
import { PrintInfoComponent } from 'src/app/dashboard/transaction/search-consumer/print-info/print-info.component';
import { SubSink } from 'subsink';

@Component({
  selector: 'app-consumer-transaction-history',
  templateUrl: './consumer-transaction-history.component.html',
  styleUrls: ['./consumer-transaction-history.component.scss'],
})
export class ConsumerTransactionHistoryComponent implements OnInit {
  displayedColumns = [
    'transactionId',
    'storeName',
    'storeAddress',
    'receiptDate',
    'posTransNumber',
    'action',
  ];
  dataSource = new MatTableDataSource<TransactionHistory>([]);

  constructor(
    private reportService: ReportsService,
    private toster: ToastrService,
    public dialog: MatDialog,
    private activatedRoute: ActivatedRoute,
    private _location: Location,
    private spinner: NgxSpinnerService
  ) {}
  TransationHistoryDetails: any;
  userId: any;
  totalCount = 0;
  PageIndex = 1;
  PageSize = 50;
  SortBy: string = '';
  SortOrder = 'asc';
  Storename: string = '';
  subs = new SubSink();
  length: number = 0;
  ngOnInit(): void {
    this.getUserId();
  }
  getUserId() {
    this.subs.add(
      this.activatedRoute.paramMap.subscribe((params) => {
        this.userId = params.get('userId');
        // console.log(this.userId);
        if (this.userId) {
          this.getTransationHistory();
        }
      })
    );
  }

  searchTransaction = debounce((event: any) => {
    this.Storename = event.target.value;
    this.getTransationHistory();
  }, 1000);

  getTransationHistory() {
    this.spinner.show();
    this.reportService
      .getConsumerTransationHistory(
        this.userId,
        this.Storename,
        this.PageIndex,
        this.PageSize,
        this.SortBy,
        this.SortOrder
      )
      .subscribe(
        (data: any) => {
          this.TransationHistoryDetails = data.data;
          // console.log(this.TransationHistoryDetails.length);
          this.length = this.TransationHistoryDetails.length;
          this.totalCount = data.totalCount;
          // console.log(this.TransationHistoryDetails);
          this.dataSource = new MatTableDataSource(
            this.TransationHistoryDetails.data
          );
          this.spinner.hide();
        },
        (err) => {
          // console.log(err);
          if (err.status == 500) {
            this.toster.error('Internal Server errors   status:500');
          }
          // this.toster.error(err.message);
        }
      );
  }
  filterdata($event: any) {
    this.PageIndex = 1;
    this.Storename = $event.target.value;
    this.getTransationHistory();
  }
  onClickBack() {
    this._location.back();
  }
  pageChanged(event: PageEvent) {
    this.PageIndex = event.pageIndex + 1;
    this.PageSize = event.pageSize;
    this.getTransationHistory();
  }
  pdfPopup(action: any, obj: any) {
    obj.action = action;
    const dialogRef = this.dialog.open(PrintInfoComponent, {
      width: '450px',
      panelClass: 'popup',
      data: obj,
    });
  }
  throttle = 300;
  scrollDistance = 1;
  scrollUpDistance = 2;
  direction = '';
  modalOpen = false;
  onScroll() {
    console.log('scrolled!!');
  }
  onScrollDown(ev: any) {
    console.log('scrolled down!!', ev);
  }

  onUp(ev: any) {
    console.log('scrolled up!', ev);
  }
}
export interface TransactionHistory {
  transactionId: number;
  storeName: string;
  storeAddress: string;
  receiptDate: string;
  posTransNumber: string;
}
