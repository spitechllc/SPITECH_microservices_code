import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormControlName, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
import { SubSink } from 'subsink';

import * as _moment from 'moment';

import { default as _rollupMoment, Moment } from 'moment';
import { DatePipe, formatDate, Location } from '@angular/common';
import { StoreService } from 'src/app/dashboard/api-service/storeService';
import { NgxSpinnerService } from 'ngx-spinner';
const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'MM-DD-YYYY',
  },
  display: {
    dateInput: 'MM-DD-YYYY',
    monthYearLabel: 'MMM  YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM  YYYY',
  },
};
@Component({
  selector: 'app-update-consumer',
  templateUrl: './update-consumer.component.html',
  styleUrls: ['./update-consumer.component.scss'],
  providers: [DatePipe],
})
export class UpdateConsumerComponent implements OnInit {
  consumerForm!: FormGroup;
  subs = new SubSink();
  userId: any = null;
  submitted: boolean = false;
  countries: any = [];
  state: any;
  get f() {
    return this.consumerForm.controls;
  }

  constructor(
    private fb: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private identityService: IdentityService,
    private toster: ToastrService,
    private datePipe: DatePipe,
    private storeService: StoreService,
    private spinner: NgxSpinnerService,
    private _location: Location
  ) {}

  ngOnInit(): void {
    this.createConsumerForm();
    this.getUserId();
    this.getCountry();
  }
  getCountry() {
    this.storeService.getCountry().subscribe((data: any) => {
      this.countries = data.data;
    });
  }
  countryCode: any;
  countryChange(value: any) {
    this.countryCode = value;
  }
  onChangeCountry(countryId: any) {
    if (countryId) {
      this.storeService.getStates(countryId).subscribe((data: any) => {
        this.state = data.data;
      });
    } else {
      this.state = null;
    }
  }
  getUserId() {
    this.subs.add(
      this.activatedRoute.paramMap.subscribe((params) => {
        this.userId = params.get('userId');
        if (this.userId) {
          this.getUserDetails(this.userId);
        }
      })
    );
  }
  getUserDetails(id: any) {
    this.spinner.show();
    this.subs.add(
      this.identityService.getConsumerById(id).subscribe(
        (data: any) => {
          this.setFormValue(data.data);
          this.spinner.hide();
        },
        (err: any) => {
          if (err.status == 500) {
            this.toster.error('Internal server error Status:500');
            this.spinner.hide();
          }
        }
      )
    );
  }
  dob: any;
  date: any;
  setFormValue(data: any) {
    (this.dob = data.dob),
      (this.date = this.datePipe.transform(this.dob, 'MM-dd-yyyy'));
    this.consumerForm.patchValue({
      userId: data.userId,
      isActive: data.isActive,
      firstName: data.firstName,
      lastName: data.lastName,
      email: data.email,
      mobileCountryCode: data.mobileCountryCode,
      mobileNumber: data.mobileNumber,
      gender: data.userProfile.gender,
      addressLine1: data.userProfile.addressLine1,
      addressLine2: data.userProfile.addressLine2,
      country: data.userProfile.country,
      countryCode: data.userProfile.countryCode,
      state: data.userProfile.state,
      city: data.userProfile.city,
      longitude: data.userProfile.longitude,
      latitude: data.userProfile.latitude,
      zipCode: data.userProfile.zipCode,
      companyId: data.userProfile.companyId,
      company: data.userProfile.company,
      storeId: data.userProfile.storeId,
      store: data.userProfile.store,
      photoUrlbase64: data.userProfile.photoUrlbase64,
      dob: this.dob,
      deviceToken: data.deviceToken,
      deviceType: data.deviceType,
      mobileAppType: data.mobileAppType,
      roleIds: data.roles,
    });
  }
  checked = true;
  createConsumerForm() {
    this.consumerForm = this.fb.group({
      userId: new FormControl(0),
      isActive: true,
      firstName: new FormControl(''),
      lastName: new FormControl(''),
      email: new FormControl(''),
      mobileCountryCode: new FormControl(''),
      mobileNumber: new FormControl(''),
      gender: new FormControl(''),
      addressLine1: new FormControl(''),
      addressLine2: new FormControl(''),
      country: new FormControl(''),
      countryCode: new FormControl(''),
      state: new FormControl(''),
      city: new FormControl(''),
      longitude: new FormControl(''),
      latitude: new FormControl(''),
      zipCode: new FormControl(''),
      companyId: new FormControl(0),
      company: new FormControl(''),
      storeId: new FormControl(0),
      store: new FormControl(''),
      photoUrlbase64: new FormControl(''),
      dob: new FormControl('02-02-1996'),
      deviceToken: new FormControl(''),
      deviceType: new FormControl(0),
      mobileAppType: 'None',
      roleIds: [],
    });
  }
  dateEvent: any;
  onClickDate(event: any) {
    // console.log(event.target.value);
    this.dateEvent = event;
    this.date = this.datePipe.transform(
      this.dateEvent.target.value,
      'MM-dd-yyyy'
    );
  }
  updateConsumer() {
    this.submitted = true;
    this.identityService
      .updateConsumerProfile({
        ...this.consumerForm.value,
        dob: this.dateEvent ? this.date : this.date,
      })
      .subscribe((data: any) => {
        this.toster.success('Update profile successfully');
      });
  }
  onClickBack() {
    this._location.back();
  }
}