import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsumersProfileExcelExportComponent } from './consumers-profile-excel-export.component';

describe('ConsumersProfileExcelExportComponent', () => {
  let component: ConsumersProfileExcelExportComponent;
  let fixture: ComponentFixture<ConsumersProfileExcelExportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsumersProfileExcelExportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsumersProfileExcelExportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
