import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { ExcelService } from 'src/app/dashboard/api-service/excel-servive/excel.service';

@Component({
  selector: 'app-consumers-profile-excel-export',
  templateUrl: './consumers-profile-excel-export.component.html',
  styleUrls: ['./consumers-profile-excel-export.component.scss'],
})
export class ConsumersProfileExcelExportComponent implements OnInit {
  constructor(
    private excelService: ExcelService,
    public dialogRef: MatDialogRef<ConsumersProfileExcelExportComponent>,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: { data: any }
  ) {
    this.excelData = data;
    // console.log(this.excelData);
  }
  excelData: any;
  userId :boolean=true;
  firstName: boolean = true;
  lastName: boolean = true;

  mobileNumber: boolean = true;

  email: boolean = true;
  addressLine1: boolean = true;
  addressLine2: boolean = true;
  city: boolean = true;
  state: boolean = true;
  zipCode: boolean = true;
  createdOn: boolean = true;
  lastTransactionDate: boolean = true;
  dob: boolean = true;
  totalCreditAmount: boolean = true;
  totalRedeemedAmount: boolean = true;
  totalReceivedAmount: boolean = true;
  totalSharedAmount: boolean = true;
  totalExpiredAmount: boolean = true;

  ngOnInit(): void {}

  onClickChexBox(event: any) {
    
    if (event.source.value == 'userId' && event.checked == false) {
      this.userId = false;
    } else if (event.source.value == 'userId' && event.checked == true) {
      this.userId = true;
    }
    if (event.source.value == 'firstName' && event.checked == false) {
      this.firstName = false;
    } else if (event.source.value == 'firstName' && event.checked == true) {
      this.firstName = true;
    }
    if (event.source.value == 'lastName' && event.checked == false) {
      this.lastName = false;
    } else if (event.source.value == 'lastName' && event.checked == true) {
      this.lastName = true;
    }

    if (event.source.value == 'mobileNumber' && event.checked == false) {
      this.mobileNumber = false;
    } else if (event.source.value == 'mobileNumber' && event.checked == true) {
      this.mobileNumber = true;
    }

    if (event.source.value == 'email' && event.checked == false) {
      this.email = false;
    } else if (event.source.value == 'email' && event.checked == true) {
      this.email = true;
    }
    if (event.source.value == 'addressLine1' && event.checked == false) {
      this.addressLine1 = false;
    } else if (event.source.value == 'addressLine1' && event.checked == true) {
      this.addressLine1 = true;
    }
    if (event.source.value == 'addressLine2' && event.checked == false) {
      this.addressLine2 = false;
    } else if (event.source.value == 'addressLine2' && event.checked == true) {
      this.addressLine2 = true;
    }
    if (event.source.value == 'city' && event.checked == false) {
      this.city = false;
    } else if (event.source.value == 'city' && event.checked == true) {
      this.city = true;
    }
    if (event.source.value == 'state' && event.checked == false) {
      this.state = false;
    } else if (event.source.value == 'state' && event.checked == true) {
      this.state = true;
    }
    if (event.source.value == 'zipCode' && event.checked == false) {
      this.zipCode = false;
    } else if (event.source.value == 'zipCode' && event.checked == true) {
      this.zipCode = true;
    }
    if (event.source.value == 'createdOn' && event.checked == false) {
      this.createdOn = false;
    } else if (event.source.value == 'createdOn' && event.checked == true) {
      this.createdOn = true;
    }
    if (event.source.value == 'createdOn' && event.checked == false) {
      this.createdOn = false;
    } else if (event.source.value == 'createdOn' && event.checked == true) {
      this.createdOn = true;
    }
    if (event.source.value == 'lastTransactionDate' && event.checked == false) {
      this.lastTransactionDate = false;
    } else if (
      event.source.value == 'lastTransactionDate' &&
      event.checked == true
    ) {
      this.lastTransactionDate = true;
    }
    if (event.source.value == 'dob' && event.checked == false) {
      this.dob = false;
    } else if (event.source.value == 'dob' && event.checked == true) {
      this.dob = true;
    }

    if (event.source.value == 'totalCreditAmount' && event.checked == false) {
      this.totalCreditAmount = false;
    } else if (event.source.value == 'totalCreditAmount' && event.checked == true) {
      this.totalCreditAmount = true;
    }

    if (event.source.value == 'totalRedeemedAmount' && event.checked == false) {
      this.totalRedeemedAmount = false;
    } else if (event.source.value == 'totalRedeemedAmount' && event.checked == true) {
      this.totalRedeemedAmount = true;
    }
    if (event.source.value == 'totalExpiredAmount' && event.checked == false) {
      this.totalExpiredAmount = false;
    } else if (event.source.value == 'totalExpiredAmount' && event.checked == true) {
      this.totalExpiredAmount = true;
    }
  }

  excelExport() {
    const excelExportData = this.excelData.map((t: any) => {
      const dataObject: any = {};
      

      if (this.userId == true) {
        dataObject.userId = t.userId;
      }

      if (this.firstName == true) {
        dataObject.firstName = t.firstName;
      }
      if (this.lastName == true) {
        dataObject.lastName = t.lastName;
      }
      if (this.dob == true) {
        dataObject.dob = t.dob;
      }
      if (this.mobileNumber == true) {
        dataObject.mobileNumber = t.mobileNumber;
      }
      if (this.email == true) {
        dataObject.email = t.email;
      }

      if (this.totalCreditAmount == true) {
        dataObject.totalCreditAmount = t.totalCreditAmount;
      }
      if (this.totalRedeemedAmount == true) {
        dataObject.totalRedeemedAmount = t.totalRedeemedAmount;
      }
      if (this.totalExpiredAmount == true) {
        dataObject.totalExpiredAmount = t.totalExpiredAmount;
      }

      
      if (this.addressLine1 == true) {
        dataObject.addressLine1 = t.userProfile.addressLine1;
      }
      if (this.addressLine2 == true) {
        dataObject.addressLine2 = t.userProfile.addressLine2;
      }
      if (this.city == true) {
        dataObject.city = t.userProfile.city;
      }
      if (this.state == true) {
        dataObject.state = t.userProfile.state;
      }
      if (this.zipCode == true) {
        dataObject.zipCode = t.userProfile.zipCode;
      }
      if (this.createdOn == true) {
        dataObject.createdOn = t.createdOn;
      }
      if (this.lastTransactionDate == true) {
        dataObject.lastTransactionDate = t.lastTransactionDate;
      }
      return dataObject;
    });

    this.excelService.exportAsExcelFile(
      excelExportData,
      'Consumers-Profile exported-data'
    );
  }
}
