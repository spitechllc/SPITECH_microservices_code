import { Component, OnInit } from '@angular/core';
import { PaymentService } from 'src/app/dashboard/api-service/payment.srvice';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-paymentmethod',
  templateUrl: './paymentmethod.component.html',
  styleUrls: ['./paymentmethod.component.scss']
})
export class PaymentmethodComponent implements OnInit {

  constructor(private paymentService: PaymentService,
              private activatedRoute: ActivatedRoute) { }

  userPaymentTableData: any = [];
  userId: any;
  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe((params) => {
      this.userId = params.get('userId');
      this.getPaymentInfo(this.userId);
    })
  }

  getPaymentInfo(id: any) {
    this.paymentService.getUserPaymentMethodById(id).subscribe(
      (res) => {
        debugger;
        this.userPaymentTableData=res;

      },
      (err: any) => {
        if (err.status == 500) {
        }
      }
    );
  }

}
