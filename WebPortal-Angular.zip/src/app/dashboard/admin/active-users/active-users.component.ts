import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { debounce } from 'lodash';
import { ToastrService } from 'ngx-toastr';
import { IdentityService } from '../../api-service/identityService';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-active-users',
  templateUrl: './active-users.component.html',
  styleUrls: ['./active-users.component.scss'],
})
export class ActiveUsersComponent implements OnInit {
  displayedColumns = [
    'userId',
    'firstName',
    'lastName',
    'loginDateTime',
    'lastAccessTime',
    'activeDuration',
    'action',
  ];
  dataSource = new MatTableDataSource<TableElement>([]);
  constructor(
    private identityService: IdentityService,
    private router: Router,
    private auth: AuthService,
    private toster: ToastrService
  ) {}
  claimIdArray: any;
  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.getAllActiveUsers();
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  pageIndex: number = 1;
  pageSize: number = 50;
  userID: number = 0;
  firstName: string = '';
  lastName: string = '';
  sortBy: string = '';
  sortOrder: string = '';
  total: number = 0;
  getAllActiveUsers() {
    this.identityService
      .getAllActiveUsers(
        this.userID,
        this.firstName,
        this.lastName,
        this.pageIndex,
        this.pageSize,
        this.sortBy,
        this.sortOrder
      )
      .subscribe((data: any) => {
        this.total = data.totalCount;
        this.dataSource = new MatTableDataSource(data.data);
      });
  }
  onChange(event: any) {
    this.searchEvent = event;
    if (event == 0) {
      this.firstName = '';
      this.lastName = '';
      this.userID = 0;
      this.searchEvent = 0;
      this.router.navigate(['admin/active-users'], {
        queryParams: {
          pageIndex: this.pageIndex,
          pageSize: this.pageSize,
          searchEvent: (this.searchEvent = 0),
          data: 'true',
          userID: (this.userID = 0),
          firstName: (this.firstName = ''),
          lastName: (this.lastName = ''),
        },
        queryParamsHandling: 'merge',
      });
      this.getAllActiveUsers();
    }
  }
  searchEvent: any;
  filterByFirstName = debounce(($event: any) => {
    this.firstName = $event.target.value;
    this.pageIndex = 1;
    this.router.navigate(['admin/active-users'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        data: 'true',
        firstName: this.firstName,
        lastName: (this.lastName = ''),
        userID: (this.userID = 0),
      },
      queryParamsHandling: 'merge',
    });
    this.getAllActiveUsers();
  }, 1000);
  filterByLastName = debounce(($event: any) => {
    this.lastName = $event.target.value;
    this.pageIndex = 1;
    this.router.navigate(['admin/active-users'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        data: 'true',
        firstName: (this.firstName = ''),
        lastName: this.lastName,
        userID: (this.userID = 0),
      },
      queryParamsHandling: 'merge',
    });
    this.getAllActiveUsers();
  }, 1000);
  filterByUserID = debounce(($event: any) => {
    this.userID = $event.target.value;
    this.pageIndex = 1;
    this.router.navigate(['admin/active-users'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        data: 'true',
        firstName: (this.firstName = ''),
        lastName: (this.lastName = ''),
        userID: this.userID,
      },
      queryParamsHandling: 'merge',
    });
    this.getAllActiveUsers();
  }, 1000);
  onHeaderSortChange(event: any) {
    this.sortBy = event.active;
    this.sortOrder = event.direction;
    this.getAllActiveUsers();
  }
  pageChanged(event: any) {
    this.pageIndex = event.pageIndex + 1;
    this.pageSize = event.pageSize;
    this.getAllActiveUsers();
  }
  onClickRefresh() {
    this.userID = 0;
    this.firstName = '';
    this.lastName = '';
    this.pageIndex = 1;
    this.pageSize = 50;
  }
  forceLogout(userId: number) {
    console.log(userId);
    this.identityService
      .forcelogout({ userId: userId })
      .subscribe((data: any) => {
        if (data.success == true) {
          this.toster.success('Successfully logout to this user');
          this.getAllActiveUsers();
        }
      });
  }
}
export interface TableElement {
  userId: number;
}
