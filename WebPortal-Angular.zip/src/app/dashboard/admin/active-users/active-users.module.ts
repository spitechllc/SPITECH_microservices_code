import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActiveUsersComponent } from './active-users.component';
import { AdminGuardGuard } from '../../auth/admin-guard.guard';

import { SharedModule } from './../../../shared.module';

import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
export const router: Routes = [
  {
    path: '',
    component: ActiveUsersComponent,
    canActivate: [AdminGuardGuard],
  },
];

@NgModule({
  declarations: [ActiveUsersComponent],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(router),
  ],
})
export class ActiveUsersModule {}
