import { NgModule } from '@angular/core';
import { SharedModule } from './../../../shared.module';
import { StoreComponent } from './store.component';
import { RouterModule, Routes } from '@angular/router';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatTooltipModule } from '@angular/material/tooltip';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CompanyTabComponent } from './company-tab/company-tab.component';
import { StoreTabComponent } from './store-tab/store-tab.component';
import { NgxMaskModule, IConfig } from 'ngx-mask';
import { CompanyExcelExportComponent } from './company-tab/company-excel-export/company-excel-export.component';
import { StoreExcelExportComponent } from './store-tab/store-excel-export/store-excel-export.component';

export const options: Partial<null | IConfig> | (() => Partial<IConfig>) = null;
export const router: Routes = [{ path: '', component: StoreComponent }];

@NgModule({
  declarations: [
    StoreComponent,
    CompanyTabComponent,
    StoreTabComponent,
    CompanyExcelExportComponent,
    StoreExcelExportComponent,
  ],
  imports: [
    SharedModule,
    MatExpansionModule,
    ReactiveFormsModule,

    FormsModule,
    FormsModule,
    MatTooltipModule,
    NgxMaskModule.forRoot({
      showMaskTyped: true,
      // clearIfNotMatch : true
    }),
    RouterModule.forChild(router),
  ],
})
export class StoreModule {}
