import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyExcelExportComponent } from './company-excel-export.component';

describe('CompanyExcelExportComponent', () => {
  let component: CompanyExcelExportComponent;
  let fixture: ComponentFixture<CompanyExcelExportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompanyExcelExportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyExcelExportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
