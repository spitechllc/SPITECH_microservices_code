import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { ExcelService } from 'src/app/dashboard/api-service/excel-servive/excel.service';

@Component({
  selector: 'app-company-excel-export',
  templateUrl: './company-excel-export.component.html',
  styleUrls: ['./company-excel-export.component.scss'],
})
export class CompanyExcelExportComponent implements OnInit {
  constructor(
    private excelService: ExcelService,
    public dialogRef: MatDialogRef<CompanyExcelExportComponent>,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: { data: any }
  ) {
    this.excelData = data;
    // console.log(this.excelData);
  }
  excelData: any;
  id: boolean = true;
  name: boolean = true;

  mcC_SICNumber: boolean = true;

  number: boolean = true;
  email: boolean = true;
  addressLine1: boolean = true;
  addressLine: boolean = true;
  city: boolean = true;
  state: boolean = true;
  zipCode: boolean = true;
  ngOnInit(): void {}

  onClickChexBox(event: any) {
    if (event.source.value == 'id' && event.checked == false) {
      this.id = false;
    } else if (event.source.value == 'id' && event.checked == true) {
      this.id = true;
    }
    if (event.source.value == 'name' && event.checked == false) {
      this.name = false;
    } else if (event.source.value == 'name' && event.checked == true) {
      this.name = true;
    }

    if (event.source.value == 'mcC_SICNumber' && event.checked == false) {
      this.mcC_SICNumber = false;
    } else if (event.source.value == 'mcC_SICNumber' && event.checked == true) {
      this.mcC_SICNumber = true;
    }

    if (event.source.value == 'city' && event.checked == false) {
      this.city = false;
    } else if (event.source.value == 'city' && event.checked == true) {
      this.city = true;
    }
    if (event.source.value == 'state' && event.checked == false) {
      this.state = false;
    } else if (event.source.value == 'state' && event.checked == true) {
      this.state = true;
    }

    if (event.source.value == 'email' && event.checked == false) {
      this.email = false;
    } else if (event.source.value == 'email' && event.checked == true) {
      this.email = true;
    }
    if (event.source.value == 'number' && event.checked == false) {
      this.number = false;
    } else if (event.source.value == 'number' && event.checked == true) {
      this.number = true;
    }
    if (event.source.value == 'addressLine1' && event.checked == false) {
      this.addressLine1 = false;
    } else if (event.source.value == 'addressLine1' && event.checked == true) {
      this.addressLine1 = true;
    }
    if (event.source.value == 'zipCode' && event.checked == false) {
      this.zipCode = false;
    } else if (event.source.value == 'zipCode' && event.checked == true) {
      this.zipCode = true;
    }
  }
  excelExport() {
    const excelExportData = this.excelData.map((t: any) => {
      const dataObject: any = {};
      if (this.id == true) {
        dataObject.id = t.id;
      }

      if (this.name == true) {
        dataObject.name = t.name;
      }
      if (this.mcC_SICNumber == true) {
        dataObject.mcC_SICNumber = t.mcC_SICNumber;
      }
      if (this.email == true) {
        t.emails.map((p: any) => {
          dataObject.email = p.email;
          return p.email;
        });
      }
      if (this.number == true) {
        t.phones.map((p: any) => {
          dataObject.number = p.number;
          return p.number;
        });
      }
      if (this.addressLine1 == true) {
        t.addresses.map((a: any) => {
          dataObject.addressLine1 = a.addressLine1;
          return a.addressLine1;
        });
      }
      if (this.addressLine1 == true) {
        t.addresses.map((a: any) => {
          dataObject.addressLine2 = a.addressLine2;
          return a.addressLine2;
        });
      }
      if (this.city == true) {
        t.addresses.map((a: any) => {
          dataObject.city = a.city;
          return a.city;
        });
      }
      if (this.state == true) {
        t.addresses.map((a: any) => {
          dataObject.state = a.state;
          return a.state;
        });
      }
      if (this.zipCode == true) {
        t.addresses.map((a: any) => {
          dataObject.zipCode = a.zipCode;
          return a.zipCode;
        });
      }

      return dataObject;
    });

    this.excelService.exportAsExcelFile(
      excelExportData,
      'Company-exported-data'
    );
  }
}
