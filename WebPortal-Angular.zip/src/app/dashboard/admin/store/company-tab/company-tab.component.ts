import {
  AfterViewInit,
  Component,
  Input,
  OnInit,
  ViewChild,
} from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

import { MatSort, Sort } from '@angular/material/sort';
import { MatSnackBar } from '@angular/material/snack-bar';
import { PageEvent } from '@angular/material/paginator';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { StoreService } from 'src/app/dashboard/api-service/storeService';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/dashboard/auth/auth.service';
import { debounce } from 'lodash';
import { ExcelService } from 'src/app/dashboard/api-service/excel-servive/excel.service';
import { SharedService } from 'src/app/dashboard/auth/shared.service';
import { CompanyExcelExportComponent } from './company-excel-export/company-excel-export.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-company-tab',
  templateUrl: './company-tab.component.html',
  styleUrls: ['./company-tab.component.scss'],
})
export class CompanyTabComponent implements OnInit {
  @ViewChild(MatSort) sort: MatSort;
  displayedColumns = [
    'storeId',
    'siteId',
    'storeName',
    'addressId',
    'phoneId',
    'createdOn',
    'action',
    'status',
  ];
  dataSource = new MatTableDataSource<StoreTable>([]);

  step = 0;
  setStep(index: number) {
    // console.log(index, 'index');
    this.step = index;
    this.storeService.getStoreByCompanyId(index).subscribe(
      (data: any) => {
        this.dataArray = data;
        this.dataSource.data = data.data;
        this.dataSource.sort = this.sort;
        this.length = this.dataArray.data.length;
        if (this.StoreId > 0) {
          this.dataSource.data = this.dataArray.data?.filter(
            (element: any) => element.storeId == this.StoreId
          );
        }
      },
      (err) => {}
    );
  }
  nextStep() {
    this.step++;
  }
  prevStep() {
    this.step--;
  }
  dataArray: any;
  storeId: any;
  companyName: any;

  term: any;
  companyId: any;
  companyDetails: any;
  err: any;
  totalCount = 0;
  PageIndex = 1;
  PageSize = 50;
  SortBy = '';
  SortOrder = 'asc';
  totalPages: any;
  pageSizeOptions: number[] = [10, 25, 50, 100, 200];
  loading: boolean = true;
  itemsPerPage: any;
  CompanyName: string = '';
  roles: any;
  isFirst: number = 1;
  StoreId: any;
  paramData: any = {};
  allCompanyData: any = [];
  searchEvent: any;
  City: string = '';
  StateId: number = 0;
  ZipCode: string = '';
  claimIdArray: any;
  // @Input() companyDetail: any = {};
  constructor(
    private storeService: StoreService,
    private activetedRoute: ActivatedRoute,
    private toster: ToastrService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private authService: AuthService,
    private excelService: ExcelService,
    public sharedService: SharedService,
    public dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.companyId = localStorage.getItem('companyId');
    this.StoreId = localStorage.getItem('storeId');
    this.roles = this.authService.getRols();
    const claim = this.authService.getClaims();
    this.claimIdArray = claim;
    this.activetedRoute.queryParamMap.subscribe((data: any) => {
      this.paramData = data.params;
    });

    if (this.paramData.data == 'true') {
      this.PageIndex = this.paramData.PageIndex;
      this.PageSize = this.paramData.PageSize;
      this.searchEvent = this.paramData.searchEvent
        ? this.paramData.searchEvent
        : 0;

      this.CompanyName = this.paramData.CompanyName
        ? this.paramData.CompanyName
        : '';
      this.City = this.paramData.City ? this.paramData.City : '';
      this.ZipCode = this.paramData.ZipCode ? this.paramData.ZipCode : '';
      this.StateId = this.paramData.StateId ? this.paramData.StateId : 0;
      this.getCompanyByWithPagging();
    }
    if (this.roles.includes('SuperAdmin')) {
      this.getCompanyByWithPagging();
    } else if (this.roles.includes('StoreOwner')) {
      this.getCompanyByStoreOwnerId();
    } else {
      this.getCompanyByCompanyId();
    }
    this.getAllState();
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  getCompanyByStoreOwnerId() {
    const userId = localStorage.getItem('userId') as string;
    this.storeService
      .getAllCompanyByStoreOwner(userId)
      .subscribe((data: any) => {
        this.totalPages = data.totalPages;
        this.companyDetails = data.companies;
        this.totalCount = data.totalCount;
      });
  }

  phones: any;
  number: any;
  emails: any;
  addressline1: any;
  addressline2: any;
  city: any;
  state: any;
  country: any;
  zipCode: any;
  exportAsExcel() {
    var PageSize = 0;
    var PageIndex = 0;
    this.storeService
      .getCompanyByWithPagging(
        PageIndex,
        PageSize,
        this.CompanyName,
        this.City,
        this.StateId,
        this.ZipCode
      )
      .subscribe((data: any) => {
        this.allCompanyData = data.data;
        const dialogRef = this.dialog.open(CompanyExcelExportComponent, {
          width: '450px',
          panelClass: 'popup',
          data: this.allCompanyData,
        });
        // if (this.allCompanyData.length > 0) {
        //   this.excelService.exportAsExcelFile(
        //     this.allCompanyData.map((c: any) => {
        //       return {
        //         'Company Id': c.id,
        //         'Company Name': c.name,
        //         mcC_SICNumber: c.mcC_SICNumber,
        //         'Mobile Number': c.phones.map((p: any) => {
        //           // console.log(p.number);
        //           this.number = p.number;
        //           return { MobileNumber: p.number };
        //         })
        //           ? this.number
        //           : '',
        //         Email: c.emails.map((e: any) => {
        //           this.emails = e.email;
        //           return { email: e.email };
        //         })
        //           ? this.emails
        //           : '',
        //         AddressLine1: c.addresses.map((a: any) => {
        //           this.addressline1 = a.addressLine1;
        //           this.city = a.city;
        //           this.state = a.state;
        //           (this.country = a.country),
        //             (this.addressline1 = a.addressLine1);
        //           this.addressline2 = a.addressLine2;
        //           this.zipCode = a.zipCode;
        //           return {};
        //         })
        //           ? this.addressline1
        //           : '',

        //         AddressLine2: this.addressline2,
        //         City: this.city,
        //         State: this.state,
        //         Country: this.country,
        //         'Zip Code': this.zipCode,
        //       };
        //     }),

        //     'all-Company'
        //   );
        // } else {
        //   this.toster.error('Data not found');
        // }
      });
  }

  getCompanyByCompanyId() {
    this.storeService
      .getCompanyByCompanyId(this.companyId)
      .subscribe((data: any) => {
        this.totalCount = data.totalCount;
        this.totalPages = data.totalPages;
        // console.log(data);
        this.companyDetails = [data];
      });
  }
  companyLength: any;
  getCompanyByWithPagging() {
    this.storeService
      .getCompanyByWithPagging(
        this.PageIndex,
        this.PageSize,
        this.CompanyName,
        this.City,
        this.StateId,
        this.ZipCode
      )
      .subscribe(
        (data: any) => {
          this.totalPages = data.totalPages;
          this.companyDetails = data.data;
          this.companyLength = data.data.length;
          this.totalCount = data.totalCount;
        },
        (err) => {
          if (err.message.error.status == 500) {
            this.err = 'Internal server error';
            this.toster.error('Internal server error');
          }
          if (err.message.name == 'HttpErrorResponse') {
            this.err = 'Internal server error';
            this.toster.error('Internal server error');
          }
          this.err = err.message.name;
          this.toster.error(err.message.name);
        }
      );

    this.companyName = localStorage.getItem('companyName');
  }
  length: any;
  onChangeStore(id: number) {
    if (id) {
      this.storeService.getStoreByCompanyId(id).subscribe(
        (data: any) => {
          this.dataArray = data;
          this.length = this.dataArray.length;

          this.dataSource = new MatTableDataSource(this.dataArray.data);
          this.dataSource.sort = this.sort;
          // console.log(this.dataSource);
        },
        (err) => {
          if (err.status == 500) {
            this.err = 'Internal Server Error';
          }
        }
      );
    }
  }

  onChange(event: any) {
    this.searchEvent = event;
    if (event == 0) {
      this.CompanyName = '';
      this.City = '';
      this.StateId = 0;
      this.ZipCode = '';
      this.searchEvent = 0;

      this.router.navigate(['/admin/stores-owner'], {
        queryParams: {
          PageIndex: this.PageIndex,
          PageSize: this.PageSize,

          searchEvent: (this.searchEvent = 0),
          data: 'true',
          tabPostion: 0,
          StateId: (this.StateId = 0),

          CompanyName: (this.CompanyName = ''),
          City: (this.City = ''),
          ZipCode: (this.ZipCode = ''),
        },
        queryParamsHandling: 'merge',
      });

      this.getCompanyByWithPagging();
    }
  }
  allState: any = [];
  getAllState() {
    this.storeService.getAllState().subscribe((data: any) => {
      this.allState = data.data;
    });
  }
  onClickState(stateId: any) {
    this.StateId = stateId;
    this.router.navigate(['/admin/stores-owner'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        searchEvent: this.searchEvent,
        data: 'true',
        tabPostion: 0,
        City: (this.City = ''),
        CompanyName: (this.CompanyName = ''),
        ZipCode: (this.ZipCode = ''),
        StateId: this.StateId,
      },
      queryParamsHandling: 'merge',
    });
    this.getCompanyByWithPagging();
  }
  filterByStateId = debounce(($event) => {
    if ($event.target.value == '') {
      this.StateId = 0;
    } else {
      this.StateId = $event.target.value;
    }

    this.PageIndex = 1;

    this.router.navigate(['/admin/stores-owner'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        searchEvent: this.searchEvent,
        data: 'true',
        tabPostion: 0,
        City: (this.City = ''),
        CompanyName: (this.CompanyName = ''),
        ZipCode: (this.ZipCode = ''),
        StateId: this.StateId,
      },
      queryParamsHandling: 'merge',
    });

    this.getCompanyByWithPagging();
  }, 1000);

  filterByCompanyName = debounce((event) => {
    this.CompanyName = event.target.value;
    this.PageIndex = 1;

    this.router.navigate(['/admin/stores-owner'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        data: 'true',
        tabPostion: 0,
        searchEvent: this.searchEvent,
        City: (this.City = ''),
        CompanyName: this.CompanyName,
        ZipCode: (this.ZipCode = ''),
        StateId: (this.StateId = 0),
      },
      queryParamsHandling: 'merge',
    });

    this.getCompanyByWithPagging();
  }, 1000);

  filterByZipCode = debounce(($event) => {
    this.ZipCode = $event.target.value;
    this.PageIndex = 1;

    this.router.navigate(['/admin/stores-owner'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        data: 'true',
        tabPostion: 0,
        searchEvent: this.searchEvent,
        City: (this.City = ''),
        CompanyName: (this.CompanyName = ''),
        ZipCode: this.ZipCode,
        StateId: (this.StateId = 0),
      },
      queryParamsHandling: 'merge',
    });

    this.getCompanyByWithPagging();
  }, 1000);

  filterByCityName = debounce((event) => {
    this.City = event.target.value;
    this.PageIndex = 1;
    this.router.navigate(['/admin/stores-owner'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        data: 'true',
        tabPostion: 0,
        searchEvent: this.searchEvent,
        City: this.City,
        CompanyName: (this.CompanyName = ''),
        ZipCode: (this.ZipCode = ''),
        StateId: (this.StateId = 0),
      },
      queryParamsHandling: 'merge',
    });

    this.getCompanyByWithPagging();
  }, 1000);
  // filterByCompanyName = debounce((event) => {
  //   this.CompanyName = event.target.value;
  //   this.PageIndex = 1;
  //   this.totalCount = 0;
  //   this.router.navigate(['/admin/stores-owner'], {
  //     queryParams: {
  //       PageIndex: this.PageIndex,
  //       PageSize: this.PageSize,
  //       data: 'true',
  //       tabPostion: 0,
  //       search: this.CompanyName,
  //     },
  //     queryParamsHandling: 'merge',
  //   });

  //   if (this.roles.includes('SuperAdmin')) {
  //     this.getCompanyByWithPagging();
  //   } else {
  //     this.getCompanyByCompanyId();
  //   }
  // }, 1000);

  filterdata($event: any) {
    this.CompanyName = $event.target.value;
    this.PageIndex = 1;
    this.totalCount = 0;
    this.router.navigate(['/admin/stores-owner'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        data: 'true',
        search: this.CompanyName,
      },
      queryParamsHandling: 'merge',
    });
    if (this.roles.includes('SuperAdmin')) {
      this.getCompanyByWithPagging();
    } else {
      this.getCompanyByCompanyId();
    }
  }

  pageChanged(event: PageEvent) {
    this.PageIndex = event.pageIndex + 1;
    this.PageSize = event.pageSize;
    this.router.navigate(['/admin/stores-owner'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        data: 'true',
        tabPostion: 0,
        search: this.CompanyName,
      },
      queryParamsHandling: 'merge',
    });
    this.getCompanyByWithPagging();
  }
}

export interface StoreTable {
  StateId: number;
  storeName: string;
}
