import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-store',
  templateUrl: './store.component.html',
  styleUrls: ['./store.component.scss'],
})
export class StoreComponent implements OnInit {
  tabPostion: any;
  claimIdArray: any;
  constructor(
    private router: Router,
    private activateRoute: ActivatedRoute,
    private auth: AuthService
  ) {}
  paramsData: any;
  tabName: string = 'Company';
  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.activateRoute.queryParamMap.subscribe((data: any) => {
      this.paramsData = data.params;
      this.tabPostion = data.params.tabPostion;
    });
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  onClickTab(event: any) {
    this.tabName = event.tab.textLabel;
    if (event.index == 0) {
      this.router.navigate(['/admin/stores-owner'], {
        queryParams: {
          tabPostion: 0,
        },
        queryParamsHandling: 'merge',
      });
    }
    if (event.index == 1) {
      this.queryParams();
    }
  }
  queryParams() {
    this.router.navigate(['/admin/stores-owner'], {
      queryParams: {
        tabPostion: 1,
      },
      queryParamsHandling: 'merge',
    });
  }
}
