import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { ExcelService } from 'src/app/dashboard/api-service/excel-servive/excel.service';

@Component({
  selector: 'app-store-excel-export',
  templateUrl: './store-excel-export.component.html',
  styleUrls: ['./store-excel-export.component.scss'],
})
export class StoreExcelExportComponent implements OnInit {
  constructor(
    private excelService: ExcelService,
    public dialogRef: MatDialogRef<StoreExcelExportComponent>,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: { data: any }
  ) {
    this.excelData = data;
    // console.log(this.excelData);
  }
  excelData: any;
  siteId: boolean = true;
  storeName: boolean = true;

  company: boolean = true;

  createdOn: boolean = true;
  time: boolean = true;
  mangerName: boolean = true;
  addressLine: boolean = true;
  regionalManagerName: boolean = true;
  posName: boolean = true;
  saleAgentName: boolean = true;
  number: boolean = true;
  email: boolean = true;
  addressLine1: boolean = true;
  addressLine2: boolean = true;
  city: boolean = true;
  state: boolean = true;
  country: boolean = true;
  zipCode: boolean = true;
  ngOnInit(): void {}

  onClickChexBox(event: any) {
    if (event.source.value == 'siteId' && event.checked == false) {
      this.siteId = false;
    } else if (event.source.value == 'siteId' && event.checked == true) {
      this.siteId = true;
    }
    if (event.source.value == 'storeName' && event.checked == false) {
      this.storeName = false;
    } else if (event.source.value == 'storeName' && event.checked == true) {
      this.storeName = true;
    }

    if (event.source.value == 'company' && event.checked == false) {
      this.company = false;
    } else if (event.source.value == 'company' && event.checked == true) {
      this.company = true;
    }

    if (event.source.value == 'regionalManagerName' && event.checked == false) {
      this.regionalManagerName = false;
    } else if (
      event.source.value == 'regionalManagerName' &&
      event.checked == true
    ) {
      this.regionalManagerName = true;
    }
    if (event.source.value == 'posName' && event.checked == false) {
      this.posName = false;
    } else if (event.source.value == 'posName' && event.checked == true) {
      this.posName = true;
    }

    if (event.source.value == 'time' && event.checked == false) {
      this.time = false;
    } else if (event.source.value == 'time' && event.checked == true) {
      this.time = true;
    }
    if (event.source.value == 'createdOn' && event.checked == false) {
      this.createdOn = false;
    } else if (event.source.value == 'createdOn' && event.checked == true) {
      this.createdOn = true;
    }
    if (event.source.value == 'mangerName' && event.checked == false) {
      this.mangerName = false;
    } else if (event.source.value == 'mangerName' && event.checked == true) {
      this.mangerName = true;
    }
    if (event.source.value == 'saleAgentName' && event.checked == false) {
      this.saleAgentName = false;
    } else if (event.source.value == 'saleAgentName' && event.checked == true) {
      this.saleAgentName = true;
    }
    if (event.source.value == 'number' && event.checked == false) {
      this.number = false;
    } else if (event.source.value == 'number' && event.checked == true) {
      this.number = true;
    }
    if (event.source.value == 'email' && event.checked == false) {
      this.email = false;
    } else if (event.source.value == 'email' && event.checked == true) {
      this.email = true;
    }
    if (event.source.value == 'addressLine1' && event.checked == false) {
      this.addressLine1 = false;
    } else if (event.source.value == 'addressLine1' && event.checked == true) {
      this.addressLine1 = true;
    }
    if (event.source.value == 'addressLine2' && event.checked == false) {
      this.addressLine2 = false;
    } else if (event.source.value == 'addressLine2' && event.checked == true) {
      this.addressLine2 = true;
    }
    if (event.source.value == 'city' && event.checked == false) {
      this.city = false;
    } else if (event.source.value == 'city' && event.checked == true) {
      this.city = true;
    }
    if (event.source.value == 'state' && event.checked == false) {
      this.state = false;
    } else if (event.source.value == 'state' && event.checked == true) {
      this.state = true;
    }
    if (event.source.value == 'country' && event.checked == false) {
      this.country = false;
    } else if (event.source.value == 'country' && event.checked == true) {
      this.country = true;
    }
    if (event.source.value == 'zipCode' && event.checked == false) {
      this.zipCode = false;
    } else if (event.source.value == 'zipCode' && event.checked == true) {
      this.zipCode = true;
    }
  }
  excelExport() {
    const excelExportData = this.excelData.map((t: any) => {
      const dataObject: any = {};
      if (this.siteId == true) {
        dataObject.siteId = t.siteId;
      }
      if (this.time == true) {
        dataObject.time = t.time;
      }

      if (this.storeName == true) {
        dataObject.storeName = t.storeName;
      }
      if (this.company == true) {
        dataObject.company = t.company;
      }
      if (this.createdOn == true) {
        dataObject.createdOn = t.createdOn;
      }
      if (this.mangerName == true) {
        dataObject.mangerName = t.mangerName;
      }
      if (this.regionalManagerName == true) {
        dataObject.regionalManagerName = t.regionalManagerName;
      }
      if (this.posName == true) {
        dataObject.posName = t.posName;
      }
      if (this.saleAgentName == true) {
        dataObject.saleAgentName = t.saleAgentName;
      }
      if (this.number == true) {
        t.phones.map((p: any) => {
          dataObject.number = p.number;
          return p.number;
        });
      }
      if (this.email == true) {
        t.emails.map((p: any) => {
          dataObject.email = p.email;
          return p.email;
        });
      }
      if (this.addressLine1 == true) {
        t.addresses.map((a: any) => {
          dataObject.addressLine1 = a.addressLine1;
          return a.addressLine1;
        });
      }
      if (this.addressLine2 == true) {
        t.addresses.map((a: any) => {
          dataObject.addressLine2 = a.addressLine2;
          return a.addressLine2;
        });
      }
      if (this.city == true) {
        t.addresses.map((a: any) => {
          dataObject.city = a.city;
          return a.city;
        });
      }
      if (this.state == true) {
        t.addresses.map((a: any) => {
          dataObject.state = a.state;
          return a.state;
        });
      }
      if (this.country == true) {
        t.addresses.map((a: any) => {
          dataObject.country = a.country;
          return a.country;
        });
      }
      if (this.zipCode == true) {
        t.addresses.map((a: any) => {
          dataObject.zipCode = a.zipCode;
          return a.zipCode;
        });
      }

      return dataObject;
    });

    this.excelService.exportAsExcelFile(excelExportData, 'Store-exported-data');
  }
}
