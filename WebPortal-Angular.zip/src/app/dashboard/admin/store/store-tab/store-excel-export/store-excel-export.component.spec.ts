import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StoreExcelExportComponent } from './store-excel-export.component';

describe('StoreExcelExportComponent', () => {
  let component: StoreExcelExportComponent;
  let fixture: ComponentFixture<StoreExcelExportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StoreExcelExportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StoreExcelExportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
