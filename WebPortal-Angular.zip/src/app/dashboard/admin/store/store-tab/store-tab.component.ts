import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FormGroup, FormBuilder } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { debounce } from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ExcelService } from 'src/app/dashboard/api-service/excel-servive/excel.service';

import { StoreService } from 'src/app/dashboard/api-service/storeService';
import { AuthService } from 'src/app/dashboard/auth/auth.service';
import { SharedService } from 'src/app/dashboard/auth/shared.service';
import { StoreExcelExportComponent } from './store-excel-export/store-excel-export.component';

import { IdentityService } from 'src/app/dashboard/api-service/identityService';
@Component({
  selector: 'app-store-tab',
  templateUrl: './store-tab.component.html',
  styleUrls: ['./store-tab.component.scss'],
})
export class StoreTabComponent implements OnInit {
  displayedColumns = [
    'storeId',
    'siteId',
    'storeName',
    'CompanyName',
    'storeCategory',
    'appName',
    'LastTransactionDate',
    'createdOn',
    'isActive',
    'action',
  ];
  dataSource = new MatTableDataSource<StoreTable>([]);

  total: number = 0;
  searchEvent: any;
  storeId: number = 0;

  company: string = '';
  siteId: string = '';
  pageIndex: number = 1;
  pageSize: number = 50;
  storeName: string = '';
  sortBy = '';
  roles: any;
  sortOrder: string = '';
  allStoreData: any = [];
  paramsData: any;
  claimIdArray: any;
  phones: any;
  number: any;
  emails: any;
  addressline1: any;
  addressline2: any;
  city: any;
  state: any;
  country: any;
  zipCode: any;
  heartBeat: number = 300;
  constructor(
    private storeService: StoreService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private activateRoute: ActivatedRoute,
    private toster: ToastrService,
    private excelService: ExcelService,
    private authService: AuthService,
    private sharedService: SharedService,
    public dialog: MatDialog,
    private fb: FormBuilder,
    private indentityService: IdentityService
  ) {}
  StoreId: any;
  storeSearchForm!: FormGroup;
  ngOnInit(): void {
    this.createForm();
    const claim = this.authService.getClaims();
    this.getTenant();
    this.claimIdArray = claim;
    this.StoreId = localStorage.getItem('storeId');
    this.activateRoute.queryParamMap.subscribe((data: any) => {
      this.paramsData = data.params;
    });
    if (this.paramsData.data == 'store') {
      this.pageIndex = this.paramsData.pageIndex;
      this.pageSize = this.paramsData.pageSize;

      this.searchEvent = this.paramsData.searchEvent
        ? this.paramsData.searchEvent
        : 0;

      this.storeName = this.paramsData.storeName
        ? this.paramsData.storeName
        : '';
      this.company = this.paramsData.company ? this.paramsData.company : '';
      this.siteId = this.paramsData.siteId ? this.paramsData.siteId : '';
      this.City = this.paramsData.City ? this.paramsData.City : '';
      this.StateName = this.paramsData.StateName
        ? this.paramsData.StateName
        : '';
      this.ZipCode = this.paramsData.ZipCode ? this.paramsData.ZipCode : '';
      this.storeId = this.paramsData.storeId ? this.paramsData.storeId : 0;

      this.getStoreWithPaging();
    } else {
    }
    this.roles = this.authService.getRols();
    if (this.roles.includes('SuperAdmin')) {
      this.getStoreWithPaging();
    } else if (this.roles.includes('StoreOwner')) {
      this.getCompanyByStoreOwnerId();
    } else {
      this.getstoreByStoreId();
    }
    this.getAllState();
    this.tenantData = this.sharedService.tenantData;
    // this.dataSource = new MatTableDataSource(this.storeDetals);
  }
  storeDetals: any = [
    { storeId: 1, siteId: '1234', storeName: 'abc', CompanyName: 'abc' },
  ];

  createForm() {
    this.storeSearchForm = this.fb.group({
      appIds: [[]],
    });
  }
  appDetails: any = [];
  getTenant() {
    this.indentityService.getTenantMasterList().subscribe((data: any) => {
      this.appDetails = data;
    });
  }
  // appDetails: any = [
  //   { id: 1, tenantName: 'Velocity' },
  //   { id: 2, tenantName: 'Verifone' },
  //   { id: 3, tenantName: 'SpiTech' },
  // ];
  selctedAppIds: any = [];
  isAllSelected: boolean = false;
  onClickSelectAllApp(event: any) {
    this.isAllSelected = true;
    // this.showStoreNames = false;
    if (event.isUserInput) {
      if (event.source.selected) {
        this.selctedAppIds = this.appDetails.map((app: any) => app.id);
      } else {
        this.selctedAppIds = [];
      }
      this.storeSearchForm.get('appIds')?.patchValue(this.selctedAppIds);
    }
    this.getStoreWithPaging();
  }
  tenantData: any;
  tenantId: any = [];
  onClickTenant() {
    this.getStoreWithPaging();
  }

  getstoreByStoreId() {
    this.storeService.getStoreByStoreId(this.StoreId).subscribe((data: any) => {
      this.dataSource = new MatTableDataSource([data]);
    });
  }

  companyIds: any = [];
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  getCompanyByStoreOwnerId() {
    const userId = localStorage.getItem('userId') as string;
    this.storeService
      .getAllCompanyByStoreOwner(userId)
      .subscribe((data: any) => {
        this.companyIds.push(data.companyIds);
        this.allStoreOwnerStores();
      });
  }
  allStoreOwnerStores() {
    this.storeService
      .getAllStoreByCompanyIds({
        companyIds: this.companyIds[0],
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        sortBy: this.sortBy,
        sortOrder: this.sortOrder,
      })
      .subscribe((data: any) => {
        // console.log(data);
        this.dataSource = new MatTableDataSource(data.data);
      });
  }

  timeZoneName: any = [];
  time: any;
  timeZone() {
    this.storeService.getTimeZone().subscribe((data: any) => {
      this.timeZoneName = data.data;
    });
  }
  getTimeZone(id: any) {
    this.timeZoneName.filter((t: any) => {
      if (t.timeZoneId == id) {
        this.time = t.timeZoneName;
        return t.timeZoneName;
      }
    });
  }

  exportAsExcel() {
    var pageSize = 0;
    var pageIndex = 0;
    this.storeService
      .getStoreWithPagingg(
        pageIndex,
        pageSize,
        this.sortOrder,
        this.sortBy,
        this.storeId,
        this.storeName,
        this.siteId,
        this.company,
        this.IsOnline,
        this.heartBeat,
        this.City,
        this.ZipCode,
        this.StateName,
        this.storeSearchForm.get('appIds')?.value
      )
      .subscribe((data: any) => {
        this.allStoreData = data.data;
        const dialogRef = this.dialog.open(StoreExcelExportComponent, {
          width: '450px',
          panelClass: 'popup',
          data: this.allStoreData,
        });
        // if (this.allStoreData.length > 0) {
        //   this.excelService.exportAsExcelFile(
        //     this.allStoreData.map((s: any) => {
        //       this.getTimeZone(s.timeZoneId);
        //       return {
        //         'Site Id': s.siteId,
        //         StoreId: s.storeId,
        //         'Store Name': s.storeName,
        //         'Company Name': s.company,
        //         CreatedOn: s.createdOn,
        //         'TimeZone Name': this.time,
        //         'Manger Name': s.mangerName,
        //         'Regional Manager Name': s.regionalManagerName,
        //         'Pos Name': s.posName,
        //         'Sale Agent Name': s.saleAgentName,
        //         'Mobile Number': s.phones.map((p: any) => {
        //           this.number = p.number;
        //           return { MobileNumber: p.number };
        //         })
        //           ? this.number
        //           : '',
        //         Email: s.emails.map((e: any) => {
        //           this.emails = e.email;
        //           return { email: e.email };
        //         })
        //           ? this.emails
        //           : '',
        //         AddressLine1: s.addresses.map((a: any) => {
        //           this.addressline1 = a.addressLine1;
        //           this.city = a.city;
        //           this.state = a.state;
        //           (this.country = a.country), (this.zipCode = a.zipCode);
        //           this.addressline2 = a.addressLine2;
        //           return {};
        //         })
        //           ? this.addressline1
        //           : '',

        //         AddressLine2: this.addressline2,
        //         City: this.city,
        //         State: this.state,
        //         Country: this.country,
        //         'Zip Code': this.zipCode,
        //       };
        //     }),
        //     'all-stores'
        //   );
        // } else {
        //   this.toster.error('Data not found');
        // }
      });
  }

  onChange(event: any) {
    // console.log(event);
    this.searchEvent = event;
    this.sortBy = '';
    this.sortOrder = '';
    if (event == 0) {
      this.storeId = 0;
      this.siteId = '';
      this.company = '';
      this.storeName = '';
      (this.City = ''),
        (this.ZipCode = ''),
        (this.StateName = ''),
        (this.searchEvent = 0);
      this.router.navigate(['/admin/stores-owner'], {
        queryParams: {
          pageIndex: this.pageIndex,
          pageSize: this.pageSize,

          searchEvent: (this.searchEvent = 0),
          data: 'store',
          storeId: (this.storeId = 0),

          storeName: (this.storeName = ''),
          company: (this.company = ''),
          siteId: (this.siteId = ''),
          StateName: (this.StateName = ''),
          ZipCode: (this.ZipCode = ''),
          City: (this.City = ''),
        },
        queryParamsHandling: 'merge',
      });

      this.getStoreWithPaging();
    }
  }
  filterByStoreID = debounce(($event) => {
    if ($event.target.value == '') {
      this.storeId = 0;
    } else {
      this.storeId = $event.target.value;
    }

    this.pageIndex = 1;

    this.router.navigate(['/admin/stores-owner'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        searchEvent: this.searchEvent,
        data: 'store',
        company: (this.company = ''),
        storeName: (this.storeName = ''),
        siteId: (this.siteId = ''),
        storeId: this.storeId,
        StateName: (this.StateName = ''),
        ZipCode: (this.ZipCode = ''),
        City: (this.City = ''),
      },
      queryParamsHandling: 'merge',
    });

    this.getStoreWithPaging();
  }, 1000);

  filterByStoreName = debounce((event) => {
    this.storeName = event.target.value;
    this.pageIndex = 1;
    this.router.navigate(['/admin/stores-owner'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        data: 'store',
        searchEvent: this.searchEvent,
        company: (this.company = ''),
        storeName: this.storeName,
        siteId: (this.siteId = ''),
        storeId: (this.storeId = 0),
        StateName: (this.StateName = ''),
        ZipCode: (this.ZipCode = ''),
        City: (this.City = ''),
      },
      queryParamsHandling: 'merge',
    });

    this.getStoreWithPaging();
  }, 1000);
  filterByCity = debounce((event) => {
    this.City = event.target.value;
    this.pageIndex = 1;
    this.router.navigate(['/admin/stores-owner'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        data: 'store',
        searchEvent: this.searchEvent,

        company: (this.company = ''),
        storeName: (this.storeName = ''),
        siteId: (this.siteId = ''),
        storeId: (this.storeId = 0),
        StateName: (this.StateName = ''),

        ZipCode: (this.ZipCode = ''),
        City: this.City,
      },
      queryParamsHandling: 'merge',
    });
    this.getStoreWithPaging();
  }, 1000);
  filterByZipCode = debounce((event) => {
    this.ZipCode = event.target.value;
    this.pageIndex = 1;
    this.router.navigate(['/admin/stores-owner'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        data: 'store',
        searchEvent: this.searchEvent,
        ZipCode: this.ZipCode,
        company: (this.company = ''),
        storeName: (this.storeName = ''),
        siteId: (this.siteId = ''),
        storeId: (this.storeId = 0),
        StateName: (this.StateName = ''),
        City: (this.City = ''),
      },
      queryParamsHandling: 'merge',
    });

    this.getStoreWithPaging();
  }, 1000);
  filterBySiteId = debounce(($event) => {
    this.siteId = $event.target.value;
    this.pageIndex = 1;

    this.router.navigate(['/admin/stores-owner'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        data: 'store',
        searchEvent: this.searchEvent,
        company: (this.company = ''),
        storeName: (this.storeName = ''),
        siteId: this.siteId,
        storeId: (this.storeId = 0),
        StateName: (this.StateName = ''),
        ZipCode: (this.ZipCode = ''),
        City: (this.City = ''),
      },
      queryParamsHandling: 'merge',
    });

    this.getStoreWithPaging();
  }, 1000);

  filterByCompanyName = debounce((event) => {
    this.company = event.target.value;
    this.pageIndex = 1;
    this.total = 0;
    this.router.navigate(['/admin/stores-owner'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        data: 'store',
        searchEvent: this.searchEvent,
        company: this.company,
        storeName: (this.storeName = ''),
        siteId: (this.siteId = ''),
        storeId: (this.storeId = 0),
        StateName: (this.StateName = ''),

        ZipCode: (this.ZipCode = ''),
        City: (this.City = ''),
      },
      queryParamsHandling: 'merge',
    });

    this.getStoreWithPaging();
  }, 1000);
  allState: any = [];
  stateName: string = '';
  getAllState() {
    this.storeService
      .getStateAutoComplete(this.stateName)
      .subscribe((data: any) => {
        this.allState = data.data;
      });
  }
  serachByCompanyName = debounce((event: any) => {
    if (event.target.value) {
      this.stateName = event.target.value;
      this.getAllState();
    } else if (event.target.value == '') {
      this.stateName = '';
      this.getAllState();
    }
  }, 1000);
  onClickState(stateId: any) {
    if (stateId == 0) {
      this.StateName = '';
    } else {
      this.StateName = stateId;
    }

    this.router.navigate(['/admin/stores-owner'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        data: 'store',
        searchEvent: this.searchEvent,
        StateName: this.StateName,
        company: (this.company = ''),
        ZipCode: (this.ZipCode = ''),
        City: (this.City = ''),
        storeName: (this.storeName = ''),
        siteId: (this.siteId = ''),
        storeId: (this.storeId = 0),
      },
      queryParamsHandling: 'merge',
    });

    this.getStoreWithPaging();
  }
  filterByStateName = debounce((event) => {
    this.StateName = event.target.value;
    this.pageIndex = 1;
    this.total = 0;
    this.router.navigate(['/admin/stores-owner'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        data: 'store',
        searchEvent: this.searchEvent,
        StateName: this.StateName,
        company: (this.company = ''),
        ZipCode: (this.ZipCode = ''),
        City: (this.City = ''),
        storeName: (this.storeName = ''),
        siteId: (this.siteId = ''),
        storeId: (this.storeId = 0),
      },
      queryParamsHandling: 'merge',
    });

    this.getStoreWithPaging();
  }, 1000);

  onHeaderSortChange(event: any) {
    if (event.active == 'createdOn') {
      this.sortBy = 'StoreId';
    } else {
      this.sortBy = event.active;
    }
    if (event.direction == '') {
      this.sortOrder = 'asc';
    } else {
      this.sortOrder = event.direction;
    }
    if (this.roles.includes('SuperAdmin')) {
      this.getStoreWithPaging();
    } else if (this.roles.includes('StoreOwner')) {
      this.getCompanyByStoreOwnerId();
    }
  }
  totalPage: number = 0;
  IsOnline: any;
  City: string = '';
  ZipCode: string = '';
  StateName: string = '';
  getStoreWithPaging() {
    this.storeService
      .getStoreWithPagingg(
        this.pageIndex,
        this.pageSize,
        this.sortOrder,
        this.sortBy,
        this.storeId,
        this.storeName,
        this.siteId,
        this.company,
        this.IsOnline,
        this.heartBeat,
        this.City,
        this.ZipCode,
        this.StateName,
        this.storeSearchForm.get('appIds')?.value
      )
      .subscribe(
        (data: any) => {
          this.dataSource = new MatTableDataSource(data.data);
          this.total = data.totalCount;
          this.totalPage = data.totalPages;
        },
        (err) => {}
      );
  }
  pageChanged(event: any) {
    this.pageIndex = event.pageIndex + 1;
    this.pageSize = event.pageSize;
    this.queryParams();
    this.getStoreWithPaging();
  }
  queryParams() {
    this.router.navigate(['/admin/stores-owner'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        sortBy: this.sortBy,
        sortOrder: this.sortOrder,
        tabPostion: 1,
        data: 'store',
      },
      queryParamsHandling: 'merge',
    });
  }
  onClickStores(element: any) {
    this.sharedService.onClickStore(element);
  }
}

export interface StoreTable {
  storeId: number;
  storeName: string;
  createdOn: string;

  addresses: [
    {
      addressId: number;
      categoryTypeLevelId: number;
      addressLine1: string;
      addressLine2: string;
      countryId: number;
      stateId: number;
      cityId: number;
      longitude: string;
      latitude: string;
    }
  ];
  phones: [
    {
      phoneId: number;
      categoryTypeLevelId: number;
      countryCode: string;
      areaCode: string;
      number: string;
    }
  ];
}
