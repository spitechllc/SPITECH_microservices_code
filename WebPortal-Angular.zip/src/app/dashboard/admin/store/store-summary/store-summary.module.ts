import { NgModule } from '@angular/core';
import { SharedModule } from './../../../../shared.module';
import { StoreSummaryComponent } from './store-summary.component';
import { RouterModule, Routes } from '@angular/router';

export const router: Routes = [
  {path: ':storeId', component: StoreSummaryComponent}
]


@NgModule({
    declarations: [StoreSummaryComponent],
    imports: [
        SharedModule,
        RouterModule.forChild(router)
    ]
})
export class StoreSummaryModule { }