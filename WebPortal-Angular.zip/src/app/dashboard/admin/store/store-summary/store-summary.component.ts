import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { GasPumpService } from 'src/app/dashboard/api-service/gasPump.service';
import { StoreService } from 'src/app/dashboard/api-service/storeService';

@Component({
  selector: 'app-store-summary',
  templateUrl: './store-summary.component.html',
  styleUrls: ['./store-summary.component.scss'],
})
export class StoreSummaryComponent implements OnInit {
  displayedColumns = ['posId', 'stationNumber', 'stationSystemId'];
  dataSource = new MatTableDataSource<PeriodicElement>([]);

  displayedColumns2 = [
    'pumpProductId',
    'description',
    'originalAmountUnitPrice',
  ];
  dataSource2 = new MatTableDataSource<FuilPrice>([]);

  displayedColumns3 = ['storeId', 'carWashName', 'price', 'Description'];
  dataSource3 = new MatTableDataSource<CarWashDetails>([]);

  constructor(
    private storeService: StoreService,
    private activatedRoute: ActivatedRoute,
    private posService: GasPumpService,
    private gasPumpService: GasPumpService,
    private _location: Location
  ) {}
  storeId: number | undefined;
  storeHours: any;
  storeSummaryDetails: any;
  Amenity: any;
  ngOnInit(): void {
    this.activatedRoute.params.subscribe((data: any) => {
      // console.log(data);
      this.storeId = data.storeId;
      // console.log((this.storeId))
    });
    //
    this.viewStoreSummery();
    this.getPos();
  }

  siteId: any;
  addressDetails: any;
  fuelPriceDetails: any;
  carWashType: any;
  aminitiesDetails: any;
  phonesDetails: any;
  viewStoreSummery() {
    const _id: number = this.storeId as number;
    this.storeService.viewStoreSummery(_id).subscribe((data) => {
      this.storeSummaryDetails = data;
      this.addressDetails = this.storeSummaryDetails.addresses;
      this.phonesDetails = this.storeSummaryDetails.phones;
      this.siteId = this.storeSummaryDetails.siteId;

      this.gasPumpService.getFuelPrice(this.siteId).subscribe((data: any) => {
        this.fuelPriceDetails = data;
        this.dataSource2 = new MatTableDataSource(this.fuelPriceDetails);
        // console.log(this.fuelPriceDetails, 'fuildetails');
      });
      // this.fuelPriceDetails = this.storeSummaryDetails.pumpProduct;

      // console.log(this.dataSource2, 'fullll');
      this.carWashType = this.storeSummaryDetails.carWashType;
      this.dataSource3 = new MatTableDataSource(this.carWashType);
      this.aminitiesDetails = this.storeSummaryDetails.amenities;
      this.storeHours = this.storeSummaryDetails.storeHours;
      // console.log(this.fuelPriceDetails, 'fuildetails');
      // console.log(this.storeSummaryDetails, 'store summery');
    });
  }

  // Display pos
  PosDetails: any;
  dataArray: any;
  getPos() {
    const _id: number = this.storeId as number;
    this.posService.getPos(_id).subscribe((data: any) => {
      this.dataArray = data;
      this.dataSource = new MatTableDataSource(this.dataArray.data);
      //  console.log(this.dataSource,'posdetails')
    });
  }
  getAmenity() {
    this.storeService.getStoreAmenities().subscribe((data: any) => {
      this.Amenity = data.data;
      // console.log(this.Amenity,'Amenity')
    });
  }
  weekendayDetails: any;
  getStoreWeekrnday() {
    this.storeService.storeWeekenId().subscribe((data: any) => {
      this.weekendayDetails = data.data;
      // console.log(this.weekendayDetails, 'store weeknd');
    });
  }
  getStoreHours() {
    const _id: number = this.storeId as number;
    this.storeService.getStoreHours(_id).subscribe((data: any) => {
      this.storeHours = data.data;
      // console.log(this.storeHours, 'store hours');
    });
  }
  onClickBack() {
    this._location.back();
  }
}

export interface PeriodicElement {
  posId: number;
  POSStationNo: string;
  systemID: string;
}

export interface FuilPrice {
  pumpProductId: number;
  originalAmountUnitPrice: string;
  description: string;
  unitMeasure: string;
}

export interface CarWashDetails {
  storeId: number;
  carWashName: string;
  price: number;
  Description: string;
}

// const ELEMENT_DATA3: PeriodicElement3[] = [
//   { id: '1', CarWashName: 'CarWashName', CarWashPrice: '$230', Description: 'Lorem ipsum dolor sit amet, consectetur adipiscing' },
//   { id: '2', CarWashName: 'CarWashName', CarWashPrice: '$230', Description: 'Lorem ipsum dolor sit amet, consectetur adipiscing' },
//   { id: '3', CarWashName: 'CarWashName', CarWashPrice: '$230', Description: 'Lorem ipsum dolor sit amet, consectetur adipiscing' },
// ];
