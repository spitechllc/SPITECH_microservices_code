import { NgModule } from '@angular/core';
import { SharedModule } from './../../../../shared.module';

import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AddEditOwnerComponent } from './add-edit-owner/add-edit-owner.component';
import {
  MatSnackBarModule,
  MAT_SNACK_BAR_DEFAULT_OPTIONS,
  MAT_SNACK_BAR_DEFAULT_OPTIONS_FACTORY,
} from '@angular/material/snack-bar';
import { GooglePlaceModule } from 'ngx-google-places-autocomplete';
import { RolePermissionGuard } from 'src/app/dashboard/auth/role-permission.guard';
import { RxReactiveFormsModule } from '@rxweb/reactive-form-validators';
import { NgxMaskModule, IConfig } from 'ngx-mask';
export const options: Partial<null | IConfig> | (() => Partial<IConfig>) = null;
export const router: Routes = [
  {
    path: '',
    component: AddEditOwnerComponent,
    canActivate: [RolePermissionGuard],
  },
  {
    path: 'edit/:id',
    component: AddEditOwnerComponent,
    canActivate: [RolePermissionGuard],
  },
];

@NgModule({
  declarations: [AddEditOwnerComponent],
  imports: [
    SharedModule,
    ReactiveFormsModule,
    MatSnackBarModule,
    GooglePlaceModule,
    FormsModule,
    NgxMaskModule.forRoot({
      showMaskTyped: true,
      // clearIfNotMatch : true
    }),
    RxReactiveFormsModule,
    RouterModule.forChild(router),
  ],
  providers: [
    { provide: MAT_SNACK_BAR_DEFAULT_OPTIONS, useValue: { duration: 2500 } },
  ],
})
export class CreateOwnerModule {}
