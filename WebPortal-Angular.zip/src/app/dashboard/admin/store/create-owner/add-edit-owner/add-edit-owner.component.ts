import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { StoreService } from 'src/app/dashboard/api-service/storeService';
import { Router, ActivatedRoute } from '@angular/router';
import { RequestService } from 'src/app/dashboard/api-service/request-service/request.service';
import { SubSink } from 'subsink';

import { MatSnackBar } from '@angular/material/snack-bar';

import { ToastrService } from 'ngx-toastr';
import { RxwebValidators } from '@rxweb/reactive-form-validators';
import { Location } from '@angular/common';
import { NgxSpinnerService } from 'ngx-spinner';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
import { SharedService } from 'src/app/dashboard/auth/shared.service';

@Component({
  selector: 'app-add-edit-owner',
  templateUrl: './add-edit-owner.component.html',
  styleUrls: ['./add-edit-owner.component.scss'],
})
export class AddEditOwnerComponent implements OnInit {
  ownerForm!: FormGroup;
  addressCategory: any;
  emailcategory: any;
  phonecategory: any;
  countries: any;
  title: any;
  submitted: boolean = false;
  loading: boolean = false;
  checked = true;
  state: any;
  // city: any = null;
  subs = new SubSink();
  ownerId: any = null;
  sameAddress: boolean = false;
  //  myModel = true;
  // for accessing form controls
  get f() {
    return this.ownerForm.controls;
  }
  get o() {
    return (this.ownerForm.controls.owners as FormGroup).controls;
  }

  get phones() {
    return this.ownerForm.get('phones') as FormArray;
  }
  get addresses() {
    return this.ownerForm.get('addresses') as FormArray;
  }

  get emails() {
    return this.ownerForm.get('emails') as FormArray;
  }

  get ownerAddresses() {
    return this.ownerForm.get('owners.addresses') as FormArray;
  }

  get ownerEmails() {
    return this.ownerForm.get('owners.emails') as FormArray;
  }
  get ownerPhones() {
    return this.ownerForm.get('owners.phones') as FormArray;
  }

  constructor(
    private fb: FormBuilder,
    private storeService: StoreService,
    private router: Router,
    private request: RequestService,
    private activatedRoute: ActivatedRoute,
    private _snackBar: MatSnackBar,
    private toster: ToastrService,
    private _location: Location,
    private identityServer: IdentityService,
    public SharedService: SharedService
  ) {}
  phoneEmpty: any;
  ngOnInit(): void {
    this.createForm();
    this.getCountry();
    this.getTitle();
    this.getEmailCategoryLevel();
    this.phoneCategory();
    this.getAddressCategoryLevel();
    this.getOwnerId();
    // this.tenantData = this.SharedService.tenantData;
  }
  tenantData: any;

  getOwnerId() {
    this.activatedRoute.paramMap.subscribe((params) => {
      this.ownerId = params.get('id');
      // console.log(this.ownerId, 'owner');
      if (this.ownerId) {
        this.getOwnerDetails(this.ownerId);
      }
    });
  }
  getOwnerDetails(id: any) {
    // debugger;
    this.storeService.getCompanyById(id).subscribe(
      (res) => {
        // debugger;
        this.setFormValue(res);
      },
      (err: any) => {
        if (err.status == 500) {
          this.toster.error('Internal server error  Status:500');
        }
      }
    );
  }
  getTitle() {
    this.storeService.getTitle().subscribe((data: any) => {
      this.title = data.data;
    });
  }
  createForm() {
    this.ownerForm = this.fb.group({
      name: [
        '',
        Validators.compose([
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(200),
        ]),
      ],
      url: ['', Validators.maxLength(500)],
      note: ['', Validators.maxLength(100)],
      mcC_SICNumber: [
        '',
        Validators.compose([
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(20),
          Validators.pattern('^[A-Za-z0-9ñÑáéíóúÁÉÍÓÚ/s ]+$'),
        ]),
      ],
      addresses: this.fb.array([this.createAddressForm()]),
      phones: this.fb.array([this.createPhoneForm()]),
      emails: this.fb.array([this.createEmailForm()]),
      // owners: this.fb.group({
      //   userId: [0],
      //   title: ['', Validators.required],
      //   firstName: [
      //     '',
      //     Validators.compose([
      //       Validators.required,

      //       Validators.pattern('[a-zA-Z- /S]+$'),
      //     ]),
      //   ],
      //   lastName: [
      //     '',
      //     Validators.compose([
      //       Validators.required,

      //       Validators.pattern('[a-zA-Z- /S]+$'),
      //     ]),
      //   ],
      //   designationId: [1],
      //   companyId: [0],
      //   storeId: [0],
      //   managerId: [0],
      //   regionId: [0],
      //   userName: this.ownerId ? [''] : [''],
      //   password: this.ownerId
      //     ? ['']
      //     : [
      //         '',
      //         Validators.compose([
      //           Validators.pattern(
      //             '(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-zd$@$!%*?&].{7,}'
      //           ),
      //         ]),
      //       ],
      //   addresses: this.fb.array([this.createAddressForm()]),
      //   phones: this.fb.array([]),
      //   emails: this.fb.array([]),
      // }),
    });
  }
  hide = true;

  get passwordInput() {
    return this.ownerForm.get('owners.password');
  }
  setFormValue(data: any) {
    // debugger;
    this.ownerForm.patchValue({
      // id: data.id,
      name: data.name,
      url: data.url,
      note: data.note,
      mcC_SICNumber: data.mcC_SICNumber,
    });
    if (data.owners) {
      this.ownerForm.patchValue({
        owners: {
          userId: data.owners.userId,
          title: data.owners.title,
          firstName: data.owners.firstName,
          lastName: data.owners.lastName,
          designationId: data.owners.designationId,
          companyId: data.owners.companyId,
          storeId: data.owners.storeId,
          managerId: data.owners.managerId,
          regionId: data.owners.regionId,
          userName: data.owners.userName,
          password: data.owners.password,
        },
      });
      data.owners.phones.forEach((element: any, index: any) => {
        if (index < data.owners.phones.length) {
          this.addAnotherOwnerPhone();
        }
        this.ownerPhones.controls[index].patchValue(element);
      });
      data.owners.emails.forEach((element: any, index: any) => {
        if (index < data.owners.emails.length) {
          // console.log('email patched ', element);
          this.addAnotherOwnerEmail();
        }
        this.ownerEmails.controls[index].patchValue(element);
      });

      data.owners.addresses.forEach((element: any, index: any) => {
        if (index < data.owners.addresses.length - 1) {
          this.addAnotherOwnerAddress();
        }
        this.ownerAddresses.controls[index].patchValue(element);
      });
    }

    data.phones.forEach((element: any, index: any) => {
      // debugger;
      if (index < data.phones.length - 1) {
        this.addAnotherPhone();
      }
      this.phones.controls[index].patchValue(element);
    });
    data.emails.forEach((element: any, index: any) => {
      if (index < data.emails.length - 1) {
        this.addAnotherEmail();
      }
      this.emails.controls[index].patchValue(element);
    });

    data.addresses.forEach((element: any, index: any) => {
      // debugger;
      if (index < data.addresses.length - 1) {
        this.addAnotherAddress();
      }
      if (element.countryId) {
        this.storeService
          .getStates(element.countryId)
          .subscribe((data: any) => {
            this.state = data.data;
            // this.city = null;
          });
      } else {
        this.state = null;
        // this.city = null;
      }
      this.addresses.controls[index].patchValue(element);
    });

    //patch owner emails ,address and phones
  }
  countryCode: any;
  countryChange(value: any) {
    // console.log(value);
    this.countryCode = value;
  }
  comm: any;
  copyAddressIntoOwnerAddress(checked: any) {
    this.sameAddress = checked;
    if (checked) {
      this.ownerAddresses.clear();
      this.addresses.controls.forEach((element, index: any) => {
        if (index < this.addresses.length) {
          this.addAnotherOwnerAddress();
        }
        this.ownerAddresses.controls[index].patchValue(element.value);
      });
    }
  }

  createPhoneForm() {
    return this.fb.group({
      phoneId: [0],
      categoryTypeLevelId: [null, Validators.required],
      areaCode: [null],
      number: [
        '',
        Validators.compose([
          Validators.required,
          Validators.maxLength(20),
          Validators.pattern('[- +()0-9]+'),
          RxwebValidators.unique(),
        ]),
      ],
      countryCode: ['+1', Validators.required],
    });
  }
  createOwnerPhoneForm() {
    return this.fb.group({
      phoneId: [0],
      categoryTypeLevelId: [null, Validators.required],
      areaCode: [null],
      number: [
        '',
        Validators.compose([
          Validators.maxLength(20),
          Validators.pattern('[- +()0-9]+'),
          Validators.required,
          RxwebValidators.unique(),
        ]),
      ],
      countryCode: ['+1'],
    });
  }
  addAnotherPhone() {
    this.phones.push(this.createPhoneForm());
  }

  removePhone(i: any) {
    // let i = this.phones.length - 1;
    this.phones.removeAt(i);
  }
  addAnotherOwnerPhone() {
    this.ownerPhones.push(this.createOwnerPhoneForm());
  }

  removeOwnerPhone(i: any) {
    // let i = this.ownerPhones.length - 1;
    this.ownerPhones.removeAt(i);
  }
  createAddressForm() {
    return this.fb.group({
      addressId: [0],
      categoryTypeLevelId: ['', Validators.required],
      addressLine1: [
        '',
        Validators.compose([Validators.required, Validators.maxLength(500)]),
      ],
      addressLine2: ['', Validators.maxLength(500)],
      countryId: [null, Validators.required],
      stateId: [null, Validators.required],
      city: [
        '',
        Validators.compose([Validators.required, Validators.maxLength(20)]),
      ],
      zipCode: [
        '',
        Validators.compose([
          Validators.required,
          Validators.maxLength(6),
          Validators.pattern('[- +()0-9]+'),
        ]),
      ],
      longitude: [null],
      latitude: [null],
    });
  }
  addAnotherAddress() {
    this.addresses.push(this.createAddressForm());
  }
  removeAddress(i: any) {
    // let i = this.addresses.length - 1;
    this.addresses.removeAt(i);
  }
  addAnotherOwnerAddress() {
    this.ownerAddresses.push(this.createAddressForm());
  }
  removeOwnerAddress(i: any) {
    // let i = this.ownerAddresses.length - 1;
    this.ownerAddresses.removeAt(i);
  }

  createEmailForm() {
    return this.fb.group({
      emailId: [0],
      categoryTypeLevelId: ['', Validators.required],
      email: [
        '',
        Validators.compose([
          Validators.required,
          Validators.minLength(2),
          Validators.email,
        ]),
      ],
    });
  }
  createOwnerEmailForm() {
    return this.fb.group({
      emailId: [0],
      categoryTypeLevelId: ['', Validators.required],
      email: [
        '',
        Validators.compose([
          Validators.minLength(2),
          Validators.email,
          Validators.required,
        ]),
      ],
    });
  }
  addAnotherEmail() {
    this.emails.push(this.createEmailForm());
    if (this.emailcategory.length == this.emails.length) {
      var DATA = document.getElementById('addemail');

      DATA!.style.display = 'none';
    }
  }
  removeEmail(i: any) {
    // let i = this.emails.length - 1;
    this.emails.removeAt(i);
    var DATA = document.getElementById('addemail');
    DATA!.style.display = '';
  }
  isControlExist(categoryTypeLevelId: any): boolean {
    for (var i = 0; i < this.emails.controls.length; i++) {
      if (
        this.emails.controls[i].value.categoryTypeLevelId == categoryTypeLevelId
      ) {
        return true;
      }
    }

    return false;
  }

  onCopyClick(emailIndex: any) {
    const emailCopy = this.emails.controls[emailIndex].value.email;

    if (!this.emails.controls[emailIndex].valid) {
      this.toster.error('Please enter a valid email before copy');
      return;
    }
    for (var i = 0; i < this.emails.controls.length; i++) {
      if (this.emails.controls[i].value.categoryTypeLevelId <= 0) {
        this.toster.error('Please remove blank category before copy');
        return;
      }
    }

    this.emailcategory.forEach((emailCat: any, index: any) => {
      if (!this.isControlExist(emailCat.id)) {
        if (this.emails.controls.length < this.emailcategory.length) {
          this.addAnotherEmail();
          this.emails.controls[this.emails.controls.length - 1].patchValue({
            categoryTypeLevelId: emailCat.id,
            email: emailCopy,
          });
        }
      } else {
        for (var i = 0; i < this.emails.controls.length; i++) {
          this.emails.controls[i].patchValue({
            email: emailCopy,
          });
        }
      }
    });
  }
  addAnotherOwnerEmail() {
    this.ownerEmails.push(this.createOwnerEmailForm());
  }
  removeOwnerEmail(i: any) {
    // let i = this.ownerEmails.length - 1;
    this.ownerEmails.removeAt(i);
  }

  getAddressCategoryLevel() {
    this.storeService.getCategoryLavelAddress(3).subscribe(
      (data: any) => {
        this.addressCategory = data.data;
      },
      (err) => {
        // this.loading = false;
        // this.err = err.message;
        this._snackBar.open(err.message);
        // console.log(err, 'errrrrrrrrrr');
      }
    );
  }
  phoneCategory() {
    this.storeService.getCategoryLevelPhone(8).subscribe(
      (data: any) => {
        this.phonecategory = data.data;
      },
      (err) => {
        // this.loading = false;
        // this.err = err.message;
        this._snackBar.open(err.message);
      }
    );
  }
  getEmailCategoryLevel() {
    this.storeService.getCategoryLevelEmail(5).subscribe(
      (data: any) => {
        this.emailcategory = data.data;
      },
      (err) => {
        // this.loading = false;
        // this.err = err.message;
        this._snackBar.open(err.message);
      }
    );
  }
  getCountry() {
    this.storeService.getCountry().subscribe((data: any) => {
      this.countries = data.data;
    });
  }

  onChangeCountry(countryId: number) {
    if (countryId) {
      this.storeService.getStates(countryId).subscribe((data: any) => {
        this.state = data.data;
        // this.city = null;
      });
    } else {
      this.state = null;
      // this.city = null;
    }
  }

  // cancelButton() {
  //   this.router.navigateByUrl('/admin/stores-owner');
  // }
  submit() {
    this.submitted = true;
    if (this.ownerForm.invalid) return;

    if (this.ownerId) {
      this.updateOwner();
    } else {
      this.createOwner();
    }
  }
  userAddress: string = '';
  userLatitude: any;
  userLongitude: any;
  userAddress2: string = '';

  handleAddressChange(address: any, i: any) {
    this.userAddress = address.formatted_address;
    this.userLatitude = address.geometry.location.lat();
    this.userAddress2 = address.vicinity;
    this.userLongitude = address.geometry.location.lng();
    this.address.at(i).patchValue({
      addressLine1: this.userAddress,
      addressLine2: this.userAddress2,
      latitude: this.userLatitude,
      longitude: this.userLongitude,
    });
  }
  handleOwnerAddressChange(address: any, i: any) {
    this.userAddress = address.formatted_address;
    this.userLatitude = address.geometry.location.lat();
    this.userAddress2 = address.vicinity;
    this.userLongitude = address.geometry.location.lng();
    this.ownerAddress.at(i).patchValue({
      addressLine1: this.userAddress,
      addressLine2: this.userAddress2,
      latitude: this.userLatitude,
      longitude: this.userLongitude,
    });
  }
  get address() {
    return this.ownerForm.get('addresses') as FormArray;
  }
  get ownerAddress() {
    return this.ownerForm.get('owners.addresses') as FormArray;
  }
  createOwner() {
    // console.log(this.ownerForm.value);
    this.submitted = true;
    if (this.ownerForm.invalid) return;

    this.loading = true;
    this.storeService.createOwner({ ...this.ownerForm.value }).subscribe(
      (res) => {
        this.loading = false;
        this.toster.success('Company created successfully!');
        this.ownerForm.reset();
        this.submitted = false;
        this.onClickBack();
        // console.log(res);
      },
      (err) => {
        this.loading = false;

        if (err.error.errors.CompanyName) {
          err.error.errors.CompanyName.forEach((err: any) => {
            this.toster.error(err, '', {
              // positionClass: 'toast-top-center',
              timeOut: 10000,
            });
          });
        }
        if (err.error.errors.CategoryLevel) {
          err.error.errors.CategoryLevel.forEach((err: any) => {
            this.toster.error(err, '', {
              // positionClass: 'toast-top-center',
              timeOut: 10000,
            });
          });
        }
        if (err.status == 500) {
          this.toster.error('Internal server error  Status:500');
        }
        if (err.error.errors.UserName) {
          err.error.errors.UserName.forEach((err: any) => {
            this.toster.error(err, '', {
              // positionClass: 'toast-top-center',
              timeOut: 10000,
            });
          });
        }
      }
    );
  }
  // createOwner() {
  //   // console.log(this.ownerForm.value);

  //   let URL = `${environment.mobile_url}${CREATE_OWNER}`;
  //   this.loading = true;
  //   this.subs.add(
  //     this.request.POST(URL, { ...this.ownerForm.value }).subscribe(
  //       (res) => {
  //         this.loading = false;
  //         this._snackBar.open('Company  Update Successfuly');
  //         this.ownerForm.reset();
  //         this.submitted = false;
  //         this.router.navigateByUrl('/admin/stores-owner');
  //         // console.log(res);
  //       },
  //       (err) => {
  //         this.loading = false;
  //         if (err.status == 400) {
  //           this._snackBar.open('validation errors occurred');
  //         }
  //         if (err.errors.CompanyName) {
  //         err.errors.CompanyName.forEach((err: any) => {
  //           // console.log(err, 'hhhhhherrr');
  //           this._snackBar.open(err);
  //         });
  //         }
  //         if (err.errors.UserName) {
  //           err.errors.UserName.forEach((err: any) => {
  //             // console.log(err, 'hhhhhherrr');
  //             this._snackBar.open(err);
  //           });
  //         }
  //         console.log(err);
  //       }
  //     )
  //   );
  // }
  updateOwner() {
    this.submitted = true;
    if (this.ownerForm.invalid) return;
    this.storeService
      .updateOwner({ ...this.ownerForm.value, id: this.ownerId })
      .subscribe(
        (res) => {
          this.loading = false;
          this.toster.success('Company updated successfully!');
          this.onClickBack();
          // console.log(res);
        },
        (err) => {
          this.loading = false;
          if (err.error.errors.CompanyName) {
            err.error.errors.CompanyName.forEach((err: any) => {
              this.toster.error(err, '', {
                // positionClass: 'toast-top-center',
                timeOut: 10000,
              });
            });
          }
          if (err.error.errors.Email) {
            err.error.errors.Email.forEach((err: any) => {
              this.toster.error(err);
            });
          }
          if (err.error.errors.Number) {
            err.error.errors.Number.forEach((err: any) => {
              this.toster.error(err);
            });
          }
          if (err.error.errors.CategoryLevel) {
            err.error.errors.CategoryLevel.forEach((err: any) => {
              this.toster.error(err, '', {
                timeOut: 10000,
              });
            });
          }
          if (err.error.errors.UserName) {
            err.error.errors.UserName.forEach((err: any) => {
              this.toster.error(err, '', {
                // positionClass: 'toast-top-center',
                timeOut: 10000,
              });
            });
          }
        }
      );
  }
  onClickBack() {
    this._location.back();
  }
  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }
}
