import { Location } from '@angular/common';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { RxwebValidators } from '@rxweb/reactive-form-validators';
import { debounce } from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { GasPumpService } from 'src/app/dashboard/api-service/gasPump.service';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
import { RequestService } from 'src/app/dashboard/api-service/request-service/request.service';
import { StoreService } from 'src/app/dashboard/api-service/storeService';

import { UserService } from 'src/app/dashboard/api-service/userService';
import { SharedService } from 'src/app/dashboard/auth/shared.service';

import { environment } from 'src/environments/environment';
import { SubSink } from 'subsink';

@Component({
  selector: 'app-add-edit-store',
  templateUrl: './add-edit-store.component.html',
  styleUrls: ['./add-edit-store.component.scss'],
})
export class AddEditStoreComponent implements OnInit {
  @Output() buttonClicked: EventEmitter<any> = new EventEmitter<any>();
  addStoreForm!: FormGroup;
  addressCategory: any;
  emailcategory: any;
  phonecategory: any;
  countries: any;
  title: any;
  submitted: boolean = false;
  loading: boolean = false;
  checked = true;
  state: any;
  // city: any = null;
  subs = new SubSink();
  storeId: any = null;
  companyId: any = null;
  posDetails: any;
  timeZoneDetails: any;
  Amenity: any;
  myModel: boolean = true;
  saleAgentData: any;
  firstLastName: string = '';
  mobile: string = '';
  email: string = '';
  pageIndex: number = 1;
  pageSize: number = 50;
  storeName: string = '';
  sortBy = 'saleAgentId';
  sortOrder: string = 'desc';
  companyID: any;
  // for accessing form controls
  get f() {
    return this.addStoreForm.controls;
  }

  get phones() {
    return this.addStoreForm.get('phones') as FormArray;
  }
  get addresses() {
    return this.addStoreForm.get('addresses') as FormArray;
  }

  get emails() {
    return this.addStoreForm.get('emails') as FormArray;
  }
  get amenities() {
    return this.addStoreForm.get('amenities') as FormArray;
  }

  constructor(
    private fb: FormBuilder,
    private storeService: StoreService,
    private userService: UserService,
    private posService: GasPumpService,
    private router: Router,
    private request: RequestService,
    private activatedRoute: ActivatedRoute,
    private toster: ToastrService,
    private _location: Location,
    private spinner: NgxSpinnerService,
    public SharedService: SharedService,
    private indentityService: IdentityService
  ) {}

  ngOnInit(): void {
    this.createForm();
    this.getTenant();
    this.getAmenity();
    this.getCountry();
    this.getTitle();
    this.getEmailCategoryLevel();
    this.phoneCategory();
    this.getAddressCategoryLevel();
    this.getStoreId();
    this.getRegion();
    this.getManager();
    this.getSaleAgent();
    this.getStoreCategory();
    this.storeService.getTimeZone().subscribe((data: any) => {
      this.timeZoneDetails = data.data;
    });
  }
  appDetails: any = [];
  getTenant() {
    this.indentityService.getTenantMasterList().subscribe((data: any) => {
      this.appDetails = data;
    });
  }
  
  selctedAppIds: any = [];
  isAllSelected: boolean = false;
  onClickSelectAllApp(event: any) {
    this.isAllSelected = true;
    // this.showStoreNames = false;
    if (event.isUserInput) {
      if (event.source.selected) {
        this.selctedAppIds = this.appDetails.map((app: any) => app.id);
      } else {
        this.selctedAppIds = [];
      }
      this.addStoreForm.get('appIds')?.patchValue(this.selctedAppIds);
    }
  }
  storeCategoryData: any;
  getStoreCategory() {
    this.storeService.getStoreCategory().subscribe((data: any) => {
      this.storeCategoryData = data.data;
    });
  }
  getSaleAgent() {
    this.storeService
      .saleAgent(
        this.firstLastName,
        this.mobile,
        this.email,
        this.storeName,
        this.pageIndex,
        this.pageSize,
        this.sortBy,
        this.sortOrder
      )
      .subscribe(
        (data: any) => {
          this.saleAgentData = data.data;
        },
        (err) => {
          if (err.status == 500) {
            this.toster.error('Internal server error');
          }
        }
      );
  }
  filterByName = debounce(($event: any) => {
    this.firstLastName = $event.target.value;
    this.pageIndex = 1;
    this.getSaleAgent();
  }, 1000);
  getStoreId() {
    this.activatedRoute.paramMap.subscribe((params) => {
      // console.log(params);
      this.storeId = params.get('id');
      // console.log(this.storeId);
      this.companyId = params.get('companyId');
      this.companyID = this.companyId;
      if (params.get('saleAgentId')) {
        this.storeId = params.get('companyId');
        this.companyId = null;
      }
      if (params.get('storeId') == ':storeId') {
        this.storeId = params.get('companyId');
        this.systemStatusRoute = true;
      }
      this.storeService.getPosSystem().subscribe((data: any) => {
        this.posDetails = data.data;
      });

      if (this.storeId) {
        this.getStoreDetails(this.storeId);
        this.SharedService.storeDataDetails.subscribe((data: any) => {});
      }
    });
  }
  systemStatusRoute: boolean = false;
  storeImages: any;

  // storeRes = {
  //   storeId: 0,
  //   storeName: 'string',
  //   siteId: 'string',
  //   storeUrl: 'string',
  //   mangerId: 0,
  //   regionId: 0,
  //   regionalManagerId: 0,
  //   posId: 0,
  //   posName: 'string',
  //   description: 'string',
  //   note: 'string',
  //   timeZoneId: 0,
  //   storeImage: 'string',
  //   isActive: true,
  //   companyId: 0,
  //   company: 'string',
  //   maxAuthorizeAmount: 0,
  //   status: true,
  //   enableBilling: true,
  //   consentCashReward: true,
  //   distance: 'string',
  //   isMasterStore: true,
  //   saleAgentId: 0,
  //   isTestStore: true,
  //   disableEod: true,
  //   disableBilling: true,
  //   createdOn: '2023-12-27T12:12:14.696Z',
  //   storeCategoryId: 0,
  //   storeCategory: 'string',
  //   isAchEnabled: true,
  //   enableACHLoyalty: true,
  //   enableCardLoyalty: true,
  //   loyaltyProgramId: 'string',
  //   addresses: [
  //     {
  //       addressId: 0,
  //       categoryTypeLevelId: 0,
  //       addressLine1: 'string',
  //       addressLine2: 'string',
  //       countryId: 0,
  //       country: 'string',
  //       stateId: 0,
  //       state: 'string',
  //       city: 'string',
  //       longitude: 0,
  //       latitude: 0,
  //       zipCode: 'string',
  //       isActive: true,
  //       companyId: 0,
  //       storeId: 0,
  //       userId: 0,
  //       saleAgentId: 0,
  //       resellerId: 0,
  //     },
  //   ],
  //   phones: [
  //     {
  //       phoneId: 0,
  //       categoryTypeLevelId: 0,
  //       countryCode: 'string',
  //       areaCode: 'string',
  //       number: 'string',
  //       isActive: true,
  //     },
  //   ],
  //   emails: [
  //     {
  //       emailId: 0,
  //       categoryTypeLevelId: 0,
  //       email: 'string',
  //       isActive: true,
  //     },
  //   ],
  //   amenities: [
  //     {
  //       storeAmenityId: 0,
  //       amenityId: 0,
  //       amenityName: 'string',
  //     },
  //   ],
  //   storeHours: [
  //     {
  //       name: 'string',
  //       openTime: 'string',
  //       closeTime: 'string',
  //       is24Hours: true,
  //     },
  //   ],
  //   pumpProducts: [
  //     {
  //       siteId: 'string',
  //       originalAmountUnitPrice: 0,
  //       unitMeasure: 'string',
  //       description: 'string',
  //       priceTier: 'string',
  //     },
  //   ],
  //   carWashTypes: [
  //     {
  //       carWashName: 'string',
  //       price: 0,
  //       storeId: 0,
  //     },
  //   ],
  //   appIds: [1, 2],
  // };
  getStoreDetails(id: any) {
    this.storeService.viewStoreSummery(id).subscribe(
      (res: any) => {
        this.setFormValue(res);
        this.storeImages = res.storeImage;
      },
      (err: any) => {}
    );
  }
  setFormValue(data: any) {
    console.log(data);
    // var appIds = data.appIds.map();
    this.companyID = data.companyId;

    this.posName = data.posName;
    if (Array.isArray(data.appIds)) {
      var appIds = data.appIds.map((id: any) => id);
      this.addStoreForm.patchValue({
        storeName: data.storeName,
        storeUrl: data.storeUrl,
        siteId: data.siteId,
        appIds: appIds,
        storeCategoryId: data.storeCategoryId,
        maxAuthorizeAmount: data.maxAuthorizeAmount,
        loyaltyProgramId: data.loyaltyProgramId,
        storeImage: data.storeImage ? '' : '',
        isActive: data.isActive,
        disableEod: data.disableEod,
        enableACHLoyalty: data.enableACHLoyalty,
        enableCardLoyalty: data.enableCardLoyalty,
        disableBilling: data.disableBilling,
        managerId: data.mangerId,
        regionId: data.regionId,
        saleAgentId: data.saleAgentId,
        consentCashReward: data.consentCashReward,
        regionManagerId: data.regionManagerId,
        posId: data.posId,
        posName: data.posName,
        description: data.description,
        note: data.note,
        timeZoneId: data.timeZoneId,
        companyId: data.companyId,
      });
    }
    console.log(appIds);

    // if (data.posId) {

    // }
    // if (data.storeImage) {
    //   this.addStoreForm.get('storeImage')?.patchValue('');
    // }
    data.phones.forEach((element: any, index: any) => {
      if (index < data.phones.length - 1) {
        this.addAnotherPhone();
      }
      this.phones.controls[index].patchValue(element);
    });
    data.emails.forEach((element: any, index: any) => {
      if (index < data.emails.length - 1) {
        this.addAnotherEmail();
      }
      this.emails.controls[index].patchValue(element);
    });

    data.addresses.forEach((element: any, index: any) => {
      if (index < data.addresses.length - 1) {
        this.addAnotherAddress();
      }
      if (element.countryId) {
        this.storeService
          .getStates(element.countryId)
          .subscribe((data: any) => {
            this.state = data.data;
          });
      } else {
        this.state = null;
      }
      this.addresses.controls[index].patchValue(element);
    });
    data.amenities.forEach((element: any, index: any) => {
      if (index < data.amenities.length - 1) {
        this.addAnotherAmenity();
      }
      this.amenities.controls[index].patchValue(element);
    });
  }
  getTitle() {
    this.storeService.getTitle().subscribe((data: any) => {
      this.title = data.data;
    });
  }
  countryCode: any;
  countryChange(value: any) {
    // console.log(value);
    this.countryCode = value;
  }
  createForm() {
    this.addStoreForm = this.fb.group({
      storeName: ['', Validators.required],
      storeUrl: [''],
      siteId: ['', Validators.required],
      appIds: [[]],
      maxAuthorizeAmount: [
        '',
        Validators.compose([Validators.required, Validators.pattern('[0-9]+')]),
      ],
      loyaltyProgramId: [''],
      storeImage: [''],
      storeCategoryId: new FormControl(null, Validators.required),
      isActive: true,
      managerId: [0],
      regionId: [0],
      saleAgentId: [0],
      regionManagerId: [0],
      posId: [0],
      posName: [''],
      description: [''],
      disableEod: false,
      disableBilling: false,
      enableACHLoyalty: false,
      enableCardLoyalty: false,
      note: [''],

      consentCashReward: [true],
      timeZoneId: ['', Validators.required],
      companyId: [Validators.required],
      addresses: this.fb.array([this.createAddressForm()]),
      phones: this.fb.array([this.createPhoneForm()]),
      emails: this.fb.array([this.createEmailForm()]),
      amenities: this.fb.array([this.createAmenityForm()]),
    });
  }
  createAmenityForm() {
    return this.fb.group({
      storeAmenityId: [0],
      amenityId: ['', Validators.required],
    });
  }
  addAnotherAmenity() {
    this.amenities.push(this.createAmenityForm());
  }

  removeAmenity() {
    let i = this.amenities.length - 1;
    this.amenities.removeAt(i);
  }

  getAmenity() {
    this.storeService.getStoreAmenities().subscribe((data: any) => {
      this.Amenity = data.data;
      // console.log(this.Amenity, 'Amenity')
    });
  }

  region: any;
  getRegion() {
    this.storeService.getRegion().subscribe((data: any) => {
      this.region = data.data;
    });
  }
  managerName: any;
  getManager() {
    this.userService.findAllUser().subscribe((data: any) => {
      this.managerName = data.data;
      // console.log(this.managerName, 'manager name')
    });
  }
  posName: any;

  createPhoneForm() {
    return this.fb.group({
      phoneId: [0],
      categoryTypeLevelId: ['', Validators.required],
      areaCode: [''],
      number: [
        '',
        Validators.compose([
          Validators.required,
          Validators.pattern('[- +()0-9]+'),
          RxwebValidators.unique(),
        ]),
      ],
      countryCode: ['+1', Validators.required],
    });
  }

  addAnotherPhone() {
    this.phones.push(this.createPhoneForm());
  }

  removePhone(i: any) {
    // let i = this.phones.length - 1;
    this.phones.removeAt(i);
  }

  createAddressForm() {
    return this.fb.group({
      addressId: [0],
      categoryTypeLevelId: ['', Validators.required],
      addressLine1: ['', Validators.required],
      addressLine2: [''],
      countryId: ['', Validators.required],
      stateId: ['', Validators.required],
      city: ['', Validators.required],
      zipCode: [
        '',
        Validators.compose([
          Validators.required,
          Validators.pattern('[- +()0-9]+'),
        ]),
      ],
      longitude: [null],
      latitude: [null],
    });
  }
  addAnotherAddress() {
    this.addresses.push(this.createAddressForm());
  }
  removeAddress(i: any) {
    // let i = this.addresses.length - 1;
    this.addresses.removeAt(i);
  }

  createEmailForm() {
    return this.fb.group({
      emailId: [0],
      categoryTypeLevelId: ['', Validators.required],
      email: ['', Validators.required],
    });
  }
  addAnotherEmail() {
    this.emails.push(this.createEmailForm());
    if (this.emailcategory.length == this.emails.length) {
      var DATA = document.getElementById('addemail');

      DATA!.style.display = 'none';
    }
  }
  removeEmail(i: any) {
    // let i = this.emails.length - 1;
    this.emails.removeAt(i);
    var DATA = document.getElementById('addemail');
    DATA!.style.display = '';
  }
  isControlExist(categoryTypeLevelId: any): boolean {
    for (var i = 0; i < this.emails.controls.length; i++) {
      if (
        this.emails.controls[i].value.categoryTypeLevelId == categoryTypeLevelId
      ) {
        return true;
      }
    }

    return false;
  }

  onCopyClick(emailIndex: any) {
    const emailCopy = this.emails.controls[emailIndex].value.email;

    if (!this.emails.controls[emailIndex].valid) {
      this.toster.error('Please enter a valid email before copy');
      return;
    }
    for (var i = 0; i < this.emails.controls.length; i++) {
      if (this.emails.controls[i].value.categoryTypeLevelId <= 0) {
        this.toster.error('Please remove blank category before copy');
        return;
      }
    }

    this.emailcategory.forEach((emailCat: any, index: any) => {
      if (!this.isControlExist(emailCat.id)) {
        if (this.emails.controls.length < this.emailcategory.length) {
          this.addAnotherEmail();
          this.emails.controls[this.emails.controls.length - 1].patchValue({
            categoryTypeLevelId: emailCat.id,
            email: emailCopy,
          });
        }
      } else {
        for (var i = 0; i < this.emails.controls.length; i++) {
          this.emails.controls[i].patchValue({
            email: emailCopy,
          });
        }
      }
    });
  }
  getAddressCategoryLevel() {
    this.storeService.getCategoryLavelAddress(2).subscribe((data: any) => {
      this.addressCategory = data.data;
    });
  }
  phoneCategory() {
    this.storeService.getCategoryLevelPhone(9).subscribe((data: any) => {
      this.phonecategory = data.data;
    });
  }
  getEmailCategoryLevel() {
    this.storeService.getCategoryLevelEmail(6).subscribe((data: any) => {
      this.emailcategory = data.data;
    });
  }
  getCountry() {
    this.storeService.getCountry().subscribe((data: any) => {
      this.countries = data.data;
    });
  }

  onChangeCountry(countryId: number) {
    if (countryId) {
      this.storeService.getStates(countryId).subscribe((data: any) => {
        this.state = data.data;
      });
    } else {
      this.state = null;
    }
  }

  dragging: boolean = false;
  loaded: boolean = false;
  imageLoaded: boolean = false;
  imageSrc: string = '';
  url: any;
  uploadImage: boolean = true;
  handleInputChange(e: any) {
    // console.log(e, "input change")
    var file = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];

    var pattern = /image-*/;
    var reader = new FileReader();

    if (!file.type.match(pattern)) {
      alert('invalid format');
      return;
    }

    this.loaded = false;

    reader.onload = this._handleReaderLoaded.bind(this);

    reader.readAsDataURL(file);
  }

  _handleReaderLoaded(e: any) {
    // console.log(e, "_handleReaderLoaded")
    var reader = e.target;
    this.url = e.target.result;
    if (this.url) {
      this.uploadImage = false;
    }
    this.imageSrc = reader.result.split(',')[1];

    this.addStoreForm.get('storeImage')?.setValue(this.imageSrc);
    // console.log(this.imageSrc, 'imgsrc');
    this.loaded = true;
  }
  cancelButton() {
    this.router.navigateByUrl('/admin/stores-owner');
  }
  userAddress: string = '';
  userLatitude: any;
  userLongitude: any;
  userAddress2: string = '';

  handleAddressChange(address: any, i: any) {
    this.userAddress = address.formatted_address;
    this.userLatitude = address.geometry.location.lat();
    this.userAddress2 = address.vicinity;

    this.userLongitude = address.geometry.location.lng();

    this.address.at(i).patchValue({
      addressLine1: this.userAddress,
      city: this.userAddress2,
      latitude: this.userLatitude,
      longitude: this.userLongitude,
    });
  }

  get address() {
    return this.addStoreForm.get('addresses') as FormArray;
  }
  get ownerAddress() {
    return this.addStoreForm.get('owners.addresses') as FormArray;
  }
  submit() {
    // console.log(this.addStoreForm.value);
    this.submitted = true;
    if (this.addStoreForm.invalid) return;
    if (this.storeId) {
      this.updateStore();
    }
    if (this.companyId) {
      this.createStore();
    }
  }

  createStore() {
    this.loading = true;
    this.storeService
      .addStore({ ...this.addStoreForm.value, companyId: this.companyId })
      .subscribe(
        (res) => {
          this.loading = false;
          this.toster.success('Store created successfully!');
          this.addStoreForm.reset();
          this.onClickBack();
          // console.log(res);
        },
        (err) => {
          this.loading = false;
          // console.log(err, 'err');
          if (err.error.status == 500) {
            this.toster.error('Internal Server error status:500');
          }
          // if (err.status == 400) {
          //   this.toster.error('validation errors occurred', '', {
          //     // positionClass: 'toast-top-center',
          //     timeOut: 10000,
          //   });
          // }
          // this._snackBar.open(err.name);
          // console.log(err);
          if (err.error.errors.SiteId) {
            err.error.errors.SiteId.forEach((err: any) => {
              this.toster.error(err, '', {
                // positionClass: 'toast-top-center',
                timeOut: 10000,
              });
            });
          }
          if (err.error.errors.CategoryLevel) {
            err.error.errors.CategoryLevel.forEach((err: any) => {
              this.toster.error(err, '', {
                // positionClass: 'toast-top-center',
                timeOut: 10000,
              });
            });
          }
          if (err.error.errors.StoreImage) {
            err.error.errors.StoreImage.forEach((err: any) => {
              this.toster.error(err, '', {
                // positionClass: 'toast-top-center',
                timeOut: 10000,
              });
            });
          }
        }
      );
    // let URL = `${environment.mobile_url}${CREATE_OWNER}`;
    // this.loading = true;
    // this.subs.add(
    //   this.request.POST(URL, { ...this.addStoreForm.value }).subscribe(
    //     (res) => {
    //       this.loading = false;
    //       this._snackBar.open("update successfuly");
    //       this.addStoreForm.reset();
    //       console.log(res);
    //     },
    //     (err) => {
    //       this.loading = false;
    //       console.log(err);
    //     }
    //   )
    // );
  }

  updateStore() {
    this.loading = true;
    this.storeService
      .updateEditStoreForm({
        ...this.addStoreForm.value,
        storeId: this.storeId,
      })
      .subscribe(
        (res) => {
          this.loading = false;
          this.toster.success('Store updated Successfully!');
          this.onClickBack();
          // console.log(res);
        },
        (err) => {
          this.loading = false;
          // console.log(err);
          if (err.error.status == 500) {
            this.toster.error('Internal Server error status:500');
          }
          if (err.error.errors.CategoryLevel) {
            err.error.errors.CategoryLevel.forEach((err: any) => {
              this.toster.error(err, '', {
                // positionClass: 'toast-top-center',
                timeOut: 10000,
              });
            });
          }
          // console.log(err.error, 'err');
          if (err.error.errors.StoreImage) {
            err.error.errors.StoreImage.forEach((err: any) => {
              this.toster.error(err, '', {
                // positionClass: 'toast-top-center',
                timeOut: 10000,
              });
            });
          }
          if (err.error.errors.SiteId) {
            err.error.errors.SiteId.forEach((err: any) => {
              this.toster.error(err, '', {
                // positionClass: 'toast-top-center',
                timeOut: 10000,
              });
            });
          }
        }
      );
  }

  onChangePos(event: any) {
    // console.log(event);
    this.addStoreForm.get('posId')?.patchValue(event.posId);
    this.addStoreForm.get('posName')?.patchValue(event.posName);
  }
  showElement: string = 'back';
  onClickBack() {
    this._location.back();
  }
  getDataText(id: any) {
    const result = this.posDetails.filter((x: any) => x.posName === id);
    // console.log(id);
    return result;
  }
  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }
}
