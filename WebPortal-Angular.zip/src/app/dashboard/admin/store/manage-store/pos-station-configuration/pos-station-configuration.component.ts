import { Location } from '@angular/common';
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { GasPumpService } from 'src/app/dashboard/api-service/gasPump.service';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
import { StoreService } from 'src/app/dashboard/api-service/storeService';
import { AuthService } from 'src/app/dashboard/auth/auth.service';

export interface Pos {
  POSStationNo: string;
  systemID: string;
  networkType: string;
  port: string;
  stationIPAddress: string;
  qrCode: string;
  barCode: string;
  action: string;
}
@Component({
  selector: 'app-pos-station-configuration',
  templateUrl: './pos-station-configuration.component.html',
  styleUrls: ['./pos-station-configuration.component.scss'],
})
export class PosStationConfigurationComponent implements OnInit {
  @Input() storeDetail: any;
  checked = true;

  displayedColumns = [
    // 'posId',
    'stationNumber',
    'stationSystemId',
    'stationIPAddress',
    'networkType',
    'port',
    'action',
  ];
  dataSource = new MatTableDataSource<Pos>([]);

  constructor(
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private posService: GasPumpService,
    private toster: ToastrService,
    private auth: AuthService,
    private _location: Location,
    private identityServer: IdentityService
  ) {}
  posConfigurationForm!: FormGroup;
  storeId: any;
  dataArray: any;
  claims: any;
  claimIdArray: any;
  err: string = '';
  storeDetails: any;
  posName: any;
  posId: any;
  PosDetails: any;
  submitted: boolean = false;
  @ViewChild(MatSort) sort: MatSort;
  validPattern = '^[A-Za-z0-9ñÑáéíóúÁÉÍÓÚ/s ]+$';
  get f() {
    return this.posConfigurationForm.controls;
  }
  manageStoreRoute: boolean = false;
  ngOnInit(): void {
    this.storeDetails = this.storeDetail;
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.activatedRoute.params.subscribe((data: any) => {
      this.storeId = data.storeId;
    });
    this.activatedRoute.queryParamMap.subscribe((data: any) => {
      console.log(data);
      if (data.params.manageStore == 'manageStore') {
        this.manageStoreRoute = true;
      }
    });
    this.posConfigurationForm = this.formBuilder.group({
      storeId: new FormControl(this.storeId, Validators.required),
      stationNumber: new FormControl(
        '',
        Validators.compose([
          Validators.required,
          Validators.pattern(this.validPattern),
        ])
      ),
      stationSystemId: new FormControl(
        '',
        Validators.compose([Validators.pattern(this.validPattern)])
      ),
      stationIPAddress: new FormControl(''),
      networkType: new FormControl(
        '',
        Validators.compose([
          Validators.required,
          Validators.pattern(this.validPattern),
        ])
      ),
      port: new FormControl(
        '',
        Validators.compose([
          Validators.required,
          Validators.pattern(this.validPattern),
        ])
      ),
      qrCode: new FormControl(null),
      barCode: new FormControl(null),
    });
    this.getPos();
    // this.getTenantId();
  }
  // tenantData: any;
  // getTenantId() {
  //   this.identityServer.getTantetId().subscribe((data: any) => {
  //     this.tenantData = data.data;
  //   });
  // }
  getPos() {
    const _id: number = this.storeId as number;
    this.posService.getPos(_id).subscribe((data: any) => {
      this.dataArray = data;
      this.dataSource = new MatTableDataSource(this.dataArray.data);
      this.dataSource.sort = this.sort;
      //  console.log(this.dataSource,'posdetails')
    });
  }

  onClickEdit(posId: any) {
    this.posId = posId;

    this.posService
      .getPosById(posId)
      .toPromise()
      .then((data: any) => {
        // console.log(data, 'posdata');
        this.posConfigurationForm.patchValue({
          storeId: data.storeId,
          stationNumber: data.stationNumber,
          stationSystemId: data.stationSystemId,
          stationIPAddress: data.stationIPAddress,
          networkType: data.networkType,
          port: data.port,
          qrCode: null,
          barCode: null,
        });
      });
  }

  submit() {
    this.submitted = true;
    if (!this.posId) {
      this.posConfig();
    }
    if (this.posId) {
      this.updatePos();
    }
  }
  posConfig() {
    this.submitted = true;
    if (this.posConfigurationForm.invalid) return;
    this.posService
      .posConfiguration(this.posConfigurationForm.value)
      .subscribe((data: any) => {
        if (data == data) {
          this.toster.success('POS configuration created successfuly!');
          this.posConfigurationForm.reset();

          this.getPos();
        }
      });
  }
  updatePos() {
    this.submitted = true;
    if (this.posConfigurationForm.invalid) return;
    this.posService
      .updatePos({ ...this.posConfigurationForm.value, posId: this.posId })
      .subscribe((data: any) => {
        this.toster.success('POS configuration updated successfuly!');
        this.posConfigurationForm.reset();
        this.getPos();
      });
  }
  onClickBack() {
    this._location.back();
  }
}
