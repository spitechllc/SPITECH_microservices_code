import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PosStationConfigurationComponent } from './pos-station-configuration.component';

describe('PosStationConfigurationComponent', () => {
  let component: PosStationConfigurationComponent;
  let fixture: ComponentFixture<PosStationConfigurationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PosStationConfigurationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PosStationConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
