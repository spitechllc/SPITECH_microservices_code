import { Component, Injectable, Input, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { PaymentService } from 'src/app/dashboard/api-service/payment.srvice';
import { StoreService } from 'src/app/dashboard/api-service/storeService';
import { AuthService } from 'src/app/dashboard/auth/auth.service';
import { environment } from 'src/environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import { ToastrService } from 'ngx-toastr';
import { Location } from '@angular/common';
@Component({
  selector: 'app-payment-configuration',
  templateUrl: './payment-configuration.component.html',
  styleUrls: ['./payment-configuration.component.scss'],
})
export class PaymentConfigurationComponent implements OnInit {
  displayedColumns = [
    'storeId',
    'siteID',
    'accountNumber',
    'accountType',
    'isDefault',
  ];
  bankAccountNumber: string = '';
  isMasked: boolean = true;
  dataSource = new MatTableDataSource<TableDetails>([]);
  baseUrl: string = `${environment.base_url}payments/api/`;
  @Input() storeDetail: any = {};
  myModel = true;
  checked = true;
  storeId: any;
  storeDetails: any = {};
  paymentMethodDetails: any;
  claimIdArray: any;
  err: string = '';
  paymentAccountNumber: any;
  constructor(
    private paymentService: PaymentService,
    private storeService: StoreService,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private _snakebar: MatSnackBar,
    private auth: AuthService,
    private domSanitizer: DomSanitizer,
    private tosterService: ToastrService,
    private _location: Location
  ) { }
  paymentConfigurationForm!: FormGroup;
  paymentConfigurationDetails: any;
  submitted: boolean = false;
  get f() {
    return this.paymentConfigurationForm.controls;
  }
  manageStoreRoute: boolean = false;
  ngOnInit(): void {
    this.storeDetails = this.storeDetail;
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.activatedRoute.params.subscribe((data: any) => {
      console.log(data);
      this.storeId = data.storeId;
      //this.getPaymetAccount();
      if (this.storeId) {
        //this.getPaymetConfig();
        this.getPaymetAccount()
      }
    });
    this.activatedRoute.queryParamMap.subscribe((data: any) => {
      // console.log(data);
      if (data.params.manageStore == 'manageStore') {
        this.manageStoreRoute = true;
      }
    });
    this.paymentConfigForm();
  }
  achAccontDetails: any;
  documentId: any;
  isBeneficialOwnerCertified: any;
  businessDocumentId: any;

  paymentConfigForm() {
    this.paymentConfigurationForm = this.formBuilder.group({
      storeId: new FormControl(this.storeId),
      paymentProcessorId: new FormControl('', Validators.required),
      accountName: new FormControl('', Validators.required),
      bank: new FormControl('', Validators.required),
      accountNo: new FormControl('', Validators.required),
      routingNo: new FormControl('', Validators.required),
      isChecking: true,
      isMasterAccount: false,
      isActive: true,
      isAchEnabled: true,
      // cardProcessorId: new FormControl(''),
      achProcessorId: new FormControl(''),
    });
  }

  achPageUrl: any;
  frameUrl: any;
  achclick: boolean = false;

  createDocumentFrameUrl: any;
  createDocumentFrame: boolean = false;

  checkStatusFrameUrl: any;
  checkStatuss: boolean = false;
  documentStatusData: any;

  certify: boolean = true;
  certifyBenficialOwner: any;

  closeModal() {
    this.achclick = false;
  }
  closeModalStatus() {
    this.checkStatuss = false;
  }
  closeModalCertify() {
    this.certify = false;
  }
  closeModalCreate() {
    this.createDocumentFrame = false;
  }

  toggleMaskAccount(): void {
    this.isMasked = !this.isMasked;
  }
  savePaymentConfig() {
    this.submitted = true;
    if (this.paymentConfigurationForm.invalid) return;
    this.paymentService
      .addPaymentConfig(this.paymentConfigurationForm.value)
      .subscribe((data: any) => {
        if (data) {
          this.tosterService.success(
            'Payment configuration save successfully!'
          );
        }

        this.getPaymetConfig();
      });
  }


  paymentConfigDetails: any;
  paymentAccountNumberDetail: any;

  getPaymetAccount() {
    this.paymentService.getPaymentAccount(this.storeId).subscribe((data:any)=>{
    this.paymentAccountNumberDetail=data.data;
      if (this.paymentAccountNumberDetail != null)
      {
        this.paymentAccountNumber= this.paymentAccountNumberDetail.accountNo;
        this.getPaymetConfig();
      }
      else{
        this.isMasked= false;
      }
    });
  }

  getPaymetConfig() {
    this.paymentService
      .getPaymentConfig(this.storeId)
      .subscribe((data: any) => {
        this.paymentConfigDetails = data.data;
        if (data.data !== null) {
          this.paymentConfigurationForm.patchValue({
            storeId: this.paymentConfigDetails.storeId,
            paymentProcessorId: this.paymentConfigDetails.paymentProcessorId,
            accountName: this.paymentConfigDetails.accountName,
            bank: this.paymentConfigDetails.bank,
            accountNo: this.paymentAccountNumber,
            //accountNo : this.paymentConfigDetails.accountNo,
            routingNo: this.paymentConfigDetails.routingNo,
            isChecking: this.paymentConfigDetails.isChecking,
            isMasterAccount: this.paymentConfigDetails.isMasterAccount,
            // cardProcessorId: this.paymentConfigDetails.cardProcessorId,
            isAchEnabled: this.paymentConfigDetails.isAchEnabled,
            achProcessorId: this.paymentConfigDetails.achProcessorId,
            isActive: this.paymentConfigDetails.isActive,
          });
        }
      });
  }
  onClickBack() {
    this._location.back();
  }
}

export interface TableDetails {
  storeId: number;
  siteID: string;
  accountNumber: string;
  accountType: string;
  isDefault: boolean;
}
