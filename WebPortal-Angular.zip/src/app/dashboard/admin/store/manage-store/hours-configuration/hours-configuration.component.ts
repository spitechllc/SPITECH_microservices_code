import { Location } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';

import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { StoreService } from 'src/app/dashboard/api-service/storeService';

@Component({
  selector: 'app-hours-configuration',
  templateUrl: './hours-configuration.component.html',
  styleUrls: ['./hours-configuration.component.scss'],
})
export class HoursConfigurationComponent implements OnInit {
  checked: boolean = false;
  @Input() storeDetail: any;
  constructor(
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private storeService: StoreService,
    private toster: ToastrService,
    private router: Router,
    private _location: Location
  ) {}
  storeId: any;
  storeHoursForm!: FormGroup;
  storeDetails: any;
  date: any;
  ngOnInit(): void {
    this.storeDetails = this.storeDetail;
    this.getStoreWeekday();
    this.getData();
    this.createForm();
    // this.viewStoreDetails();
  }
  manageStoreRoute: boolean = false;
  getData() {
    this.activatedRoute.params.subscribe((data: any) => {
      // console.log(data);
      this.storeId = data.storeId;
    });
    this.activatedRoute.queryParamMap.subscribe((data: any) => {
      console.log(data);
      if (data.params.manageStore == 'manageStore') {
        this.manageStoreRoute = true;
      }
    });
  }
  createForm() {
    this.storeHoursForm = this.formBuilder.group({
      is24Hours: new FormControl(this.checked),
      storeId: new FormControl(this.storeId),
      storeHours: this.formBuilder.array([]),
    });
  }

  get storeHoursFormGroups() {
    return this.storeHoursForm.get('storeHours') as FormArray;
  }
  weekdayname: any;
  addMoreStoreHours(data: any) {
    (<FormArray>this.storeHoursForm.get('storeHours')).push(
      this.formBuilder.group({
        storeHoursId: new FormControl(0),
        weekDayId: new FormControl(data.weekDayId),
        name: new FormControl(data.name),
        openTime: new FormControl(''),
        closeTime: new FormControl(''),
      })
    );
  }

  weekendayDetails: any;
  getStoreWeekday() {
    this.storeService.storeWeekenId().subscribe((data: any) => {
      this.weekendayDetails = data.data;
      this.weekendayDetails.forEach((element: any, key: number) => {
        this.addMoreStoreHours(element);
        this.weekdayname = element.name;
      });

      this.storeService
        .getStoreHoursByStoreId(this.storeId)
        .subscribe((data: any) => {
          this.setFormValue(data.data);
        });
    });
  }

  setFormValue(data: any) {
    this.storeHoursForm.patchValue({
      storeId: this.storeId,
    });

    data.forEach((element: any, index: any) => {
      this.storeHoursFormGroups.controls[index].patchValue(element);
      this.storeHoursId = element.storeHoursId;
      if (element.is24Hours == true) {
        this.storeHoursForm.patchValue({
          is24Hours: element.is24Hours,
        });
      }
    });
  }
  storeHoursId: any;
  cancelBtn() {
    this.router.navigateByUrl(`/admin/stores-owner`);
  }
  submit() {
    if (this.storeHoursId) {
      this.updateStoreWorkingHours();
    }
    if (!this.storeHoursId) {
      this.StoreWorkingHours();
    }
  }
  updateStoreWorkingHours() {
    this.storeService
      .updateSoreHour(this.storeHoursForm.value)
      .subscribe((data: any) => {
        this.toster.success('Store working hours updated successfully!');
        this.storeService
          .getStoreHoursByStoreId(this.storeId)
          .subscribe((data: any) => {
            this.setFormValue(data.data);
          });
      });
  }
  StoreWorkingHours() {
    this.storeService
      .StoreWorkingHours(this.storeHoursForm.value)
      .subscribe((data) => {
        this.toster.success('Store Working Hours Update');
        this.storeService
          .getStoreHoursByStoreId(this.storeId)
          .subscribe((data: any) => {
            this.setFormValue(data.data);
          });
      });
  }
  onClickBack() {
    this._location.back();
  }
}
