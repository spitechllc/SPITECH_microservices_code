import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HoursConfigurationComponent } from './hours-configuration.component';

describe('HoursConfigurationComponent', () => {
  let component: HoursConfigurationComponent;
  let fixture: ComponentFixture<HoursConfigurationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HoursConfigurationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HoursConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
