import { Location } from '@angular/common';
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { GasPumpService } from 'src/app/dashboard/api-service/gasPump.service';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
import { StoreService } from 'src/app/dashboard/api-service/storeService';

export interface GasPump {
  pumpNumber: string;
  posId: number;
  action: string;
}

@Component({
  selector: 'app-gas-pump-configuration',
  templateUrl: './gas-pump-configuration.component.html',
  styleUrls: ['./gas-pump-configuration.component.scss'],
})
export class GasPumpConfigurationComponent implements OnInit {
  checked = true;

  displayedColumns = ['pumpNumber', 'pumpSystemId', 'posId', 'action'];
  dataSource = new MatTableDataSource<GasPump>([]);
  @Input() storeDetail: any;
  constructor(
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private gasPumpServive: GasPumpService,
    private storeService: StoreService,
    private toster: ToastrService,
    private _location: Location,
    private identityServer: IdentityService
  ) {}
  storeId: any;
  dataArray: any;
  storeDetails: any;
  @ViewChild(MatSort) sort: MatSort;
  submitted: boolean = false;
  gasPumpForm!: FormGroup;
  validPattern = '^[A-Za-z0-9ñÑáéíóúÁÉÍÓÚ/s ]+$';
  get f() {
    return this.gasPumpForm.controls;
  }
  manageStoreRoute: boolean = false;
  ngOnInit(): void {
    this.storeDetails = this.storeDetail;
    this.activatedRoute.params.subscribe((data: any) => {
      this.storeId = data.storeId;
    });
    this.gasPumpForm = this.formBuilder.group({
      storeId: new FormControl(this.storeId, Validators.required),
      posId: new FormControl(
        null,
        Validators.compose([
          Validators.required,
          Validators.pattern('[- +()0-9]+'),
        ])
      ),
      pumpNumber: new FormControl(
        '',
        Validators.compose([
          Validators.required,
          Validators.pattern(this.validPattern),
        ])
      ),
      pumpSystemId: new FormControl(
        '',
        Validators.compose([Validators.pattern(this.validPattern)])
      ),
      qrCode: new FormControl(null),
      barCode: new FormControl(null),
    });
    this.getGasPumpBYStoreId();
    this.activatedRoute.queryParamMap.subscribe((data: any) => {
      //  console.log(data);
      if (data.params.manageStore == 'manageStore') {
        this.manageStoreRoute = true;
      }
    });
    // this.getTenantId();
  }
  // tenantData: any;
  // getTenantId() {
  //   this.identityServer.getTantetId().subscribe((data: any) => {
  //     this.tenantData = data.data;
  //   });
  // }
  gasPumpId: any;
  onClickEdit(element: any) {
    this.gasPumpId = element.gasPumpId;
    this.gasPumpForm.patchValue({
      storeId: element.storeId,
      posId: element.posId,
      pumpNumber: element.pumpNumber,
      pumpSystemId: element.pumpSystemId,
      qrCode: null,
      barCode: null,
    });
  }
  // gasPump details by storeid
  getGasPumpBYStoreId() {
    const _id: number = this.storeId as number;
    this.gasPumpServive.getGasPumpBYStoreId(_id).subscribe((data: any) => {
      this.dataArray = data;
      this.dataSource = new MatTableDataSource(this.dataArray.data);
      this.dataSource.sort = this.sort;
      // console.log(this.dataSource, 'gasPump details')
    });
  }
  submit() {
    if (!this.gasPumpId) {
      this.gasPumpConfiguration();
    }
    if (this.gasPumpId) {
      this.updateGasPumpConfig();
    }
  }
  gasPumpConfiguration() {
    this.submitted = true;

    if (this.gasPumpForm.invalid) return;
    this.gasPumpServive
      .gaPumpConfiguration(this.gasPumpForm.value)
      .subscribe((data: any) => {
        if (data == data) {
          this.toster.success('Gas pump configuration save Successfuly!');
          this.gasPumpForm.reset();
          this.getGasPumpBYStoreId();
        }
      });
  }
  updateGasPumpConfig() {
    this.submitted = true;
    if (this.gasPumpForm.invalid) return;
    this.gasPumpServive
      .updateGasPump({ ...this.gasPumpForm.value, gasPumpId: this.gasPumpId })
      .subscribe((data: any) => {
        if (data == data) {
          this.toster.success('Gas pump configuration updated successfully!');
          this.getGasPumpBYStoreId();
        }
      });
  }
  onClickBack() {
    this._location.back();
  }
}
