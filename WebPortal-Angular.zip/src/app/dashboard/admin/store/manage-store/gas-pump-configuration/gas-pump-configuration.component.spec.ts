import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GasPumpConfigurationComponent } from './gas-pump-configuration.component';

describe('GasPumpConfigurationComponent', () => {
  let component: GasPumpConfigurationComponent;
  let fixture: ComponentFixture<GasPumpConfigurationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [GasPumpConfigurationComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GasPumpConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
