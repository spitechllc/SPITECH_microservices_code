import { Location } from '@angular/common';

import { Component, Input, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { GasPumpService } from 'src/app/dashboard/api-service/gasPump.service';
import { StoreService } from 'src/app/dashboard/api-service/storeService';

@Component({
  selector: 'app-fuel-price',
  templateUrl: './fuel-price.component.html',
  styleUrls: ['./fuel-price.component.scss'],
})
export class FuelPriceComponent implements OnInit {
  checked = true;

  displayedColumns: string[] = [
    'itemId',
    'description',
    'originalAmountUnitPrice',
    'unitMeasure',
    'priceTier',
  ];
  dataSource = new MatTableDataSource<PeriodicElement>([]);

  constructor(
    private storeService: StoreService,
    private gasPumpService: GasPumpService,
    private activatedRoute: ActivatedRoute,
    private _location: Location
  ) {}
  storeId: any;
  manageStoreRoute: boolean = false;
  ngOnInit(): void {
    this.activatedRoute.params.subscribe((data: any) => {
      this.storeId = data.storeId;
    });
    this.activatedRoute.queryParamMap.subscribe((data: any) => {
      // console.log(data);
      if (data.params.manageStore == 'manageStore') {
        this.manageStoreRoute = true;
      }
    });
    this.viewStoreDetails();
  }
  storeDetails: any;
  siteId: any;
  fuelPriceDetails: any;
  err: any;
  length: number = 0;
  viewStoreDetails() {
    const _id: number = this.storeId as number;
    this.storeService.viewStoreSummery(_id).subscribe((data: any) => {
      this.storeDetails = data;
      this.siteId = this.storeDetails.siteId;
      // console.log(this.siteId, 'siteid=========');
      this.gasPumpService.getFuelPrice(this.siteId).subscribe(
        (data: any) => {
          this.fuelPriceDetails = data;

          this.length = this.fuelPriceDetails.length;
          this.dataSource = new MatTableDataSource(this.fuelPriceDetails);
        },
        (err) => {}
      );
    });
  }
  onClickBack() {
    this._location.back();
  }
}

export interface PeriodicElement {
  itemId: string;
  description: string;
  originalAmountUnitPrice: number;

  unitMeasure: string;
  priceTier: string;
  color: string;
}
