import { NgModule } from '@angular/core';
import { SharedModule } from './../../../../shared.module';
import { ManageStoreComponent } from './manage-store.component';
import { RouterModule, Routes } from '@angular/router';
import { PaymentConfigurationComponent } from './payment-configuration/payment-configuration.component';
import { HostConfigurationComponent } from './host-configuration/host-configuration.component';
import { PosStationConfigurationComponent } from './pos-station-configuration/pos-station-configuration.component';
import { GasPumpConfigurationComponent } from './gas-pump-configuration/gas-pump-configuration.component';
import { FuelPriceComponent } from './fuel-price/fuel-price.component';
import { CarWashConfigurationComponent } from './car-wash-configuration/car-wash-configuration.component';
import { HoursConfigurationComponent } from './hours-configuration/hours-configuration.component';
import { MatCardModule } from '@angular/material/card';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
  MatSnackBarModule,
  MAT_SNACK_BAR_DEFAULT_OPTIONS,
  MAT_SNACK_BAR_DEFAULT_OPTIONS_FACTORY,
} from '@angular/material/snack-bar';
import { EditHoursConfigurationComponent } from './edit-hours-configuration/edit-hours-configuration.component';

import { RolePermissionGuard } from 'src/app/dashboard/auth/role-permission.guard';
import { StoreBillingSetupComponent } from './store-billing-setup/store-billing-setup.component';
import { DefaultPopupComponent } from './store-billing-setup/default-popup/default-popup.component';
import { AddEditStoreComponent } from '../create-store/add-edit-store/add-edit-store.component';

export const router: Routes = [
  { path: ':storeId', component: ManageStoreComponent },

  {
    path: ':storeId/edit-hours/:storeId',
    component: EditHoursConfigurationComponent,
  },
  // {
  //   path: 'add-store/edit/:id',
  //   component: AddEditStoreComponent,

  //   canActivate: [RolePermissionGuard],
  // },
];

@NgModule({
  declarations: [
    ManageStoreComponent,
    PaymentConfigurationComponent,
    HostConfigurationComponent,
    PosStationConfigurationComponent,
    GasPumpConfigurationComponent,
    FuelPriceComponent,
    CarWashConfigurationComponent,
    HoursConfigurationComponent,
    // EditGasPumpConfigurationComponent,
    EditHoursConfigurationComponent,
    StoreBillingSetupComponent,
    DefaultPopupComponent,
  ],
  imports: [
    SharedModule,
    MatCardModule,
    FormsModule,
    MatSnackBarModule,
    ReactiveFormsModule,
    NgxMaterialTimepickerModule,

    RouterModule.forChild(router),
  ],
  providers: [
    { provide: MAT_SNACK_BAR_DEFAULT_OPTIONS, useValue: { duration: 2500 } },
  ],
})
export class ManageStoreModule {}
