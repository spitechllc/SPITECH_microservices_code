import { Location } from '@angular/common';
import { Component, createPlatform, Input, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { GasPumpService } from 'src/app/dashboard/api-service/gasPump.service';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
import { StoreService } from 'src/app/dashboard/api-service/storeService';

@Component({
  selector: 'app-host-configuration',
  templateUrl: './host-configuration.component.html',
  styleUrls: ['./host-configuration.component.scss'],
})
export class HostConfigurationComponent implements OnInit {
  @Input() storeDetail: any;
  hostConfigurationForm!: FormGroup;
  storeId: any;
  authentication: any;
  storeDetails: any;
  adapter: any;
  frequentUnit: any;
  siteLoyality: any;
  submitted: boolean = false;
  get f() {
    return this.hostConfigurationForm.controls;
  }
  constructor(
    private formBuilder: FormBuilder,
    private hostservice: GasPumpService,
    private activatedRoute: ActivatedRoute,
    private storeService: StoreService,
    private toster: ToastrService,
    private _location: Location,
    private identityServer: IdentityService
  ) {}
  manageStoreRoute: boolean = false;
  ngOnInit(): void {
    this.storeDetails = this.storeDetail;
    this.activatedRoute.params.subscribe((data: any) => {
      this.storeId = data.storeId;
    });
    this.getgetadapter();
    this.createForm();
    this.activatedRoute.queryParamMap.subscribe((data: any) => {
      console.log(data);
      if (data.params.manageStore == 'manageStore') {
        this.manageStoreRoute = true;
      }
    });
    // this.getTenantId();
  }
  tenantData: any;
  getTenantId() {
    this.identityServer.getTantetId().subscribe((data: any) => {
      this.tenantData = data.data;
    });
  }
  validPattern = '^[A-Za-z0-9ñÑáéíóúÁÉÍÓÚ/s ]+$';
  createForm() {
    this.hostConfigurationForm = this.formBuilder.group({
      interface: new FormControl(
        '',

        Validators.compose([
          Validators.required,
          Validators.pattern(this.validPattern),
        ])
      ),
      programName: new FormControl('', Validators.pattern(this.validPattern)),
      merchantId: new FormControl(
        '',
        Validators.compose([
          Validators.required,
          Validators.pattern('[- +()0-9]+'),
        ])
      ),
      authenticationType: new FormControl(
        '',
        Validators.pattern(this.validPattern)
      ),
      siteTerminalId: new FormControl(
        '',
        Validators.pattern(this.validPattern)
      ),
      locationId: new FormControl('', Validators.pattern(this.validPattern)),
      storeId: new FormControl(this.storeId),
      settlementEmpNumber: new FormControl(
        '',
        Validators.pattern(this.validPattern)
      ),
      settlementPasscode: new FormControl(
        '',
        Validators.pattern(this.validPattern)
      ),
      phoneNumber: new FormControl(
        '',
        Validators.compose([Validators.pattern('[- +()0-9]+')])
      ),
      domainName: new FormControl('', Validators.pattern(this.validPattern)),
      heartbeatfrequency: new FormControl(
        '',
        Validators.pattern(this.validPattern)
      ),
      heartbeatTimeUnit: new FormControl(
        '',
        Validators.pattern(this.validPattern)
      ),
      sslAllow: true,
      outdoorAuthenticationTimeout: new FormControl(
        null,
        Validators.compose([
          Validators.required,
          ,
          Validators.pattern('[- +()0-9]+'),
        ])
      ),
      siteLoyality: new FormControl('', Validators.pattern(this.validPattern)),
      mnspId: new FormControl(''),
      mnsp: new FormControl(''),
    });
  }

  getgetadapter() {
    this.hostservice.getadapter().subscribe((data: any) => {
      this.adapter = data.data;
    });
  }

  saveHostConfig() {
    this.submitted = true;
    if (this.hostConfigurationForm.invalid) return;
    this.hostservice.hostConfig(this.hostConfigurationForm.value).subscribe(
      (data: any) => {
        if (data == data) {
          this.toster.success('Host configuration created successfully!');
        }
      },
      (err) => {
        this.toster.error(err.name, ':', err.status);
        if (err.message.status == 500) {
          this.toster.error(err.status);
        }
        if (err.message.status == 400) {
          this.toster.error('Validation error!');
        }
        if (err.message.error.errors.MerchantId) {
          err.message.error.errors.MerchantId.forEach((err: any) => {
            this.toster.error(err);
          });
        }
      }
    );
  }
  onClickBack() {
    this._location.back();
  }
}
