import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarWashConfigurationComponent } from './car-wash-configuration.component';

describe('CarWashConfigurationComponent', () => {
  let component: CarWashConfigurationComponent;
  let fixture: ComponentFixture<CarWashConfigurationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CarWashConfigurationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CarWashConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
