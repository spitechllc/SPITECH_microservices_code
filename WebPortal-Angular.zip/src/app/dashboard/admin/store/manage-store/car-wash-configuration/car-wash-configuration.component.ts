import { Component, Input, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { StoreService } from 'src/app/dashboard/api-service/storeService';

@Component({
  selector: 'app-car-wash-configuration',
  templateUrl: './car-wash-configuration.component.html',
  styleUrls: ['./car-wash-configuration.component.scss'],
})
export class CarWashConfigurationComponent implements OnInit {
  checked = true;

  displayedColumns: string[] = [
    'id',
    'CarWashName',
    'CarWashPrice',
    'Description',
    'action',
  ];
  dataSource = new MatTableDataSource(ELEMENT_DATA);
  storeId: any;
  storeDetails: any;
  constructor(
    private activatedRoute: ActivatedRoute,
    private storeService: StoreService
  ) {}
  @Input() storeDetail: any;
  ngOnInit(): void {
    this.storeDetails = this.storeDetail;
    this.activatedRoute.params.subscribe((data: any) => {
      // console.log(data);
      this.storeId = data.storeId;
    });
  }
}

export interface PeriodicElement {
  id: string;
  CarWashName: string;
  CarWashPrice: string;
  Description: string;
  action: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {
    id: '1',
    CarWashName: 'CarWashName',
    CarWashPrice: '$230',
    Description: 'Lorem ipsum dolor sit amet, consectetur adipiscing',
    action: '',
  },
  {
    id: '2',
    CarWashName: 'CarWashName',
    CarWashPrice: '$230',
    Description: 'Lorem ipsum dolor sit amet, consectetur adipiscing',
    action: '',
  },
  {
    id: '3',
    CarWashName: 'CarWashName',
    CarWashPrice: '$230',
    Description: 'Lorem ipsum dolor sit amet, consectetur adipiscing',
    action: '',
  },
];
