import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { StoreService } from 'src/app/dashboard/api-service/storeService';

@Component({
  selector: 'app-manage-store',
  templateUrl: './manage-store.component.html',
  styleUrls: ['./manage-store.component.scss'],
})
export class ManageStoreComponent implements OnInit {
  constructor(
    private storeService: StoreService,
    private activatedRoute: ActivatedRoute
  ) {}

  storeId: any;
  storeDetails: any;
  ngOnInit(): void {
    this.activatedRoute.params.subscribe((data: any) => {
      // console.log(data);
      if (data.id) {
        this.storeId = data.id;
      }
      this.storeId = data.storeId;
      if (this.storeId || data.id) {
        this.storeService
          .viewStoreSummery(this.storeId)
          .subscribe((data: any) => {
            this.storeDetails = data;
          });
      }
      // console.log((this.storeId))
    });
  }

  moveToSelectedTab(tabName: string) {
    for (
      let i = 0;
      i < document.querySelectorAll('.mat-tab-label-content').length;
      i++
    ) {
      if (
        (<HTMLElement>document.querySelectorAll('.mat-tab-label-content')[i])
          .innerText == tabName
      ) {
        (<HTMLElement>document.querySelectorAll('.mat-tab-label')[i]).click();
      }
    }
  }
}
