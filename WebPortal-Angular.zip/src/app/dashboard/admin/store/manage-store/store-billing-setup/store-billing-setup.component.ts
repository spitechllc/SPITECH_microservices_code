import { Location } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
import { PaymentService } from 'src/app/dashboard/api-service/payment.srvice';
import { StoreService } from 'src/app/dashboard/api-service/storeService';
import { TransactionService } from 'src/app/dashboard/api-service/trasation.service';
import { AuthService } from 'src/app/dashboard/auth/auth.service';
import { DefaultPopupComponent } from './default-popup/default-popup.component';

@Component({
  selector: 'app-store-billing-setup',
  templateUrl: './store-billing-setup.component.html',
  styleUrls: ['./store-billing-setup.component.scss'],
})
export class StoreBillingSetupComponent implements OnInit {
  @Input() storeDetail: any;
  range = new FormGroup({
    start: new FormControl(),
    end: new FormControl(),
  });
  displayedColumns = [
    'paymentMethod',
    'monthlySaasFee',
    'transactionFee',
    'transactionPercentageFee',
    'minTransactionRange',
    'maxTransactionRange',
    'isActive',
    'action',
  ];
  dataSource = new MatTableDataSource<TableDetails>([]);

  myModel = true;
  checked = true;
  storeId: any;
  storeDetails: any;
  paymentMethodDetails: any;
  claimIdArray: any;
  err: string = '';
  storeBillingForm!: FormGroup;
  paymentConfigurationDetails: any;
  submitted: boolean = false;
  paymentMethod: any;
  storeBillingDetails: any = [];
  storeBillingFeeId: any;
  isActive: boolean = true;
  constructor(
    private storeService: StoreService,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private toster: ToastrService,
    private auth: AuthService,
    private _location: Location,
    private dialog: MatDialog,
    private paymentService: PaymentService,
    private transactionService: TransactionService,
    private identityServer: IdentityService
  ) {}
  get f() {
    return this.storeBillingForm.controls;
  }
  manageStoreRoute: boolean = false;
  ngOnInit(): void {
    this.activatedRoute.params.subscribe((data: any) => {
      this.storeId = data.storeId;
    });
    this.activatedRoute.queryParamMap.subscribe((data: any) => {
      //  console.log(data);
      if (data.params.manageStore == 'manageStore') {
        this.manageStoreRoute = true;
      }
    });
    this.storeDetails = this.storeDetail;
    this.createForm();

    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.getPaymentMethod();
    this.getStoreBilling();
    // this.getTenantId();
  }
  // tenantData: any;
  // getTenantId() {
  //   this.identityServer.getTantetId().subscribe((data: any) => {
  //     this.tenantData = data.data;
  //   });
  // }
  onClickisActive(event: MatSlideToggleChange) {
    // console.log(event);
    this.isActive = event.checked;
  }

  createForm() {
    this.storeBillingForm = this.formBuilder.group({
      storeId: new FormControl(this.storeId),
      siteId: new FormControl(this.storeDetails.siteId),
      paymentMethodId: new FormControl('', Validators.required),
      minTransactionRange: new FormControl('', Validators.required),
      maxTransactionRange: new FormControl('', Validators.required),
      transactionFee: new FormControl('', Validators.required),
      transactionPercentageFee: new FormControl('', Validators.required),
      monthlySaasFee: new FormControl('', Validators.required),
      isDefault: false,
    });
  }
  getPaymentMethod() {
    this.paymentService.getPaymentMethod().subscribe((data: any) => {
      this.paymentMethod = data.data;
      // console.log(this.paymentMethod);
    });
  }
  length: any;
  getStoreBilling() {
    this.transactionService
      .getStoreBillingFeeByStoreId(this.storeId)
      .subscribe((data: any) => {
        this.storeBillingDetails = data.data;
        this.length = this.storeBillingDetails.length;
        // console.log(this.storeBillingDetails.length);
        this.dataSource = new MatTableDataSource(data.data);
      });
  }

  onClickStoreBilling(id: any) {
    // console.log(id);
    this.storeBillingFeeId = id;
    this.transactionService.getStoreBillingFeeBy(id).subscribe((data: any) => {
      this.storeBillingForm.patchValue({
        storeId: data.data.storeId,
        siteId: data.data.siteId,
        paymentMethodId: data.data.paymentMethodId,
        minTransactionRange: data.data.minTransactionRange,
        maxTransactionRange: data.data.maxTransactionRange,
        transactionFee: data.data.transactionFee,
        transactionPercentageFee: data.data.transactionPercentageFee,
        monthlySaasFee: data.data.monthlySaasFee,
        isDefault: false,
      });
    });
  }

  formReset() {
    this.storeBillingForm.reset();
    this.storeBillingFeeId = 0;
    this.createForm();
  }

  submit() {
    if (!this.storeBillingFeeId) {
      this.saveStoreBilling();
    }
    if (this.storeBillingFeeId) {
      this.updateStoreBilling();
    }
  }
  mintransationerr: string = '';
  saveStoreBilling() {
    this.submitted = true;
    if (this.storeBillingForm.invalid) return;
    this.transactionService
      .addStoreBillingFee(this.storeBillingForm.value)
      .subscribe(
        (data: any) => {
          if (data.success == true) {
            this.toster.success('Store billing save successfully');
            this.getStoreBilling();
          }
          if (data.success == false) {
            this.toster.warning('Store billing not save status:false');
          }
        },
        (err) => {
          // console.log(err);
          if (err.error.errors.MinTransactionRange) {
            err.error.errors.MinTransactionRange.forEach((err: any) => {
              this.mintransationerr = err;
              // console.log(err);
              this.toster.error(err);
            });
          }
          if (err.error.errors.TransactionRange) {
            err.error.errors.TransactionRange.forEach((err: any) => {
              // console.log(err);
              this.toster.error(err);
            });
          }
        }
      );
  }
  updateStoreBilling() {
    this.transactionService
      .updateStoreBillingFee({
        ...this.storeBillingForm.value,
        storeBillingFeeId: this.storeBillingFeeId,
        isActive: this.isActive,
      })
      .subscribe(
        (data) => {
          this.toster.success('Update store billing Successfully');
          this.getStoreBilling();
        },
        (err) => {
          if (err.error.errors.MinTransactionRange) {
            err.error.errors.MinTransactionRange.forEach((err: any) => {
              this.mintransationerr = err;
              // console.log(this.mintransationerr);
              this.toster.error(err);
            });
          }
        }
      );
  }
  onClickBack() {
    this._location.back();
  }

  defaultPopUp() {
    const dialogRef = this.dialog.open(DefaultPopupComponent, {
      width: '430px',
      panelClass: 'popup',
      data: [this.storeId, this.storeDetails.siteId],
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.getStoreBilling();
    });
  }
}

export interface TableDetails {
  monthlySaasFee: string;
  transactionFee: string;
  Subscription: string;
  transactionPercentageFee: string;
  effectiveDate: string;
  storeBillingFeeId: string;
  storeName: string;
  action: string;
}
