import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
import { TransactionService } from 'src/app/dashboard/api-service/trasation.service';
export interface UsersData {
  roleId: number;
  roleName: string;
}
@Component({
  selector: 'app-default-popup',
  templateUrl: './default-popup.component.html',
  styleUrls: ['./default-popup.component.scss'],
})
export class DefaultPopupComponent implements OnInit {
  local_data: any;
  roleId: any;
  submitted: boolean = false;
  get f() {
    return this.defaultBillingFeeForm.controls;
  }
  constructor(
    private transactionService: TransactionService,
    private formBuilder: FormBuilder,
    private toster: ToastrService,
    private activatedRoute: ActivatedRoute,
    private spinner: NgxSpinnerService,
    public dialogRef: MatDialogRef<DefaultPopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: UsersData,
    private router: Router
  ) {
    this.storeIdSiteId = { ...data };
    // console.log(this.storeIdSiteId);
    this.roleId = this.storeIdSiteId.roleId;
    // console.log(this.roleId)
    if (this.storeIdSiteId) {
      this.defaultBillingFeeForm = this.formBuilder.group({
        storeId: new FormControl(this.storeIdSiteId[0]),
        siteId: new FormControl(this.storeIdSiteId[1]),
      });
    }
  }
  defaultBillingFeeForm!: FormGroup;
  storeIdSiteId: any;
  dataLoaded: boolean = false;
  RoleId: any;
  ngOnInit(): void {
    this.dataLoaded = false;
  }

  updateCopyDefaultBillingFee() {
    this.transactionService
      .copyDefaultBillingFee({
        storeId: this.storeIdSiteId[0],
        siteId: this.storeIdSiteId[1],
      })
      .subscribe(
        (data: any) => {
          this.toster.success('Update default billing fee successfully');
          this.dialogRef.close([]);
        },
        (err) => {
          // console.log(err);
          if (err.error.errors.DefaultFees) {
            err.error.errors.DefaultFees.forEach((err: any) => {
              this.toster.error(err);
            });
          }
        }
      );
  }
}
