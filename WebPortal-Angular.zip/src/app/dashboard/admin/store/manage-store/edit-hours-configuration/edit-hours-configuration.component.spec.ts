import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditHoursConfigurationComponent } from './edit-hours-configuration.component';

describe('EditHoursConfigurationComponent', () => {
  let component: EditHoursConfigurationComponent;
  let fixture: ComponentFixture<EditHoursConfigurationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditHoursConfigurationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditHoursConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
