import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { StoreService } from 'src/app/dashboard/api-service/storeService';

@Component({
  selector: 'app-edit-hours-configuration',
  templateUrl: './edit-hours-configuration.component.html',
  styleUrls: ['./edit-hours-configuration.component.scss'],
})
export class EditHoursConfigurationComponent implements OnInit {
  constructor(
    private activatedRoute: ActivatedRoute,
    private storeService: StoreService,
    private formBuilder: FormBuilder
  ) {}
  storeId: any;
  checked = true;
  edithoursForm!: FormGroup;
  ngOnInit(): void {
    this.activatedRoute.params.subscribe((data: any) => {
      this.storeId = data.storeId;

      if (this.storeId !== '') {
        const _id: number = this.storeId as number;
        this.storeService
          .getStoreHoursByStoreId(_id)
          .toPromise()
          .then((data: any) => {
            this.storeDetails = data;
            Object.assign(this.storeDetails, data);
            // console.log(this.storeDetails, 'storehorsdetrails');
            this.edithoursForm = this.formBuilder.group({
              storeId: new FormControl(this.storeId),
              is24Hours: new FormControl(true),
              storeHours: this.formBuilder.array([
                this.formBuilder.group({
                  storeHoursId: new FormControl(0),
                  weekDayId: new FormControl(0),
                  openTime: new FormControl(''),
                  closeTime: new FormControl(''),
                }),
              ]),
            });
          });
      }
    });
  }
  get storeHoursFormGroups() {
    return this.edithoursForm.get('storeHours') as FormGroup;
  }
  storeDetails: any;
  updateStoreHours() {
    this.storeService.updateSoreHour(this.edithoursForm.value);
  }
}
