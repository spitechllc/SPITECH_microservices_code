import { Component, OnInit } from '@angular/core';
import { IdentityService } from '../../api-service/identityService';
import { StoreService } from 'src/app/dashboard/api-service/storeService';
import { ToastrService } from 'ngx-toastr';
import {
  AbstractControl,
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  ValidationErrors,
  ValidatorFn,
  Validators,
} from '@angular/forms';
import { PaymentService } from '../../api-service/payment.srvice';
import { RxwebValidators, json } from '@rxweb/reactive-form-validators';
import { MatTableDataSource } from '@angular/material/table';
import Validation from '../../util/passValidation';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../../auth/auth.service';
import { MonthWisePopupComponent } from '../../dashboard-page/month-wise-popup/month-wise-popup.component';
import { MatDialog } from '@angular/material/dialog';
import { InhouseUserDetailComponent } from './inhouse-user-detail/inhouse-user-detail.component';

@Component({
  selector: 'app-inhouseonboard',
  templateUrl: './inhouseonboard.component.html',
  styleUrls: ['./inhouseonboard.component.scss'],
})
export class InhouseonboardComponent implements OnInit {
  displayedColumns = [
    'id',
    'companyName',
    'inhouseNo',
    'mopUser',
    'limitAmount',
    'action',
  ];

  onBoardForm!: FormGroup;

  submitted: boolean = false;
  inhouseId: number = 0;
  tenantData: any[] = [];
  onBoardTableData: any = [];
  id: any;
  phoneList: any;
  phonecategory: any;
  counter: number = 0;
  checkDuplicate: any = [];
  inhouseUserId: any;
  get f() {
    return this.onBoardForm.controls;
  }

  /*
  This is phones detail form array after that i eill push data in phones array
  */
  get phones() {
    return this.onBoardForm.get('phones') as FormArray;
  }
  get ownerPhones() {
    return this.onBoardForm.get('owners.phones') as FormArray;
  }
  constructor(
    private fb: FormBuilder,
    private identityService: IdentityService,
    private paymentService: PaymentService,
    private storeService: StoreService,
    private auth: AuthService,
    private toster: ToastrService,
    private activatedRoute: ActivatedRoute,
    private dialog:MatDialog
  ) {}

  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.createForm();
    this.getTenant();
    this.phoneCategory();
    this.GetOnboardTableData();
    //this.getOnboardById();
  }
  claimIdArray: any;
  countryCode: number = 0;
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  dataSource = new MatTableDataSource<OnboardTable>([]);
  createForm() {
    this.onBoardForm = this.fb.group({
      id: 0,
      tenantId: new FormControl('', Validators.required),
      paymentMethod: new FormControl('1', Validators.required),
      companyName: new FormControl('', Validators.required),
      accountNo: ['', Validators.maxLength(17)],
      inhouseNo: new FormControl('', Validators.required),
      limitAmount: new FormControl('', Validators.required),
      primaryPhone: '900000009',
      contactPerson: new FormControl('', Validators.required),
      phones: this.fb.array([this.createPhoneForm()]),
    });
  }

  /*
  This is phones related form data which is use to push in phones form array.
  inside create phone form asssign cotrol with value
  */
  createPhoneForm() {
    return this.fb.group({
      flName: ['', Validators.required],
      categoryTypeLevelId: [1, Validators.required],
      areaCode: ['91'],
      id: [0],
      phoneNumber: [
        '',
        Validators.compose([
          Validators.required,
          Validators.maxLength(20),
          Validators.pattern('[- +()0-9]+'),
          RxwebValidators.unique(),
        ]),
      ],
      countryCode: ['+1', Validators.required],
      email: ['', Validators.required],
      accountType: [false],
    });
  }

  getTenant() {
    this.identityService.getTantetId().subscribe((data: any) => {
      this.tenantData = data.data;
    });
  }

  GetOnboardTableData() {
    this.paymentService.getInhouseOnboard().subscribe((data: any) => {
      debugger;
      this.onBoardTableData = data;
      this.dataSource = new MatTableDataSource(this.onBoardTableData.data);
    });
  }

  //short cut of control code

  onChangeTenant(value: number) {
    this.onBoardForm.patchValue({
      cashBackEventId: value,
    });
  }

  CompanyName: any;
  setValue() {
    this.CompanyName = this.onBoardForm.get('companyName')?.value;
  }
  formReset() {
    this.onBoardForm.reset();
    this.id = 0;
  }
  messaage: any;
  checkAccountType: any;

  /*
  This is formgroup submit function to perform operation
  add,edit and also check validation
  */
  submit() {
    debugger;
    let hasTrueAccountType = false;
    this.phones.value.forEach((element: any) => {
      if (element.accountType === true) {
        hasTrueAccountType = true;
        return;
      }
    });

    if (!hasTrueAccountType) {
      this.toster.error('At least one primary account');
      return;
    }
    this.submitted = true;
    this.checkDuplicate.length = 0;
    if (this.onBoardForm.invalid) return;

    if (this.inhouseId == 0) {
      this.messaage = 'Inhouse Account Save Successfully!';
      this.createOnBoard(this.messaage);
    } else {
      this.messaage = 'Inhouse Account Updated Successfully!';
      this.createOnBoard(this.messaage);
    }
  }

  /*
  This method is use to save data via calling api which is use a
  payment service which will call on contructor and also check validation
  error meesage with toaster function.
  */
  createOnBoard(messaage: any) {
    this.paymentService.createInhOnboard(this.onBoardForm.value).subscribe(
      (data: any) => {
        console.log(data);
        this.toster.success(messaage, '', {
          timeOut: 5000,
        });
        this.GetOnboardTableData();
      },
      (err) => {
        console.log(err);
        if (err.error.errors.AccountNo) {
          err.error.errors.AccountNo.forEach((err: any) => {
            this.toster.error(err, '', {
              timeOut: 10000,
            });
          });
        }
        if (err.error.errors.InhouseNo) {
          err.error.errors.InhouseNo.forEach((err: any) => {
            this.toster.error(err, '', {
              timeOut: 10000,
            });
          });
        }

        if (err.error.errors.LimitAmount) {
          err.error.errors.LimitAmount.forEach((err: any) => {
            this.toster.error(err, '', {
              timeOut: 10000,
            });
          });
        }

        if (err.status == 500) {
          this.toster.error('Internal server error  Status:500');
        }
      }
    );
  }

  /*
  Push data in phones form array as in form of create phone form control with data
  */
  hideContactDtl = true;
  addAnotherPhone() {
    this.counter++;
    if (this.inhouseId) {
      if (this.counter < 3) {
        this.phones.push(this.createPhoneForm());
        this.hideContactDtl = true;
      } else {
        this.phones.push(this.createPhoneForm());
        this.hideContactDtl = false;
      }
    } else {
      if (this.counter === 1) {
        this.phones.push(this.createPhoneForm());
      } else if (this.counter === 2) {
        this.phones.push(this.createPhoneForm());
        this.hideContactDtl = false;
      }
    }
  }

  getFormGroup(index: number): FormGroup {
    return this.phones.at(index) as FormGroup;
  }
  onIsPrimaryContactChecked(index: number) {
    for (let i = 0; i < this.phones.length; i++) {
      if (i == index) continue;
      this.getFormGroup(i).get('accountType')?.setValue(false);
    }
  }

  addAnotherOwnerPhone() {
    this.ownerPhones.push(this.createOwnerPhoneForm());
  }

  getOnboardById() {
    this.getInhouseDetails(this.id);
  }

  getInhouseDetails(id: any) {
    this.paymentService.getInhouseDetailById(id).subscribe(
      (res) => {
        debugger;
        this.setFormValue(res);
      },
      (err: any) => {
        if (err.status == 500) {
          this.toster.error('Internal server error  Status:500');
        }
      }
    );
  }

  /*
  Clear fprm coontrol data
  */
  clearForm() {
    this.onBoardForm.reset({
      accountNo: '',
      companyName: '',
      contactPerson: '',
      limitAmount: '',
    });
  }
  setFormValue(data: any) {
    this.onBoardForm.patchValue({
      id: data.id,
      inhouseNo: data.inhouseNo,
      accountNo: data.accountNo,
      companyName: data.companyName,
      contactPerson: data.contactPerson,
      limitAmount: data.limitAmount,
      tenantId: data.tenantId,
      paymentMethod: '1',
    });

    this.phones.controls.length = 0;
    // this.phoneList=data.phones
    // this.phones.controls = data.phones;
    data.phones.forEach((element: any, index: any) => {
      //if (data.phones.length === 0) {
      debugger;
      this.counter = 0;
      if (data.phones.length < 3) {
        this.addAnotherPhone();
        this.hideContactDtl = true;
      } else {
        this.addAnotherPhone();
        this.hideContactDtl = false;
      }

      // this.phones.controls = this.phones.controls.push(element);
      //}
      this.phones.controls[index].patchValue(element);

      console.log(element, 'ph');
    });
  }

  onclick(value: any) {
    console.log(value);
  }
  createOwnerPhoneForm() {
    return this.fb.group({
      Id: [0],
      flName: ['', Validators.required],
      categoryTypeLevelId: [1, Validators.required],
      areaCode: [91],
      phoneNumber: [
        '',
        Validators.compose([
          Validators.maxLength(20),
          Validators.pattern('[- +()0-9]+'),
          Validators.required,
          RxwebValidators.unique(),
        ]),
      ],
      countryCode: ['0'],
      email: ['', Validators.required],
      primaryAc: ['', Validators.required],
    });
  }

  // This method is use to remove phone items from list as per index
  removePhone(i: any) {
    this.phones.removeAt(i);
  }

  phoneCategory() {
    // debugger;
    this.storeService.getCategoryLevelPhone(16).subscribe(
      (data: any) => {
        // debugger;
        this.phonecategory = data.data;
      },
      (err) => {
        // this.loading = false;
      }
    );
  }

  onClickUserDetail(element: any)
  {
    this.inhouseUserId= element;
    sessionStorage.setItem('InhouseNo',this.inhouseUserId)
    const dialogRef = this.dialog.open(InhouseUserDetailComponent, {
      width: '1000px',
      panelClass: 'popup',
      disableClose: true,
      data: [],
    });
  }
  onClickEdit(element: any) {
    debugger;
    this.inhouseId = element.id;
    this.getInhouseDetails(element.id);
  }

  total: any;
  PageSize: number = 50;
  SortOrder = 'asc';
  PageIndex: number = 1;
  pageChanged(event: any) {
    this.PageIndex = event.pageIndex + 1;
    this.PageSize = event.pageSize;
    this.GetOnboardTableData();
  }
}

export interface OnboardTable {
  id: Number;
  inhouseNo: string;
  mopUser : string;
  accountNo: string;
  limitAmount: string;
  companyName: string;
}
