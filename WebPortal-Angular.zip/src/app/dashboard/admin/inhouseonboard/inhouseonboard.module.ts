import { NgModule } from '@angular/core';
import { InhouseonboardComponent } from './inhouseonboard.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { SharedModule } from 'src/app/shared.module';
import { SharedModule } from './../../../shared.module';
import { NgxMaskModule } from 'ngx-mask';
import { InhouseUserDetailComponent } from './inhouse-user-detail/inhouse-user-detail.component';

export const router: Routes = [
  { path: '', component: InhouseonboardComponent },
];
@NgModule({
  declarations: [InhouseonboardComponent, InhouseUserDetailComponent],
  imports: [
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    NgxMaskModule.forRoot({
      showMaskTyped: true,
      // clearIfNotMatch : true
    }),
    RouterModule.forChild(router),
  ],
})
export class InhouseonboardModule {}
