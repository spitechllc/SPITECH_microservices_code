
import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';
import { PaymentService } from 'src/app/dashboard/api-service/payment.srvice';

@Component({
  selector: 'app-inhouse-user-detail',
  templateUrl: './inhouse-user-detail.component.html',
  styleUrls: ['./inhouse-user-detail.component.scss']
})

export class InhouseUserDetailComponent implements OnInit {

  InhouseNo: any;
  Message: any;
  displayedColumns = [
    'userId',
    'userName',
    'firstName',
    'lastName',
    'displayName',
    'dob',
    'mobileNumber',
    'action',
  ];
  onUserDetailTableData: any = [];
  constructor(private paymentService: PaymentService, private dialog: MatDialog,
    private toster: ToastrService) {
  }
  ngOnInit(): void {
    this.InhouseNo = sessionStorage.getItem('InhouseNo')
    this.GetInhouseAccountUserDetail(this.InhouseNo);
  }

  dataSource = new MatTableDataSource<UserDetailTable>([]);

  GetInhouseAccountUserDetail(inhouseNumber: any) {
    this.paymentService.GetInhouseAccountUserDetail(inhouseNumber).subscribe((data: any) => {
      debugger;
      this.onUserDetailTableData = data;
      this.dataSource = new MatTableDataSource(this.onUserDetailTableData);
      if (data.length == 0) {
        this.Message = "Data Not Found !!!";
      }
    });
  }

  DeleteInhouseUser(element: any) {    
    if (confirm('Are you want to sure delete inhouse account user ?')) {

     const jsonData =  {
        inhouseNo: this.InhouseNo,
        userId: element.userId
      }
      this.paymentService.deleteInhouseAccUser(jsonData).subscribe(
        (data: any) => {
          
          this.toster.success(data.message, '', {
            timeOut: 3000,
          });
          this.GetInhouseAccountUserDetail(this.InhouseNo);
        },
        (err) => {
          console.log(err);
          if (err.error.errors.AccountNo) {
            err.error.errors.AccountNo.forEach((err: any) => {
              this.toster.error(err, '', {
                timeOut: 10000,
              });
            });
          }
          if (err.error.errors.InhouseNo) {
            err.error.errors.InhouseNo.forEach((err: any) => {
              this.toster.error(err, '', {
                timeOut: 10000,
              });
            });
          }

          if (err.error.errors.LimitAmount) {
            err.error.errors.LimitAmount.forEach((err: any) => {
              this.toster.error(err, '', {
                timeOut: 10000,
              });
            });
          }

          if (err.status == 500) {
            this.toster.error('Internal server error  Status:500');
          }
        }
      );
    }
    else {
      this.toster.error("Cancel", '', {
        timeOut: 2000,
      });
    }

  }


}
export class confirmDialog {
  constructor(public dialogRef: MatDialogRef<confirmDialog>) { }
}

export interface UserDetailTable {
  userId: Number;
  userName: string;
  firstName: string;
  lastName: string;
  displayName: string;
  dob: string;
  mobileNumber: string;
}
