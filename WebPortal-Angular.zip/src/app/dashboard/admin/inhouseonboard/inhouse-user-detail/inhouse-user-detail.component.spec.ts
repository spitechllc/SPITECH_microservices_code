import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InhouseUserDetailComponent } from './inhouse-user-detail.component';

describe('InhouseUserDetailComponent', () => {
  let component: InhouseUserDetailComponent;
  let fixture: ComponentFixture<InhouseUserDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InhouseUserDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InhouseUserDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
