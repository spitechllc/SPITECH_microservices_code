import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InhouseonboardComponent } from './inhouseonboard.component';

describe('InhouseonboardComponent', () => {
  let component: InhouseonboardComponent;
  let fixture: ComponentFixture<InhouseonboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InhouseonboardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InhouseonboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
