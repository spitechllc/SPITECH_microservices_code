import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserExcelExportComponent } from './user-excel-export.component';

describe('UserExcelExportComponent', () => {
  let component: UserExcelExportComponent;
  let fixture: ComponentFixture<UserExcelExportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserExcelExportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserExcelExportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
