import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';

import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { debounce } from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ExcelService } from 'src/app/dashboard/api-service/excel-servive/excel.service';
import { StoreService } from 'src/app/dashboard/api-service/storeService';
import { UserService } from 'src/app/dashboard/api-service/userService';
import { AuthService } from 'src/app/dashboard/auth/auth.service';
import { SharedService } from 'src/app/dashboard/auth/shared.service';
import { UserExcelExportComponent } from './user-excel-export/user-excel-export.component';

@Component({
  selector: 'app-user-tab',
  templateUrl: './user-tab.component.html',
  styleUrls: ['./user-tab.component.scss'],
})
export class UserTabComponent implements OnInit {
  displayedColumns = [
    'userId',
    'firstName',
    'lastName',
    'PhoneNumber',
    'EmailAddress',
    'roles',
    'isActive',
    'action',
  ];

  dataArray: any = [];
  totalCountData = 0;
  PageIndex = 1;
  PageSize = 50;
  SortBy = '';
  SortOrder = 'desc';
  loading: boolean = true;
  claimIdArray: any;
  FirstNameOrEmailOrPhone: string = '';
  paramsData: any = {};
  allUsersData: any = [];
  phones: any;
  number: any;
  emails: any;
  addressline1: any;
  addressline2: any;
  city: any;
  state: any;
  country: any;
  zipCode: any;
  err: any;
  dataSource = new MatTableDataSource<UserTable>([]);
  constructor(
    private userService: UserService,
    private spinner: NgxSpinnerService,
    private toster: ToastrService,
    private router: Router,
    private activateRoute: ActivatedRoute,
    private auth: AuthService,
    private excelService: ExcelService,
    private storeService: StoreService,
    public dialog: MatDialog
  ) {}

  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.activateRoute.queryParamMap.subscribe((data: any) => {
      this.paramsData = data.params;
    });
    if (this.paramsData.data == 'true') {
      this.PageIndex = this.paramsData.PageIndex;
      this.PageSize = this.paramsData.PageSize;
      this.firstName = this.paramsData.firstName
        ? this.paramsData.firstName
        : '';
      this.lastName = this.paramsData.lastName ? this.paramsData.lastName : '';
      this.email = this.paramsData.email ? this.paramsData.email : '';
      this.City = this.paramsData.City ? this.paramsData.City : '';
      this.StateName = this.paramsData.StateName
        ? this.paramsData.StateName
        : '';
      this.ZipCode = this.paramsData.ZipCode ? this.paramsData.ZipCode : '';
      this.storeName = this.paramsData.storeName
        ? this.paramsData.storeName
        : '';
      this.getAllUserWithPagging();
    } else {
      this.getAllUserWithPagging();
    }
    this.getAllState();
  }

  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  exportAsExcel() {
    var pageSize = 0;
    var pageIndex = 0;
    this.spinner.show();
    this.userService
      .getUserByPagging(
        pageIndex,
        pageSize,
        this.SortOrder,
        this.SortBy,
        this.firstName,
        this.lastName,
        this.storeName,
        this.email,
        this.phone,
        this.StateName,
        this.City,
        this.ZipCode
      )
      .subscribe((data: any) => {
        this.allUsersData = data.data;
        const dialogRef = this.dialog.open(UserExcelExportComponent, {
          width: '450px',
          panelClass: 'popup',
          data: this.allUsersData,
        });
        // if (this.allUsersData.length > 0) {
        //   this.excelService.exportAsExcelFile(
        //     this.allUsersData.map((u: any) => {
        //       return {
        //         UserId: u.userId,
        //         'First Name': u.firstName,
        //         'Last Name': u.lastName,
        //         'Mobile Number': u.phones.map((p: any) => {
        //           this.number = p.number;
        //           return { MobileNumber: p.number };
        //         })
        //           ? this.number
        //           : '',
        //         Email: u.emails.map((e: any) => {
        //           this.emails = e.email;
        //           return { email: e.email };
        //         })
        //           ? this.emails
        //           : '',
        //         AddressLine1: u.addresses.map((a: any) => {
        //           this.addressline1 = a.addressLine1;
        //           this.city = a.city;
        //           this.state = a.state;
        //           (this.country = a.country), (this.zipCode = a.zipCode);
        //           this.addressline2 = a.addressLine2;
        //           return {};
        //         })
        //           ? this.addressline1
        //           : '',
        //         AddressLine2: this.addressline2,
        //         City: this.city,
        //         State: this.state,
        //         Country: this.country,
        //         'Zip Code': this.zipCode,
        //       };
        //     }),
        //     'all-users'
        //   );
        // } else {
        //   this.toster.error('Data not found');
        // }
      });
  }

  onHeaderSortChange(event: any) {
    this.SortBy = event.active;
    if (event.direction == '') {
      this.SortOrder = 'asc';
    } else {
      this.SortOrder = event.direction;
    }
    this.getAllUserWithPagging();
  }

  // formatPhoneNumber(phoneNumber: any) {
  //   var cleaned = ('' + 12333355).replace(/\D/g, '');
  //   var match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
  //   if (match) {
  //     this.formattedNumber = '(' + match[1] + ') ' + match[2] + '-' + match[3];
  //   }
  //   this.formattedNumber = null;
  // }
  formattedNumber: string = ' ';
  formatPhoneNumber(number: any) {
    console.log(number);
    var cleaned = ('+1' + number).replace(/\D/g, '');
    var match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
      this.formattedNumber = '(' + match[1] + ') ' + match[2] + '-' + match[3];
    }
    return this.formattedNumber;
  }
  getAllUserWithPagging() {
    this.userService
      .getUserByPagging(
        this.PageIndex,
        this.PageSize,
        this.SortOrder,
        this.SortBy,
        this.firstName,
        this.lastName,
        this.storeName,
        this.email,
        this.phone,
        this.StateName,
        this.City,
        this.ZipCode
      )
      .subscribe(
        (data: any) => {
          this.dataArray = data;
          this.dataSource = new MatTableDataSource(this.dataArray.data);
          this.totalCountData = data.totalCount;
        },
        (err) => {
          if (err.status == 500) {
            this.err = 'Internal server error';
          }
          if (err.status == 400) {
            this.toster.error('Bad request');
          }
        }
      );
  }

  pageChanged(event: PageEvent) {
    this.PageIndex = event.pageIndex + 1;
    this.PageSize = event.pageSize;
    this.router.navigate(['/admin/user'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        SortOrder: this.SortOrder,
        SortBy: this.SortBy,
        data: 'true',
        storeName: this.storeName,

        firstName: this.firstName,
        lastName: this.lastName,
        email: this.email,
        phone: this.phone,
      },
      queryParamsHandling: 'merge',
    });
    this.getAllUserWithPagging();
  }
  searchEvent: any;
  firstName: string = '';
  lastName: string = '';
  storeName: string = '';
  email: string = '';
  phone: string = '';
  onChange(event: any) {
    this.searchEvent = event;
    this.SortBy = '';
    this.SortOrder = '';
    if (event == 0) {
      this.firstName = '';
      this.lastName = '';
      this.storeName = '';
      this.email = '';
      this.phone = '';

      this.searchEvent = 0;
      (this.City = ''),
        (this.StateName = ''),
        this.ZipCode,
        this.router.navigate(['/admin/user'], {
          queryParams: {
            PageIndex: this.PageIndex,
            PageSize: this.PageSize,

            searchEvent: (this.searchEvent = 0),
            data: 'true',
            tabPostion: 0,
            storeName: (this.storeName = ''),

            firstName: (this.firstName = ''),
            lastName: (this.lastName = ''),
            email: (this.email = ''),
            phone: (this.phone = ''),
            City: (this.City = ''),
            StateName: (this.StateName = ''),
            ZipCode: this.ZipCode,
          },
          queryParamsHandling: 'merge',
        });

      this.getAllUserWithPagging();
    }
  }
  filterByFirstName = debounce(($event: any) => {
    this.firstName = $event.target.value;
    this.PageIndex = 1;
    this.router.navigate(['/admin/user'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        data: 'true',
        firstName: this.firstName,
        lastName: (this.lastName = ''),
        storeName: (this.storeName = ''),
        email: (this.email = ''),
        phone: (this.phone = ''),
        City: (this.City = ''),
        StateName: (this.StateName = ''),
        ZipCode: this.ZipCode,
      },
      queryParamsHandling: 'merge',
    });
    this.getAllUserWithPagging();
  }, 1000);
  filterByLastName = debounce(($event: any) => {
    this.lastName = $event.target.value;
    this.PageIndex = 1;
    this.router.navigate(['/admin/user'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        data: 'true',
        firstName: (this.firstName = ''),
        lastName: this.lastName,
        storeName: (this.storeName = ''),
        email: (this.email = ''),
        phone: (this.phone = ''),
        City: (this.City = ''),
        StateName: (this.StateName = ''),
        ZipCode: this.ZipCode,
      },
      queryParamsHandling: 'merge',
    });
    this.getAllUserWithPagging();
  }, 1000);
  filterByStoreId = debounce(($event: any) => {
    this.storeName = $event.target.value;
    this.PageIndex = 1;
    this.router.navigate(['/admin/user'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        data: 'true',
        firstName: (this.firstName = ''),
        lastName: (this.lastName = ''),
        storeName: this.storeName,
        email: (this.email = ''),
        phone: (this.phone = ''),
        City: (this.City = ''),
        StateName: (this.StateName = ''),
        ZipCode: this.ZipCode,
      },
      queryParamsHandling: 'merge',
    });
    this.getAllUserWithPagging();
  }, 1000);
  filterByEmail = debounce(($event: any) => {
    this.email = $event.target.value;
    this.PageIndex = 1;
    this.router.navigate(['/admin/user'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        data: 'true',
        firstName: (this.firstName = ''),
        lastName: (this.lastName = ''),
        storeName: (this.storeName = ''),
        email: this.email,
        phone: (this.phone = ''),
      },
      queryParamsHandling: 'merge',
    });
    this.getAllUserWithPagging();
  }, 1000);
  filterByPhone = debounce(($event: any) => {
    this.phone = $event.target.value;
    this.PageIndex = 1;
    this.router.navigate(['/admin/user'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        data: 'true',
        firstName: (this.firstName = ''),
        lastName: (this.lastName = ''),
        storeName: (this.storeName = ''),
        email: (this.email = ''),
        phone: this.phone,
        City: (this.City = ''),
        StateName: (this.StateName = ''),
        ZipCode: this.ZipCode,
      },
      queryParamsHandling: 'merge',
    });
    this.getAllUserWithPagging();
  }, 1000);

  search = debounce(($event: any) => {
    this.FirstNameOrEmailOrPhone = $event.target.value;
    this.PageIndex = 1;
    this.router.navigate(['/admin/user'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        data: 'true',
        search: this.FirstNameOrEmailOrPhone,
      },
      queryParamsHandling: 'merge',
    });
    this.getAllUserWithPagging();
  }, 1000);

  allState: any = [];
  stateName: string = '';
  StateName: string = '';
  City: string = '';
  ZipCode: string = '';
  getAllState() {
    this.storeService
      .getStateAutoComplete(this.stateName)
      .subscribe((data: any) => {
        this.allState = data.data;
      });
  }
  serachByCompanyName = debounce((event: any) => {
    if (event.target.value) {
      this.stateName = event.target.value;
      this.getAllState();
    } else if (event.target.value == '') {
      this.stateName = '';
      this.getAllState();
    }
  }, 1000);
  onClickState(stateId: any) {
    if (stateId == 0) {
      this.StateName = '';
    } else {
      this.StateName = stateId;
    }

    this.router.navigate(['/admin/user'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        data: 'true',
        firstName: (this.firstName = ''),
        lastName: (this.lastName = ''),
        storeName: (this.storeName = ''),
        email: (this.email = ''),
        phone: this.phone,
        StateName: this.StateName,
        City: (this.City = ''),
        ZipCode: (this.ZipCode = ''),
      },
      queryParamsHandling: 'merge',
    });
    this.getAllUserWithPagging();
  }
  filterByStateName = debounce((event) => {
    this.StateName = event.target.value;
    this.PageIndex = 1;

    this.router.navigate(['/admin/user'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        data: 'true',
        firstName: (this.firstName = ''),
        lastName: (this.lastName = ''),
        storeName: (this.storeName = ''),
        email: (this.email = ''),
        phone: this.phone,
      },
      queryParamsHandling: 'merge',
    });
    this.getAllUserWithPagging();
  }, 1000);
  filterByCity = debounce((event) => {
    this.City = event.target.value;
    this.PageIndex = 1;
    this.router.navigate(['/admin/user'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        data: 'true',
        firstName: (this.firstName = ''),
        lastName: (this.lastName = ''),
        storeName: (this.storeName = ''),
        email: (this.email = ''),
        phone: this.phone,
        City: this.City,
        StateName: (this.StateName = ''),
        ZipCode: (this.ZipCode = ''),
      },
      queryParamsHandling: 'merge',
    });
    this.getAllUserWithPagging();
  }, 1000);
  filterByZipCode = debounce((event) => {
    this.ZipCode = event.target.value;
    this.PageIndex = 1;
    this.router.navigate(['/admin/user'], {
      queryParams: {
        PageIndex: this.PageIndex,
        PageSize: this.PageSize,
        data: 'true',
        firstName: (this.firstName = ''),
        lastName: (this.lastName = ''),
        storeName: (this.storeName = ''),
        email: (this.email = ''),
        phone: this.phone,
        City: (this.City = ''),
        StateName: (this.StateName = ''),
        ZipCode: this.ZipCode,
      },
      queryParamsHandling: 'merge',
    });
    this.getAllUserWithPagging();
  }, 1000);
}

export interface UserTable {
  userId: string;
  firstName: string;
  lastName: string;
  email: string;
  action: string;
  phones: [
    {
      phoneId: number;
      categoryTypeLevelId: number;
      countryCode: string;
      areaCode: string;
      number: string;
    }
  ];
  // emails: [
  //   {
  //     emailId: number;
  //     categoryTypeLevelId: number;
  //     email: string;
  //   }
  // ];
}
