import { Component, Inject, OnInit, Optional } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
export interface UsersData {
  roleId: number;
  roleName: string;
}

@Component({
  selector: 'app-create-role',
  templateUrl: './create-role.component.html',
  styleUrls: ['./create-role.component.scss'],
})
export class CreateRoleComponent implements OnInit {
  checked = true;
  local_data: any;

  constructor(
    private indentityService: IdentityService,
    private formBuilder: FormBuilder,
    private toster: ToastrService,
    public dialogRef: MatDialogRef<CreateRoleComponent>,
    @Inject(MAT_DIALOG_DATA) public data: UsersData,
    private router: Router
  ) {
    // console.log(data);
    this.local_data = { ...data };
    // console.log(this.local_data);
  }
  createRoleForm!: FormGroup;
  submitted: boolean = false;
  roleType: any;
  get f() {
    return this.createRoleForm.controls;
  }
  ngOnInit(): void {
    this.createRoleForm = this.formBuilder.group({
      roleName: new FormControl(
        '',
        Validators.compose([
          Validators.required,
          Validators.pattern('[a-zA-Z- /S]+$'),
        ])
      ),
      roleType: new FormControl(null, Validators.required),
    });
    this.getRoleType();
  }
  // get role type

  getRoleType() {
    this.indentityService.getRoleType().subscribe((data: any) => {
      this.roleType = data.data;
    });
  }
  naviagete() {
    this.router.navigateByUrl('/admin/');
  }

  public createRole(): void {
    this.indentityService
      .createRole(this.createRoleForm.value)
      .subscribe((data) => {
        if (data == data) {
          this.toster.success('Roles Create Successfully');
          this.createRoleForm.reset();
          this.dialogRef.close([]);
        }
      });
  }
}
