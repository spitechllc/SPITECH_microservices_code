import { Component, OnInit } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { ActivatedRoute, Router } from '@angular/router';
import { IdentityService } from '../../api-service/identityService';
import { AuthService } from '../../auth/auth.service';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss'],
})
export class UserComponent implements OnInit {
  constructor(
    private router: Router,
    private indentityService: IdentityService,
    private auth: AuthService
  ) {}
  tabPostion: any;
  tabName: string = 'Users';
  claimIdArray: any;
  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
  }
  onClickTab(event: any) {
    this.tabName = event.tab.textLabel;
    if (event.index == 1) {
      this.router.navigate(['/admin/user'], {
        queryParams: {
          tab: 'storeOwner',
        },
        queryParamsHandling: 'merge',
      });
    }
    if (event.index == 3) {
      this.router.navigate(['/admin/user'], {
        queryParams: {
          tab: 'permissions',
        },
        queryParamsHandling: 'merge',
      });
    }
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  // getRoles() {
  //   this.indentityService.getRoles().subscribe((data: any) => {});
  // }

  queryParams() {}
  tabChanged = (tabChangeEvent: MatTabChangeEvent): void => {};
}
