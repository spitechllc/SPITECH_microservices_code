import { state } from '@angular/animations';
import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute } from '@angular/router';
import { RxwebValidators } from '@rxweb/reactive-form-validators';
import { debounce } from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
import { RequestService } from 'src/app/dashboard/api-service/request-service/request.service';
import { SnackbarService } from 'src/app/dashboard/api-service/snackbar/snackbar.service';
import { StoreService } from 'src/app/dashboard/api-service/storeService';
import { UserService } from 'src/app/dashboard/api-service/userService';
import { SharedService } from 'src/app/dashboard/auth/shared.service';
import { ChangePasswordComponent } from 'src/app/dashboard/header/change-password/change-password.component';
import { CREATE_USER } from 'src/environments/api.paths';
import { environment } from 'src/environments/environment';
import { SubSink } from 'subsink';

@Component({
  selector: 'app-add-edit-user',
  templateUrl: './add-edit-user.component.html',
  styleUrls: ['./add-edit-user.component.scss'],
})
export class AddEditUserComponent implements OnInit {
  userForm!: FormGroup;
  subs = new SubSink();
  phonecategory: any;
  emailcategory: any;
  userId: any = null;
  submitted: boolean = false;
  roleDetails: any;
  store: any;
  companyId: any;
  region: any;
  loading: boolean = false;
  title: any;
  PageIndex = 1;
  PageSize = 50;
  SortBy = 'userId';
  SortOrder = 'asc';
  companyerr: string = '';
  storeerr: string = '';
  FirstNameOrEmailOrPhone: string = '';
  CompanyId: any;
  StoreId: any;
  comapnyDetals: any;
  lengthOfCompanyData: any;
  lengthOfStoreData: any;
  dataNotFond: string = 'Data not found';
  companyDataNotFond: string = 'Data not found';
  firstName: string = '';
  lastName: string = '';
  storeId: number = 0;
  email: string = '';
  phone: string = '';
  storeDetails: any;

  storeName: string = '';
  get f() {
    return this.userForm.controls;
  }

  get phones() {
    return this.userForm.get('phones') as FormArray;
  }
  get emails() {
    return this.userForm.get('emails') as FormArray;
  }
  get roleIds() {
    return this.userForm.get('roleIds') as FormArray;
  }

  constructor(
    private fb: FormBuilder,
    private storeService: StoreService,
    private router: Router,
    private request: RequestService,
    private activatedRoute: ActivatedRoute,
    private identityServer: IdentityService,
    private userService: UserService,
    private toster: ToastrService,
    private _location: Location,
    private spinner: NgxSpinnerService,
    public SharedService: SharedService,
    public dialog: MatDialog
  ) {}
  historyStateData: any = {};
  ngOnInit(): void {
    this.historyStateData = history.state;
    this.getCompany();

    this.createForm();
    this.getRoles();
    this.getRegion();
    this.companyId = localStorage.getItem('companyId');
    this.getUserId();
    this.getUsersDetails();
    this.getEmailCategoryLevel();
    this.phoneCategory();
    this.getAddressCategoryLevel();
    this.getTitle();
  }

  getTitle() {
    this.storeService.getTitle().subscribe((data: any) => {
      this.title = data.data;
    });
  }
  addressCategory: any;
  getAddressCategoryLevel() {
    this.storeService.getCategoryLavelAddress(1).subscribe((data: any) => {
      this.addressCategory = data.data;
    });
  }
  getUserId() {
    this.subs.add(
      this.activatedRoute.paramMap.subscribe((params) => {
        this.userId = params.get('id');
        if (this.userId) {
          this.getUserDetails(this.userId);
        }
      })
    );
  }

  getUserDetails(id: any) {
    this.subs.add(
      this.userService.getUserDetailsbyId(id).subscribe(
        (data) => {
          this.setFormValue(data);
        },
        (err) => {
          if (err.error.errors.UserId) {
            err.error.errors.UserId.forEach((err: any) => {
              this.toster.error(err);
            });
          }
        }
      )
    );
  }
  checked = true;
  passValue: string = '********';
  createForm() {
    this.userForm = this.fb.group({
      // userId: ['', Validators.required],
      title: [0],
      isActive: true,
      userName: this.userId ? [''] : ['', Validators.required],
      password: this.userId
        ? ['']
        : [
            '',
            Validators.compose([
              Validators.min(8),

              Validators.pattern(
                '(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-zd$@$!%*?&].{7,}'
              ),
            ]),
          ],
      firstName: [
        '',
        Validators.compose([
          Validators.required,

          Validators.minLength(2),
          Validators.maxLength(50),
          Validators.pattern('[a-zA-Z- /S]+$'),
        ]),
      ],
      lastName: [
        '',
        Validators.compose([
          Validators.required,
          Validators.minLength(1),
          Validators.maxLength(50),
          Validators.pattern('[a-zA-Z- /S]+$'),
        ]),
      ],
      designationId: null,
      companyId: [0],
      storeId: [0],
      managerId: [0],
      regionId: [0],
      addresses: this.fb.array([]),
      phones: this.fb.array([this.createPhoneForm()]),
      emails: this.fb.array([this.createEmailForm('')]),
      roleIds: ['', Validators.required],
      // roleIds: this.fb.array([this.createroleIdsForm()]),
    });
  }
  hide = true;

  get passwordInput() {
    return this.userForm.get('password');
  }
  countryCode: any;
  countryChange(value: any) {
    this.countryCode = value;
  }
  setFormValue(data: any) {
    let roles = data.roles.map(this.getRoleIdArray);
    this.userForm.patchValue({
      title: data.title,
      userName: data.userName,
      password: data.password,
      isActive: data.isActive,
      firstName: data.firstName,
      lastName: data.lastName,
      designationId: data.designationId,
      companyId: data.companyId,
      storeId: data.storeId,
      managerId: data.managerId,
      regionId: data.regionId,
      roleIds: roles,
    });
    if (data.companyId) {
      this.storeService
        .autoSuggestByCompanyId(data.companyId)
        .subscribe((data: any) => {
          this.comapnyDetals = data.data;
        });
      this.storeService
        .getStoreByCompanyId(data.companyId)
        .subscribe((data: any) => {
          this.storeDetails = data.data;
        });
    }
    data.phones.forEach((element: any, index: any) => {
      if (index < data.phones.length - 1) {
        this.addAnotherPhone();
      }
      this.phones.controls[index].patchValue(element);
    });
    data.emails.forEach((element: any, index: any) => {
      if (index < data.emails.length - 1) {
        this.addAnotherEmail();
      }
      this.emails.controls[index].patchValue(element);
    });
  }
  compayName: string = '';
  createroleIdsForm() {
    return this.fb.group({
      roleIds: [],
    });
  }
  createPhoneForm() {
    return this.fb.group({
      phoneId: [0],
      categoryTypeLevelId: ['', Validators.required],
      areaCode: [''],
      number: [
        '',
        Validators.compose([
          Validators.required,
          Validators.maxLength(13),
          Validators.pattern('[- +()0-9]+'),
          RxwebValidators.unique(),
        ]),
      ],
      countryCode: ['+1', Validators.required],
    });
  }

  addAnotherPhone() {
    this.phones.push(this.createPhoneForm());
    if (this.phoneCategoryLength == this.phones.length) {
      var DATA = document.getElementById('addphone');
      DATA!.style.display = 'none';
    }
  }

  removePhone(i: any) {
    this.phones.removeAt(i);
    var DATA = document.getElementById('addphone');
    DATA!.style.display = '';
  }

  createEmailForm(email: string) {
    return this.fb.group({
      emailId: [0],
      categoryTypeLevelId: ['', Validators.required],
      email: [email, Validators.required],
    });
  }
  emailCategoryIndex: any;
  onClickCategory(categoryIndex: any) {
    this.emailCategoryIndex = categoryIndex;
  }

  addAnotherEmail() {
    this.emails.push(this.createEmailForm(''));
    if (this.emailcategory.length == this.emails.length) {
      var DATA = document.getElementById('addemail');

      DATA!.style.display = 'none';
    }
  }

  isControlExist(categoryTypeLevelId: any): boolean {
    for (var i = 0; i < this.emails.controls.length; i++) {
      if (
        this.emails.controls[i].value.categoryTypeLevelId == categoryTypeLevelId
      ) {
        return true;
      }
    }

    return false;
  }

  onCopyClick(emailIndex: any) {
    const emailCopy = this.emails.controls[emailIndex].value.email;

    if (!this.emails.controls[emailIndex].valid) {
      this.toster.error('Please enter a valid email before copy');
      return;
    }
    for (var i = 0; i < this.emails.controls.length; i++) {
      if (this.emails.controls[i].value.categoryTypeLevelId <= 0) {
        this.toster.error('Please remove blank category before copy');
        return;
      }
    }

    this.emailcategory.forEach((emailCat: any, index: any) => {
      if (!this.isControlExist(emailCat.id)) {
        if (this.emails.controls.length < this.emailcategory.length) {
          this.addAnotherEmail();
          this.emails.controls[this.emails.controls.length - 1].patchValue({
            categoryTypeLevelId: emailCat.id,
            email: emailCopy,
          });
        }
      } else {
        for (var i = 0; i < this.emails.controls.length; i++) {
          this.emails.controls[i].patchValue({
            email: emailCopy,
          });
        }
      }
    });
  }

  removeEmail(i: any) {
    // let i = this.emails.length - 1;
    this.emails.removeAt(i);
    var DATA = document.getElementById('addemail');
    DATA!.style.display = '';
  }
  phoneCategoryLength: any;
  phoneCategory() {
    this.storeService.getCategoryLevelPhone(7).subscribe((data: any) => {
      this.phonecategory = data.data;
      this.phoneCategoryLength = this.phonecategory.length;
    });
  }

  getEmailCategoryLevel() {
    this.storeService.getCategoryLevelEmail(4).subscribe((data: any) => {
      this.emailcategory = data.data;
    });
  }

  getRoles() {
    this.identityServer.getRoles().subscribe((data: any) => {
      const filteredRoleDetails = data.filter(
        (role: any) => role.roleId !== 'ConsumerUser'
      );
      this.roleDetails = filteredRoleDetails;
    });
  }

  serachByCompanyName = debounce((event: any) => {
    if (event.target.value) {
      this.compayName = event.target.value;
      this.getCompany();
    } else if (event.target.value == '') {
      this.CompanyId = 0;
    }
  }, 1000);

  getCompany() {
    const PageIndex: number = 1;
    const PageSize: number = 10;
    this.storeService
      .autoSuggestByCompanyName(this.compayName)
      .subscribe((data: any) => {
        this.comapnyDetals = data.data;
        this.lengthOfCompanyData = data.data.length;
      });
  }

  onClickCompanyName(event: any) {
    this.CompanyId = event;
    this.userForm.patchValue({ companyId: event });
  }
  onClickOnCompany(companyId: any) {
    console.log(companyId);
    this.storeService.getStoreByCompanyId(companyId).subscribe((data: any) => {
      this.storeDetails = data.data;
    });
  }

  onClickStoreName(event: any) {
    this.StoreId = event;
  }

  onChangeStore(id: number) {
    if (id) {
      this.storeService.getStoreByCompanyId(id).subscribe((data: any) => {
        this.store = data.data;
      });
    }
  }
  userDetails: any;
  totalCount: any;
  storeNames: string = '';
  StateName: string = '';
  City: string = '';
  ZipCode: string = '';
  tenanntId: number = 0;
  getUsersDetails() {
    this.userService
      .getUserByPagging(
        this.PageIndex,
        this.PageSize,
        this.SortOrder,
        this.SortBy,
        this.firstName,
        this.lastName,
        this.storeNames,
        this.email,
        this.phone,
        this.StateName,
        this.City,
        this.ZipCode
      )
      .subscribe((data: any) => {
        this.userDetails = data.data;
        this.totalCount = data.totalCount;
        this.PageSize = this.totalCount;
        if (this.totalCount) {
          this.userService
            .getUserByPagging(
              this.PageIndex,
              this.PageSize,
              this.SortOrder,
              this.SortBy,
              this.firstName,
              this.lastName,
              this.storeNames,
              this.email,
              this.phone,
              this.StateName,
              this.City,
              this.ZipCode
            )
            .subscribe((data: any) => {
              this.userDetails = data.data;
            });
        }
      });
  }

  getRegion() {
    this.storeService.getRegion().subscribe((data: any) => {
      this.region = data.data;
    });
  }

  submit() {
    if (this.userId) {
      this.updateUser();
    } else {
      this.createUser();
    }
  }

  err: any;
  createUser() {
    this.submitted = true;
    if (this.userForm.invalid) return;
    this.userService.addUser(this.userForm.value).subscribe(
      (res) => {
        this.loading = false;
        this.toster.success('User Created successfully!');
        this.cancelBUtton();
      },
      (err) => {
        this.loading = false;
        this.err = err.message;

        if (err.status == 500) {
          this.toster.error('Internal Server Error');
        }
        if (err.error.errors.CategoryLevel) {
          err.error.errors.CategoryLevel.forEach((err: any) => {
            this.toster.error(err, '', {
              timeOut: 10000,
            });
          });
        }
        if (err.error.errors.Email) {
          err.error.errors.Email.forEach((err: any) => {
            this.toster.error(err);
          });
        }
        if (err.error.errors.UserName) {
          err.error.errors.UserName.forEach((err: any) => {
            this.toster.error(err, '', {
              timeOut: 10000,
            });
          });
        }
        if (err.error.errors.CompanyId) {
          err.error.errors.CompanyId.forEach((err: any) => {
            this.toster.error('Company is required!', '', {
              timeOut: 10000,
            });
          });
        }
        if (err.error.errors.StoreId) {
          err.error.errors.StoreId.forEach((err: any) => {
            this.toster.error('Store is required!', '', {
              // positionClass: 'inline',
              timeOut: 10000,
            });
          });
        }
      }
    );
  }

  updateUser() {
    this.submitted = true;
    if (this.userForm.invalid) return;
    this.userService
      .updateEditUser({ ...this.userForm.value, userId: this.userId })
      .subscribe(
        (res) => {
          this.toster.success('User updated successfully!');
          this.loading = false;

          this.cancelBUtton();
        },
        (err) => {
          if (err.status == 500) {
            this.toster.error('Internal Server Error');
          }
          if (err.status == 404) {
            this.toster.error('Invalid Url');
          }
          if (err.status == 401) {
            this.toster.error('Token error');
          }
          if (err.error.errors.UserId) {
            err.error.errors.UserId.forEach((err: any) => {
              this.toster.error(err);
            });
          }
          if (err.error.errors.CompanyId) {
            err.error.errors.CompanyId.forEach((err: any) => {
              this.companyerr = err;
              this.toster.error('Company is required!', '', {
                // positionClass: 'inline',
                timeOut: 10000,
              });
            });
          }
          if (err.error.errors.StoreId) {
            err.error.errors.StoreId.forEach((err: any) => {
              this.storeerr = err;

              this.toster.error('Store is required!', '', {
                // positionClass: 'inline',
                timeOut: 10000,
              });
            });
          }
          this.loading = false;
        }
      );
  }
  onClickChangePassword() {
    const dialogRef = this.dialog.open(ChangePasswordComponent, {
      width: '430px',
      panelClass: 'popup',
      data: this.userId,
    });
  }
  roleName: any;
  onChangeRole(roleId: any) {
    this.roleDetails.filter((element: any) => {
      if (element.roleId == roleId) {
        this.roleName = element.roleName;
        return element.roleName;
      }
    });
  }

  Roles: any;
  storeDropDown: boolean = false;
  getRoleIdArray(data: any) {
    // this.Roles = data.roleId;

    return data.roleId;
    // this.checkPermission(data.roleId);
  }
  onClickRole(event: any) {
    event.value?.forEach((element: any) => {
      this.checkPermission(element);
    });
    this.checkRoles = event.value;
  }
  checkRoles: any = [];
  checkPermission(roleId: any) {
    return this.checkRoles.includes(roleId);
  }
  cancelBUtton() {
    this._location.back();
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }
}
