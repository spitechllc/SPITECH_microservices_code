import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddEditUserComponent } from './add-edit-user.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from 'src/app/shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { RolePermissionGuard } from 'src/app/dashboard/auth/role-permission.guard';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { RxReactiveFormsModule } from '@rxweb/reactive-form-validators';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { NgxMaskModule, IConfig } from 'ngx-mask';
export const options: Partial<null | IConfig> | (() => Partial<IConfig>) = null;
const routes: Routes = [
  {
    path: '',
    component: AddEditUserComponent,
    canActivate: [RolePermissionGuard],
  },
  {
    path: '',
    component: AddEditUserComponent,
    canActivate: [RolePermissionGuard],
  },
];

@NgModule({
  declarations: [AddEditUserComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    SharedModule,
    NgxMaskModule.forRoot({
      showMaskTyped: true,
      // clearIfNotMatch : true
    }),
    MatAutocompleteModule,
    ReactiveFormsModule,
    RxReactiveFormsModule,
  ],
})
export class AddEditUserModule {}
