import { Component, OnInit } from '@angular/core';
import { debounce, startsWith } from 'lodash';
import { StoreService } from 'src/app/dashboard/api-service/storeService';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from 'src/app/dashboard/auth/auth.service';
import { MatTableDataSource } from '@angular/material/table';
import { PageEvent } from '@angular/material/paginator';
import { ExcelService } from 'src/app/dashboard/api-service/excel-servive/excel.service';
import { SharedService } from 'src/app/dashboard/auth/shared.service';
@Component({
  selector: 'app-store-owner',
  templateUrl: './store-owner.component.html',
  styleUrls: ['./store-owner.component.scss'],
})
export class StoreOwnerComponent implements OnInit {
  displayedColumns = [
    'userId',
    'firstName',
    'lastName',
    'companyId',
    'companyName',
  ];
  dataSource = new MatTableDataSource<Storewner>([]);
  storeOwnerform!: FormGroup;
  get storeIds() {
    return this.storeOwnerform.get('companyIds') as FormArray;
  }
  allStoreOwnerData: any = [];
  allCompany: any;
  company: string = '';
  suggestEventValue: any;
  storeDetails: any;
  lengthsite: any;
  StoreId: any;
  submitted: boolean = false;
  paramsData: any;
  claimIdArray: any;
  get f() {
    return this.storeOwnerform.controls;
  }
  constructor(
    private storeService: StoreService,
    private fb: FormBuilder,
    private toster: ToastrService,
    private activateRoute: ActivatedRoute,
    private auth: AuthService,
    private excelService: ExcelService,
    private sharedService: SharedService
  ) {}
  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.activateRoute.queryParamMap.subscribe((data: any) => {
      this.paramsData = data.params;
      if (this.paramsData.tab == 'storeOwner') {
        this.getAllStoreOwner();
        this.getAllStoreOwnerTable();
      }
    });
    this.createForm();

    this.getAllCompany();
  }

  companyId: any;
  comapiesName: any;
  exportAsExcel() {
    var pageSize = 0;
    var pageIndex = 0;
    this.storeService
      .getAllStoreOwners(
        this.firstNames,
        this.lastNames,
        this.emails,
        this.phones,
        this.sortBy,
        this.sortOrder,
        pageIndex,
        pageSize
      )
      .subscribe((data: any) => {
        if (data.data) {
          this.excelService.exportAsExcelFile(
            data.data.map((f: any) => {
              return {
                'User ID': f.owner.userId,
                'First Name': f.owner.firstName,
                'Last Name': f.owner.lastName,
                'Company Id': f.companies.map((c: any) => {
                  this.companyId = c.id;
                  this.comapiesName = c.name;

                  return {};
                })
                  ? this.companyId
                  : '',
                'Company Name': this.comapiesName,
              };
            }),
            'Store Owner'
          );
        }
      });
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  createForm() {
    this.storeOwnerform = this.fb.group({
      companyIds: [[0]],
      ownerId: new FormControl('', Validators.required),
      tenantId: new FormControl(0),
    });
  }
  oncChhage(event: any) {}
  onHeaderSortChange(event: any) {
    this.sortBy = event.active;
    if (event.direction == '') {
      this.sortOrder = 'asc';
    } else {
      this.sortOrder = event.direction;
    }
    this.getAllStoreOwnerTable();
  }
  firstNames: string = '';
  lastNames: string = '';
  emails: string = '';
  phones: string = '';
  pageIndex: number = 1;
  pageSize: number = 50;
  sortBy: string = '';
  sortOrder: string = '';
  totalCountData: number = 0;
  getAllStoreOwnerTable() {
    this.storeService
      .getAllStoreOwners(
        this.firstNames,
        this.lastNames,
        this.emails,
        this.phones,
        this.sortBy,
        this.sortOrder,
        this.pageIndex,
        this.pageSize
      )
      .subscribe((data: any) => {
        this.dataSource = new MatTableDataSource(data.data);
        this.totalCountData = data.totalCount;
      });
  }
  pageChanged(event: PageEvent) {
    this.pageIndex = event.pageIndex + 1;
    this.pageSize = event.pageSize;

    this.getAllStoreOwnerTable();
  }
  getAllStoreOwner() {
    this.storeService
      .getAllStoreOwner(this.firstName, this.lastName, this.email, this.phone)
      .subscribe((data: any) => {
        this.allStoreOwnerData = data.data;
        // console.log(this.allStoreOwnerData);
      });
  }
  updateStoreOwner() {
    this.submitted = true;
    if (this.storeOwnerform.get('ownerId')?.invalid) return;
    this.storeService.updateOwnerCompany(this.storeOwnerform.value).subscribe(
      (data: any) => {
        this.toster.success('Update Store Owner with Company Sucessfully');
        this.getAllStoreOwnerTable();
      },
      (err) => {
        if (err.error.errors.Company) {
          err.error.errors.Company.forEach((err: any) => {
            this.toster.error(err);
          });
        }
        if (err.error.errors.CompanyIds) {
          err.error.errors.CompanyIds.forEach((err: any) => {
            this.toster.error(err);
          });
        }
      }
    );
  }

  getAllCompany() {
    this.storeService.getAllCompany(this.company).subscribe((data: any) => {
      this.allCompany = data.data;
    });
  }
  searchByCompanyName = debounce(($event: any) => {
    if ($event.target.value == '') {
      this.company = '';
    } else {
      this.company = $event.target.value;
    }
    this.getAllCompany();
  }, 1000);

  onChangeStoreOwner(ownerId: any) {
    if (ownerId) {
      this.storeService.getStoreOwnerId(ownerId).subscribe((data: any) => {
        this.storeOwnerform.patchValue({
          companyIds: data.companyIds,
        });
      });
    }
  }
  onChange(event: any) {
    this.suggestEventValue = event;
  }
  firstName: string = '';
  lastName: string = '';
  email: string = '';
  phone: string = '';
  getSearchByFirstName = debounce(($event: any) => {
    this.lastName = '';
    this.email = '';
    this.phone = '';
    if ($event.target.value == '') {
      this.firstName = '';
    } else {
      this.firstName = $event.target.value;
    }
    this.getAllStoreOwner();
  }, 1000);
  getSearchByLastName = debounce(($event: any) => {
    if ($event.target.value == '') {
      this.lastName = '';
    } else {
      this.lastName = $event.target.value;
    }

    this.firstName = '';
    this.email = '';
    this.phone = '';

    this.getAllStoreOwner();
  }, 1000);
  getSearchByEmail = debounce(($event: any) => {
    this.firstName = '';
    this.lastName = '';
    this.phone = '';

    if ($event.target.value == '') {
      this.email = '';
    } else {
      this.email = $event.target.value;
    }
    this.getAllStoreOwner();
  }, 1000);
  getSearchByPhone = debounce(($event: any) => {
    if ($event.target.value == '') {
      this.phone = '';
    } else {
      this.phone = $event.target.value;
    }
    this.firstName = '';
    this.lastName = '';
    this.email = '';

    this.getAllStoreOwner();
  }, 1000);

  serachBySiteId = debounce((event: any) => {
    if (!event.target.value) {
      this.StoreId = 0;
    }
    this.storeService
      .getStoreAutoCompleteBySiteId(event.target.value)
      .subscribe((data: any) => {
        this.lengthsite = data.data.length;

        this.storeDetails = data.data;

        this.StoreId = this.storeDetails.storeId;
      });
  }, 1000);
  serachByStoreName = debounce((event: any) => {
    if (!event.target.value) {
      this.StoreId = 0;
    }
  }, 1000);
}
export interface Storewner {
  userId: Number;
  firstName: string;
  lastName: string;
}
