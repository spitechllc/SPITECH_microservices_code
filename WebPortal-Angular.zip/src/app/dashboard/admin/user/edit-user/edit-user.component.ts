import { Component, OnInit } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';

import { StoreService } from 'src/app/dashboard/api-service/storeService';
import { UserService } from 'src/app/dashboard/api-service/userService';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.scss'],
})
export class EditUserComponent implements OnInit {
  checked = true;
  constructor(
    private userService: UserService,
    private formBuilder: FormBuilder,
    private storeService: StoreService,
    private activatedRoute: ActivatedRoute,
    private indentityService: IdentityService,
    private toster: ToastrService,
    private route: Router
  ) {}
  editUserForm!: FormGroup;
  dataLoaded: boolean = false;
  userId: any;
  userDetails: any;
  companyId: any;
  ngOnInit(): void {
    //Form
    this.editUserForm = this.formBuilder.group({
      userId: ['', Validators.required],
      title: ['', Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      designationId: ['', Validators.required],
      companyId: ['', Validators.required],
      storeId: ['', Validators.required],
      managerId: ['', Validators.required],
      regionId: ['', Validators.required],
      phones: this.formBuilder.array([]),
      emails: this.formBuilder.array([]),
    });

    // this.dataLoaded = false
    this.activatedRoute.params.subscribe((data: any) => {
      // console.log(data);
      this.userId = data.userId;
    });

    if (this.userId) {
      const _id: number = this.userId as number;
      this.userService
        .getUserDetailsbyId(_id)
        .toPromise()
        .then((data: any) => {
          this.userDetails = data;
          // console.log(this.userDetails);
          // console.log(this.userDetails.phones);
          this.editUserForm.patchValue({
            ...this.userDetails,

            phones: this.assignPhones(this.userDetails.phones),
            emails: this.assignEmails(this.userDetails.emails),
          });

          //  this.dataLoaded = true
        })
        .catch((error) => {
          // console.log(error);
        });
    }
    this.getEmailCategoryLevel();
    this.phoneCategory();

    this.getRegion();
    this.getRoles();
    this.companyId = localStorage.getItem('companyId');
    this.getCompany();
    this.getUsersDetails();
  }
  phonesArray(): FormArray {
    return this.editUserForm.get('phones') as FormArray;
  }

  phonesObject(item: any): FormGroup {
    return this.formBuilder.group({
      phoneId: item.phoneId,
      categoryTypeLevelId: item.categoryTypeLevelId,
      countryCode: item.countryCode,
      areaCode: item.areaCode,
      number: item.number,
    });
  }

  assignPhones(phones: Array<any>) {
    for (let item of phones) {
      this.phonesArray().push(this.phonesObject(item));
    }
  }
  addMorePhone() {
    (<FormArray>this.editUserForm.get('phones')).push(
      this.formBuilder.group({
        categoryTypeLevelId: [],
        countryCode: [''],
        areaCode: ['91'],
        number: [''],
      })
    );
  }
  emailsArray(): FormArray {
    return this.editUserForm.get('emails') as FormArray;
  }

  emailObject(item: any): FormGroup {
    return this.formBuilder.group({
      emailId: item.emailId,
      categoryTypeLevelId: item.categoryTypeLevelId,
      email: item.email,
    });
  }

  assignEmails(emails: Array<any>) {
    for (let item of emails) {
      this.emailsArray().push(this.emailObject(item));
    }
  }
  addMoreEmail() {
    (<FormArray>this.editUserForm.get('emails')).push(
      this.formBuilder.group({
        categoryTypeLevelId: [],
        email: [''],
      })
    );
  }
  removeEmail(j: any) {
    (<FormArray>this.editUserForm.get('emails')).removeAt(j);
  }

  userMangerDetails: any;
  getUsersDetails() {
    this.userService.findAllUser().subscribe((data: any) => {
      // console.log(data);
      this.userMangerDetails = data.data;
      // console.log(this.userMangerDetails,'userDetailsmanger')
    });
  }
  comapnyDetals: any;

  getCompany() {
    this.storeService.getCompanyWithPagging().subscribe((data: any) => {
      this.comapnyDetals = data.data;
      // console.log(this.comapnyDetals, 'comapnyDetails')
    });
  }
  onChangeStore(id: number) {
    // console.log(id);
    if (id) {
      this.storeService.getStoreByCompanyId(id).subscribe((data: any) => {
        this.store = data.data;
        // console.log(this.store, 'store');
      });
    }
  }
  roleDetails: any;
  getRoles() {
    // this.oidcSecurityService.authorize();
    this.indentityService.getRoles().subscribe((data: any) => {
      this.roleDetails = data;
      // console.log(this.roleDetails, 'roleid')
    });
  }
  get userPhoneFormGroups(): FormArray {
    return this.editUserForm.get('phones') as FormArray;
  }

  //   getuserPhoneFormGroup(): FormArray{
  // return this.editUserForm.get('') as FormArray
  //   }
  get userEmailFormGroups(): FormArray {
    return this.editUserForm.get('emails') as FormArray;
  }

  region: any;
  getRegion() {
    this.storeService.getRegion().subscribe((data: any) => {
      this.region = data.data;
      // console.log(this.region, 'region');
    });
  }
  phonecategory: any;
  phoneCategory() {
    this.storeService.getCategoryLevelPhone(7).subscribe((data: any) => {
      this.phonecategory = data.data;
      // console.log(this.phonecategory);
    });
  }
  emailcategory: any;
  getEmailCategoryLevel() {
    this.storeService.getCategoryLevelEmail(4).subscribe((data: any) => {
      this.emailcategory = data.data;
      // console.log(this.emailcategory, 'emaill');
    });
  }
  store: any;
  getStore() {
    this.storeService.getStore().subscribe((data: any) => {
      // console.log(data);
      this.store = data.data;
      // console.log(this.store, 'stores');
    });
  }
  navigateRoute() {
    this.route.navigateByUrl('/admin/user');
  }
  updateUser() {
    this.userService
      .updateEditUser(this.editUserForm.value)
      .subscribe((data) => {
        if (data == data) {
          this.toster.success('User edit  successfuly');
          this.navigateRoute();
        }
      });
  }
}
