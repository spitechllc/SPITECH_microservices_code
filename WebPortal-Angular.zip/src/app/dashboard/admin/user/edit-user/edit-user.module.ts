import { NgModule } from '@angular/core';
import { SharedModule } from './../../../../shared.module';
import { RouterModule, Routes } from '@angular/router';
import { TagInputModule } from 'ngx-chips';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EditUserComponent } from './edit-user.component';



export const router: Routes = [
  {path: ':userId', component: EditUserComponent}
]


@NgModule({
    declarations: [EditUserComponent],
    imports: [
        SharedModule,
        FormsModule,
        TagInputModule,
        ReactiveFormsModule,
        RouterModule.forChild(router)
    ]
})
export class EditUsereModule { }