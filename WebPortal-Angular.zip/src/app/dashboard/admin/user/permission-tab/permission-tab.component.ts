import { Component, OnInit } from '@angular/core';
import { RequestService } from 'src/app/dashboard/api-service/request-service/request.service';
import { SubSink } from 'subsink';
import { environment } from 'src/environments/environment';
import {
  GET_CLAIMS,
  GET_ROLES,
  SET_ROLE_CLAIMS,
} from 'src/environments/api.paths';
import { SnackbarService } from 'src/app/dashboard/api-service/snackbar/snackbar.service';
import { AuthService } from 'src/app/dashboard/auth/auth.service';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-permission-tab',
  templateUrl: './permission-tab.component.html',
  styleUrls: ['./permission-tab.component.scss'],
})
export class PermissionTabComponent implements OnInit {
  subs = new SubSink();
  roleList: any = [];
  claimList: any = [];
  roleWiseClaim: any = [];
  selectedRole: any = {
    roleId: null,
    claims: [],
    claim: [],
  };
  claimIdArray: any;
  loading: boolean = false;
  constructor(
    private request: RequestService,
    private toster: ToastrService,
    private auth: AuthService,
    private identityService: IdentityService,
    private activateRoute: ActivatedRoute
  ) {}
  paramsData: any;
  ngOnInit(): void {
    this.activateRoute.queryParamMap.subscribe((data: any) => {
      this.paramsData = data.params;

      // console.log(this.paramsData, 'subdata');
      if (this.paramsData.tab == 'permissions') {
        this.getRoles();
        this.getClaims();
      }
    });
    const claim = this.auth.getClaims();
    // const claim = localStorage.getItem('clams');
    this.claimIdArray = claim;
    this.getRoles();
    this.getClaims();
  }
  filteredRoleDetails: any = [];
  getRoles() {
    this.subs.add(
      this.identityService.getRoles().subscribe((res) => {
        this.filteredRoleDetails = res;
        this.roleList = this.filteredRoleDetails.filter(
          (role: any) => role.roleId !== 'ConsumerUser'
        );
      })
    );
  }
  filteredclaimList: any = [];
  getClaims() {
    this.subs.add(
      this.identityService.getClaims().subscribe((res) => {
        this.filteredRoleDetails = res;
        this.claimList = this.filteredRoleDetails.filter(
          (role: any) =>
            role.claimId !== 'ConsumerMenu' &&
            role.claimId !== 'ConsumerMenu_MyRewards' &&
            role.claimId !== 'ConsumerMenu_MyRewards' &&
            role.claimId !== 'ConsumerProfile' &&
            role.claimId !== 'ConsumerProfile_Edit' &&
            role.claimId !== 'ConsumerTransaction_History_View' &&
            role.claimId !== 'ConsumerTransaction_Recipt_View'
        );
      })
    );
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  onRoleChange(event: any) {
    this.selectedRole['claim'] = this.selectedRole.claims.map(
      this.getClaimsArray
    );
  }
  getClaimsArray(item: any) {
    return item.claimId;
  }

  changeInRoleClaim(event: any, claimId: any) {
    if (event.target.checked) {
      this.selectedRole.claim.push(claimId);
    } else {
      let claimIndex = this.selectedRole.claim.findIndex(
        (x: any) => x == claimId
      );
      this.selectedRole.claim.splice(claimIndex, 1);
    }
  }

  saveRoleClaims() {
    if (!this.selectedRole.roleId) {
      this.toster.error('Please select role first!');
      return;
    }
    this.loading = true;

    this.subs.add(
      this.identityService
        .updateClaimsMap({
          roleId: this.selectedRole.roleId,
          claimIds: this.selectedRole.claim,
        })
        .subscribe(
          (res) => {
            this.loading = false;
            this.toster.success('Role permission updated successfully!');
            this.getRoles();
            this.getClaims();
          },
          (err) => {
            // console.log(err);

            this.loading = false;
            this.toster.error(
              'Role permission could not be updated. Please try again!'
            );
          }
        )
    );
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }
}
