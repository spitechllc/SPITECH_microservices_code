import { NgModule } from '@angular/core';
import { SharedModule } from './../../../shared.module';
import { UserComponent } from './user.component';
import { RouterModule, Routes } from '@angular/router';
import { RoleTabComponent } from './role-tab/role-tab.component';
import { UserTabComponent } from './user-tab/user-tab.component';
import { PermissionTabComponent } from './permission-tab/permission-tab.component';
import { CreateRoleComponent } from './create-role/create-role.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatSnackBarModule,
  MAT_SNACK_BAR_DEFAULT_OPTIONS,
} from '@angular/material/snack-bar';
import { EditRoleComponent } from './role-tab/edit-role/edit-role.component';

import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { RolePermissionGuard } from '../../auth/role-permission.guard';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { StoreOwnerComponent } from './store-owner/store-owner.component';
import { NgxMaskModule, IConfig } from 'ngx-mask';
import { UserExcelExportComponent } from './user-tab/user-excel-export/user-excel-export.component';
export const options: Partial<null | IConfig> | (() => Partial<IConfig>) = null;
export const router: Routes = [{ path: '', component: UserComponent }];

@NgModule({
  declarations: [
    UserComponent,
    RoleTabComponent,
    UserTabComponent,
    PermissionTabComponent,
    CreateRoleComponent,
    EditRoleComponent,
    StoreOwnerComponent,
    UserExcelExportComponent,
  ],
  imports: [
    SharedModule,
    ReactiveFormsModule,
    MatSnackBarModule,
    Ng2SearchPipeModule,
    MatAutocompleteModule,
    FormsModule,
    NgxMaskModule.forRoot(),
    RouterModule.forChild(router),
  ],
  providers: [
    { provide: MAT_SNACK_BAR_DEFAULT_OPTIONS, useValue: { duration: 2500 } },
  ],
})
export class UserModule {}
