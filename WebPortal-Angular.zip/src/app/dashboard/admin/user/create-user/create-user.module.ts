import { NgModule } from '@angular/core';
import { SharedModule } from './../../../../shared.module';
import { CreateUserComponent } from './create-user.component';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { GooglePlaceModule } from 'ngx-google-places-autocomplete';


export const router: Routes = [
  {path: '', component: CreateUserComponent}
]


@NgModule({
    declarations: [CreateUserComponent],
    imports: [
        SharedModule,
        ReactiveFormsModule,
        GooglePlaceModule,
        RouterModule.forChild(router)
    ]
})
export class CreateUserModule { }