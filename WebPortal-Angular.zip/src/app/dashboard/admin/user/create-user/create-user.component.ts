import { Component, OnInit } from '@angular/core';
import {
  Form,
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
import { StoreService } from 'src/app/dashboard/api-service/storeService';
import { UserService } from 'src/app/dashboard/api-service/userService';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.scss'],
})
export class CreateUserComponent implements OnInit {
  checked = true;
  addUserForm!: FormGroup;
  companyId: any;
  constructor(
    private userService: UserService,
    private formBuilder: FormBuilder,
    private storeService: StoreService,
    private indentityService: IdentityService,
    private router: Router,
    private identityServer: IdentityService,
    private _snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.addUserForm = this.formBuilder.group({
      title: [1],
      userName: [''],
      password: [''],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      designationId: [0],
      companyId: [],
      storeId: [],
      managerId: [],
      regionId: [],
      // addresses: this.formBuilder.array([
      //   this.formBuilder.group({
      //     'addressId': new FormControl(0),
      //     'categoryTypeLevelId':new FormControl(1),
      //     'addressLine1':new FormControl('adress'),
      //     'addressLine2':new FormControl('address'),
      //     'countryId':new FormControl(1),
      //     'stateId':new FormControl(1),
      //     'cityId':new FormControl(1),
      //     'longitude':new FormControl(null),
      //     'latitude':new FormControl(null),
      //   })
      // ]),
      phones: this.formBuilder.array([
        this.formBuilder.group({
          phoneId: new FormControl(0),
          categoryTypeLevelId: new FormControl(),
          countryCode: new FormControl(''),
          areaCode: new FormControl('91'),
          number: new FormControl('', [
            Validators.required,
            Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$'),
          ]),
        }),
      ]),
      emails: this.formBuilder.array([
        this.formBuilder.group({
          emailId: new FormControl(0),
          categoryTypeLevelId: new FormControl(),
          email: new FormControl('', [Validators.required, Validators.email]),
        }),
      ]),
    });
    // console.log(this.userFormGroups.controls.phones.value)
    console.log(this.userPhoneFormGroups);
    //  console.log(this.userFormGroups.controls)
    // this.adddUser()
    this.getRegion();
    // this.getStore()
    this.phoneCategory();
    this.getEmailCategoryLevel();
    // this.getRoleType()
    this.getRoles();
    this.companyId = localStorage.getItem('companyId');
    this.getCompany();
    this.getUsersDetails();
  }

  userAddress: string = '';
  userLatitude: string = '';
  userLongitude: string = '';

  handleAddressChange(address: any) {
    // console.log(address, 'addd');
    this.userAddress = address.formatted_address;
    this.userLatitude = address.geometry.location.lat();
    console.log(this.userLatitude, 'addd');
    this.userLongitude = address.geometry.location.lng();
  }

  get(f: any) {
    this.addUserForm.get('phones');
  }
  //get companyBy userId
  comapnyDetals: any;

  getCompany() {
    this.storeService.getCompanyWithPagging().subscribe((data: any) => {
      this.comapnyDetals = data.data;
      // console.log(this.comapnyDetals, 'comapnyDetails')
    });
  }
  onChangeStore(id: number) {
    // console.log(id);
    if (id) {
      this.storeService.getStoreByCompanyId(id).subscribe((data: any) => {
        this.store = data.data;
        // console.log(this.store, 'store');
      });
    }
  }

  roleDetails: any;
  getRoles() {
    // this.oidcSecurityService.authorize();
    this.identityServer.getRoles().subscribe((data: any) => {
      this.roleDetails = data;
      // console.log(this.roleDetails, 'roleid')
    });
  }
  userDetails: any;
  getUsersDetails() {
    this.userService.findAllUser().subscribe((data: any) => {
      // console.log(data);
      this.userDetails = data.data;
      // console.log(this.userDetails,'userDetails')
    });
  }
  // get userFormGroups(): FormGroup {
  //   return this.addUserForm.get('user') as FormGroup
  // }
  // get userAddressFormGroups(): FormArray {
  //   return this.addUserForm.get(' addresses') as FormArray
  // }
  get userPhoneFormGroups(): FormArray {
    return this.addUserForm.get('phones') as FormArray;
  }
  addMorePhone() {
    (<FormArray>this.addUserForm.get('phones')).push(
      this.formBuilder.group({
        phoneId: new FormControl(1),
        categoryTypeLevelId: new FormControl(1),
        areaCode: new FormControl('91'),
        number: new FormControl(''),
        countryCode: new FormControl('91'),
      })
    );
  }
  addMoreEmail() {
    (<FormArray>this.addUserForm.get('emails')).push(
      this.formBuilder.group({
        emailId: new FormControl(0),
        categoryTypeLevelId: new FormControl(1),
        email: new FormControl(''),
      })
    );
  }
  get userEmailFormGroups(): FormArray {
    return this.addUserForm.get('emails') as FormArray;
  }
  naviagete() {
    this.router.navigateByUrl('/admin/user');
  }

  createUser() {
    this.userService.addUser(this.addUserForm.value).subscribe((data) => {
      // console.log(data);
      if (data == data) {
        this._snackBar.open('User create successfuly');
        this.naviagete();

        this.addUserForm.reset();
      }
    });
  }
  region: any;
  getRegion() {
    this.storeService.getRegion().subscribe((data: any) => {
      this.region = data.data;
      // console.log(this.region, 'region');
    });
  }
  phonecategory: any;
  phoneCategory() {
    this.storeService.getCategoryLevelPhone(7).subscribe((data: any) => {
      this.phonecategory = data.data;
      // console.log(this.phonecategory);
    });
  }
  emailcategory: any;
  getEmailCategoryLevel() {
    this.storeService.getCategoryLevelEmail(4).subscribe((data: any) => {
      this.emailcategory = data.data;
      // console.log(this.emailcategory, 'emaill');
    });
  }
  store: any;
  roleType: any;
  getRoleType() {
    this.indentityService.getRoleType().subscribe((data: any) => {
      this.roleType = data.data;
    });
  }
  cancelBUtton() {
    this.router.navigateByUrl('/admin/user');
  }
}
