import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { CreateRoleComponent } from './../create-role/create-role.component';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
import { EditRoleComponent } from './edit-role/edit-role.component';
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { MatSort } from '@angular/material/sort';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from 'src/app/dashboard/auth/auth.service';

import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-role-tab',
  templateUrl: './role-tab.component.html',
  styleUrls: ['./role-tab.component.scss'],
})
export class RoleTabComponent implements OnInit {
  displayedColumns = ['roleId', 'roleName', 'roleType', 'action'];
  dataSource = new MatTableDataSource<PeriodicElement>([]);
  dataArray: any;
  claimIdArray: any;
  roleDetails: any;
  err: any;

  @ViewChild(MatSort) sort: MatSort;
  constructor(
    public dialog: MatDialog,
    private identityServer: IdentityService,
    public oidcSecurityService: OidcSecurityService,
    private spinner: NgxSpinnerService,
    private auth: AuthService,
    private toster: ToastrService
  ) {}

  ngOnInit(): void {
    // const claim = localStorage.getItem('clams');
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;

    this.getRoles();
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  //get roles

  getRoles() {
    this.identityServer.getRoles().subscribe((data: any) => {
      this.roleDetails = data;
      const filteredRoleDetails = this.roleDetails.filter(
        (role: any) => role.roleId !== 'ConsumerUser'
      );

      this.dataSource = new MatTableDataSource(filteredRoleDetails);
      // this.dataSource = new MatTableDataSource(this.roleDetails);
      this.dataSource.sort = this.sort;
    });
  }
  filterdata($event: any) {
    this.dataSource.filter = $event.target.value;
  }

  addRowData(row_obj: any) {
    var d = new Date();
    this.identityServer.getRoles().subscribe((data: any) => {
      this.roleDetails = data;
      this.dataSource = new MatTableDataSource(this.roleDetails);
    });
  }

  createRolePopup() {
    const dialogRef = this.dialog.open(CreateRoleComponent, {
      width: '430px',
      panelClass: 'popup',
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.getRoles();
    });
  }
  editRolePopup(action: any, obj: any) {
    obj.action = action;
    const dialogRef = this.dialog.open(EditRoleComponent, {
      width: '430px',
      panelClass: 'popup',
      data: obj,
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.getRoles();
    });
  }
}

export interface PeriodicElement {
  roleId: number;
  roleName: string;
  roleType: string;
  action: string;
}
