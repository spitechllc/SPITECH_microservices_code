import { NgModule } from '@angular/core';

import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { EditRoleComponent } from './edit-role.component';
import { SharedModule } from 'src/app/shared.module';

export const router: Routes = [
  { path: ':roleId', component: EditRoleComponent },
];

@NgModule({
  declarations: [EditRoleComponent],
  entryComponents: [],
  imports: [SharedModule, ReactiveFormsModule, RouterModule.forChild(router)],
})
export class EditRoleModule {}
