import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { IdentityService } from 'src/app/dashboard/api-service/identityService';
import { AuthService } from 'src/app/dashboard/auth/auth.service';

export interface UsersData {
  roleId: number;
  roleName: string;
}

@Component({
  selector: 'app-edit-role',
  templateUrl: './edit-role.component.html',
  styleUrls: ['./edit-role.component.scss'],
})
export class EditRoleComponent implements OnInit {
  local_data: any;
  roleId: any;
  submitted: boolean = false;
  copyRoleForm!: FormGroup;
  get f() {
    return this.editRoleForm.controls;
  }
  constructor(
    private indentityService: IdentityService,
    private formBuilder: FormBuilder,
    private toster: ToastrService,
    private activatedRoute: ActivatedRoute,
    private spinner: NgxSpinnerService,
    private authService: AuthService,
    public dialogRef: MatDialogRef<EditRoleComponent>,
    @Inject(MAT_DIALOG_DATA) public data: UsersData,
    private router: Router
  ) {
    this.spinner.show();
    this.roleByIdDetails = { ...data };
    // console.log(this.roleByIdDetails)
    this.roleId = this.roleByIdDetails.roleId;
    // console.log(this.roleId)
    if (this.RoleId !== '') {
      this.spinner.hide();
      this.editRoleForm = this.formBuilder.group({
        roleId: new FormControl(this.roleId),
        roleName: new FormControl(this.roleByIdDetails.roleName),
        roleType: new FormControl(this.roleByIdDetails.roleType),
      });
      this.copyRoleForm = this.formBuilder.group({
        fromRoleId: this.roleId,
        toRoleId: new FormControl(''),
      });
      this.dataLoaded = true;
    }
  }
  editRoleForm!: FormGroup;
  roleByIdDetails: any;
  dataLoaded: boolean = false;
  RoleId: any;
  roleDetails: any;
  roles: any;
  ngOnInit(): void {
    this.dataLoaded = false;
    this.getRoles();
    this.getRoleType();
    this.roles = this.authService.getRols();
  }
  filteredRoleDetails: any = [];
  getRoles() {
    this.indentityService.getRoles().subscribe((data: any) => {
      this.roleDetails = data;
      this.filteredRoleDetails = this.roleDetails.filter(
        (role: any) => role.roleId !== 'ConsumerUser'
      );
    });
  }

  // get role type
  roleType: any;
  getRoleType() {
    this.indentityService.getRoleType().subscribe((data: any) => {
      this.roleType = data.data;
      // console.log(this.roleType, 'rrr');
    });
  }
  naviagete() {
    this.router.navigateByUrl('/admin/user');
  }

  updateCopyRoles() {
    this.indentityService
      .copyRoles(this.copyRoleForm.value)
      .subscribe((res) => {
        this.toster.success('Copy this role to another role successfully');
        this.getRoles();
        // this.getClaims();
      });
  }
  claimList: any = [];
  getClaims() {
    this.indentityService.getClaims().subscribe((res) => {
      this.claimList = res;
    });
  }
  submit() {
    this.updateRole();
    this.updateCopyRoles();
  }
  updateRole() {
    this.indentityService
      .updateRole(this.editRoleForm.value)
      .subscribe((data: any) => {
        if (data == data) {
          this.toster.success('Roles Update Successfully');

          this.dialogRef.close([]);
          this.naviagete();
        }
      });
  }
}
