import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CashRewardSetupComponent } from './cash-reward-setup.component';

describe('CashRewardSetupComponent', () => {
  let component: CashRewardSetupComponent;
  let fixture: ComponentFixture<CashRewardSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CashRewardSetupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CashRewardSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
