import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { IdentityService } from '../../api-service/identityService';
import { MarketingService } from '../../api-service/marketing.service';
import { AuthService } from '../../auth/auth.service';
import { SharedService } from '../../auth/shared.service';

@Component({
  selector: 'app-cash-reward-setup',
  templateUrl: './cash-reward-setup.component.html',
  styleUrls: ['./cash-reward-setup.component.scss'],
})
export class CashRewardSetupComponent implements OnInit {
  displayedColumns = [
    'loyaltyId',
    'eventName',
    'criteriaName',
    'value',
    'isPercentage',
    'startDate',
    'endDate',
    'displayOrder',
    'Action',
  ];
  dataSource = new MatTableDataSource<CastRewardTable>([]);

  cashRewardSetupForm!: FormGroup;
  constructor(
    private fb: FormBuilder,
    private marketingService: MarketingService,
    private toster: ToastrService,
    private spinner: NgxSpinnerService,
    private auth: AuthService,
    private identityServer: IdentityService
  ) {}
  get f() {
    return this.cashRewardSetupForm.controls;
  }
  submitted: boolean = false;
  cashBackEvent: any = [];
  CashBackCrietria: any;
  hasValue: any;
  loyalty: any = [];
  checked: boolean = true;
  loyaltyObject: any = {};
  claimIdArray: any;
  PageIndex: number = 1;
  PageSize: number = 50;
  SortOrder = 'asc';
  SortBy = 'loyaltyId';
  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.createForm();
    this.getCashBack();
    this.getLoyalty();
  }

  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  createForm() {
    this.cashRewardSetupForm = this.fb.group({
      cashBackEventId: new FormControl('', Validators.required),
      cashBackCriteriaId: new FormControl('', Validators.required),
      criteria: new FormControl(''),
      isPercentage: new FormControl(false),
      startDate: new FormControl('', Validators.required),
      endDate: new FormControl('', Validators.required),
      value: new FormControl('', Validators.required),
      expireDays: new FormControl(365),
      displayOrder: new FormControl('', Validators.required),
      description: new FormControl(''),
    });
  }
  onClickStartDateUtc(event: any) {
    this.cashRewardSetupForm.patchValue({
      startDate: event.target.value.utc().format('YYYY-MM-DD HH:mm:ss'),
    });
  }
  onClickEndDateUtc(event: any) {
    this.cashRewardSetupForm.patchValue({
      endDate: event.target.value.utc().format('YYYY-MM-DD HH:mm:ss'),
    });
  }
  todayDates: any;
  getCashBack() {
    this.marketingService.getCashBackEvent('Loyalty').subscribe((data: any) => {
      this.cashBackEvent = data;
    });
  }
  onCheckBox(event: any) {
    this.cashRewardSetupForm.patchValue({
      isPercentage: event.checked,
    });
  }
  isDisabled = true;
  onChangeCashBackCrietriaByEventId(value: number) {
    this.cashRewardSetupForm.patchValue({
      cashBackEventId: value,
    });
    this.criteria(value);
  }

  criteria(value: any) {
    this.marketingService
      .getCashBackCrietriaByEventId(value)
      .subscribe((data: any) => {
        this.CashBackCrietria = data;
        this.CashBackCrietria.forEach((element: any) => {
          this.hasValue = element.hasValue;
          if (this.hasValue == true) {
            this.cashRewardSetupForm.patchValue({
              criteria: element.criteriaName,
            });
          }
          if (this.hasValue == false) {
            this.cashRewardSetupForm.patchValue({
              criteria: null,
            });
          }
          // this.cashRewardSetupForm.patchValue({
          //   cashBackEventId: element.cashBackEventId,
          //   cashBackCriteriaId: element.cashBackCriteriaId,
          // });
        });

        // console.log(this.CashBackCrietria, 'CashBackCrietria');
      });
  }

  total: any;
  onHeaderSortChange(event: any) {
    this.SortBy = event.active;
    if (event.direction == '') {
      this.SortOrder = 'asc';
    } else {
      this.SortOrder = event.direction;
    }

    this.getLoyalty();
  }
  getLoyalty() {
    this.marketingService
      .getGetLoyalty(this.PageIndex, this.PageSize, this.SortOrder, this.SortBy)
      .subscribe(
        (data: any) => {
          this.loyalty = data.data;
          this.total = data.totalCount;
          this.dataSource = new MatTableDataSource(this.loyalty);
        },
        (err) => {
          if (err.status == 500) {
            this.toster.error('Internal Server error ');
          }
        }
      );
  }
  loyaltyId: number = 0;
  onClickEdit(loyaltyId: number) {
    this.loyaltyId = loyaltyId;
    this.spinner.show();
    this.marketingService.getByloyaltyId(loyaltyId).subscribe((data: any) => {
      this.loyaltyObject = data;

      if (data.cashBackEventId) {
        this.marketingService
          .getCashBackCrietriaByEventId(data.cashBackEventId)
          .subscribe((data: any) => {
            this.CashBackCrietria = data;
          });
      }
      this.cashRewardSetupForm.patchValue({
        cashBackEventId: data.cashBackEventId,
        cashBackCriteriaId: data.cashBackCriteriaId,
        criteria: data.criteria,
        isPercentage: data.isPercentage,
        value: data.value,
        startDate: data.startDate,
        endDate: data.endDate,
        displayOrder: data.displayOrder,
        description: data.description,
      });
    });
  }
  onChageCriteria(event: any) {
    this.cashRewardSetupForm.patchValue({
      cashBackCriteriaId: event.value,
    });
  }

  formReset() {
    this.cashRewardSetupForm.reset();
    this.loyaltyId = 0;
    this.createForm();
  }
  submit() {
    this.submitted = true;
    if (!this.loyaltyId) {
      this.createCashBack();
    }
    if (this.loyaltyId) {
      this.updateCashBackReward();
    }
  }
  createCashBack() {
    this.marketingService
      .cashRewardSetup(this.cashRewardSetupForm.value)
      .subscribe(
        (data: any) => {
          this.toster.success('Cash Reward  Save Successfully!');
          this.getLoyalty();
        },
        (err) => {
          if (err.error.errors.value) {
            err.error.errors.value.forEach((err: any) => {
              this.toster.error(err);
            });
          }
          if (err.error.errors.Event) {
            err.error.errors.Event.forEach((err: any) => {
              this.toster.error(err, '', {
                timeOut: 1000,
              });
            });
          }
          if (err.error.errors.Criteria) {
            err.error.errors.Criteria.forEach((err: any) => {
              this.toster.error(err, '', {
                timeOut: 1000,
              });
            });
          }
          if (err.error.errors.IsPercentage) {
            err.error.errors.IsPercentage.forEach((err: any) => {
              this.toster.error(err, '', {
                timeOut: 1000,
              });
            });
          }
          if (err.error.errors.CashBackCriteriaId) {
            err.error.errors.CashBackCriteriaId.forEach((err: any) => {
              this.toster.error(err, '', {
                timeOut: 1000,
              });
            });
          }
        }
      );
  }
  updateCashBackReward() {
    this.marketingService
      .updateCashBackReward({
        ...this.cashRewardSetupForm.value,
        loyaltyId: this.loyaltyId,
      })
      .subscribe(
        (data: any) => {
          this.getLoyalty();
          this.toster.success('Cash Reward  Update Successfully');
        },
        (err) => {
          // console.log(err);
          if (err.status == 400) {
            this.toster.error('Validation error', '', {
              timeOut: 1000,
            });
          }
          if (err.error.errors.value) {
            err.error.errors.value.forEach((err: any) => {
              this.toster.error(err);
            });
          }
          if (err.error.errors.Event) {
            err.error.errors.Event.forEach((err: any) => {
              this.toster.error('Event is required', '', {
                timeOut: 1000,
              });
            });
          }
          if (err.error.errors.Criteria) {
            err.error.errors.Criteria.forEach((err: any) => {
              this.toster.error(err, '', {
                timeOut: 1000,
              });
            });
          }
          if (err.error.errors.IsPercentage) {
            err.error.errors.IsPercentage.forEach((err: any) => {
              this.toster.error(err, '', {
                timeOut: 1000,
              });
            });
          }
          if (err.error.errors.CashBackCriteriaId) {
            err.error.errors.CashBackCriteriaId.forEach((err: any) => {
              this.toster.error(err, '', {
                timeOut: 1000,
              });
            });
          }
        }
      );
  }

  pageChanged(event: any) {
    this.PageIndex = event.pageIndex + 1;
    this.PageSize = event.pageSize;
    this.getLoyalty();
  }
}
export interface CastRewardTable {
  cashBackEventId: number;
  criteriaName: string;
  eventName: string;
  value: number;
  isPercentage: boolean;
}
