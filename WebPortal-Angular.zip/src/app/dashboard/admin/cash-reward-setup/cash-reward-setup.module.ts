import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CashRewardSetupComponent } from './cash-reward-setup.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from 'src/app/shared.module';
import { MatCardModule } from '@angular/material/card';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSnackBarModule } from '@angular/material/snack-bar';

export const router: Routes = [
  {
    path: '',
    component: CashRewardSetupComponent,
  },
];

@NgModule({
  declarations: [CashRewardSetupComponent],
  imports: [
    CommonModule,
    SharedModule,
    MatCardModule,
    FormsModule,
    MatSnackBarModule,
    ReactiveFormsModule,
    RouterModule.forChild(router),
  ],
})
export class CashRewardSetupModule {}
