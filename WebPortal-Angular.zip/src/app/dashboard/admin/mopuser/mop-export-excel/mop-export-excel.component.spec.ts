import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MopExportExcelComponent } from './mop-export-excel.component';

describe('MopExportExcelComponent', () => {
  let component: MopExportExcelComponent;
  let fixture: ComponentFixture<MopExportExcelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MopExportExcelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MopExportExcelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
