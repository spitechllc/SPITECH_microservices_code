import { Component, OnInit, Inject } from '@angular/core';
import { ExcelService } from 'src/app/dashboard/api-service/excel-servive/excel.service';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';

import * as XLSX from 'xlsx';

@Component({
  selector: 'app-mop-export-excel',
  templateUrl: './mop-export-excel.component.html',
  styleUrls: ['./mop-export-excel.component.scss']
})
export class MopExportExcelComponent implements OnInit {
  constructor(
    private excelService: ExcelService,
    public dialogRef: MatDialogRef<MopExportExcelComponent>,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: { data: any }
  ){
    this.excelData = data.data;
  }
  excelData: any;
  userId: boolean = true;
  email: boolean = true;
  displayName: boolean=true;
  mobileNumber: boolean=true;
  cardDetails: any;
  appendedString: string = ''; 
  ngOnInit(): void {
  }

  onClickChexBox(event: any) {
    if (event.source.value == 'userId' && event.checked == false) {
      this.userId = false;
    } else if (event.source.value == 'userId' && event.checked == true) {
      this.userId = true;
    }

    if (event.source.value == 'email' && event.checked == false) {
      this.email = false;
    } else if (event.source.value == 'email' && event.checked == true) {
      this.email = true;
    }

    if (event.source.value == 'displayName' && event.checked == false) {
      this.email = false;
    } else if (event.source.value == 'displayName' && event.checked == true) {
      this.email = true;
    }

    if (event.source.value == 'mobileNumber' && event.checked == false) {
      this.mobileNumber = false;
    } else if (event.source.value == 'mobileNumber' && event.checked == true) {
      this.mobileNumber = true;
    }

    if (event.source.value == 'cardDetails' && event.checked == false) {
      this.cardDetails = false;
    } else if (event.source.value == 'cardDetails' && event.checked == true) {
      this.cardDetails = true;
    }
  }
  excelExport() {
    const excelExportData = this.excelData.map((t: any) => {
      const dataObject: any = {};
      if (this.userId == true) {
        dataObject.userId = t.userId;
      }
      if (this.email == true) {
        dataObject.email = t.email;
      }
      if (this.displayName == true) {
        dataObject.displayName = t.displayName;
      }
      if (this.mobileNumber == true) {
        dataObject.mobileNumber = t.mobileNumber;
      }
      if(t.cardDetails.length > 0)
      {
        for (const item of t.cardDetails) {
          dataObject.cardDetails = 'Card Name : '+ item.cardName
          +'|| Card Type : ' + item.cardType +'|| Card Number : ' + item.cardNumber +'\n';

          this.appendedString += dataObject.cardDetails;
        }
        dataObject.cardDetails=this.appendedString;
        this.appendedString='';
      }

      return dataObject;
    });

    this.excelService.exportAsExcelFile(excelExportData, 'MOP-exported-data');
  }

}
