import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MopuserComponent } from './mopuser.component';
import { RouterModule, Routes } from '@angular/router';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatTooltipModule } from '@angular/material/tooltip';
import { SharedModule } from 'src/app/shared.module';
import { FormsModule } from '@angular/forms';
import { MopExportExcelComponent } from './mop-export-excel/mop-export-excel.component';


export const router: Routes = [
  { path: '', component: MopuserComponent },
];
@NgModule({
  declarations: [
    MopuserComponent,
    MopExportExcelComponent
  ],
  imports: [
    SharedModule,
    FormsModule,
    CommonModule,
    MatExpansionModule,
    MatTooltipModule,
    RouterModule.forChild(router),
  ],
  
})
export class MopuserModule { }
