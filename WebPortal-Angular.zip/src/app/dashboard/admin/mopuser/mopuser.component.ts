import { Component, OnInit } from '@angular/core';
import { IdentityService } from '../../api-service/identityService';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort, Sort } from '@angular/material/sort';
import { MatSnackBar } from '@angular/material/snack-bar';
import { PageEvent } from '@angular/material/paginator';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { StoreService } from 'src/app/dashboard/api-service/storeService';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/dashboard/auth/auth.service';
import { debounce } from 'lodash';
import { ExcelService } from 'src/app/dashboard/api-service/excel-servive/excel.service';
import { SharedService } from 'src/app/dashboard/auth/shared.service';
import { MatDialog } from '@angular/material/dialog';
import {MopExportExcelComponent} from './mop-export-excel/mop-export-excel.component';
@Component({
  selector: 'app-mopuser',
  templateUrl: './mopuser.component.html',
  styleUrls: ['./mopuser.component.scss']
})
export class MopuserComponent implements OnInit {

  constructor(private identityService: IdentityService,
              private excelService: ExcelService,
              public dialog: MatDialog) {

     }

  MOPUser: any = [];
  allCompanyData: any = [];
  err: any;
  totalCount = 0;
  excelData: any;

  id: boolean = true;
  name: boolean = true;
  firstName: boolean = true;
  lastName: boolean = true;
  email: boolean = true;
  mobile: boolean = true;

  ngOnInit(): void {
    this.GetMopUserTableData();
  }

  GetMopUserTableData()
  {
    this.identityService.GetMopUser().subscribe((data: any)=>{
        this.MOPUser= data;
    });
  }

  exportAsExcel() {
    var PageSize = 0;
    var PageIndex = 0;
    this.identityService.GetMopUser().subscribe((data: any)=>{
        this.MOPUser = data;
        const dialogRef = this.dialog.open(MopExportExcelComponent, {
          width: '450px',
          panelClass: 'popup',
          data: this.MOPUser,
        });
    });
  }

  total: any;
  PageSize: number = 50;
  SortOrder = 'asc';
  PageIndex: number = 1;
  pageChanged(event: any) {
    this.PageIndex = event.pageIndex + 1;
    this.PageSize = event.pageSize;
    this.GetMopUserTableData();
  }

  excelExport() {
    const excelExportData = this.excelData.map((t: any) => {
      const dataObject: any = {};

      if (this.mobile == true) {
        t.emails.map((p: any) => {
          dataObject.mobile = p.mobile;
          return p.mobile;
        });
      }
      if (this.email == true) {
        t.phones.map((p: any) => {
          dataObject.email = p.email;
          return p.email;
        });
      }
   
      return dataObject;
    });

    this.excelService.exportAsExcelFile(
      excelExportData,
      'MOP-exported-data'
    );
  }
}