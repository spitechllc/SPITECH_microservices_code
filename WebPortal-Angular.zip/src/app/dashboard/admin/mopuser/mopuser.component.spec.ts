import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MopuserComponent } from './mopuser.component';

describe('MopuserComponent', () => {
  let component: MopuserComponent;
  let fixture: ComponentFixture<MopuserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MopuserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MopuserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

