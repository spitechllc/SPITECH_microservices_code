import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivityComponent } from './activity.component';
import { SharedModule } from 'src/app/shared.module';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';
import { RouterModule, Routes } from '@angular/router';
export const router: Routes = [{ path: '', component: ActivityComponent }];

@NgModule({
  declarations: [ActivityComponent],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    NgxMaterialTimepickerModule,
    RouterModule.forChild(router),
  ],
})
export class ActivityModule {}
