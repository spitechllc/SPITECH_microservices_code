import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { PageEvent } from '@angular/material/paginator';
import { Router } from '@angular/router';
import * as _moment from 'moment';
import {
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
  MomentDateAdapter,
} from '@angular/material-moment-adapter';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
} from '@angular/material/core';
import { NoficationService } from '../../api-service/nofication.service';
import { ExcelService } from '../../api-service/excel-servive/excel.service';
import { AuthService } from '../../auth/auth.service';
import { ToastrService } from 'ngx-toastr';
import { SharedService } from '../../auth/shared.service';
export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/DD/YYYY',
  },
  display: {
    dateInput: 'MM/DD/YYYY',
    monthYearLabel: 'MMM  YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM   YYYY',
  },
};
@Component({
  selector: 'app-activity',
  templateUrl: './activity.component.html',
  styleUrls: ['./activity.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },

    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})
export class ActivityComponent implements OnInit {
  displayedColumns = [
    'activityId',
    'activityType',
    'userId',
    'userName',
    'activityTime',
    'activityRecordKeyId',
    'activityIP',
    'isError',
    'errorMessage',
  ];

  dataSource = new MatTableDataSource<PayamentTable>([]);
  submitted: boolean = false;
  activityForm!: FormGroup;
  length: any;
  startDate: string = '';
  endDate: string = '';
  total: number = 0;
  pageIndex = 1;
  pageSize = 50;
  sortBy: string = '';
  sortOrder: string = '';
  userId: number = 0;
  claimIdArray: any;
  tenantData: any;
  get f() {
    return this.activityForm.controls;
  }
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private notificationService: NoficationService,
    private excelService: ExcelService,
    private auth: AuthService,
    private toster: ToastrService,
    public SharedService: SharedService
  ) {}

  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.createForm();
    this.getActivity();
    this.tenantData = this.SharedService.tenantData;
  }
  tenantId: number = 0;
  onClickTenant(value: any) {
    console.log(value);
    this.tenantId = value;
    this.getActivity();
  }
  exportAsExcel() {
    var pageSize = 0;
    var pageIndex = 0;
    this.notificationService
      .getActivity(
        this.userId,
        this.startDate,
        this.endDate,
        pageIndex,
        pageSize,
        this.sortBy,
        this.sortOrder,
        this.tenantId
      )
      .subscribe((data: any) => {
        if (data.data) {
          this.excelService.exportAsExcelFile(
            data.data.map((f: any) => {
              return {
                'User ID': f.userId,
                'Activity ID': f.activityId,
                'User Name': f.userName,
                'Activity Time': f.activityTime,
                'Error Status': f.isError,
                'Error Message': f.errorMessage,
              };
            }),
            'Acticity'
          );
        }
      });
  }
  createForm() {
    this.activityForm = this.fb.group(
      {
        UserId: new FormControl(null),
        StartDateUtc: new FormControl(''),
        EndDateUtc: new FormControl(''),
      },
      { validator: this.dateLessThan('StartDateUtc', 'EndDateUtc') }
    );
  }
  dateLessThan(from: string, to: string) {
    return (group: FormGroup): { [key: string]: any } => {
      let f = group.controls[from];
      let t = group.controls[to];
      if (f.value > t.value && t.value) {
        this.toster.error('from Date  should be less than to Date ');
        return {
          dates: 'Date from should be less than Date to',
        };
      }
      return {};
    };
  }
  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }

  onHeaderSortChange(event: any) {
    this.sortBy = event.active;
    if (event.direction == '') {
      this.sortOrder = 'asc';
    } else {
      this.sortOrder = event.direction;
    }
    this.getActivity();
  }
  onChangeUserId(event: any) {
    if (event.target.value == '') {
      this.userId = 0;
    } else this.userId = event.target.value;
  }
  onChangeTransactionStartDate(event: any) {
    var startDt = event.target.value.format('YYYY-MM-DD HH:mm:ss');
    this.startDate = _moment(_moment(startDt))
      .utc()
      .format('YYYY-MM-DD HH:mm:ss');
  }
  onChangeTransactionEndDate(event: any) {
    var endDt = event.target.value.format('YYYY-MM-DD HH:mm:ss');
    this.endDate = _moment(_moment(endDt)).utc().format('YYYY-MM-DD HH:mm:ss');
  }
  getActivity() {
    this.submitted = true;

    this.notificationService
      .getActivity(
        this.userId,
        this.startDate,
        this.endDate,
        this.pageIndex,
        this.pageSize,
        this.sortBy,
        this.sortOrder,
        this.tenantId
      )
      .subscribe((data: any) => {
        this.total = data.totalCount;

        this.dataSource = new MatTableDataSource(data.data);
      });
  }
  pageChanged(event: PageEvent) {
    this.pageIndex = event.pageIndex + 1;
    this.pageSize = event.pageSize;
    this.router.navigate(['/admin/activity'], {
      queryParams: {
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
      },
      queryParamsHandling: 'merge',
    });
    this.getActivity();
  }
}
export interface PayamentTable {
  transactionId: number;
  firstName: string;
  city: string;
  mobileNumber: string;
  state: string;
  country: string;
  zipCode: string;
  action: string;
}
