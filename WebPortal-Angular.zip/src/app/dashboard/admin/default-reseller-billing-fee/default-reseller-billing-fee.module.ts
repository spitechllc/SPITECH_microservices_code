import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule, Routes } from '@angular/router';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatCardModule } from '@angular/material/card';
import { SharedModule } from 'src/app/shared.module';
import { DefaultResellerBillingFeeComponent } from './default-reseller-billing-fee.component';

export const router: Routes = [
  {
    path: '',
    component: DefaultResellerBillingFeeComponent,
  },
];

@NgModule({
  declarations: [DefaultResellerBillingFeeComponent],
  imports: [
    CommonModule,
    SharedModule,
    MatCardModule,
    FormsModule,
    MatSnackBarModule,
    ReactiveFormsModule,
    NgxMaterialTimepickerModule,
    RouterModule.forChild(router),
  ],
})
export class DefaultResellerBillingFeeModule {}
