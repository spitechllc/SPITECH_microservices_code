import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DefaultResellerBillingFeeComponent } from './default-reseller-billing-fee.component';

describe('DefaultResellerBillingFeeComponent', () => {
  let component: DefaultResellerBillingFeeComponent;
  let fixture: ComponentFixture<DefaultResellerBillingFeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DefaultResellerBillingFeeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DefaultResellerBillingFeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
