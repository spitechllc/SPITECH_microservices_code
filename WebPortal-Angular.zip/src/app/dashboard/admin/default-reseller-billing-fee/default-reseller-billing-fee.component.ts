import { Location } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

import { TransactionService } from '../../api-service/trasation.service';
import { AuthService } from '../../auth/auth.service';
import { SubSink } from 'subsink';
import { IdentityService } from '../../api-service/identityService';
@Component({
  selector: 'app-default-reseller-billing-fee',
  templateUrl: './default-reseller-billing-fee.component.html',
  styleUrls: ['./default-reseller-billing-fee.component.scss'],
})
export class DefaultResellerBillingFeeComponent implements OnInit {
  @ViewChild(MatSort) sort: MatSort;
  displayedColumns = [
    'resellerFeeId',
    'minStoreRange',
    'maxStoreRange',
    'coreProcessingName',
    'achTransactionFee',
    'cardTransactionFee',
    'cashRewardTransactionFee',
    'achProcessingFee',
    'monthlySaasFee',

    'action',
  ];
  dataSource = new MatTableDataSource<TableDetails>([]);

  myModel = true;
  checked = true;
  storeId: any;
  storeDetails: any;
  paymentMethodDetails: any;
  claimIdArray: any;
  err: string = '';
  ResellerBillingForm!: FormGroup;
  paymentConfigurationDetails: any;
  submitted: boolean = false;
  paymentMethod: any;
  ResellerData: any = [];
  resellerFeeId: any;
  isActive: boolean = true;
  resellerId: number = 0;
  subs = new SubSink();
  constructor(
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private toster: ToastrService,
    private auth: AuthService,
    private _location: Location,
    private transactionService: TransactionService,
    private identityServer: IdentityService
  ) {}
  get f() {
    return this.ResellerBillingForm.controls;
  }
  ngOnInit(): void {
    this.getResllerId();
    this.createForm();
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.getResellerDefault();
  }

  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  getResllerId() {
    this.subs.add(
      this.activatedRoute.paramMap.subscribe((params: any) => {
        this.resellerId = params.get('resellerId');
      })
    );
  }
  getResellerDefault() {
    this.transactionService.getResellerDefault().subscribe((data: any) => {
      this.dataSource = new MatTableDataSource(data.data);
      this.dataSource.sort = this.sort;
    });
  }

  createForm() {
    this.ResellerBillingForm = this.formBuilder.group({
      resellerId: new FormControl(this.resellerId),
      minStoreRange: new FormControl('', Validators.required),
      maxStoreRange: new FormControl('', Validators.required),
      achTransactionFee: new FormControl('', Validators.required),
      cardTransactionFee: new FormControl('', Validators.required),
      cashRewardTransactionFee: new FormControl('', Validators.required),
      achProcessingFee: new FormControl('', Validators.required),
      monthlySaasFee: new FormControl('', Validators.required),
      coreProcessingName: new FormControl(''),
      isDefault: true,
    });
  }

  onClickEdit(id: any) {
    this.resellerFeeId = id;
    this.transactionService
      .getResellerFeeByResellerFeeId(id)
      .subscribe((data: any) => {
        this.ResellerBillingForm.patchValue({
          resellerId: data.data.resellerId,
          minStoreRange: data.data.minStoreRange,
          maxStoreRange: data.data.maxStoreRange,
          achTransactionFee: data.data.achTransactionFee,
          cardTransactionFee: data.data.cardTransactionFee,
          cashRewardTransactionFee: data.data.cashRewardTransactionFee,
          achProcessingFee: data.data.achProcessingFee,
          monthlySaasFee: data.data.monthlySaasFee,
          coreProcessingName: data.data.coreProcessingName,
          isDefault: true,
        });
      });
  }

  formReset() {
    this.ResellerBillingForm.reset();
    this.resellerFeeId = 0;
    this.createForm();
  }

  submit() {
    if (!this.resellerFeeId) {
      this.saveStoreBilling();
    }
    if (this.resellerFeeId) {
      this.updateStoreBilling();
    }
  }
  mintransationerr: string = '';
  saveStoreBilling() {
    this.submitted = true;
    if (this.ResellerBillingForm.invalid) return;
    this.transactionService
      .createResllerBillingFee(this.ResellerBillingForm.value)
      .subscribe(
        (data: any) => {
          if (data.success == true) {
            this.toster.success('Default Reseller save successfully');
            this.getResellerDefault();
          }
          if (data.success == false) {
            this.toster.warning('Default Reseller  not save status:false');
          }
        },
        (err) => {
          if (err.error.errors.minStoreRange) {
            err.error.errors.minStoreRange.forEach((err: any) => {
              this.mintransationerr = err;
              this.toster.error(err);
            });
          }
          if (err.error.errors.StoreRange) {
            err.error.errors.StoreRange.forEach((err: any) => {
              this.toster.error(err);
            });
          }
        }
      );
  }
  updateStoreBilling() {
    this.transactionService
      .UpdateResllerBillingFee({
        ...this.ResellerBillingForm.value,
        resellerFeeId: this.resellerFeeId,
        isActive: this.isActive,
      })
      .subscribe(
        (data) => {
          this.toster.success('Update Default Reseller  Successfully');
          this.getResellerDefault();
        },
        (err) => {
          if (err.error.errors.minStoreRange) {
            err.error.errors.minStoreRange.forEach((err: any) => {
              this.mintransationerr = err;

              this.toster.error(err);
            });
          }
        }
      );
  }
  onClickBack() {
    this._location.back();
  }
}

export interface TableDetails {
  monthlySaasFee: string;
  transactionFee: string;
  Subscription: string;
  transactionPercentageFee: string;
  effectiveDate: string;
  resellerFeeId: string;
  storeName: string;
  action: string;
}
