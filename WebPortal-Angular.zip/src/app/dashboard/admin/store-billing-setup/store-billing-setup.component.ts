import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-store-billing-setup',
  templateUrl: './store-billing-setup.component.html',
  styleUrls: ['./store-billing-setup.component.scss'],
})
export class StoreBillingSetupComponent implements OnInit {
  displayedColumns = [
    'MerchantName',
    'Subcription',
    'Percent',
    'ValidFrom',
    'TranceFee',
    'Billing',
    'status',
  ];
  dataSource = new MatTableDataSource();
  constructor() {}

  ngOnInit(): void {}
}
