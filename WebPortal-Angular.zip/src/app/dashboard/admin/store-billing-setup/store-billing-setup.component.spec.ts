import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StoreBillingSetupComponent } from './store-billing-setup.component';

describe('StoreBillingSetupComponent', () => {
  let component: StoreBillingSetupComponent;
  let fixture: ComponentFixture<StoreBillingSetupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StoreBillingSetupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StoreBillingSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
