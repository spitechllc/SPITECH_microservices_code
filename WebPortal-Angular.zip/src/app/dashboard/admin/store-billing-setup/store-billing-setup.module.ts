import { NgModule } from '@angular/core';
import { SharedModule } from './../../../shared.module';

import { RouterModule, Routes } from '@angular/router';
import { AdminGuardGuard } from '../../auth/admin-guard.guard';
import { StoreBillingSetupComponent } from './store-billing-setup.component';

export const router: Routes = [
  {
    path: '',
    component: StoreBillingSetupComponent,
    canActivate: [AdminGuardGuard],
  },
];

@NgModule({
    declarations: [StoreBillingSetupComponent],
    imports: [SharedModule, RouterModule.forChild(router)]
})
export class StoreBillingSetupModule {}
