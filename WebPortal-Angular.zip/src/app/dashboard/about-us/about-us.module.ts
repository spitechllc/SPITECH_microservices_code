import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AboutUsComponent } from './about-us.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from 'src/app/shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
export const router: Routes = [{ path: '', component: AboutUsComponent }];

@NgModule({
  declarations: [AboutUsComponent],
  imports: [
    CommonModule,
    SharedModule,
    MatCardModule,
    ReactiveFormsModule,
    RouterModule.forChild(router),
  ],
})
export class AboutUsModule {}
