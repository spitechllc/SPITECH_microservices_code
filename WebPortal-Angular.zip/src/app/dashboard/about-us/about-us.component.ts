import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.scss'],
})
export class AboutUsComponent implements OnInit {
  displayedColumns = ['versionNo', 'updateDate', 'des'];

  constructor() {}
  webPortalDetails: any = [
    {
      versionNo: 1.0,
      updateDate: '03-10-2022',
      description: 'Update date formate',
    },
  ];
  dataSource = new MatTableDataSource<TableElement>([]);
  ngOnInit(): void {
    this.dataSource = new MatTableDataSource(this.webPortalDetails);
  }
}
export interface TableElement {
  versionNo: string;
  updateDate: string;
  contactMobile: string;
}
