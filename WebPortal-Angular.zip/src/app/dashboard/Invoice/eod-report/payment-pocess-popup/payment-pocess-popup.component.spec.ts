import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentPocessPopupComponent } from './payment-pocess-popup.component';

describe('PaymentPocessPopupComponent', () => {
  let component: PaymentPocessPopupComponent;
  let fixture: ComponentFixture<PaymentPocessPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaymentPocessPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentPocessPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
