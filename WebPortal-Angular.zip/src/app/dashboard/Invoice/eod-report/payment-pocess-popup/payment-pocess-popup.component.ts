import { Component, OnInit, Inject } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
} from '@angular/material/core';
import * as _moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { TransactionService } from 'src/app/dashboard/api-service/trasation.service';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/DD/YYYY',
  },
  display: {
    dateInput: 'MM/DD/YYYY',
    monthYearLabel: 'MMM  YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM   YYYY',
  },
};
@Component({
  selector: 'app-payment-pocess-popup',
  templateUrl: './payment-pocess-popup.component.html',
  styleUrls: ['./payment-pocess-popup.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },

    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})
export class PaymentPocessPopupComponent implements OnInit {
  BusinessDate: any;
  Data: any;

  minDate = new Date();
  selectedDate = new FormControl(new Date());

  get f() {
    return this.processSetelementForm.controls;
  }
  constructor(
    private fb: FormBuilder,
    private transactionService: TransactionService,
    public dialog: MatDialog,

    private toster: ToastrService,
    public dialogRef: MatDialogRef<PaymentPocessPopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { data: any }
  ) {
    this.Data = data;
    // console.log(this.data);
    this.BusinessDate = this.Data.date;    
  }

  submitted: boolean = false;
  currentDate : any = new Date();

  ngOnInit(): void {
    this.createNachaForm();
  }
  processSetelementForm!: FormGroup;
  createNachaForm() {
    this.processSetelementForm = this.fb.group({
      OnlyCard: new FormControl('1', Validators.required),
      OnlyCashReward: new FormControl('1', Validators.required),
      EffectiveDate : new FormControl('', Validators.required),
      OnlyAch: new FormControl('1'),
    });
  }

  // dateValidator(control:any) {
  //   const selectedDate = new Date(control.value);
  //   const currentDate = new Date();

  //   return selectedDate > currentDate ? null : { invalidDate: true };
  // }

  EffectiveDate: any;

  onClickTransactionDate(event: any) {
    debugger;
    var effectiveDate = event.target.value.format('YYYY-MM-DD HH:mm:ss');
    this.EffectiveDate = _moment(_moment(effectiveDate))
      .utc()
      .format('YYYY-MM-DD HH:mm:ss');
  }

  submit() {
    this.submitted = true;
    if (this.processSetelementForm.invalid) {
      return;
    }
  }

  updateEodSettelement() {
    debugger;
    if (this.processSetelementForm.invalid) {
      this.toster.warning("Effective Date is required.");
      return;
    }
    console.log(this.Data.trans.settlementRequest);
    if(this.Data.trans.settlementRequest == 0)
    {
      this.toster.warning("no data found for process settlement transaction data.");
      return;
    }
    var OnlyCard = null;
    var OnlyCashReward = null;
    var OnlyAch = null;
    if (this.processSetelementForm.get('OnlyCard')?.value == '1') {
      OnlyCard = 1;
    } else if (this.processSetelementForm.get('OnlyCard')?.value == '0') {
      OnlyCard = 0;
    }
    if (this.processSetelementForm.get('OnlyCashReward')?.value == '1') {
      OnlyCashReward = 1;
    } else if (this.processSetelementForm.get('OnlyCashReward')?.value == '0') {
      OnlyCashReward = 0;
    }
    if (this.processSetelementForm.get('OnlyAch')?.value == '1') {
      OnlyAch = 1;
    } else if (this.processSetelementForm.get('OnlyAch')?.value == '0') {
      OnlyAch = 0;
    } else if (this.processSetelementForm.get('OnlyAch')?.value == '2') {
      OnlyAch = 2;
    }
    this.transactionService
      .UpdateEodSettlement({
        businessDate: this.BusinessDate,
        cardPayment: OnlyCard,
        cashRewardPayment: OnlyCashReward,
        effectiveDate: this.EffectiveDate,
        achPayment: OnlyAch,
        settlementRequest: this.Data.trans.settlementRequest,
      })
      .subscribe(
        (data: any) => {
          if (data.success == true) {
            this.toster.success(
              'Eod Settlement Succssfully for Process Payment'
            );
          }
          if (data.success == false) {
            this.toster.warning(data.message);
          }
          this.dialogRef.close([]);
        },
        (err) => {
          if (err.error.errors.StoreConfigs) {
            err.error.errors.StoreConfigs.forEach((err: any) => {
              this.toster.error(err);
            });
          }
        }
      );
  }
}
