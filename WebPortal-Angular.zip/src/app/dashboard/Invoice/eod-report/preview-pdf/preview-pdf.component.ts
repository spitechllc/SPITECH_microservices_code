import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { TransactionService } from 'src/app/dashboard/api-service/trasation.service';

@Component({
  selector: 'app-preview-pdf',
  templateUrl: './preview-pdf.component.html',
  styleUrls: ['./preview-pdf.component.scss'],
})
export class PreviewPdfComponent implements OnInit {
  constructor(
    private transactionService: TransactionService,
    public dialog: MatDialog,
    private sanitizer: DomSanitizer,
    private toster: ToastrService,
    private fb: FormBuilder,
    private spinner: NgxSpinnerService,
    public dialogRef: MatDialogRef<PreviewPdfComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { data: any }
  ) {
    // console.log(data, 'date');
    this.SettlementRequestId = data;
    // console.log(data);

    this.getEodPreview();
  }

  submitted: boolean = false;

  ngOnInit(): void {}
  nachaFilesDetails: any;
  filename: string = '';

  pdfLink: any;
  SettlementRequestId: any;

  getEodPreview() {
    this.spinner.show();
    this.transactionService.eodPreviewPdf(this.SettlementRequestId).subscribe(
      (data: any) => {
        this.nachaFilesDetails = data;
        // console.log(this.nachaFilesDetails, 'nachafile');
        let dataType = data.type;
        let binaryData = [];
        binaryData.push(data);
        let downloadLink = document.createElement('iframe');
        var downloadURL = window.URL.createObjectURL(data);
        var link = document.createElement('a');
        // link.href = downloadURL;
        // link.download = 'Eod_settlement.pdf';
        // link.click();
        downloadLink.src = window.URL.createObjectURL(
          new Blob(binaryData, { type: dataType })
        );
        this.pdfLink = this.sanitizer.bypassSecurityTrustResourceUrl(
          downloadLink.src
        );
        this.spinner.hide();
        // console.log(downloadLink, 'download link');
        // if (this.filename) downloadLink.setAttribute('download', this.filename);
        // document.body.appendChild(downloadLink);
        // downloadLink.click();
      },
      (err) => {
        this.spinner.hide();
        if (err.status == 404) {
          this.toster.error('Resource not found Status:404');
        }
        // if (err.status == 500) {
        //   this.toster.error('Internal server error');
        // }
      }
    );
  }
}
