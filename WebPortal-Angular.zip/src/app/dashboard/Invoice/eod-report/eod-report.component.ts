import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { FinanceService } from '../../api-service/finance.service';
import { StoreService } from '../../api-service/storeService';
import { TransactionService } from '../../api-service/trasation.service';
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
} from '@angular/material/core';
import * as _moment from 'moment';
import { debounce, indexOf } from 'lodash';
import { NachaFileComponent } from './nacha-file/nacha-file.component';
import { ViewNachaComponent } from './view-nacha/view-nacha.component';
import { MatCheckbox, MatCheckboxChange } from '@angular/material/checkbox';
import { UnpaidComponent } from './unpaid/unpaid.component';
import { PreviewPdfComponent } from './preview-pdf/preview-pdf.component';
import { ExcelService } from '../../api-service/excel-servive/excel.service';
import { PaymentPocessPopupComponent } from './payment-pocess-popup/payment-pocess-popup.component';
import { AuthService } from '../../auth/auth.service';
import { InvoiceEodReportExcelReportComponent } from './invoice-eod-report-excel-report/invoice-eod-report-excel-report.component';
import {
  animate,
  state,
  style,
  transition,
  trigger,
} from '@angular/animations';
import { UnpaidTransComponent } from './unpaid-trans/unpaid-trans.component';
import { CheckbalanceComponent } from './checkbalance/checkbalance.component';
import { json } from '@rxweb/reactive-form-validators';
import { ChangeDetectorRef } from '@angular/core';
import { NgZone } from '@angular/core';

import { SharedService } from '../../auth/shared.service';
export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/DD/YYYY',
  },
  display: {
    dateInput: 'MM/DD/YYYY',
    monthYearLabel: 'MMM  YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM   YYYY',
  },
};

interface TableRow {
  id: number;
  name: string;
  status: string;
}

@Component({
  selector: 'app-eod-report',
  templateUrl: './eod-report.component.html',
  styleUrls: ['./eod-report.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*', minHeight: '*' })),
      transition(
        'expanded <=> collapsed',
        animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')
      ),
    ]),
  ],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },

    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})

export class EodReportComponent implements OnInit {
  checked = false;
  InvoiceEodReportForm!: FormGroup;
  submmited: boolean = false;
  length: any;
  walletCreditsDetails: any = {};
  claimIdArray: any;
  reportDetails: any = [];
  settlementDetails: any;
  siteId: any = [];
  PageIndex: number = 1;
  PageSize: number = 50;
  sortBy: string = '';
  sortOrder: string = '';
  BusinessDate: any;
  StoreId: number = 0;
  totalCount: number = 0;
  reviewSeleted: any;
  unReviwSelected: any = false;
  eodInvoiceDetils: any;

  constructor(
    private fb: FormBuilder,
    private transactionService: TransactionService,
    public dialog: MatDialog,
    private storeService: StoreService,
    private financeService: FinanceService,
    private toster: ToastrService,
    private excelService: ExcelService,
    private auth: AuthService,
    private cdr: ChangeDetectorRef,
    private zone: NgZone,
    private shareService: SharedService
  ) {}
  nowDate: any;
  SiteId: string = '';
  roles: any = [];
  storeId: number = 0;
  TransactionDate: string = '';
  EndDateUtc: string = '';
  isTableExpanded = false;
  transactionDate: any;
  displayedColumns = [
    'expand',
    'siteId',
    'StoreName',
    'BusinessDate',
    'mppaTotalAmount',
    'mppaCounts',
    'terminalCounts',
    'terminalTotalAmount',
    'cashRewardAmount',
    'cardAmount',
    'achAmount',

    'isTotalAmountMatched',
    // 'card',
    // 'cashreward',
    // 'ACH',
    // 'review',
    // 'viewNacha',
    // 'previewPdf',
  ];

  dataSource = new MatTableDataSource<EodTable>([]);
  dataSource2 = new MatTableDataSource<EodTable>([]);
  filteredOptions?: Observable<string[]>;
  myControl = new FormControl();
  submitted: boolean = false;
  eodInvoiveData: any = [];
  get f() {
    return this.InvoiceEodReportForm.controls;
  }
  jsonData: any;
  ngOnInit(): void {
    //this.jsonData = this.shareService.data;
    const claim = this.auth.getClaims();
    this.roles = this.auth.getRols();
    this.claimIdArray = claim;
    this.createForm();
    this.needReview();
    //this.dataSource = new MatTableDataSource(this.jsonData.data);
  }

  checkBalance(access_token: any) {
    console.log(access_token);
    if (access_token) {
      this.transactionService
        .checkBalance({ access_token: access_token })
        .subscribe((res: any) => {
          console.log(res);
          const dialogRef = this.dialog.open(CheckbalanceComponent, {
            width: '450px',
            panelClass: 'popup',
            data: res,
          });
          dialogRef.afterClosed().subscribe((data: any) => {
            this.getInvoiceEodReport();
          });
        });
    }
  }

  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  exportAsExcel() {
    this.submitted = true;
    if (this.InvoiceEodReportForm.invalid) {
      return;
    }
    var PageSize = 0;
    var PageIndex = 0;
    var IsNeedReview = null;
    var AmountMatched = null;
    var PaymentStatus = null;
    var HasTransactionAmount = null;
    var CardPayment = null;
    var CashRewardPayment = null;
    var AchPayment = null;
    if (this.InvoiceEodReportForm.get('IsNeedReview')?.value == '1') {
      IsNeedReview = true;
      this.reviewSeleted = IsNeedReview;
    } else if (this.InvoiceEodReportForm.get('IsNeedReview')?.value == '0') {
      IsNeedReview = false;
      this.unReviwSelected = IsNeedReview;
    }

    if (this.InvoiceEodReportForm.get('AmountMatched')?.value == '1') {
      AmountMatched = true;
    } else if (this.InvoiceEodReportForm.get('AmountMatched')?.value == '0') {
      AmountMatched = false;
    }
    if (this.InvoiceEodReportForm.get('HasTransactionAmount')?.value == '1') {
      HasTransactionAmount = true;
    } else if (
      this.InvoiceEodReportForm.get('HasTransactionAmount')?.value == '0'
    ) {
      HasTransactionAmount = false;
    }
    if (this.InvoiceEodReportForm.get('CardPayment')?.value == '1') {
      CardPayment = 1;
    } else if (this.InvoiceEodReportForm.get('CardPayment')?.value == '0') {
      CardPayment = 0;
    } else if (this.InvoiceEodReportForm.get('CardPayment')?.value == '2') {
      CardPayment = 2;
    }
    if (this.InvoiceEodReportForm.get('CashRewardPayment')?.value == '1') {
      CashRewardPayment = 1;
    } else if (
      this.InvoiceEodReportForm.get('CashRewardPayment')?.value == '0'
    ) {
      CashRewardPayment = 0;
    } else if (
      this.InvoiceEodReportForm.get('CashRewardPayment')?.value == '2'
    ) {
      CashRewardPayment = 2;
    }
    if (this.InvoiceEodReportForm.get('AchPayment')?.value == '1') {
      AchPayment = 1;
    } else if (this.InvoiceEodReportForm.get('AchPayment')?.value == '0') {
      AchPayment = 0;
    } else if (this.InvoiceEodReportForm.get('AchPayment')?.value == '2') {
      CashRewardPayment = 2;
    }
    this.transactionService
      .getInvoiceEodReport(
        PageIndex,
        PageSize,
        this.BusinessDate,
        this.StoreId,
        IsNeedReview,
        AmountMatched,
        CardPayment,
        CashRewardPayment,
        AchPayment,
        this.sortBy,
        this.sortOrder,
        HasTransactionAmount
      )
      .subscribe((data: any) => {
        this.eodInvoiveData = data.data;
        if (this.eodInvoiveData.length > 0) {
          const dialogRef = this.dialog.open(
            InvoiceEodReportExcelReportComponent,
            {
              width: '450px',
              panelClass: 'popup',
              data: this.eodInvoiveData,
            }
          );
          // this.excelService.exportAsExcelFile(
          // this.eodInvoiveData.map((t: any) => {
          //     return {
          //       SiteId: t.siteId,
          //       StoreName: t.storeName,
          //       BusinessDate: t.businessDate,
          //       MPPA$: t.mppaTotalAmount,
          //       MPPACount: t.mppaCounts,
          //       TerminalTotal$: t.terminalTotalAmount,
          //       TerminalCounts: t.terminalCounts,
          //       CashRewardAmount: t.cashRewardAmount,
          //       CardAmount: t.cardAmount,
          //       AchAmount: t.achAmount,
          //       PaidNotPaid: t.isPaid == true ? 'Paid' : 'Not Paid',
          //     };
          //   }),
          //   'eod-invoice-excel'
          // );
        }
      });
  }

  onClickSiteId(event: any) {
    this.SiteId = event.target.value;
    if (this.SiteId) {
      this.storeService.getStoreBySiteId(this.SiteId).subscribe((data: any) => {
        this.storeId = data.storeId;
      });
    }
  }
  activationDate: any = new Date();
  onClickTransactionDate(event: any) {
    var businessdt = event.target.value.format('YYYY-MM-DD HH:mm:ss');
    this.BusinessDate = _moment(_moment(businessdt))
      .utc()
      .format('YYYY-MM-DD HH:mm:ss');
  }
  needReviewForm!: FormGroup;
  needReview() {
    this.needReviewForm = this.fb.group({
      settlementRequestIds: this.fb.array([]),
      isNeedReview: new FormControl(true),
    });
  }
  getsettlementRequestId() {
    return this.needReviewForm.get('settlementRequestIds') as FormArray;
  }
  UpdateReview(settlementRequestId: any) {
    if (
      !this.claimIdArray.includes('ProcessesMenu_EODSettelement_ReviewUnreview')
    ) {
      this.toster.error('You are not authorized');
      return;
    }
    this.transactionService
      .updateEodNeedReview({
        settlementRequestIds: [settlementRequestId[0]],
        isNeedReview: settlementRequestId[1] == false ? true : false,
      })
      .subscribe((data: any) => {
        this.toster.success('Update need review');
        this.getInvoiceEodReport();
      });
  }
  settlementRequestIds: any = [];
  isNeedReview: any;
  onClickCheckBox(event: any) {
    this.settlementRequestIds = event;
  }
  selectAllReview() {
    this.transactionService
      .updateEodNeedReview({
        settlementRequestIds: [this.settlementRequestIds],
        isNeedReview: false,
      })
      .subscribe((data: any) => {
        this.toster.success('Update need review');
        this.getInvoiceEodReport();
      });
  }

  selectAllunreview() {
    this.reportDetails.forEach((element: any) => {
      this.checked = true;
      this.transactionService
        .updateEodNeedReview({
          settlementRequestIds: [element.settlementRequestId],
          isNeedReview: element.isNeedReview == false ? true : true,
        })
        .subscribe((data: any) => {
          this.toster.success('Update need review');
          this.checked = false;
        });
    });
  }
  onHeaderSortChange(event: any) {
    this.sortBy = event.active;
    if (event.direction == '') {
      this.sortOrder = 'asc';
    } else {
      this.sortOrder = event.direction;
    }

    this.getInvoiceEodReport();
  }
  submit() {
    this.submitted = true;
    if (this.InvoiceEodReportForm.invalid) {
      return;
    }
    this.getInvoiceEodReport();
  }
  createForm() {
    this.InvoiceEodReportForm = this.fb.group({
      storeId: new FormControl(''),
      Businessdt: new FormControl('', Validators.required),
      IsNeedReview: new FormControl(''),
      CardPayment: new FormControl(''),
      CashRewardPayment: new FormControl(''),
      AchPayment: new FormControl(''),
      AmountMatched: new FormControl(''),
      HasTransactionAmount: new FormControl(''),
    });
  }
  getInvoiceEodReport() {
    var IsNeedReview = null;
    var AmountMatched = null;
    var CardPayment = null;
    var CashRewardPayment = null;
    var AchPayment = null;
    var HasTransactionAmount = null;
    if (this.InvoiceEodReportForm.get('IsNeedReview')?.value == '1') {
      IsNeedReview = true;
      this.reviewSeleted = IsNeedReview;
    } else if (this.InvoiceEodReportForm.get('IsNeedReview')?.value == '0') {
      IsNeedReview = false;
      this.unReviwSelected = IsNeedReview;
    }
    if (this.InvoiceEodReportForm.get('AmountMatched')?.value == '1') {
      AmountMatched = true;
    } else if (this.InvoiceEodReportForm.get('AmountMatched')?.value == '0') {
      AmountMatched = false;
    }
    if (this.InvoiceEodReportForm.get('HasTransactionAmount')?.value == '1') {
      HasTransactionAmount = true;
    } else if (
      this.InvoiceEodReportForm.get('HasTransactionAmount')?.value == '0'
    ) {
      HasTransactionAmount = false;
    }
    if (this.InvoiceEodReportForm.get('CardPayment')?.value == '1') {
      CardPayment = 1;
    } else if (this.InvoiceEodReportForm.get('CardPayment')?.value == '0') {
      CardPayment = 0;
    } else if (this.InvoiceEodReportForm.get('CardPayment')?.value == '2') {
      CardPayment = 2;
    }
    if (this.InvoiceEodReportForm.get('CashRewardPayment')?.value == '1') {
      CashRewardPayment = 1;
    } else if (
      this.InvoiceEodReportForm.get('CashRewardPayment')?.value == '0'
    ) {
      CashRewardPayment = 0;
    } else if (
      this.InvoiceEodReportForm.get('CashRewardPayment')?.value == '2'
    ) {
      CashRewardPayment = 2;
    }
    if (this.InvoiceEodReportForm.get('AchPayment')?.value == '1') {
      AchPayment = 1;
    } else if (this.InvoiceEodReportForm.get('AchPayment')?.value == '0') {
      AchPayment = 0;
    } else if (this.InvoiceEodReportForm.get('AchPayment')?.value == '2') {
      AchPayment = 2;
    }
    this.transactionService
      .getInvoiceEodReport(
        this.PageIndex,
        this.PageSize,
        this.BusinessDate,
        this.StoreId,
        IsNeedReview,
        AmountMatched,
        CardPayment,
        CashRewardPayment,
        AchPayment,
        this.sortBy,
        this.sortOrder,
        HasTransactionAmount
      )
      .subscribe((data: any) => {
        this.eodInvoiceDetils = data;
        this.reportDetails = data.data;
        this.totalCount = data.totalCount;
        this.reportDetails.forEach((element: any) => {
          this.reviewSeleted = element.needReview;
        });
        this.length = this.reportDetails.length;
        this.dataSource = new MatTableDataSource(data.data);
      });
  }
  reportDetail: any;
  site: any;
  pageLength: any;
  siteNumber: any = null;
  pageChanged(event: PageEvent) {
    this.PageIndex = event.pageIndex + 1;
    this.PageSize = event.pageSize;
    this.getInvoiceEodReport();
  }
  siteText: any;
  fiterSiteId: any;
  lengthsite: any;
  dataNotFond: string = 'Data not found';
  onChange(event: any) {
    this.siteText = event;
  }
  serachBySiteId = debounce((event: any) => {
    if (!event.target.value) {
      this.StoreId = 0;
    }
    this.storeService
      .getStoreAutoCompleteBySiteId(event.target.value)
      .subscribe((data: any) => {
        this.lengthsite = data.data.length;
        this.fiterSiteId = data.data;
        this.SiteId = this.fiterSiteId.siteId;
        this.StoreId = this.fiterSiteId.storeId;
      });
  }, 700);
  serachByStoreName = debounce((event: any) => {
    if (!event.target.value) {
      this.StoreId = 0;
    }
    this.storeService
      .getStoreAutoCompleteByStoreName(event.target.value)
      .subscribe((data: any) => {
        this.lengthsite = data.data.length;
        this.fiterSiteId = data.data;
      });
  }, 700);
  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.fiterSiteId.filter((siteId: any) =>
      siteId.toLowerCase().includes(filterValue)
    );
  }
  onClickSiteIdd(event: any) {
    this.SiteId = event;
    this.StoreId = event;
  }
  nachaFilesDetails: any;
  filename: string = '';

  eodProcsesSettelement() {
    if (this.transactionDetails.settlementRequest.length === 0) {
      this.toster.warning(
        'Data not found for process settlement transaction data.'
      );
      return;
    }

    const dialogRef = this.dialog.open(PaymentPocessPopupComponent, {
      width: '780px',
      panelClass: 'popup',
      data: { date: this.BusinessDate, trans: this.transactionDetails },
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.transactionDetails.settlementRequest = [];
      this.getInvoiceEodReport();
    });
  }
  previewNacha() {
    if (this.transactionDetails.settlementRequest.length === 0) {
      this.toster.warning(
        'Not found transaction data added for preview nacha file.'
      );
      return;
    }
    const dialogRef = this.dialog.open(NachaFileComponent, {
      width: '780px',
      panelClass: 'popup',
      data: { date: this.BusinessDate, trans: this.transactionDetails },
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.transactionDetails.settlementRequest = [];
      // console.log('popup on close two');
      // console.log(this.transactionDetails.settlementRequest);
      this.getInvoiceEodReport();
    });
  }
  viewNacha(settlementRequestId: number) {
    if (!this.claimIdArray.includes('ProcessesMenu_EODSettelement_ViewPdf')) {
      this.toster.error('You are not authorized');
      return;
    }
    const dialogRef = this.dialog.open(ViewNachaComponent, {
      width: '780px',
      panelClass: 'popup',
      data: settlementRequestId,
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.getInvoiceEodReport();
    });
  }

  unpaidCashReward(settlementRequestId: number) {
    if (!this.claimIdArray.includes('ProcessesMenu_EODSettelement_Paid')) {
      this.toster.error('You are not authorized');
      return;
    }
    const dialogRef = this.dialog.open(UnpaidComponent, {
      width: '450px',
      panelClass: 'popup',
      data: [settlementRequestId, 'cashrewad'],
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.getInvoiceEodReport();
    });
  }
  rowDetails: any;
  onClickRow(row: any) {
    this.rowDetails = row;

    this.dataSource2 = new MatTableDataSource(
      this.rowDetails.transactionDetailsEod
    );
    // this.cdr.detectChanges();
    this.zone.run(() => {
      // Asynchronous operations here
    });
  }
  selectAllMerchantPay(checked: boolean) {
    // Update the selection status
    this.selectAllRowsMerchant = checked;
    const filterpaid = this.rowDetails.transactionDetailsEod.filter(
      (row: any) => row.merchantPaid != 1
    );

    filterpaid.forEach((row: any) => {
      row.merchantPay = this.selectAllRowsMerchant;

      const settlementRequestItem = {
        transactionId: row.transactionId,
        settlementRequestId: row.settlementRequestId,
        merchantId: String(row.merchantId),
        consumerId: row.consumerId,
        consumerProcess: row.consumerPay,
        merchantProcess: row.merchantPay,
      };

      const isDuplicateIndex =
        this.transactionDetails.settlementRequest.findIndex(
          (item: any) =>
            item.transactionId === settlementRequestItem.transactionId &&
            item.settlementRequestId ===
              settlementRequestItem.settlementRequestId
        );

      if (isDuplicateIndex !== -1) {
        this.transactionDetails.settlementRequest[
          isDuplicateIndex
        ].merchantProcess = row.merchantPay;
      } else {
        // console.log('No duplicate, adding');
        this.transactionDetails.settlementRequest.push(settlementRequestItem);
      }
    });

    // console.log('All Rows Data:', this.rowDetails.transactionDetailsEod);
    // console.log(this.transactionDetails.settlementRequest);
    if (checked == false)
    {
      this.transactionDetails.settlementRequest=[];
    } 
  }

  selectAllConsumersPay(checked: boolean) {
    this.selectAllRowsConsumers = checked;
    const filterpaid = this.rowDetails.transactionDetailsEod.filter(
      (row: any) => row.consumerPaid != 1 && row.newPaymentMethod != 'Credit'
    );
    filterpaid.forEach((row: any) => {
      row.consumerPay = this.selectAllRowsConsumers;
      const settlementRequestItem = {
        transactionId: row.transactionId,
        settlementRequestId: row.settlementRequestId,
        merchantId: String(row.merchantId),
        consumerId: row.consumerId,
        consumerProcess: row.consumerPay,
        merchantProcess: row.merchantPay,
      };

      const isDuplicateIndex =
        this.transactionDetails.settlementRequest.findIndex(
          (item: any) =>
            item.transactionId === settlementRequestItem.transactionId &&
            item.settlementRequestId ===
              settlementRequestItem.settlementRequestId
        );

      if (isDuplicateIndex !== -1) {
        this.transactionDetails.settlementRequest[
          isDuplicateIndex
        ].consumerProcess = row.consumerPay;
      } else {
        // console.log('No duplicate, adding');
        this.transactionDetails.settlementRequest.push(settlementRequestItem);
      }
    });

    console.log('All Rows Data:', this.rowDetails.transactionDetailsEod);
    console.log(this.transactionDetails.settlementRequest);
    if (checked == false)
    {
      this.transactionDetails.settlementRequest=[];
    }
  }
  transactionDetails: any = { settlementRequest: [] };

  merchantPay: boolean = false;
  selectAllRowsMerchant: boolean = false;
  selectAllRowsConsumers: boolean = false;
  onClickExpandTableMercentPay(event: Event,row: any ,value: any) {
    // this.merchantPay = !this.merchantPay;
    // row.merchantPay = !this.merchantPay;
    const buttonText = (event.target as HTMLButtonElement).textContent;
    if(buttonText == ' Add ')
    {
      row.merchantPay= true;
       this.merchantPay= true;
    }
    else
    {
      row.merchantPay= false;
      this.merchantPay= false;
    }
    const settlementRequestItem = {
      transactionId: value[0],
      settlementRequestId: value[1],
      merchantId: String(value[2]),
      consumerId: value[3],
      consumerProcess: row.consumerPay,
      merchantProcess: row.merchantPay,
    };
    const isDuplicateIndex =
      this.transactionDetails.settlementRequest.findIndex(
        (item: any) =>
          item.transactionId === settlementRequestItem.transactionId &&
          item.settlementRequestId === settlementRequestItem.settlementRequestId
      );
    if (isDuplicateIndex !== -1) {
      this.transactionDetails.settlementRequest[
        isDuplicateIndex
      ].merchantProcess = row.merchantPay;
    } else {
      // console.log('No duplicate, adding');
      this.transactionDetails.settlementRequest.push(settlementRequestItem);
    }

    // if (row.merchantPay == true) {
    //   this.rowDetails.transactionDetailsEod.forEach(
    //     (element: any, index: number) => {

    //       if (element.transactionId == settlementRequestItem.transactionId) {
    //         element.edit = true;
    //         this.rowDetails.transactionDetailsEod[index].merchantPay =
    //           this.merchantPay;
    //         if (
    //           this.rowDetails.transactionDetailsEod[index].merchantPay ==
    //             true &&
    //           this.rowDetails.transactionDetailsEod[index].consumerPay == true
    //         ) {
    //           this.transactionDetails.settlementRequest.forEach(
    //             (element: any, index: number) => {
    //               this.transactionDetails.settlementRequest[
    //                 index
    //               ].merchantProcess = true;
    //               this.transactionDetails.settlementRequest[
    //                 index
    //               ].consumerProcess = true;
    //             }
    //           );
    //         }
    //       }
    //     }
    //   );
    // }
    // if (row.merchantPay == false) {
    //   this.rowDetails.transactionDetailsEod.forEach(
    //     (element: any, index: number) => {
    //       // console.log(element);
    //       if (element.transactionId == settlementRequestItem.transactionId) {
    //         element.edit = true;
    //         this.rowDetails.transactionDetailsEod[index].merchantPay =
    //           this.merchantPay;
    //         if (
    //           this.rowDetails.transactionDetailsEod[index].merchantPay ==
    //             true &&
    //           this.rowDetails.transactionDetailsEod[index].consumerPay == true
    //         ) {
    //           this.transactionDetails.settlementRequest.forEach(
    //             (element: any, index: number) => {
    //               this.transactionDetails.settlementRequest[
    //                 index
    //               ].merchantProcess = true;
    //               this.transactionDetails.settlementRequest[
    //                 index
    //               ].consumerProcess = true;
    //             }
    //           );
    //         }
    //       }
    //     }
    //   );
    // }
    // console.log(this.transactionDetails.settlementRequest);
    // console.log(this.rowDetails.transactionDetailsEod);
    // console.log(this.transactionDetails);
  }

  consumerPay: boolean = false;
  consumersProcess: boolean = false;
  onClickExpandTableConsumersProcess(event: Event,row: any ,value: any) {
    // this.consumerPay = !this.consumerPay;
    // row.consumerPay = this.consumerPay;
    const MerchantText = (event.target as HTMLButtonElement).textContent;

    if(MerchantText == ' Add ')
    {
      row.consumerPay = true;
      this.consumerPay= true;
    }
    else
    {
      row.consumerPay = false;
      this.consumerPay= false;
    }
    const settlementRequestItem = {
      transactionId: value[0],
      settlementRequestId: value[1],
      merchantId: String(value[2]),
      consumerId: value[3],
      consumerProcess: row.consumerPay,
      merchantProcess: row.merchantPay,
    };

    // console.log(settlementRequestItem);

    const isDuplicateIndex =
      this.transactionDetails.settlementRequest.findIndex(
        (item: any) =>
          item.transactionId === settlementRequestItem.transactionId &&
          item.settlementRequestId === settlementRequestItem.settlementRequestId
      );

    if (isDuplicateIndex !== -1) {
      console.log('Duplicate found, updating');
      console.log(row.consumerPay);
      // Update the existing item's merchantProcess
      this.transactionDetails.settlementRequest[
        isDuplicateIndex
      ].consumerProcess = row.consumerPay;
      console.log(this.transactionDetails.settlementRequest);
    } else {
      console.log('No duplicate, adding');
      this.transactionDetails.settlementRequest.push(settlementRequestItem);
    }

    // console.log(this.transactionDetails.settlementRequest);
  }

  // onClickExpandTableConsumersProcess(value: any, row: any) {
  //   this.consumerPay = !this.consumerPay;
  //   row.consumerPay = this.consumerPay;
  //   console.log('consumer ==1025', row.consumerPay);

  //   const settlementRequestItem = {
  //     transactionId: value[0],
  //     settlementRequestId: value[1],
  //     merchantId: String(value[2]),
  //     consumerId: value[3],
  //     consumerProcess: row.consumerPay,
  //     merchantProcess: false,
  //   };
  //   console.log(settlementRequestItem);
  //   const isDuplicate = this.transactionDetails.settlementRequest.some(
  //     (item: any) =>
  //       item.transactionId === settlementRequestItem.transactionId &&
  //       item.settlementRequestId === settlementRequestItem.settlementRequestId
  //   );
  //   if (isDuplicate !== -1) {
  //     console.log('Duplicate found, updating');

  //     this.transactionDetails.settlementRequest[isDuplicate].consumerProcess =
  //       row.consumerPay;
  //   } else {
  //     console.log('add');
  //   }

  //   if (!isDuplicate) {
  //     this.transactionDetails.settlementRequest.push(settlementRequestItem);
  //   }
  //   console.log(this.transactionDetails.settlementRequest);
  //   // if (row.consumerPay == true) {
  //   //   this.rowDetails.transactionDetailsEod.forEach(
  //   //     (element: any, index: number) => {
  //   //       //  console.log(element);
  //   //       if (element.transactionId == settlementRequestItem.transactionId) {
  //   //         this.rowDetails.transactionDetailsEod[index].consumerPay =
  //   //           this.consumerPay;
  //   //         if (
  //   //           this.rowDetails.transactionDetailsEod[index].merchantPay ==
  //   //             true &&
  //   //           this.rowDetails.transactionDetailsEod[index].consumerPay == true
  //   //         ) {
  //   //           this.transactionDetails.settlementRequest.forEach(
  //   //             (element: any, index: number) => {
  //   //               this.transactionDetails.settlementRequest[
  //   //                 index
  //   //               ].merchantProcess = true;
  //   //               this.transactionDetails.settlementRequest[
  //   //                 index
  //   //               ].consumerProcess = true;
  //   //             }
  //   //           );
  //   //         }
  //   //       }
  //   //     }
  //   //   );
  //   // }
  //   // if (row.consumerPay == false) {
  //   //   this.rowDetails.transactionDetailsEod.forEach(
  //   //     (element: any, index: number) => {

  //   //       if (element.transactionId == settlementRequestItem.transactionId) {
  //   //         this.rowDetails.transactionDetailsEod[index].consumerPay =
  //   //           this.consumerPay;
  //   //         if (
  //   //           this.rowDetails.transactionDetailsEod[index].merchantPay ==
  //   //             true &&
  //   //           this.rowDetails.transactionDetailsEod[index].consumerPay == true
  //   //         ) {
  //   //           this.transactionDetails.settlementRequest.forEach(
  //   //             (element: any, index: number) => {
  //   //               this.transactionDetails.settlementRequest[
  //   //                 index
  //   //               ].merchantProcess = true;
  //   //               this.transactionDetails.settlementRequest[
  //   //                 index
  //   //               ].consumerProcess = true;
  //   //             }
  //   //           );
  //   //         }
  //   //       }
  //   //     }
  //   //   );
  //   // }
  //   console.log(this.transactionDetails.settlementRequest);
  // }
  unpaidACH(settlementRequestId: number) {
    if (!this.claimIdArray.includes('ProcessesMenu_EODSettelement_Paid')) {
      this.toster.error('You are not authorized');

      return;
    }
    const dialogRef = this.dialog.open(UnpaidComponent, {
      width: '450px',
      panelClass: 'popup',
      data: [settlementRequestId, 'ach'],
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.getInvoiceEodReport();
    });
  }

  unpaidTranACH(data: number) {
    if (!this.claimIdArray.includes('ProcessesMenu_EODSettelement_Paid')) {
      this.toster.error('You are not authorized');
      return;
    }
    const dialogRef = this.dialog.open(UnpaidTransComponent, {
      width: '450px',
      panelClass: 'popup',
      data: [data, 'ach'],
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.getInvoiceEodReport();
    });
  }

  unpaidCashRewardTran(transactionId: number) {
    if (!this.claimIdArray.includes('ProcessesMenu_EODSettelement_Paid')) {
      this.toster.error('You are not authorized');
      return;
    }
    const dialogRef = this.dialog.open(UnpaidTransComponent, {
      width: '450px',
      panelClass: 'popup',
      data: [transactionId, 'cashrewad'],
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.getInvoiceEodReport();
    });
  }

  unpaidCardTran(transactionId: number) {
    if (!this.claimIdArray.includes('ProcessesMenu_EODSettelement_Paid')) {
      this.toster.error('You are not authorized');
      return;
    }
    const dialogRef = this.dialog.open(UnpaidTransComponent, {
      width: '450px',
      panelClass: 'popup',
      data: [transactionId, 'card'],
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.getInvoiceEodReport();
    });
  }

  unpaidCard(settlementRequestId: number) {
    if (!this.claimIdArray.includes('ProcessesMenu_EODSettelement_Paid')) {
      this.toster.error('You are not authorized');
      return;
    }
    const dialogRef = this.dialog.open(UnpaidComponent, {
      width: '450px',
      panelClass: 'popup',
      data: [settlementRequestId, 'card'],
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.getInvoiceEodReport();
    });
  }
  getEodPdf(settlementRequestId: number) {
    if (!this.claimIdArray.includes('ProcessesMenu_EODSettelement_ViewPdf')) {
      this.toster.error('You are not authorized');
      return;
    }
    const dialogRef = this.dialog.open(PreviewPdfComponent, {
      panelClass: 'popup',
      data: settlementRequestId,
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.getInvoiceEodReport();
    });
  }
}

export interface EodTable {
  settlementRequestId: number;
  siteId: string;
  umti: string;
  merchantId: number;

  businessDate: number;
  settlementPeriodId: number;
  mppaCounts: number;
  mppaTotalAmount: number;
  terminalTotalAmount: number;
  terminalCounts: number;
  error: boolean;
  isResponseError: boolean;
  actions: string;
}
