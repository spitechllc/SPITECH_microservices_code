import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { ExcelService } from 'src/app/dashboard/api-service/excel-servive/excel.service';

@Component({
  selector: 'app-invoice-eod-report-excel-report',
  templateUrl: './invoice-eod-report-excel-report.component.html',
  styleUrls: ['./invoice-eod-report-excel-report.component.scss'],
})
export class InvoiceEodReportExcelReportComponent implements OnInit {
  constructor(
    private excelService: ExcelService,
    public dialogRef: MatDialogRef<InvoiceEodReportExcelReportComponent>,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: { data: any }
  ) {
    this.excelData = data;
    // console.log(this.excelData);
  }
  excelData: any;
  siteId: boolean = true;
  storeName: boolean = true;
  businessDate: boolean = true;
  mppaTotalAmount: boolean = true;
  createdOn: boolean = true;
  mppaCounts: boolean = true;
  terminalTotalAmount: boolean = true;
  terminalCounts: boolean = true;
  cashRewardAmount: boolean = true;
  cardAmount: boolean = true;
  isPaid: boolean = true;
  country: boolean = true;
  zipCode: boolean = true;
  achAmount: boolean = true;
  ngOnInit(): void {}

  onClickChexBox(event: any) {
    if (event.source.value == 'siteId' && event.checked == false) {
      this.siteId = false;
    } else if (event.source.value == 'siteId' && event.checked == true) {
      this.siteId = true;
    }
    if (event.source.value == 'storeName' && event.checked == false) {
      this.storeName = false;
    } else if (event.source.value == 'storeName' && event.checked == true) {
      this.storeName = true;
    }
    if (event.source.value == 'businessDate' && event.checked == false) {
      this.businessDate = false;
    } else if (event.source.value == 'businessDate' && event.checked == true) {
      this.businessDate = true;
    }

    if (event.source.value == 'mppaTotalAmount' && event.checked == false) {
      this.mppaTotalAmount = false;
    } else if (
      event.source.value == 'mppaTotalAmount' &&
      event.checked == true
    ) {
      this.mppaTotalAmount = true;
    }

    if (event.source.value == 'mppaCounts' && event.checked == false) {
      this.mppaCounts = false;
    } else if (event.source.value == 'mppaCounts' && event.checked == true) {
      this.mppaCounts = true;
    }
    if (event.source.value == 'terminalTotalAmount' && event.checked == false) {
      this.terminalTotalAmount = false;
    } else if (
      event.source.value == 'terminalTotalAmount' &&
      event.checked == true
    ) {
      this.terminalTotalAmount = true;
    }
    if (event.source.value == 'terminalCounts' && event.checked == false) {
      this.terminalCounts = false;
    } else if (
      event.source.value == 'terminalCounts' &&
      event.checked == true
    ) {
      this.terminalCounts = true;
    }
    if (event.source.value == 'cashRewardAmount' && event.checked == false) {
      this.cashRewardAmount = false;
    } else if (
      event.source.value == 'cashRewardAmount' &&
      event.checked == true
    ) {
      this.cashRewardAmount = true;
    }
    if (event.source.value == 'cardAmount' && event.checked == false) {
      this.cardAmount = false;
    } else if (event.source.value == 'cardAmount' && event.checked == true) {
      this.cardAmount = true;
    }
    if (event.source.value == 'achAmount' && event.checked == false) {
      this.achAmount = false;
    } else if (event.source.value == 'achAmount' && event.checked == true) {
      this.achAmount = true;
    }
    if (event.source.value == 'isPaid' && event.checked == false) {
      this.isPaid = false;
    } else if (event.source.value == 'isPaid' && event.checked == true) {
      this.isPaid = true;
    }
  }
  excelExport() {
    const excelExportData = this.excelData.map((t: any) => {
      const dataObject: any = {};
      if (this.siteId == true) {
        dataObject.siteId = t.siteId;
      }
      if (this.storeName == true) {
        dataObject.storeName = t.storeName;
      }
      if (this.achAmount == true) {
        dataObject.achAmount = t.achAmount;
      }
      if (this.businessDate == true) {
        dataObject.businessDate = t.businessDate;
      }
      if (this.mppaTotalAmount == true) {
        dataObject.mppaTotalAmount = t.mppaTotalAmount;
      }

      if (this.mppaCounts == true) {
        dataObject.mppaCounts = t.mppaCounts;
      }
      if (this.terminalTotalAmount == true) {
        dataObject.terminalTotalAmount = t.terminalTotalAmount;
      }
      if (this.terminalCounts == true) {
        dataObject.terminalCounts = t.terminalCounts;
      }
      if (this.cashRewardAmount == true) {
        dataObject.cashRewardAmount = t.cashRewardAmount;
      }
      if (this.cardAmount == true) {
        dataObject.cardAmount = t.cardAmount;
      }
      if (this.isPaid == true) {
        dataObject.isPaid = t.isPaid;
      }

      return dataObject;
    });

    this.excelService.exportAsExcelFile(
      excelExportData,
      'Invoice-eod-report-exported-data'
    );
  }
}
