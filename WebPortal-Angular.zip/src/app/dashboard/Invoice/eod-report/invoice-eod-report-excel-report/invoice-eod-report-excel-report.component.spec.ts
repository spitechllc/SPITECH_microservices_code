import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoiceEodReportExcelReportComponent } from './invoice-eod-report-excel-report.component';

describe('InvoiceEodReportExcelReportComponent', () => {
  let component: InvoiceEodReportExcelReportComponent;
  let fixture: ComponentFixture<InvoiceEodReportExcelReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InvoiceEodReportExcelReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoiceEodReportExcelReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
