import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-checkbalance',
  templateUrl: './checkbalance.component.html',
  styleUrls: ['./checkbalance.component.scss'],
})
export class CheckbalanceComponent implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<CheckbalanceComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { data: any }
  ) {
    this.accounts = data;
    this.accountDetails = this.accounts.accounts;
  }
  accounts: any;
  accountDetails: any;
  ngOnInit(): void {}
}
