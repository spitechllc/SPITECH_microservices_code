import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewNachaComponent } from './view-nacha.component';

describe('ViewNachaComponent', () => {
  let component: ViewNachaComponent;
  let fixture: ComponentFixture<ViewNachaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewNachaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewNachaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
