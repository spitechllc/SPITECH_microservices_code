import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NachaFileComponent } from './nacha-file.component';

describe('NachaFileComponent', () => {
  let component: NachaFileComponent;
  let fixture: ComponentFixture<NachaFileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NachaFileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NachaFileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
