import { Component, Inject, OnInit } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { TransactionService } from 'src/app/dashboard/api-service/trasation.service';
import { DomSanitizer } from '@angular/platform-browser';
import { ToastrService } from 'ngx-toastr';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
} from '@angular/material/core';
import * as _moment from 'moment';
export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/DD/YYYY',
  },
  display: {
    dateInput: 'MM/DD/YYYY',
    monthYearLabel: 'MMM  YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM   YYYY',
  },
};
@Component({
  selector: 'app-nacha-file',
  templateUrl: './nacha-file.component.html',
  styleUrls: ['./nacha-file.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },

    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})
export class NachaFileComponent implements OnInit {
  
  minDate = new Date();
  selectedDate = new FormControl(new Date());
  nachaFilesDetails: any;
  filename: string = '';
  BusinessDate: any;
  Data: any;
  nachaLink: any;
  constructor(
    private transactionService: TransactionService,
    public dialog: MatDialog,
    private sanitizer: DomSanitizer,
    private toster: ToastrService,
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<NachaFileComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { data: any }
  ) {
    this.Data = data;
    // console.log(this.Data);
    this.BusinessDate = this.Data.date;
  }
  previewNachaForm!: FormGroup;


  get f() {
    return this.previewNachaForm.controls;
  }
  ngOnInit(): void {
    this.createNachaForm();
  }
  nacha: boolean = true;

  createNachaForm() {
    this.previewNachaForm = this.fb.group({
      OnlyCard: new FormControl('0', Validators.required),
      OnlyCashReward: new FormControl('1', Validators.required),
      OnlyAch: new FormControl('1'),
      EffectiveDate: new FormControl('', Validators.required),
    });
  }
  EffectiveDate: any;
  onClickTransactionDate(event: any) {
    var effectiveDate = event.target.value.format('YYYY-MM-DD HH:mm:ss');
    this.EffectiveDate = _moment(_moment(effectiveDate))
      .utc()
      .format('YYYY-MM-DD HH:mm:ss');
  }
  getNachaFile() {
    var OnlyCard = null;
    var OnlyCashReward = null;
    var OnlyAch = null;
    
    if(this.EffectiveDate == 'undefined' || this.EffectiveDate == undefined)
    {
      this.toster.info('Effective date required');
      return;
    }

    if (this.previewNachaForm.get('OnlyCard')?.value == '1') {
      OnlyCard = 1;
    } else if (this.previewNachaForm.get('OnlyCard')?.value == '0') {
      OnlyCard = 0;
    }
    if (this.previewNachaForm.get('OnlyCashReward')?.value == '1') {
      OnlyCashReward = 1;
    } else if (this.previewNachaForm.get('OnlyCashReward')?.value == '0') {
      OnlyCashReward = 0;
    }
    if (this.previewNachaForm.get('OnlyAch')?.value == '1') {
      OnlyAch = 1;
    } else if (this.previewNachaForm.get('OnlyAch')?.value == '0') {
      OnlyAch = 0;
    } else if (this.previewNachaForm.get('OnlyAch')?.value == '2') {
      OnlyAch = 2;
    }
    
    this.transactionService
      .geteodPreviewNachaFile({
        businessDate: this.BusinessDate,
        cardPayment: OnlyCard,
        cashRewardPayment: OnlyCashReward,
        effectiveDate: this.EffectiveDate,
        achPayment: OnlyAch,
        settlementRequest: this.Data.trans.settlementRequest,

        // businessDate: '2024-01-01 18:30:00',
        // cardPayment: 0,
        // cashRewardPayment: 1,
        // effectiveDate: '2024-01-04 18:30:00',
        // achPayment: 1,
        // settlementRequest: [
        //   {
        //     transactionId: 7035,
        //     settlementRequestId: 14420,
        //     merchantId: '0',
        //     consumerId: 541,
        //     consumerProcess: true,
        //     merchantProcess: true,
        //   },
        // ],
      })
      .subscribe(
        (data: any) => {
          this.nachaFilesDetails = data;
          if (this.nachaFilesDetails == null) {
            this.nacha = false;
          }
          if (this.nachaFilesDetails != null) {
            let dataType = data.type;
            let binaryData = [];
            binaryData.push(data);
            let downloadLink = document.createElement('iframe');

            downloadLink.src = window.URL.createObjectURL(
              new Blob(binaryData, { type: dataType })
            );
            this.nachaLink = this.sanitizer.bypassSecurityTrustResourceUrl(
              downloadLink.src
            );
          }
        },
        (err) => {
          if (err.status == 404) {
            this.toster.error('Nacha file not process ');
          }
        }
      );
  }
}
