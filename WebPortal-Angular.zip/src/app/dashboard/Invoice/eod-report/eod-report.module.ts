import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EodReportComponent } from '../eod-report/eod-report.component';
import { SharedModule } from 'src/app/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatListModule } from '@angular/material/list';
import { NgxMaterialTimepickerModule } from 'ngx-material-timepicker';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { RouterModule, Routes } from '@angular/router';
import { NachaFileComponent } from './nacha-file/nacha-file.component';
import { ViewNachaComponent } from './view-nacha/view-nacha.component';
import { UnpaidComponent } from './unpaid/unpaid.component';
import { PreviewPdfComponent } from './preview-pdf/preview-pdf.component';
import { PaymentPocessPopupComponent } from './payment-pocess-popup/payment-pocess-popup.component';
import { InvoiceEodReportExcelReportComponent } from './invoice-eod-report-excel-report/invoice-eod-report-excel-report.component';
import { UnpaidTransComponent } from './unpaid-trans/unpaid-trans.component';
import { CheckbalanceComponent } from './checkbalance/checkbalance.component';

export const router: Routes = [{ path: '', component: EodReportComponent }];
@NgModule({
  declarations: [EodReportComponent, NachaFileComponent, ViewNachaComponent, UnpaidComponent, PreviewPdfComponent, PaymentPocessPopupComponent, InvoiceEodReportExcelReportComponent, UnpaidTransComponent, CheckbalanceComponent],
  imports: [
    CommonModule,
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    MatListModule,
    NgxMaterialTimepickerModule,
    MatAutocompleteModule,
    RouterModule.forChild(router),
  ],
})
export class EodReportModule {}
