import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
import { ToastrService } from 'ngx-toastr';
import { TransactionService } from 'src/app/dashboard/api-service/trasation.service';
@Component({
  selector: 'app-unpaid',
  templateUrl: './unpaid-trans.component.html',
  styleUrls: ['./unpaid-trans.component.scss'],
})
export class UnpaidTransComponent implements OnInit {
  constructor(
    private transactionService: TransactionService,
    public dialog: MatDialog,
    private sanitizer: DomSanitizer,
    private toster: ToastrService,
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<UnpaidTransComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { data: any }
  ) {
    // console.log(data, 'date');
    this.popupdata = data;
    console.log(this.popupdata, 'data');
    this.card = this.popupdata[1];
  }
  d: boolean = false;
  submitted: boolean = false;
  popupdata: any;
  eodUnpaidTranForm!: FormGroup;
  card: any;
  ngOnInit(): void {
    this.createForm();
  }
  createForm() {
    this.eodUnpaidTranForm = this.fb.group({
      TransactionId: new FormControl(this.popupdata[0].transactionId),
      onlyCard:
        this.card == 'card'
          ? false
          : this.popupdata[0].cardPaymentStatusId == 0
          ? false
          : true,
      onlyCashReward:
        this.card == 'cashrewad'
          ? false
          : this.popupdata[0].cashRewardPaymentStatusId == 0
          ? false
          : true,
      onlyACH:
        this.card == 'ach'
          ? false
          : this.popupdata[0].achPaymentStatusId == 0
          ? false
          : true,
      reason: new FormControl(''),
    });
  }

  updateEodUnpaid() {
    const spaceRegex = /^\s*$/;
    if (spaceRegex.test(this.eodUnpaidTranForm.value.reason)) {
      this.toster.error('Please enter reason exp: Unpaid ACH.');
      return;
    }
    if(this.eodUnpaidTranForm.value.reason == "")
    {
      this.toster.error('Please enter reason exp: Unpaid ACH.');
      return;
    }
    this.transactionService
      .eodUnpaidTrans(this.eodUnpaidTranForm.value)
      .subscribe(
        (data: any) => {
          if (data.success == false) {
            this.toster.error(data.message);
          }
          if (data.success == true) {
            this.toster.success('Unpaid reason post successfully');
          }
          this.dialogRef.close([]);
        },
        (err) => {
          if (err.status == 401) {
            this.toster.error('Resource not found');
          }
        }
      );
  }
}
