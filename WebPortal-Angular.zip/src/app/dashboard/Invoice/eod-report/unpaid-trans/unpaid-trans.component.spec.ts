import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UnpaidTransComponent } from './unpaid-trans.component';

describe('UnpaidTransComponent', () => {
  let component: UnpaidTransComponent;
  let fixture: ComponentFixture<UnpaidTransComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UnpaidTransComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UnpaidTransComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
