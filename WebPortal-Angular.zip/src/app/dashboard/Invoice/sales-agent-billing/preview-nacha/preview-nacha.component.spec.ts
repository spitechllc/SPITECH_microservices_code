import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PreviewNachaComponent } from './preview-nacha.component';

describe('PreviewNachaComponent', () => {
  let component: PreviewNachaComponent;
  let fixture: ComponentFixture<PreviewNachaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PreviewNachaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PreviewNachaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
