import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SalesAgentBillingComponent } from './sales-agent-billing.component';
import { SharedModule } from 'src/app/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { RouterModule, Routes } from '@angular/router';
import { SaleAgentUnpaidPopupComponent } from './sale-agent-unpaid-popup/sale-agent-unpaid-popup.component';
import { PreviewNachaComponent } from './preview-nacha/preview-nacha.component';
import { ViewNachaComponent } from './view-nacha/view-nacha.component';
import { PreviewPdfComponent } from './preview-pdf/preview-pdf.component';
import { SaleAgentBillingExcelReportComponent } from './sale-agent-billing-excel-report/sale-agent-billing-excel-report.component';

export const router: Routes = [
  {
    path: '',
    component: SalesAgentBillingComponent,
  },
];

@NgModule({
  declarations: [SalesAgentBillingComponent, SaleAgentUnpaidPopupComponent, PreviewNachaComponent, ViewNachaComponent, PreviewPdfComponent, SaleAgentBillingExcelReportComponent],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatAutocompleteModule,
    // NgMultiSelectDropDownModule.forRoot(),
    RouterModule.forChild(router),
  ],
})
export class SalesAgentBillingModule {}
