import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SalesAgentBillingComponent } from './sales-agent-billing.component';

describe('SalesAgentBillingComponent', () => {
  let component: SalesAgentBillingComponent;
  let fixture: ComponentFixture<SalesAgentBillingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SalesAgentBillingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SalesAgentBillingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
