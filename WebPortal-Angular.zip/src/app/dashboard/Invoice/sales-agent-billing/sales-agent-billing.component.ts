import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { debounce } from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { StoreService } from '../../api-service/storeService';
import { TransactionService } from '../../api-service/trasation.service';
import { AuthService } from '../../auth/auth.service';
import { PreviewNachaComponent } from './preview-nacha/preview-nacha.component';
import { SaleAgentUnpaidPopupComponent } from './sale-agent-unpaid-popup/sale-agent-unpaid-popup.component';
import { ViewNachaComponent } from './view-nacha/view-nacha.component';
import { ExcelService } from '../../api-service/excel-servive/excel.service';

import { DomSanitizer } from '@angular/platform-browser';
import { PreviewPdfComponent } from './preview-pdf/preview-pdf.component';
import { SharedService } from '../../auth/shared.service';
import { SaleAgentBillingExcelReportComponent } from './sale-agent-billing-excel-report/sale-agent-billing-excel-report.component';
@Component({
  selector: 'app-sales-agent-billing',
  templateUrl: './sales-agent-billing.component.html',
  styleUrls: ['./sales-agent-billing.component.scss'],
})
export class SalesAgentBillingComponent implements OnInit {
  displayedColumns = [
    'saleAgentId',
    'saleAgentName',
    'siteId',
    'storeId',
    'storeName',
    'transactionAmount',
    'transactionPercentageFee',
    'totalFee',
    'isPaid',
    'viewNacha',
    'action',
    'PreviewPdf',
    // 'TransactionDetail',
  ];
  dataSource = new MatTableDataSource<StoreTable>([]);
  stores: any = [];
  PageIndex = 1;
  PageSize = 50;
  GenerateBy: number = 0;
  dropdownList: any = [];
  selectedItems: any = [];
  selectedValue: any;
  searchTxt: any;
  totalCount: any;
  items: any;
  monthlyBillingForm!: FormGroup;
  geneareteForm!: FormGroup;
  err: string = '';
  checked: boolean = false;
  storeBillingDetails: any = [];
  length: any;
  checkbox = false;
  generateBy: any;
  get roleIds() {
    return this.monthlyBillingForm.get('siteIds') as FormArray;
  }
  claimIdArray: any;
  searchEvent: any;
  fiterSiteId: any;
  lengthsite: any;
  dataNotFond: string = 'Data not found';
  SiteId: any;
  BusinessDate = '';
  StoreId: number = 0;
  IsNeedReview: boolean = false;

  AmountMatched: boolean = false;
  reportDetail: any;
  site: any;
  pageLength: any;
  siteNumber: any = null;
  Month: number = 0;
  Year: number = 0;
  sortBy: string = '';
  sortOrder: string = '';
  gMonth: number = 0;
  gYear: number = 0;
  submitted: boolean = false;
  gsubmitted: boolean = false;
  salesAgentData: any = [];
  get f() {
    return this.monthlyBillingForm.controls;
  }
  get gf() {
    return this.geneareteForm.controls;
  }
  constructor(
    private storeService: StoreService,
    private transactionService: TransactionService,
    private toster: ToastrService,
    private spinner: NgxSpinnerService,
    public dialog: MatDialog,
    private sanitizer: DomSanitizer,
    private fb: FormBuilder,
    private auth: AuthService,
    private router: Router,
    private excelService: ExcelService,
    public sharedService: SharedService
  ) {}
  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.createForm();
    if (history.state.Back == 'back') {
      this.monthlyBillingForm.patchValue({
        month: history.state.Month,
        year: history.state.Year,
      });

      this.Month = history.state.Month;
      this.Year = history.state.Year;
      this.StoreId = history.state.StoreId;
      this.PageIndex = history.state.PageIndex;
      this.PageSize = history.state.PageSize;
      this.IsNeedReview = history.state.IsNeedReview;
      this.IsPaid = history.state.IsPaid;
      this.monthlyBilling();
    }
  }

  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  exportAsExcel() {
    this.submitted = true;
    if (this.monthlyBillingForm.invalid) {
      return;
    }

    var pageSize = 0;
    var pageIndex = 0;
    var IsNeedReview = null;
    var IsPaid = null;

    if (this.monthlyBillingForm.get('IsNeedReview')?.value == '1') {
      IsNeedReview = true;
    } else if (this.monthlyBillingForm.get('IsNeedReview')?.value == '0') {
      IsNeedReview = false;
    }
    if (this.monthlyBillingForm.get('IsPaid')?.value == '1') {
      IsPaid = true;
    } else if (this.monthlyBillingForm.get('IsPaid')?.value == '0') {
      IsPaid = false;
    }

    this.transactionService
      .getSalesAgentMonthlyBill(
        pageSize,
        pageSize,
        this.StoreId,
        IsNeedReview,
        IsPaid,
        this.Month,
        this.Year,
        this.sortBy,
        this.sortOrder
      )
      .subscribe((data: any) => {
        this.salesAgentData = data.data;
        if (this.salesAgentData.length > 0) {
          const dialogRef = this.dialog.open(
            SaleAgentBillingExcelReportComponent,
            {
              width: '450px',
              panelClass: 'popup',
              data: this.salesAgentData,
            }
          );
          // this.excelService.exportAsExcelFile(
          //   this.salesAgentData.map((t: any) => {
          //     return {
          //       SiteId: t.siteId,
          //       StoreId: t.storeId,
          //       StoreName: t.storeName,
          //       SaleAgentId: t.saleAgentId,
          //       SaleAgentName: t.saleAgentName,
          //       DefineTransactionPercentageFee:
          //         t.defineTransactionPercentageFee,
          //       DefineMonthlySaasFee: t.defineMonthlySaasFee,
          //       TransactionPercentageFee: t.transactionPercentageFee,
          //       TotalFee: t.totalFee,
          //       TransactionAmount: t.transactionAmount,
          //     };
          //   }),
          //   'sales-agent-excel'
          // );
        } else {
          this.toster.error('Data not found');
        }
      });
  }
  createForm() {
    this.monthlyBillingForm = this.fb.group({
      month: new FormControl('', Validators.required),
      year: new FormControl('', Validators.required),
      IsNeedReview: new FormControl(''),
      IsPaid: new FormControl(''),
    });
    this.geneareteForm = this.fb.group({
      gmonth: new FormControl('', Validators.required),
      gyear: new FormControl('', Validators.required),
    });
  }
  onSelectgMonth(month: any) {
    this.gMonth = month.value;
  }
  onSelectgYear(year: any) {
    this.gYear = year.value;
  }
  onSelectMonth(month: any) {
    this.Month = month.value;
  }
  onSelectYear(year: any) {
    this.Year = year.value;
  }

  onChange(event: any) {
    this.searchEvent = event;
    if (this.searchEvent == 0) {
      this.StoreId = 0;
    }
  }

  onClickSiteIdd(event: any) {
    this.SiteId = event;
    this.StoreId = event;
  }

  serachBySiteId = debounce((event: any) => {
    if (event.target.value == '') {
      this.StoreId = 0;
    }
    this.storeService
      .getStoreAutoCompleteBySiteId(event.target.value)
      .subscribe((data: any) => {
        this.lengthsite = data.data.length;

        this.fiterSiteId = data.data;
        this.SiteId = this.fiterSiteId.siteId;
        this.StoreId = this.fiterSiteId.storeId;
      });
  }, 1000);

  serachByStoreName = debounce((event: any) => {
    this.storeService
      .getStoreAutoCompleteByStoreName(event.target.value)
      .subscribe((data: any) => {
        this.lengthsite = data.data.length;
        this.fiterSiteId = data.data;
      });
  }, 1000);

  needReview: any;
  paid: any;
  IsStoreNeedReview: any;
  IsSaleAgentNeedReview: any;
  IsPaid: any;

  saleAgentData: any;

  onHeaderSortChange(event: any) {
    this.sortBy = event.active;
    if (event.direction == '') {
      this.sortOrder = 'asc';
    } else {
      this.sortOrder = event.direction;
    }

    this.monthlyBilling();
  }

  monthlyBilling() {
    this.submitted = true;
    if (this.monthlyBillingForm.invalid) {
      return;
    }
    this.spinner.show();
    var IsNeedReview = null;
    var IsPaid = null;

    if (this.monthlyBillingForm.get('IsNeedReview')?.value == '1') {
      IsNeedReview = true;
    } else if (this.monthlyBillingForm.get('IsNeedReview')?.value == '0') {
      IsNeedReview = false;
    }
    if (this.monthlyBillingForm.get('IsPaid')?.value == '1') {
      IsPaid = true;
    } else if (this.monthlyBillingForm.get('IsPaid')?.value == '0') {
      IsPaid = false;
    }

    this.transactionService
      .getSalesAgentMonthlyBill(
        this.PageIndex,
        this.PageSize,
        this.StoreId,
        IsNeedReview,
        IsPaid,
        this.Month,
        this.Year,
        this.sortBy,
        this.sortOrder
      )
      .subscribe(
        (data: any) => {
          this.saleAgentData = data;
          this.storeBillingDetails = data.data;
          // console.log(data);
          this.length = this.storeBillingDetails.length;
          if (this.length == 0) {
            this.spinner.hide();
          }

          this.storeBillingDetails.forEach((element: any) => {
            // this.setSiteId(this.storeBillingDetails);
            this.dataSource = new MatTableDataSource(data.data);
            this.totalCount = data.totalCount;
            this.spinner.hide();
          });
        },
        (err: any) => {
          // console.log(err, 'err');
          this.spinner.hide();

          if (err.status == 400) {
            this.toster.error('Bad request ');
          }

          if (err.error.errors.Year) {
            err.error.errors.Year.forEach((err: any) => {
              this.toster.error(err);
            });
          }
          if (err.error.errors.Month) {
            err.error.errors.Month.forEach((err: any) => {
              this.toster.error(err);
            });
          }
        }
      );
  }

  generateBill() {
    this.gsubmitted = true;
    if (this.geneareteForm.invalid) {
      return;
    }
    this.transactionService
      .getSalesAgentMonthlyBillGenerate({
        Month: this.gMonth,
        Year: this.gYear,
      })
      .subscribe(
        (data: any) => {
          if (data.success == true) {
            this.toster.success('Bill generate successfully');
          }
          if (data.success == false && data.message == null) {
            this.toster.error('Bill is not generate for this month');
          } else if (data.success == false && data.message) {
            this.toster.error(data.message);
          }
        },
        (err) => {
          if (err.status == 400) {
            this.toster.error('Bad request ');
          }
          if (err.status == 401) {
            this.toster.error('Reasource not found ');
          }
          if (err.error.errors.Year) {
            err.error.errors.Year.forEach((err: any) => {
              this.toster.error(err);
            });
          }
          if (err.error.errors.Month) {
            err.error.errors.Month.forEach((err: any) => {
              this.toster.error(err);
            });
          }
        }
      );
  }
  UpdateReview(saleAgentBillingId: any) {
    if (
      !this.claimIdArray.includes(
        'ProcessesMenu_SaleAgentMonthlyBilling_ReviewUnreview'
      )
    ) {
      this.toster.error('You are not authorized');
      return;
    }
    this.transactionService
      .updateSalesAgentNeedReview({
        saleAgentBillingIds: [saleAgentBillingId[0]],
        isNeedReview: saleAgentBillingId[1] == false ? true : false,
      })
      .subscribe(
        (data: any) => {
          if (data.success == true) {
            this.toster.success('Update need review');
          }
          if (data.success == false) {
            this.toster.error(data.message);
          }
          this.monthlyBilling();
        },
        (err) => {
          if (err.status == 400) {
            this.toster.error('Bad request ');
          }
          if (err.status == 401) {
            this.toster.error('Reasource not found ');
          }
        }
      );
  }

  processPayment() {
    this.transactionService
      .saleAgentBillingPaymentProcess({ Month: this.Month, Year: this.Year })
      .subscribe(
        (data: any) => {
          if (data.success == true) {
            this.toster.success('Process Payment successfully');
            this.monthlyBilling();
          }
          if (data.success == false) {
            this.toster.warning(data.message);
            this.monthlyBilling();
          }
        },
        (err) => {
          if (err.status == 400) {
            this.toster.error('Bad request ');
          }
          if (err.status == 401) {
            this.toster.error('Reasource not found ');
          }
        }
      );
  }
  // selectAllReview() {
  //   this.storeBillingDetails.forEach((element: any) => {
  //     this.checked = true;

  //     this.transactionService
  //       .updateNeedReview({
  //         storeBillingIds: [element.storeBillingId],
  //         isNeedReview: element.isNeedReview == true ? false : false,
  //       })
  //       .subscribe((data: any) => {
  //         this.toster.success('Update need review');
  //         this.checked = false;
  //       });
  //   });
  // }
  // selectAllunreview() {
  //   this.storeBillingDetails.forEach((element: any) => {
  //     this.checked = true;

  //     this.transactionService
  //       .updateNeedReview({
  //         storeBillingIds: [element.storeBillingId],
  //         isNeedReview: element.isNeedReview == false ? true : true,
  //       })
  //       .subscribe((data: any) => {
  //         this.toster.success('Update need review');
  //         this.checked = false;
  //       });
  //   });
  // }
  PreviewNachaPopup() {
    const dialogRef = this.dialog.open(PreviewNachaComponent, {
      width: '400px',
      panelClass: 'popup',
      data: { Month: this.Month, Year: this.Year },
    });
    dialogRef.afterClosed().subscribe(
      (data: any) => {
        this.monthlyBilling();
      },
      (err) => {
        if (err.status == 500) {
          this.toster.error('Internal sever error');
        }
        if (err.status == 400) {
          this.toster.error('Bad request ');
        }
        if (err.status == 401) {
          this.toster.error('Reasource not found ');
        }
      }
    );
  }
  ViewNacha(storeBillingId: number) {
    if (
      !this.claimIdArray.includes(
        'ProcessesMenu_SaleAgentMonthlyBilling_ViewNacha'
      )
    ) {
      this.toster.error('You are not authorized');
      return;
    }
    const dialogRef = this.dialog.open(ViewNachaComponent, {
      width: '400px',
      panelClass: 'popup',
      data: storeBillingId,
    });
    dialogRef.afterClosed().subscribe(
      (data: any) => {
        this.monthlyBilling();
      },
      (err) => {
        if (err.status == 500) {
          this.toster.error('Internal sever error');
        }
        if (err.status == 400) {
          this.toster.error('Bad request ');
        }
        if (err.status == 401) {
          this.toster.error('Reasource not found ');
        }
      }
    );
  }

  unpaidPopup(storeBillingId: number) {
    if (
      !this.claimIdArray.includes('ProcessesMenu_SaleAgentMonthlyBilling_Paid')
    ) {
      this.toster.error('You are not authorized');
      return;
    }
    const dialogRef = this.dialog.open(SaleAgentUnpaidPopupComponent, {
      width: '400px',
      panelClass: 'popup',
      data: storeBillingId,
    });
    dialogRef.afterClosed().subscribe(
      (data: any) => {
        this.monthlyBilling();
      },
      (err) => {
        if (err.status == 500) {
          this.toster.error('Internal sever error');
        }
        if (err.status == 400) {
          this.toster.error('Bad request ');
        }
        if (err.status == 401) {
          this.toster.error('Reasource not found ');
        }
      }
    );
  }
  // getsiteId() {
  //   const siteId: any = [];
  //   this.reportDetail?.forEach((element: any) => {
  //     siteId.push(element.siteId);
  //   });

  //   this.site = [...new Set(siteId)];
  //   this.pageLength = this.site.length;
  //   // console.log(this.site);
  //   return siteId;
  // }

  pageChanged2(event: PageEvent) {
    let pageNumber = event.pageIndex;
    const siteId = this.site[pageNumber];

    this.dataSource.data = this.storeBillingDetails?.filter(
      (element: any) => element.siteId == siteId
    );
  }

  pdfLink: any;
  saleAjentpdf(saleAgentBillingDetailId: any) {
    this.spinner.show();
    this.transactionService
      .saleAgentMonthlyInvoicePdf(saleAgentBillingDetailId)
      .subscribe(
        (data: any) => {
          // this.nachaFilesDetails = data;
          // console.log(this.nachaFilesDetails, 'nachafile');
          let dataType = data.type;
          let binaryData = [];
          binaryData.push(data);
          let downloadLink = document.createElement('iframe');
          var downloadURL = window.URL.createObjectURL(data);
          var link = document.createElement('a');
          link.href = downloadURL;
          link.download = 'saleAgent_billing.pdf';
          link.click();
          downloadLink.src = window.URL.createObjectURL(
            new Blob(binaryData, { type: dataType })
          );
          this.pdfLink = this.sanitizer.bypassSecurityTrustResourceUrl(
            downloadLink.src
          );
          this.spinner.hide();
        },
        (err) => {}
      );
  }

  saleAjentMonthlypdf() {
    this.spinner.show();
    this.transactionService
      .getAllSaleAgentMonthlyInvoicePdf(
        this.StoreId,
        this.IsNeedReview,
        this.IsPaid,
        this.Month,
        this.Year
      )
      .subscribe(
        (data: any) => {
          // this.nachaFilesDetails = data;
          // console.log(this.nachaFilesDetails, 'nachafile');
          let dataType = data.type;
          let binaryData = [];
          binaryData.push(data);
          let downloadLink = document.createElement('iframe');
          var downloadURL = window.URL.createObjectURL(data);
          var link = document.createElement('a');
          link.href = downloadURL;
          link.download = 'saleAgent_billing.pdf';
          link.click();
          downloadLink.src = window.URL.createObjectURL(
            new Blob(binaryData, { type: dataType })
          );
          this.pdfLink = this.sanitizer.bypassSecurityTrustResourceUrl(
            downloadLink.src
          );
          this.spinner.hide();
        },
        (err) => {}
      );
  }

  getMonthlyBillingPdf() {
    var IsNeedReview = null;
    var IsPaid = null;

    if (this.monthlyBillingForm.get('IsNeedReview')?.value == '1') {
      IsNeedReview = true;
    } else if (this.monthlyBillingForm.get('IsNeedReview')?.value == '0') {
      IsNeedReview = false;
    }

    if (this.monthlyBillingForm.get('IsPaid')?.value == '1') {
      IsPaid = true;
    } else if (this.monthlyBillingForm.get('IsPaid')?.value == '0') {
      IsPaid = false;
    }

    const dialogRef = this.dialog.open(PreviewPdfComponent, {
      panelClass: 'popup',
      data: [
        1,
        'monthlypdf',
        this.StoreId,
        IsNeedReview,
        IsPaid,
        this.Month,
        this.Year,
      ],
    });
    // dialogRef.afterClosed().subscribe((data: any) => {
    //   this.getInvoiceEodReport();
    // });
  }
  getStoreBillingPdf(saleAgentBillingDetailId: number) {
    if (
      !this.claimIdArray.includes(
        'ProcessesMenu_SaleAgentMonthlyBilling_ViewPdf'
      )
    ) {
      this.toster.error('You are not authorized');
      return;
    }
    const dialogRef = this.dialog.open(PreviewPdfComponent, {
      panelClass: 'popup',
      data: [saleAgentBillingDetailId, 'pdf'],
    });
    // dialogRef.afterClosed().subscribe((data: any) => {
    //   this.getInvoiceEodReport();
    // });
  }
}

export interface StoreTable {
  billGenerateDate: string;
  siteId: string;
  storeId: string;
  // StoreName: string;
  monthlySaasFee: number;
  transactionFee: number;
  transactionPercentageFee: number;
  transactionCount: number;
  transactionAmount: number;
  totalFee: number;
  isProcessed: boolean;
}
