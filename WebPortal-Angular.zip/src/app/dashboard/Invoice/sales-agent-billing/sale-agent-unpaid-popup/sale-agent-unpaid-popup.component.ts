import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
import { ToastrService } from 'ngx-toastr';
import { TransactionService } from 'src/app/dashboard/api-service/trasation.service';

@Component({
  selector: 'app-sale-agent-unpaid-popup',
  templateUrl: './sale-agent-unpaid-popup.component.html',
  styleUrls: ['./sale-agent-unpaid-popup.component.scss'],
})
export class SaleAgentUnpaidPopupComponent implements OnInit {
  constructor(
    private transactionService: TransactionService,
    public dialog: MatDialog,
    private sanitizer: DomSanitizer,
    private toster: ToastrService,
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<SaleAgentUnpaidPopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { data: any }
  ) {
    this.saleAgentBillingDetailId = data;

    // this.getNachaFile();
  }
  d: boolean = false;
  submitted: boolean = false;
  roleType: any;
  // get f() {
  //   return this.eodUnpaidForm.controls;
  // }
  ngOnInit(): void {
    this.createForm();
  }
  nachaFilesDetails: any;
  filename: string = '';

  nachaLink: any;
  saleAgentBillingDetailId: any;
  eodUnpaidForm!: FormGroup;
  createForm() {
    this.eodUnpaidForm = this.fb.group({
      saleAgentBillingId: new FormControl(this.saleAgentBillingDetailId),
      reason: new FormControl(''),
    });
  }

  updateStoreBillingUnpaid() {
    this.transactionService
      .updateSalesAgentUnpaid(this.eodUnpaidForm.value)
      .subscribe(
        (data: any) => {
          if (data.success == false) {
            this.toster.error(data.message);
          }
          if (data.success == true) {
            // this.toster.success(data.message);
            this.toster.success('Unpaid reason post successfully');
          }

          this.dialogRef.close([]);
        },
        (err) => {
          if (err.status == 500) {
            this.toster.error('Internal server error');
          }
          if (err.status == 401) {
            this.toster.error('Resource not found');
          }
        }
      );
  }

  getNachaFile() {
    this.transactionService
      .getViewNacheBySettlementRequestId(this.saleAgentBillingDetailId)
      .subscribe(
        (data: any) => {
          this.nachaFilesDetails = data;
          // console.log(this.nachaFilesDetails, 'nachafile');
          let dataType = data.type;
          let binaryData = [];
          binaryData.push(data);
          let downloadLink = document.createElement('iframe');

          downloadLink.src = window.URL.createObjectURL(
            new Blob(binaryData, { type: dataType })
          );
          this.nachaLink = this.sanitizer.bypassSecurityTrustResourceUrl(
            downloadLink.src
          );
          // console.log(downloadLink, 'download link');
          // if (this.filename) downloadLink.setAttribute('download', this.filename);
          // document.body.appendChild(downloadLink);
          // downloadLink.click();
        },
        (err) => {
          if (err.status == 404) {
            this.toster.error('Resource not found Status:404');
          }
          if (err.status == 500) {
            this.toster.error('Internal server error');
          }
        }
      );
  }
}
