import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaleAgentBillingExcelReportComponent } from './sale-agent-billing-excel-report.component';

describe('SaleAgentBillingExcelReportComponent', () => {
  let component: SaleAgentBillingExcelReportComponent;
  let fixture: ComponentFixture<SaleAgentBillingExcelReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SaleAgentBillingExcelReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SaleAgentBillingExcelReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
