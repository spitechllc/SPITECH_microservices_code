import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { ExcelService } from 'src/app/dashboard/api-service/excel-servive/excel.service';

@Component({
  selector: 'app-sale-agent-billing-excel-report',
  templateUrl: './sale-agent-billing-excel-report.component.html',
  styleUrls: ['./sale-agent-billing-excel-report.component.scss'],
})
export class SaleAgentBillingExcelReportComponent implements OnInit {
  constructor(
    private excelService: ExcelService,
    public dialogRef: MatDialogRef<SaleAgentBillingExcelReportComponent>,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: { data: any }
  ) {
    this.excelData = data;
    // console.log(this.excelData);
  }
  excelData: any;
  siteId: boolean = true;
  storeId: boolean = true;
  storeName: boolean = true;
  saleAgentId: boolean = true;
  createdOn: boolean = true;
  saleAgentName: boolean = true;
  transactionPercentageFee: boolean = true;
  totalFee: boolean = true;
  transactionAmount: boolean = true;
  city: boolean = true;
  state: boolean = true;
  country: boolean = true;
  zipCode: boolean = true;
  ngOnInit(): void {}

  onClickChexBox(event: any) {
    if (event.source.value == 'siteId' && event.checked == false) {
      this.siteId = false;
    } else if (event.source.value == 'siteId' && event.checked == true) {
      this.siteId = true;
    }
    if (event.source.value == 'storeId' && event.checked == false) {
      this.storeId = false;
    } else if (event.source.value == 'storeId' && event.checked == true) {
      this.storeId = true;
    }
    if (event.source.value == 'storeName' && event.checked == false) {
      this.storeName = false;
    } else if (event.source.value == 'storeName' && event.checked == true) {
      this.storeName = true;
    }

    if (event.source.value == 'saleAgentId' && event.checked == false) {
      this.saleAgentId = false;
    } else if (event.source.value == 'saleAgentId' && event.checked == true) {
      this.saleAgentId = true;
    }

    if (event.source.value == 'saleAgentName' && event.checked == false) {
      this.saleAgentName = false;
    } else if (event.source.value == 'saleAgentName' && event.checked == true) {
      this.saleAgentName = true;
    }
    if (
      event.source.value == 'transactionPercentageFee' &&
      event.checked == false
    ) {
      this.transactionPercentageFee = false;
    } else if (
      event.source.value == 'transactionPercentageFee' &&
      event.checked == true
    ) {
      this.transactionPercentageFee = true;
    }
    if (event.source.value == 'totalFee' && event.checked == false) {
      this.totalFee = false;
    } else if (event.source.value == 'totalFee' && event.checked == true) {
      this.totalFee = true;
    }
    if (event.source.value == 'transactionAmount' && event.checked == false) {
      this.transactionAmount = false;
    } else if (
      event.source.value == 'transactionAmount' &&
      event.checked == true
    ) {
      this.transactionAmount = true;
    }
  }
  excelExport() {
    const excelExportData = this.excelData.map((t: any) => {
      const dataObject: any = {};
      if (this.siteId == true) {
        dataObject.siteId = t.siteId;
      }
      if (this.storeId == true) {
        dataObject.storeId = t.storeId;
      }
      if (this.storeName == true) {
        dataObject.storeName = t.storeName;
      }
      if (this.saleAgentId == true) {
        dataObject.saleAgentId = t.saleAgentId;
      }

      if (this.saleAgentName == true) {
        dataObject.saleAgentName = t.saleAgentName;
      }
      if (this.transactionPercentageFee == true) {
        dataObject.transactionPercentageFee = t.transactionPercentageFee;
      }
      if (this.totalFee == true) {
        dataObject.totalFee = t.totalFee;
      }
      if (this.transactionAmount == true) {
        dataObject.transactionAmount = t.transactionAmount;
      }

      return dataObject;
    });

    this.excelService.exportAsExcelFile(
      excelExportData,
      'Saleagent-report-exported-data'
    );
  }
}
