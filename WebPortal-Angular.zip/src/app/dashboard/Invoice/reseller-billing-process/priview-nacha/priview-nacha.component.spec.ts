import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PriviewNachaComponent } from './priview-nacha.component';

describe('PriviewNachaComponent', () => {
  let component: PriviewNachaComponent;
  let fixture: ComponentFixture<PriviewNachaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PriviewNachaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PriviewNachaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
