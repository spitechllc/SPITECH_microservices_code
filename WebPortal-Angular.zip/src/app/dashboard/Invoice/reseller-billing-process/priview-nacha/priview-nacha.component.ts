import { Component, Inject, OnInit } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
import { ToastrService } from 'ngx-toastr';
import { TransactionService } from 'src/app/dashboard/api-service/trasation.service';

@Component({
  selector: 'app-priview-nacha',
  templateUrl: './priview-nacha.component.html',
  styleUrls: ['./priview-nacha.component.scss'],
})
export class PriviewNachaComponent implements OnInit {
  constructor(
    private transactionService: TransactionService,
    public dialog: MatDialog,
    private sanitizer: DomSanitizer,
    private toster: ToastrService,

    public dialogRef: MatDialogRef<PriviewNachaComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { data: any }
  ) {
    // console.log(data, 'date');
    this.Data = data;
    // this.BusinessDate = this.Data.date;
    this.Moth = this.Data.Month;
    this.Year = this.Data.Year;
    this.getNachaFile();
  }
  ngOnInit(): void {}
  nachaFilesDetails: any;
  filename: string = '';
  BusinessDate: any;
  Data: any;
  nachaLink: any;
  Moth: any;
  Year: any;
  nacha: boolean = true;

  getNachaFile() {
    this.transactionService
      .getResellerPreviewNacha(this.Moth, this.Year)
      .subscribe(
        (data: any) => {
          this.nachaFilesDetails = data;
          if (this.nachaFilesDetails == null) {
            this.nacha = false;
          }
          if (this.nachaFilesDetails != null) {
            let dataType = data.type;
            let binaryData = [];
            binaryData.push(data);
            let downloadLink = document.createElement('iframe');

            downloadLink.src = window.URL.createObjectURL(
              new Blob(binaryData, { type: dataType })
            );
            this.nachaLink = this.sanitizer.bypassSecurityTrustResourceUrl(
              downloadLink.src
            );
            // console.log(downloadLink, 'download link');
            // if (this.filename) downloadLink.setAttribute('download', this.filename);
            // document.body.appendChild(downloadLink);
            // downloadLink.click();
          }
        },
        (err) => {
          console.log(err.error);
          if (err.status == 404) {
            this.toster.warning('Already process preview nacha');
          }
          if (err.error.errors.SaleAgentConfig) {
            err.error.errors.SaleAgentConfig.forEach((err: any) => {
              return this.toster.error(err);
            });
          }
        }
      );
  }
}
