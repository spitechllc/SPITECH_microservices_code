import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { ExcelService } from 'src/app/dashboard/api-service/excel-servive/excel.service';

@Component({
  selector: 'app-reseller-billing-process-excel-report',
  templateUrl: './reseller-billing-process-excel-report.component.html',
  styleUrls: ['./reseller-billing-process-excel-report.component.scss'],
})
export class ResellerBillingProcessExcelReportComponent implements OnInit {
  constructor(
    private excelService: ExcelService,
    public dialogRef: MatDialogRef<ResellerBillingProcessExcelReportComponent>,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: { data: any }
  ) {
    this.excelData = data;
    // console.log(this.excelData);
  }
  excelData: any;
  resellerBillingId: boolean = true;
  resellerId: boolean = true;
  resellerName: boolean = true;
  transactionCount: boolean = true;
  createdOn: boolean = true;
  achTransactionAmount: boolean = true;
  cardTransactionAmount: boolean = true;
  achProcessingFee: boolean = true;
  cashRewardTransactionAmount: boolean = true;
  achTransactionFee: boolean = true;
  cardTransactionFee: boolean = true;
  cashRewardTransactionFee: boolean = true;
  totalFee: boolean = true;
  ngOnInit(): void {}

  onClickChexBox(event: any) {
    if (event.source.value == 'resellerBillingId' && event.checked == false) {
      this.resellerBillingId = false;
    } else if (
      event.source.value == 'resellerBillingId' &&
      event.checked == true
    ) {
      this.resellerBillingId = true;
    }
    if (event.source.value == 'resellerId' && event.checked == false) {
      this.resellerId = false;
    } else if (event.source.value == 'resellerId' && event.checked == true) {
      this.resellerId = true;
    }
    if (event.source.value == 'resellerName' && event.checked == false) {
      this.resellerName = false;
    } else if (event.source.value == 'resellerName' && event.checked == true) {
      this.resellerName = true;
    }

    if (event.source.value == 'transactionCount' && event.checked == false) {
      this.transactionCount = false;
    } else if (
      event.source.value == 'transactionCount' &&
      event.checked == true
    ) {
      this.transactionCount = true;
    }

    if (
      event.source.value == 'achTransactionAmount' &&
      event.checked == false
    ) {
      this.achTransactionAmount = false;
    } else if (
      event.source.value == 'achTransactionAmount' &&
      event.checked == true
    ) {
      this.achTransactionAmount = true;
    }
    if (
      event.source.value == 'cardTransactionAmount' &&
      event.checked == false
    ) {
      this.cardTransactionAmount = false;
    } else if (
      event.source.value == 'cardTransactionAmount' &&
      event.checked == true
    ) {
      this.cardTransactionAmount = true;
    }
    if (event.source.value == 'achProcessingFee' && event.checked == false) {
      this.achProcessingFee = false;
    } else if (
      event.source.value == 'achProcessingFee' &&
      event.checked == true
    ) {
      this.achProcessingFee = true;
    }
    if (
      event.source.value == 'cashRewardTransactionAmount' &&
      event.checked == false
    ) {
      this.cashRewardTransactionAmount = false;
    } else if (
      event.source.value == 'cashRewardTransactionAmount' &&
      event.checked == true
    ) {
      this.cashRewardTransactionAmount = true;
    }
    if (event.source.value == 'achTransactionFee' && event.checked == false) {
      this.achTransactionFee = false;
    } else if (
      event.source.value == 'achTransactionFee' &&
      event.checked == true
    ) {
      this.achTransactionFee = true;
    }
    if (event.source.value == 'cardTransactionFee' && event.checked == false) {
      this.cardTransactionFee = false;
    } else if (
      event.source.value == 'cardTransactionFee' &&
      event.checked == true
    ) {
      this.cardTransactionFee = true;
    }
    if (
      event.source.value == 'cashRewardTransactionFee' &&
      event.checked == false
    ) {
      this.cashRewardTransactionFee = false;
    } else if (
      event.source.value == 'cashRewardTransactionFee' &&
      event.checked == true
    ) {
      this.cashRewardTransactionFee = true;
    }
    if (event.source.value == 'totalFee' && event.checked == false) {
      this.totalFee = false;
    } else if (event.source.value == 'totalFee' && event.checked == true) {
      this.totalFee = true;
    }
  }
  excelExport() {
    const excelExportData = this.excelData.map((t: any) => {
      const dataObject: any = {};
      if (this.resellerBillingId == true) {
        dataObject.resellerBillingId = t.resellerBillingId;
      }
      if (this.resellerId == true) {
        dataObject.resellerId = t.resellerId;
      }
      if (this.resellerName == true) {
        dataObject.resellerName = t.resellerName;
      }
      if (this.transactionCount == true) {
        dataObject.transactionCount = t.transactionCount;
      }

      if (this.achTransactionAmount == true) {
        dataObject.achTransactionAmount = t.achTransactionAmount;
      }
      if (this.cardTransactionAmount == true) {
        dataObject.cardTransactionAmount = t.cardTransactionAmount;
      }
      if (this.achProcessingFee == true) {
        dataObject.achProcessingFee = t.achProcessingFee;
      }
      if (this.cashRewardTransactionAmount == true) {
        dataObject.cashRewardTransactionAmount = t.cashRewardTransactionAmount;
      }
      if (this.achTransactionFee == true) {
        dataObject.achTransactionFee = t.achTransactionFee;
      }
      if (this.cardTransactionFee == true) {
        dataObject.cardTransactionFee = t.cardTransactionFee;
      }
      if (this.cashRewardTransactionFee == true) {
        dataObject.cashRewardTransactionFee = t.cashRewardTransactionFee;
      }
      if (this.totalFee == true) {
        dataObject.totalFee = t.totalFee;
      }

      return dataObject;
    });

    this.excelService.exportAsExcelFile(
      excelExportData,
      'Reseller-billing-report-exported-data'
    );
  }
}
