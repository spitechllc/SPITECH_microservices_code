import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ResellerBillingProcessComponent } from './reseller-billing-process.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from 'src/app/shared.module';
import { MatInputModule } from '@angular/material/input';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ViewNachaComponent } from './view-nacha/view-nacha.component';
import { ViewPdfComponent } from './view-pdf/view-pdf.component';
import { ResellerUnpaidPopupComponent } from './reseller-unpaid-popup/reseller-unpaid-popup.component';
import { PriviewNachaComponent } from './priview-nacha/priview-nacha.component';
import { ResellerBillingProcessExcelReportComponent } from './reseller-billing-process-excel-report/reseller-billing-process-excel-report.component';
export const router: Routes = [
  {
    path: '',
    component: ResellerBillingProcessComponent,
  },
];

@NgModule({
  declarations: [ResellerBillingProcessComponent, ViewNachaComponent, ViewPdfComponent, ResellerUnpaidPopupComponent, PriviewNachaComponent, ResellerBillingProcessExcelReportComponent],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatAutocompleteModule,
    // NgMultiSelectDropDownModule.forRoot(),
    RouterModule.forChild(router),
  ],
})
export class ResellerBillingProcessModule {}
