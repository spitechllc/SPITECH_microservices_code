import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResellerBillingProcessComponent } from './reseller-billing-process.component';

describe('ResellerBillingProcessComponent', () => {
  let component: ResellerBillingProcessComponent;
  let fixture: ComponentFixture<ResellerBillingProcessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResellerBillingProcessComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResellerBillingProcessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
