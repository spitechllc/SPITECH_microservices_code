import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
import { ToastrService } from 'ngx-toastr';
import { TransactionService } from 'src/app/dashboard/api-service/trasation.service';

@Component({
  selector: 'app-view-nacha',
  templateUrl: './view-nacha.component.html',
  styleUrls: ['./view-nacha.component.scss'],
})
export class ViewNachaComponent implements OnInit {
  constructor(
    private transactionService: TransactionService,
    public dialog: MatDialog,
    private sanitizer: DomSanitizer,
    private toster: ToastrService,
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<ViewNachaComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { data: any }
  ) {
    this.resellerBillingId = data;

    this.getNachaFile();
  }
  d: boolean = false;
  submitted: boolean = false;
  roleType: any;

  ngOnInit(): void {}
  nachaFilesDetails: any;
  filename: string = '';

  nachaLink: any;
  resellerBillingId: any;
  nacha: boolean = true;
  getNachaFile() {
    this.transactionService
      .getResellerViewNacha(this.resellerBillingId)
      .subscribe(
        (data: any) => {
          this.nachaFilesDetails = data;
          if (this.nachaFilesDetails == null) {
            this.nacha = false;
          }
          if (this.nachaFilesDetails != null) {
            let dataType = data.type;
            let binaryData = [];
            binaryData.push(data);
            let downloadLink = document.createElement('iframe');

            downloadLink.src = window.URL.createObjectURL(
              new Blob(binaryData, { type: dataType })
            );
            this.nachaLink = this.sanitizer.bypassSecurityTrustResourceUrl(
              downloadLink.src
            );
          }
        },
        (err) => {
          if (err.status == 404) {
            this.toster.error('Nacha not found ');
          }
          if (err.status == 500) {
            this.toster.error('Internal server error');
          }
        }
      );
  }
}
