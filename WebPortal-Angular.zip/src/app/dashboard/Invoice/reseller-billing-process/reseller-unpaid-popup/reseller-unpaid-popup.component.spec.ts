import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResellerUnpaidPopupComponent } from './reseller-unpaid-popup.component';

describe('ResellerUnpaidPopupComponent', () => {
  let component: ResellerUnpaidPopupComponent;
  let fixture: ComponentFixture<ResellerUnpaidPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResellerUnpaidPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResellerUnpaidPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
