import { Component, Inject, OnInit } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { TransactionService } from 'src/app/dashboard/api-service/trasation.service';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
@Component({
  selector: 'app-view-pdf',
  templateUrl: './view-pdf.component.html',
  styleUrls: ['./view-pdf.component.scss'],
})
export class ViewPdfComponent implements OnInit {
  constructor(
    private transactionService: TransactionService,
    public dialog: MatDialog,
    private sanitizer: DomSanitizer,
    private toster: ToastrService,
    private fb: FormBuilder,

    public dialogRef: MatDialogRef<ViewPdfComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { data: any }
  ) {
    // console.log(data, 'date');
    this.resellerData = data;
    // console.log(data);
    if (this.resellerData[1] == 'pdf') {
      this.resellerPdf();
    }
    if (this.resellerData[1] == 'monthlypdf') {
      this.resellerMonthlypdf();
    }
  }
  resellerData: any;
  ngOnInit(): void {}

  pdfLink: any;
  nachaFilesDetails: any;
  resellerPdf() {
    this.transactionService.getResellerPdf(this.resellerData[0]).subscribe(
      (data: any) => {
        this.nachaFilesDetails = data;
        // console.log(this.nachaFilesDetails, 'nachafile');
        let dataType = data.type;
        let binaryData = [];
        binaryData.push(data);
        let downloadLink = document.createElement('iframe');
        var downloadURL = window.URL.createObjectURL(data);
        var link = document.createElement('a');
        // link.href = downloadURL;
        // link.download = 'saleAgent_billing.pdf';
        // link.click();
        downloadLink.src = window.URL.createObjectURL(
          new Blob(binaryData, { type: dataType })
        );
        this.pdfLink = this.sanitizer.bypassSecurityTrustResourceUrl(
          downloadLink.src
        );
      },
      (err) => {}
    );
  }

  resellerMonthlypdf() {
    this.transactionService
      .getResellerMonthlyInvoicePdf(
        this.resellerData[2],
        this.resellerData[3],
        this.resellerData[4],
        this.resellerData[5]
      )
      .subscribe(
        (data: any) => {
          this.nachaFilesDetails = data;
          // console.log(this.nachaFilesDetails, 'nachafile');
          let dataType = data.type;
          let binaryData = [];
          binaryData.push(data);
          let downloadLink = document.createElement('iframe');
          var downloadURL = window.URL.createObjectURL(data);
          var link = document.createElement('a');
          // link.href = downloadURL;
          // link.download = 'allSaleAgentMonthlybilling.pdf';
          // link.click();
          downloadLink.src = window.URL.createObjectURL(
            new Blob(binaryData, { type: dataType })
          );
          this.pdfLink = this.sanitizer.bypassSecurityTrustResourceUrl(
            downloadLink.src
          );
        },
        (err) => {}
      );
  }
}
