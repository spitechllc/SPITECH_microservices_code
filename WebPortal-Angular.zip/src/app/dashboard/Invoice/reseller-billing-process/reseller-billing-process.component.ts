import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { debounce } from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ExcelService } from '../../api-service/excel-servive/excel.service';
import { StoreService } from '../../api-service/storeService';
import { TransactionService } from '../../api-service/trasation.service';
import { AuthService } from '../../auth/auth.service';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { DomSanitizer } from '@angular/platform-browser';
import { ViewNachaComponent } from './view-nacha/view-nacha.component';
import { ResellerUnpaidPopupComponent } from './reseller-unpaid-popup/reseller-unpaid-popup.component';
import { PriviewNachaComponent } from './priview-nacha/priview-nacha.component';
import { ViewPdfComponent } from './view-pdf/view-pdf.component';
import { SharedService } from '../../auth/shared.service';
import { ResellerBillingProcessExcelReportComponent } from './reseller-billing-process-excel-report/reseller-billing-process-excel-report.component';
@Component({
  selector: 'app-reseller-billing-process',
  templateUrl: './reseller-billing-process.component.html',
  styleUrls: ['./reseller-billing-process.component.scss'],
})
export class ResellerBillingProcessComponent implements OnInit {
  displayedColumns = [
    'resellerBillingId',
    'resellerId',
    'resellerName',
    'defineCoreProcessingName',
    'transactionCount',
    'transactionAmount',
    'achTransactionAmount',
    'cardTransactionAmount',
    'defineACHProcessingFee',
    'defineACHTransactionFee',
    'defineCardTransactionFee',
    'defineCashRewardTransactionFee',
    'defineMonthlySaasFee',
    'achProcessingFee',
    'cashRewardTransactionAmount',
    'cardTransactionFee',
    'cashRewardTransactionFee',
    'achTransactionFee',
    'totalFee',
    'isPaid',
    'viewNacha',
    'PreviewPdf',
    'action',
  ];
  dataSource = new MatTableDataSource<StoreTable>([]);
  stores: any = [];
  PageIndex = 1;
  PageSize = 50;
  GenerateBy: number = 0;
  dropdownList: any = [];
  selectedItems: any = [];
  selectedValue: any;
  searchTxt: any;
  totalCount: any;
  items: any;
  monthlyBillingForm!: FormGroup;
  geneareteForm!: FormGroup;
  err: string = '';
  checked: boolean = false;
  storeBillingDetails: any = [];
  length: any;
  checkbox = false;
  generateBy: any;
  get roleIds() {
    return this.monthlyBillingForm.get('siteIds') as FormArray;
  }
  claimIdArray: any;
  searchEvent: any;
  fiterSiteId: any;
  lengthsite: any;
  dataNotFond: string = 'Data not found';
  SiteId: any;
  BusinessDate = '';
  StoreId: number = 0;
  IsNeedReview: boolean = false;
  AmountMatched: boolean = false;
  reportDetail: any;
  site: any;
  pageLength: any;
  siteNumber: any = null;
  Month: number = 0;
  Year: number = 0;
  sortBy: string = '';
  sortOrder: string = '';
  gMonth: number = 0;
  gYear: number = 0;
  submitted: boolean = false;
  gsubmitted: boolean = false;
  salesAgentData: any = [];
  get f() {
    return this.monthlyBillingForm.controls;
  }
  get gf() {
    return this.geneareteForm.controls;
  }
  constructor(
    private storeService: StoreService,
    private transactionService: TransactionService,
    private toster: ToastrService,
    private spinner: NgxSpinnerService,
    public dialog: MatDialog,
    private sanitizer: DomSanitizer,
    private fb: FormBuilder,
    private auth: AuthService,
    private router: Router,
    private excelService: ExcelService,
    private sharedService: SharedService
  ) {}
  ngOnInit(): void {
    const claim = this.auth.getClaims();
    this.claimIdArray = claim;
    this.createForm();

    if (history.state.Back == 'back') {
      this.monthlyBillingForm.patchValue({
        month: history.state.Month,
        year: history.state.Year,
      });
      this.Month = history.state.Month;
      this.Year = history.state.Year;
      this.StoreId = history.state.StoreId;
      this.PageIndex = history.state.PageIndex;
      this.PageSize = history.state.PageSize;
      this.IsNeedReview = history.state.IsNeedReview;
      this.IsPaid = history.state.IsPaid;
      this.monthlyBilling();
    }
  }

  checkPermission(claimId: string) {
    return this.claimIdArray.includes(claimId);
  }
  exportAsExcel() {
    this.submitted = true;
    if (this.monthlyBillingForm.invalid) {
      return;
    }

    var pageSize = 0;
    var pageIndex = 0;
    var IsNeedReview = null;

    var IsPaid = null;

    if (this.monthlyBillingForm.get('IsNeedReview')?.value == '1') {
      IsNeedReview = true;
    } else if (this.monthlyBillingForm.get('IsNeedReview')?.value == '0') {
      IsNeedReview = false;
    }

    if (this.monthlyBillingForm.get('IsPaid')?.value == '1') {
      IsPaid = true;
    } else if (this.monthlyBillingForm.get('IsPaid')?.value == '0') {
      IsPaid = false;
    }
    this.transactionService
      .getResellerBillingProcess(
        pageSize,
        pageSize,
        IsNeedReview,
        IsPaid,
        this.Month,
        this.Year,
        this.sortBy,
        this.sortOrder
      )
      .subscribe((data: any) => {
        this.salesAgentData = data.data;
        if (this.salesAgentData.length > 0) {
          const dialogRef = this.dialog.open(
            ResellerBillingProcessExcelReportComponent,
            {
              width: '450px',
              panelClass: 'popup',
              data: this.salesAgentData,
            }
          );
          // this.excelService.exportAsExcelFile(
          //   this.salesAgentData.map((t: any) => {
          //     return {
          //       resellerBillingId: t.resellerBillingId,
          //       resellerId: t.resellerId,
          //       resellerName: t.resellerName,
          //       defineCoreProcessingName: t.defineCoreProcessingName,
          //       transactionCount: t.transactionCount,
          //       achTransactionAmount: t.achTransactionAmount,
          //       cardTransactionAmount: t.cardTransactionAmount,
          //       defineACHProcessingFee: t.defineACHProcessingFee,
          //       defineCardTransactionFee: t.defineCardTransactionFee,
          //       defineCashRewardTransactionFee:
          //         t.defineCashRewardTransactionFee,
          //       defineMonthlySaasFee: t.defineMonthlySaasFee,
          //       achProcessingFee: t.achProcessingFee,
          //       cashRewardTransactionAmount: t.cashRewardTransactionAmount,
          //       achTransactionFee: t.achTransactionFee,
          //       cardTransactionFee: t.cardTransactionFee,
          //       cashRewardTransactionFee: t.cashRewardTransactionFee,
          //       totalFee: t.totalFee,
          //     };
          //   }),
          //   'Reseller-excel'
          // );
        } else {
          this.toster.error('Data not found');
        }
      });
  }
  createForm() {
    this.monthlyBillingForm = this.fb.group({
      month: new FormControl('', Validators.required),
      year: new FormControl('', Validators.required),
      IsNeedReview: new FormControl(''),
      IsPaid: new FormControl(''),
    });
    this.geneareteForm = this.fb.group({
      gmonth: new FormControl('', Validators.required),
      gyear: new FormControl('', Validators.required),
    });
  }
  onSelectgMonth(month: any) {
    this.gMonth = month.value;
  }
  onSelectgYear(year: any) {
    this.gYear = year.value;
  }
  onSelectMonth(month: any) {
    this.Month = month.value;
  }
  onSelectYear(year: any) {
    this.Year = year.value;
  }

  needReview: any;
  paid: any;
  IsStoreNeedReview: any;
  IsSaleAgentNeedReview: any;
  IsPaid: any;

  resellerData: any;

  onHeaderSortChange(event: any) {
    this.sortBy = event.active;
    if (event.direction == '') {
      this.sortOrder = 'asc';
    } else {
      this.sortOrder = event.direction;
    }

    this.monthlyBilling();
  }

  monthlyBilling() {
    this.submitted = true;
    if (this.monthlyBillingForm.invalid) {
      return;
    }
    this.spinner.show();
    var IsNeedReview = null;
    var IsPaid = null;
    if (this.monthlyBillingForm.get('IsNeedReview')?.value == '1') {
      IsNeedReview = true;
    } else if (this.monthlyBillingForm.get('IsNeedReview')?.value == '0') {
      IsNeedReview = false;
    }

    if (this.monthlyBillingForm.get('IsPaid')?.value == '1') {
      IsPaid = true;
    } else if (this.monthlyBillingForm.get('IsPaid')?.value == '0') {
      IsPaid = false;
    }

    this.transactionService
      .getResellerBillingProcess(
        this.PageIndex,
        this.PageSize,
        IsNeedReview,
        IsPaid,
        this.Month,
        this.Year,
        this.sortBy,
        this.sortOrder
      )
      .subscribe(
        (data: any) => {
          this.resellerData = data;
          this.storeBillingDetails = data.data;
          this.length = this.storeBillingDetails.length;
          if (this.length == 0) {
            this.spinner.hide();
          }

          this.storeBillingDetails.forEach((element: any) => {
            this.dataSource = new MatTableDataSource(data.data);
            this.totalCount = data.totalCount;
            this.spinner.hide();
          });
        },
        (err: any) => {
          if (err.status == 400) {
            this.toster.error('Bad request ');
          }

          if (err.error.errors.Year) {
            err.error.errors.Year.forEach((err: any) => {
              this.toster.error(err);
            });
          }
          if (err.error.errors.Month) {
            err.error.errors.Month.forEach((err: any) => {
              this.toster.error(err);
            });
          }
        }
      );
  }

  generateBill() {
    this.gsubmitted = true;
    if (this.geneareteForm.invalid) {
      return;
    }
    this.transactionService
      .generateResellerBillingProcess({
        Month: this.gMonth,
        Year: this.gYear,
      })
      .subscribe(
        (data: any) => {
          if (data.success == true) {
            this.toster.success('Bill generate successfully');
          }
          if (data.success == false && data.message == null) {
            this.toster.error('Bill is not generate for this month');
          } else if (data.success == false && data.message) {
            this.toster.error(data.message);
          }
        },
        (err) => {
          if (err.status == 401) {
            this.toster.error('Reasource not found ');
          }
          if (err.error.errors.Year) {
            err.error.errors.Year.forEach((err: any) => {
              this.toster.error(err);
            });
          }
          if (err.error.errors.Month) {
            err.error.errors.Month.forEach((err: any) => {
              this.toster.error(err);
            });
          }
          if (err.error.errors.ResellerFee) {
            err.error.errors.ResellerFee.forEach((err: any) => {
              this.toster.error(err);
            });
          }
        }
      );
  }
  UpdateReview(resellerBillingId: any) {
    if (
      !this.claimIdArray.includes(
        'ProcessesMenu_ResellerMonthlyBilling_ReviewUnreview'
      )
    ) {
      this.toster.error('You are not authorized');
      return;
    }
    this.transactionService
      .updateResellerNeedReview({
        resellerBillingIds: [resellerBillingId[0]],
        isNeedReview: resellerBillingId[1] == false ? true : false,
      })
      .subscribe(
        (data: any) => {
          if (data.success == true) {
            this.toster.success('Update need review');
          }
          if (data.success == false) {
            this.toster.error(data.message);
          }
          this.monthlyBilling();
        },
        (err) => {
          if (err.status == 400) {
            this.toster.error('Bad request ');
          }
          if (err.status == 401) {
            this.toster.error('Reasource not found ');
          }
        }
      );
  }

  processPayment() {
    this.transactionService
      .resellerBillingPaymentProcess({ Month: this.Month, Year: this.Year })
      .subscribe((data: any) => {
        if (data.success == true) {
          this.toster.success('Process Payment successfully');
          this.monthlyBilling();
        }
        if (data.success == false) {
          this.toster.warning(data.message);
          this.monthlyBilling();
        }
      });
  }
  PreviewNachaPopup() {
    const dialogRef = this.dialog.open(PriviewNachaComponent, {
      width: '400px',

      panelClass: 'popup',
      data: { Month: this.Month, Year: this.Year },
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.monthlyBilling();
    });
  }
  ViewNacha(resellerBillingId: number) {
    if (
      !this.claimIdArray.includes(
        'ProcessesMenu_ResellerMonthlyBilling_ViewNacha'
      )
    ) {
      this.toster.error('You are not authorized');
      return;
    }
    const dialogRef = this.dialog.open(ViewNachaComponent, {
      width: '400px',
      panelClass: 'popup',
      data: resellerBillingId,
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.monthlyBilling();
    });
  }

  unpaidPopup(resellerBillingId: number) {
    const dialogRef = this.dialog.open(ResellerUnpaidPopupComponent, {
      width: '400px',
      panelClass: 'popup',
      data: resellerBillingId,
    });
    dialogRef.afterClosed().subscribe((data: any) => {
      this.monthlyBilling();
    });
  }

  pdfLink: any;
  // saleAjentpdf(saleAgentBillingDetailId: any) {
  //   this.spinner.show();
  //   this.transactionService
  //     .saleAgentMonthlyInvoicePdf(saleAgentBillingDetailId)
  //     .subscribe(
  //       (data: any) => {
  //         // this.nachaFilesDetails = data;
  //         // console.log(this.nachaFilesDetails, 'nachafile');
  //         let dataType = data.type;
  //         let binaryData = [];
  //         binaryData.push(data);
  //         let downloadLink = document.createElement('iframe');
  //         var downloadURL = window.URL.createObjectURL(data);
  //         var link = document.createElement('a');
  //         link.href = downloadURL;
  //         link.download = 'saleAgent_billing.pdf';
  //         link.click();
  //         downloadLink.src = window.URL.createObjectURL(
  //           new Blob(binaryData, { type: dataType })
  //         );
  //         this.pdfLink = this.sanitizer.bypassSecurityTrustResourceUrl(
  //           downloadLink.src
  //         );
  //         this.spinner.hide();
  //       },
  //       (err) => {}
  //     );
  // }

  // saleAjentMonthlypdf() {
  //   this.spinner.show();
  //   this.transactionService
  //     .getAllSaleAgentMonthlyInvoicePdf(
  //       this.StoreId,
  //       this.IsStoreNeedReview,
  //       this.IsSaleAgentNeedReview,
  //       this.IsPaid,
  //       this.Month,
  //       this.Year
  //     )
  //     .subscribe(
  //       (data: any) => {
  //         // this.nachaFilesDetails = data;
  //         // console.log(this.nachaFilesDetails, 'nachafile');
  //         let dataType = data.type;
  //         let binaryData = [];
  //         binaryData.push(data);
  //         let downloadLink = document.createElement('iframe');
  //         var downloadURL = window.URL.createObjectURL(data);
  //         var link = document.createElement('a');
  //         link.href = downloadURL;
  //         link.download = 'saleAgent_billing.pdf';
  //         link.click();
  //         downloadLink.src = window.URL.createObjectURL(
  //           new Blob(binaryData, { type: dataType })
  //         );
  //         this.pdfLink = this.sanitizer.bypassSecurityTrustResourceUrl(
  //           downloadLink.src
  //         );
  //         this.spinner.hide();
  //       },
  //       (err) => {}
  //     );
  // }

  getMonthlyBillingPdf() {
    var IsNeedReview = null;
    var IsPaid = null;
    if (this.monthlyBillingForm.get('IsNeedReview')?.value == '1') {
      IsNeedReview = true;
    } else if (this.monthlyBillingForm.get('IsNeedReview')?.value == '0') {
      IsNeedReview = false;
    }

    if (this.monthlyBillingForm.get('IsPaid')?.value == '1') {
      IsPaid = true;
    } else if (this.monthlyBillingForm.get('IsPaid')?.value == '0') {
      IsPaid = false;
    }

    const dialogRef = this.dialog.open(ViewPdfComponent, {
      panelClass: 'popup',
      data: [1, 'monthlypdf', IsNeedReview, IsPaid, this.Month, this.Year],
    });
  }
  getStoreBillingPdf(resellerBillingId: number) {
    if (
      !this.claimIdArray.includes(
        'ProcessesMenu_ResellerMonthlyBilling_ViewPdf'
      )
    ) {
      this.toster.error('You are not authorized');
      return;
    }
    const dialogRef = this.dialog.open(ViewPdfComponent, {
      panelClass: 'popup',
      data: [resellerBillingId, 'pdf'],
    });
  }
}

export interface StoreTable {
  billGenerateDate: string;
  siteId: string;
  storeId: string;

  monthlySaasFee: number;
  transactionFee: number;
  transactionPercentageFee: number;
  transactionCount: number;
  transactionAmount: number;
  totalFee: number;
  isProcessed: boolean;
}
