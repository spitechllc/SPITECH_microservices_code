import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, throwIfEmpty } from 'rxjs/operators';
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { environment } from 'src/environments/environment';

@Injectable()
export class IdentityService {
  baseUrl: string = `${environment.identity_url}api/AccountUser/`;

  constructor(
    private http: HttpClient,
    private oidcSecurityService: OidcSecurityService
  ) {}

  // get all consumer list

  getAllConsumer(
    userId: number,
    firstName: string,
    lastName: string,
    email: string,
    mobile: string,
    Locked: boolean,
    pageIndex: number,
    pageSize: number,
    sortOrder: string,
    sortBy: string
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }GetAllUserWithPaging?UserId=${userId}&FirstName=${firstName}&LastName=${lastName}&Email=${email}&Mobile=${mobile}&Locked=${
        Locked == null ? '' : Locked
      }&PageIndex=${pageIndex}&PageSize=${pageSize}&SortOrder=${sortOrder}&SortBy=${sortBy}`
    );
  }
  getAllConsumerr(
    userId: number,
    firstName: string,
    lastName: string,
    email: string,
    mobile: string,
    Locked: boolean,
    pageIndex: number,
    pageSize: number,
    sortOrder: string,
    sortBy: string,
    tenantId: number[]
  ) {
    let params = new HttpParams();
    params = params.append('AppName', 'SpiTech');
    tenantId.forEach((tenantId) => {
      params = params.append('TenantId', tenantId.toString());
    });
    return this.http.get(
      `${
        this.baseUrl
      }GetAllUserWithPaging?UserId=${userId}&FirstName=${firstName}&LastName=${lastName}&Email=${email}&Mobile=${mobile}&Locked=${
        Locked == null ? '' : Locked
      }&PageIndex=${pageIndex}&PageSize=${pageSize}&SortOrder=${sortOrder}&SortBy=${sortBy}&${params}`
    );
  }
  getConsumerById(userId: null) {
    return this.http.get(`${this.baseUrl}GetUserById?UserId=${userId}`);
  }
  getTenantMasterList() {
    return this.http.get(`${this.baseUrl}GetTenantMasterList`);
  }
  updateConsumerProfile(value: any) {
    return this.http.post(`${this.baseUrl}UpdateProfileUsingPortal`, value);
  }

  // create Role
  createRole(value: any) {
    return this.http.post(this.baseUrl + 'Role', value);
  }
  // get role type
  getRoleType() {
    return this.http.get(this.baseUrl + 'RoleType');
  }

  getuserdetails() {
    return this.http.get(this.baseUrl + 'GetUserFromtoken');
  }

  // get roles
  getRoles() {
    return this.http.get(this.baseUrl + 'Roles');
  }
  // get claims data
  getClaims() {
    return this.http.get(`${this.baseUrl}Claims`);
  }
  // update claims
  updateClaimsMap(value: any) {
    return this.http.post(`${this.baseUrl}MapRoleClaim`, value);
  }
  // get role by Id
  getRoleById(RoleId: any) {
    return this.http.get(this.baseUrl + 'GetRoleById/' + RoleId);
  }
  //update user profile
  updateProfie(value: any) {
    return this.http.post(this.baseUrl + 'UpdateProfile', value);
  }
  // update role
  updateRole(value: any) {
    return this.http.patch(this.baseUrl + 'Role', value);
  }
  // change password
  changePassword(value: any) {
    return this.http.post(this.baseUrl + 'ChangePassword', value);
  }

  getConsumerCase(userId: any) {
    return this.http.get(`${this.baseUrl}ConsumerCase?UserId=${userId}`);
  }
  getMerchentCase(userId: any) {
    return this.http.get(`${this.baseUrl}MerchantCase?UserId=${userId}`);
  }
  getSearchEmailPhone(EmailorPhone: any) {
    return this.http.get(
      `${this.baseUrl}GetUserByEmailOrPhone?EmailorPhone=${EmailorPhone}`
    );
  }
  updateBusinessUser(value: any) {
    return this.http.post(`${this.baseUrl}UpdateConsumerToBusiness`, value);
  }

  copyRoles(value: any) {
    return this.http.post(`${this.baseUrl}CopyRoleClaim`, value);
  }

  getAllActiveUsers(
    userId: number,
    firstName: string,
    lastName: string,
    pageIndex: number,
    pageSize: number,
    sortBy: string,
    sortOrder: string
  ) {
    return this.http.get(
      `${this.baseUrl}ActivePortalUsers?UserId=${userId}&FirstName=${firstName}&LastName=${lastName}&PageIndex=${pageIndex}&PageSize=${pageSize}&SortBy=${sortBy}&SortOrder=${sortOrder}`
    );
  }
  lockUnlock(value: any) {
    return this.http.post(`${this.baseUrl}UnlockUser`, value);
  }

  forcelogout(value: any) {
    return this.http.post(`${this.baseUrl}Logout`, value);
  }

  getTantetId() {
    return this.http.get(`${environment.identity_url}api/Tenant`);
  }
  GetMopUser() {
    return this.http.get(
      `${this.baseUrl}GetAllUserWithMOP??PageIndex=1&PageSize=300`
    );
  }
  private handleErrors(response: any) {
    // alert(response.message);
    return throwError({ response });
  }
}
