import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
@Injectable()
export class NoficationService {
  baseUrl: string = `${environment.base_url}notifications/api/`;
  constructor(private http: HttpClient) {}

  getNotification(
    pageIndex: any,
    pageSize: any,
    sortBy: string,
    sortOrder: string
  ) {
    return this.http.get(
      `${this.baseUrl}Notifications/GetAppNotification?PageIndex=${pageIndex}&PageSize=${pageSize}&sortable.SortBy=${sortBy}&sortable.SortOrder=${sortOrder}`
    );
  }

  sendNotification(value: any) {
    return this.http.post(
      `${this.baseUrl}Notifications/SendOfferNotification`,
      value
    );
  }
  sendEmailMeassage(value: any) {
    return this.http.post(
      `${this.baseUrl}Notifications/EmailNotification`,
      value
    );
  }

  getNotificationType() {
    return this.http.get(`${this.baseUrl}Notifications/GetNotificationType`);
  }

  updateNotificationType(value: any) {
    return this.http.post(
      `${this.baseUrl}Notifications/UpdateNotificationType`,
      value
    );
  }
  getActivity(
    userId: number,
    StartDateUtc: string,
    EndDateUtc: string,
    PageIndex: number,
    PageSize: number,
    SortBy: string,
    SortOrder: string,
    TenantId: number
  ) {
    return this.http.get(
      `${this.baseUrl}Activity?UserId=${
        userId == 0 ? '' : userId
      }&StartDateUtc=${StartDateUtc == '' ? null : StartDateUtc}&EndDateUtc=${
        EndDateUtc == '' ? null : EndDateUtc
      }&PageIndex=${PageIndex == 0 ? '' : PageIndex}&PageSize=${
        PageSize == 0 ? '' : PageSize
      }&SortBy=${SortBy}&SortOrder=${SortOrder}&TenantId=${TenantId}`
    );
  }
}
