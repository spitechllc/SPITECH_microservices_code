import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
  HttpParams,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, throwIfEmpty } from 'rxjs/operators';
import { OidcSecurityService } from 'angular-auth-oidc-client';
// import { Store }  from '../../dashboard/Models/store';
import { PeriodicElement } from '../admin/user/role-tab/role-tab.component';
import { environment } from 'src/environments/environment';
// import { HubConnection, HubConnectionBuilder } from '@ssv/signalr-client';

@Injectable()
export class TransactionService {
  baseUrl: string = `${environment.base_url}transactions/api/`;
  constructor(private http: HttpClient) {}

  // get payment method
  getTranstionHistoryMethod() {
    const userId = localStorage.getItem('userId');
    return this.http.get(this.baseUrl + 'Transaction?UserId=' + userId);
  }
  checkBalance(body: {}) {
    return this.http.post(
      `${this.baseUrl}SettlementInvoice/CheckBalance`,
      body
    );
  }

  // get transation recept
  getTransactionReceipt(TransactionId: number) {
    return this.http.get(
      `${this.baseUrl}Transaction/Receipt?TransactionId=` + TransactionId
    );
  }

  //store billing generate
  storeBillingGenerate(value: any) {
    return this.http.post(`${this.baseUrl}StoreBilling/Generate`, value);
  }

  // TransactionDetails of Eod report
  transactionDetailsBySettlementRequestId(SettlementRequestId: number) {
    return this.http.get(
      `${this.baseUrl}SettlementInvoice/DetailsBySettlementRequestId?SettlementRequestId=${SettlementRequestId}`
    );
  }
  //  TransactionDetails of store billing
  transactionDetailsByStoreBillingId(storeBillingId: number) {
    return this.http.get(
      `${this.baseUrl}Transaction/DetailsByStoreBillingId?StoreBillingId=${storeBillingId}`
    );
  }
  getTransactionCount(SiteId: any) {
    return this.http.get(
      `${this.baseUrl}Transaction/TransactionCount?SiteId=${SiteId}`
    );
  }

  // get daly transaction details
  getDailyTransactuion(siteId: string, TransactionDate: any) {
    return this.http.get(
      `${this.baseUrl}Transaction/DailyTransactionBySiteId?siteId=${siteId}&TransactionDate=${TransactionDate}`
    );
  }
  // get monthly transaction detaiils
  getmonthlyTransactuion(siteId: string, month: number, year: number) {
    return this.http.get(
      `${this.baseUrl}Transaction/MonthlyTransactionBySiteId?siteId=${siteId}&month=${month}&year=${year}`
    );
  }
  sendTransactionReportEmail(value: any) {
    return this.http.post(
      `${this.baseUrl}Transaction/SendTransactionReportEmail`,
      value
    );
  }

  getEODReport(SiteId: string, StartDateUtc: string, EndDateUtc: string) {
    return this.http.get(
      `${this.baseUrl}Transaction/EODReport?SiteId=${SiteId}&StartDateUtc=${StartDateUtc}&EndDateUtc=${EndDateUtc}`
    );
  }
  /// Invoice
  getInvoiceEodReport(
    PageIndex: number,
    PageSize: number,
    BusinessDate: any,
    StoreId: any,
    IsNeedReview: any,
    AmountMatched: any,
    CardPayment: any,
    CashRewardPayment: any,
    AchPayment: any,
    sortBy: string,
    sortOrder: string,
    HasTransactionAmount: any
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }SettlementInvoice/eod-settlement-request?PageIndex=${PageIndex}&PageSize=${PageSize}&BusinessDate=${BusinessDate}&StoreId=${
        StoreId == 0 ? '' : StoreId
      }&IsNeedReview=${
        IsNeedReview == null ? '' : IsNeedReview
      }&AmountMatched=${AmountMatched == null ? '' : AmountMatched}
      &CardPayment=${CardPayment == null ? '' : CardPayment}
      &CashRewardPayment=${CashRewardPayment == null ? '' : CashRewardPayment}
      &AchPayment=${
        AchPayment == null ? '' : AchPayment
      }&SortBy=${sortBy}&SortOrder=${sortOrder}&HasTransactionAmount=${
        HasTransactionAmount == null ? '' : HasTransactionAmount
      }`
    );
  }
  updateEodNeedReview(value: any) {
    return this.http.post(
      `${this.baseUrl}SettlementInvoice/update-eod-needreview`,
      value
    );
  }

  geteodPreviewNachaFile(
    body: any = {},
    headers: any = this.createHeader('application/json')
  ) {
    return this.http.post(
      this.baseUrl + `SettlementInvoice/eod-preview-nacha`,
      body,
      headers
    );
  }
  private createHeader(contentType: string): any {
    return {
      headers: new HttpHeaders({ 'Content-Type': contentType }),
      responseType: 'blob',
    };
  }
  getViewNacheBySettlementRequestId(SettlementRequestId: number) {
    return this.http.get(
      this.baseUrl +
        'SettlementInvoice/eod-view-nacha?SettlementRequestId=' +
        SettlementRequestId,
      this.createHeader('application/json')
    );
  }

  getAchMethod(paymentmethod: number) {
    return this.http.get(
      this.baseUrl + 'Payment/Add/' + paymentmethod,
      this.createHeader('application/json')
    );
  }
  UpdateEodSettlement(value: any) {
    return this.http.post(
      `${this.baseUrl}SettlementInvoice/eod-settlement`,
      value
    );
  }

  //Invoice monthly Billing

  getMonthlyInvoiceBilling(
    PageIndex: number,
    PageSize: number,
    StoreId: any,
    IsNeedReview: any,
    IsPaid: any,
    Month: any,
    Year: any,
    sortBy: string,
    sortOrder: string
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }StoreBilling/store-bills?PageIndex=${PageIndex}&PageSize=${PageSize}&StoreId=${
        StoreId == 0 ? '' : StoreId
      }&IsNeedReview=${IsNeedReview == null ? '' : IsNeedReview}&IsPaid=${
        IsPaid == null ? '' : IsPaid
      }&Month=${Month}&Year=${Year}&SortBy=${sortBy}&SortOrder=${sortOrder}`
    );
  }

  updateMonthlyNeedReview(value: any) {
    return this.http.post(
      `${this.baseUrl}StoreBilling/update-needreview`,
      value
    );
  }
  getMonthlyNachaFile(Month: any, Year: any, EffectiveDate: any) {
    return this.http.get(
      `${
        this.baseUrl
      }StoreBilling/store-preview-nacha?Month=${Month}&Year=${Year}&EffectiveDate=${
        EffectiveDate == undefined ? '' : EffectiveDate
      }`,
      this.createHeader('application/json')
    );
  }

  generateBill(value: any) {
    return this.http.post(`${this.baseUrl}StoreBilling/store-generate`, value);
  }

  processPayment(value: any) {
    return this.http.post(
      `${this.baseUrl}StoreBilling/store-process-payment`,
      value
    );
  }

  updateNeedReview(value: any) {
    return this.http.post(
      `${this.baseUrl}StoreBilling/store-update-needreview`,
      value
    );
  }

  // store billing fee
  addStoreBillingFee(value: any) {
    return this.http.post(`${this.baseUrl}StoreBillingFee`, value);
  }

  updateStoreBillingFee(value: any) {
    return this.http.patch(`${this.baseUrl}StoreBillingFee`, value);
  }

  getStoreBillingFeeByStoreId(storeId: number) {
    return this.http.get(
      `${this.baseUrl}StoreBillingFee/store-bystoreid?storeId=${storeId}`
    );
  }

  getStoreBillingFeeBy(storebillingFeeId: number) {
    return this.http.get(`${this.baseUrl}StoreBillingFee/${storebillingFeeId}`);
  }
  eodUnpaid(value: any) {
    return this.http.post(
      `${this.baseUrl}SettlementInvoice/update-eod-unpaid`,
      value
    );
  }

  eodUnpaidTrans(value: any) {
    return this.http.post(
      `${this.baseUrl}SettlementInvoice/update-tran-eod-unpaid`,
      value
    );
  }
  storeBillingUnpaid(value: any) {
    return this.http.post(
      `${this.baseUrl}StoreBilling/store-update-unpaid`,
      value
    );
  }

  storeBillingViewNacha(storeBillingId: number) {
    return this.http.get(
      this.baseUrl +
        'StoreBilling/store-view-nacha?StoreBillingId=' +
        storeBillingId,
      this.createHeader('application/json')
    );
  }
  // getViewNacheBySettlementRequestId(SettlementRequestId: number) {
  //   return this.http.get(
  //     this.baseUrl +
  //       'SettlementInvoice/eod-view-nacha?SettlementRequestId=' +
  //       SettlementRequestId,
  //     this.createHeader('application/json')
  //   );
  // }
  eodPreviewPdf(SettlementRequestId: number) {
    return this.http.get(
      `${this.baseUrl}SettlementInvoice/preview-eod-invoice-pdf?SettlementRequestId=${SettlementRequestId}`,
      this.createHeader('application/json')
    );
  }
  monthlyStoreBillingPdf(StoreBillingId: number) {
    return this.http.get(
      `${this.baseUrl}StoreBilling/store-monthly-invoice-pdf?StoreBillingId=${StoreBillingId}`,
      this.createHeader('application/json')
    );
  }
  saleAgentMonthlyInvoicePdf(saleAgentBillingDetailId: number) {
    return this.http.get(
      `${this.baseUrl}SaleAgentBilling/saleagent-monthly-invoice-pdf?SaleAgentBillingId=${saleAgentBillingDetailId}`,
      this.createHeader('application/json')
    );
  }

  allsaleAgentMonthlyInvoicePdf(saleAgentBillingDetailId: number) {
    return this.http.get(
      `${this.baseUrl}SaleAgentBilling/saleagent-monthly-invoice-pdf?SaleAgentBillingDetailId=${saleAgentBillingDetailId}`,
      this.createHeader('application/json')
    );
  }

  // Sale Agent Fee
  addSaleAgentFee(value: any) {
    return this.http.post(`${this.baseUrl}SaleAgentFee`, value);
  }

  updateSaleAgentFee(value: any) {
    return this.http.patch(`${this.baseUrl}SaleAgentFee`, value);
  }

  getSaleAgentFeeBySaleAgentId(SaleAgentId: number, storeId: number) {
    return this.http.get(
      `${this.baseUrl}SaleAgentFee?SaleAgentId=${SaleAgentId}&StoreId=${storeId}`
    );
  }

  getSaleAgentFeeBySaleAgentFeeId(saleAgentFeeId: number) {
    return this.http.get(`${this.baseUrl}SaleAgentFee/${saleAgentFeeId}`);
  }

  // Sales agent billing

  getSalesAgentMonthlyBill(
    pageIndex: number,
    pageSize: number,
    storeId: number,
    IsNeedReview: any,
    IsPaid: any,
    month: number,
    year: number,
    sortBy: string,
    sortOrder: string
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }SaleAgentBilling/saleagent-bills?PageIndex=${pageIndex}&PageSize=${pageSize}&StoreId=${storeId}&IsNeedReview=${
        IsNeedReview == null ? '' : IsNeedReview
      }&IsPaid=${
        IsPaid == null ? '' : IsPaid
      }&Month=${month}&Year=${year}&SortBy=${sortBy}&SortOrder=${sortOrder}`
    );
  }

  getSalesAgentMonthlyBillGenerate(value: any) {
    return this.http.post(
      `${this.baseUrl}SaleAgentBilling/saleagent-generate`,
      value
    );
  }

  saleAgentBillingPaymentProcess(value: any) {
    return this.http.post(
      `${this.baseUrl}SaleAgentBilling/saleagent-process-payment`,
      value
    );
  }

  updateSalesAgentNeedReview(value: any) {
    return this.http.post(
      `${this.baseUrl}SaleAgentBilling/saleagent-update-needreview`,
      value
    );
  }

  updateSalesAgentUnpaid(value: any) {
    return this.http.post(
      `${this.baseUrl}SaleAgentBilling/saleagent-update-unpaid`,
      value
    );
  }

  getSalesAgentPreviewNacha(Month: number, Year: number) {
    return this.http.get(
      `${this.baseUrl}SaleAgentBilling/saleagent-preview-nacha?Month=${Month}&Year=${Year}`,
      this.createHeader('application/json')
    );
  }

  getSalesAgentViewNacha(SaleAgentBillingDetailId: number) {
    return this.http.get(
      this.baseUrl +
        'SaleAgentBilling/saleagent-view-nacha?SaleAgentBillingId=' +
        SaleAgentBillingDetailId,
      this.createHeader('application/json')
    );
  }
  getAllSaleAgentMonthlyInvoicePdf(
    storeId: number,
    IsNeedReview: any,
    IsPaid: any,
    month: number,
    year: number
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }SaleAgentBilling/saleagent-all-monthly-invoice-pdf?StoreId=${
        storeId == 0 ? '' : storeId
      }&IsNeedReview=${IsNeedReview == null ? '' : IsNeedReview}&IsPaid=${
        IsPaid == null ? '' : IsPaid
      }&Month=${month}&Year=${year}
      `,
      this.createHeader('application/json')
    );
  }

  // Default sale agent fee setup

  getDefaultSaleAgentFeeSetup() {
    return this.http.get(`${this.baseUrl}SaleAgentFee/salesagent-default`);
  }

  saveDefaultSaleAgentFeeSetup(value: any) {
    return this.http.post(`${this.baseUrl}SaleAgentFee`, value);
  }
  updateDefaultSaleAgentFeeSetup(value: any) {
    return this.http.patch(`${this.baseUrl}SaleAgentFee`, value);
  }

  getMonthlyInvoicePdf(
    IsNeedReview: any,
    IsPaid: any,
    month: number,
    year: number,
    storeId: number
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }StoreBilling/store-all-monthly-invoice-pdf?&IsNeedReview=${
        IsNeedReview == null ? '' : IsNeedReview
      }&IsPaid=${
        IsPaid == null ? '' : IsPaid
      }&Month=${month}&Year=${year}&StoreId=${storeId == 0 ? '' : storeId}`,
      this.createHeader('application/json')
    );
  }

  //Eod report

  getEodReport(
    pageIndex: number,
    pageSize: number,
    StartDateUtc: any,
    EndDateUtc: any,
    StoreId: any,

    HasTransaction: any,
    IsAmountMached: any,
    CardPayment: any,
    CashRewardPayment: any,
    AchPayment: any,
    sortBy: string,
    sortOrder: string
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }SettlementInvoice/EODReport?PageIndex=${pageIndex}&PageSize=${pageSize}&StartDateUtc=${StartDateUtc}&EndDateUtc=${EndDateUtc}&StoreId=${
        StoreId == 0 ? '' : StoreId
      }&HasTransaction=${
        HasTransaction == null ? '' : HasTransaction
      }&IsAmountMached=${
        IsAmountMached == null ? '' : IsAmountMached
      }&CardPayment=${
        CardPayment == null ? '' : CardPayment
      }&CashRewardPayment=${
        CashRewardPayment == null ? '' : CashRewardPayment
      }&AchPayment=${
        AchPayment == null ? '' : AchPayment
      }&SortBy=${sortBy}&SortOrder=${sortOrder}`
    );
  }

  getTransactionReconcile(
    pageIndex: number,
    pageSize: number,
    storeId: number,
    StartDateUtc: any,
    EndDateUtc: any,
    IsPaid: any,
    sortBy: string,
    sortOrder: string
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }Transaction/TransactionReconcileReport?PageIndex=${pageIndex}&PageSize=${pageSize}&StoreId=${
        storeId == 0 ? '' : storeId
      }&StartDateUtc=${StartDateUtc}&EndDateUtc=${EndDateUtc}&&IsPaid=${
        IsPaid == null ? '' : IsPaid
      }&SortBy=${sortBy}&SortOrder=${sortOrder}`
    );
  }

  getMonthlyTransactionBySiteId(
    pageIndex: number,
    pageSize: number,
    storeId: number,
    month: number,
    year: number,
    IsSuccess: any,
    IsCancelled: any,
    IsFailed: any,
    sortBy: string,
    sortOrder: string
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }Transaction/MonthlyTransactionBySiteId?PageIndex=${pageIndex}&PageSize=${pageSize}&StoreId=${
        storeId == 0 ? '' : storeId
      }&Month=${month == 0 ? '' : month}&Year=${
        year == 0 ? '' : year
      }&IsSuccess=${IsSuccess == null ? '' : IsSuccess}&IsCancelled=${
        IsCancelled == null ? '' : IsCancelled
      }&IsFailed=${
        IsFailed == null ? '' : IsFailed
      }&SortBy=${sortBy}&SortOrder=${sortOrder}`
    );
  }

  // Default billing setup

  getDefaultBillingFee() {
    return this.http.get(`${this.baseUrl}StoreBillingFee/store-default`);
  }

  copyDefaultBillingFee(value: any) {
    return this.http.post(
      `${this.baseUrl}StoreBillingFee/store-default-clone`,
      value
    );
  }

  /// Reseller Start

  createResllerBillingFee(value: any) {
    return this.http.post(`${this.baseUrl}ResellerFee`, value);
  }
  UpdateResllerBillingFee(value: any) {
    return this.http.patch(`${this.baseUrl}ResellerFee`, value);
  }

  getBillingFeeByResellerId(resellerId: number) {
    return this.http.get(
      `${this.baseUrl}ResellerFee/reseller-byresellerid?resellerId=${resellerId}`
    );
  }

  getResellerFeeByResellerFeeId(resellerFeeId: number) {
    return this.http.get(`${this.baseUrl}ResellerFee/${resellerFeeId}`);
  }

  getResellerDefault() {
    return this.http.get(`${this.baseUrl}ResellerFee/reseller-default`);
  }
  copyDefaultResellerBillingFee(value: any) {
    return this.http.post(
      `${this.baseUrl}ResellerFee/reseller-default-clone`,
      value
    );
  }
  getResellerBillingProcess(
    pageIndex: number,
    pageSize: number,
    IsNeedReview: any,
    IsPaid: any,
    month: number,
    year: number,
    sortBy: string,
    sortOrder: string
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }ResellerBilling/reseller-bills?PageIndex=${pageIndex}&PageSize=${pageSize}&IsNeedReview=${
        IsNeedReview == null ? '' : IsNeedReview
      }&IsPaid=${
        IsPaid == null ? '' : IsPaid
      }&Month=${month}&Year=${year}&SortBy=${sortBy}&SortOrder=${sortOrder}`
    );
  }

  generateResellerBillingProcess(value: any) {
    return this.http.post(
      `${this.baseUrl}ResellerBilling/reseller-generate`,
      value
    );
  }

  resellerBillingPaymentProcess(value: any) {
    return this.http.post(
      `${this.baseUrl}ResellerBilling/reseller-process-payment`,
      value
    );
  }

  updateResellerNeedReview(value: any) {
    return this.http.post(
      `${this.baseUrl}ResellerBilling/reseller-update-needreview`,
      value
    );
  }

  updateResellerUnpaid(value: any) {
    return this.http.post(
      `${this.baseUrl}ResellerBilling/reseller-update-unpaid`,
      value
    );
  }

  getResellerPreviewNacha(Month: number, Year: number) {
    return this.http.get(
      `${this.baseUrl}ResellerBilling/reseller-preview-nacha?Month=${Month}&Year=${Year}`,
      this.createHeader('application/json')
    );
  }

  getResellerViewNacha(resellerBillingId: number) {
    return this.http.get(
      this.baseUrl +
        'ResellerBilling/reseller-view-nacha?ResellerBillingId=' +
        resellerBillingId,
      this.createHeader('application/json')
    );
  }
  getResellerPdf(resellerBillingId: number) {
    return this.http.get(
      `${this.baseUrl}ResellerBilling/reseller-monthly-invoice-pdf?ResellerBillingId=${resellerBillingId}`,
      this.createHeader('application/json')
    );
  }
  getResellerMonthlyInvoicePdf(
    IsNeedReview: any,
    IsPaid: any,
    month: number,
    year: number
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }ResellerBilling/reseller-all-monthly-invoice-pdf?IsNeedReview=${
        IsNeedReview == null ? '' : IsNeedReview
      }&IsPaid=${IsPaid == null ? '' : IsPaid}&Month=${month}&Year=${year}
      `,
      this.createHeader('application/json')
    );
  }

  // Reseller End
  getAchDailyReport(
    StartDateUtc: any,
    endDate: any,
    pageIndex: number,
    pageSize: number,
    sortBy: string,
    sortOrder: string
  ) {
    return this.http.get(
      `${this.baseUrl}NachReports/NachaDailyProcessingReport?FromDate=${StartDateUtc}&ToDate=${endDate}&PageIndex=${pageIndex}&PageSize=${pageSize}&SortBy=${sortBy}&SortOrder=${sortOrder}`
    );
  }
  getAchDailyReturn(
    StartDateUtc: any,
    endDate: any,
    pageIndex: number,
    pageSize: number,

    sortBy: string,
    sortOrder: string
  ) {
    return this.http.get(
      `${this.baseUrl}NachReports/NachaDailyReturnReport?FromDate=${StartDateUtc}&ToDate=${endDate}&PageIndex=${pageIndex}&PageSize=${pageSize}&SortBy=${sortBy}&SortOrder=${sortOrder}`
    );
  }
  getAchTransactionReport(
    StartDateUtc: any,
    endDate: any,
    pageIndex: number,
    pageSize: number,
    sortBy: string,
    sortOrder: string
  ) {
    return this.http.get(
      `${this.baseUrl}NachReports/ACHTransactionReport?FromDate=${StartDateUtc}&ToDate=${endDate}&PageIndex=${pageIndex}&PageSize=${pageSize}&SortBy=${sortBy}&SortOrder=${sortOrder}`
    );
  }
  getAchReturnReport(
    StartDateUtc: any,
    endDate: any,
    pageIndex: number,
    pageSize: number,
    sortBy: string,
    sortOrder: string
  ) {
    return this.http.get(
      `${this.baseUrl}NachReports/ACHReturnReport?FromDate=${StartDateUtc}&ToDate=${endDate}&PageIndex=${pageIndex}&PageSize=${pageSize}&SortBy=${sortBy}&SortOrder=${sortOrder}`
    );
  }
  getTransactionDetails(
    formDate: any,
    toDate: any,
    pageIndex: number,
    pageSize: number,
    sortBy: string,
    sortOrder: string
  ) {
    return this.http.get(
      `${this.baseUrl}Transaction/GetTransactionDetailReport?FromDate=${formDate}&ToDate=${toDate}&PageIndex=${pageIndex}&PageSize=${pageSize}&SortBy=${sortBy}&SortOrder=${sortOrder}`
    );
  }

  //Transaction tab
  dashboardview(body: {}) {
    // console.log('Transaction detail api data');
    return this.http.post(`${this.baseUrl}Dashboard/TransactionDetails`, body);
  }
  monthWise(body: {}) {
    // console.log('Transaction detail api data');
    return this.http.post(
      `${this.baseUrl}Dashboard/MonthwiseTransactionDetails`,
      body
    );
  }

  //Reward tab
  rewardPageView(body: {}) {
    // console.log('Rewards detail api data');
    return this.http.post(`${this.baseUrl}Dashboard/RewardDetails`, body);
  }
  consumersDetails(body: {}) {
    return this.http.post(`${this.baseUrl}Dashboard/ConsumersDetails`, body);
  }
  dashboardIteams(body: {}) {
    return this.http.post(`${this.baseUrl}Dashboard/ItemsDetails`, body);
  }
  getSignalRMessage() {
    const signalRBaseUrl = 'wss://prod-apim-00.azure-api.net/';
    return this.http.get(`${signalRBaseUrl}DashBoardHub`);
  }
  getConsumrsListing(
    pageIndex: number,
    pageSize: number,
    sortBy: any,
    sortOrder: any,
    tenantId: number[]
  ) {
    let params = new HttpParams();
    params = params.append('AppName', 'SpiTech');
    if (tenantId.length > 0) {
      tenantId?.forEach((tenantId) => {
        params = params.append('AppIds', tenantId.toString());
      });
    }

    return this.http.get(
      `${this.baseUrl}Dashboard/GetDashboardConsumersList?PageIndex=${pageIndex}&PageSize=${pageSize}&SortBy=${sortBy}&SortOrder=${sortOrder}&${params}`
    );
  }

  getConsumersProfileDetails(startDate: any, endDate: any, tenantId: number[]) {
    let params = new HttpParams();
    params = params.append('AppName', 'SpiTech');
    tenantId.forEach((tenantId) => {
      params = params.append('TenantId', tenantId.toString());
    });
    return this.http.get(
      `${this.baseUrl}Dashboard/ProfileDetails?StartDate=${startDate}&EndDate=${endDate}&${params}`
    );
  }
  private handleErrors(response: any) {
    // alert(response.message);
    return throwError({ message: response.message });
  }
}
