import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, throwIfEmpty } from 'rxjs/operators';

import { PeriodicElement } from '../admin/user/role-tab/role-tab.component';
import { EditUsereModule } from '../admin/user/edit-user/edit-user.module';
import { environment } from 'src/environments/environment';
import { sortBy } from 'lodash';

@Injectable()
export class ReportsService {
  baseUrl: string = `${environment.base_url}reports/api/`;
  constructor(private http: HttpClient) {}

  // Error log
  getErrorLog(
    userId: number,
    fromDate: string,
    toDate: string,
    pageIndex: number,
    pageSize: number,
    sortBy: string,
    sortOrder: string
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }ErrorLog/GetErrorLog?UserId=${userId}&FromDate=${fromDate}&ToDate=${toDate}&PageIndex=${
        pageIndex == 0 ? '' : pageIndex
      }&PageSize=${
        pageSize == 0 ? '' : pageSize
      }&SortBy=${sortBy}&SortOrder=${sortOrder}`
    );
  }

  getConsumerReports(
    StartZipcode: null,
    EndZipcode: null,
    AreaCode: string,
    State: string,
    City: string,
    TransactionStartDate: string,
    TransactionEndDate: string,
    RegisterStartDate: string,
    RegisterEndDate: string,
    TransactionMinAmount: null,
    TransactionMaxAmount: null
  ) {
    return this.http.get(
      `${this.baseUrl}Consumer?StartZipcode=${StartZipcode}&EndZipcode=${EndZipcode}&AreaCode=${AreaCode}&State=${State}&City=${City}&TransactionStartDate=${TransactionStartDate}&TransactionEndDate=${TransactionEndDate}&RegisterStartDate=${RegisterStartDate}&RegisterEndDate=${RegisterEndDate}&TransactionMinAmount=${TransactionMinAmount}&TransactionMaxAmount=${TransactionMaxAmount}`
    );
  }

  getTransationConsumer(
    AreaCode: string,
    State: string,
    City: string,
    StartZipcode: any,
    EndZipcode: any
  ) {
    return this.http.get(
      `${this.baseUrl}Consumer?AreaCode=${AreaCode}&State=${State}&City=${City}&StartZipcode=${StartZipcode}&EndZipcode=${EndZipcode}`
    );
  }
  getTransactionSearch(body: {}) {
    return this.http.post(
      `${this.baseUrl}Transaction/TransactionSearch
      `,
      body
    );
  }
  getTransactionSearchByStoreId(
    StoreId: number,
    PageIndex: number,
    PageSize: number
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }Transaction/TransactionSearch?StoreId=${StoreId}&PageIndex=${
        PageIndex == 0 ? '' : PageIndex
      }&PageSize=${PageSize == 0 ? '' : PageSize}`
    );
  }
  getConsumerTransationHistory(
    userId: number,
    Storename: string,
    PageIndex: number,
    PageSize: number,
    SortBy: string,
    SortOrder: string
  ) {
    return this.http.get(
      `${this.baseUrl}Transaction?UserId=${userId}&Storename=${Storename}&PageIndex=${PageIndex}&SortBy=${SortBy}&PageSize=${PageSize}&SortOrder=${SortOrder}`
    );
  }
  getTotalConsumer() {
    return this.http.get(`${this.baseUrl}Consumer`);
  }

  getTransationSearchByFilter(
    firstName: string,
    storeId: number,
    storeName: string,
    mobileNumber: string,
    FromDate: string,
    ToDate: string,
    PageIndex: number,
    PageSize: number,
    sortBy: string,
    sortOrder: string
  ) {
    return this.http.get(
      `${this.baseUrl}Transaction/TransactionSearchByFilter?FirstName=${firstName}&StoreId=${storeId}&StoreName=${storeName}&MobileNumber=${mobileNumber}&FromDate=${FromDate}&ToDate=${ToDate}&PageIndex=${PageIndex}&PageSize=${PageSize}&sortable.SortBy=${sortBy}&sortable.SortOrder=${sortOrder}`
    );
  }
  private handleErrors(response: any) {
    // alert(response.message);
    return throwError({ message: response.message });
  }
}
