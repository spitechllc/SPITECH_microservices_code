import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
@Injectable()
export class FinanceService {
  baseUrl: string = `${environment.base_url}finances/api/`;
  constructor(private http: HttpClient) {}

  // get user wallet
  getUserWallet(userId: any) {
    return this.http.get(
      `${this.baseUrl}Wallet/GetUserWallet?UserId=${userId}`
    );
  }

  getWalletCreditsByStoreId(siteId: number, month: number, year: any) {
    return this.http.get(
      `${this.baseUrl}Wallet/GetWalletCreditsByStoreId?StoreId=${siteId}&month=${month}&year=${year}`
    );
  }

  getWalletCredits() {
    return this.http.get(`${this.baseUrl}Wallet/GetWalletCreditsByStoreId`);
  }

  // credit & debit
  cashBackCredit(value: any) {
    return this.http.post(`${this.baseUrl}AdminProcess/Credit`, value);
  }
  cashBackDebit(value: any) {
    return this.http.post(`${this.baseUrl}AdminProcess/Debit`, value);
  }

  getWalletHistory(userId: any, PageIndex: number, PageSize: number) {
    return this.http.get(
      `${this.baseUrl}Wallet/GetWalletHistory?UserId=${userId}&PageIndex=${PageIndex}&PageSize=${PageSize}`
    );
  }

  getUserWalletList(userId: any) {
    return this.http.get(
      `${this.baseUrl}Wallet/GetUserWalletList?UserIds=${userId}`
    );
  }
  getUserWalletData(userId: any) {
    return this.http.get(
      `${this.baseUrl}Wallet/WalletDetailsByUserId?UserId=${userId}`
    );
  }
}
