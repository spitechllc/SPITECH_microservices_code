import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, throwIfEmpty } from 'rxjs/operators';
import { OidcSecurityService } from 'angular-auth-oidc-client';
// import { Store }  from '../../dashboard/Models/store';
import { PeriodicElement } from '../admin/user/role-tab/role-tab.component';
import { environment } from 'src/environments/environment';

@Injectable()
export class PaymentService {
  baseUrl: string = `${environment.base_url}payments/api/`;
  constructor(
    private http: HttpClient,
    private oidcSecurityService: OidcSecurityService
  ) {}

  getSaleAgentConfig(saleAgentId: number) {
    return this.http.get(`${this.baseUrl}SaleAgentConfig/${saleAgentId}`);
  }
  getInhouseOnboard() {
    return this.http.get(`${this.baseUrl}InhouseAccount/GetInhouseAccount`);
  }
  GetInhouseAccountUserDetail(inhouseNumber: string) {
    return this.http.get(this.baseUrl + 'InhouseAccount/GetInhouseAccountUserDetail/' + inhouseNumber);
  }
  getInhouseDetailById(inhouseId: number) {
    return this.http.get(this.baseUrl + 'InhouseAccount/GetInhouseAccountById/' + inhouseId);
  }
  createSalesAgentConfig(value: any) {
    return this.http.post(`${this.baseUrl}SaleAgentConfig`, value);
  }
  createInhOnboard(value: any) {
    return this.http.post(`${this.baseUrl}InhouseAccount/InhouseAccount`, value);
  }

  deleteInhouseAccUser(value: any) {
    return this.http.post(`${this.baseUrl}InhouseAccount/DeleteInhouseAccountUser`, value);
  }
  getUserPaymentMethodById(userId: number) {
    return this.http.get(this.baseUrl + 'UserPaymentMethod/GetUserPaymentMethod/' + userId);
  }

  getPaymentFailed(
    UserId: number,
    StartDate: string,
    EndDate: string,
    IsPaymentReceived: boolean,
    TransactionId: number,
    confirmationNumber: string,
    PageIndex: number,
    PageSize: number,
    SortBy: string,
    SortOrder: string
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }PaymentProcess/FailedPaymentList?UserId=${UserId}&StartDate=${StartDate}&EndDate=${EndDate}&IsPaymentReceived=${IsPaymentReceived}&TransactionId=${TransactionId}&confirmationNumber=${confirmationNumber}&PageIndex=${
        PageIndex == 0 ? '' : PageIndex
      }&PageSize=${
        PageSize == 0 ? '' : PageSize
      }&SortBy=${SortBy}&SortOrder=${SortOrder}`
    );
  }

  // get payment method
  getPaymentMethod() {
    return this.http.get(this.baseUrl + 'Payment/PaymentMethod');
  }
  // get credit card method by creditcardmethodId
  getCreditCardMethod(paymentmethod: number) {
    return this.http
      .get(
        this.baseUrl + 'Payment/AddCreditCard/' + paymentmethod,
        this.createHeader('application/json')
      )
      .pipe(catchError(this.handleErrors.bind(this)));
  }
  //get ash card
  getAchMethod(paymentmethod: number) {
    return this.http.get(
      this.baseUrl + 'Payment/Add/' + paymentmethod,
      this.createHeader('application/json')
    );
  }
  // GetDefaultUserPaymentMethod
  getDefaultUserPaymentMethod() {
    const userId = localStorage.getItem('userId');
    return this.http.get(
      this.baseUrl + 'Payment/GetDefaultUserPaymentMethod?UserId=' + userId
    );
  }
  //get paymetnt method
  getUserPaymentMethod() {
    return this.http.get(this.baseUrl + 'Payment/UserPaymentMethod');
  }

  // PaymentConfiguration(
  paymentConfiguration(value: any) {
    return this.http.post(
      `${environment.base_url}payments/api/PaymentMethodConfiguration/PaymentMethodConfiguration`,
      value
    );
  }

  // get payment configuration
  getPaymentConfiguration(storeId: number) {
    return this.http.get(
      environment.base_url +
        'payments/api/PaymentMethodConfiguration/StorePaymentMethodByStoreId/' +
        storeId
    );
  }
  getPaymentConfigByStoreIdPaymentGatewayConfigId(
    storeId: number,
    PaymentGatewayConfigId: number
  ) {
    return this.http.get(
      `${environment.base_url}payments/api/PaymentMethodConfiguration/GetStorePaymentMethod?storeId=${storeId}&PaymentGatewayConfigId=${PaymentGatewayConfigId} `
    );
  }
  getPaymentGateway() {
    return this.http.get(
      `${environment.base_url}payments/api/PaymentMethodConfiguration/PaymentGateway`
    );
  }
  addAchCard(storeId: any) {
    return this.http.get(`${this.baseUrl}Payment/AddCardStore/${storeId}`);
  }
  private createHeader(contentType: string): any {
    return {
      headers: new HttpHeaders({ 'Content-Type': contentType }),
      responseType: 'text',
    };
  }

  addPaymentConfig(value: any) {
    return this.http.post(`${this.baseUrl}StoreConfig`, value);
  }

  getPaymentAccount(storeId: any) {
    return this.http.get(`${this.baseUrl}StoreConfig/showAccount/${storeId}`);
  }
  getPaymentConfig(storeId: any) {
    return this.http.get(`${this.baseUrl}StoreConfig/${storeId}`);
  }

  getCertifyCertifyBeneficialOwner(storeId: number) {
    return this.http.get(
      `${this.baseUrl}Business/CertifyBeneficialOwner?StoreId=${storeId}`
    );
  }

  getDocumentStatus(documentId: number) {
    return this.http.get(
      `${this.baseUrl}Business/GetBusinessCustomerDocumentStatus?documentId=${documentId}`
    );
  }

  // Reseller

  createUpdateResellerConfig(value: any) {
    return this.http.post(`${this.baseUrl}ResellerConfig`, value);
  }
  getResellerConfigById(resellerId: number) {
    return this.http.get(`${this.baseUrl}ResellerConfig/${resellerId}`);
  }

  private handleErrors(response: any) {
    // alert(response.message);
    return throwError({ message: response.message });
  }
}
