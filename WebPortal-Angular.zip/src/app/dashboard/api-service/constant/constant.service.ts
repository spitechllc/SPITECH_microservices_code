import { ElementRef, Injectable, ViewChild } from '@angular/core';
@Injectable({
  providedIn: 'root',
})
export class ConstantService {
  constructor() {}
  @ViewChild('TABLE') table: ElementRef;
  applicationType: any = [
    { id: 1, name: 'At Pump' },
    { id: 2, name: 'Car Wash' },
    { id: 3, name: 'In Store' },
  ];

  TransactionStatus: any = [
    { id: 1, name: 'Inprogress' },
    { id: 2, name: 'Success' },
    { id: 3, name: 'Fail' },
  ];
}
