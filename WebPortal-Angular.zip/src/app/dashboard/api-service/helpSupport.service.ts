import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, throwIfEmpty } from 'rxjs/operators';
// import { Store }  from '../../dashboard/Models/store';
import { PeriodicElement } from '../admin/user/role-tab/role-tab.component';
import { environment } from 'src/environments/environment';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';

@Injectable()
export class HelpSupportService {
  baseUrl: string = `${environment.base_url}helpsupport/api/`;

  constructor(
    private http: HttpClient,
    private toster: ToastrService,
    private sppiner: NgxSpinnerService,
    private router: Router
  ) {}

  // store : Store[] = []

  getTutorail(
    PageIndex: any,
    PageSize: any,
    SortOrder: any,
    SortBy: any,
    TutorialName: string,
    CategoryId: number,
    tenantId: number
  ) {
    return this.http
      .get(
        `${this.baseUrl}Tutorial?PageIndex=${
          PageIndex == 0 ? '' : PageIndex
        }&PageSize=${
          PageSize == 0 ? '' : PageSize
        }&SortOrder=${SortOrder}&SortBy=${SortBy}&TutorialName=${TutorialName}&CategoryId=${CategoryId}&TenantId=${tenantId}`
      )
      .pipe(catchError(this.handleErrors.bind(this)));
  }
  // get tutorail
  getTutorialCategory() {
    return this.http.get(this.baseUrl + 'Tutorial/GetTutorialCategory');
  }
  // create tutorial
  createTutorial(value: any) {
    // console.log(value, 'value');
    return this.http
      .post(this.baseUrl + 'Tutorial', value)
      .pipe(catchError(this.handleErrors.bind(this)));
  }
  //get tutorial by tutorialId
  getTutorialById(tutorialId: number) {
    return this.http
      .get(this.baseUrl + 'Tutorial/GetTutorialById/' + tutorialId)
      .pipe(catchError(this.handleErrors.bind(this)));
  }
  // update tutorial
  updateTutorial(value: any) {
    return this.http
      .patch(this.baseUrl + 'Tutorial', value)
      .pipe(catchError(this.handleErrors.bind(this)));
  }

  // create App configuration
  createAppConfiguration(value: any) {
    return this.http
      .post(this.baseUrl + 'AppConfiguration', value)
      .pipe(catchError(this.handleErrors.bind(this)));
  }

  // get appconfiguration
  getAppConfiguration() {
    return this.http
      .get(this.baseUrl + 'AppConfiguration')
      .pipe(catchError(this.handleErrors.bind(this)));
  }
  // update
  updateAppConfiguration(value: any) {
    return this.http
      .patch(this.baseUrl + 'AppConfiguration', value)
      .pipe(catchError(this.handleErrors.bind(this)));
  }

  getApplicationSupport(
    pageIndex: number,
    pageSize: number,
    sortBy: string,
    sortOrder: string
  ) {
    return this.http
      .get(
        `${this.baseUrl}ApplicationSupport?PageIndex=${pageIndex}&PageSize=${pageSize}&SortBy=${sortBy}&SortOrder=${sortOrder}`
      )
      .pipe(catchError(this.handleErrors.bind(this)));
  }

  addApplicationSupport(value: any) {
    return this.http.post(`${this.baseUrl}ApplicationSupport`, value);
  }

  private handleErrors(err: any) {
    if (err.status == 500) {
      // this.toster.error('Inetnal server error');
      this.router.navigate(['/error']);
    }
    this.sppiner.hide();
    return throwError({ message: err });
  }

  // get user details
}
