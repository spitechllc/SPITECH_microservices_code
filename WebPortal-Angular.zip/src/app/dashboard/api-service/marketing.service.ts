import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, throwIfEmpty } from 'rxjs/operators';
// import { Store }  from '../../dashboard/Models/store';
import { PeriodicElement } from '../admin/user/role-tab/role-tab.component';
import { EditUsereModule } from '../admin/user/edit-user/edit-user.module';
import { environment } from 'src/environments/environment';

@Injectable()
export class MarketingService {
  baseUrl: string = `${environment.base_url}marketing/api/`;
  constructor(private http: HttpClient) {}

  createOfferAndDeals(value: any) {
    return this.http.post(this.baseUrl + 'Offer', value);
  }
  getOfferAndDeals(
    OfferDeal: string,
    storeName: string,
    PageIndex: any,
    PageSize: any,
    SortOrder: any,
    SortBy: any
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }Offer/ByFilter?OfferDeal=${OfferDeal}&StoreName=${storeName}&PageIndex=${
        PageIndex == 0 ? '' : PageIndex
      }&PageSize=${
        PageSize == 0 ? '' : PageSize
      }&sortable.SortOrder=${SortOrder}&sortable.SortBy=${SortBy}`
    );
  }
  getAllInactiveOfferAndDeals(
    OfferDeal: string,
    storeName: string,
    PageIndex: any,
    PageSize: any,
    SortOrder: any,
    SortBy: any
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }Offer/InactiveOfferByFilter?OfferDeal=${OfferDeal}&StoreName=${storeName}&PageIndex=${
        PageIndex == 0 ? '' : PageIndex
      }&PageSize=${
        PageSize == 0 ? '' : PageSize
      }&sortable.SortOrder=${SortOrder}&sortable.SortBy=${SortBy}`
    );
  }
  getInActiveOfferById(offerId: any) {
    return this.http.get(
      `${this.baseUrl}Offer/InactiveOfferByFilter?OfferId=${offerId}`
    );
  }

  getOfferwithSearch(OfferDeal: any) {
    return this.http.get(
      `${this.baseUrl}Offer/ByFilter?OfferDeal=${OfferDeal}`
    );
  }
  // get offerAnd Deals by offferById
  getOfferAndDealsBYOfferId(offerId: number) {
    return this.http.get(this.baseUrl + 'Offer/ByFilter?OfferId=' + offerId);
  }
  // update offer and deals
  updateOfferAndDeals(value: any) {
    return this.http.patch(this.baseUrl + 'Offer', value);
  }
  consumerOffer(value: any) {
    return this.http.post(this.baseUrl + 'ConsumerOffer', value);
  }

  // get consumer offer
  getConsumerOffer(userId: number, SortBy: string, SortOrder: string) {
    return this.http.get(
      `${this.baseUrl}ConsumerOffer?userId=${userId}&SortBy=${SortBy}&SortOrder=${SortOrder}`
    );
  }

  // cashReward setup
  cashRewardSetup(value: any) {
    return this.http.post(`${this.baseUrl}Loyalty`, value);
  }
  // promotion setup
  promotion(value: any) {
    return this.http.post(`${this.baseUrl}Promotion`, value);
  }
  // get cash back event

  getCashBackEvent(id: any) {
    return this.http.get(
      `${this.baseUrl}Loyalty/GetCashBackEvent?creditType=${id}`
    );
  }
  getCashBackCrietriaByEventId(EventId: number) {
    return this.http.get(
      `${this.baseUrl}Loyalty/CashBackCrietriaByEventId?EventId=${EventId}`
    );
  }
  getGetLoyalty(PageIndex: any, PageSize: any, SortOrder: any, SortBy: any) {
    return this.http.get(
      `${this.baseUrl}Loyalty/GetLoyalty?PageIndex=${PageIndex}&PageSize=${PageSize}&sortable.SortOrder=${SortOrder}&sortable.SortBy=${SortBy}`
    );
  }
  getByloyaltyId(LoyaltyId: number) {
    return this.http.get(
      `${this.baseUrl}Loyalty/GetById?LoyaltyId=${LoyaltyId}`
    );
  }
  updateCashBackReward(value: any) {
    return this.http.patch(`${this.baseUrl}Loyalty`, value);
  }
  getPromotion(PageIndex: any, PageSize: any, SortOrder: any, SortBy: any) {
    return this.http.get(
      `${this.baseUrl}Promotion/GetPromotion?PageIndex=${PageIndex}&PageSize=${PageSize}&sortable.SortOrder=${SortOrder}&sortable.SortBy=${SortBy}`
    );
  }
  getPromotionById(PromotionId: number) {
    return this.http.get(
      `${this.baseUrl}Promotion/GetById?PromotionId=${PromotionId}`
    );
  }
  updatePromotion(value: any) {
    return this.http.patch(`${this.baseUrl}Promotion`, value);
  }
}
