import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, throwIfEmpty } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable()
export class UserService {
  baseUrl: string = `${environment.base_url}stores/api/`;
  // baseUrl: string = `${environment.base_url}userstoremanagement/api/`;
  constructor(private http: HttpClient) {}

  // store : Store[] = []

  addUser(value: any) {
    // console.log(value);
    return this.http.post(`${this.baseUrl}Users`, value);
  }

  // Owner create
  createOwner(value: any) {
    // console.log(value);
    return this.http.post(`${this.baseUrl}Companies`, value);
  }

  //get user details
  getUsersDetails() {
    return this.http.get(this.baseUrl + 'Users/ByEntityId/1?entityName=1');
  }
  //get all user by pagging
  findAllUser() {
    return this.http.get(`${this.baseUrl}Users/WithPaging`);
  }

  getUserByPagging(
    PageIndex: number,
    PageSize: number,
    SortOrder: string,
    SortBy: string,
    firstName: string,
    lastName: string,
    StoreName: string,
    email: string,
    phone: string,
    stateName: string,
    city: string,
    zipCode: string
  ) {
    return this.http.get(
      `${this.baseUrl}Users/WithPaging?PageIndex=${
        PageIndex == 0 ? '' : PageIndex
      }&PageSize=${
        PageSize == 0 ? '' : PageSize
      }&SortOrder=${SortOrder}&SortBy=${SortBy}&FirstName=${firstName}&LastName=${lastName}&StoreName=${StoreName}&Email=${email}&Phone=${phone}&StateName=${stateName}&City=${city}&Zipcode=${zipCode}`
    );
  }

  // get user details by id
  getUserDetailsbyId(userId: number) {
    return this.http.get(this.baseUrl + 'Users/ByUserId/' + userId);
  }

  // update user form
  updateEditUser(value: any) {
    return this.http.patch(this.baseUrl + 'Users', value);
  }

  private handleErrors(response: any) {
    return throwError({ message: response.message });
  }
}
