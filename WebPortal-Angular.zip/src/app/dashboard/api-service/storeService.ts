import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, throwIfEmpty } from 'rxjs/operators';
// import { Store } from '../../dashboard/Models/store';
import { PeriodicElement } from '../admin/user/role-tab/role-tab.component';
import { SnackbarService } from './snackbar/snackbar.service';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

@Injectable()
export class StoreService {
  baseUrl: string = `${environment.base_url}Stores/api/`;
  // baseUrl: string = `${environment.base_url}userstoremanagement/api/`;
  constructor(
    private http: HttpClient,
    private snack: SnackbarService,
    private router: Router,
    private sppiner: NgxSpinnerService
  ) {}

  // store: Store[] = []

  getUserDetails(userId: any) {
    return this.http.get(`${this.baseUrl}Users/ByUserId/${userId}`);
  }
  updateUser(value: any) {
    return this.http.patch(this.baseUrl + 'Users', value);
  }

  saleAgent(
    firstLastName: string,
    mobile: string,
    email: string,
    storeName: string,
    pageIndex: number,
    pageSize: number,
    sortBy: string,
    sortOrder: string
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }SaleAgent/GetAllSaleAgents?Name=${firstLastName}&Mobile=${mobile}&Email=${email}&StoreName=${storeName}&PageIndex=${
        pageIndex == 0 ? '' : pageIndex
      }&PageSize=${
        pageSize == 0 ? '' : pageSize
      }&Sortby=${sortBy}&SortOrder=${sortOrder} `
    );
  }
  getAllSaleAgent() {
    return this.http.get(`${this.baseUrl}SaleAgent/GetAllSaleAgents`);
  }
  createSalesAgent(value: any) {
    return this.http.post(`${this.baseUrl}SaleAgent`, value);
  }

  updateSaleAgent(value: any) {
    return this.http.patch(`${this.baseUrl}SaleAgent`, value);
  }

  getSalesAgentById(saleAgentId: number) {
    return this.http.get(`${this.baseUrl}SaleAgent/${saleAgentId}`);
  }

  getCountry() {
    return this.http.get(this.baseUrl + 'Country');
  }
  getState() {
    return this.http.get(this.baseUrl + 'State');
  }
  getStates(countryId: number) {
    return this.http
      .get(`${this.baseUrl}State/ByCountryId/${countryId}`)
      .pipe(catchError(this.handleErrors.bind(this)));
  }
  getCities(stateId: number) {
    return this.http.get(`${this.baseUrl}City/ByStateId/${stateId}`);
  }

  getCategoryLevelPhone(id: any) {
    return this.http.get(`${this.baseUrl}CategoryTypeLevel/${id}`);
  }
  getCategoryLevelEmail(id: any) {
    return this.http.get(`${this.baseUrl}CategoryTypeLevel/${id}`);
  }
  getCategoryLavelAddress(id: any) {
    return this.http.get(`${this.baseUrl}CategoryTypeLevel/${id}`);
  }
  addStore(value: any) {
    // console.log(value, 'value');
    return this.http.post(`${this.baseUrl}Stores`, value);
  }
  getStore() {
    var companyId = localStorage.getItem('companyId');
    return this.http.get(this.baseUrl + 'Stores/ByCompanyId/' + companyId);
  }
  getCompanyDetails(userId: any) {
    return this.http.get(`${this.baseUrl}Companies/ByUserId/${userId}`);
  }

  // get store by companyId
  getStoreByCompanyId(id: number) {
    return this.http.get(this.baseUrl + 'Stores/ByCompanyId/' + id);
  }
  getStoreByStoreId(id: number) {
    return this.http.get(this.baseUrl + 'Stores/' + id);
  }
  // company ById

  getCompanyByUserId(userId: number) {
    return this.http.get(`${this.baseUrl}Companies/ByUserId/${userId}`);
  }

  getCompanyByCompanyId(companyId: number) {
    return this.http.get(`${this.baseUrl}Companies/ByCompanyId/${companyId}`);
  }

  getCompanyById(companyId: number) {
    return this.http.get(this.baseUrl + 'Companies/ByCompanyId/' + companyId);
  }

  autoSuggestByCompanyName(CompanyName: string) {
    return this.http.get(
      `${this.baseUrl}Companies/CompanyAutoComplete?CompanyName=${CompanyName}`
    );
  }
  autoSuggestByCompanyId(ComapnyId: number) {
    return this.http.get(
      `${this.baseUrl}Companies/CompanyAutoComplete?ComapnyId=${ComapnyId}`
    );
  }
  getCompanyByCompanyName(
    CompanyName: string,
    PageIndex: number,
    PageSize: number
  ) {
    return this.http
      .get(
        `${this.baseUrl}Companies/WithPaging?CompanyName=${CompanyName}&PageIndex=${PageIndex}&PageSize=${PageSize}`
      )
      .pipe(catchError(this.handleErrors.bind(this)));
  }

  getCompanyWithPagging() {
    return this.http
      .get(`${this.baseUrl}Companies/WithPaging`)
      .pipe(catchError(this.handleErrors.bind(this)));
  }
  getCompanyByWithPagging(
    PageIndex: number,
    PageSize: number,
    CompanyName: string,
    City: string,
    StateId: number,
    ZipCode: string
  ) {
    return this.http.get(
      `${this.baseUrl}Companies/WithPaging?PageIndex=${
        PageIndex == 0 ? '' : PageIndex
      }&PageSize=${
        PageSize == 0 ? '' : PageSize
      }&CompanyName=${CompanyName}&City=${City}&StateId=${
        StateId == 0 ? '' : StateId
      }&ZipCode=${ZipCode}`
    );
    // .pipe(catchError(this.handleErrors.bind(this)));
  }

  getAllCompanyByStoreOwner(ownerId: any) {
    return this.http.get(`${this.baseUrl}Companies/${ownerId}`);
  }

  viewStoreSummery(storeId: number) {
    return this.http
      .get(this.baseUrl + 'Stores/' + storeId)
      .pipe(catchError(this.handleErrors.bind(this)));
  }

  getStoreHours(storeId: number) {
    return this.http
      .get(this.baseUrl + 'Stores/Hours/' + storeId)
      .pipe(catchError(this.handleErrors.bind(this)));
  }

  // Owner create
  createOwner(value: any) {
    // console.log(value);
    return this.http.post(`${this.baseUrl}Companies`, value);
  }

  // update owner
  updateOwner(value: any) {
    // console.log(value);
    return this.http.patch(this.baseUrl + 'Companies', value);
  }

  // Store Aminities
  getStoreAmenities() {
    return this.http.get(this.baseUrl + 'Amenity');
  }

  // Region
  getRegion() {
    return this.http.get(this.baseUrl + 'Region');
  }

  // title
  getTitle() {
    return this.http.get(this.baseUrl + 'Title');
  }
  getManager() {
    return this.http.get(this.baseUrl + 'Users/ByEntityId/2?entityName=2');
  }

  // update edit-store form
  updateEditStoreForm(value: any) {
    // console.log(value, 'value');
    return this.http.patch(this.baseUrl + 'Stores', value);
  }
  // get wekendid
  storeWeekenId() {
    return this.http.get(this.baseUrl + 'Stores/WeekDays');
  }
  // store working hours
  StoreWorkingHours(value: any) {
    // console.log(value, 'value');
    return this.http.post(this.baseUrl + 'Stores/Hours', value);
  }
  // get store hours
  getStoreHoursByStoreId(storeId: number) {
    return this.http.get(this.baseUrl + 'Stores/Hours/' + storeId);
  }
  // update store hours
  updateSoreHour(value: any) {
    return this.http.patch(this.baseUrl + 'Stores/Hours/', value);
  }

  // get fuel price
  getFuelPrice(siteId: string) {
    return this.http.get(this.baseUrl + 'PumpProduct/BySiteId/' + siteId);
  }
  // get TimeZone
  getTimeZone() {
    return this.http.get(this.baseUrl + 'TimeZone');
  }

  //get all store
  getStoreWithPaging(
    pageIndex: number,
    pageSize: number,
    sortOrder: string,
    Sortby: string,
    storeId: number,
    storeName: string,
    siteId: string,
    company: string,
    IsOnline: any,
    HeartBeatInterval: number,
    city: string,
    Zipcode: string,
    StateName: string,
    tenantId: number
  ) {
    return this.http.get(
      `${this.baseUrl}Stores/Withpaging?PageIndex=${
        pageIndex == 0 ? '' : pageIndex
      }&PageSize=${
        pageSize == 0 ? '' : pageSize
      }&SortOrder=${sortOrder}&Sortby=${Sortby}&StoreId=${storeId}&StoreName=${storeName}&SiteId=${siteId}&CompanyName=${company}&IsOnline=${
        IsOnline == undefined ? '' : IsOnline
      }&HeartBeatInterval=${HeartBeatInterval}&City=${city}&Zipcode=${Zipcode}&StateName=${StateName}&TenantId=${tenantId}`
    );
    // .pipe(catchError(this.handleErrors.bind(this)));
  }
  getStoreWithPagingg(
    pageIndex: number,
    pageSize: number,
    sortOrder: string,
    Sortby: string,
    storeId: number,
    storeName: string,
    siteId: string,
    company: string,
    IsOnline: any,
    HeartBeatInterval: number,
    city: string,
    Zipcode: string,
    StateName: string,
    tenantId: number[]
  ) {
    let params = new HttpParams();
    params = params.append('AppName', 'SpiTech');
    tenantId.forEach((tenantId) => {
      params = params.append('TenantId', tenantId.toString());
    });
    return this.http.get(
      `${this.baseUrl}Stores/Withpaging?PageIndex=${
        pageIndex == 0 ? '' : pageIndex
      }&PageSize=${
        pageSize == 0 ? '' : pageSize
      }&SortOrder=${sortOrder}&Sortby=${Sortby}&StoreId=${storeId}&StoreName=${storeName}&SiteId=${siteId}&CompanyName=${company}&IsOnline=${
        IsOnline == undefined ? '' : IsOnline
      }&HeartBeatInterval=${HeartBeatInterval}&City=${city}&Zipcode=${Zipcode}&StateName=${StateName}&${params}`
    );
    // .pipe(catchError(this.handleErrors.bind(this)));
  }

  getAllStoreWithPaging() {
    return this.http.get(`${this.baseUrl}Stores/WithPaging`);
  }

  // store billng
  saveStoreBilling(value: any) {
    return this.http.post(`${this.baseUrl}StoreBillingFee`, value);
  }
  getStoreBilling(storeId: number) {
    return this.http.get(
      `${this.baseUrl}StoreBillingFee/ByStoreId?storeId=${storeId}`
    );
  }

  // update storeBilling
  updateStoreBilling(value: any) {
    return this.http.patch(`${this.baseUrl}StoreBillingFee`, value);
  }

  //** get store BySiteId */
  getStoreBySiteId(siteId: string) {
    return this.http.get(
      `${this.baseUrl}Stores/StoreBySiteId?SiteId=${siteId}`
    );
  }
  getStoreAutoCompleteBySiteId(SiteId: string) {
    return this.http.get(
      `${this.baseUrl}Stores/StoreAutoComplete?SiteId=${SiteId}`
    );
  }
  getStoreAutoCompleteByStoreName(StoreName: string) {
    return this.http.get(
      `${this.baseUrl}Stores/StoreAutoComplete?StoreName=${StoreName}`
    );
  }
  getAllCompanies() {
    return this.http.get(`${this.baseUrl}Companies/CompanyAutoComplete`);
  }

  getStoreGroup() {
    return this.http.get(`${this.baseUrl}StoreGroup/StoreGroupAutoComplete`);
  }

  geAlltStoreAutoCompleteByStoreName() {
    return this.http.get(`${this.baseUrl}Stores/StoreAutoComplete`);
  }
  getStoreAutoCompleteByStoreId(storeId: number) {
    return this.http.get(
      `${this.baseUrl}Stores/StoreAutoComplete?StoreId=${storeId}`
    );
  }
  // get pos
  getPosSystem() {
    return this.http.get(`${this.baseUrl}Stores/PosSystem`);
  }

  updateSaleAgentStores(value: any) {
    return this.http.patch(`${this.baseUrl}Stores/UpdateSaleAgent`, value);
  }

  /// Resseler

  getAllReseller(
    name: string,
    mobile: string,
    email: string,
    companyName: string,
    pageIndex: number,
    pageSize: number,
    sortBy: string,
    sortOrder: string
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }Reseller/GetAllResellers?Name=${name}&Mobile=${mobile}&Email=${email}&CompanyName=${companyName}&PageIndex=${
        pageIndex == 0 ? '' : pageIndex
      }&PageSize=${
        pageSize == 0 ? '' : pageSize
      }&SortBy=${sortBy}&SortOrder=${sortOrder}`
    );
  }

  getResellerById(id: number) {
    return this.http.get(`${this.baseUrl}Reseller/${id}`);
  }
  addResellers(value: any) {
    return this.http.post(`${this.baseUrl}Reseller`, value);
  }

  updateResellers(value: any) {
    return this.http.patch(`${this.baseUrl}Reseller`, value);
  }

  updateResellersCompany(value: any) {
    return this.http.patch(`${this.baseUrl}Companies/UpdateReseller`, value);
  }

  getAllStoreOwner(
    firstName: string,
    lastName: string,
    email: string,
    phone: string
  ) {
    return this.http.get(
      `${this.baseUrl}Companies/GetAllOwners?FirstName=${firstName}&LastName=${lastName}&Email=${email}&Phone=${phone}`
    );
  }
  getAllStoreOwners(
    firstName: string,
    lastName: string,
    email: string,
    phone: string,
    sortBy: string,
    sortOrder: string,
    pageIndex: number,
    pageSize: number
  ) {
    return this.http.get(
      `${
        this.baseUrl
      }Companies/GetAllOwners?FirstName=${firstName}&LastName=${lastName}&Email=${email}&Phone=${phone}&sortBy=${sortBy}&sortOrder=${sortOrder}&pageIndex=${
        pageIndex == 0 ? '' : pageIndex
      }&pageSize=${pageSize == 0 ? '' : pageSize}`
    );
  }
  getStoreOwnerId(ownerId: number) {
    return this.http.get(`${this.baseUrl}Companies/${ownerId}`);
  }

  getAllCompany(CompanyName: string) {
    return this.http.get(
      `${this.baseUrl}Companies/WithPaging?CompanyName=${CompanyName}`
    );
  }
  getAllCompanyAutoComplete(CompanyName: string) {
    return this.http.get(
      `${this.baseUrl}Companies/CompanyAutoComplete?CompanyName=${CompanyName}`
    );
  }
  updateOwnerCompany(value: any) {
    return this.http.patch(`${this.baseUrl}Companies/AddOwnerCompanies`, value);
  }

  getAllStoreByCompanyIds(value: any) {
    return this.http.post(`${this.baseUrl}Stores/GetByCompanyIds`, value);
  }

  getAllState() {
    return this.http.get(`${this.baseUrl}State`);
  }
  getStateAutoComplete(stateName: string) {
    return this.http.get(
      `${this.baseUrl}State/StateAutoComplete?StateName=${stateName}`
    );
  }
  addStoreGroup(body: {}) {
    return this.http.post(`${this.baseUrl}StoreGroup`, body);
  }
  updateStoreGroup(body: {}) {
    return this.http.patch(`${this.baseUrl}StoreGroup`, body);
  }
  getStoreGroupById(id: any) {
    return this.http.get(`${this.baseUrl}StoreGroup?StotreGroupId=${id}`);
  }
  getAllStateAutoComplete() {
    return this.http.get(`${this.baseUrl}State/StateAutoComplete`);
  }
  getPowerBi() {
    return this.http.get(
      `https://api.powerbi.com/v1.0/myorg/groups/a5443ea4-a35e-4209-88c9-f5a7c99d74c2/reports`
    );
  }
  getStoreCategory() {
    return this.http.get(`${this.baseUrl}StoreCategory`);
  }
  processExcel(body: any) {
    return this.http.post(`${this.baseUrl}Stores/ProcessStoreExcelData`, body);
  }

  submitExcelData(body: any) {
    return this.http.post(`${this.baseUrl}Stores/SubmitStoreExcelData`, body);
  }
  getStoreCountOnDashboard() {
    return this.http.get(`${this.baseUrl}Stores/StoreCount`);
  }
  private handleErrors(err: any) {
    if (err.status == 500) {
      // this.toster.error('Inetnal server error');
      this.router.navigate(['/error']);
    }
    this.sppiner.hide();
    return throwError({ err });
  }
}
