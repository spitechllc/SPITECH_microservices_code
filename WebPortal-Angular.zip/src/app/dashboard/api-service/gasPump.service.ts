import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, throwIfEmpty } from 'rxjs/operators';

import { environment } from 'src/environments/environment';

@Injectable()
export class GasPumpService {
  baseUrl: string = `${environment.base_url}mppa/api/`;
  constructor(private http: HttpClient) {}

  //get Gas Pump details
  getGasPump(storeId: number) {
    return this.http
      .get(this.baseUrl + 'GasPump/ByStoreId/' + storeId)
      .pipe(catchError(this.handleErrors.bind(this)));
  }

  // get pos details
  getPos(storeId: number) {
    return this.http
      .get(this.baseUrl + 'POS/ByStoreId/' + storeId)
      .pipe(catchError(this.handleErrors.bind(this)));
  }

  hostConfig(value: any) {
    // console.log(value, 'value');
    return this.http
      .post(this.baseUrl + 'HostConfigration', value)
      .pipe(catchError(this.handleErrors.bind(this)));
  }

  getadapter() {
    return this.http
      .get(this.baseUrl + 'HostConfigration/Adapter')
      .pipe(catchError(this.handleErrors.bind(this)));
  }

  // getauthentication() {
  //   return this.http.get(this.baseUrl + 'HostConfigration/AuthenticationType');
  // }
  // getFrequencyUnit() {
  //   return this.http.get(this.baseUrl + 'HostConfigration/FrequencyUnit');
  // }
  // getSiteLoyality() {
  //   return this.http.get(this.baseUrl + 'HostConfigration/SiteLoyality');
  // }

  posConfiguration(value: any) {
    return this.http
      .post(this.baseUrl + 'POS', value)
      .pipe(catchError(this.handleErrors.bind(this)));
  }
  // get pos by postId
  getPosById(postId: number) {
    return this.http.get(this.baseUrl + 'POS/' + postId);
  }
  // edit pos system
  updatePos(value: any) {
    return this.http
      .patch(this.baseUrl + 'POS', value)
      .pipe(catchError(this.handleErrors.bind(this)));
  }
  // get gasPump by storeId
  getGasPumpBYStoreId(storeId: number) {
    return this.http.get(`${this.baseUrl}GasPump/ByStoreId?StoreId=${storeId}`);
  }
  // gas pump configuration
  gaPumpConfiguration(value: any) {
    return this.http.post(this.baseUrl + 'GasPump', value);
  }
  //get gasPump by gasPumpID
  getGasPumpBYGasPumpId(gasPumpId: number) {
    return this.http.get(this.baseUrl + 'GasPump/' + gasPumpId);
  }

  // update gasPump configuratation
  updateGasPump(value: any) {
    return this.http.patch(this.baseUrl + 'GasPump', value);
  }
  // fuel price
  getFuelPrice(siteId: number) {
    return this.http.get(this.baseUrl + 'SiteProduct/BySiteId/' + siteId);
  }

  // EOD Settlement Report
  report(SiteId: string, StartDateUtc: string, EndDateUtc: string) {
    return this.http.get(
      `${this.baseUrl}Transaction/Settlement?SiteId=${SiteId}&StartDateUtc=${StartDateUtc}&EndDateUtc=${EndDateUtc}`
    );
  }

  getSystemStatus(siteId: string) {
    return this.http.get(this.baseUrl + 'Commander/Status/' + siteId);
  }

  getCommamderMessage(
    PageIndex: number,
    PageSize: number,
    From: string,
    To: string,
    RequestType: string,
    Utmi: string,
    transactionId: number,
    MerchantId: string,
    siteId: string,
    sortBy: string,
    sortOrder: string
  ) {
    return this.http.get(
      `${this.baseUrl}Commander/messages?PageIndex=${PageIndex}&PageSize=${PageSize}&From=${From}&To=${To}&RequestType=${RequestType}&UMTI=${Utmi}&SiteId=${siteId}&MerchantId=${MerchantId}&TransactionId=${transactionId}&SortBy=${sortBy}&SortOrder=${sortOrder}`
    );
  }

  private handleErrors(response: any) {
    // alert(response.message);
    return throwError({ message: response });
  }
}
