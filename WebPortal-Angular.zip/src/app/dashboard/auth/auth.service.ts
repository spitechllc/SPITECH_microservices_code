import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  roleList!: any;

  constructor() {}

  setRole(roles: any) {
    // console.log(roles, 'roles');
    this.roleList = roles;
    if (this.roleList) {
      const roles = this.getRols();
    }
    // console.log(this.roleList);
  }

  getClaims() {
    let claims: any = [];
    // console.log(this.roleList, 'rolelist');

    this.roleList.forEach((element: any) => {
      claims.push(element.claims.map(this.transformClaims));
    });

    return claims.flat();
  }

  getRols() {
    let roles: any = [];
    this.roleList?.forEach((element: any) => {
      roles.push(element.roleId);
    });

    return roles.flat();
  }

  getRolesLength() {
    return this.roleList.length ? this.roleList.length : 0;
  }

  transformClaims(claim: any) {
    return claim.claimId;
  }

  public getToken() {
    return localStorage.getItem('token');
  }
}
