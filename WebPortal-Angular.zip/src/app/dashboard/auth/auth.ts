import { AuthWellKnownEndpoints, OidcSecurityService, OpenIdConfiguration } from "angular-auth-oidc-client";

export class Auth {
    constructor(public oidcSecurityService: OidcSecurityService) {}



//     const openIdConfiguration: OpenIdConfiguration = {

//         // stsServer: this.authUrl,
//         // redirect_url: this.originUrl + 'callback',
//         // client_id: 'spaCodeClient',
//         // response_type: 'code',
//         // scope: 'openid profile resourceApi',
//         // post_logout_redirect_uri: this.originUrl,
//         // forbidden_route: '/forbidden',
//         // unauthorized_route: '/unauthorized',
//         // silent_renew: true,
//         // silent_renew_url: this.originUrl + '/silent-renew.html',
//         // history_cleanup_off: true,
//         // auto_userinfo: true,
//         // log_console_warning_active: true,
//         // log_console_debug_active: true,
//         // max_id_token_iat_offset_allowed_in_seconds: 10,
//     };
 
//     const authWellKnownEndpoints: AuthWellKnownEndpoints = {
//         // issuer: this.authUrl,
//         // jwks_uri: this.authUrl + '/.well-known/openid-configuration/jwks',
//         // authorization_endpoint: this.authUrl + '/connect/authorize',
//         // token_endpoint: this.authUrl + '/connect/token',
//         // userinfo_endpoint: this.authUrl + '/connect/userinfo',
//         // end_session_endpoint: this.authUrl + '/connect/endsession',
//         // check_session_iframe: this.authUrl + '/connect/checksession',
//         // revocation_endpoint: this.authUrl + '/connect/revocation',
//         // introspection_endpoint: this.authUrl + '/connect/introspect',
//     };
 
//     // this.oidcSecurityService.setupModule(openIdConfiguration, authWellKnownEndpoints);
// }
}