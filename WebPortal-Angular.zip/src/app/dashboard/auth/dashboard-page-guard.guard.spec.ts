import { TestBed } from '@angular/core/testing';

import { DashboardPageGuardGuard } from './dashboard-page-guard.guard';

describe('DashboardPageGuardGuard', () => {
  let guard: DashboardPageGuardGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(DashboardPageGuardGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
