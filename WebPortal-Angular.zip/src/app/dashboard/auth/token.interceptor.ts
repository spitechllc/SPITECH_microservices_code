import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse,
} from '@angular/common/http';
import { AuthService } from './auth.service';
import { Observable, from, throwError, of } from 'rxjs';
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { catchError } from 'rxjs/operators';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { IdentityService } from '../api-service/identityService';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root',
})
export class TokenInterceptor implements HttpInterceptor {
  constructor(
    public oidcSecurityService: OidcSecurityService,
    private router: Router,
    private sppiner: NgxSpinnerService,
    private auth: AuthService,
    private toster: ToastrService
  ) {}
  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    request = request.clone({
      setHeaders: {
        Authorization: `Bearer ${this.oidcSecurityService.getToken()}`
      },
    });
    return next
      .handle(request)
      .pipe(catchError((x: any) => this.handleAuthError(x)));
  }

  private handleAuthError(err: HttpErrorResponse): Observable<any> {
    //handle your auth error or rethrow
    this.sppiner.hide();

    if (err.status == 401) {
      this.oidcSecurityService.logoff();
      this.oidcSecurityService.authorize();
      this.router.navigate(['/']);
    }

    if (err.error.error == 'invalid_grant') {
      this.oidcSecurityService.logoff();
    }

    if (err.status == 500) {
      this.toster.error('Internal server error Status:500');
    }
    if (err.status == 404) {
      this.toster.error('Resource not found Status:404');
    }

    return throwError(err);
  }
}
