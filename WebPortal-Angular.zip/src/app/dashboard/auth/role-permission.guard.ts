import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  RouterStateSnapshot,
  UrlTree,
} from '@angular/router';
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { IdentityService } from '../api-service/identityService';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root',
})
export class RolePermissionGuard implements CanActivate {
  constructor(
    private indentityService: IdentityService,
    private router: Router,
    public oidcSecurityService: OidcSecurityService,
    private auth: AuthService,
    private toster: ToastrService
  ) {}
  roleDetails: any;

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
    let url: string = state.url;
    return this.checkRoutePermission(next, url);
  }

  checkRoutePermission(route: ActivatedRouteSnapshot, url: any): boolean {
    const userClaims = this.auth.getClaims();
    // const userClaims = localStorage.getItem('clams');
    // const roels = this.auth.getRols();
    // console.log(userClaims);
    const claimExists = userClaims?.includes(route.data.claimId);

    if (route.data.claimId && !claimExists) {
      // snc
      this.toster.error('You are not authorized');
      this.router.navigate([this.router.url]);
      return false;
    }
    return true;
  }
}
