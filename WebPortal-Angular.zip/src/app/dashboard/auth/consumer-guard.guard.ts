import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  RouterStateSnapshot,
  UrlTree,
} from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ConsumerGuardGuard implements CanActivate {
  userType = localStorage.getItem('userTypeId');
  constructor(private router: Router) {}
  userType1 = 1;
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): any {
    // console.log(route ,state ,"state")
    // this.userType1 =
    // return !AuthUttils.getAuthDetails();
    // const isLoggedIn = localStorage.getItem('token');
    if (this.userType == '1') {
      // this.router.navigate(['consumer/my-profile'])
      // this.router.navigateByUrl('consumer/my-profile')
      return true;
    } else {
      return false;
    }
  }
}
