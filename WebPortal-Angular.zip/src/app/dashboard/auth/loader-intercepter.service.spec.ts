import { TestBed } from '@angular/core/testing';

import { LoaderIntercepterService } from './loader-intercepter.service';

describe('LoaderIntercepterService', () => {
  let service: LoaderIntercepterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LoaderIntercepterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
