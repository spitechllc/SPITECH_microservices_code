import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  RouterStateSnapshot,
  UrlTree,
} from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AdminGuardGuard implements CanActivate {
  userType = localStorage.getItem('userTypeId');

  userType1 = 1;
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): any {
    // console.log(route ,state ,"state")
    // this.userType1 =
    // return !AuthUttils.getAuthDetails();
    // const isLoggedIn = !!AuthUttils.getAuthDetails();
    if (this.userType == '2') {
      // this.router.navigate(['dashboard'])
      return true;
    } else {
      return false;
    }
  }
}
