import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  RouterStateSnapshot,
  UrlTree,
} from '@angular/router';
import { Observable } from 'rxjs';
import { IdentityService } from '../api-service/identityService';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root',
})
export class DashboardPageGuardGuard implements CanActivate {
  constructor(
    private auth: AuthService,
    private indentityService: IdentityService
  ) {}
  userDetails: any;
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): any {
    const roles = this.auth.getRols();

    this.indentityService.getuserdetails().subscribe((data: any) => {
      this.userDetails = data;
    });

    // console.log(roles);
    if (this.userDetails) {
      return true;
    } else {
      return false;
    }
  }
}
