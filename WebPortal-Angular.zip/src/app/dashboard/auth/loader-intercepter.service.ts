import { Injectable } from '@angular/core';

import {
  HttpResponse,
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
} from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { NgxSpinnerService } from 'ngx-spinner';
import { finalize } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class LoaderIntercepterService {
  private requests: HttpRequest<any>[] = [];
  private signalR = new BehaviorSubject<any>(false);
  signalRsub = this.signalR.asObservable();
  onSignalR(signalRsub: any) {
    console.log(signalRsub);
    this.signalR.next(signalRsub);
  }
  constructor(private spinner: NgxSpinnerService) {
    this.signalRsub.subscribe((data: any) => {
      this.singnalRData = data;
    });
  }
  singnalRData: any;
  requestLength: any;
  removeRequest(req: HttpRequest<any>) {
    const i = this.requests.indexOf(req);
    // console.log(i);
    if (i > 0) {
      this.requests.splice(i, 1);
    }
    // if (this.requests.length <= 0) {
    //   this.spinner.hide();
    // }
    this.spinner.hide();
  }

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    this.requests.push(req);
    this.requestLength = this.requests.length;
    // console.log('No of requests--->' + this.requests.length);

    // if (
    //   req.url.includes(
    //     `${environment.base_url}/transactions/api/Dashboard/TransactionDetails`
    //   )
    // ) {
    //   return next.handle(req);
    // }
    this.spinner.show();
    return Observable.create((observer: any) => {
      const subscription = next.handle(req).subscribe(
        (event) => {
          if (event instanceof HttpResponse) {
            this.removeRequest(req);
            observer.next(event);
          }
        },
        (err) => {
          this.removeRequest(req);
          observer.error(err);
        },
        () => {
          this.removeRequest(req);
          observer.complete();
        }
      );

      return () => {
        this.removeRequest(req);
        subscription.unsubscribe();
      };
    });
  }
}
