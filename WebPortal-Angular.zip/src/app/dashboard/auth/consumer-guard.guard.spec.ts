import { TestBed } from '@angular/core/testing';

import { ConsumerGuardGuard } from './consumer-guard.guard';

describe('ConsumerGuardGuard', () => {
  let guard: ConsumerGuardGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(ConsumerGuardGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
