import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { IdentityService } from '../api-service/identityService';

@Injectable({
  providedIn: 'root',
})
export class SharedService {
  constructor(private identityService: IdentityService) {}
  tenantData: any;
  tenantDropDown: boolean = true;
  tenantId: any;
  tenantName: any;
  getTenant(tenantData: any) {
    this.tenantData = tenantData;
  }

  getTenantId(tenantId: any) {
    this.tenantId = tenantId;
    if (tenantId > 0) {
      this.tenantDropDown = false;
    } else if (tenantId == 0) {
      this.tenantDropDown = true;
    }
    this.getTenantName(tenantId);
  }

  getTenantName(tenantId: any) {
    this.tenantData.filter((tenant: any) => {
      if (tenant.tenantId == tenantId) {
        this.tenantName = tenant.tenantName;
        return tenant.tenantName;
      }
    });
  }
  private storeDetails = new BehaviorSubject<any>('');
  storeDataDetails = this.storeDetails.asObservable();
  onClickStore(data: any) {
    this.storeDetails.next(data);
  }
  private showActiveClass = new BehaviorSubject<boolean>(false);
  showActive = this.showActiveClass.asObservable();
  onClickMobileView(data: any) {
    // console.log(data);
    this.showActiveClass.next(data);
  }
  private startDate = new BehaviorSubject<any>('');
  startDates = this.startDate.asObservable();
  onClickStart(startDates: any) {
    // console.log(startDates);
    this.startDate.next(startDates);
  }
  private endDate = new BehaviorSubject<any>('');
  endDates = this.endDate.asObservable();
  onClickEndDate(endDates: any) {
    // console.log(endDates);
    this.endDate.next(endDates);
  }
  // private store = new BehaviorSubject<any>(null);
  // stores = this.store.asObservable();
  // onClickStores(endDates: any) {
  //   console.log(endDates);
  //   this.store.next(endDates);
  // }
  private zipCode = new BehaviorSubject<string>('');
  zipcodes = this.zipCode.asObservable();
  onClickZipCode(zipcodes: any) {
    // console.log(zipcodes);
    this.zipCode.next(zipcodes);
  }
  private city = new BehaviorSubject<string>('');
  cities = this.city.asObservable();
  onClickCity(cities: any) {
    // console.log(cities);
    this.city.next(cities);
  }
  private state = new BehaviorSubject<any>(0);
  states = this.state.asObservable();
  onClickState(states: any) {
    // console.log(states);
    this.state.next(states);
  }
  private companyIds = new BehaviorSubject<any>(0);
  companies = this.companyIds.asObservable();
  onClickCompany(companyId: any) {
    // console.log(companyId);
    this.companyIds.next(companyId);
  }
  private tabValue = new BehaviorSubject<any>(1);
  tabValues = this.tabValue.asObservable();
  onClickTab(companyId: any) {
    // console.log(companyId);
    this.tabValue.next(companyId);
  }
  private storeId = new BehaviorSubject<any>(0);
  storeIds = this.storeId.asObservable();
  onClickStores(storeIds: any) {
    // console.log(storeIds);
    this.storeId.next(storeIds);
  }
  private appId = new BehaviorSubject<any>(0);
  appIds = this.appId.asObservable();
  onClickApp(appIds: any) {
    console.log(appIds);
    this.appId.next(appIds);
  }

  private store = new BehaviorSubject<any>(false);
  storeSection = this.store.asObservable();
  onClickStoreSelection(storeSection: any) {
    // console.log(storeSection);
    this.store.next(storeSection);
  }
  private dataRefresh = new BehaviorSubject<any>(false);
  dataRefreshs = this.dataRefresh.asObservable();
  onClickDataRefresh(dataRefreshs: any) {
    // console.log(dataRefreshs);
    this.dataRefresh.next(dataRefreshs);
  }
  private company = new BehaviorSubject<any>(false);
  companySection = this.company.asObservable();
  onClickCompanySelection(companySection: any) {
    // console.log(companySection);
    this.company.next(companySection);
  }
  private stateSelcetion = new BehaviorSubject<any>(false);
  stateSection = this.stateSelcetion.asObservable();
  onClickStateSelection(stateSection: any) {
    // console.log(stateSection);
    this.stateSelcetion.next(stateSection);
  }
  private zipCodeSelection = new BehaviorSubject<any>(false);
  zipcodeSection = this.zipCodeSelection.asObservable();
  onClickZipCodeSelection(zipcodeSection: any) {
    // console.log(zipcodeSection);
    this.zipCodeSelection.next(zipcodeSection);
  }
  private storeGroupSelction = new BehaviorSubject<any>(false);
  storeGroupSection = this.storeGroupSelction.asObservable();
  onClickStoreGroupSelection(storeGroupSection: any) {
    // console.log(storeGroupSection);
    this.storeGroupSelction.next(storeGroupSection);
  }
  private citySelection = new BehaviorSubject<any>(false);
  citySelections = this.citySelection.asObservable();
  onClickCitySelection(citySelections: any) {
    // console.log(citySelections);
    this.citySelection.next(citySelections);
  }
  private StartDateSelection = new BehaviorSubject<any>(false);
  startDateSelections = this.StartDateSelection.asObservable();
  onClickStartDateSelection(startDateSelections: any) {
    // console.log(startDateSelections);
    this.StartDateSelection.next(startDateSelections);
  }
  private EndDateSelection = new BehaviorSubject<any>(false);
  endDateSelections = this.EndDateSelection.asObservable();
  onClickEndDateSelection(endDateSelections: any) {
    // console.log(endDateSelections);
    this.EndDateSelection.next(endDateSelections);
  }
  private storeGroup = new BehaviorSubject<any>(0);
  storeGroupIds = this.storeGroup.asObservable();
  onClickStoreGroup(storeGroupIds: any) {
    // console.log(storeGroupIds);
    this.storeGroup.next(storeGroupIds);
  }
  private dashfull = new BehaviorSubject<any>(false);
  dashboardFull = this.dashfull.asObservable();
  onClickDashBoard(dashboardFull: any) {
    // console.log(dashboardFull);
    this.dashfull.next(dashboardFull);
  }
  private storeUserData = new BehaviorSubject<any>('');
  userDataStore = this.storeUserData.asObservable();
  onStoreUSer(userDataStore: any) {
    // console.log(userDataStore);
    this.storeUserData.next(userDataStore);
  }
}
