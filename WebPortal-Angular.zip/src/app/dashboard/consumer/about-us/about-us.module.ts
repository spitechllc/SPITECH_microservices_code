import { NgModule } from '@angular/core';
import { SharedModule } from './../../../shared.module';
import { AboutUsComponent } from './about-us.component';
import { RouterModule, Routes } from '@angular/router';


export const router: Routes = [
  {path: '', component: AboutUsComponent }
]


@NgModule({
    declarations: [AboutUsComponent],
    imports: [
        SharedModule,
        RouterModule.forChild(router)
    ]
})
export class AboutUsModule { }