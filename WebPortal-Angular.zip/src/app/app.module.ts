import { BrowserModule } from '@angular/platform-browser';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { SharedModule } from './shared.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { MenuModule } from './dashboard/menu/menu.module';
import { HeaderModule } from './dashboard/header/header.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { StoreService } from './dashboard/api-service/storeService';
import { UserService } from './dashboard/api-service/userService';
import { GasPumpService } from './dashboard/api-service/gasPump.service';
import { TokenInterceptor } from './dashboard/auth/token.interceptor';
import { IdentityService } from './dashboard/api-service/identityService';
import { HelpSupportService } from './dashboard/api-service/helpSupport.service';
import { PaymentService } from './dashboard/api-service/payment.srvice';
import { TransactionService } from './dashboard/api-service/trasation.service';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { MarketingService } from './dashboard/api-service/marketing.service';
import { ReportsService } from './dashboard/api-service/report.service';

import { GooglePlaceModule } from 'ngx-google-places-autocomplete';
import { MomentPipePipe } from './dashboard/pipe/moment-pipe.pipe';
import { FinanceService } from './dashboard/api-service/finance.service';
import { AuthModule, OidcConfigService } from 'angular-auth-oidc-client';
import { DashboardPageModule } from './dashboard/dashboard-page/dashboard-page.module';
import { NoficationService } from './dashboard/api-service/nofication.service';
import { ToastrModule } from 'ngx-toastr';
import { environment } from 'src/environments/environment';
import { LoaderIntercepterService } from './dashboard/auth/loader-intercepter.service';
import { ConstantService } from './dashboard/api-service/constant/constant.service';
import { HubConnectionFactory } from '@ssv/signalr-client';
export function configureAuth(oidcConfigService: OidcConfigService) {
  return () =>
    oidcConfigService.withConfig({
      clientId: `${environment.clientId}`,
      stsServer: `${environment.stsServer}`,
      responseType: 'code',
      redirectUrl: `${environment.redirectUrl}`,
      postLogoutRedirectUri: `${environment.postLogoutRedirectUri}`,

      scope:
        ' profile  openid userstoreapi IdentityServerApi  mppaapi paymentapi transactionapi financeapi marketingapi reportapi notificationapi helpsupportapi',
    });
}
@NgModule({
  declarations: [AppComponent, MomentPipePipe],

  imports: [
    BrowserModule,
    SharedModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    MenuModule,
    HeaderModule,
    DashboardPageModule,
    ReactiveFormsModule,
    HttpClientModule,
    Ng2SearchPipeModule,
    GooglePlaceModule,

    AuthModule.forRoot(),
    ToastrModule.forRoot({
      // timeOut: 50000,
      positionClass: 'toast-top-center',
      preventDuplicates: true,
      progressBar: true,
      closeButton: false,
    }),

    // NoSanitizePipe
  ],
  providers: [
    StoreService,
    UserService,
    TransactionService,
    MarketingService,
    ReportsService,
    PaymentService,
    GasPumpService,
    HelpSupportService,
    IdentityService,
    FinanceService,
    NoficationService,
    OidcConfigService,
    ConstantService,
    { provide: HubConnectionFactory },
    {
      provide: APP_INITIALIZER,
      useFactory: configureAuth,
      deps: [OidcConfigService],
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: LoaderIntercepterService,
      multi: true,
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}

