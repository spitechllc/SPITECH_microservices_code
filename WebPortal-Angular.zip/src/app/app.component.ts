import { HostListener, Component } from '@angular/core';
import { Router } from '@angular/router';
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { NgxSpinnerService } from 'ngx-spinner';
import { IdentityService } from './dashboard/api-service/identityService';
import { AuthService } from './dashboard/auth/auth.service';
import { LoaderIntercepterService } from './dashboard/auth/loader-intercepter.service';
import { SharedService } from './dashboard/auth/shared.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'SpiTech';
  userDetails: any;
  displayName: any;
  userType: any;
  photoUrl: any;
  fullScreen: string = 'true';
  constructor(
    public oidcSecurityService: OidcSecurityService,
    private router: Router,
    private indentityService: IdentityService,
    private auth: AuthService,
    private spinner: NgxSpinnerService,
    private sharedService: SharedService,
    private loder: LoaderIntercepterService
  ) {
    // window.addEventListener('beforeunload', (event) => {
    //   event.preventDefault();
    //   event.returnValue = 'Unsaved modifications';
    //   return event;
    // });
  }
  dashboardFull: boolean = false;
  sppinerShow: boolean = false;
  ngOnInit(): void {
    this.oidc();
    this.sharedService.dashboardFull.subscribe((data: any) => {
      this.dashboardFull = data;
    });
    this.loder.signalRsub.subscribe((data: any) => {
      this.sppinerShow = data;
    });
    this.sharedService.showActive.subscribe((data: any) => {
      if (data == true) {
        this.active = true;
      } else if (data == false) {
        this.active = false;
      }
    });
  }
  active: boolean = false;

  // @HostListener('click', ['$event'])
  // onClick(e: any) {
  //   console.log(e);
  //   window.close();
  //   this.oidcSecurityService.logoff();
  // }

  oidc() {
    this.spinner.show();
    this.oidcSecurityService.checkAuth().subscribe(
      (auth) => {
        const token = this.oidcSecurityService.getToken();
        localStorage.setItem('token', token);

        if (auth == false) {
          this.spinner.show();
          this.login();
        }
        if (auth == true) {
          this.spinner.show();
          this.getAccountDetails();
        }
        // this.getAccountDetails();
      },
      (err) => {}
    );
  }

  login() {
    // console.log('login');
    this.oidcSecurityService.authorize();
    this.spinner.hide();
  }

  getAccountDetails() {
    this.indentityService.getuserdetails().subscribe(
      (data: any) => {
        this.userDetails = data.data;

        sessionStorage.setItem('activeSession', 'true');
        this.auth.setRole(this.userDetails.roles);
        this.displayName = this.userDetails.displayName;
        this.userType = this.userDetails.userTypeId;
        this.photoUrl = this.userDetails.userProfile.photoUrl;
        localStorage.setItem(
          'companyName',
          this.userDetails.userProfile.company
        );
        localStorage.setItem('userTypeId', this.userType);
        localStorage.setItem('displayName', this.displayName);
        localStorage.setItem('userId', this.userDetails.userId);
        localStorage.setItem(
          'companyId',
          this.userDetails.userProfile.companyId
        );
        localStorage.setItem('storeId', this.userDetails.userProfile.storeId);
        this.sharedService.onStoreUSer(this.userDetails);
        this.spinner.hide();
        this.router.navigate(['/'], {
          queryParams: {
            login: 'true',
          },

          queryParamsHandling: 'merge',
        });
      },
      (err) => {
        console.log(err);
      }
    );
  }

  // logout() {
  //   this.oidcSecurityService.logoff();
  // }
}
