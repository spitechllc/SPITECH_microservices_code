import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AdminGuardGuard } from './dashboard/auth/admin-guard.guard';
import { ConsumerGuardGuard } from './dashboard/auth/consumer-guard.guard';
import { RolePermissionGuard } from './dashboard/auth/role-permission.guard';

const routes: Routes = [
  // {
  //   path: '',
  //   component: DashboardPageComponent,
  //   canActivate: [AdminGuardGuard, RolePermissionGuard],
  // },
  // {
  //   path: '',

  //   //
  //   loadChildren: () =>
  //     import('./dashboard/admin/user/user.module').then((m) => m.UserModule),
  // },
  // {
  //   path: 'admin/DashBoard',
  //   canActivate: [AdminGuardGuard, RolePermissionGuard],
  //   //
  //   loadChildren: () =>
  //     import('./dashboard/dashboard-page/dashboard-page.module').then(
  //       (m) => m.DashboardPageModule
  //     ),
  // },
  {
    path: 'error',
    canActivate: [AdminGuardGuard, RolePermissionGuard],
    //
    loadChildren: () =>
      import('./dashboard/error-page/error-page.module').then(
        (m) => m.ErrorPageModule
      ),
  },
  {
    path: 'admin/user',
    canActivate: [AdminGuardGuard, RolePermissionGuard],
    //
    loadChildren: () =>
      import('./dashboard/admin/user/user.module').then((m) => m.UserModule),
  },
  {
    path: 'edit-profile',
    loadChildren: () =>
      import('./dashboard/header/edit-profile/edit-profile.module').then(
        (m) => m.EditProfileModule
      ),
  },
  {
    path: 'admin/process-excel-data',
    loadChildren: () =>
      import(
        './dashboard/admin/process-excel-data/process-excel-data.module'
      ).then((m) => m.ProcessExcelDataModule),
  },
  // {
  //   path: 'admin/user',
  //   loadChildren: () => import('./dashboard/admin/user/user.module').then(m => m.UserModule)
  // },
  // {
  //   path: 'admin/user/edit-roles',
  //   loadChildren: () => import('./dashboard/admin/user/edit-role/edit-role.module').then(m => m.EditRoleModule)
  // },

  // {
  //   path: 'admin/user/edit-user',
  //   loadChildren: () =>
  //     import('./dashboard/admin/user/edit-user/edit-user.module').then(
  //       (m) => m.EditUsereModule
  //     ),
  // },
  {
    path: 'admin/user/add-user',
    loadChildren: () =>
      import('./dashboard/admin/user/add-edit-user/add-edit-user.module').then(
        (m) => m.AddEditUserModule
      ),
  },

  {
    path: 'admin/user/edit-user/:id',
    loadChildren: () =>
      import('./dashboard/admin/user/add-edit-user/add-edit-user.module').then(
        (m) => m.AddEditUserModule
      ),
  },

  {
    path: 'admin/user/create-user',
    canActivate: [AdminGuardGuard],
    loadChildren: () =>
      import('./dashboard/admin/user/create-user/create-user.module').then(
        (m) => m.CreateUserModule
      ),
  },
  {
    path: 'admin/stores-owner',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import('./dashboard/admin/store/store.module').then((m) => m.StoreModule),
  },

  {
    path: 'consumer-profile',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import('./dashboard/admin/consumer-profile/consumer-profile.module').then(
        (m) => m.ConsumerProfileModule
      ),
  },

  {
    path: 'admin/business-user',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import('./dashboard/admin/business-user/business-user.module').then(
        (m) => m.BusinessUserModule
      ),
  },
  {
    path: 'admin/cashrewardsetup',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import(
        './dashboard/admin/cash-reward-setup/cash-reward-setup.module'
      ).then((m) => m.CashRewardSetupModule),
  },
  {
    path: 'admin/promotion',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import('./dashboard/admin/promotion/promotion.module').then(
        (m) => m.PromotionModule
      ),
  },
  {
    path: 'admin/stores-owner/create-owner',
    loadChildren: () =>
      import('./dashboard/admin/store/create-owner/create-owner.module').then(
        (m) => m.CreateOwnerModule
      ),
  },
  {
    path: 'admin/system-status/create-owner',
    loadChildren: () =>
      import('./dashboard/admin/store/create-owner/create-owner.module').then(
        (m) => m.CreateOwnerModule
      ),
  },

  {
    path: 'admin/stores-owner/add-store',
    canActivate: [AdminGuardGuard],

    loadChildren: () =>
      import('./dashboard/admin/store/create-store/create-store.module').then(
        (m) => m.CreateStoreModule
      ),
  },

  {
    path: 'admin/sales-agent/edit-sales-agent/:saleAgentId/add-store/edit',
    canActivate: [AdminGuardGuard],

    loadChildren: () =>
      import('./dashboard/admin/store/create-store/create-store.module').then(
        (m) => m.CreateStoreModule
      ),
  },
  {
    path: 'admin/system-status/add-store/edit/',
    canActivate: [AdminGuardGuard],

    loadChildren: () =>
      import('./dashboard/admin/store/create-store/create-store.module').then(
        (m) => m.CreateStoreModule
      ),
  },
  {
    path: 'admin/stores-owner/manage-store',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import('./dashboard/admin/store/manage-store/manage-store.module').then(
        (m) => m.ManageStoreModule
      ),
  },
  {
    path: 'admin/stores-owner/add-store/edit/manage-store',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import('./dashboard/admin/store/manage-store/manage-store.module').then(
        (m) => m.ManageStoreModule
      ),
  },
  {
    path: 'admin/system-status/manage-store',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import('./dashboard/admin/store/manage-store/manage-store.module').then(
        (m) => m.ManageStoreModule
      ),
  },
  // {
  //   path: 'admin/stores-owner/manage-store/edit-pos',
  //   loadChildren: () => import('./dashboard/admin/store/manage-store/edit-pos-station-configuration/edit-pos-station.module').then(m => m.EditPosModule)
  // },
  // {

  {
    path: 'admin/stores-owner/store-summary',
    canActivate: [AdminGuardGuard, RolePermissionGuard],
    loadChildren: () =>
      import('./dashboard/admin/store/store-summary/store-summary.module').then(
        (m) => m.StoreSummaryModule
      ),
  },
  {
    path: 'admin/tutorials',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import('./dashboard/admin/tutorials/tutorials.module').then(
        (m) => m.TutorialsModule
      ),
  },
  {
    path: 'admin/Inhouseonboard',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import('./dashboard/admin/inhouseonboard/inhouseonboard.module').then(
        (m) => m.InhouseonboardModule
      ),
  },

  {
    path: 'admin/tutorials/create-tutorial',
    loadChildren: () =>
      import(
        './dashboard/admin/tutorials/create-tutorial/create-tutorial.module'
      ).then((m) => m.CreateTutorialModule),
  },
  {
    path: 'admin/tutorials/edit-tutorial',
    canActivate: [AdminGuardGuard, RolePermissionGuard],
    loadChildren: () =>
      import(
        './dashboard/admin/tutorials/edit-tutorials/edit-tutorials.modules'
      ).then((m) => m.EditTutorialStoreModule),
  },
  {
    path: 'admin/car-cash-codes',
    canActivate: [AdminGuardGuard],
    loadChildren: () =>
      import('./dashboard/admin/car-wash-codes/car-wash-codes.module').then(
        (m) => m.CarWashCodesModule
      ),
  },
  {
    path: 'admin/car-cash-codes/create-car-wash-code',
    loadChildren: () =>
      import(
        './dashboard/admin/car-wash-codes/create-car-wash-code/create-car-wash-code.module'
      ).then((m) => m.CreateCarWashCodeModule),
  },
  {
    path: 'admin/system-status',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import('./dashboard/admin/system-status/system-status.module').then(
        (m) => m.SystemStatusModule
      ),
  },
  {
    path: 'admin/system-status/add-store/edit/:storeId',
    canActivate: [AdminGuardGuard],

    loadChildren: () =>
      import('./dashboard/admin/store/create-store/create-store.module').then(
        (m) => m.CreateStoreModule
      ),
  },
  {
    path: 'admin/app-configuration',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import(
        './dashboard/admin/app-configuration/app-configuration.module'
      ).then((m) => m.AppConfigurationModule),
  },
  {
    path: 'admin/appilication-suport',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import(
        './dashboard/admin/application-support/application-support.module'
      ).then((m) => m.ApplicationSupportModule),
  },
  {
    path: 'activity',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import('./dashboard/admin/activity/activity.module').then(
        (m) => m.ActivityModule
      ),
  },
  {
    path: 'admin/app-notification-message',
    canActivate: [AdminGuardGuard, RolePermissionGuard],
    //
    loadChildren: () =>
      import(
        './dashboard/admin/app-notification-message/app-notification-message.module'
      ).then((m) => m.AppNotificationMessageModule),
  },
  {
    path: 'admin/app-notification-message/edit/:id',
    loadChildren: () =>
      import(
        './dashboard/admin/app-notification-message/edit-notification/edit-notification.module'
      ).then((m) => m.EditNotificationModule),
  },
  {
    path: 'admin/sales-agent',
    canActivate: [AdminGuardGuard, RolePermissionGuard],
    //
    loadChildren: () =>
      import('./dashboard/admin/sales-agent/sales-agent.module').then(
        (m) => m.SalesAgentModule
      ),
  },
  {
    path: 'admin/reseller',
    canActivate: [AdminGuardGuard, RolePermissionGuard],
    //
    loadChildren: () =>
      import('./dashboard/admin/resseler/resseler.module').then(
        (m) => m.ResselerModule
      ),
  },

  {
    path: 'admin/default-billing-setup',
    canActivate: [AdminGuardGuard, RolePermissionGuard],
    //
    loadChildren: () =>
      import(
        './dashboard/admin/default-biiling-setup/default-biiling-setup.module'
      ).then((m) => m.DefaultBiilingSetupModule),
  },
  {
    path: 'admin/active-users',
    canActivate: [AdminGuardGuard, RolePermissionGuard],
    loadChildren: () =>
      import('./dashboard/admin/active-users/active-users.module').then(
        (m) => m.ActiveUsersModule
      ),
  },
  {
    path: 'admin/mopuser',
    canActivate: [AdminGuardGuard, RolePermissionGuard],
    loadChildren: () =>
      import('./dashboard/admin/mopuser/mopuser.module').then(
        (m) => m.MopuserModule
      ),
  },
  {
    path: 'admin/default-sale-agent-fee-setup',
    canActivate: [AdminGuardGuard, RolePermissionGuard],
    //
    loadChildren: () =>
      import(
        './dashboard/admin/default-sale-agent-fee-setup/default-sale-agent-fee-setup.module'
      ).then((m) => m.DefaultSaleAgentFeeSetupModule),
  },
  {
    path: 'admin/default-reseller-billing-fee',
    canActivate: [AdminGuardGuard, RolePermissionGuard],
    //
    loadChildren: () =>
      import(
        './dashboard/admin/default-reseller-billing-fee/default-reseller-billing-fee.module'
      ).then((m) => m.DefaultResellerBillingFeeModule),
  },
  // {
  //   path: 'marketing/offers-and-deals/create-offers-and-deals2',
  //   canActivate: [AdminGuardGuard],
  //   loadChildren: () =>
  //     import(
  //       './dashboard/marketing/offers-and-deals/create-offers-and-deals2/create-offers-and-deals2.module'
  //     ).then((m) => m.CreateOffersAndDeals2Module),
  // },
  {
    path: 'admin/sales-agent/add-edit-sales-agent',
    loadChildren: () =>
      import(
        './dashboard/admin/sales-agent/add-sale-agent/add-edit-sale-agent.module'
      ).then((m) => m.AddEditSaleAgentModule),
  },
  // {
  //   path: 'admin/sales-agent/edit-sales-agent/:id',
  //   canActivate: [AdminGuardGuard, RolePermissionGuard],
  //   //
  //   loadChildren: () =>
  //     import(
  //       './dashboard/admin/sales-agent/add-sale-agent/add-edit-sale-agent.module'
  //     ).then((m) => m.AddEditSaleAgentModule),
  // },
  {
    path: 'admin/store-billing-setup',
    canActivate: [AdminGuardGuard],
    loadChildren: () =>
      import(
        './dashboard/admin/store-billing-setup/store-billing-setup.module'
      ).then((m) => m.StoreBillingSetupModule),
  },
  {
    path: 'transaction/search-consumer',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import(
        './dashboard/transaction/search-consumer/search-consumer.module'
      ).then((m) => m.SearchConsumerModule),
  },
  {
    path: 'transaction/tansaction-details',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import(
        './dashboard/transaction/transaction-details/transaction-details.module'
      ).then((m) => m.TransactionDetailsModule),
  },
  {
    path: 'transaction/reports',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import('./dashboard/transaction/reports/reports.module').then(
        (m) => m.ReportsModule
      ),
  },
  {
    path: 'transaction/payment-failed',
    canActivate: [AdminGuardGuard, RolePermissionGuard],
    //
    loadChildren: () =>
      import(
        './dashboard/transaction/payment-failed/payment-failed.module'
      ).then((m) => m.PaymentFailedModule),
  },
  {
    path: 'transaction/commander-message',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import(
        './dashboard/transaction/commander-message/commander-message.module'
      ).then((m) => m.CommanderMessageModule),
  },
  {
    path: 'transaction/transaction-details',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import(
        './dashboard/transaction/transation-details/transation-details.module'
      ).then((m) => m.TransationDetailsModule),
  },
  {
    path: 'mobile-error-log',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import('./dashboard/transaction/error-log/error-log.module').then(
        (m) => m.ErrorLogModule
      ),
  },
  {
    path: 'Processes/store-billing',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import(
        './dashboard/transaction/store-billing/store-billing/store-billing.module'
      ).then((m) => m.StoreBillingModule),
  },
  {
    path: 'report/settlement-reconcile',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import(
        './dashboard/transaction/daily-settlement/daily-settlement.module'
      ).then((m) => m.DailySettlementModule),
  },
  {
    path: 'transaction/monthly-settlement-report',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import(
        './dashboard/transaction/monthly-settlement-report/monthly-settlement-report.module'
      ).then((m) => m.MonthlySettlementReportModule),
  },
  {
    path: 'nachaReport/ACH-processing-reports',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import(
        './dashboard/nacha-reports/ach-daily-proccessing-reports/ach-daily-proccessing-reports.module'
      ).then((m) => m.ACHDailyProccessingReportsModule),
  },
  {
    path: 'nachaReport/Daily-Return-Activity',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import(
        './dashboard/nacha-reports/daily-return-activity/daily-return-activity.module'
      ).then((m) => m.DailyReturnActivityModule),
  },
  {
    path: 'nachaReport/ACH-transaction-report',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import(
        './dashboard/nacha-reports/achtransaction-report/achtransaction-report.module'
      ).then((m) => m.ACHTransactionReportModule),
  },
  {
    path: 'nachaReport/ACH-return-report',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import(
        './dashboard/nacha-reports/ach-return-report/ach-return-report.module'
      ).then((m) => m.AchReturnReportModule),
  },
  {
    path: 'transaction/reports',
    canActivate: [AdminGuardGuard, RolePermissionGuard],
    loadChildren: () =>
      import('./dashboard/transaction/reports/reports.module').then(
        (m) => m.ReportsModule
      ),
  },
  {
    path: 'Processes/eod-reports',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import('./dashboard/Invoice/eod-report/eod-report.module').then(
        (m) => m.EodReportModule
      ),
  },
  {
    path: 'Processes/sales-agent-billing',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import(
        './dashboard/Invoice/sales-agent-billing/sales-agent-billing.module'
      ).then((m) => m.SalesAgentBillingModule),
  },
  {
    path: 'Processes/reseller-billing',
    canActivate: [AdminGuardGuard, RolePermissionGuard],

    loadChildren: () =>
      import(
        './dashboard/Invoice/reseller-billing-process/reseller-billing-process.module'
      ).then((m) => m.ResellerBillingProcessModule),
  },
  {
    path: 'marketing/offers-and-deals',
    canActivate: [AdminGuardGuard],

    loadChildren: () =>
      import(
        './dashboard/marketing/offers-and-deals/offers-and-deals.module'
      ).then((m) => m.OffersAndDealsModule),
  },
  {
    path: 'marketing/all-offers',
    canActivate: [AdminGuardGuard],

    loadChildren: () =>
      import('./dashboard/marketing/all-offers/all-offers.module').then(
        (m) => m.AllOffersModule
      ),
  },
  {
    path: 'marketing/offers-and-deals/create-offers-and-deals',
    loadChildren: () =>
      import(
        './dashboard/marketing/offers-and-deals/create-offers-and-deals/create-offers-and-deals.module'
      ).then((m) => m.CreateOffersAndDealsModule),
  },

  {
    path: 'marketing/offers-and-deals/create-offers-and-deals2',
    canActivate: [AdminGuardGuard],
    loadChildren: () =>
      import(
        './dashboard/marketing/offers-and-deals/create-offers-and-deals2/create-offers-and-deals2.module'
      ).then((m) => m.CreateOffersAndDeals2Module),
  },
  {
    path: 'marketing/email-campaign',
    canActivate: [AdminGuardGuard],
    loadChildren: () =>
      import('./dashboard/marketing/email-campaign/email-campaign.module').then(
        (m) => m.EmailCampaignModule
      ),
  },

  // {
  //   path: 'marketing/app-notification',
  //   canActivate: [AdminGuardGuard],
  //   loadChildren: () =>
  //     import(
  //       './dashboard/marketing/app-notification/app-notification.module'
  //     ).then((m) => m.AppNotificationModule),
  // },
  {
    path: 'marketing/app-notification/create-app-notification',
    canActivate: [AdminGuardGuard],
    loadChildren: () =>
      import(
        './dashboard/marketing/app-notification/create-app-notification/create-app-notification.module'
      ).then((m) => m.CreateAppNotificationModule),
  },
  {
    path: 'marketing/app-notification/create-app-notification2',
    canActivate: [AdminGuardGuard],
    loadChildren: () =>
      import(
        './dashboard/marketing/app-notification/create-app-notification2/create-app-notification2.module'
      ).then((m) => m.CreateAppNotification2Module),
  },

  {
    path: 'support/help-and-support',
    canActivate: [AdminGuardGuard],
    loadChildren: () =>
      import(
        './dashboard/support/help-and-support/help-and-support.module'
      ).then((m) => m.HelpAndSupportModule),
  },
  {
    path: 'about/about-us',
    canActivate: [AdminGuardGuard],
    loadChildren: () =>
      import('./dashboard/about-us/about-us.module').then(
        (m) => m.AboutUsModule
      ),
  },
  {
    path: 'support/tutorials',
    canActivate: [AdminGuardGuard],
    loadChildren: () =>
      import('./dashboard/support/tutorials/tutorials.module').then(
        (m) => m.TutorialsModule
      ),
  },
  {
    path: 'support/documentation',
    canActivate: [AdminGuardGuard],
    loadChildren: () =>
      import('./dashboard/support/documentation/documentation.module').then(
        (m) => m.DocumentationModule
      ),
  },

  {
    path: 'consumer/my-profile',
    canActivate: [ConsumerGuardGuard],
    loadChildren: () =>
      import('./dashboard/consumer/my-profile/my-profile.module').then(
        (m) => m.MyProfileModule
      ),
  },
  {
    path: 'consumer/history',
    canActivate: [ConsumerGuardGuard],
    loadChildren: () =>
      import('./dashboard/consumer/history/history.module').then(
        (m) => m.HistoryModule
      ),
  },

  {
    path: 'consumer/my-rewards',
    canActivate: [ConsumerGuardGuard],
    loadChildren: () =>
      import('./dashboard/consumer/my-rewards/my-rewards.module').then(
        (m) => m.MyRewardsModule
      ),
  },
  {
    path: 'consumer/my-offers-and-deals',
    canActivate: [ConsumerGuardGuard],
    loadChildren: () =>
      import(
        './dashboard/consumer/my-offers-and-deals/my-offers-and-deals.module'
      ).then((m) => m.MyOffersAndDealsModule),
  },
  {
    path: 'consumer/payment-method',
    canActivate: [ConsumerGuardGuard],
    loadChildren: () =>
      import('./dashboard/consumer/payment-method/payment-method.module').then(
        (m) => m.PaymentMethodModule
      ),
  },

  {
    path: 'consumer/car-wash-code',
    canActivate: [ConsumerGuardGuard],
    loadChildren: () =>
      import('./dashboard/consumer/car-wash-code/car-wash-code.module').then(
        (m) => m.CarWashCodeModule
      ),
  },
  {
    path: 'consumer/my-tutorials',
    canActivate: [ConsumerGuardGuard],
    loadChildren: () =>
      import('./dashboard/consumer/my-tutorials/my-tutorials.module').then(
        (m) => m.MyTutorialsModule
      ),
  },

  {
    path: 'consumer/help-and-support',
    canActivate: [ConsumerGuardGuard],
    loadChildren: () =>
      import(
        './dashboard/consumer/help-and-support/help-and-support.module'
      ).then((m) => m.HelpAndSupportModule),
  },
  {
    path: 'consumer/terms-and-conditions',
    canActivate: [ConsumerGuardGuard],
    loadChildren: () =>
      import(
        './dashboard/consumer/terms-and-conditions/terms-and-conditions.module'
      ).then((m) => m.TermsAndConditionsModule),
  },
  {
    path: 'consumer/privacy-policy',
    canActivate: [ConsumerGuardGuard],
    loadChildren: () =>
      import('./dashboard/consumer/privacy-policy/privacy-policy.module').then(
        (m) => m.PrivacyPolicyModule
      ),
  },
  {
    path: 'consumer/about-us',
    canActivate: [ConsumerGuardGuard],
    loadChildren: () =>
      import('./dashboard/consumer/about-us/about-us.module').then(
        (m) => m.AboutUsModule
      ),
  },
];

@NgModule({
  declarations: [],

  imports: [
    CommonModule,
    RouterModule.forRoot(routes, {
      scrollPositionRestoration: 'enabled',
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
