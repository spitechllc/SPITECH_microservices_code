﻿using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.AspNetCore.Hosting;
using MimeKit;
using MimeKit.Utils;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Domain.Configs;
using SpiTech.Notifications.Domain.Models;
using System;
using System.IO;
using System.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace SpiTech.Notifications.Infrastructure.Services
{
    public class EmailService : IEmailService
    {
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly EmailClientConfig _emailClientConfig;
        private readonly ILogger<EmailService> logger;

        public EmailService(IWebHostEnvironment webHostEnvironment, EmailClientConfig emailClientConfig, ILogger<EmailService> logger)
        {
            _webHostEnvironment = webHostEnvironment;
            _emailClientConfig = emailClientConfig;
            this.logger = logger;
        }

        public void SendEmail(
            string[] toEmails,
            string[] ccEmails,
            string subject,
            string htmlBodyTemplate,
            EmailAttachmentModel[] attachments = null,
            string fromEmail = null, string tenantName = null)
        {
            logger.TraceEnterMethod(nameof(SendEmail), toEmails, ccEmails, subject, htmlBodyTemplate);

            if ((toEmails == null || !toEmails.Any() || toEmails.All(t => string.IsNullOrWhiteSpace(t))) && (ccEmails == null || !ccEmails.Any() || ccEmails.All(t => string.IsNullOrWhiteSpace(t))))
            {
                return;
            }

            MimeMessage message = new();
            if (!string.IsNullOrWhiteSpace(fromEmail))
            {
                message.From.Add(new MailboxAddress(_emailClientConfig.FromFriendlyName, fromEmail));
            }
            else
            {
                if (!string.IsNullOrEmpty(tenantName))
                {
                    _emailClientConfig.FromFriendlyName = tenantName.Split(' ')[0];
                }
                message.From.Add(new MailboxAddress(_emailClientConfig.FromFriendlyName, _emailClientConfig.FromEmailAddress));
            }
            if (_emailClientConfig.IsTestMode)
            {
                message.To.Add(MailboxAddress.Parse(_emailClientConfig.TestEmail));
            }
            else
            {
                if (toEmails != null)
                {
                    foreach (string email in toEmails)
                    {
                        if (!string.IsNullOrWhiteSpace(email))
                        {
                            message.To.Add(MailboxAddress.Parse(email));
                        }
                    }
                }

                if (ccEmails != null)
                {
                    foreach (string email in ccEmails)
                    {
                        if (!string.IsNullOrWhiteSpace(email))
                        {
                            message.Cc.Add(MailboxAddress.Parse(email));
                        }
                    }
                }
            }

            message.Subject = $"{_emailClientConfig.SubjectPrefix} {subject}";
            BodyBuilder bodyBuilder = new();
            htmlBodyTemplate = AddImageInTemplate(htmlBodyTemplate, "[[TheStation]]", "TheStation.png", bodyBuilder);
            htmlBodyTemplate = AddImageInTemplate(htmlBodyTemplate, "[[Verifone]]", "Verifone.png", bodyBuilder);

            htmlBodyTemplate = AddImageInTemplate(htmlBodyTemplate, "[[NoImage]]", "NoImage.jpg", bodyBuilder);

            htmlBodyTemplate = AddImageInTemplate(htmlBodyTemplate, "[[SpiTechImgId]]", "SpiTech-logo.jpg", bodyBuilder);
            htmlBodyTemplate = AddImageInTemplate(htmlBodyTemplate, "[[SpiTechSignatureImgId]]", "SpiTechsignature-logo.png", bodyBuilder);
            htmlBodyTemplate = AddImageInTemplate(htmlBodyTemplate, "[[SpiTechBannerImgId]]", "banner.jpg", bodyBuilder);
            htmlBodyTemplate = AddImageInTemplate(htmlBodyTemplate, "[[SpiTechConfirmEmailImgId]]", "confirm_email.png", bodyBuilder);
            htmlBodyTemplate = AddImageInTemplate(htmlBodyTemplate, "[[SpiTechFacebookImgId]]", "facebook.png", bodyBuilder);
            htmlBodyTemplate = AddImageInTemplate(htmlBodyTemplate, "[[SpiTechTwitterImgId]]", "twitter.png", bodyBuilder);
            htmlBodyTemplate = AddImageInTemplate(htmlBodyTemplate, "[[SpiTechGooglePluseImgId]]", "google_pluse.png", bodyBuilder);

            bodyBuilder.HtmlBody = htmlBodyTemplate;

            if (attachments != null && attachments.Any())
            {
                foreach (var attachment in attachments)
                {
                    if (attachment != null)
                        bodyBuilder.Attachments.Add(attachment.FileName, attachment.Content);
                }
            }

            message.Body = bodyBuilder.ToMessageBody();

            logger.Trace("HtmlBody===>" + bodyBuilder.HtmlBody);
            logger.Trace("Subject===>" + message.Subject);

            if (!_emailClientConfig.IsTestMode)
            {
                using SmtpClient client = new();
                client.ServerCertificateValidationCallback = (s, c, h, e) => true;
                client.Timeout = 5000;

                if (_emailClientConfig.SslEnable)
                {
                    // client.Connect(_emailClientConfig.SMTPServer, _emailClientConfig.Port, true);
                    client.Connect(_emailClientConfig.SMTPServer, _emailClientConfig.Port, SecureSocketOptions.StartTls);
                }
                else
                {
                    client.Connect(_emailClientConfig.SMTPServer, _emailClientConfig.Port);
                }

                if (!string.IsNullOrWhiteSpace(_emailClientConfig.UserName) && !string.IsNullOrWhiteSpace(_emailClientConfig.Password))
                {
                    client.AuthenticationMechanisms.Remove("XOAUTH2");
                    client.Authenticate(_emailClientConfig.UserName, _emailClientConfig.Password);
                }

                client.Send(message);
                client.Disconnect(true);
            }

            logger.TraceExitMethod(nameof(SendEmail));
        }

        public string AddImageInTemplate(string htmlBodyTemplate, string imageMarker, string replaceImageName, BodyBuilder bodyBuilder)
        {
            if (htmlBodyTemplate.Contains(imageMarker))
            {
                string SpiTechImgPath = Path.Combine(_webHostEnvironment.ContentRootPath, "Resources", replaceImageName);
                MimeEntity SpiTechImage = bodyBuilder.LinkedResources.Add(SpiTechImgPath);
                SpiTechImage.ContentId = MimeUtils.GenerateMessageId();
                htmlBodyTemplate = htmlBodyTemplate.Replace(imageMarker, SpiTechImage.ContentId, StringComparison.InvariantCultureIgnoreCase);
            }

            return htmlBodyTemplate;
        }
    }
}
