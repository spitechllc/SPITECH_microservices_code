﻿using AutoMapper;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Notifications.Application.Repositories;
using SpiTech.Notifications.Application.UnitOfWorks;
using SpiTech.Notifications.Infrastructure.Repositories;
using System.Data;

namespace SpiTech.Notifications.Infrastructure.UnitOfWorks
{
    public sealed class UnitOfWork : BaseUnitOfWork, IUnitOfWork
    {
        public UnitOfWork(string connectionString,
                           System.IServiceProvider serviceProvider,
                          IsolationLevel isolationLevel = IsolationLevel.ReadCommitted)
                          : base(connectionString, serviceProvider, isolationLevel)
        {
        }

        private IGuestUserRepository _guestusers = null;
        private IUserNotificationConfigrationRepository _userNotificationConfigrations = null;
        private INotificationModuleRepository _notificationModules = null;
        private INotificationTypeRepository _notificationTypes = null;
        private INotificationRecipientRepository _notificationRecipients = null;
        private INotificationRepository _notifications = null;
        private INotificationConfigRepository _notificationConfigs = null;
        private IPushNotificationRepository _pushNotifications = null;
        private IUserNotificationRepository _userNotifications = null;
        private IActivityTypeRepository _activitytypes = null;
        private IActivityRepository _activities = null;

        public IGuestUserRepository GuestUsers => _guestusers ??= new GuestUserRepository(this, serviceProvider);
        public IUserNotificationConfigrationRepository UserNotificationConfigrations => _userNotificationConfigrations ??= new UserNotificationConfigrationRepository(this, serviceProvider);
        public INotificationModuleRepository NotificationModules => _notificationModules ??= new NotificationModuleRepository(this, serviceProvider);
        public INotificationTypeRepository NotificationTypes => _notificationTypes ??= new NotificationTypeRepository(this, serviceProvider);
        public INotificationRecipientRepository NotificationRecipients => _notificationRecipients ??= new NotificationRecipientRepository(this, serviceProvider);
        public INotificationRepository Notifications => _notifications ??= new NotificationRepository(this, serviceProvider);
        public INotificationConfigRepository NotificationConfigs => _notificationConfigs ??= new NotificationConfigRepository(this, serviceProvider);
        public IPushNotificationRepository PushNotifications => _pushNotifications ??= new PushNotificationRepository(this, serviceProvider);
        public IUserNotificationRepository UserNotifications => _userNotifications ??= new UserNotificationRepository(this, serviceProvider);
        public IActivityTypeRepository ActivityTypes => _activitytypes ??= new ActivityTypeRepository(this, serviceProvider);
        public IActivityRepository Activities => _activities ??= new ActivityRepository(this, serviceProvider);

        public override void ResetRepositories()
        {
            _guestusers = null;
            _userNotificationConfigrations = null;
            _notificationModules = null;
            _notificationTypes = null;
            _notificationRecipients = null;
            _notifications = null;
            _notificationConfigs = null;
            _pushNotifications = null;
            _userNotifications = null;
            _activitytypes = null;
            _activities = null;
        }
    }
}
