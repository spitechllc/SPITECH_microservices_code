﻿using AutoMapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Notifications.Application.Repositories;
using PushNotification = SpiTech.Notifications.Domain.Entities.PushNotification;

namespace SpiTech.Notifications.Infrastructure.Repositories
{
    public class PushNotificationRepository : Repository<PushNotification>, IPushNotificationRepository
    {
        public PushNotificationRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
    }
}
