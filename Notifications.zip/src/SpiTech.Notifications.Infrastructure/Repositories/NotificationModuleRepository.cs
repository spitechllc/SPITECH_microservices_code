﻿using AutoMapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Notifications.Application.Repositories;
using SpiTech.Notifications.Domain.Entities;

namespace SpiTech.Notifications.Infrastructure.Repositories
{
    public class NotificationModuleRepository : Repository<NotificationModule>, INotificationModuleRepository
    {
        public NotificationModuleRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
    }
}
