﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Notifications.Application.Repositories;
using SpiTech.Notifications.Domain.Entities;
using SpiTech.Notifications.Domain.Enums;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Infrastructure.Repositories
{
    public class NotificationConfigRepository : Repository<NotificationConfig>, INotificationConfigRepository
    {
        public NotificationConfigRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<NotificationConfig> GetConfigs(NotificationConfigType notificationConfigType)
        {
            DynamicParameters dynamicParameters = new();
            dynamicParameters.Add("notificationConfigType", (int)notificationConfigType);

            StringBuilder sbquery = new();
            sbquery.Append($"Select * from NotificationConfig where NotificationConfigTypeId=@notificationConfigType");

            return await DbConnection.QueryFirstOrDefaultAsync<NotificationConfig>(sbquery.ToString(), dynamicParameters, DbTransaction);
        }
    }
}