﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Notifications.Application.Repositories;
using SpiTech.Notifications.Domain.Entities;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Infrastructure.Repositories
{
    public class ActivityTypeRepository : Repository<ActivityType>, IActivityTypeRepository
    {
        public ActivityTypeRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
    }
}
