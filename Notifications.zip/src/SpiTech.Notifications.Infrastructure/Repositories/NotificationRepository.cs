﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Notifications.Application.Repositories;
using SpiTech.Notifications.Domain.Entities;
using SpiTech.Notifications.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Infrastructure.Repositories
{
    public class NotificationRepository : Repository<Notification>, INotificationRepository
    {
        public NotificationRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<List<Notification>> GetByIds(int[] notificationIds)
        {
            StringBuilder sbquery = new();
            sbquery.Append("Select * from Notification where IsActive=1 and NotificationId in @notificationIds order by NotificationId desc");

            DynamicParameters dynamicParams = new();

            dynamicParams.Add("notificationIds", notificationIds);

            return (await DbConnection.QueryAsync<Notification>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }

        public async Task<Notification> GetByFilter(string messageIdentifier)
        {
            DynamicParameters dynamicParams = new();

            dynamicParams.Add("messageIdentifier", messageIdentifier);

            StringBuilder sbquery = new();

            sbquery.Append("Select * from Notification where IsActive=1 and MessageIdentifier= @messageIdentifier");

            return await DbConnection.QueryFirstOrDefaultAsync<Notification>(sbquery.ToString(), dynamicParams, DbTransaction);
        }

        public async Task<List<AppNotificationModel>> GetAppNotificationList(int? PageIndex, int? PageSize, string SortBy, string SortOrder)
        {
            StringBuilder sbquery = new();
            DynamicParameters dynamicParams = new();
            sbquery.Append($"select count(1) over() as TotalRecord, N.NotificationId,N.EventId,N.NotificationTypeIdentifier,N.CreatedOn, NR.DisplayMessage, NR.DisplayMessageES,NR.UserId, NR.PushNotificationSentDate from [Notification] N INNER JOIN  NotificationRecipient NR on N.NotificationId= NR.NotificationId where N.NotificationTypeIdentifier='AppNotificationEvent'");

            if (!string.IsNullOrEmpty(SortBy) && !string.IsNullOrEmpty(SortOrder))
            {
                sbquery.Append($" Order by {SortBy} {SortOrder}");
            }
            else
            {
                sbquery.Append($" Order by N.CreatedOn desc");
            }
            if (PageIndex.HasValue && PageSize.HasValue)
            {
                int skiprow = (PageIndex.Value - 1) * PageSize.Value;
                sbquery.Append($" OFFSET {skiprow} rows fetch next {PageSize.Value} rows only");
            }
            return (await DbConnection.QueryAsync<AppNotificationModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }

        public async Task<AppNotificationDetailModel> GetAppNotificationById(int notificationId)
        {
            DynamicParameters dynamicParams = new();
            string query = ($"select N.NotificationId,N.EventId,N.NotificationTypeIdentifier,N.CreatedOn, NR.DisplayMessage, NR.DisplayMessageES,NR.UserId, NR.PushNotificationSentDate,N.EventIdentifierName,N.NotificationTypeId,N.JsonData from [Notification] N INNER JOIN  NotificationRecipient NR on N.NotificationId= NR.NotificationId ");

            if (notificationId > 0)
            {
                query += " where N.NotificationId = @notificationId";
                dynamicParams.Add("notificationId", notificationId);
            }
            return (await DbConnection.QueryFirstOrDefaultAsync<AppNotificationDetailModel>(query, dynamicParams, DbTransaction));
        }
    }
}
