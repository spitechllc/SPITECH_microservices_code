﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Notifications.Application.Repositories;
using SpiTech.Notifications.Domain.Entities;
using SpiTech.Notifications.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Infrastructure.Repositories
{
    public class NotificationRecipientRepository : Repository<NotificationRecipient>, INotificationRecipientRepository
    {
        public NotificationRecipientRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<List<NotificationRecipientModel>> GetNotificationRecipientByFilter(int? recipientUserId, int? pageIndex, int? pageSize, bool? isRead)
        {
            StringBuilder sbquery = new();
            DynamicParameters dynamicParameters = new();
            sbquery.Append(@"Select NotificationRecipientId, UserId,StoreId,DisplayMessage,IsRead,ReadDate,EventId,EventIdentifierName,JsonData, N.NotificationTypeId, NR.CreatedOn,
                            count(1) over() as TotalRecord  from [Notification] N inner Join NotificationRecipient NR  On N.NotificationId =NR.NotificationId where NR.IsActive=1 and N.DisplayEnabled=1 ");

            if (recipientUserId.HasValue)
            {
                sbquery.Append($" and  NR.UserId =@UserId");
                dynamicParameters.Add("UserId", recipientUserId.Value);
            }

            if (isRead.HasValue)
            {
                sbquery.Append($" and  NR.IsRead = @IsRead ");
                dynamicParameters.Add("IsRead", isRead.Value ? 1 : 0);
            }

            sbquery.Append($" order by NR.NotificationRecipientId desc ");

            if (pageIndex.HasValue && pageSize.HasValue)
            {
                int skiprow = (pageIndex.Value - 1) * pageSize.Value;

                sbquery.Append($" OFFSET {skiprow} rows fetch next {pageSize.Value} rows only");

            }

            return (await DbConnection.QueryAsync<NotificationRecipientModel>(sbquery.ToString(), dynamicParameters, DbTransaction)).ToList();
        }

        public async Task<int> GetUnreadNotificationCount(int recipientUserId)
        {
            DynamicParameters dynamicParameters = new();
            dynamicParameters.Add("recipientUserId", recipientUserId);

            string query = @$"Select count(1) as unread from [Notification] N inner Join NotificationRecipient NR  On N.NotificationId = NR.NotificationId
                                    where NR.IsActive=1 and IsRead = 0 and N.DisplayEnabled=1
                                    and UserId=@recipientUserId";
            return (await DbConnection.QueryAsync<int>(query, dynamicParameters, DbTransaction)).FirstOrDefault();
        }

        public async Task<bool> UpdateNotificationReadStatus(int recipientUserId, int[] notificationRecipientIds)
        {
            string query = "";
            DynamicParameters dynamicParameters = new();

            if (notificationRecipientIds != null && notificationRecipientIds.Any())
            {
                query = @$" Update NotificationRecipient set IsRead=1, UpdatedOn=getUtcdate(), UpdatedBy=@UpdatedBy                                    
                                 where UserId=@recipientUserId
                                  and  NotificationRecipientId in @NotificationRecipientId ";
                dynamicParameters.Add("recipientUserId", recipientUserId);
                dynamicParameters.Add("NotificationRecipientId", notificationRecipientIds);
                dynamicParameters.Add("NotificationRecipientId", notificationRecipientIds);
                dynamicParameters.Add("UpdatedBy", GetActionUserId());
            }
            else
            {
                query = @$" Update NotificationRecipient set IsRead=1                                    
                                 where UserId=@recipientUserId";
                dynamicParameters.Add("recipientUserId", recipientUserId);
            }
            return (await DbConnection.ExecuteAsync(query, dynamicParameters, DbTransaction)) > 0;
        }
    }
}
