﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Notifications.Application.Repositories;
using SpiTech.Notifications.Domain.Entities;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Infrastructure.Repositories
{
    public class UserNotificationConfigrationRepository : Repository<UserNotificationConfigration>, IUserNotificationConfigrationRepository
    {
        public UserNotificationConfigrationRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<bool> UpdateUser(int userId, bool emailNotificationAllow, bool appNotificationAllow)
        {
            DynamicParameters dynamicParams = new();

            dynamicParams.Add("userId", userId);
            dynamicParams.Add("emailNotificationAllow", emailNotificationAllow ? 1 : 0);
            dynamicParams.Add("appNotificationAllow", appNotificationAllow ? 1 : 0);
            dynamicParams.Add("UpdatedBy", GetActionUserId());

            return (await DbConnection.ExecuteAsync($"Update [UserNotificationConfigration] set emailNotificationAllow=@emailNotificationAllow, appNotificationAllow =@appNotificationAllow, UpdatedOn=getUtcdate(), UpdatedBy=@UpdatedBy   where UserId=@userId", dynamicParams, DbTransaction)) > 0;
        }
    }
}
