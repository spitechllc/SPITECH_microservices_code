﻿using AutoMapper;
using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Notifications.Application.Repositories;
using SpiTech.Notifications.Domain.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Infrastructure.Repositories
{
    public class NotificationTypeRepository : Repository<NotificationType>, INotificationTypeRepository
    {
        public NotificationTypeRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public async Task<List<NotificationType>> GetByfilter(int notificationTypeId, int notificationModuleId, string notificationTypeIdentifier)
        {
            StringBuilder sbquery = new();

            sbquery.Append("Select * from NotificationType where IsActive=1");
            DynamicParameters dynamicParams = new();
            if (notificationTypeId > 0)
            {
                sbquery.Append($" and NotificationTypeId = @notificationTypeId");
                dynamicParams.Add("notificationTypeId", notificationTypeId);
            }

            if (notificationModuleId > 0)
            {
                sbquery.Append($" and NotificationModuleId = @notificationModuleId ");
                dynamicParams.Add("notificationModuleId", notificationModuleId);
            }
            if (!string.IsNullOrWhiteSpace(notificationTypeIdentifier))
            {
                sbquery.Append($" and NotificationTypeIdentifier = @notificationTypeIdentifier ");
                dynamicParams.Add("notificationTypeIdentifier", notificationTypeIdentifier);
            }

            return (await DbConnection.QueryAsync<NotificationType>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }

        public async Task<List<NotificationType>> GetByIds(int[] notificationTypeIds)
        {
            StringBuilder sbquery = new();

            sbquery.Append("Select * from NotificationType where IsActive=1 and NotificationTypeId in @notificationTypeIds");

            DynamicParameters dynamicParams = new();

            dynamicParams.Add("notificationTypeIds", notificationTypeIds);

            return (await DbConnection.QueryAsync<NotificationType>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }
        public async Task<int> UpdateNotificationMessages(int notificationTypeId, string notificationTypeIdentifier, string displaymessage, string emailsubject, string smstemplate, string pushNotificationTemplate)
        {

            DynamicParameters dynamicParams = new();
            int result = 0;

            dynamicParams.Add("NotificationTypeId", notificationTypeId);
            dynamicParams.Add("Displaymessage", displaymessage);
            dynamicParams.Add("NotificationTypeIdentifier", notificationTypeIdentifier);
            dynamicParams.Add("pushNotificationTemplate", pushNotificationTemplate);
            dynamicParams.Add("UpdatedBy", GetActionUserId());

            string query = "Update [dbo].[NotificationType] Set DisplayTemplate=@Displaymessage,PushNotificationTemplate=@PushNotificationTemplate, UpdatedOn=getUtcdate(), UpdatedBy=@UpdatedBy   ";

            if (!string.IsNullOrWhiteSpace(emailsubject))
            {
                query += ",EmailSubject=@Emailsubject";
                dynamicParams.Add("Emailsubject", emailsubject);
            }

            if (!string.IsNullOrWhiteSpace(smstemplate))
            {
                query += ",SmsTemplate=@Smstemplate";
                dynamicParams.Add("Smstemplate", smstemplate);
            }

            query += " WHERE NotificationTypeId = @NotificationTypeId and NotificationTypeIdentifier=@NotificationTypeIdentifier";

            result = await DbConnection.ExecuteAsync(query, dynamicParams, DbTransaction);


            return result;

        }
    }
}
