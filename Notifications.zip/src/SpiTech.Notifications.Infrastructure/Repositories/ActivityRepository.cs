﻿using Dapper;
using SpiTech.ApplicationCore.Repositories;
using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Notifications.Application.Repositories;
using SpiTech.Notifications.Domain.Entities;
using SpiTech.Notifications.Domain.Enums;
using SpiTech.Notifications.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Infrastructure.Repositories
{
    public class ActivityRepository : Repository<Activity>, IActivityRepository
    {
        public ActivityRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
        public async Task<List<ActivityReportModel>> GetActivityByFilter(int? userId,DateTime? startDateUtc,DateTime? endDateUtc, int? pageIndex, int? pageSize,ActivitySortBy? sortBy, SortOrderEnum? sortOrder)
        {
            StringBuilder sbquery = new();
            sbquery.Append($"Select count(1) over() as TotalRecord,AT.Name as ActivityType,A.* from Activity A inner join ActivityType AT on A.ActivityTypeId=AT.ActivityTypeId where 1=1 ");

            DynamicParameters dynamicParams = new();
            if(userId.HasValue)
            {
                sbquery.Append($" and A.UserId = @userId");
                dynamicParams.Add("userId", userId);
            }
            if (startDateUtc.HasValue && endDateUtc.HasValue)
            {
                sbquery.Append($" and ActivityTime >= @FromDate ");
                dynamicParams.Add("FromDate", startDateUtc);
                sbquery.Append($" and ActivityTime <= @ToDate ");
                dynamicParams.Add("ToDate", endDateUtc);
            }
            if (sortBy != null && sortOrder != null && sortBy.Value != ActivitySortBy.None && sortOrder.Value != SortOrderEnum.None)
            {
                if (sortBy.Value == ActivitySortBy.ActivityType)
                {
                    sbquery.Append($" Order by AT.Name {sortOrder} ");
                }
                else
                {
                    if (sortBy.Value != ActivitySortBy.UserName)
                    {
                        sbquery.Append($" Order by A.{sortBy} {sortOrder} ");
                    }
                    else
                    {
                        sbquery.Append($" Order by A.ActivityTime desc");
                    }
                }
            }
            else
            {
                sbquery.Append($" Order by A.ActivityTime desc");
            }
            if (pageIndex.HasValue && pageSize.HasValue)
            {
                int skiprow = (pageIndex.Value - 1) * pageSize.Value;

                sbquery.Append($" OFFSET {skiprow} rows fetch next {pageSize.Value} rows only");
            }
            return (await DbConnection.QueryAsync<ActivityReportModel>(sbquery.ToString(), dynamicParams, DbTransaction)).ToList();
        }
    }
}
