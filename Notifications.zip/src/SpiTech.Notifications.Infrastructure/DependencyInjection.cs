﻿using AutoMapper;
using FluentValidation;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Application.UnitOfWorks;
using SpiTech.Notifications.Infrastructure.Services;
using SpiTech.Notifications.Infrastructure.UnitOfWorks;
using System.Reflection;

namespace SpiTech.Notifications.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            string connectionString = configuration.GetConnectionString("Notifications");
            services
                .AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());

            services.AddScoped<IUnitOfWork, UnitOfWork>(serviceProvider => new UnitOfWork(connectionString, serviceProvider));

            DapperExtensions.DapperExtensions.SetMappingAssemblies(new[]{
                    typeof(DependencyInjection).Assembly
            });

            services.AddTransient<IEmailService, EmailService>();
            return services;
        }
    }
}