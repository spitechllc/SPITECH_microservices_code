﻿namespace SpiTech.Notifications.Domain.Enums
{
    public enum NotificationConfigType
    {
        None = 0,
        HelpDesk = 1,
        Admin = 2,
        Support = 3,
    }
}
