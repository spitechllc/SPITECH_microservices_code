﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Domain.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum ActivitySortBy
    {
       
        None = 0,
        ActivityId = 1,
        ActivityTypeId = 2,
        ActivityType = 3,
        UserId = 4,
        UserName = 5,
        ActivityTime = 6,
        IsError = 7
    
}
}
