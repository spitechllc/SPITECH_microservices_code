﻿using SpiTech.EventBus.DomainEvents.Events.Marketings;
using SpiTech.Service.Clients.Stores;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Domain.Models.Marketing
{
    public class ConsumerOfferSendEventModel: ConsumerOfferSendEvent
    {
        public UserInfoModel User { get; set; }
        public string StoreName { get; set; }
        public AddressModel StoreAddress { get; set; }
    }
}
