﻿using SpiTech.EventBus.DomainEvents.Events.Store;
using SpiTech.Service.Clients.Stores;

namespace SpiTech.Notifications.Domain.Models.Store
{
    public class StoreUserEventModel: StoreUserEvent
    {
        public UserInfoModel User { get; set; }
        public StoreInfoModel Store { get; set; }
    }
}
