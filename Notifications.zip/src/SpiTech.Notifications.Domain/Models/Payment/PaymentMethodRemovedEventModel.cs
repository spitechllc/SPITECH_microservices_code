﻿using SpiTech.EventBus.DomainEvents.Events.Payment;

namespace SpiTech.Notifications.Domain.Models.Payment
{
    public class PaymentMethodRemovedEventModel: PaymentMethodRemovedEvent
    {
        public UserInfoModel User { get; set; }
    }
}
