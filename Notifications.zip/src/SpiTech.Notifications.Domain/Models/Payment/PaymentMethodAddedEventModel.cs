﻿using SpiTech.EventBus.DomainEvents.Events.Payment;

namespace SpiTech.Notifications.Domain.Models.Payment
{
    public class PaymentMethodAddedEventModel: PaymentMethodAddedEvent
    {
        public UserInfoModel User { get; set; }
    }
}
