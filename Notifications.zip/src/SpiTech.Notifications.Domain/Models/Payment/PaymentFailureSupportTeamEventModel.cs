﻿using SpiTech.EventBus.DomainEvents.Events.Payment;

namespace SpiTech.Notifications.Domain.Models.Payment
{
    public class PaymentFailureSupportTeamEventModel: PaymentFailureSupportTeamEvent
    {
        public UserInfoModel User { get; set; }
    }
}
