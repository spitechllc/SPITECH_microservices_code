﻿using SpiTech.EventBus.DomainEvents.Events.Payment;

namespace SpiTech.Notifications.Domain.Models.Payment
{
    public class PaymentStatusEventModel : PaymentStatusEvent
    {
        public UserInfoModel User { get; set; }
    }
}
