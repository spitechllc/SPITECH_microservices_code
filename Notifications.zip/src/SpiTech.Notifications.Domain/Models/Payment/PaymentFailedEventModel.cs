﻿using SpiTech.EventBus.DomainEvents.Events.Payment;

namespace SpiTech.Notifications.Domain.Models.Payment
{
    public class PaymentFailedEventModel: PaymentFailedEvent
    {
        public UserInfoModel User { get; set; }
    }
}
