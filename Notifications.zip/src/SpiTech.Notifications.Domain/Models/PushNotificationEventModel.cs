﻿using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events;
using SpiTech.Notifications.Domain.Entities;

namespace SpiTech.Notifications.Domain.Models
{
    public class PushNotificationEventModel
    {
        public IEvent Event { get; set; }
        public bool IsPushNotificationSent { get; set; }
        public bool IsError { get; set; }
        public int? RetryCount { get; set; }
        public string Error { get; set; }
        public UserInfoModel User { get; set; }
        public MobileAppType MobileAppType { get; set; } = MobileAppType.None;
        public NotificationType NotificationType { get; set; }
        public object MacroObject { get; set; }
        public int UnReadCount { get; set; }
    }
}
