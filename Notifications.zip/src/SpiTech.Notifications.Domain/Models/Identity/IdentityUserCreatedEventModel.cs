﻿using SpiTech.EventBus.DomainEvents.Events.Identity;

namespace SpiTech.Notifications.Domain.Models.Identity
{
    public class IdentityUserCreatedEventModel: IdentityUserCreatedEvent
    {
        public UserInfoModel User { get; set; }
    }
}
