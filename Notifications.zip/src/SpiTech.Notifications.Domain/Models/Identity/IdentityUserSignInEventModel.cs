﻿using SpiTech.EventBus.DomainEvents.Events.Identity;

namespace SpiTech.Notifications.Domain.Models.Identity
{
    public class IdentityUserSignInEventModel: IdentityUserSignInEvent
    {
        public UserInfoModel User { get; set; }
    }
}
