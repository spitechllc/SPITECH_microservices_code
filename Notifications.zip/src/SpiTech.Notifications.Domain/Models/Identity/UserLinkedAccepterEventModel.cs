﻿using SpiTech.EventBus.DomainEvents.Events.Identity;

namespace SpiTech.Notifications.Domain.Models.Identity
{
    public class UserLinkedAccepterEventModel: UserLinkedAccepterEvent
    {
        public UserInfoModel User { get; set; }
        public string RequesterName { get; set; }
    }
}
