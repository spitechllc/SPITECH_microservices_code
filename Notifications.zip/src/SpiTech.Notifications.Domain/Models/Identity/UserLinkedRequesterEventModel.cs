﻿using SpiTech.EventBus.DomainEvents.Events.Identity;

namespace SpiTech.Notifications.Domain.Models.Identity
{
    public class UserLinkedRequesterEventModel: UserLinkedRequesterEvent
    {
        public UserInfoModel User { get; set; }
        public string AccepterName { get; set; }
    }
}
