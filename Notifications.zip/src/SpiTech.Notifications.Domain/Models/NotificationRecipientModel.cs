﻿using System;

namespace SpiTech.Notifications.Domain.Models
{
    public class NotificationRecipientModel
    {
        public int NotificationRecipientId { get; set; }
        public int? UserId { get; set; }
        public int? StoreId { get; set; }
        public string DisplayMessage { get; set; }
        public bool IsRead { get; set; }
        public DateTime? ReadDate { get; set; }
        public string EventId { get; set; }
        public string EventIdentifierName { get; set; }
        public string JsonData { get; set; }
        public int NotificationTypeId { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string DisplayMessageES { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        [Newtonsoft.Json.JsonIgnore]
        public int TotalRecord { get; set; }
    }
}

