﻿namespace SpiTech.Notifications.Domain.Models
{
    public class ActivityTypeModel
    {      
        public string Name { get; set; }

    }
}

