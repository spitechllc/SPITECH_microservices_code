﻿using SpiTech.EventBus.DomainEvents.Events.Mppa.Mobiles;
using SpiTech.EventBus.DomainEvents.Models.Mppa;
using SpiTech.Service.Clients.Stores;

namespace SpiTech.Notifications.Domain.Models.Mppa
{
    public class MobileFinalizesDataResponseEventModel: MobileFinalizesDataResponseEvent
    {
        public string StoreName { get; set; }
        public AddressModel StoreAddress { get; set; }
        public string SubTotal { get; set; }
        public string Total { get; set; }
        public string Tax { get; set; }
        public Transaction Transaction { get; set; }
        public PaymentInfo PaymentInfo { get; set; }
        public string Amount { get; set; }
        public UserInfoModel User { get; set; }
    }
}
