﻿using SpiTech.EventBus.DomainEvents.Events.Mppa.Mobiles;

namespace SpiTech.Notifications.Domain.Models.Mppa
{
    public class MobileStacCaptureResponsesEventModel: MobileStacCaptureResponsesEvent
    {
        public UserInfoModel User { get; set; }
        public string Status { get; set; }
    }
}
