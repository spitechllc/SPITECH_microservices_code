﻿using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.Service.Clients.Stores;

namespace SpiTech.Notifications.Domain.Models.Mppa
{
    public class TransactionSettlementEventModel: TransactionSettlementEvent
    {
        public StoreInfoModel Store { get; set; }
        public string StoreName { get; set; }
        public AddressModel StoreAddress { get; set; }
        public bool SettlementStatus { get; set; }
        public string SettlementDetails { get; set; }
    }
}
