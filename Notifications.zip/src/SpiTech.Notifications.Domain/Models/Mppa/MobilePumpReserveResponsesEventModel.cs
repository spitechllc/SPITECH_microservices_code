﻿using SpiTech.EventBus.DomainEvents.Events.Mppa.Mobiles;

namespace SpiTech.Notifications.Domain.Models.Mppa
{
    public class MobilePumpReserveResponsesEventModel : MobilePumpReserveResponsesEvent
    {
        public UserInfoModel User { get; set; }

        public int FuelingPositionId
        {
            get
            {
                return PumpReserveResponse?.FuelingPositionId ?? 0;
            }
        }
    }
}
