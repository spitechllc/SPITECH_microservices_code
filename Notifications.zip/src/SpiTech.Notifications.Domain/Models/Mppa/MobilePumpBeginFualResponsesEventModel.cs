﻿using SpiTech.EventBus.DomainEvents.Events.Mppa.Mobiles;
using SpiTech.EventBus.DomainEvents.Models.Mppa;

namespace SpiTech.Notifications.Domain.Models.Mppa
{
    public class MobilePumpBeginFualResponsesEventModel: MobilePumpBeginFualResponsesEvent
    {
        public UserInfoModel User { get; set; }
    }
}
