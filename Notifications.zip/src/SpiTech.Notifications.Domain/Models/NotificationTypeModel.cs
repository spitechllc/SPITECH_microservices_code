﻿namespace SpiTech.Notifications.Domain.Models
{
    public class NotificationTypeModel 
    {
        public int NotificationTypeId { get; set; }
        public string NotificationTypeIdentifier { get; set; }
        public string NotificationTypeName { get; set; }
        public string DisplayTemplate { get; set; }
        public string SmsTemplate { get; set; }
        public string EmailSubject { get; set; }
        public string PushNotificationTemplate { get; set; }
        public string DisplayTemplateES { get; set; }
        public string EmailSubjectES { get; set; }
        public string PushNotificationTemplateES { get; set; }
    }
}

