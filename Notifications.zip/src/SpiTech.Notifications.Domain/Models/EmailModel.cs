﻿using SpiTech.EventBus.DomainEvents.Events;
using SpiTech.Notifications.Domain.Entities;
using SpiTech.Service.Clients.Stores;

namespace SpiTech.Notifications.Domain.Models
{
    public class EmailModel
    {
        public IEvent Event { get; set; }
        public bool IsEmailSent { get; set; }
        public bool IsError { get; set; }
        public int? RetryCount { get; set; }
        public string Error { get; set; }
        public UserInfoModel User { get; set; }
        public StoreInfoModel Store { get; set; }
        public SaleAgentModel SaleAgent { get; set; }
        public ResellerModel Reseller { get; set; }
        public NotificationType NotificationType { get; set; }
        public object MacroObject { get; set; }
    }
}
