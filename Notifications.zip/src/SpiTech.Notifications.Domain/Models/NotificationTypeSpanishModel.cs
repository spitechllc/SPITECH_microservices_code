﻿namespace SpiTech.Notifications.Domain.Models
{
    public class NotificationTypeSpanishModel 
    {
        public int NotificationTypeId { get; set; }
        public string NotificationTypeIdentifier { get; set; }
        public string NotificationTypeName { get; set; }
        public string DisplayTemplate { get; set; }
        public string SmsTemplate { get; set; }
        public string EmailSubject { get; set; }
        public string PushNotificationTemplate { get; set; }
    }
}

