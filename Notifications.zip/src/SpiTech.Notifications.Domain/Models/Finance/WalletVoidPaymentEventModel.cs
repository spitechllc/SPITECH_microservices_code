﻿using SpiTech.EventBus.DomainEvents.Events.Finance;

namespace SpiTech.Notifications.Domain.Models.Finance
{
    public class WalletVoidPaymentEventModel: WalletVoidPaymentEvent
    {
        public UserInfoModel User { get; set; }
    }
}
