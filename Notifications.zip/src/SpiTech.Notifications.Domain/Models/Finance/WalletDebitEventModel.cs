﻿using SpiTech.EventBus.DomainEvents.Events.Finance;

namespace SpiTech.Notifications.Domain.Models.Finance
{
    public class WalletDebitEventModel: WalletDebitEvent
    {
        public string Amount { get; set; }
        public string Name { get; set; }
        public string TransactionDesc { get; set; }
        public string Message { get; set; }
        public string StoreName { get; set; }
        public UserInfoModel User { get; set; }
    }
}
