﻿using SpiTech.EventBus.DomainEvents.Events.Finance;

namespace SpiTech.Notifications.Domain.Models.Finance
{
    public class WalletCreditEventModel: WalletCreditEvent
    {
        public string CreditAmount { get; set; }
        public string TransactionDesc { get; set; }
        public int? TransactionCount { get; set; }
        public string Name { get; set; }
        public string Message { get; set; }
        public string StoreName { get; set; }
        public UserInfoModel User { get; set; }
    }
}
