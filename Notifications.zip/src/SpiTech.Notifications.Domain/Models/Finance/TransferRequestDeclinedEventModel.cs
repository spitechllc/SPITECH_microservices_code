﻿using SpiTech.EventBus.DomainEvents.Events.Finance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Domain.Models.Finance
{
    public class TransferRequestDeclinedEventModel: TransferRequestDeclinedEvent
    {
        public string TransferRequestAmount { get; set; }
        public string ToName { get; set; }
        public UserInfoModel User { get; set; }
    }
}
