﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Domain.Models
{
    public class AppNotificationModel
    {
        public long NotificationId { get; set; }
        public long EventId { get; set; }
        public string NotificationTypeIdentifier { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string DisplayMessage { get; set; }
        public string DisplayMessageES { get; set; }
        public int UserId { get; set; }
        public DateTime? PushNotificationSentDate { get; set; }
        [Newtonsoft.Json.JsonIgnore]
        [System.Text.Json.Serialization.JsonIgnore]
        public int TotalRecord { get; set; }
    }

    public class AppNotificationDetailModel : AppNotificationModel
    {
        public string EventIdentifierName { get; set; }
        public int NotificationTypeId { get; set; }
        public string JsonData { get; set; }
    }
}
