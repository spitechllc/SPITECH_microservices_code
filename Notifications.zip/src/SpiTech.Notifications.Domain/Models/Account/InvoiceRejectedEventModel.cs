﻿using SpiTech.EventBus.DomainEvents.Events.Account;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Domain.Models.Account
{
    public class InvoiceRejectedEventModel: InvoiceRejectedEvent
    {
        public string ReceiverUserName { get; set; }
        public string SenderUserName { get; set; }
        public UserInfoModel User { get; set; }
    }
}
