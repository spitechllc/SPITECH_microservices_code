﻿using SpiTech.EventBus.DomainEvents.Events.Account;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Domain.Models.Account
{
    public class InvoiceReceiveEventModel: InvoiceReceiveEvent
    {
        public string UserName { get; set; }
        public string SenderUserName { get; set; }
        public string SenderEmail { get; set; }
        public string SenderMobile { get; set; }
        public string ReceiverUserName { get; set; }
        public string ReceiverEmail { get; set; }
        public string ReceiverMobile { get; set; }
        public UserInfoModel User { get; set; }
        public DateTime IssuedOn { get; set; }

       
    }
}
