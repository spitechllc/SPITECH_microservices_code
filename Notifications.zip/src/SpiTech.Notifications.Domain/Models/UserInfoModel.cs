﻿using SpiTech.Service.Clients.Identity;

namespace SpiTech.Notifications.Domain.Models
{
    public class UserInfoModel : UserModel
    {
        public bool EmailNotificationAllow { get; set; }
        public bool AppNotificationAllow { get; set; }
    }
}
