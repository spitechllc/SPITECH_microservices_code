﻿using System;

namespace SpiTech.Notifications.Domain.Models
{

    public class ActivityModel
    {
        public int ActivityTypeId { get; set; }
        public string ActivityRecordKeyId { get; set; }
        public string ActivityPreData { get; set; }
        public string ActivityPostData { get; set; }
        public DateTime ActivityTime { get; set; }
        public string ActivityIP { get; set; }

    }
}

