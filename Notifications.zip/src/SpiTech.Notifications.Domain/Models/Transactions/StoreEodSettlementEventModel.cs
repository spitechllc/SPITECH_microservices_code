﻿using SpiTech.EventBus.DomainEvents.Events.Transactions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Domain.Models.Transactions
{
    public class StoreEodSettlementEventModel: StoreEodSettlementEvent
    {
        public string BusinessDateFormatted {
            get
            {
                return StoreEodSettlement.BusinessDate.ToShortDateString();
            }
        }
    }
}
