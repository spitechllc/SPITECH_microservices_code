﻿using SpiTech.EventBus.DomainEvents.Events.Transactions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Domain.Models.Transactions
{
    public class StoreMonthlyBillingInvoiceEventModel: StoreMonthlyBillingInvoiceEvent
    {
        public string AccountNo { get; set; }
        public DateTime BusinessDate { get; set; }
        public string IdentificationNumber { get; set; }
    }
}
