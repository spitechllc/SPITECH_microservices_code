﻿using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.Service.Clients.Stores;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Domain.Models.Transactions
{
    public class ResellerMonthlyBillingInvoiceEventModel : ResellerMonthlyBillingInvoiceEvent
    {
        public ResellerModel Reseller { get; set; }
    }
}
