﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Domain.Models
{
    public class ActivityReportModel
    {
        public int ActivityId { get; set; }
        public int ActivityTypeId { get; set; }
        public string ActivityType { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string ActivityRecordKeyId { get; set; }
        public string ActivityPreData { get; set; }
        public string ActivityPostData { get; set; }
        public DateTime ActivityTime { get; set; }
        public string ActivityIP { get; set; }
        public bool IsError { get; set; }
        public string ErrorMessage { get; set; }
        [Newtonsoft.Json.JsonIgnore]
        [System.Text.Json.Serialization.JsonIgnore]
        public int TotalRecord { get; set; }
    }
}
