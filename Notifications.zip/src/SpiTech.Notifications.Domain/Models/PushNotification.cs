﻿namespace SpiTech.Notifications.Domain.Models
{
    public class PushNotification
    {
        public string Title { get; set; }
        public string Body { get; set; }
        public string Data { get; set; }
        public string Type { get; set; }
    }
}
