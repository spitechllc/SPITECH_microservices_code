﻿namespace SpiTech.Notifications.Domain.Models
{
    public class UserNotificationConfigrationModel
    {
        public int UserId { get; set; }
        public bool EmailNotificationAllow { get; set; }
        public bool AppNotificationAllow { get; set; }
    }
}
