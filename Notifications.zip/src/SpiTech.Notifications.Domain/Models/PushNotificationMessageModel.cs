﻿using Newtonsoft.Json;

namespace SpiTech.Notifications.Domain.Models
{
    public class PushNotificationMessageModel
    {
        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("body")]
        public string Body { get; set; }

        [JsonProperty("content-available")]
        public int Contentavailable { get; set; }
    }
}
