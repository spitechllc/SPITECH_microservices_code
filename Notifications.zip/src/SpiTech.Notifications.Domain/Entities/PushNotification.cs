﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.Notifications.Domain.Entities
{
    [Table("PushNotification")]
    public class PushNotification : BaseEntity
    {
        [Key]
        public int PushNotificationId { get; set; }
        public int UserId { get; set; }
        public string UserDeviceToken { get; set; }
        public string Title { get; set; }
        public string Body { get; set; }
        public int RetryCount { get; set; }
        public bool IsSent { get; set; }
        public DateTime? SentDate { get; set; }
        public bool HasError { get; set; }
        public string ErrorMessage { get; set; }
    }
}

