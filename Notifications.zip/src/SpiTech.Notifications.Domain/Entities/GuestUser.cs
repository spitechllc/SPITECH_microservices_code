﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Notifications.Domain.Entities
{
    [Table("GuestUser")]
    public class GuestUser : BaseEntity
    {
        [Key]
        public int GuestUserId { get; set; }
        public string UserName { get; set; }
        public string MobileNumber { get; set; }
        public string Email { get; set; }
        public string Description { get; set; }
    }
}
