﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Notifications.Domain.Entities
{
    [Table("ActivityType")]
    public class ActivityType : BaseEntity
    {
        [Key]
        public int ActivityTypeId { get; set; }
        public string Name { get; set; }

    }
}

