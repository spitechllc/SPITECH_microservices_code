﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Notifications.Domain.Entities
{
    [Table("NotificationModule")]
    public class NotificationModule : BaseEntity
    {
        [Key]
        public int NotificationModuleId { get; set; }
        public string NotificationModuleName { get; set; }
    }
}

