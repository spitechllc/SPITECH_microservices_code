﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Notifications.Domain.Entities
{
    [Table("NotificationType")]
    public class NotificationType : BaseEntity
    {
        [ExplicitKey]
        public int NotificationTypeId { get; set; }
        [ExplicitKey]
        public string NotificationTypeIdentifier { get; set; }
        public string NotificationTypeName { get; set; }
        public int NotificationModuleId { get; set; }
        public string DisplayTemplate { get; set; }
        public bool DisplayEnabled { get; set; }
        public string SmsTemplate { get; set; }
        public bool SmsEnabled { get; set; }
        public string EmailSubject { get; set; }
        public string EmailTemplatePath { get; set; }
        public bool EmailEnabled { get; set; }
        public string PushNotificationTemplate { get; set; }
        public bool PushNotificationEnabled { get; set; }
        public string DisplayTemplateES { get; set; }
        public string EmailSubjectES { get; set; }
        public string PushNotificationTemplateES { get; set; }

    }
}

