﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;
using System;

namespace SpiTech.Notifications.Domain.Entities
{
    [Table("Activity")]
    public class Activity : BaseEntity
    {
        [Key]
        public int ActivityId { get; set; }
        public int ActivityTypeId { get; set; }
        public int UserId { get; set; }
        public string ActivityRecordKeyId { get; set; }
        public string ActivityPreData { get; set; }
        public string ActivityPostData { get; set; }
        public DateTime ActivityTime { get; set; }
        public string ActivityIP { get; set; }
        public bool IsError { get; set; }
        public string ErrorMessage { get; set; }


    }
}

