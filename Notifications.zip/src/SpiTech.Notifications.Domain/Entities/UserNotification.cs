﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Notifications.Domain.Entities
{
    [Table("UserNotification")]
    public class UserNotification : BaseEntity
    {
        [Key]
        public int UserNotificationId { get; set; }
        public int UserId { get; set; }
        public int? DeviceTypeId { get; set; }
        public int? MobileAppTypeId { get; set; }
        public string DeviceToken { get; set; }
        public string Email { get; set; }
        public string MobileNumber { get; set; }
        public string NotificationData { get; set; }
        public bool? EmailSent { get; set; }
        public string SmsResponse { get; set; }
        public string PushResponse { get; set; }
        public string Error { get; set; }
    }
}

