﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Notifications.Domain.Entities
{
    [Table("[UserNotificationConfigration]")]
    public class UserNotificationConfigration : BaseEntity
    {
        [ExplicitKey]
        public int UserId { get; set; }
        public bool EmailNotificationAllow { get; set; }
        public bool AppNotificationAllow { get; set; }
    }
}
