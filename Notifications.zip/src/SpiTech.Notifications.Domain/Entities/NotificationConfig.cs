﻿using Dapper.Contrib.Extensions;
using SpiTech.ApplicationCore.Domain.Entities;

namespace SpiTech.Notifications.Domain.Entities
{
    [Table("NotificationConfig")]
    public class NotificationConfig : BaseEntity
    {
        [Key]
        public int NotificationConfigId { get; set; }
        public string EmailIds { get; set; }
        public string Mobiles { get; set; }
        public int NotificationConfigTypeId { get; set; }
    }
}
