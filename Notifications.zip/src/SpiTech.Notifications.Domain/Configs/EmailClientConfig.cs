﻿namespace SpiTech.Notifications.Domain.Configs
{
    public class EmailClientConfig
    {
        public bool Enable { get; set; }
        public bool SslEnable { get; set; }
        public bool IsTestMode { get; set; }
        public string TestEmail { get; set; }
        public string SMTPServer { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public int Port { get; set; }
        public string FromFriendlyName { get; set; }
        public string FromEmailAddress { get; set; }
        public string SubjectPrefix { get; set; }
    }
}
