﻿namespace SpiTech.Notifications.Domain.Configs
{
    public class BatchProcessorConfig
    {
        public bool Enable { get; set; }
        public int BatchSize { get; set; }
        public int BatchMinIntervalInSec { get; set; }
        public int BatchMaxIntervalInSec { get; set; }
    }
}
