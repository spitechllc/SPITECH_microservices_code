﻿using SpiTech.EventBus.DomainEvents.Enums;
using System.Collections.Generic;

namespace SpiTech.Notifications.Domain.Configs
{
    public class FcmSettingConfigList : List<FcmSettingConfig>
    {
    }

    public class FcmSettingConfig
    {
        public MobileAppType MobileAppType
        {
            get;
            set;
        }
        public string SenderId
        {
            get;
            set;
        }

        public string ServerKey
        {
            get;
            set;
        }
    }
}
