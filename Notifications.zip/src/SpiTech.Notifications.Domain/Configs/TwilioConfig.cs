﻿namespace SpiTech.Notifications.Domain.Configs
{
    public class TwilioConfig
    {
        public string AccountSid { get; set; }
        public string AuthToken { get; set; }
        public string MessagingServiceSid { get; set; }
        public string SenderPhone { get; set; }
    }
}
