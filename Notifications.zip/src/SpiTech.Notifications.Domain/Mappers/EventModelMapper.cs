﻿using AutoMapper;
using SpiTech.EventBus.DomainEvents.Events.Account;
using SpiTech.EventBus.DomainEvents.Events.Finance;
using SpiTech.EventBus.DomainEvents.Events.Identity;
using SpiTech.EventBus.DomainEvents.Events.Marketings;
using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Mobiles;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.EventBus.DomainEvents.Events.Store;
using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.Notifications.Domain.Models.Account;
using SpiTech.Notifications.Domain.Models.Finance;
using SpiTech.Notifications.Domain.Models.Identity;
using SpiTech.Notifications.Domain.Models.Marketing;
using SpiTech.Notifications.Domain.Models.Mppa;
using SpiTech.Notifications.Domain.Models.Payment;
using SpiTech.Notifications.Domain.Models.Store;
using SpiTech.Notifications.Domain.Models.Transactions;

namespace SpiTech.Notifications.Domain.Mappers
{
    public class EventModelMapper : Profile
    {
        public EventModelMapper()
        {
            #region Account Mapper
            CreateMap<InvoiceReceiveEvent, InvoiceReceiveEventModel>().ReverseMap();
            CreateMap<InvoiceCancelledEvent, InvoiceCancelledEventModel>().ReverseMap();
            CreateMap<InvoiceRejectedEvent, InvoiceRejectedEventModel>().ReverseMap();
            CreateMap<InvoicePaidEvent, InvoicePaidEventModel>().ReverseMap();
            #endregion

            #region Transactions Mapper
            CreateMap<AchNachaReturnFileEvent, AchNachaReturnFileEventModel>().ReverseMap();
            CreateMap<StoreEodSettlementInvoiceAdminEvent, StoreEodSettlementInvoiceAdminEventModel>().ReverseMap();
            CreateMap<StoreEodSettlementEvent, StoreEodSettlementEventModel>().ReverseMap();
            CreateMap<StoreMonthlyBillingInvoiceEvent, StoreMonthlyBillingInvoiceEventModel>().ReverseMap();
            CreateMap<SaleAgentMonthlyBillingInvoiceEvent, SaleAgentMonthlyBillingInvoiceEventModel>().ReverseMap();
            CreateMap<ResellerMonthlyBillingInvoiceEvent, ResellerMonthlyBillingInvoiceEventModel>().ReverseMap();
            CreateMap<StoreEodSettlementInvoiceEvent, StoreEodSettlementInvoiceEventModel>().ReverseMap();
            #endregion

            #region Finance Mapper
            CreateMap<ExpiringWalletCreditEvent, ExpiringWalletCreditEventModel>().ReverseMap();
            CreateMap<TransferRequestDeclinedEvent, TransferRequestDeclinedEventModel>().ReverseMap();
            CreateMap<TransferRequestEvent, TransferRequestEventModel>().ReverseMap();
            CreateMap<WalletCreditEvent, WalletCreditEventModel>().ReverseMap();
            CreateMap<WalletDebitEvent, WalletDebitEventModel>().ReverseMap();
            CreateMap<WalletVoidPaymentEventModel, WalletVoidPaymentEvent> ().ReverseMap();
            #endregion

            #region Identity Mapper
            CreateMap<IdentityUserCreatedEvent, IdentityUserCreatedEventModel>().ReverseMap();
            CreateMap<IdentityUserUpdatedEvent, IdentityUserUpdatedEventModel>().ReverseMap();
            CreateMap<IdentityForgotPasswordEvent, IdentityForgotPasswordEventModel>().ReverseMap();
            CreateMap<IdentityPasswordChangedEvent, IdentityPasswordChangedEventModel>().ReverseMap();
            CreateMap<IdentityUserSignInEvent, IdentityUserSignInEventModel>().ReverseMap();
            CreateMap<UserLinkedAccepterEvent, UserLinkedAccepterEventModel>().ReverseMap();
            CreateMap<UserLinkedRequesterEvent, UserLinkedRequesterEventModel>().ReverseMap();
            CreateMap<IdentityUserEmailVerifiedEvent, IdentityUserEmailVerifiedEventModel>().ReverseMap();
            CreateMap<IdentityUserVerificationCodeEvent, IdentityUserVerificationCodeEventModel>().ReverseMap();
            #endregion

            #region Marketing Mapper
            CreateMap<ConsumerOfferSendEvent, ConsumerOfferSendEventModel>().ReverseMap();
            #endregion

            #region MPPA Mapper

            CreateMap<TransactionSettlementEvent, TransactionSettlementEventModel>().ReverseMap();
            CreateMap<MobileFinalizesDataResponseEvent, MobileFinalizesDataResponseEventModel>().ReverseMap();
            CreateMap<MobilePumpBeginFualResponsesEvent, MobilePumpBeginFualResponsesEventModel>().ReverseMap();
            CreateMap<MobilePumpReserveResponsesEventModel, MobilePumpReserveResponsesEvent>().ReverseMap();
            CreateMap<MobileStacCaptureResponsesEventModel, MobileStacCaptureResponsesEvent>().ReverseMap();
            #endregion

            #region Payment Mapper
            CreateMap<PaymentMethodAddedEvent, PaymentMethodAddedEventModel>().ReverseMap();
            CreateMap<PaymentMethodRemovedEvent, PaymentMethodRemovedEventModel>().ReverseMap();
            CreateMap<PaymentFailedEvent, PaymentFailedEventModel>().ReverseMap();
            CreateMap<PaymentFailureSupportTeamEvent, PaymentFailureSupportTeamEventModel>().ReverseMap();
            CreateMap<PaymentStatusEvent, PaymentStatusEventModel>().ReverseMap();
            #endregion

            #region Store Mapper
            CreateMap<StoreEvent, StoreEventModel>().ReverseMap();
            CreateMap<StoreUserEvent, StoreUserEventModel>().ReverseMap();
            #endregion
        }
    }
}
