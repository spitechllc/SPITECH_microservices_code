﻿using AutoMapper;
using SpiTech.Notifications.Domain.Entities;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Domain.Mappers
{
    public class UserProfile : Profile
    {
        public UserProfile()
        {
            CreateMap<UserNotificationConfigration, UserInfoModel>().ReverseMap();
            CreateMap<UserNotificationConfigration, UserNotificationConfigrationModel>().ReverseMap();
            CreateMap<Service.Clients.Identity.UserModel, UserInfoModel>().ReverseMap();
            CreateMap<UserNotificationConfigrationModel, UserInfoModel>().ReverseMap();
            CreateMap<Service.Clients.Identity.UserModel, UserNotificationConfigrationModel>().ReverseMap();
        }
    }
}
