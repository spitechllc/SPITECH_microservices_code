﻿using AutoMapper;
using SpiTech.Notifications.Domain.Entities;
using SpiTech.Notifications.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Domain.Mappers
{
    public class ActivityTypeProfile : Profile
    {
        public ActivityTypeProfile()
        {
            CreateMap<ActivityType, ActivityTypeModel>().ReverseMap();
        }
    }
}
