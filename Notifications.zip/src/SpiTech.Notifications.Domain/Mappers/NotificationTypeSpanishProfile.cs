﻿using AutoMapper;
using SpiTech.Notifications.Domain.Entities;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Domain.Mappers
{
    public class NotificationTypeSpanishProfile : Profile
    {
        public NotificationTypeSpanishProfile()
        {
            CreateMap<NotificationTypeSpanish, NotificationTypeSpanishModel>().ReverseMap();
        }
    }
}
