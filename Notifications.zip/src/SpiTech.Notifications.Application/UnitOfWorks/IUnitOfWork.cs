﻿using SpiTech.ApplicationCore.UnitOfWorks;
using SpiTech.Notifications.Application.Repositories;

namespace SpiTech.Notifications.Application.UnitOfWorks
{
    public interface IUnitOfWork : IBaseUnitOfWork
    {
        IGuestUserRepository GuestUsers { get; }
        IUserNotificationConfigrationRepository UserNotificationConfigrations { get; }
        INotificationModuleRepository NotificationModules { get; }
        INotificationTypeRepository NotificationTypes { get; }
        INotificationRepository Notifications { get; }
        INotificationRecipientRepository NotificationRecipients { get; }
        INotificationConfigRepository NotificationConfigs { get; }
        IPushNotificationRepository PushNotifications { get; }
        IUserNotificationRepository UserNotifications { get; }
        IActivityTypeRepository ActivityTypes { get; }
        IActivityRepository Activities { get; }
    }
}
