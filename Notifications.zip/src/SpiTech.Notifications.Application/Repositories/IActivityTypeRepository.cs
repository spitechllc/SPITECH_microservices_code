﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Notifications.Domain.Entities;

namespace SpiTech.Notifications.Application.Repositories
{
    public interface IActivityTypeRepository : IRepository<ActivityType>
    {
    }
}
