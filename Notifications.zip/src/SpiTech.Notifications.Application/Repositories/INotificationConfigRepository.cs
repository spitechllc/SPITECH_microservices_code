﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Notifications.Domain.Entities;
using SpiTech.Notifications.Domain.Enums;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Repositories
{
    public interface INotificationConfigRepository : IRepository<NotificationConfig>
    {
        Task<NotificationConfig> GetConfigs(NotificationConfigType notificationConfigType);
    }
}
