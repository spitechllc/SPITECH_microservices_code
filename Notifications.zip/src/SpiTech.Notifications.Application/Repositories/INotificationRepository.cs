﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Notifications.Domain.Entities;
using SpiTech.Notifications.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Repositories
{
    public interface INotificationRepository : IRepository<Notification>
    {
        Task<List<Notification>> GetByIds(int[] ids);
        Task<Notification> GetByFilter(string messageIdentifier);
        Task<List<AppNotificationModel>> GetAppNotificationList(int? PageIndex, int? PageSize, string SortBy, string SortOrder);
        Task<AppNotificationDetailModel> GetAppNotificationById(int notificationId);
    }
}
