﻿using SpiTech.ApplicationCore.Repositories;
using PushNotification = SpiTech.Notifications.Domain.Entities.PushNotification;

namespace SpiTech.Notifications.Application.Repositories
{
    public interface IPushNotificationRepository : IRepository<PushNotification>
    {
    }
}
