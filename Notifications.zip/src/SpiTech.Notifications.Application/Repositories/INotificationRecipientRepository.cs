﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Notifications.Domain.Entities;
using SpiTech.Notifications.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Repositories
{
    public interface INotificationRecipientRepository : IRepository<NotificationRecipient>
    {
        Task<List<NotificationRecipientModel>> GetNotificationRecipientByFilter(int? recipientUserId, int? pageIndex, int? pageSize, bool? isRead);

        Task<int> GetUnreadNotificationCount(int recipientUserId);

        Task<bool> UpdateNotificationReadStatus(int recipientUserId, int[] notificationRecipientIds);
    }
}
