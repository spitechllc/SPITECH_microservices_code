﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Notifications.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Repositories
{
    public interface INotificationTypeRepository : IRepository<NotificationType>
    {
        Task<List<NotificationType>> GetByfilter(int notificationTypeId, int notificationModuleId, string notificationTypeIdentifier);
        Task<List<NotificationType>> GetByIds(int[] notificationTypeIds);
        Task<int> UpdateNotificationMessages(int notificationTypeId, string notificationTypeIdentifier, string displaymessage, string emailsubject, string smstemplate,string pushNotificationTemplate);
    }
}
