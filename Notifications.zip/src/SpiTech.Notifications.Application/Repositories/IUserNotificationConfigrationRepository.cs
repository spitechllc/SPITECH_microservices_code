﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.Notifications.Domain.Entities;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Repositories
{
    public interface IUserNotificationConfigrationRepository : IRepository<UserNotificationConfigration>
    {
        Task<bool> UpdateUser(int userId, bool emailNotificationAllow, bool appNotificationAllow);
    }
}
