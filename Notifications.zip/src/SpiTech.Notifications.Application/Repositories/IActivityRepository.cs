﻿using SpiTech.ApplicationCore.Repositories;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Notifications.Domain.Entities;
using SpiTech.Notifications.Domain.Enums;
using SpiTech.Notifications.Domain.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Repositories
{
    public interface IActivityRepository : IRepository<Activity>
    {
        Task<List<ActivityReportModel>> GetActivityByFilter(int? userId, DateTime? startDateUtc, DateTime? endDateUtc,int? pageIndex, int? pageSize, ActivitySortBy? sortBy, SortOrderEnum? sortOrder);
    }
}
