﻿using CorePush.Interfaces;

namespace SpiTech.Notifications.Application.Interfaces
{
    public interface IBusinessFcmSender : IFcmSender
    {
    }
}
