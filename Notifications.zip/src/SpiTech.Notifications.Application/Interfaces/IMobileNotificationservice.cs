﻿using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Interfaces
{
    public interface IMobileNotificationservice
    {
        Task<string> SendSms(string text, string mobileNumber);
    }
}
