﻿using SpiTech.Notifications.Domain.Models;
using System;

namespace SpiTech.Notifications.Application.Interfaces
{
    public interface IEmailService
    {
        void SendEmail(
            string[] toEmails,
            string[] ccEmails,
            string subject,
            string htmlBodyTemplate,
            EmailAttachmentModel[] attachments = null,
            string fromEmail = null, string tenantName= null);
    }
}