﻿using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Notifications.Domain.Models;
using System;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Interfaces
{
    public interface IPushNotificationService
    {
        Task<bool> SendNotification(MobileAppType mobileAppType, string userToken, PushNotification notification);

        Task<bool> SendNotification(DeviceType Dtype, MobileAppType mobileAppType, string userToken, string type,
            string title, string body, object data, string bodyTemplateFile, int UnReadCount, Func<string, string> bodyTemplateMacroBinder = null);
    }
}
