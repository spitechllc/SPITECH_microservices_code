﻿using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Interfaces
{
    public interface IEmailBatchProcessor
    {
        Task Process(CancellationToken token = default);
    }
}