﻿using CorePush.Google;
using FluentValidation;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.ApplicationCore.AppSettingsConfigLoader;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Account;
using SpiTech.EventBus.DomainEvents.Events.Finance;
using SpiTech.EventBus.DomainEvents.Events.Identity;
using SpiTech.EventBus.DomainEvents.Events.Marketings;
using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Mobiles;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.EventBus.DomainEvents.Events.Store;
using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.EventBus.DomainEvents.ServiceCollection;
using SpiTech.Notifications.Application.EventConsumers.Account;
using SpiTech.Notifications.Application.EventConsumers.Finance;
using SpiTech.Notifications.Application.EventConsumers.Identity;
using SpiTech.Notifications.Application.EventConsumers.Marketing;
using SpiTech.Notifications.Application.EventConsumers.Mppa;
using SpiTech.Notifications.Application.EventConsumers.Notification;
using SpiTech.Notifications.Application.EventConsumers.Payment;
using SpiTech.Notifications.Application.EventConsumers.Store;
using SpiTech.Notifications.Application.EventConsumers.Transactions;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Application.Processors;
using SpiTech.Notifications.Application.PushNotifications;
using SpiTech.Notifications.Application.Services;
using SpiTech.Notifications.Domain.Configs;
using SpiTech.Notifications.Domain.Entities;
using System.Linq;
using System.Reflection;
using Twilio;

namespace SpiTech.Notifications.Application
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services, IConfiguration configuration)
        {
            services
                .AddMediatR(Assembly.GetExecutingAssembly()).AddAutoMapper(typeof(Notification))
                .AddValidatorsFromAssembly(Assembly.GetExecutingAssembly())
                .ConfigureRabbitMQ(configuration);

            services.AddScoped<IEmailTemplateProcessService, EmailTemplateProcessService>();
            services.AddScoped<IEmailBatchProcessor, EmailBatchProcessor>();
            services.AddScoped<IPushNotificationService, PushNotificationService>();

            services.AddHostedService<EmailProcessorHostedService>();

            services.AddSingleton(configuration.GetSection(nameof(BatchProcessorConfig)).Get<BatchProcessorConfig>());
            services.AddSingleton(configuration.GetSection(nameof(EmailClientConfig)).Get<EmailClientConfig>());

            FcmSettingConfigList fcmSettingConfigList = configuration.LoadConfig<FcmSettingConfigList>();
            services.AddSingleton(fcmSettingConfigList);

            FcmSettingConfig businessFcmSettingConfig = fcmSettingConfigList.FirstOrDefault(t => t.MobileAppType == MobileAppType.Business);
            services.AddScoped<IBusinessFcmSender>(t => new BusinessFcmSender(new FcmSettings
            {
                SenderId = businessFcmSettingConfig.SenderId,
                ServerKey = businessFcmSettingConfig.ServerKey
            }, new System.Net.Http.HttpClient()));

            FcmSettingConfig consumerFcmSettingConfig = fcmSettingConfigList.FirstOrDefault(t => t.MobileAppType == MobileAppType.Consumer);
            services.AddScoped<IConsumerFcmSender>(t => new ConsumerFcmSender(new FcmSettings
            {
                SenderId = consumerFcmSettingConfig.SenderId,
                ServerKey = consumerFcmSettingConfig.ServerKey
            }, new System.Net.Http.HttpClient()));

            services.AddHttpClient();

            TwilioConfig twilioConfig = configuration.LoadConfig<TwilioConfig>();
            services.AddSingleton(twilioConfig);

            TwilioClient.Init(twilioConfig.AccountSid, twilioConfig.AuthToken);

            services.AddTransient<IMobileNotificationservice, MobileNotificationservice>();

            FirebaseAdmin.FirebaseApp.Create(new FirebaseAdmin.AppOptions
            {
                Credential = Google.Apis.Auth.OAuth2.
                GoogleCredential.FromFile("Credential/SpiTech-21ed0-firebase-adminsdk-cppx3-4d469543e2.json")
            });
            return services;
        }

        public static IServiceCollection ConfigureRabbitMQ(this IServiceCollection services, IConfiguration configuration)
        {
            services.RegisterMessageQueue(configuration, config =>
            {
                config.AddConsumer<InvoiceCancelledEventConsumer>();
                config.AddConsumer<InvoicePaidEventConsumer>();
                config.AddConsumer<InvoiceReceiveEventConsumer>();
                config.AddConsumer<InvoiceRejectedEventConsumer>();

                config.AddConsumer<ExpiringWalletCreditEventConsumer>();
                config.AddConsumer<TransferRequestDeclinedEventConsumer>();
                config.AddConsumer<TransferRequestEventConsumer>();
                config.AddConsumer<WalletCreditEventConsumer>();
                config.AddConsumer<WalletDebitEventConsumer>();
                config.AddConsumer<WalletVoidPaymentEventConsumer>();

                config.AddConsumer<IdentityForgotPasswordEventConsumer>();
                config.AddConsumer<IdentityPasswordChangedEventConsumer>();
                config.AddConsumer<IdentityUserCreatedEventConsumer>();
                config.AddConsumer<IdentityUserSignInEventConsumer>();
                config.AddConsumer<IdentityUserUpdatedEventConsumer>();
                config.AddConsumer<IdentityUserVerificationCodeEventConsumer>();
                config.AddConsumer<UserLinkedAccepterEventConsumer>();
                config.AddConsumer<UserLinkedRequesterEventConsumer>();

                config.AddConsumer<ConsumerOfferSendEventConsumer>();

                config.AddConsumer<MobileFinalizesDataResponseEventConsumer>();
                config.AddConsumer<MobilePumpBeginFualResponsesEventConsumer>();
                config.AddConsumer<MobilePumpReserveResponsesEventConsumer>();
                config.AddConsumer<MobileStacCaptureResponsesEventConsumer>();
                config.AddConsumer<TransactionSettlementEventConsumer>();

                
                config.AddConsumer<PaymentMethodAddedEventConsumer>();
                config.AddConsumer<PaymentMethodRemovedEventConsumer>();
                config.AddConsumer<PaymentFailedEventConsumer>();
                config.AddConsumer<PaymentFailureSupportTeamEventConsumer>();

                config.AddConsumer<StoreEventConsumer>();
                config.AddConsumer<StoreUserEventConsumer>();

				config.AddConsumer<AchNachaReturnFileEventConsumer>();
                config.AddConsumer<StoreEodSettlementInvoiceAdminEventConsumer>();
                config.AddConsumer<SaleAgentMonthlyBillingInvoiceEventConsumer>();
                config.AddConsumer<ResellerMonthlyBillingInvoiceEventConsumer>();
                config.AddConsumer<StoreEodSettlementEventConsumer>();
                config.AddConsumer<StoreEodSettlementInvoiceEventConsumer>();
                config.AddConsumer<StoreMonthlyBillingInvoiceEventConsumer>();

                config.AddConsumer<UserActivityLogEventConsumer>();

            }, (ctx, cfg) =>
            {
                cfg.BindConsumer<InvoiceCancelledEvent, InvoiceCancelledEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<InvoicePaidEvent, InvoicePaidEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<InvoiceReceiveEvent, InvoiceReceiveEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<InvoiceRejectedEvent, InvoiceRejectedEventConsumer>(ctx, EventBusConstants.NotificationService);

                cfg.BindConsumer<ExpiringWalletCreditEvent, ExpiringWalletCreditEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<TransferRequestDeclinedEvent, TransferRequestDeclinedEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<TransferRequestEvent, TransferRequestEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<WalletCreditEvent, WalletCreditEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<WalletDebitEvent, WalletDebitEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<WalletVoidPaymentEvent, WalletVoidPaymentEventConsumer>(ctx, EventBusConstants.NotificationService);


                cfg.BindConsumer<IdentityForgotPasswordEvent, IdentityForgotPasswordEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<IdentityPasswordChangedEvent, IdentityPasswordChangedEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<IdentityUserCreatedEvent, IdentityUserCreatedEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<IdentityUserSignInEvent, IdentityUserSignInEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<IdentityUserUpdatedEvent, IdentityUserUpdatedEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<IdentityUserVerificationCodeEvent, IdentityUserVerificationCodeEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<UserLinkedAccepterEvent, UserLinkedAccepterEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<UserLinkedRequesterEvent, UserLinkedRequesterEventConsumer>(ctx, EventBusConstants.NotificationService);


                cfg.BindConsumer<ConsumerOfferSendEvent, ConsumerOfferSendEventConsumer>(ctx, EventBusConstants.NotificationService);


                cfg.BindConsumer<MobileFinalizesDataResponseEvent, MobileFinalizesDataResponseEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<MobilePumpBeginFualResponsesEvent, MobilePumpBeginFualResponsesEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<MobilePumpReserveResponsesEvent, MobilePumpReserveResponsesEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<MobileStacCaptureResponsesEvent, MobileStacCaptureResponsesEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<TransactionSettlementEvent, TransactionSettlementEventConsumer>(ctx, EventBusConstants.NotificationService);


                
                cfg.BindConsumer<PaymentMethodAddedEvent, PaymentMethodAddedEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<PaymentMethodRemovedEvent, PaymentMethodRemovedEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<PaymentFailedEvent, PaymentFailedEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<PaymentFailureSupportTeamEvent, PaymentFailureSupportTeamEventConsumer>(ctx, EventBusConstants.NotificationService);

                cfg.BindConsumer<StoreEvent, StoreEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<StoreUserEvent, StoreUserEventConsumer>(ctx, EventBusConstants.NotificationService);


                cfg.BindConsumer<AchNachaReturnFileEvent, AchNachaReturnFileEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<StoreEodSettlementInvoiceAdminEvent, StoreEodSettlementInvoiceAdminEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<SaleAgentMonthlyBillingInvoiceEvent, SaleAgentMonthlyBillingInvoiceEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<ResellerMonthlyBillingInvoiceEvent, ResellerMonthlyBillingInvoiceEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<StoreEodSettlementEvent, StoreEodSettlementEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<StoreEodSettlementInvoiceEvent, StoreEodSettlementInvoiceEventConsumer>(ctx, EventBusConstants.NotificationService);
                cfg.BindConsumer<StoreMonthlyBillingInvoiceEvent, StoreMonthlyBillingInvoiceEventConsumer>(ctx, EventBusConstants.NotificationService);

                cfg.BindConsumer<UserActivityLogEvent, UserActivityLogEventConsumer>(ctx, EventBusConstants.NotificationService);
            });

            return services;
        }
    }
}