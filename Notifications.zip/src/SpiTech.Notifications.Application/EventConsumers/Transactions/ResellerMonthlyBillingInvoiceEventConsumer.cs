﻿using AutoMapper;
using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Domain.Models.Transactions;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.EventConsumers.Transactions
{
    public class ResellerMonthlyBillingInvoiceEventConsumer : IConsumer<ResellerMonthlyBillingInvoiceEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<ResellerMonthlyBillingInvoiceEventConsumer> _logger;
        private readonly IStoreServiceClient storeApiClient;
        private readonly IMapper mapper;

        public ResellerMonthlyBillingInvoiceEventConsumer(IMediator mediator,
            ILogger<ResellerMonthlyBillingInvoiceEventConsumer> logger,
            IStoreServiceClient storeApiClient,
            IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.storeApiClient = storeApiClient;
            this.mapper = mapper;
        }

        public async Task Consume(ConsumeContext<ResellerMonthlyBillingInvoiceEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                var reseller = await storeApiClient.ResellerAsync(context.Message.ResellerBilling.ResellerId);

                var resellerMonthlyBillingInvoiceEventModel = mapper.Map<ResellerMonthlyBillingInvoiceEventModel>(context.Message);
                resellerMonthlyBillingInvoiceEventModel.Reseller = reseller;

                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    Reseller = reseller,
                    ResellerMacroObject = resellerMonthlyBillingInvoiceEventModel
                });

                _logger.TraceExitMethod(nameof(Consume), $"ResellerMonthlyBillingPaymentPdfEvent event consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}

