﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Transactions;

namespace SpiTech.Notifications.Application.EventConsumers.Transactions
{
    public class AchNachaReturnFileEventConsumer : IConsumer<AchNachaReturnFileEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<AchNachaReturnFileEventConsumer> _logger;
        private readonly IStoreServiceClient storeServiceClient;
        private readonly IMapper _mapper;

        public AchNachaReturnFileEventConsumer(IMediator mediator, 
                                                        ILogger<AchNachaReturnFileEventConsumer> logger,
                                                        IStoreServiceClient storeServiceClient, 
                                                        IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.storeServiceClient = storeServiceClient;
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<AchNachaReturnFileEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                Service.Clients.Stores.StoreInfoModel store = await storeServiceClient.GetMasterStoreInfoAsync();
                var achNachaReturnFileEventModel = _mapper.Map<AchNachaReturnFileEventModel>(context.Message);
                achNachaReturnFileEventModel.Store = store;

                 await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    Store = store,
                    StoreMacroObject = achNachaReturnFileEventModel
                });

                _logger.TraceExitMethod(nameof(Consume), $"AchNachaReturnFileEventConsumer consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}
