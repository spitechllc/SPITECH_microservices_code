﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetStoreInfo;
using System;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Transactions;

namespace SpiTech.Notifications.Application.EventConsumers.Transactions
{
    public class StoreEodSettlementEventConsumer : IConsumer<StoreEodSettlementEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<StoreEodSettlementEventConsumer> _logger;
        private readonly IMapper _mapper;

        public StoreEodSettlementEventConsumer(IMediator mediator, ILogger<StoreEodSettlementEventConsumer> logger, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<StoreEodSettlementEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                Service.Clients.Stores.StoreInfoModel store = await _mediator.Send(new GetStoreInfoQuery { StoreId = context.Message.StoreEodSettlement.StoreId });

                var storeEodSettlementEventModel = _mapper.Map<StoreEodSettlementEventModel>(context.Message);
               
                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    Store = store,
                    StoreMacroObject = storeEodSettlementEventModel
                });
                _logger.TraceExitMethod(nameof(Consume), $"StoreEodSettlementEvent consumed successfully.");

            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}
