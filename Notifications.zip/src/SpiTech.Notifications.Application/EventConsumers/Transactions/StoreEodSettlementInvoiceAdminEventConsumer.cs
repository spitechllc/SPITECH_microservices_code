﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Transactions;

namespace SpiTech.Notifications.Application.EventConsumers.Transactions
{
    public class StoreEodSettlementInvoiceAdminEventConsumer : IConsumer<StoreEodSettlementInvoiceAdminEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<StoreEodSettlementInvoiceAdminEventConsumer> _logger;
        private readonly IStoreServiceClient storeServiceClient;
        private readonly IMapper _mapper;

        public StoreEodSettlementInvoiceAdminEventConsumer(IMediator mediator, 
                                                        ILogger<StoreEodSettlementInvoiceAdminEventConsumer> logger,
                                                        IStoreServiceClient storeServiceClient, 
                                                        IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.storeServiceClient = storeServiceClient;
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<StoreEodSettlementInvoiceAdminEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                Service.Clients.Stores.StoreInfoModel store = await storeServiceClient.GetMasterStoreInfoAsync();
                var storeEodSettlementInvoiceAdminEventModel = _mapper.Map<StoreEodSettlementInvoiceAdminEventModel>(context.Message);
                storeEodSettlementInvoiceAdminEventModel.Store = store;
                 await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    Store = store,
                    StoreMacroObject = storeEodSettlementInvoiceAdminEventModel
                });

                _logger.TraceExitMethod(nameof(Consume), $"StoreEodSettlementInvoiceAdminEventConsumer consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}
