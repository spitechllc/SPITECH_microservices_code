﻿using AutoMapper;
using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Domain.Models.Transactions;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.EventConsumers.Transactions
{
    public class SaleAgentMonthlyBillingInvoiceEventConsumer : IConsumer<SaleAgentMonthlyBillingInvoiceEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<SaleAgentMonthlyBillingInvoiceEventConsumer> _logger;
        private readonly IStoreServiceClient storeApiClient;
        private readonly IMapper mapper;

        public SaleAgentMonthlyBillingInvoiceEventConsumer(IMediator mediator,
            ILogger<SaleAgentMonthlyBillingInvoiceEventConsumer> logger,
            IStoreServiceClient storeApiClient,
            IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.storeApiClient = storeApiClient;
            this.mapper = mapper;
        }

        public async Task Consume(ConsumeContext<SaleAgentMonthlyBillingInvoiceEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                var saleAgent = await storeApiClient.SaleAgentAsync(context.Message.SaleAgentBilling.SaleAgentId);

                var saleAgentMonthlyBillingInvoiceEventModel = mapper.Map<SaleAgentMonthlyBillingInvoiceEventModel>(context.Message);
                saleAgentMonthlyBillingInvoiceEventModel.SaleAgent = saleAgent;

                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    SaleAgent = saleAgent,
                    SaleAgentMacroObject = saleAgentMonthlyBillingInvoiceEventModel
                });

                _logger.TraceExitMethod(nameof(Consume), $"SaleAgentMonthlyBillingPaymentPdfEvent event consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}

