﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using System;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Payment;

namespace SpiTech.Notifications.Application.EventConsumers.Payment
{
    public class PaymentFailedEventConsumer : IConsumer<PaymentFailedEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<PaymentFailedEventConsumer> _logger;
        private readonly IMapper _mapper;

        public PaymentFailedEventConsumer(IMediator mediator, ILogger<PaymentFailedEventConsumer> logger, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<PaymentFailedEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                Domain.Models.UserInfoModel user = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.UserId });

                var paymentFailedEventModel = _mapper.Map<PaymentFailedEventModel>(context.Message);
                paymentFailedEventModel.User = user;
                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    User = user,
                    UserMacroObject= paymentFailedEventModel,
                });

                _logger.TraceExitMethod(nameof(Consume), $"PaymentFailedEvent consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}
