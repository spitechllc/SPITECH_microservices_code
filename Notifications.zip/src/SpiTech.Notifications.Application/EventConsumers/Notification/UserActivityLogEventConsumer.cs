﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Notifications.Application.Commands.CreateUserNotificationConfigration;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using SpiTech.Notifications.Application.UnitOfWorks;
using System;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Identity;
using SpiTech.EventBus.DomainEvents.Events.Notification;
using SpiTech.Notifications.Application.Commands.CreateUserActivityLog;

namespace SpiTech.Notifications.Application.EventConsumers.Notification
{
    public class UserActivityLogEventConsumer : IConsumer<UserActivityLogEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<UserActivityLogEventConsumer> _logger;
        private readonly IUnitOfWork context;
        private readonly IMapper _mapper;

        public UserActivityLogEventConsumer(IMediator mediator,
            ILogger<UserActivityLogEventConsumer> logger,
            IUnitOfWork context, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.context = context;
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<UserActivityLogEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                _logger.Warn($"SMS Message check UserActivityLogEvent");

                try
                {
                    await _mediator.Send(new CreateUserActivityLogCommand
                    {
                        ActivityTypeId = context.Message.ActivityTypeId,
                        UserId = context.Message.UserId,
                        ActivityRecordKeyId = context.Message.ActivityRecordKeyId,
                        ActivityTime = context.Message.ActivityTime,
                        ActivityIP=context.Message.ActivityIP,
                        ActivityPreData=context.Message.ActivityPreData,
                        ActivityPostData=context.Message.ActivityPostData
                    });
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                    throw;
                }

                _logger.TraceExitMethod(nameof(Consume), $"UserActivityLogEvent consumed successfully.");
                _logger.Warn($"SMS Message check UserActivityLogEvent consumed successfully");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}
