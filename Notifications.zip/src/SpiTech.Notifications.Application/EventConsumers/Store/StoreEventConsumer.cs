﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Store;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetStoreInfo;
using SpiTech.Notifications.Application.UnitOfWorks;
using System;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Store;

namespace SpiTech.Notifications.Application.EventConsumers.Store
{
    public class StoreEventConsumer : IConsumer<StoreEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<StoreEventConsumer> _logger;
        private readonly IUnitOfWork context;
        private readonly IMapper _mapper;

        public StoreEventConsumer(IMediator mediator, ILogger<StoreEventConsumer> logger, IUnitOfWork context, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.context = context;
            this._mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }
        public async Task Consume(ConsumeContext<StoreEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                Service.Clients.Stores.StoreInfoModel store = await _mediator.Send(new GetStoreInfoQuery { StoreId = context.Message.StoreId });

                var storeEventModel = _mapper.Map<StoreEventModel>(context.Message);
                storeEventModel.Store = store;
                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    Store = store,
                    StoreMacroObject = storeEventModel

                });

                _logger.TraceExitMethod(nameof(Consume), $"StoreEvent consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}
