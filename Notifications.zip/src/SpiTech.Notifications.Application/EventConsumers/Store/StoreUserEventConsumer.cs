﻿using MediatR;
using System;
using MassTransit;
using System.Linq;
using System.Threading.Tasks;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Store;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetStoreInfo;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using SpiTech.Notifications.Application.UnitOfWorks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Store;
using SpiTech.Notifications.Application.Queries.GetCompanyById;
using SpiTech.EventBus.DomainEvents.Enums;

namespace SpiTech.Notifications.Application.EventConsumers.Store
{
    public class StoreUserEventConsumer : IConsumer<StoreUserEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<StoreUserEventConsumer> _logger;
        private readonly IUnitOfWork context;
        private readonly IMapper _mapper;

        public StoreUserEventConsumer(IMediator mediator, ILogger<StoreUserEventConsumer> logger, IUnitOfWork context, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.context = context;
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }
        public async Task Consume(ConsumeContext<StoreUserEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                Domain.Models.UserInfoModel user = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.UserId });
                var storeUserEventModel = _mapper.Map<StoreUserEventModel>(context.Message);

                Service.Clients.Stores.StoreInfoModel store = null;
                if (context.Message.StoreId > 0)
                {
                    store = await _mediator.Send(new GetStoreInfoQuery { StoreId = context.Message.StoreId });
                    user.Email = store.Emails.Select(s => s.Email).FirstOrDefault();
                    storeUserEventModel.Emails.AddRange(store.Emails.Where(t => t.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.Main).Select(t => t.Email));
                }
                else if (context.Message.CompanyId > 0)
                {
                    var comp = await _mediator.Send(new GetCompanyByIdQuery { ComapnyId = context.Message.CompanyId });

                    user.Email = comp.Emails.Select(s=>s.Email).FirstOrDefault();
                    storeUserEventModel.Emails.AddRange(comp.Emails.Where(t => t.CategoryTypeLevelId == (int)CompanyEmailCategoryTypeLevel.Main ).Select(t => t.Email));

                }
                storeUserEventModel.Store = store;
                storeUserEventModel.User = user;
                user.EmailConfirmed = true;
                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    User = user,
                    // Store=store,
                    UserMacroObject = storeUserEventModel,
                    //StoreMacroObject= storeUserEventModel
                });

                _logger.TraceExitMethod(nameof(Consume), $"StoreUserEvent consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }

}

