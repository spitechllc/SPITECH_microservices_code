﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Marketings;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetStoreInfo;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using System;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Marketing;

namespace SpiTech.Notifications.Application.EventConsumers.Marketing
{
    public class ConsumerOfferSendEventConsumer : IConsumer<ConsumerOfferSendEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<ConsumerOfferSendEventConsumer> _logger;
        private readonly IMapper _mapper;

        public ConsumerOfferSendEventConsumer(IMediator mediator, ILogger<ConsumerOfferSendEventConsumer> logger, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }
        public async Task Consume(ConsumeContext<ConsumerOfferSendEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                Service.Clients.Stores.StoreInfoModel store = await _mediator.Send(new GetStoreInfoQuery { StoreId = context.Message.StoreId });

                Service.Clients.Stores.AddressModel address = store.Addresses.FirstOrDefault();

                var consumerOfferSendEventModel = _mapper.Map<ConsumerOfferSendEventModel>(context.Message);

                consumerOfferSendEventModel.StoreName = store.StoreName;
                consumerOfferSendEventModel.StoreAddress = address;
                
                if (context.Message.UserIds != null && context.Message.UserIds.Any())
                {
                    foreach (int userId in context.Message.UserIds)
                    {
                        try
                        {
                            Domain.Models.UserInfoModel user = await _mediator.Send(new GetUserInfoQuery { UserId = userId });
                            consumerOfferSendEventModel.User = user;
                            await _mediator.Send(new EventNotificationCommand
                            {
                                User = user,
                                Event = context.Message,
                                UserMacroObject = consumerOfferSendEventModel
                            });
                        }
                        catch (Exception ex)
                        {
                            _logger.Error(ex);
                        }
                    }
                }
                _logger.TraceExitMethod(nameof(Consume), $"ConsumerOfferSendEvent consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}