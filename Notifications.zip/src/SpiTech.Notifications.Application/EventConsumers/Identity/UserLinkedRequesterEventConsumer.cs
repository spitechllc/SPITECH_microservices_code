﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Identity;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using System;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Identity;

namespace SpiTech.Notifications.Application.EventConsumers.Identity
{
    public class UserLinkedRequesterEventConsumer : IConsumer<UserLinkedRequesterEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<UserLinkedRequesterEventConsumer> _logger;
        private readonly IMapper _mapper;

        public UserLinkedRequesterEventConsumer(IMediator mediator, ILogger<UserLinkedRequesterEventConsumer> logger, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<UserLinkedRequesterEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                Domain.Models.UserInfoModel acceptUser = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.AcceptUserId });
                Domain.Models.UserInfoModel requestedUser = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.RequestedUserId });

                var userLinkedRequesterEventModel = _mapper.Map<UserLinkedRequesterEventModel>(context.Message);
                userLinkedRequesterEventModel.User = requestedUser;
                userLinkedRequesterEventModel.AccepterName = acceptUser.FirstName + " " + acceptUser.LastName;

                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    User = requestedUser,
                    UserMacroObject = userLinkedRequesterEventModel
                });
                _logger.TraceExitMethod(nameof(Consume), $"UserLinkedRequesterEvent consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}
