﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Identity;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using SpiTech.Notifications.Application.UnitOfWorks;
using System;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Identity;

namespace SpiTech.Notifications.Application.EventConsumers.Identity
{
    public class IdentityUserUpdatedEventConsumer : IConsumer<IdentityUserUpdatedEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<IdentityUserUpdatedEventConsumer> _logger;
        private readonly IUnitOfWork context;
        private readonly IMapper _mapper;

        public IdentityUserUpdatedEventConsumer(IMediator mediator,
            ILogger<IdentityUserUpdatedEventConsumer> logger,
            IUnitOfWork context, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.context = context;
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<IdentityUserUpdatedEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                Domain.Models.UserInfoModel user = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.UserId });

                var identityUserUpdatedEventModel = _mapper.Map<IdentityUserUpdatedEventModel>(context.Message);
                identityUserUpdatedEventModel.User = user;

                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    User = user,
                    MobileAppType = context.Message.MobileAppType,
                    UserMacroObject = identityUserUpdatedEventModel
                });
                _logger.TraceExitMethod(nameof(Consume), $"IdentityUserUpdatedEvent consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}
