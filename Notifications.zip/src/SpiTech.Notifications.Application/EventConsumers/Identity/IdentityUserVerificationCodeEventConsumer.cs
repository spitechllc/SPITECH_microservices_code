﻿using AutoMapper;
using Flurl;
using MassTransit;
using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.HttpClients;
using SpiTech.EventBus.DomainEvents.Events.Identity;
using SpiTech.Notifications.Application.Commands.TextNotification;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using SpiTech.Notifications.Application.Services;
using SpiTech.Notifications.Application.UnitOfWorks;
using SpiTech.Notifications.Domain.Entities;
using SpiTech.Notifications.Domain.Models.Identity;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.EventConsumers.Identity
{
    public class IdentityUserVerificationCodeEventConsumer : IConsumer<IdentityUserVerificationCodeEvent>
    {
        private const string TemplateFolder = "Identity";
        private readonly IUnitOfWork dbcontext;
        private readonly IMediator _mediator;
        private readonly ILogger<IdentityUserVerificationCodeEventConsumer> _logger;
        private readonly IEmailService emailService;
        private readonly IdentityConfig identityConfig;
        private readonly IEmailTemplateProcessService emailTemplateProcessService;
        private readonly IMapper _mapper;

        public IdentityUserVerificationCodeEventConsumer(IUnitOfWork context, IMediator mediator,
            ILogger<IdentityUserVerificationCodeEventConsumer> logger,
            IEmailService emailService,
            IdentityConfig identityConfig,
            IEmailTemplateProcessService emailTemplateProcessService, IMapper mapper)
        {
            dbcontext = context;
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.emailService = emailService;
            this.identityConfig = identityConfig;
            this.emailTemplateProcessService = emailTemplateProcessService;
            _mapper = mapper;
        }
        public async Task Consume(ConsumeContext<IdentityUserVerificationCodeEvent> context)
        {
            _logger.Warn($"SMS Message check IdentityUserVerificationCodeEvent");
            _logger.TraceEnterMethod(nameof(Consume), context.Message);

            UserNotification userNotification = new()
            {
                UserId = context.Message.UserId,
                NotificationData = JsonConvert.SerializeObject(context.Message),
            };
            bool isEmail = false;

            try
            {
                Domain.Models.UserInfoModel user = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.UserId });
                var preferedLanguage = "";

                if (user!=null && user.PreferedLanguage == "es")
                {
                    preferedLanguage = "-es";
                }

                var identityUserVerificationCodeEventModel = _mapper.Map<IdentityUserVerificationCodeEventModel>(context.Message);

                if (context.Message.CodeType == EventBus.DomainEvents.Enums.CodeType.EmailVerification)
                {
                    isEmail = true;
                    userNotification.Email = context.Message.Receiver;
                    string verificationlink = Url.Combine(identityConfig.BaseUrl, $"api/AccountUser/VerifyEmail/{context.Message.Code}/{context.Message.TenantName}");

                    if (string.IsNullOrEmpty(context.Message.TenantName))
                    {
                        context.Message.TenantName = "SpiTech Email Verification";
                    }
                    else {
                        context.Message.TenantName = string.Concat(context.Message.TenantName, " Email Verification");
                    }
                    identityUserVerificationCodeEventModel.VerificationLink = verificationlink;

                    if (!string.IsNullOrWhiteSpace(context.Message.Receiver))
                    {
                        emailService.SendEmail(new[] { context.Message.Receiver }
                            , null
                            , context.Message.TenantName
                            , await this.emailTemplateProcessService.ProcessHtmlTemplateFromView(Path.Combine(TemplateFolder, $"EmailVerification{preferedLanguage}.cshtml"), identityUserVerificationCodeEventModel), null,null, context.Message.TenantName);
                    }
                }
                else if (context.Message.CodeType == EventBus.DomainEvents.Enums.CodeType.ForgotPasswordEmail)
                {
                    isEmail = true;
                    userNotification.Email = context.Message.Receiver;
                    if (!string.IsNullOrWhiteSpace(context.Message.Receiver))
                    {
                        emailService.SendEmail(new[] { context.Message.Receiver }
                            , null
                            , "Forgot Password Verification Code"
                            , await this.emailTemplateProcessService.ProcessHtmlTemplateFromView(Path.Combine(TemplateFolder, $"ForgotPassword{preferedLanguage}.cshtml"), identityUserVerificationCodeEventModel));

                        userNotification.EmailSent = true;
                    }
                }
                else if (context.Message.CodeType == EventBus.DomainEvents.Enums.CodeType.MobileVerification)
                {
                    string message = "";
                    userNotification.MobileNumber = context.Message.Receiver;
                    if (string.IsNullOrEmpty(context.Message.TenantName))
                    {
                        message = $"Use verification code {context.Message.Code} for SpiTech mobile verification";
                    }
                    else
                    {
                        message = $"Use verification code {context.Message.Code} for {context.Message.TenantName} mobile verification";
                    }
                    _logger.Warn($"SMS message: { message }");
                    _logger.Warn($"SMS Message Receiver : {context.Message.Receiver}");
                    userNotification.SmsResponse = (await _mediator.Send(new TextNotificationCommand { Message = message, MobileNo = context.Message.Receiver })).Message;
                }
                else if (context.Message.CodeType == EventBus.DomainEvents.Enums.CodeType.ForgotPasswordSms)
                {
                    if (string.IsNullOrEmpty(context.Message.TenantName))
                    {
                        context.Message.TenantName = "SpiTech";
                    }
                    userNotification.MobileNumber = context.Message.Receiver;
                    string message = $"Use verification code {context.Message.Code} for {context.Message.TenantName} forgot password authentication";
                    userNotification.SmsResponse = (await _mediator.Send(new TextNotificationCommand { Message = message, MobileNo = context.Message.Receiver })).Message;
                }
                if (context.Message.CodeType == EventBus.DomainEvents.Enums.CodeType.UserUnlock)
                {
                    isEmail = true;
                    userNotification.Email = context.Message.Receiver;
                    string verificationlink = Url.Combine(identityConfig.BaseUrl, $"api/AccountUser/UnlockUser/{context.Message.Code}");

                    identityUserVerificationCodeEventModel.VerificationLink = verificationlink;

                    if (!string.IsNullOrWhiteSpace(context.Message.Receiver))
                    {
                        emailService.SendEmail(new[] { context.Message.Receiver }
                            , null
                            , "SpiTech User Unlock Account"
                            , await this.emailTemplateProcessService.ProcessHtmlTemplateFromView(Path.Combine(TemplateFolder, $"UserUnlock{preferedLanguage}.cshtml"), identityUserVerificationCodeEventModel));
                    }
                }

                _logger.TraceExitMethod(nameof(Consume), $"IdentityUserVerificationCodeEvent consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);

                userNotification.Error = ex.Message;

                if (isEmail)
                {
                    userNotification.EmailSent = false;
                }
            }

            try
            {
                await dbcontext.UserNotifications.Add(userNotification);

                dbcontext.Commit();
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                dbcontext.Rollback();
            }
        }
    }
}
