﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Identity;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using System;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Identity;

namespace SpiTech.Notifications.Application.EventConsumers.Identity
{
    public class UserLinkedAccepterEventConsumer : IConsumer<UserLinkedAccepterEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<UserLinkedAccepterEventConsumer> _logger;
        private readonly IMapper _mapper;

        public UserLinkedAccepterEventConsumer(IMediator mediator, ILogger<UserLinkedAccepterEventConsumer> logger, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<UserLinkedAccepterEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                Domain.Models.UserInfoModel requestedUser = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.RequestedUserId });
                Domain.Models.UserInfoModel acceptUser = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.AcceptUserId });

                var userLinkedAccepterEventModel = _mapper.Map<UserLinkedAccepterEventModel>(context.Message);
                userLinkedAccepterEventModel.User = acceptUser;
                userLinkedAccepterEventModel.RequesterName = requestedUser.FirstName + " " + requestedUser.LastName;

               

                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    User = acceptUser,
                    UserMacroObject = userLinkedAccepterEventModel
                });

                _logger.TraceExitMethod(nameof(Consume), $"UserLinkedAccepterEvent consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}
