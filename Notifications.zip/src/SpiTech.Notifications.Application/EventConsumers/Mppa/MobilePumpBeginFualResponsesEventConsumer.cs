﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Mobiles;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using System;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Mppa;

namespace SpiTech.Notifications.Application.EventConsumers.Mppa
{
    public class MobilePumpBeginFualResponsesEventConsumer : IConsumer<MobilePumpBeginFualResponsesEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<MobilePumpBeginFualResponsesEventConsumer> _logger;
        private readonly IMapper _mapper;

        public MobilePumpBeginFualResponsesEventConsumer(IMediator mediator, ILogger<MobilePumpBeginFualResponsesEventConsumer> logger, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<MobilePumpBeginFualResponsesEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                Domain.Models.UserInfoModel user = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.PumpBeginFualResponse.UserId });

                var mobilePumpBeginFualResponsesEventModel = _mapper.Map<MobilePumpBeginFualResponsesEventModel>(context.Message);
                mobilePumpBeginFualResponsesEventModel.User = user;

                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    User = user,
                    UserMacroObject = mobilePumpBeginFualResponsesEventModel
                });
                _logger.TraceExitMethod(nameof(Consume), $"MobilePumpBeginFualResponsesEvent consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}
