﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetStoreInfo;
using System;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Mppa;

namespace SpiTech.Notifications.Application.EventConsumers.Mppa
{
    public class TransactionSettlementEventConsumer : IConsumer<TransactionSettlementEvent>
    {
        private readonly IMediator mediator;
        private readonly ILogger<TransactionSettlementEventConsumer> logger;
        private readonly IMapper _mapper;

        public TransactionSettlementEventConsumer(IMediator mediator, ILogger<TransactionSettlementEventConsumer> logger, IMapper mapper)
        {
            this.mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this._mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<TransactionSettlementEvent> context)
        {
            try
            {
                logger.TraceEnterMethod(nameof(Consume), context.Message);

                Service.Clients.Stores.StoreInfoModel store = await mediator.Send(new GetStoreInfoQuery { SiteId = context.Message.SettlementRequest?.SiteId });

                var transactionSettlementEventModel = _mapper.Map<TransactionSettlementEventModel>(context.Message);
                transactionSettlementEventModel.StoreName = store.StoreName;
                transactionSettlementEventModel.StoreAddress = store.Addresses.FirstOrDefault();
                transactionSettlementEventModel.SettlementStatus = context.Message.SettlementRequest.IsReconciled;
                transactionSettlementEventModel.SettlementDetails = "";
                transactionSettlementEventModel.Store = store;
               

                await mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    Store = store,
                    StoreMacroObject = transactionSettlementEventModel
                });

                logger.TraceExitMethod(nameof(Consume), $"TransactionSettlementEventConsumer consumed successfully.");
            }
            catch (Exception ex)
            {
                logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}