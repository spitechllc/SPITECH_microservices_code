﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Mobiles;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using System;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Mppa;

namespace SpiTech.Notifications.Application.EventConsumers.Mppa
{
    public class MobileStacCaptureResponsesEventConsumer : IConsumer<MobileStacCaptureResponsesEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<MobileStacCaptureResponsesEventConsumer> _logger;
        private readonly IMapper _mapper;

        public MobileStacCaptureResponsesEventConsumer(IMediator mediator, ILogger<MobileStacCaptureResponsesEventConsumer> logger, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<MobileStacCaptureResponsesEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                Domain.Models.UserInfoModel user = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.UserId });

                var mobileStacCaptureResponsesEventModel = _mapper.Map<MobileStacCaptureResponsesEventModel>(context.Message);
                mobileStacCaptureResponsesEventModel.Status = context.Message.Success ? "successfully" : "fail";
                mobileStacCaptureResponsesEventModel.User = user;
               

                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    User = user,
                    UserMacroObject = mobileStacCaptureResponsesEventModel
                });
                _logger.TraceExitMethod(nameof(Consume), $"MobileStacCaptureResponsesEvent consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}
