﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Mobiles;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetStoreInfo;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Mppa;

namespace SpiTech.Notifications.Application.EventConsumers.Mppa
{
    public class MobileFinalizesDataResponseEventConsumer : IConsumer<MobileFinalizesDataResponseEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<MobileFinalizesDataResponseEventConsumer> _logger;
        private readonly IMapper _mapper;

        public MobileFinalizesDataResponseEventConsumer(IMediator mediator, ILogger<MobileFinalizesDataResponseEventConsumer> logger, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<MobileFinalizesDataResponseEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                Domain.Models.UserInfoModel user = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.ReceiptData.Transaction.UserId });

                Service.Clients.Stores.StoreInfoModel store = await _mediator.Send(new GetStoreInfoQuery { StoreId = context.Message.ReceiptData.Transaction.StoreId });

               
                var mobileFinalizesDataResponseEventModel = _mapper.Map<MobileFinalizesDataResponseEventModel>(context.Message);
                mobileFinalizesDataResponseEventModel.StoreName = store?.StoreName;
                mobileFinalizesDataResponseEventModel.StoreAddress = store?.Addresses.FirstOrDefault();
                mobileFinalizesDataResponseEventModel.SubTotal = context.Message.ReceiptData.SubTotal.CastMoney();
                mobileFinalizesDataResponseEventModel.Total = context.Message.ReceiptData.Total.CastMoney();
                mobileFinalizesDataResponseEventModel.Tax = context.Message.ReceiptData.Tax.CastMoney();
                mobileFinalizesDataResponseEventModel.Transaction = context.Message.ReceiptData.Transaction;
                mobileFinalizesDataResponseEventModel.PaymentInfo = context.Message.ReceiptData.PaymentInfo;
                mobileFinalizesDataResponseEventModel.Amount = context.Message.ReceiptData.Transaction.FinalAmount.CastMoney();
                mobileFinalizesDataResponseEventModel.User = user;

                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    User = user,
                    UserMacroObject = mobileFinalizesDataResponseEventModel
                });
                _logger.TraceExitMethod(nameof(Consume), $"MobileFinalizesDataResponseEvent consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}
