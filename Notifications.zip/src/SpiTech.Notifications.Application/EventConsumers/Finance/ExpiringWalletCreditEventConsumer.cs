﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.EventBus.DomainEvents.Events.Finance;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using System;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Finance;

namespace SpiTech.Notifications.Application.EventConsumers.Finance
{
    public class ExpiringWalletCreditEventConsumer : IConsumer<ExpiringWalletCreditEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<ExpiringWalletCreditEventConsumer> _logger;
        private readonly IMapper _mapper;

        public ExpiringWalletCreditEventConsumer(IMediator mediator, ILogger<ExpiringWalletCreditEventConsumer> logger, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<ExpiringWalletCreditEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                Domain.Models.UserInfoModel user = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.UserId });
                StringBuilder expiringCreditbody = new();

                var expiringWalletCreditEventModel = _mapper.Map<ExpiringWalletCreditEventModel>(context.Message);
                expiringWalletCreditEventModel.User = user;
               
                
                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    User = user,
                    UserMacroObject = expiringWalletCreditEventModel
                });

                _logger.TraceExitMethod(nameof(Consume), $"ExpiringWalletCreditEvent consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}