﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.ApplicationCore.Processors;
using SpiTech.EventBus.DomainEvents.Events;
using SpiTech.EventBus.DomainEvents.Events.Finance;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetNotificationType;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using SpiTech.Notifications.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Finance;

namespace SpiTech.Notifications.Application.EventConsumers.Finance
{
    public class WalletCreditEventConsumer : IConsumer<WalletCreditEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<WalletCreditEventConsumer> _logger;
        private readonly IMapper _mapper;

        public WalletCreditEventConsumer(IMediator mediator, ILogger<WalletCreditEventConsumer> logger, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<WalletCreditEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);
                string message;
                object macroObject = null;
                Domain.Models.UserInfoModel userTo = new();
                Domain.Models.UserInfoModel user = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.UserId });
                if (context.Message.ToUserId > 0)
                {
                    userTo = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.ToUserId });
                }

                List<NotificationTypeModel> notificationType = (await _mediator.Send(new GetNotificationTypeRequest())).Data.ToList();

                message = notificationType.Where(s => s.NotificationTypeIdentifier == context.Message.WalletCredit.NotificationTypeIdentifier).FirstOrDefault()?.DisplayTemplate;

                var walletCreditEventModel = _mapper.Map<WalletCreditEventModel>(context.Message);
                walletCreditEventModel.User = user;
                if (context.Message.WalletCredit != null)
                {
                    walletCreditEventModel.CreditAmount = context.Message.WalletCredit.CreditAmount.CastMoney();
                    walletCreditEventModel.Name = userTo.DisplayName;
                    walletCreditEventModel.Message = TextTemplateMacroProcessor.Process(message, new
                    {
                        CreditAmount = context.Message.WalletCredit.CreditAmount.CastMoney(),
                        Name = userTo.DisplayName,
                        TransactionCount = context.Message.WalletCredit.TransactionCount,
                        TransactionDesc = context.Message.WalletCredit.TransactionDesc,
                        context.Message.WalletCredit.StoreName
                    });
                    walletCreditEventModel.StoreName = context.Message.WalletCredit.StoreName;
                    walletCreditEventModel.TransactionCount = context.Message.WalletCredit.TransactionCount;
                    walletCreditEventModel.TransactionDesc = context.Message.WalletCredit.TransactionDesc;
                }

                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    User = user,
                    UserMacroObject = walletCreditEventModel
                });

                _logger.TraceExitMethod(nameof(Consume), $"WalletCreditEvent consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}