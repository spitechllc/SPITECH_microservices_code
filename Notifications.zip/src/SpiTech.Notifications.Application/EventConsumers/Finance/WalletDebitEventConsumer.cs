﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.ApplicationCore.Processors;
using SpiTech.EventBus.DomainEvents.Events.Finance;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetNotificationType;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using SpiTech.Notifications.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Finance;

namespace SpiTech.Notifications.Application.EventConsumers.Finance
{
    public class WalletDebitEventConsumer : IConsumer<WalletDebitEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<WalletDebitEventConsumer> _logger;
        private readonly IMapper _mapper;

        public WalletDebitEventConsumer(IMediator mediator, ILogger<WalletDebitEventConsumer> logger, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<WalletDebitEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);
                string message;
                object macroObject = null;
                Domain.Models.UserInfoModel userTo = new();
                Domain.Models.UserInfoModel user = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.UserId });
                if (context.Message.ToUserId > 0)
                {
                    userTo = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.ToUserId });
                }

                List<NotificationTypeModel> notificationType = (await _mediator.Send(new GetNotificationTypeRequest())).Data.ToList();

                message = notificationType.Where(s => s.NotificationTypeIdentifier == context.Message.NotificationTypeIdentifier).FirstOrDefault()?.DisplayTemplate;

                var walletDebitEventModel = _mapper.Map<WalletDebitEventModel>(context.Message);
                walletDebitEventModel.User = user;

                if (context.Message.WalletDebit != null)
                {
                    walletDebitEventModel.Amount = context.Message.WalletDebit.Amount.CastMoney();
                    walletDebitEventModel.Name = userTo.DisplayName;
                    walletDebitEventModel.TransactionDesc = context.Message.WalletDebit.TransactionDesc;
                    walletDebitEventModel.Message = TextTemplateMacroProcessor.Process(message, new
                    {
                        Amount = context.Message.WalletDebit.Amount.CastMoney(),
                        Name = userTo.DisplayName,
                        TransactionDesc = context.Message.WalletDebit.TransactionDesc,
                        context.Message.WalletDebit.StoreName
                    });
                    walletDebitEventModel.StoreName =context.Message.WalletDebit.StoreName;


                }

                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    User = user,
                    UserMacroObject = walletDebitEventModel
                });

                _logger.TraceExitMethod(nameof(Consume), $"AdminDebitEvent consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}