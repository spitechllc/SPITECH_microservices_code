﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.EventBus.DomainEvents.Events.Finance;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using System;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Finance;

namespace SpiTech.Notifications.Application.EventConsumers.Finance
{
    public class TransferRequestEventConsumer : IConsumer<TransferRequestEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<TransferRequestEventConsumer> _logger;
        private readonly IMapper _mapper;

        public TransferRequestEventConsumer(IMediator mediator, ILogger<TransferRequestEventConsumer> logger, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<TransferRequestEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                Domain.Models.UserInfoModel toUser = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.ToUserId });
                Domain.Models.UserInfoModel fromUser = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.FromUserId });

                var transferRequestEventModel = _mapper.Map<TransferRequestEventModel>(context.Message);
                transferRequestEventModel.TransferRequestAmount = context.Message.TransferAmount.CastMoney();
                transferRequestEventModel.FromName = fromUser?.FirstName + " " + fromUser?.LastName;
                transferRequestEventModel.User = fromUser;

                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    User = fromUser,
                    UserMacroObject = transferRequestEventModel
                });

                _logger.TraceExitMethod(nameof(Consume), $"TransferRequestEvent consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}