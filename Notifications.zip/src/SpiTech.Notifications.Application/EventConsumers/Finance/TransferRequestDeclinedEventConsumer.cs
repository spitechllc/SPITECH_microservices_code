﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Extensions;
using SpiTech.EventBus.DomainEvents.Events.Finance;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using System;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Finance;

namespace SpiTech.Notifications.Application.EventConsumers.Finance
{
    public class TransferRequestDeclinedEventConsumer : IConsumer<TransferRequestDeclinedEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<TransferRequestDeclinedEventConsumer> _logger;
        private readonly IMapper _mapper;

        public TransferRequestDeclinedEventConsumer(IMediator mediator, ILogger<TransferRequestDeclinedEventConsumer> logger, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper=mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<TransferRequestDeclinedEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                Domain.Models.UserInfoModel toUser = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.ToUserId });
                Domain.Models.UserInfoModel fromUser = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.FromUserId });

                var transferRequestDeclinedEventModel = _mapper.Map<TransferRequestDeclinedEventModel>(context.Message);

                transferRequestDeclinedEventModel.TransferRequestAmount = context.Message.TransferAmount.CastMoney();
                transferRequestDeclinedEventModel.ToName = fromUser?.FirstName + " " + fromUser?.LastName;
                transferRequestDeclinedEventModel.User = toUser;

                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    User = toUser,
                    UserMacroObject = transferRequestDeclinedEventModel,
                }) ;

                _logger.TraceExitMethod(nameof(Consume), $"TransferRequestDeclinedEvent consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}