﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Account;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using System;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Account;

namespace SpiTech.Notifications.Application.EventConsumers.Account
{
    public class InvoicePaidEventConsumer : IConsumer<InvoicePaidEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<InvoicePaidEventConsumer> _logger;
        private readonly IMapper _mapper;

        public InvoicePaidEventConsumer(IMediator mediator, ILogger<InvoicePaidEventConsumer> logger, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<InvoicePaidEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                Domain.Models.UserInfoModel senderUser = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.Invoice.SenderId });
                Domain.Models.UserInfoModel receiverUser = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.Invoice.ReceiverId });

                var objInvoicePaidEvent = _mapper.Map<InvoicePaidEventModel>(context.Message);
                objInvoicePaidEvent.SenderUserName = senderUser.FirstName + " " + senderUser.LastName;
                objInvoicePaidEvent.ReceiverUserName = receiverUser.FirstName + " " + receiverUser.LastName;

                objInvoicePaidEvent.User = senderUser;
               
                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    User = senderUser,
                    UserMacroObject = objInvoicePaidEvent
                });
                _logger.TraceExitMethod(nameof(Consume), $"InvoicePaidEvent consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}
