﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events.Account;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using System;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Account;

namespace SpiTech.Notifications.Application.EventConsumers.Account
{
    public class InvoiceRejectedEventConsumer : IConsumer<InvoiceRejectedEvent>
    {
        private readonly IMediator _mediator;
        private readonly ILogger<InvoiceRejectedEventConsumer> _logger;
        private readonly IMapper _mapper;
        public InvoiceRejectedEventConsumer(IMediator mediator, ILogger<InvoiceRejectedEventConsumer> logger, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task Consume(ConsumeContext<InvoiceRejectedEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                Domain.Models.UserInfoModel senderUser = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.Invoice.SenderId });
                Domain.Models.UserInfoModel receiverUser = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.Invoice.ReceiverId });

                var objInvoiceRejectEvent = _mapper.Map<InvoiceRejectedEventModel>(context.Message);
                objInvoiceRejectEvent.SenderUserName = senderUser.FirstName + " " + senderUser.LastName;
                objInvoiceRejectEvent.ReceiverUserName = receiverUser.FirstName + " " + receiverUser.LastName;

                objInvoiceRejectEvent.User = senderUser;

                await _mediator.Send(new EventNotificationCommand
                {
                    Event = context.Message,
                    User = senderUser,
                    UserMacroObject = objInvoiceRejectEvent
                });
                _logger.TraceExitMethod(nameof(Consume), $"InvoiceRejectedEventConsumer consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}
