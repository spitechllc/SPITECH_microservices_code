﻿using MassTransit;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Account;
using SpiTech.Notifications.Application.Commands.Events.EventNotification;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using System;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using SpiTech.Notifications.Domain.Models.Account;

namespace SpiTech.Notifications.Application.EventConsumers.Account
{
    public class InvoiceReceiveEventConsumer : IConsumer<InvoiceReceiveEvent>
    {
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly ILogger<InvoiceReceiveEventConsumer> _logger;

        public InvoiceReceiveEventConsumer(IMediator mediator, ILogger<InvoiceReceiveEventConsumer> logger, IMapper mapper)
        {
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _mapper = mapper;
        }

        public async Task Consume(ConsumeContext<InvoiceReceiveEvent> context)
        {
            try
            {
                _logger.TraceEnterMethod(nameof(Consume), context.Message);

                if (context.Message.Invoice.SenderId > 0)
                {
                    Domain.Models.UserInfoModel senderUser = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.Invoice.SenderId });
                    Domain.Models.UserInfoModel receiverUser = await _mediator.Send(new GetUserInfoQuery { UserId = context.Message.Invoice.ReceiverId });
                    StringBuilder sb = new();

                    var objInvoiceRecieveEvent = _mapper.Map<InvoiceReceiveEventModel>(context.Message);

                    objInvoiceRecieveEvent.UserName = senderUser.FirstName + " " + senderUser.LastName;

                    objInvoiceRecieveEvent.SenderUserName = senderUser.FirstName + " " + senderUser.LastName;
                    objInvoiceRecieveEvent.SenderEmail = senderUser.Email;
                    objInvoiceRecieveEvent.SenderMobile = senderUser.MobileCountryCode + " " + senderUser.MobileNumber;

                    objInvoiceRecieveEvent.ReceiverUserName = receiverUser.FirstName + " " + receiverUser.LastName;
                    objInvoiceRecieveEvent.ReceiverEmail = receiverUser.Email;
                    objInvoiceRecieveEvent.ReceiverMobile = receiverUser.MobileCountryCode + " " + receiverUser.MobileNumber;
                    objInvoiceRecieveEvent.User = receiverUser;
                    objInvoiceRecieveEvent.IssuedOn = DateTime.Now;


                    await _mediator.Send(new EventNotificationCommand
                    {
                        Event = context.Message,
                        User = receiverUser,
                        UserMacroObject = objInvoiceRecieveEvent
                    });
                }
                _logger.TraceExitMethod(nameof(Consume), $"InvoiceReceiveEvent consumed successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, context.Message);
                throw;
            }
        }
    }
}
