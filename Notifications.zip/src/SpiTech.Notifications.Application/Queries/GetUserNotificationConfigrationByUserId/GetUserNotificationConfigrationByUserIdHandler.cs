﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using SpiTech.Notifications.Application.UnitOfWorks;
using SpiTech.Notifications.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Queries.GetUserNotificationConfigrationByUserId
{
    public class GetUserNotificationConfigrationByUserIdHandler :
        IRequestHandler<GetUserNotificationConfigrationByUserIdQuery, UserNotificationConfigrationModel>
    {
        private readonly ILogger<GetUserNotificationConfigrationByUserIdHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly IMediator _mediator;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetUserNotificationConfigrationByUserIdHandler(
                                    ILogger<GetUserNotificationConfigrationByUserIdHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper,
                                    IMediator mediator, IUserAuthenticationProvider userAuthenticationProvider
                                    )
        {
            _logger = logger;
            _context = context;
            _mapper = mapper;
            _mediator = mediator;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<UserNotificationConfigrationModel> Handle(GetUserNotificationConfigrationByUserIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            UserNotificationConfigrationModel result = _mapper.Map<UserNotificationConfigrationModel>(await _context.UserNotificationConfigrations.Get(request.UserId));

            if (result == null)
            {
                UserInfoModel user = await _mediator.Send(new GetUserInfoQuery { UserId = request.UserId });
                result = _mapper.Map<UserNotificationConfigrationModel>(user);
            }

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
