﻿using MediatR;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Queries.GetUserNotificationConfigrationByUserId
{
    public class GetUserNotificationConfigrationByUserIdQuery : IRequest<UserNotificationConfigrationModel>
    {
        public int UserId { get; set; }
    }
}
