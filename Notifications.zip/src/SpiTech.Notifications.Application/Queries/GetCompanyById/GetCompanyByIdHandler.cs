﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Queries.GetCompanyById
{
    public class GetCompanyByIdHandler : IRequestHandler<GetCompanyByIdQuery, CompanyModel>
    {
        private readonly ILogger<GetCompanyByIdHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IStoreServiceClient storeApiClient;

        public GetCompanyByIdHandler(ILogger<GetCompanyByIdHandler> logger,
                                   IMapper mapper,
                                   IStoreServiceClient storeApiClient)
        {
            _logger = logger;
            _mapper = mapper;
            this.storeApiClient = storeApiClient;
        }
        public async Task<CompanyModel> Handle(GetCompanyByIdQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            var result = await storeApiClient.GetCompanyByIdAsync(request.ComapnyId);

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
