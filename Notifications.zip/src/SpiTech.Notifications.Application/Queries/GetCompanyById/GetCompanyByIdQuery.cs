﻿using MediatR;
using SpiTech.Service.Clients.Stores;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Queries.GetCompanyById
{
    public class GetCompanyByIdQuery:IRequest<CompanyModel>
    {
        public int ComapnyId { get; set; }
    }
}
