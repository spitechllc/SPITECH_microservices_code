﻿using MediatR;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Notifications.Domain.Enums;
using SpiTech.Notifications.Domain.Models;
using System;

namespace SpiTech.Notifications.Application.Queries.GetActivityByFilter
{
    public class GetActivityByFilterQuery : IRequest<PaginatedList<ActivityReportModel>>
    {
        public int? UserId { get; set; }
        public DateTime? StartDateUtc { get; set; }
        public DateTime? EndDateUtc { get; set; }
        public int? PageSize { get; set; }
        public int? PageIndex { get; set; }
        public ActivitySortBy? SortBy { get; set; }
        public SortOrderEnum? SortOrder { get; set; }
    }
}
