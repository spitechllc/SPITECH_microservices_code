﻿using AutoMapper;
using MediatR;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Notifications.Application.UnitOfWorks;
using SpiTech.Notifications.Domain.Models;
using SpiTech.Notifications.Application.Queries.GetUserInfo;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Collections.Generic;
using SpiTech.Notifications.Domain.Enums;

namespace SpiTech.Notifications.Application.Queries.GetActivityByFilter
{
    public class GetActivityByFilterHandler : IRequestHandler<GetActivityByFilterQuery,
        PaginatedList<ActivityReportModel>>
    {
        private readonly ILogger<GetActivityByFilterHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IIdentityServiceClient identityServiceClient;

        public GetActivityByFilterHandler(
                                    ILogger<GetActivityByFilterHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper, 
                                    IUserAuthenticationProvider userAuthenticationProvider,
                                    IIdentityServiceClient identityServiceClient)
        {
            _logger = logger;
            _context = context;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
            this.identityServiceClient = identityServiceClient;
        }

        public async Task<PaginatedList<ActivityReportModel>> Handle(GetActivityByFilterQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            System.Collections.Generic.List<ActivityReportModel> result =
                await _context.Activities.GetActivityByFilter(request.UserId, request.StartDateUtc, request.EndDateUtc, request.PageIndex, request.PageSize, request.SortBy, request.SortOrder);

            _logger.TraceExitMethod(nameof(Handle), result);

            int totalRecord = 0;

            if (result != null && result.Any())
            {
                IEnumerable<Service.Clients.Identity.UserModel> userList = await identityServiceClient.GetUserListAsync(result.Select(t => t.UserId).Distinct().ToList());
                foreach (var activity in result)
                {
                    activity.UserName = userList.Where(t => t.UserId == activity.UserId).FirstOrDefault().DisplayName;
                }

                totalRecord = result.FirstOrDefault().TotalRecord;
                if (request.SortOrder != null && request.SortBy != null)
                {
                    if (request.SortBy == ActivitySortBy.UserName)
                    {
                        if (request.SortOrder == EventBus.DomainEvents.Enums.SortOrderEnum.Asc)
                        {
                            result = result.OrderBy(t => t.UserName).ToList();
                        }
                        else
                        {
                            result = result.OrderByDescending(t => t.UserName).ToList();
                        }

                    }
                }
            }


            return new PaginatedList<ActivityReportModel>
            {
                Data = result,
                PageIndex = request.PageIndex ?? 0,
                PageSize = request.PageSize ?? 0,
                TotalCount = totalRecord,
            };
        }
    }
}