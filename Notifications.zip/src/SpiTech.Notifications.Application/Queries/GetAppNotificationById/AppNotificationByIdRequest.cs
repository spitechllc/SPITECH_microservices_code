﻿using MediatR;
using SpiTech.Notifications.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Queries.GetAppNotificationById
{
    public class AppNotificationByIdRequest : IRequest<AppNotificationDetailModel>
    {
        public int NotficationId { get; set; }
    }
}
