﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Notifications.Application.UnitOfWorks;
using SpiTech.Notifications.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Queries.GetAppNotificationById
{
    public class AppNotificationByHandler : IRequestHandler<AppNotificationByIdRequest,
       AppNotificationDetailModel>
    {
        private readonly IMediator _mediater;
        private readonly ILogger<AppNotificationByHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;

        public AppNotificationByHandler(IMediator mediater,
                                    ILogger<AppNotificationByHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper)
        {
            _mediater = mediater;
            _logger = logger;
            _context = context;
            _mapper = mapper;
        }

        public async Task<AppNotificationDetailModel> Handle(AppNotificationByIdRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            AppNotificationDetailModel result = await _context.Notifications.GetAppNotificationById(request.NotficationId);
            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
