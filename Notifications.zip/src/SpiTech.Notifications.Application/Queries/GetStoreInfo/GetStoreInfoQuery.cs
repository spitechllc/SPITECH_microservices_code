﻿using MediatR;
using SpiTech.Service.Clients.Stores;

namespace SpiTech.Notifications.Application.Queries.GetStoreInfo
{
    public class GetStoreInfoQuery : IRequest<StoreInfoModel>
    {
        public int StoreId { get; set; }
        public string SiteId { get; set; }
    }
}
