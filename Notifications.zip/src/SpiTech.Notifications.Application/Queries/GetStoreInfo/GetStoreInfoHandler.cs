﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Queries.GetStoreInfo
{
    public class GetStoreInfoHandler : IRequestHandler<GetStoreInfoQuery, StoreInfoModel>
    {
        private readonly ILogger<GetStoreInfoHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IStoreServiceClient storeApiClient;

        public GetStoreInfoHandler(ILogger<GetStoreInfoHandler> logger,
                                   IMapper mapper,
                                   IStoreServiceClient storeApiClient)
        {
            _logger = logger;
            _mapper = mapper;
            this.storeApiClient = storeApiClient;
        }

        public async Task<StoreInfoModel> Handle(GetStoreInfoQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            var result = await storeApiClient.GetStoreInfoAsync(request.StoreId, request.SiteId);

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}