﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Queries.GetNotificationType
{
    public  class GetNotificationTypeRequest : IRequest<ResponseList<NotificationTypeModel>>
    {
    }
}
