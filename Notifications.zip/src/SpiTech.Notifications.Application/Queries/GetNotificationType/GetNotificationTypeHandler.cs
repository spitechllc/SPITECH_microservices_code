﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Notifications.Application.UnitOfWorks;
using SpiTech.Notifications.Domain.Models;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Queries.GetNotificationType
{
    public class GetNotificationTypeHandler : IRequestHandler<GetNotificationTypeRequest, ResponseList<NotificationTypeModel>>
    {
        private readonly ILogger<GetNotificationTypeHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        public GetNotificationTypeHandler(
                                    ILogger<GetNotificationTypeHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper
                                    )
        {
            _logger = logger;
            _context = context;
            _mapper = mapper;
        }      
        public async Task<ResponseList<NotificationTypeModel>> Handle(GetNotificationTypeRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            ResponseList<NotificationTypeModel> resList = new ResponseList<NotificationTypeModel>();
             var result =_mapper.Map<List<NotificationTypeModel>>(await _context.NotificationTypes.GetByfilter(0,0,""));
            if(result.Count>0)
            {
                resList.Data=result;
            }
            _logger.TraceExitMethod(nameof(Handle), result);
            return resList;
        }
    }
}
