﻿using MediatR;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Queries.GetNotificationRecipientByFilter
{
    public class GetNotificationRecipientByFilterQuery : IRequest<PaginatedList<NotificationRecipientModel>>
    {
        public int? UserId { get; set; }
        public int PageIndex { get; set; }
        public int? PageSize { get; set; }

        public bool? IsRead { get; set; }
    }
}
