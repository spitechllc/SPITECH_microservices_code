﻿using AutoMapper;
using MediatR;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Notifications.Application.UnitOfWorks;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Queries.GetNotificationRecipientByFilter
{
    public class GetNotificationRecipientByFilterHandler : IRequestHandler<GetNotificationRecipientByFilterQuery,
        PaginatedList<NotificationRecipientModel>>
    {
        private readonly ILogger<GetNotificationRecipientByFilterHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetNotificationRecipientByFilterHandler(
                                    ILogger<GetNotificationRecipientByFilterHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _logger = logger;
            _context = context;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<PaginatedList<NotificationRecipientModel>> Handle(GetNotificationRecipientByFilterQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            System.Collections.Generic.List<NotificationRecipientModel> result =
                await _context.NotificationRecipients.GetNotificationRecipientByFilter(request.UserId, request.PageIndex, request.PageSize,
                    request.IsRead);

            _logger.TraceExitMethod(nameof(Handle), result);

            int totalRecord = 0;

            if (result != null && result.Any())
            {
                totalRecord = result.FirstOrDefault().TotalRecord;
            }

            return new PaginatedList<NotificationRecipientModel>
            {
                Data = result,
                PageIndex = request.PageIndex,
                PageSize = request.PageSize ?? 0,
                TotalCount = totalRecord,
            };
        }
    }
}