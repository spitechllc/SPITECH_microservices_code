﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.Notifications.Application.UnitOfWorks;
using SpiTech.Notifications.Domain.Models;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Queries.GetUserInfo
{
    public class GetUserInfoHandler : IRequestHandler<GetUserInfoQuery, UserInfoModel>
    {
        private readonly ILogger<GetUserInfoHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly IMediator _mediator;
        private readonly IIdentityServiceClient _identityapiclient;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetUserInfoHandler(ILogger<GetUserInfoHandler> logger,
                                IUnitOfWork context,
                                IMapper mapper,
                                IMediator mediator,
                                IIdentityServiceClient identityapiclient, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _logger = logger;
            _context = context;
            _mapper = mapper;
            _mediator = mediator;
            _identityapiclient = identityapiclient;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<UserInfoModel> Handle(GetUserInfoQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            //this.userAuthenticationProvider.ValidateUserAccess(request.UserId);
            Service.Clients.Identity.UserModelResponseModel userResponse = await _identityapiclient.SyncUserByIdAsync(request.UserId);

            if (userResponse == null || !userResponse.Success)
            {
                return null;
            }

            UserInfoModel userModel = _mapper.Map<UserInfoModel>(userResponse.Data);

            Domain.Entities.UserNotificationConfigration result = await _context.UserNotificationConfigrations.Get(request.UserId);

            if (result != null)
            {
                userModel.AppNotificationAllow = result.AppNotificationAllow;
                userModel.EmailNotificationAllow = result.EmailNotificationAllow;
            }
            else
            {
                userModel.AppNotificationAllow = true;
                userModel.EmailNotificationAllow = true;
            }

            return userModel;
        }
    }
}
