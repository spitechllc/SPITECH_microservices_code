﻿using MediatR;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Queries.GetUserInfo
{
    public class GetUserInfoQuery : IRequest<UserInfoModel>
    {
        public int UserId { get; set; }
    }
}
