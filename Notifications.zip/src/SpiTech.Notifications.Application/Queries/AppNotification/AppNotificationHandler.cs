﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Notifications.Application.UnitOfWorks;
using SpiTech.Notifications.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Queries.AppNotification
{
    public class AppNotificationHandler : IRequestHandler<AppNotificationRequest, PaginatedList<AppNotificationModel>>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<AppNotificationHandler> _logger;
        private readonly IMapper _mapper;

        public AppNotificationHandler(IUnitOfWork context,
                                    ILogger<AppNotificationHandler> logger,
                                    IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<PaginatedList<AppNotificationModel>> Handle(AppNotificationRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            int totalRecord = 0;

            List<AppNotificationModel> itemModel = _mapper.Map<List<AppNotificationModel>>(await _context.Notifications.GetAppNotificationList(request.PageIndex, request.PageSize,
                request.sortable?.SortBy, request.sortable?.SortOrder));

            if (itemModel != null && itemModel.Count() > 0)
            {
                totalRecord = itemModel.Select(x => x.TotalRecord).FirstOrDefault();
            }
            return new PaginatedList<AppNotificationModel>
            {
                Data = itemModel,
                PageIndex = request.PageIndex ?? 0,
                PageSize = request.PageSize ?? 0,
                TotalCount = totalRecord
            };
        }
    }
}
