﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Notifications.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Queries.AppNotification
{
    public class AppNotificationRequest : IRequest<PaginatedList<AppNotificationModel>>
    {
        public int? PageIndex { get; set; }
        public int? PageSize { get; set; }
        public Sortable sortable { get; set; }
    }
}
