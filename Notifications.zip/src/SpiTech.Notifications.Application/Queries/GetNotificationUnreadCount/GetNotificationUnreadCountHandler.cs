﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.Notifications.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Queries.GetNotificationUnreadCount
{
    public class GetNotificationUnreadCountHandler : IRequestHandler<GetNotificationUnreadCountRequest, int>
    {
        private readonly ILogger<GetNotificationUnreadCountHandler> _logger;
        private readonly IUnitOfWork _context;
        private readonly IMapper _mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GetNotificationUnreadCountHandler(
                                    ILogger<GetNotificationUnreadCountHandler> logger,
                                    IUnitOfWork context,
                                    IMapper mapper, IUserAuthenticationProvider userAuthenticationProvider
                                    )
        {
            _logger = logger;
            _context = context;
            _mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }
        public async Task<int> Handle(GetNotificationUnreadCountRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            int result = await _context.NotificationRecipients.GetUnreadNotificationCount(request.UserId);

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
