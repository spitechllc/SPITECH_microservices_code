﻿using MediatR;

namespace SpiTech.Notifications.Application.Queries.GetNotificationUnreadCount
{
    public class GetNotificationUnreadCountRequest : IRequest<int>
    {
        public int UserId { get; set; }
    }
}
