﻿namespace SpiTech.Notifications.Application
{
    internal class UserActivityLogEventEventConsumer
    {
    }
}