﻿using CorePush.Google;
using SpiTech.Notifications.Application.Interfaces;
using System.Net.Http;

namespace SpiTech.Notifications.Application.PushNotifications
{
    public class ConsumerFcmSender : FcmSender, IConsumerFcmSender
    {
        public ConsumerFcmSender(FcmSettings settings, HttpClient http) : base(settings, http)
        {
        }
    }
}
