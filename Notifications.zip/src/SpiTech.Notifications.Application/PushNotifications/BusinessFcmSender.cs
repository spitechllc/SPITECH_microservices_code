﻿using CorePush.Google;
using SpiTech.Notifications.Application.Interfaces;
using System.Net.Http;

namespace SpiTech.Notifications.Application.PushNotifications
{
    public class BusinessFcmSender : FcmSender, IBusinessFcmSender
    {
        public BusinessFcmSender(FcmSettings settings, HttpClient http) : base(settings, http)
        {
        }
    }
}
