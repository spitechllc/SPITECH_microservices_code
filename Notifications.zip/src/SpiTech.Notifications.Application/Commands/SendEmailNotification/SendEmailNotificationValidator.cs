﻿using FluentValidation;

namespace SpiTech.Notifications.Application.Commands.SendEmailNotification
{
    public class SendEmailNotificationValidator : AbstractValidator<SendEmailNotificationCommand>
    {
        public SendEmailNotificationValidator()
        {
            RuleFor(x => x.Subject).NotNull().WithMessage("Subject is Required");
            RuleFor(x => x.Body).NotNull().WithMessage("Body is Required");
            RuleFor(x => x.NotificationConfigType).NotEmpty().NotNull().WithMessage("NotificationConfigType is Required");
        }
    }
}
