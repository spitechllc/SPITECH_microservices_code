﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Application.UnitOfWorks;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.SendEmailNotification
{
    public class SendEmailNotificationHandler : IRequestHandler<SendEmailNotificationCommand, ResponseModel>
    {
        private readonly IEmailService emailService;
        private readonly IUnitOfWork context;

        public SendEmailNotificationHandler(IEmailService emailService, IUnitOfWork context)
        {
            this.emailService = emailService;
            this.context = context;
        }

        public async Task<ResponseModel> Handle(SendEmailNotificationCommand command, CancellationToken cancellationToken)
        {
            ResponseModel responseModel = new() { Message = "", Success = false };
            try
            {
                Domain.Entities.NotificationConfig config = await context.NotificationConfigs.GetConfigs(command.NotificationConfigType);

                if (config != null && !string.IsNullOrEmpty(config.EmailIds))
                {
                    string[] emails = config.EmailIds.Split(",", StringSplitOptions.RemoveEmptyEntries);
                    if (emails != null & emails.Any())
                    {
                        emailService.SendEmail(emails
                              , null
                              , command.Subject
                              , null
                              , null
                              , command.Body
                              );
                        responseModel = new ResponseModel { Message = $"Success", Success = true };
                    }
                    else
                    {
                        responseModel = new ResponseModel { Message = $"No email configured for {command.NotificationConfigType}", Success = false };
                    }
                }
                else
                {
                    responseModel = new ResponseModel { Message = $"NotificationConfigType {command.NotificationConfigType} is Invalid", Success = false };
                }
            }
            catch (Exception ex)
            {
                responseModel = new ResponseModel { Message = ex.Message, Success = false };
            }
            return await Task.FromResult(responseModel);
        }
    }
}
