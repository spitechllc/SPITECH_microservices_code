﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Notifications.Domain.Enums;

namespace SpiTech.Notifications.Application.Commands.SendEmailNotification
{
    public class SendEmailNotificationCommand : IRequest<ResponseModel>
    {
        public NotificationConfigType NotificationConfigType { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
    }
}
