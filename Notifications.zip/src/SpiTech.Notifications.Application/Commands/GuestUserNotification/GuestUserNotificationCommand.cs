﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Notifications.Domain.Enums;

namespace SpiTech.Notifications.Application.Commands.GuestUserNotification
{
    public class GuestUserNotificationCommand : IRequest<ResponseModel>
    {
        public string UserName { get; set; }
        public string MobileNumber { get; set; }
        public string Email { get; set; }
        public string Description { get; set; }
        public NotificationConfigType NotificationConfigType { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
    }
}
