﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Application.UnitOfWorks;
using SpiTech.Notifications.Domain.Entities;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.GuestUserNotification
{
    public class GuestUserNotificationHandler : IRequestHandler<GuestUserNotificationCommand, ResponseModel>
    {
        private readonly IEmailService emailService;
        private readonly IUnitOfWork context;

        public GuestUserNotificationHandler(IEmailService emailService, IUnitOfWork context)
        {
            this.emailService = emailService;
            this.context = context;
        }

        public async Task<ResponseModel> Handle(GuestUserNotificationCommand command, CancellationToken cancellationToken)
        {
            ResponseModel responseModel = new() { Message = "", Success = false };
            try
            {
                GuestUser gUser = new();
                NotificationConfig config = await context.NotificationConfigs.GetConfigs(command.NotificationConfigType);
                gUser.Email = command.Email;
                gUser.MobileNumber = command.MobileNumber;
                gUser.UserName = command.UserName;
                gUser.Description = command.Description;
                gUser.CreatedOn = DateTime.Now;
                int result = await context.GuestUsers.Add(gUser);
                if (result > 0)
                {
                    if (config != null && !string.IsNullOrEmpty(config.EmailIds))
                    {
                        string[] emails = config.EmailIds.Split(",", StringSplitOptions.RemoveEmptyEntries);
                        if (emails != null & emails.Any())
                        {
                            emailService.SendEmail(emails
                                  , null
                                  , command.Subject
                                  , command.Body
                                  , null
                                  , command.Email
                                  );
                            responseModel = new ResponseModel { Message = $"Success", Success = true };
                            context.Commit();
                        }
                        else
                        {
                            context.Rollback();
                            responseModel = new ResponseModel { Message = $"No email configured for {command.NotificationConfigType}", Success = false };
                        }
                    }
                    else
                    {
                        context.Rollback();
                        responseModel = new ResponseModel { Message = $"NotificationConfigType {command.NotificationConfigType} is Invalid", Success = false };
                    }
                }
                else
                {
                    context.Rollback();
                    responseModel = new ResponseModel { Message = $"Failed to Send Email", Success = false };
                }
            }
            catch (Exception ex)
            {
                context.Rollback();
                responseModel = new ResponseModel { Message = ex.Message, Success = false };
            }
            return await Task.FromResult(responseModel);
        }
    }
}
