﻿using FluentValidation;

namespace SpiTech.Notifications.Application.Commands.GuestUserNotification
{
    public class GuestUserNotificationValidator : AbstractValidator<GuestUserNotificationCommand>
    {
        public GuestUserNotificationValidator()
        {
            RuleFor(x => x.Email).EmailAddress().MaximumLength(250).WithMessage("Valid Email Is Required");
            RuleFor(x => x.MobileNumber).MinimumLength(10).MaximumLength(13).WithMessage("Valid Mobile Number Is Required");
            RuleFor(x => x.UserName).NotNull().NotEmpty().MaximumLength(250).WithMessage("UserName Is Required");
            RuleFor(x => x.Description).NotNull().MinimumLength(10).MaximumLength(500).WithMessage("Description Is Required (Min 10 char)");
            RuleFor(x => x.Subject).NotNull().NotEmpty().WithMessage("Subject is Required");
            RuleFor(x => x.Body).NotNull().NotEmpty().WithMessage("Body is Required");

        }
    }
}
