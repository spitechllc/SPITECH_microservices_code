﻿using FluentValidation.Results;
using MediatR;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Application.UnitOfWorks;
using SpiTech.Notifications.Domain.Enums;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.ReportIssue
{
    public class ReportIssueHandler : IRequestHandler<ReportIssueCommand, ResponseModel>
    {
        private readonly IEmailService emailService;
        private readonly IUnitOfWork context;
        private readonly IStorageService storageService;

        public ReportIssueHandler(IEmailService emailService, IUnitOfWork context, IStorageServiceFactory storageServiceFactory)
        {
            this.emailService = emailService;
            this.context = context;
            storageService = storageServiceFactory.Get(ContainerType.IssueImages);
        }

        public async Task<ResponseModel> Handle(ReportIssueCommand command, CancellationToken cancellationToken)
        {
            ResponseModel responseModel = new() { Message = "", Success = false };
            try
            {
                if (command.Subject != null && command.Body != null)
                {

                    if (command.ImageFileUrl != null && command.ImageFileUrl.Count > 0)
                    {
                        foreach (Microsoft.AspNetCore.Http.IFormFile item in command.ImageFileUrl)
                        {
                            if (item.Length > 0)
                            {
                                if (!item.ContentType.Contains("image"))
                                {
                                    throw new ValidationException(new ValidationFailure("ImageFileUrl", $"Invalid base64"));
                                }
                            }
                            else
                            {
                                throw new ValidationException(new ValidationFailure("ImageFileUrl", $"Image File Required"));
                            }
                        }
                    }
                    if (command.VedioFileUrl != null)
                    {
                        if (command.VedioFileUrl.Length > 0)
                        {
                            if (!(command.VedioFileUrl.ContentType == "video/mp4"))
                            {
                                throw new ValidationException(new ValidationFailure("VedioFileUrl", $"Invalid VedioFileUrl! Please select .mp4 file"));
                            }
                        }
                        else
                        {
                            throw new ValidationException(new ValidationFailure("VedioFileUrl", $"VedioFileUrl is required"));
                        }
                    }
                    string filename = "";
                    string Azurefileurl = "";
                    List<string> imagesurlList = new();
                    int i = 1;
                    Domain.Entities.NotificationConfig config = await context.NotificationConfigs.GetConfigs(NotificationConfigType.Support);
                    StringBuilder createBody = new();

                    createBody.Append(@"<table  width='100%' align='left' style='font-family: 'Lexend', sans-serif; font-size:14px;'>");
                    createBody.Append(@"    <tr>");
                    createBody.Append(@"        <td height='10' align='center'></td>");
                    createBody.Append(@"    </tr>");
                    createBody.Append(@"    <tr>");
                    createBody.Append(@"        <td>");
                    createBody.Append(@"            <table>");
                    createBody.Append(@"                <tr>");
                    createBody.Append(@"                    <td style='text-align: left;'>");
                    createBody.Append(@"                        <strong style='font-size:16px; line-height:5px; font-weight: 200; color: #111320;'>Hi Support Team,</strong><br><br>");
                    createBody.Append(@"                    </td>");
                    createBody.Append(@"                </tr>");
                    createBody.Append(@"                <tr >");
                    createBody.Append(@"                    <td style='font-size:14px; line-height:5px; text-align: left; '>");
                    createBody.Append(@"                        <p >");
                    createBody.Append(command.Body);
                    createBody.Append(@"                        <br><br><br><br>");
                    createBody.Append(@"                        </p>");
                    if (!string.IsNullOrEmpty(command.UserName))
                    {
                        createBody.Append(@"						<p >");
                        createBody.Append("UserName - " + command.UserName);
                        createBody.Append(@"                        </p>");
                    }

                    if (!string.IsNullOrEmpty(command.UserId))
                    {
                        createBody.Append(@"						<p >");
                        createBody.Append("UserId - " + command.UserId);
                        createBody.Append(@"                        </p>");
                    }
                    if (!string.IsNullOrEmpty(command.Email))
                    {
                        createBody.Append(@"						<p >");
                        createBody.Append("Email - " + command.Email);
                        createBody.Append(@"                        </p>");
                    }



                    if (command.ImageFileUrl != null && command.ImageFileUrl.Count() > 0)
                    {
                        foreach (Microsoft.AspNetCore.Http.IFormFile item in command.ImageFileUrl)
                        {
                            if (item.Length > 0)
                            {
                                if (!item.ContentType.Contains("image"))
                                {
                                    throw new ValidationException(new ValidationFailure("ImageFileUrl", $"Invalid File Format"));
                                }
                                else
                                {
                                    string username = string.Empty;
                                    if (!string.IsNullOrEmpty(command.UserName))
                                    {
                                        username = command.UserName.Replace(' ', '_');
                                    }
                                    filename = (string.IsNullOrEmpty(command.UserId) ? username : command.UserId).ToString() + "_IssueImages" + "_" + UniqueIdGenerator.Generate() + Path.GetExtension(item.FileName);
                                    using MemoryStream ms = new();
                                    item.CopyTo(ms);
                                    byte[] fileBytes = ms.ToArray();
                                    string s = Convert.ToBase64String(fileBytes);

                                    Azurefileurl = await SaveFile(s, filename, item.ContentType);
                                    if (!string.IsNullOrEmpty(Azurefileurl))
                                    {
                                        imagesurlList.Add(Azurefileurl);
                                        createBody.Append(@"						<p>");
                                        createBody.Append("Attached Image(s) Url " + Azurefileurl);
                                        createBody.Append(@"                        </p>");
                                        i++;
                                    }

                                }
                            }
                        }
                    }
                    #region upload file over Azure

                    if (command.VedioFileUrl != null)
                    {
                        if (command.VedioFileUrl.Length > 0)
                        {
                            if (command.VedioFileUrl.ContentType == "video/mp4")
                            {
                                string username = string.Empty;
                                if (!string.IsNullOrEmpty(command.UserName))
                                {
                                    username = command.UserName.Replace(' ', '_');
                                }
                                filename = (string.IsNullOrEmpty(command.UserId) ? username : command.UserId).ToString() + "_IssueVedio" + "_" + UniqueIdGenerator.Generate() + Path.GetExtension(command.VedioFileUrl.FileName);

                                using MemoryStream ms = new();
                                command.VedioFileUrl.CopyTo(ms);
                                byte[] fileBytes = ms.ToArray();
                                string s = Convert.ToBase64String(fileBytes);

                                Azurefileurl = await SaveFile(s, filename, command.VedioFileUrl.ContentType);
                                if (!string.IsNullOrEmpty(Azurefileurl))
                                {
                                    imagesurlList.Add(Azurefileurl);
                                    createBody.Append(@"						<p >");
                                    createBody.Append("Attached Vedio Url " + Azurefileurl);
                                    createBody.Append(@"                        </p>");


                                }


                            }
                        }
                    }
                    #endregion

                    createBody.Append(@"                        <br><br>");
                    createBody.Append(@"                    </td>");
                    createBody.Append(@"                </tr>");
                    createBody.Append(@"            </table>");
                    createBody.Append(@"        </td>");
                    createBody.Append(@"    </tr>");
                    createBody.Append(@"</table>");

                    if (config != null && !string.IsNullOrEmpty(config.EmailIds))
                    {
                        string[] emails = config.EmailIds.Split(",", StringSplitOptions.RemoveEmptyEntries);
                        if (emails != null & emails.Any())
                        {
                            emailService.SendEmail(emails.ToArray()
                                  , null
                                  , command.Subject
                                  , createBody.ToString()
                                  );
                            responseModel = new ResponseModel { Message = $"Success", Success = true };
                        }
                    }
                    else
                    {
                        responseModel = new ResponseModel { Message = $"No email configured", Success = false };
                    }
                }
                else
                {
                    responseModel = new ResponseModel { Message = $"No Data Found From Request", Success = false };
                }

            }
            catch (Exception ex)
            {
                responseModel = new ResponseModel
                {
                    Message = ex.Message,
                    Success = false
                };
            }
            return await Task.FromResult(responseModel);
        }


        private async Task<string> SaveFile(string base64file, string filename, string contenttype)
        {
            await storageService.UploadBlobBase64(base64file, filename, contenttype);
            Blob res = await storageService.GetFile(filename);
            return res != null ? res.StorageUri : string.Empty;
        }
    }
}
