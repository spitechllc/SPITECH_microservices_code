﻿using MediatR;
using Microsoft.AspNetCore.Http;
using SpiTech.ApplicationCore.Domain.Models;
using System.Collections.Generic;

namespace SpiTech.Notifications.Application.Commands.ReportIssue
{
    public class ReportIssueCommand : IRequest<ResponseModel>
    {
        public string Email { get; set; }
        public string UserName { get; set; }
        public string UserId { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public List<IFormFile> ImageFileUrl { get; set; }
        public IFormFile VedioFileUrl { get; set; }
    }
}
