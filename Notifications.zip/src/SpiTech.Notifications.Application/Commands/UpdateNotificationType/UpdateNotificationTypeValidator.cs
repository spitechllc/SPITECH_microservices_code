﻿using FluentValidation;

namespace SpiTech.Notifications.Application.Commands.UpdateNotificationType
{
    public class UpdateNotificationTypeValidator : AbstractValidator<UpdateNotificationTypeCommand>
    {
        public UpdateNotificationTypeValidator()
        {
            RuleFor(x => x.NotificationTypeId).GreaterThan(0).WithMessage("NotificationId must be greater than 0");
            RuleFor(x => x.NotificationTypeIdentifier).NotNull().NotEmpty().WithMessage("NotificationTypeIdentifier is required").Length(1,100);
            RuleFor(x => x.DisplayTemplate).NotNull().NotEmpty().WithMessage("DisplayTemplate is required").Length(1,1000);

            RuleFor(s => s.NotificationTypeIdentifier).MaximumLength(100);
            RuleFor(s => s.DisplayTemplate).MaximumLength(1000);
            RuleFor(s => s.SmsTemplate).MaximumLength(1000);
            RuleFor(s => s.EmailSubject).MaximumLength(1000);
            RuleFor(s => s.PushNotificationTemplate).MaximumLength(1000);
        }
    }
}
