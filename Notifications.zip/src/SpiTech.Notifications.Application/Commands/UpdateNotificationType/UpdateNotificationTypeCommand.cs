﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using System;

namespace SpiTech.Notifications.Application.Commands.UpdateNotificationType
{
    public class UpdateNotificationTypeCommand : IRequest<ResponseModel>
    {
        public int NotificationTypeId { get; set; }
        public string NotificationTypeIdentifier { get; set; }
        public string DisplayTemplate { get; set; }
        public string SmsTemplate { get; set; }
        public string EmailSubject { get; set; }
        public string PushNotificationTemplate { get; set; }
    }
}
