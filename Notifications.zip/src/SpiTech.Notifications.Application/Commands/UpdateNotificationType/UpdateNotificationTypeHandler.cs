﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Notifications.Application.UnitOfWorks;
using SpiTech.ApplicationCore.Domain.Models;
using System.Threading;
using System.Threading.Tasks;
using System;

namespace SpiTech.Notifications.Application.Commands.UpdateNotificationType
{
    public class UpdateNotificationTypeHandler : IRequestHandler<UpdateNotificationTypeCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateNotificationTypeHandler> _logger;
        private readonly IMapper _mapper;

        public UpdateNotificationTypeHandler(IUnitOfWork context,
                                        ILogger<UpdateNotificationTypeHandler> logger,
                                        IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<ResponseModel> Handle(UpdateNotificationTypeCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            try
            {
                int status = 0;

                status = await _context.NotificationTypes.UpdateNotificationMessages(command.NotificationTypeId,command.NotificationTypeIdentifier, command.DisplayTemplate, command.EmailSubject, command.SmsTemplate,command.PushNotificationTemplate);
                _context.Commit();
                _logger.TraceExitMethod(nameof(Handle), status);

                if (status > 0)
                {
                    return new ResponseModel { Success = true, Message = "Success" };
                }
                else
                {
                    _context.Rollback();
                    return new ResponseModel { Success = false, Message = "Fail" };
                }
            }
            catch(Exception ex)
            {
                _context.Rollback();
                _logger.Error(ex);
                throw;
            }
           
        }
    }
}