﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.UpdateEmailBanner
{
    public class UpdateEmailBannerCommand : IRequest<ResponseModel>
    {
        public string EmailBannerPath { get; set; }
    }
}
