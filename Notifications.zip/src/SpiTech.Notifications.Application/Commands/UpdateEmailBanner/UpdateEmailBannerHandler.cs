﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Hosting;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Notifications.Application.UnitOfWorks;
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.UpdateEmailBanner
{
    public class UpdateEmailBannerHandler : IRequestHandler<UpdateEmailBannerCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateEmailBannerHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly IStorageService storageService;

        public UpdateEmailBannerHandler(IUnitOfWork context,
                                        ILogger<UpdateEmailBannerHandler> logger,
                                        IMapper mapper,
                                         IStorageServiceFactory storageServiceFactory,
                                        IWebHostEnvironment webHostEnvironment
                                        )
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _webHostEnvironment = webHostEnvironment;
            storageService = storageServiceFactory.Get(ContainerType.AccountSupport);
        }

        public async Task<ResponseModel> Handle(UpdateEmailBannerCommand request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            ResponseModel result = new() { Success = false };
            
            byte[] imageBytes = await storageService.DownloadBytesAsync(request.EmailBannerPath);
            if (imageBytes != null)
            {
                string filepath = Path.Combine(_webHostEnvironment.ContentRootPath, "Resources", "banner.jpg");

                //byte[] imageBytes = Convert.FromBase64String(request.EmailBannerbase64);
                using FileStream imagefile = new(filepath, FileMode.Create);
                imagefile.Write(imageBytes, 0, imageBytes.Length);
                imagefile.Flush();
                result.Success = true;

                _logger.TraceExitMethod(nameof(Handle), result);
            }
            return await Task.FromResult(result);
        }
    }
}
