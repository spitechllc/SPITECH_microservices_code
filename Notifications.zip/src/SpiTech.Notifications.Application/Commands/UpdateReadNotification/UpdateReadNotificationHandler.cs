﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Notifications.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.UpdateReadNotification
{
    public class UpdateReadNotificationHandler : IRequestHandler<UpdateReadNotificationCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateReadNotificationHandler> _logger;
        private readonly IMapper _mapper;

        public UpdateReadNotificationHandler(IUnitOfWork context,
                                             ILogger<UpdateReadNotificationHandler> logger,
                                             IMapper mapper
                                             )
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<ResponseModel> Handle(UpdateReadNotificationCommand request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            ResponseModel result = new() { Success = false };
            await _context.Execute(async () =>
            {
                result.Success = await _context.NotificationRecipients.UpdateNotificationReadStatus(request.UserId,
                 request.NotificationRecipientIds);
            });

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
