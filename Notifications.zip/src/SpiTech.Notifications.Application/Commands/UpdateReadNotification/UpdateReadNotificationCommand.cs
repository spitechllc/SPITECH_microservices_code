﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.UpdateReadNotification
{
    public class UpdateReadNotificationCommand : IRequest<ResponseModel>
    {
        public int UserId { get; set; }
        public int[] NotificationRecipientIds { get; set; }
    }
}
