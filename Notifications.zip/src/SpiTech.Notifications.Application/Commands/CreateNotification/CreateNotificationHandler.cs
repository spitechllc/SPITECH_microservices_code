﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Notifications.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.CreateNotification
{
    public class CreateNotificationHandler : IRequestHandler<CreateNotificationCommand, int>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateNotificationHandler> _logger;
        private readonly IMapper _mapper;
        public CreateNotificationHandler(IUnitOfWork context,
                                        ILogger<CreateNotificationHandler> logger,
                                        IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<int> Handle(CreateNotificationCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            int id = 0;

            await _context.Execute(async () =>
            {
                id = await _context.Notifications.Add(new Domain.Entities.Notification()
                {
                    EventId = command.EventId,
                    EventIdentifierName = command.EventIdentifierName,
                    MessageIdentifier = command.MessageIdentifier,
                    JsonData = command.JsonData,
                    SenderUserId = command.SenderUserId,
                    NotificationTypeId = command.NotificationTypeId,
                    NotificationTypeIdentifier=command.NotificationTypeIdentifier,
                    DisplayEnabled = command.DisplayEnabled,
                    SmsEnabled = command.SmsEnabled,
                    EmailEnabled = command.EmailEnabled,
                    CreatedOn = DateTime.Now,
                    IsActive = true,
                    PushNotificationEnabled = command.PushNotificationEnabled
                });
            });

            _logger.TraceExitMethod(nameof(Handle), id);
            return id;
        }
    }
}
