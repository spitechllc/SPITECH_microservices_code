﻿using FluentValidation;

namespace SpiTech.Notifications.Application.Commands.CreateNotification
{
    public class CreateNotificationValidator : AbstractValidator<CreateNotificationCommand>
    {
        public CreateNotificationValidator()
        {
            RuleFor(x => x.EventId).NotNull().WithMessage("EventId is not required");
            RuleFor(x => x.EventIdentifierName).NotNull().WithMessage("EventIdentifierName is not required");
            RuleFor(x => x.MessageIdentifier).NotNull().WithMessage("MessageIdentifier is not required");
        }
    }
}
