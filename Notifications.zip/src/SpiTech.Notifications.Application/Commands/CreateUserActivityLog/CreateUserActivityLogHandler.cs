﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Notifications.Application.UnitOfWorks;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.CreateUserActivityLog
{
    public class CreateUserActivityLogHandler : IRequestHandler<CreateUserActivityLogCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateUserActivityLogHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IMediator mediator;

        public CreateUserActivityLogHandler(IUnitOfWork context,
                                                 ILogger<CreateUserActivityLogHandler> logger,
                                                 IMapper mapper,
                                                IMediator mediator)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            this.mediator = mediator;
        }

        public async Task<ResponseModel> Handle(CreateUserActivityLogCommand command, CancellationToken cancellationToken)
        {
            ResponseModel result = new() { Success = false, Message = "" };
            _logger.Warn($"CreateUserActivityLogCommand start userId : {command.UserId}");
            _logger.TraceEnterMethod(nameof(Handle), command);           

            try
            {               
                    await _context.Activities.Add(new Domain.Entities.Activity
                    {
                        ActivityTypeId=command.ActivityTypeId,
                        UserId=command.UserId,
                        ActivityRecordKeyId=command.ActivityRecordKeyId,
                        ActivityTime=command.ActivityTime,
                        ActivityIP=command.ActivityIP,
                        ActivityPreData=command.ActivityPreData,
                        ActivityPostData=command.ActivityPostData,
                        IsError=command.IsError,
                        ErrorMessage = command.ErrorMessage,
                        IsActive = true,
                        CreatedOn = DateTime.UtcNow
                    });               

                _context.Commit();
            }
            catch (Exception ex)
            {
                _logger.Warn($"CreateUserActivityLogCommand Error {ex.Message}");
                result.Message = "Error";
                _context.Rollback();
                throw;
            }

            _logger.TraceExitMethod(nameof(Handle), result);
            _logger.Warn($"CreateUserActivityLogCommand end");
            return result;
        }
    }
}
