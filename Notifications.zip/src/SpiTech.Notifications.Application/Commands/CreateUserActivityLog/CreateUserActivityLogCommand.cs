﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using System;

namespace SpiTech.Notifications.Application.Commands.CreateUserActivityLog
{
    public class CreateUserActivityLogCommand : IRequest<ResponseModel>
    {
        public int ActivityTypeId { get; set; }
        public int UserId { get; set; }
        public string ActivityRecordKeyId { get; set; }
        public string ActivityPreData { get; set; }
        public string ActivityPostData { get; set; }
        public DateTime ActivityTime { get; set; }
        public string ActivityIP { get; set; }
        public bool IsError { get; set; }
        public string ErrorMessage { get; set; }
    }
}
