﻿using MediatR;
using SpiTech.ApplicationCore.Processors;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Mppa;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Mobiles;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Application.Services;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.Events.Mppa.MppaEmail
{
    public class MppaEmailHandler : IRequestHandler<MppaEmailCommand, bool>
    {
        private readonly IEmailService _emailService;
        private readonly IEmailTemplateProcessService emailTemplateProcessService;

        public MppaEmailHandler(IEmailService emailService,
            IEmailTemplateProcessService emailTemplateProcessService)
        {
            _emailService = emailService;
            this.emailTemplateProcessService = emailTemplateProcessService;
        }

        public async Task<bool> Handle(MppaEmailCommand command, CancellationToken cancellationToken)
        {
            string templateFile = command.EmailModel.NotificationType.EmailTemplatePath;
            string subject = string.Empty;
            List<string> toEmails = new();
            List<string> ccEmails = new();
            object macroObject = command.EmailModel.MacroObject;

            if (command.EmailModel.Event is MobileFinalizesDataResponseEvent mobileFinalizesDataResponseEvent)
            {
                toEmails.Add(command.EmailModel.User.Email);
            }
            else if (command.EmailModel.Event is TransactionSettlementEvent transactionSettlementEvent && (command.EmailModel.Store?.Emails?.Any() ?? false))
            {
                var email = command.EmailModel.Store.Emails?.FirstOrDefault(t => t.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.DailySettlement)?.Email;

                if(string.IsNullOrEmpty(email))
                {
                    toEmails.Add(email);
                }
            }
            subject = TextTemplateMacroProcessor.Process(command.EmailModel.NotificationType.EmailSubject, command.EmailModel.MacroObject, command.EmailModel.User, command.EmailModel.Event);


            if (toEmails.Any(t => !string.IsNullOrWhiteSpace(t)))
            {
                _emailService.SendEmail(toEmails.ToArray()
                    , ccEmails.ToArray()
                    , subject
                    , await this.emailTemplateProcessService.ProcessHtmlTemplateFromView(templateFile, macroObject));
            }
            else
            {
                command.EmailModel.Error = "Email not found";
                command.EmailModel.IsEmailSent = false;
                return await Task.FromResult(false);
            }

            return await Task.FromResult(true);
        }
    }
}