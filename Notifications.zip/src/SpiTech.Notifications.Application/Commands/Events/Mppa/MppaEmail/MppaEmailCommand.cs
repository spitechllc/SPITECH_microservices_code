﻿using MediatR;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.Events.Mppa.MppaEmail
{
    public class MppaEmailCommand : IRequest<bool>
    {
        public EmailModel EmailModel { get; set; }
    }
}
