﻿using MediatR;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.Events.Mppa.MppaPushNotification
{
    public class MppaPushNotificationCommand : IRequest<bool>
    {
        public PushNotificationEventModel PushNotificationModel { get; set; }
    }
}
