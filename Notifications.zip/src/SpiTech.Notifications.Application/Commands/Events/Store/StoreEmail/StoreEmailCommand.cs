﻿using MediatR;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.Events.Store.StoreEmail
{
    public class StoreEmailCommand : IRequest<bool>
    {
        public EmailModel EmailModel { get; set; }
    }
}
