﻿using MediatR;
using SpiTech.ApplicationCore.Processors;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Store;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Application.Services;
using SpiTech.Notifications.Domain.Models.Store;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.Events.Store.StoreEmail
{
    public class StoreEmailHandler : IRequestHandler<StoreEmailCommand, bool>
    {
        private readonly IEmailService _emailService;
        private readonly IEmailTemplateProcessService emailTemplateProcessService;

        public StoreEmailHandler(IEmailService emailService,
            IEmailTemplateProcessService emailTemplateProcessService)
        {
            _emailService = emailService;
            this.emailTemplateProcessService = emailTemplateProcessService;
        }

        public async Task<bool> Handle(StoreEmailCommand command, CancellationToken cancellationToken)
        {
            string templateFile = command.EmailModel.NotificationType.EmailTemplatePath;
            string subject = command.EmailModel.NotificationType.EmailSubject;
            List<string> toEmails = new();
            List<string> ccEmails = new();
            object macroObject = command.EmailModel.MacroObject;

            if (command.EmailModel.Event is StoreEvent storeEvent)
            {
                toEmails.AddRange(command.EmailModel.Store.Emails.Where(t => t.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.Main).Select(t => t.Email));
            }
            else if (command.EmailModel.Event is StoreUserEvent storeUserEvent)
            {

                if (macroObject is StoreUserEventModel storeUserEventModel)
                {
                    //toEmails.Add(command.EmailModel.User.Email);
                    toEmails.AddRange(storeUserEventModel.Emails);
                }

                //if(command.EmailModel.User.Email!=null)
                //{
                //    ccEmails.Add(command.EmailModel.User.Email);
                //}
            }
            subject = TextTemplateMacroProcessor.Process(command.EmailModel.NotificationType.EmailSubject, command.EmailModel.MacroObject, command.EmailModel.User, command.EmailModel.Event);

            if (toEmails.Any(t => !string.IsNullOrWhiteSpace(t)))
            {
                _emailService.SendEmail(toEmails.ToArray()
                    , ccEmails.ToArray()
                    , subject
                    , await this.emailTemplateProcessService.ProcessHtmlTemplateFromView(templateFile, macroObject));
            }
            else
            {
                command.EmailModel.Error = "Email not found";
                command.EmailModel.IsEmailSent = false;
                return await Task.FromResult(false);
            }

            return await Task.FromResult(true);
        }
    }
}
