﻿using MediatR;
using System;

namespace SpiTech.Notifications.Application.Commands.Events.PushNotifications
{
    public class PushNotificationCommand : IRequest<int>
    {
        public int?[] Recipients { get; set; }
        public string UserDeviceToken { get; set; }
        public int NotificationTypeId { get; set; }
        public string Body { get; set; }
        public string Title { get; set; }
        public bool IsRead { get; set; }
        public DateTime? ReadDate { get; set; }
        public int RetryCount { get; set; }
        public bool IsSent { get; set; }
        public DateTime? SentDate { get; set; }
        public bool HasError { get; set; }
        public string ErrorMessage { get; set; }
    }
}
