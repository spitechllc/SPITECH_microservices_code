﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Notifications.Application.UnitOfWorks;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.Events.PushNotifications
{
    public class NotificationHandler : IRequestHandler<PushNotificationCommand, int>
    {
        private readonly ILogger<NotificationHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _context;

        public NotificationHandler(
                                    ILogger<NotificationHandler> logger,
                                    IMediator mediator,
                                    IMapper mapper,
                                    IUnitOfWork context)
        {
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _context = context;
        }

        public async Task<int> Handle(PushNotificationCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            int id = 0;
            if (command.Recipients != null)
            {
                foreach (int? recipient in command.Recipients.Distinct())
                {
                    id = await _context.PushNotifications.Add(new Domain.Entities.PushNotification()
                    {
                        UserId = (int)recipient,
                        UserDeviceToken = command.UserDeviceToken,
                        Body = command.Body,
                        Title = command.Title,
                        RetryCount = command.RetryCount,
                        IsSent = command.IsSent,
                        SentDate = command.SentDate,
                        HasError = command.HasError,
                        ErrorMessage = command.ErrorMessage
                    });
                }
            }

            _logger.TraceExitMethod(nameof(Handle), id);

            return id;
        }
    }
}
