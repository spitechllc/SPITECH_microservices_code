﻿using MediatR;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.Events.Identity.IdentityPushNotification
{
    public class IdentityPushNotificationCommand : IRequest<bool>
    {
        public PushNotificationEventModel PushNotificationModel { get; set; }
    }
}
