﻿using MediatR;
using SpiTech.ApplicationCore.Processors;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Notifications.Application.Interfaces;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.Events.Identity.IdentityPushNotification
{
    public class IdentityPushNotificationHandler : IRequestHandler<IdentityPushNotificationCommand, bool>
    {
        private readonly IPushNotificationService _pushNotificationService;
        private readonly IMediator _mediator;

        public IdentityPushNotificationHandler(IPushNotificationService pushNotificationService,
            IMediator mediator)
        {
            _pushNotificationService = pushNotificationService;
            _mediator = mediator;
        }

        public async Task<bool> Handle(IdentityPushNotificationCommand command, CancellationToken cancellationToken)
        {
            string pushNotificationTemplate = command.PushNotificationModel.NotificationType.PushNotificationTemplate;
            string title = command.PushNotificationModel.NotificationType.EmailSubject;
            string type = command.PushNotificationModel.NotificationType.NotificationTypeId.ToString();
            object macroObject = command.PushNotificationModel.MacroObject;

            MobileAppType mobileAppType = command.PushNotificationModel.MobileAppType;
            Service.Clients.Identity.UserDeviceModel device = command.PushNotificationModel.User.Devices.FirstOrDefault();

            if (device == null)
            {
                return await Task.FromResult(false);
            }

            if (mobileAppType == MobileAppType.None)
            {
                mobileAppType = MobileAppType.Consumer;
            }

            Func<string, string> bodyTemplateMacroBinder = t => TextTemplateMacroProcessor.Process(t, macroObject, command.PushNotificationModel.User, command.PushNotificationModel.Event);

            if (device != null && !string.IsNullOrEmpty(device.DeviceToken))
            {
                await _pushNotificationService.SendNotification((DeviceType)device.DeviceTypeId, mobileAppType,
                    device.DeviceToken, type, title, "", command.PushNotificationModel.Event, pushNotificationTemplate, command.PushNotificationModel.UnReadCount, bodyTemplateMacroBinder);
            }
            else
            {
                throw new ApplicationCore.Domain.Exceptions.BlankDeviceTokenException();
            }

            return await Task.FromResult(true);
        }
    }
}
