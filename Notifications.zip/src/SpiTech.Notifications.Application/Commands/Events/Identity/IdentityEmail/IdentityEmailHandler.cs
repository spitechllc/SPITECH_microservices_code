﻿using MediatR;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using SpiTech.EventBus.DomainEvents.Events.Identity;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Application.Services;
using System.Collections.Generic;
using SpiTech.ApplicationCore.Processors;
using Polly;

namespace SpiTech.Notifications.Application.Commands.Events.Identity.IdentityEmail
{
    public class IdentityEmailHandler : IRequestHandler<IdentityEmailCommand, bool>
    {
        private readonly IEmailService _emailService;
        private readonly IEmailTemplateProcessService emailTemplateProcessService;

        public IdentityEmailHandler(IEmailService emailService,
            IEmailTemplateProcessService emailTemplateProcessService)
        {
            _emailService = emailService;
            this.emailTemplateProcessService = emailTemplateProcessService;
        }

        public async Task<bool> Handle(IdentityEmailCommand command, CancellationToken cancellationToken)
        {
            string templateFile = command.EmailModel.NotificationType.EmailTemplatePath;
            string subject = string.Empty;
            List<string> toEmails = new();
            List<string> ccEmails = new();
            object macroObject = command.EmailModel.MacroObject;

            if (command.EmailModel.Event is IdentityUserCreatedEvent identityUserCreatedEvent)
            {
                toEmails.Add(identityUserCreatedEvent.Email);
            }
            else if (command.EmailModel.Event is IdentityUserUpdatedEvent identityUserUpdatedEvent)
            {
                toEmails.Add(identityUserUpdatedEvent.Email);
            }
            else if (command.EmailModel.Event is IdentityForgotPasswordEvent identityForgotPasswordEvent)
            {
                toEmails.Add(identityForgotPasswordEvent.Email);
            }
            else if (command.EmailModel.Event is IdentityPasswordChangedEvent identityPasswordChangedEvent)
            {
                toEmails.Add(identityPasswordChangedEvent.Email);
            }
            else 
            {
                toEmails.Add(command.EmailModel.User.Email);
            }
            subject = TextTemplateMacroProcessor.Process(command.EmailModel.NotificationType.EmailSubject, command.EmailModel.MacroObject, command.EmailModel.User, command.EmailModel.Event);

           string TenantName= ((IdentityUserCreatedEvent)command.EmailModel.MacroObject).TenantName;

            if (!string.IsNullOrEmpty(TenantName))
            {
                subject = TenantName + " account created";
            }
            if (toEmails.Any(t => !string.IsNullOrWhiteSpace(t)))
            {
                _emailService.SendEmail(toEmails.ToArray()
                    , ccEmails.ToArray()
                , subject
                    , await this.emailTemplateProcessService.ProcessHtmlTemplateFromView(templateFile, macroObject), null, null, subject);
            }
            else
            {
                command.EmailModel.Error = "Email not found";
                command.EmailModel.IsEmailSent = false;
                return await Task.FromResult(false);
            }

            return await Task.FromResult(true);
        }
    }
}
