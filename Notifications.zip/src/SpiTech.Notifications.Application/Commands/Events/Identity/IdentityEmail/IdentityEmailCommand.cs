﻿using MediatR;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.Events.Identity.IdentityEmail
{
    public class IdentityEmailCommand : IRequest<bool>
    {
        public EmailModel EmailModel { get; set; }
    }
}
