﻿using MediatR;
using SpiTech.ApplicationCore.Processors;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Application.Services;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.Events.Marketing.MarketingEmail
{
    public class MarketingEmailHandler : IRequestHandler<MarketingEmailCommand, bool>
    {
        private readonly IEmailService _emailService;
        private readonly IEmailTemplateProcessService emailTemplateProcessService;

        public MarketingEmailHandler(IEmailService emailService,
            IEmailTemplateProcessService emailTemplateProcessService)
        {
            _emailService = emailService;
            this.emailTemplateProcessService = emailTemplateProcessService;
        }

        public async Task<bool> Handle(MarketingEmailCommand command, CancellationToken cancellationToken)
        {
            string templateFile = command.EmailModel.NotificationType.EmailTemplatePath;
            string subject = string.Empty;
            List<string> toEmails = new() { command.EmailModel.User.Email };
            List<string> ccEmails = new();
            object macroObject = command.EmailModel.MacroObject;

            subject = TextTemplateMacroProcessor.Process(command.EmailModel.NotificationType.EmailSubject, command.EmailModel.MacroObject, command.EmailModel.User, command.EmailModel.Event);

            if (toEmails.Any(t => !string.IsNullOrWhiteSpace(t)))
            {
                _emailService.SendEmail(toEmails.ToArray()
                    , ccEmails.ToArray()
                    , subject
                    , await this.emailTemplateProcessService.ProcessHtmlTemplateFromView(templateFile, macroObject));
            }
            else
            {
                command.EmailModel.Error = "Email not found";
                command.EmailModel.IsEmailSent = false;
                return await Task.FromResult(false);
            }

            return await Task.FromResult(true);
        }
    }
}
