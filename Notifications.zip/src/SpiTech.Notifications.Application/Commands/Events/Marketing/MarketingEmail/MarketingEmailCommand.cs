﻿using MediatR;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.Events.Marketing.MarketingEmail
{
    public class MarketingEmailCommand : IRequest<bool>
    {
        public EmailModel EmailModel { get; set; }
    }
}
