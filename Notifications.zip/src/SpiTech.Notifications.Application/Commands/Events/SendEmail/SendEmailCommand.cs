﻿using MediatR;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.Events.SendEmail
{
    public class SendEmailCommand : IRequest<EmailModel>
    {
        public EmailModel EmailModel { get; set; }
    }
}
