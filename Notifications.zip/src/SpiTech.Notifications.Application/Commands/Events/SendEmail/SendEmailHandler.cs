﻿using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Notifications.Application.Commands.Events.Account.AccountEmail;
using SpiTech.Notifications.Application.Commands.Events.Finance.FinanceEmail;
using SpiTech.Notifications.Application.Commands.Events.Identity.IdentityEmail;
using SpiTech.Notifications.Application.Commands.Events.Marketing.MarketingEmail;
using SpiTech.Notifications.Application.Commands.Events.Mppa.MppaEmail;
using SpiTech.Notifications.Application.Commands.Events.Payment.PaymentEmail;
using SpiTech.Notifications.Application.Commands.Events.Store.StoreEmail;
using SpiTech.Notifications.Application.Commands.Events.Transactions.TransactionEmail;
using SpiTech.Notifications.Domain.Models;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.Events.SendEmail
{
    public class SendEmailHandler : IRequestHandler<SendEmailCommand, EmailModel>
    {
        private readonly IMediator mediator;
        private readonly ILogger<SendEmailHandler> logger;

        public SendEmailHandler(IMediator mediator, ILogger<SendEmailHandler> logger)
        {
            this.mediator = mediator;
            this.logger = logger;
        }

        public async Task<EmailModel> Handle(SendEmailCommand command, CancellationToken cancellationToken)
        {
            try
            {
                if (command.EmailModel.Event.EventModuleType == EventModuleType.Identity)
                {
                    command.EmailModel.IsEmailSent = await mediator.Send(new IdentityEmailCommand { EmailModel = command.EmailModel }, cancellationToken);
                }
                else if (command.EmailModel.Event.EventModuleType == EventModuleType.MPPA)
                {
                    command.EmailModel.IsEmailSent = await mediator.Send(new MppaEmailCommand { EmailModel = command.EmailModel }, cancellationToken);
                }
                else if (command.EmailModel.Event.EventModuleType == EventModuleType.Store)
                {
                    command.EmailModel.IsEmailSent = await mediator.Send(new StoreEmailCommand { EmailModel = command.EmailModel }, cancellationToken);
                }
                else if (command.EmailModel.Event.EventModuleType == EventModuleType.Finance)
                {
                    command.EmailModel.IsEmailSent = await mediator.Send(new FinanceEmailCommand { EmailModel = command.EmailModel }, cancellationToken);
                }
                else if (command.EmailModel.Event.EventModuleType == EventModuleType.Marketing)
                {
                    command.EmailModel.IsEmailSent = await mediator.Send(new MarketingEmailCommand { EmailModel = command.EmailModel }, cancellationToken);
                }
                else if (command.EmailModel.Event.EventModuleType ==EventModuleType.Payment)
                {
                    command.EmailModel.IsEmailSent = await mediator.Send(new PaymentEmailCommand { EmailModel = command.EmailModel }, cancellationToken);
                }
                else if (command.EmailModel.Event.EventModuleType == EventModuleType.Transaction)
                {
                    command.EmailModel.IsEmailSent = await mediator.Send(new TransactionEmailCommand { EmailModel = command.EmailModel }, cancellationToken);
                }
                else if (command.EmailModel.Event.EventModuleType == EventModuleType.Account)
                {
                    command.EmailModel.IsEmailSent = await mediator.Send(new AccountEmailCommand { EmailModel = command.EmailModel }, cancellationToken);
                }
            }
            catch (BlankEmailException ex)
            {
                command.EmailModel.IsEmailSent = false;
                command.EmailModel.Error = ex.Message;
                command.EmailModel.RetryCount = (command.EmailModel.RetryCount ?? 0) + 1;
            }
            catch (Exception ex)
            {
                logger.Error(ex, command);

                JsonSerializerSettings serializerSettings = new()
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                };

                command.EmailModel.IsError = true;
                command.EmailModel.IsEmailSent = false;
                command.EmailModel.Error = JsonConvert.SerializeObject(ex, serializerSettings);
                command.EmailModel.RetryCount = (command.EmailModel.RetryCount ?? 0) + 1;
            }

            return await Task.FromResult(command.EmailModel);
        }
    }
}
