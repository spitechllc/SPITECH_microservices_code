﻿using MediatR;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.Events.Transactions.TransactionEmail
{
    public class TransactionEmailCommand : IRequest<bool>
    {
        public EmailModel EmailModel { get; set; }
    }
}
