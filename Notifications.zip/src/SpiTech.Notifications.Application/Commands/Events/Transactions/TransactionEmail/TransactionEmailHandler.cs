﻿using MediatR;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Processors;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Transactions;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Application.Services;
using SpiTech.Notifications.Domain.Models;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.Events.Transactions.TransactionEmail
{
    public class TransactionEmailHandler : IRequestHandler<TransactionEmailCommand, bool>
    {
        private readonly IEmailService _emailService;
        private readonly IMediator _mediator;
        private readonly IEmailTemplateProcessService emailTemplateProcessService;
        private readonly IStoreServiceClient storeServiceClient;
        private readonly IStorageService eodStorageService;
        private readonly IStorageService monthlyStorageService;
        private readonly IStorageService saleAgentMonthlyInvoicePdfStorageService;
        private readonly IStorageService resellerMonthlyInvoicePdfStorageService;

        public TransactionEmailHandler(IEmailService emailService,
            IMediator mediator,
            IStorageServiceFactory eodStorageServiceFactory,
            IStorageServiceFactory monthlyStorageServiceFactory,
            IEmailTemplateProcessService emailTemplateProcessService,
            IStoreServiceClient storeServiceClient)
        {
            _emailService = emailService;
            _mediator = mediator;
            this.emailTemplateProcessService = emailTemplateProcessService;
            this.storeServiceClient = storeServiceClient;
            eodStorageService = eodStorageServiceFactory.Get(ContainerType.EodPdf);
            monthlyStorageService = monthlyStorageServiceFactory.Get(ContainerType.MonthlyInvoicePdf);
            saleAgentMonthlyInvoicePdfStorageService = monthlyStorageServiceFactory.Get(ContainerType.SaleAgentMonthlyInvoicePdf);
            resellerMonthlyInvoicePdfStorageService = monthlyStorageServiceFactory.Get(ContainerType.ResellerMonthlyInvoicePdf);
        }

        public async Task<bool> Handle(TransactionEmailCommand command, CancellationToken cancellationToken)
        {
            Service.Clients.Stores.StoreInfoModel masterStore = await storeServiceClient.GetMasterStoreInfoAsync();
            string templateFile = command.EmailModel.NotificationType.EmailTemplatePath;
            string subject = string.Empty;

            List<string> toEmails = new();
            List<string> ccEmails = new();
            if (masterStore != null)
            {
                var emails = masterStore?.Emails?.Where(t => t.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.SupportTeam).Select(t => t.Email).ToList();
                if (emails != null && emails.Any())
                {
                    ccEmails.AddRange(emails);
                }
                else
                {
                    emails = masterStore?.Emails?.Where(t => t.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.Main).Select(t => t.Email).ToList();
                    if (emails != null && emails.Any())
                    {
                        ccEmails.AddRange(emails);
                    }
                }
            }
            object macroObject = command.EmailModel.MacroObject;
            EmailAttachmentModel emailAttachment = null;

            if (command.EmailModel.Event is StoreEodSettlementInvoiceAdminEvent storeEodSettlementInvoiceAdminEvent)
            {

                var emails = command.EmailModel.Store?.Emails?.Where(t => t.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.EODSettlementSuccess).Select(t => t.Email).ToList();
                var emailNachaAdmins = command.EmailModel.Store?.Emails?.Where(t => t.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.EODSettlementNachaNotification).Select(t => t.Email).ToList();

                if (emails != null && emails.Any())
                {
                    toEmails.AddRange(emails);
                    
                }
                if (emailNachaAdmins != null && emailNachaAdmins.Any())
                {
                    toEmails.AddRange(emailNachaAdmins);

                }
                else
                {
                    emails = command.EmailModel.Store?.Emails?.Where(t => t.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.Main).Select(t => t.Email).ToList();
                    if (emails != null && emails.Any())
                    {
                        toEmails.AddRange(emails);
                    }
                }

                subject = TextTemplateMacroProcessor.Process(command.EmailModel.NotificationType.EmailSubject, command.EmailModel.MacroObject, command.EmailModel.Store, storeEodSettlementInvoiceAdminEvent.SettlementPayment, command.EmailModel.Event);
            }
            else if (command.EmailModel.Event is AchNachaReturnFileEvent achNachaReturnFileEvent)
            {
                //var emails = command.EmailModel.Store?.Emails?.Where(t => t.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.ACHReturnNachaNotification).Select(t => t.Email).ToList();

                List<string> emails = new List<string>
                {
                    "joey@SpiTech.com"
                };

                if ((emails != null && emails.Any()))
                {
                    toEmails.AddRange(emails);
                }
                else
                {
                    emails = command.EmailModel.Store?.Emails?.Where(t => t.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.Main).Select(t => t.Email).ToList();
                    if (emails != null && emails.Any())
                    {
                        toEmails.AddRange(emails);
                    }
                }

                subject = TextTemplateMacroProcessor.Process(command.EmailModel.NotificationType.EmailSubject, command.EmailModel.MacroObject, command.EmailModel.Store, achNachaReturnFileEvent, command.EmailModel.Event);
            }
            else if (command.EmailModel.Event is StoreEodSettlementInvoiceEvent storeEodSettlementInvoiceEvent)
            {
                var emails = command.EmailModel.Store?.Emails?.Where(t => t.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.EODSettlementSuccess).Select(t => t.Email).ToList();

                if (emails != null)
                {
                    toEmails.AddRange(emails);
                }
                else
                {
                    emails = command.EmailModel.Store?.Emails?.Where(t => t.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.Main).Select(t => t.Email).ToList();
                    if (emails != null && emails.Any())
                    {
                        toEmails.AddRange(emails);
                    }
                }

                subject = TextTemplateMacroProcessor.Process(command.EmailModel.NotificationType.EmailSubject, command.EmailModel.MacroObject, command.EmailModel.Store, command.EmailModel.Event);
               
            }
            else if (command.EmailModel.Event is StoreEodSettlementEvent storeEodSettlementEvent)
            {
                emailAttachment = new EmailAttachmentModel
                {
                    Content = await eodStorageService.DownloadBytesAsync(storeEodSettlementEvent.StoreEodSettlement.SettlementFilePath),
                    FileName = $"EODSettlement-{storeEodSettlementEvent.StoreEodSettlement.BusinessDate}.pdf"
                };

                var emails = command.EmailModel.Store?.Emails?.Where(t => t.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.EODSettlementSuccess).Select(t => t.Email).ToList();

                if (emails != null)
                {
                    toEmails.AddRange(emails);
                }
                else
                {
                    emails = command.EmailModel.Store?.Emails?.Where(t => t.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.Main).Select(t => t.Email).ToList();
                    if (emails != null && emails.Any())
                    {
                        toEmails.AddRange(emails);
                    }
                }

                subject = TextTemplateMacroProcessor.Process(command.EmailModel.NotificationType.EmailSubject, command.EmailModel.MacroObject, command.EmailModel.Store, storeEodSettlementEvent.StoreEodSettlement, command.EmailModel.Event);
            }
            else if (command.EmailModel.Event is StoreMonthlyBillingInvoiceEvent storeMonthlyBillingInvoiceEvent)
            {
                emailAttachment = new EmailAttachmentModel
                {
                    Content = await monthlyStorageService.DownloadBytesAsync(storeMonthlyBillingInvoiceEvent.StoreBilling.InvoiceFilePath),
                    FileName = $"MonthlyBill-{storeMonthlyBillingInvoiceEvent.StoreBilling.BillingNumber}-{storeMonthlyBillingInvoiceEvent.StoreBilling.MonthName}-{storeMonthlyBillingInvoiceEvent.StoreBilling.Year}.pdf"
                };

                var emails = command.EmailModel.Store?.Emails?.Where(t => t.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.MonthlySettlement).Select(t => t.Email).ToList();

                if (emails != null)
                {
                    toEmails.AddRange(emails);
                }
                else
                {
                    emails = command.EmailModel.Store?.Emails?.Where(t => t.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.Main).Select(t => t.Email).ToList();
                    if (emails != null && emails.Any())
                    {
                        toEmails.AddRange(emails);
                    }
                }

                subject = TextTemplateMacroProcessor.Process(command.EmailModel.NotificationType.EmailSubject, command.EmailModel.MacroObject, command.EmailModel.Store, storeMonthlyBillingInvoiceEvent.StoreBilling, command.EmailModel.Event);
            }
            else if (command.EmailModel.Event is SaleAgentMonthlyBillingInvoiceEvent saleAgentMonthlyBillingInvoiceEvent)
            {
                emailAttachment = new EmailAttachmentModel
                {
                    Content = await saleAgentMonthlyInvoicePdfStorageService.DownloadBytesAsync(saleAgentMonthlyBillingInvoiceEvent.SaleAgentBilling.InvoiceFilePath),
                    FileName = $"Payment-{saleAgentMonthlyBillingInvoiceEvent.SaleAgentBilling.InvoiceNumber}-{saleAgentMonthlyBillingInvoiceEvent.SaleAgentBilling.MonthName}-{saleAgentMonthlyBillingInvoiceEvent.SaleAgentBilling.Year}.pdf"
                };

                var emails = command.EmailModel.SaleAgent?.Emails?.Where(t => t.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.Main).Select(t => t.Email).ToList();

                if (emails != null)
                {
                    toEmails.AddRange(emails);
                }

                subject = TextTemplateMacroProcessor.Process(command.EmailModel.NotificationType.EmailSubject, command.EmailModel.MacroObject, command.EmailModel.Store, saleAgentMonthlyBillingInvoiceEvent.SaleAgentBilling, command.EmailModel.Event);
            }
            else if (command.EmailModel.Event is ResellerMonthlyBillingInvoiceEvent resellerMonthlyBillingInvoiceEvent)
            {
                emailAttachment = new EmailAttachmentModel
                {
                    Content = await resellerMonthlyInvoicePdfStorageService.DownloadBytesAsync(resellerMonthlyBillingInvoiceEvent.ResellerBilling.InvoiceFilePath),
                    FileName = $"Payment-{resellerMonthlyBillingInvoiceEvent.ResellerBilling.InvoiceNumber}-{resellerMonthlyBillingInvoiceEvent.ResellerBilling.MonthName}-{resellerMonthlyBillingInvoiceEvent.ResellerBilling.Year}.pdf"
                };

                var emails = command.EmailModel.Reseller?.Emails?.Where(t => t.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.Main).Select(t => t.Email).ToList();

                if (emails != null)
                {
                    toEmails.AddRange(emails);
                }

                subject = TextTemplateMacroProcessor.Process(command.EmailModel.NotificationType.EmailSubject, command.EmailModel.MacroObject, command.EmailModel.Store, resellerMonthlyBillingInvoiceEvent.ResellerBilling, command.EmailModel.Event);
            }

            if (toEmails.Any(t => !string.IsNullOrWhiteSpace(t)))
            {
                _emailService.SendEmail(toEmails.ToArray()
                    , ccEmails.ToArray()
                    , subject
                    , await this.emailTemplateProcessService.ProcessHtmlTemplateFromView(templateFile, macroObject)
                    , new[] { emailAttachment });
            }
            else
            {
                command.EmailModel.Error = "Email not found";
                command.EmailModel.IsEmailSent = false;
                return await Task.FromResult(false);
            }

            return await Task.FromResult(true);
        }
    }
}
