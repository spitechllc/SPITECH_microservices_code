﻿using MediatR;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.Events.Transactions.TransactionPushNotification
{
    public class TransactionPushNotificationCommand : IRequest<bool>
    {
        public PushNotificationEventModel PushNotificationModel { get; set; }
    }
}
