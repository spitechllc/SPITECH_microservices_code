﻿using MediatR;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.Events.Finance.FinancePushNotification
{
    public class FinancePushNotificationCommand : IRequest<bool>
    {
        public PushNotificationEventModel PushNotificationModel { get; set; }
    }
}
