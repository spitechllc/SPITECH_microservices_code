﻿using MediatR;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Notifications.Application.Commands.Events.Account.AccountPushNotification;
using SpiTech.Notifications.Application.Commands.Events.Finance.FinancePushNotification;
using SpiTech.Notifications.Application.Commands.Events.Identity.IdentityPushNotification;
using SpiTech.Notifications.Application.Commands.Events.Marketing.MarketingPushNotification;
using SpiTech.Notifications.Application.Commands.Events.Mppa.MppaPushNotification;
using SpiTech.Notifications.Application.Commands.Events.Payment.PaymentPushNotification;
using SpiTech.Notifications.Application.Commands.Events.Store.StorePushNotification;
using SpiTech.Notifications.Application.Commands.Events.Transactions.TransactionPushNotification;
using SpiTech.Notifications.Domain.Models;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.Events.SendPushNotification
{
    public class SendPushNotificationHandler : IRequestHandler<SendPushNotificationCommand, PushNotificationEventModel>
    {
        private readonly IMediator mediator;
        private readonly ILogger<SendPushNotificationHandler> _logger;

        public SendPushNotificationHandler(IMediator mediator, ILogger<SendPushNotificationHandler> logger)
        {
            this.mediator = mediator;
            _logger = logger;
        }

        public async Task<PushNotificationEventModel> Handle(SendPushNotificationCommand command, CancellationToken cancellationToken)
        {
            try
            {
                if (command.PushNotificationModel.Event.EventModuleType == EventModuleType.Identity)
                {
                    command.PushNotificationModel.IsPushNotificationSent = await mediator.Send(new IdentityPushNotificationCommand { PushNotificationModel = command.PushNotificationModel }, cancellationToken);
                }
                else if (command.PushNotificationModel.Event.EventModuleType == EventModuleType.MPPA)
                {
                    command.PushNotificationModel.IsPushNotificationSent = await mediator.Send(new MppaPushNotificationCommand { PushNotificationModel = command.PushNotificationModel }, cancellationToken);
                }
                else if (command.PushNotificationModel.Event.EventModuleType == EventModuleType.Store)
                {
                    command.PushNotificationModel.IsPushNotificationSent = await mediator.Send(new StorePushNotificationCommand { PushNotificationModel = command.PushNotificationModel }, cancellationToken);
                }
                else if (command.PushNotificationModel.Event.EventModuleType == EventModuleType.Finance)
                {
                    command.PushNotificationModel.IsPushNotificationSent = await mediator.Send(new FinancePushNotificationCommand { PushNotificationModel = command.PushNotificationModel }, cancellationToken);
                }
                else if (command.PushNotificationModel.Event.EventModuleType == EventModuleType.Marketing)
                {
                    command.PushNotificationModel.IsPushNotificationSent = await mediator.Send(new MarketingPushNotificationCommand { PushNotificationModel = command.PushNotificationModel }, cancellationToken);
                }
                else if (command.PushNotificationModel.Event.EventModuleType == EventModuleType.Payment)
                {
                    command.PushNotificationModel.IsPushNotificationSent = await mediator.Send(new PaymentPushNotificationCommand { PushNotificationModel = command.PushNotificationModel }, cancellationToken);
                }
                else if (command.PushNotificationModel.Event.EventModuleType == EventModuleType.Transaction)
                {
                    command.PushNotificationModel.IsPushNotificationSent = await mediator.Send(new TransactionPushNotificationCommand { PushNotificationModel = command.PushNotificationModel }, cancellationToken);
                }
                else if (command.PushNotificationModel.Event.EventModuleType == EventModuleType.Account)
                {
                    command.PushNotificationModel.IsPushNotificationSent = await mediator.Send(new AccountPushNotificationCommand { PushNotificationModel = command.PushNotificationModel }, cancellationToken);
                }
            }
            catch (BlankDeviceTokenException ex)
            {
                command.PushNotificationModel.IsPushNotificationSent = false;
                command.PushNotificationModel.Error = ex.Message;
                command.PushNotificationModel.RetryCount = (command.PushNotificationModel.RetryCount ?? 0) + 1;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, command);

                JsonSerializerSettings serializerSettings = new()
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                };

                command.PushNotificationModel.IsPushNotificationSent = false;
                command.PushNotificationModel.Error = JsonConvert.SerializeObject(ex, serializerSettings);
                command.PushNotificationModel.RetryCount = (command.PushNotificationModel.RetryCount ?? 0) + 1;
            }

            return await Task.FromResult(command.PushNotificationModel);
        }
    }
}
