﻿using MediatR;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.Events.SendPushNotification
{
    public class SendPushNotificationCommand : IRequest<PushNotificationEventModel>
    {
        public PushNotificationEventModel PushNotificationModel { get; set; }
    }
}
