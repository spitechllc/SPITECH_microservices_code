﻿using MediatR;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.Events.Payment.PaymentPushNotification
{
    public class PaymentPushNotificationCommand : IRequest<bool>
    {
        public PushNotificationEventModel PushNotificationModel { get; set; }
    }
}
