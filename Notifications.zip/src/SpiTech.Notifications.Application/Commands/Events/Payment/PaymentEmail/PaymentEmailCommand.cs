﻿using MediatR;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.Events.Payment.PaymentEmail
{
    public class PaymentEmailCommand : IRequest<bool>
    {
        public EmailModel EmailModel { get; set; }
    }
}
