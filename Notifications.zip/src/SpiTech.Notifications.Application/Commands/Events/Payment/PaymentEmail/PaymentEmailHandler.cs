﻿using MediatR;
using SpiTech.ApplicationCore.Processors;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Payment;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Application.Queries.GetStoreInfo;
using SpiTech.Notifications.Application.Services;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.Events.Payment.PaymentEmail
{
    public class PaymentEmailHandler : IRequestHandler<PaymentEmailCommand, bool>
    {
        private readonly IEmailService _emailService;
        private readonly IMediator mediator;
        private readonly IEmailTemplateProcessService emailTemplateProcessService;

        public PaymentEmailHandler(IEmailService emailService,
            IMediator mediator,
            IEmailTemplateProcessService emailTemplateProcessService)
        {
            _emailService = emailService;
            this.mediator = mediator;
            this.emailTemplateProcessService = emailTemplateProcessService;
        }

        public async Task<bool> Handle(PaymentEmailCommand command, CancellationToken cancellationToken)
        {
            string templateFile = command.EmailModel.NotificationType.EmailTemplatePath;
            string subject = string.Empty;
            List<string> toEmails = new();
            List<string> ccEmails = new();
            object macroObject = command.EmailModel.MacroObject;

            if (command.EmailModel.Event is PaymentFailureSupportTeamEvent paymentFailureSupprtTreamEvent)
            {
                Service.Clients.Stores.StoreInfoModel store = await mediator.Send(new GetStoreInfoQuery { StoreId = paymentFailureSupprtTreamEvent.StoreId });
                toEmails.Add(store.Emails.Where(w => w.CategoryTypeLevelId == (int)StoreEmailCategoryTypeLevel.SupportTeam).Select(s => s.Email).FirstOrDefault());
            }
            else
            {
                toEmails.Add(command.EmailModel.User.Email);
            }

            subject = TextTemplateMacroProcessor.Process(command.EmailModel.NotificationType.EmailSubject, command.EmailModel.MacroObject, command.EmailModel.User, command.EmailModel.Event);


            if (toEmails.Any(t => !string.IsNullOrWhiteSpace(t)))
            {
                _emailService.SendEmail(toEmails.ToArray()
                    , ccEmails.ToArray()
                    , subject
                    , await this.emailTemplateProcessService.ProcessHtmlTemplateFromView(templateFile, macroObject));
            }
            else
            {
                command.EmailModel.Error = "Email not found";
                command.EmailModel.IsEmailSent = false;
                return await Task.FromResult(false);
            }

            return await Task.FromResult(true);
        }
    }
}
