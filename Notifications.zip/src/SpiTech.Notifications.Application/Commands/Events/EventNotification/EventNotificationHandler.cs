﻿using AutoMapper;
using MediatR;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Processors;
using SpiTech.EventBus.DomainEvents;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Notifications.Application.Commands.CreateNotification;
using SpiTech.Notifications.Application.Commands.CreateNotificationRecipient;
using SpiTech.Notifications.Application.Commands.Events.SendEmail;
using SpiTech.Notifications.Application.Commands.Events.SendPushNotification;
using SpiTech.Notifications.Application.UnitOfWorks;
using SpiTech.Notifications.Domain.Configs;
using SpiTech.Notifications.Domain.Entities;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.Events.EventNotification
{
    public class EventNotificationHandler : IRequestHandler<EventNotificationCommand, int>
    {
        private readonly IUnitOfWork context;
        private readonly ILogger<EventNotificationHandler> _logger;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly EmailClientConfig emailClientConfig;

        public EventNotificationHandler(IUnitOfWork context,
                                    ILogger<EventNotificationHandler> logger,
                                    IEventDispatcher eventDispatcher,
                                    IMediator mediator,
                                    IMapper mapper,
                                    EmailClientConfig emailClientConfig)
        {
            this.context = context;
            _logger = logger;
            _eventDispatcher = eventDispatcher;
            _mediator = mediator;
            _mapper = mapper;
            this.emailClientConfig = emailClientConfig;
        }

        public async Task<int> Handle(EventNotificationCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            NotificationType notificationType = (await context.NotificationTypes.GetByfilter((int)command.Event.EventType, 0, command.Event.NotificationTypeIdentifier)).FirstOrDefault();

            if (command.User != null && command.User.PreferedLanguage == "es")
            {                
                string[] templateFile = notificationType.EmailTemplatePath.Split(".");
                notificationType.EmailTemplatePath = templateFile[0] + "-es." + templateFile[1];
            }

            if (notificationType == null)
            {
                throw new InvalidApplicationConfigurationException($"NotificationType is not found in system for Event - {command.Event.GetType().FullName}",
                    $"Configure NotificationType - {command.Event.GetType().FullName}");
            }

            Notification notification = await context.Notifications.GetByFilter(command.Event.MessageIdentifier.ToString());

            if (notification != null)
            {
                return notification.NotificationId;
            }

            CreateNotificationCommand createNotificationCommand = new()
            {
                JsonData = JsonConvert.SerializeObject(command.Event),
                NotificationTypeId = (int)command.Event.EventType,
                NotificationTypeIdentifier = command.Event.NotificationTypeIdentifier,
                EventId = command.Event.EventId,
                EventIdentifierName = command.Event.EventIdentifierName,
                SenderUserId = null,
                DisplayEnabled = notificationType.DisplayEnabled,
                EmailEnabled = notificationType.EmailEnabled && emailClientConfig.Enable,
                MessageIdentifier = command.Event.MessageIdentifier.ToString(),
                PushNotificationEnabled = notificationType.PushNotificationEnabled,
                SmsEnabled = notificationType.SmsEnabled,
            };

            int notificationId = await _mediator.Send(createNotificationCommand);

            if (command.User != null)
            {
                await ProcessUserNotification(command, notificationType, notificationId, cancellationToken);
            }

            if (command.Store != null)
            {
                await ProcessStoreNotification(command, notificationType, notificationId, cancellationToken);
            }

            if (command.SaleAgent != null)
            {
                await ProcessSaleAgentNotification(command, notificationType, notificationId, cancellationToken);
            }

            if (command.Reseller != null)
            {
                await ProcessSaleAgentNotification(command, notificationType, notificationId, cancellationToken);
            }



            _logger.TraceExitMethod(nameof(Handle), notificationId);

            return notificationId;
        }

        private async Task ProcessUserNotification(EventNotificationCommand command,
                                                    NotificationType notificationType,
                                                    int notificationId,
                                                    CancellationToken cancellationToken)
        {
            if (command.User != null)
            {
                string displayTemplate = notificationType.DisplayTemplate;
                if(command.User.PreferedLanguage=="es")
                {
                    notificationType.DisplayTemplate = notificationType.DisplayTemplateES;
                    notificationType.PushNotificationTemplate = notificationType.PushNotificationTemplateES;
                }
                EmailModel emailResult = null;
                PushNotificationEventModel pushNotificationResult = null;

                int unreadcount = await context.NotificationRecipients.GetUnreadNotificationCount(command.User.UserId);
                if (notificationType.EmailEnabled && emailClientConfig.Enable && command.User.EmailNotificationAllow && command.User.EmailConfirmed)
                {
                    emailResult = await _mediator.Send(new SendEmailCommand
                    {
                        EmailModel = new EmailModel
                        {
                            Event = command.Event,
                            User = command.User,
                            NotificationType = notificationType,
                            MacroObject = command.UserMacroObject,
                        }
                    }, cancellationToken);
                }

                if (notificationType.PushNotificationEnabled && command.User.AppNotificationAllow)
                {
                    pushNotificationResult = await _mediator.Send(new SendPushNotificationCommand
                    {
                        PushNotificationModel = new PushNotificationEventModel
                        {
                            Event = command.Event,
                            User = command.User,
                            MobileAppType = command.MobileAppType == MobileAppType.None ? MobileAppType.Consumer : command.MobileAppType,
                            NotificationType = notificationType,
                            MacroObject = command.UserMacroObject,
                            UnReadCount = unreadcount,
                        }
                    }, cancellationToken);
                }

                CreateNotificationRecipientCommand createNotificationRecipientCommand = new()
                {
                    NotificationId = notificationId,
                    UserId = command.User.UserId,
                    DisplayMessage = TextTemplateMacroProcessor.Process(displayTemplate, command.UserMacroObject, command.Event),
                    IsEmailSent = emailResult?.IsEmailSent,
                    HasErrorInEmail = emailResult?.IsError,
                    EmailSentDate = emailResult?.IsEmailSent ?? false ? null : DateTime.UtcNow,
                    EmailErrorMessage = emailResult?.Error,
                    EmailRetryCount = emailResult?.RetryCount ?? 0,
                    IsPushNotificationSent = pushNotificationResult?.IsPushNotificationSent,
                    HasErrorInPushNotification = pushNotificationResult?.IsError,
                    PushNotificationSentDate = pushNotificationResult?.IsPushNotificationSent ?? false ? null : DateTime.UtcNow,
                    PushNotificationErrorMessage = pushNotificationResult?.Error,
                    PushNotificationRetryCount = pushNotificationResult?.RetryCount ?? 0,
                    DisplayMessageES = TextTemplateMacroProcessor.Process(notificationType.DisplayTemplateES, command.UserMacroObject, command.Event),
                };

                await _mediator.Send(createNotificationRecipientCommand);
            }
        }

        private async Task ProcessStoreNotification(EventNotificationCommand command,
                                                    NotificationType notificationType,
                                                    int notificationId,
                                                    CancellationToken cancellationToken)
        {

            EmailModel emailResult = null;

            if (command.Store != null)
            {
                if (notificationType.EmailEnabled && emailClientConfig.Enable)
                {
                    emailResult = await _mediator.Send(new SendEmailCommand
                    {
                        EmailModel = new EmailModel
                        {
                            Event = command.Event,
                            Store = command.Store,
                            NotificationType = notificationType,
                            MacroObject = command.StoreMacroObject,
                        }
                    }, cancellationToken);
                }


                CreateNotificationRecipientCommand createNotificationRecipientCommand = new()
                {
                    NotificationId = notificationId,
                    StoreId = command.Store.StoreId,
                    DisplayMessage = TextTemplateMacroProcessor.Process(notificationType.DisplayTemplate, command.Event, command.StoreMacroObject),
                    IsEmailSent = emailResult?.IsEmailSent,
                    HasErrorInEmail = emailResult?.IsError,
                    EmailSentDate = emailResult?.IsEmailSent ?? false ? null : DateTime.UtcNow,
                    EmailErrorMessage = emailResult?.Error,
                    EmailRetryCount = emailResult?.RetryCount ?? 0
                };

                await _mediator.Send(createNotificationRecipientCommand);
            }
        }

        private async Task ProcessSaleAgentNotification(EventNotificationCommand command,
                                                    NotificationType notificationType,
                                                    int notificationId,
                                                    CancellationToken cancellationToken)
        {

            EmailModel emailResult = null;

            if (command.SaleAgent != null)
            {
                if (notificationType.EmailEnabled && emailClientConfig.Enable)
                {
                    emailResult = await _mediator.Send(new SendEmailCommand
                    {
                        EmailModel = new EmailModel
                        {
                            Event = command.Event,
                            SaleAgent = command.SaleAgent,
                            NotificationType = notificationType,
                            MacroObject = command.SaleAgentMacroObject,
                        }
                    }, cancellationToken);
                }

                CreateNotificationRecipientCommand createNotificationRecipientCommand = new()
                {
                    NotificationId = notificationId,
                    SaleAgentId = command.SaleAgent.SaleAgentId,
                    DisplayMessage = TextTemplateMacroProcessor.Process(notificationType.DisplayTemplate, command.Event, command.SaleAgentMacroObject),
                    IsEmailSent = emailResult?.IsEmailSent,
                    HasErrorInEmail = emailResult?.IsError,
                    EmailSentDate = emailResult?.IsEmailSent ?? false ? null : DateTime.UtcNow,
                    EmailErrorMessage = emailResult?.Error,
                    EmailRetryCount = emailResult?.RetryCount ?? 0
                };

                await _mediator.Send(createNotificationRecipientCommand);
            }
        }

        private async Task ProcessResellerNotification(EventNotificationCommand command,
                                                    NotificationType notificationType,
                                                    int notificationId,
                                                    CancellationToken cancellationToken)
        {

            EmailModel emailResult = null;

            if (command.Reseller != null)
            {
                if (notificationType.EmailEnabled && emailClientConfig.Enable)
                {
                    emailResult = await _mediator.Send(new SendEmailCommand
                    {
                        EmailModel = new EmailModel
                        {
                            Event = command.Event,
                            Reseller = command.Reseller,
                            NotificationType = notificationType,
                            MacroObject = command.SaleAgentMacroObject,
                        }
                    }, cancellationToken);
                }

                CreateNotificationRecipientCommand createNotificationRecipientCommand = new()
                {
                    NotificationId = notificationId,
                    ResellerId = command.Reseller.ResellerId,
                    DisplayMessage = TextTemplateMacroProcessor.Process(notificationType.DisplayTemplate, command.Event, command.SaleAgentMacroObject),
                    IsEmailSent = emailResult?.IsEmailSent,
                    HasErrorInEmail = emailResult?.IsError,
                    EmailSentDate = emailResult?.IsEmailSent ?? false ? null : DateTime.UtcNow,
                    EmailErrorMessage = emailResult?.Error,
                    EmailRetryCount = emailResult?.RetryCount ?? 0
                };

                await _mediator.Send(createNotificationRecipientCommand);
            }
        }
    }
}
