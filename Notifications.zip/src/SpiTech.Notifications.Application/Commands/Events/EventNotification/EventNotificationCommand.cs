﻿using MediatR;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events;
using SpiTech.Notifications.Domain.Models;
using SpiTech.Service.Clients.Stores;

namespace SpiTech.Notifications.Application.Commands.Events.EventNotification
{
    public class EventNotificationCommand : IRequest<int>
    {
        public IEvent Event { get; set; }
        public UserInfoModel User { get; set; }
        public MobileAppType MobileAppType { get; set; }
        public StoreInfoModel Store { get; set; }
        public SaleAgentModel SaleAgent { get; set; }
        public ResellerModel Reseller { get; set; }

        public object UserMacroObject { get; set; }
        public object StoreMacroObject { get; set; }
        public object SaleAgentMacroObject { get; set; }
        public object ResellerMacroObject { get; set; }
    }
}
