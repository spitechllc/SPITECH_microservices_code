﻿using FluentValidation;

namespace SpiTech.Notifications.Application.Commands.Events.EventNotification
{
    public class EventNotificationValidator : AbstractValidator<EventNotificationCommand>
    {
        public EventNotificationValidator()
        {
            RuleFor(x => x.Event).NotNull().DependentRules(() =>
            {
                RuleFor(x => x.Event.EventId).MaximumLength(50);
                RuleFor(x => x.Event.EventIdentifierName).MaximumLength(100);
            });
        }
    }
}
