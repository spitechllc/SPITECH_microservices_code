﻿using MediatR;
using SpiTech.ApplicationCore.Processors;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Application.UnitOfWorks;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.Events.Account.AccountPushNotification
{
    public class AccountPushNotificationHandler : IRequestHandler<AccountPushNotificationCommand, bool>
    {
        private readonly IPushNotificationService _pushNotificationService;
        private readonly IUnitOfWork context;
        public AccountPushNotificationHandler(IPushNotificationService pushNotificationService, IUnitOfWork context)
        {
            _pushNotificationService = pushNotificationService;
            this.context = context;
        }

        public async Task<bool> Handle(AccountPushNotificationCommand command, CancellationToken cancellationToken)
        {
            bool result = false;
            string pushNotificationTemplate = command.PushNotificationModel.NotificationType.PushNotificationTemplate;
            string title = command.PushNotificationModel.NotificationType.DisplayTemplate;
            string type = command.PushNotificationModel.NotificationType.NotificationTypeId.ToString();

            object macroObject = command.PushNotificationModel.MacroObject;
            Service.Clients.Identity.UserDeviceModel device = command.PushNotificationModel.User.Devices.Where(w => w.MobileAppTypeId == (int)MobileAppType.Business).FirstOrDefault();

            if (device == null)
            {
                return await Task.FromResult(result);
            }

            Func<string, string> bodyTemplateMacroBinder = t => TextTemplateMacroProcessor.Process(t, macroObject, command.PushNotificationModel.User, command.PushNotificationModel.Event, title);

            title = bodyTemplateMacroBinder(title);

            result = device != null && !string.IsNullOrEmpty(device.DeviceToken)
                ? await _pushNotificationService.SendNotification((DeviceType)device.DeviceTypeId, MobileAppType.Business,
                    device.DeviceToken, type, title, "", command.PushNotificationModel.Event, pushNotificationTemplate, command.PushNotificationModel.UnReadCount, bodyTemplateMacroBinder)
                : throw new ApplicationCore.Domain.Exceptions.BlankDeviceTokenException();

            return await Task.FromResult(result);
        }
    }
}
