﻿using MediatR;
using SpiTech.ApplicationCore.Processors;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Account;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Application.Services;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.Events.Account.AccountEmail
{
    public class AccountEmailHandler : IRequestHandler<AccountEmailCommand, bool>
    {
        private readonly IEmailService _emailService;
        private readonly IEmailTemplateProcessService emailTemplateProcessService;

        public AccountEmailHandler(IEmailService emailService,
            IEmailTemplateProcessService emailTemplateProcessService)
        {
            _emailService = emailService;
            this.emailTemplateProcessService = emailTemplateProcessService;
        }

        public async Task<bool> Handle(AccountEmailCommand command, CancellationToken cancellationToken)
        {
            string templateFile = command.EmailModel.NotificationType.EmailTemplatePath;
            string subject = string.Empty;

            List<string> toEmails = new();
            List<string> ccEmails = new();
            object macroObject = command.EmailModel.MacroObject;

            if (command.EmailModel.Event is InvoiceReceiveEvent invoiceReceiveEvent)
            {
                templateFile = Path.Combine("Account", $"{(InvocieTemplateEnum)invoiceReceiveEvent.Invoice.TemplateType}.cshtml");
            }
            subject = TextTemplateMacroProcessor.Process(command.EmailModel.NotificationType.EmailSubject, command.EmailModel.MacroObject, command.EmailModel.User, command.EmailModel.Event);

            toEmails.Add(command.EmailModel.User.Email);

            if (toEmails.Any(t => !string.IsNullOrWhiteSpace(t)))
            {
                _emailService.SendEmail(toEmails.ToArray()
                    , ccEmails.ToArray()
                    , subject
                    , await this.emailTemplateProcessService.ProcessHtmlTemplateFromView(templateFile, macroObject));
            }
            else
            {
                command.EmailModel.Error = "Email not found";
                command.EmailModel.IsEmailSent = false;
                return await Task.FromResult(false);
            }

            return await Task.FromResult(true);
        }
    }
}
