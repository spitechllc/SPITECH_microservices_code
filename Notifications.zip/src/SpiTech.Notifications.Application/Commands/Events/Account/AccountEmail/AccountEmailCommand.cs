﻿using MediatR;
using SpiTech.Notifications.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.Events.Account.AccountEmail
{
    public class AccountEmailCommand : IRequest<bool>
    {
        public EmailModel EmailModel { get; set; }
    }
}
