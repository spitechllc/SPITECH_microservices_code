﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.TextNotification
{
    public class TextNotificationCommand : IRequest<ResponseModel>
    {
        public string Message { get; set; }
        public string MobileNo { get; set; }
    }
}
