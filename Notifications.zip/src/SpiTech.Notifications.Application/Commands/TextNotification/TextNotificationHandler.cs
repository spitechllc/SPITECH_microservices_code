﻿using MediatR;
using Polly;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Application.Services;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.TextNotification
{
    public class TextNotificationHandler : IRequestHandler<TextNotificationCommand, ResponseModel>
    {
        private readonly IMobileNotificationservice mobileNotificationservice;
        private readonly ILogger<TextNotificationHandler> logger;

        public TextNotificationHandler(IMobileNotificationservice mobileNotificationservice,
            ILogger<TextNotificationHandler> logger)
        {
            this.mobileNotificationservice = mobileNotificationservice;
            this.logger = logger;
        }
        public async Task<ResponseModel> Handle(TextNotificationCommand command, CancellationToken cancellationToken)
        {
            logger.Warn($"SMS message TextNotificationHandler");
            logger.Warn($"SMS Message SendSms : {command.Message}");
            logger.Warn($"SMS Message SendSms Mobile: {command.MobileNo}");

            string msg = await mobileNotificationservice.SendSms(command.Message, command.MobileNo);

            return new ResponseModel { Message = msg, Success = true };
        }
    }
}
