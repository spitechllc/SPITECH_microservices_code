﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.CreateUserNotificationConfigration
{
    public class UserNotificationConfigrationCommand : IRequest<ResponseModel>
    {
        public int UserId { get; set; }
        public bool EmailNotificationAllow { get; set; }
        public bool AppNotificationAllow { get; set; }
    }
}
