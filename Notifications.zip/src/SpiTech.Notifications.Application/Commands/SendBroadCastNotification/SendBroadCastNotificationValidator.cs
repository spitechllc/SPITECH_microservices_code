﻿using FluentValidation;

namespace SpiTech.Notifications.Application.Commands.SendBroadCastNotification
{
    public class SendBroadCastNotificationValidator : AbstractValidator<SendBroadCastNotificationCommand>
    {
        public SendBroadCastNotificationValidator()
        {
            RuleFor(x => x.Title).NotNull().WithMessage("Title is Required");
            RuleFor(x => x.Body).NotNull().WithMessage("Body is Required");
            RuleFor(x => x.UserIds).Must(x => x.Length > 0).WithMessage("Userids must contains at least one userid");
        }
    }
}
