﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.SendBroadCastNotification
{
    public class SendBroadCastNotificationCommand : IRequest<ResponseModel>
    {
        public string Title { get; set; }
        public string Body { get; set; }
        public int[] UserIds { get; set; }
    }
}
