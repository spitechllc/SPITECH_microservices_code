﻿using FirebaseAdmin.Messaging;
using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events;
using SpiTech.Notifications.Application.Commands.CreateNotification;
using SpiTech.Notifications.Application.Commands.CreateNotificationRecipient;
using SpiTech.Notifications.Application.UnitOfWorks;
using SpiTech.Notifications.Domain.Configs;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.SendBroadCastNotification
{
    public class SendBroadCastNotificationHandler :
        IRequestHandler<SendBroadCastNotificationCommand, ResponseModel>
    {

        private readonly IUnitOfWork _context;
        private readonly IIdentityServiceClient identityapiclient;
        private readonly EmailClientConfig emailClientConfig;
        private readonly IMediator _mediator;

        public SendBroadCastNotificationHandler(IUnitOfWork context,
                                                IIdentityServiceClient identityapiclient,
                                                IMediator mediator,
                                                EmailClientConfig emailClientConfig)
        {
            _context = context;
            this.identityapiclient = identityapiclient;
            _mediator = mediator;
            this.emailClientConfig = emailClientConfig;
        }

        public async Task<ResponseModel> Handle(SendBroadCastNotificationCommand request, CancellationToken cancellationToken)
        {
            /*
              https://firebase.google.com/docs/cloud-messaging/android/topic-messaging
              https://firebase.google.com/docs/admin/setup/
              https://medium.com/@tamashudak/building-net-core-app-server-to-send-firebase-cloud-messaging-message-requests-641f3c6c90ae             
             */

            try
            {
                string topic = "SpiTechBroadcast";
                List<string> registrationTokens = await GetUserDeviceToken(request);

                if (registrationTokens == null || registrationTokens.Count <= 0)
                {
                    return await Task.FromResult(new ResponseModel { Success = false, Message = "Invalid userids" });
                }
                else
                {
                    await SubscribeTopic(topic, registrationTokens);

                    await SendNotificationTopic(topic, request.Title, request.Body);

                    await UnSubscribeTopic(topic, registrationTokens);

                    // Insert data to notification table
                    ICollection<Service.Clients.Identity.UserModel> result = await identityapiclient.GetUserListAsync(request.UserIds);
                    int[] userIds;
                    if (result != null && result.Any())
                    {
                        userIds = result.Select(t => t.UserId).Distinct().ToArray();
                        await InsertNotification(request, userIds, request.Title, request.Body, cancellationToken);

                    }

                    return await Task.FromResult(new ResponseModel { Success = true, Message = "Success" });
                }
            }
            catch (Exception ex)
            {
                return await Task.FromResult(new ResponseModel { Success = false, Message = ex.Message });
            }
        }

        private async Task<List<string>> GetUserDeviceToken(SendBroadCastNotificationCommand req)
        {
            // get on base of userid or ALL 

            ICollection<Service.Clients.Identity.UserModel> result = await identityapiclient.GetUserListAsync(req.UserIds);

            List<string> registrationTokens = null;
            if (result != null && result.Any())
            {
                result = result.Where(s => s.Devices.Count() > 0).ToList();
                registrationTokens = result.Select(x => x.Devices.FirstOrDefault().DeviceToken).ToList();
            }
            return registrationTokens;
        }

        private async Task<int> SubscribeTopic(string topic, List<string> registrationTokens)
        {
            TopicManagementResponse response = await FirebaseMessaging.DefaultInstance.SubscribeToTopicAsync(
               registrationTokens, topic);
            // See the TopicManagementResponse reference documentation
            // for the contents of response.
            return response.SuccessCount;
        }

        private async Task<int> UnSubscribeTopic(string topic, List<string> registrationTokens)
        {
            TopicManagementResponse response = await FirebaseMessaging.DefaultInstance.UnsubscribeFromTopicAsync(
               registrationTokens, topic);
            // See the TopicManagementResponse reference documentation
            // for the contents of response.
            return response.SuccessCount;
        }

        private async Task<string> SendNotificationTopic(string topic, string title, string body)
        {
            // See documentation on defining a message payload.
            Message message = new()
            {
                Data = null,
                Topic = topic,
                Notification = new Notification()
                {
                    Title = title,
                    Body = body,
                },
            };

            // Send a message to the devices subscribed to the provided topic.
            string response = await FirebaseMessaging.DefaultInstance.SendAsync(message);
            // Response is a message ID string.
            return response;
        }

        private async Task InsertNotification(SendBroadCastNotificationCommand command, int[] users, string title, string body,
                                                    CancellationToken cancellationToken)
        {
            if (users != null && users.Count() > 0)
            {

                CreateNotificationCommand createNotificationCommand = new()
                {
                    JsonData = ApplicationCore.Helpers.JsonObjectConverter.Serialize(command),
                    NotificationTypeId = (int)EventType.AppNotificationEvent,
                    NotificationTypeIdentifier = NotificationTypeIdentifierConstants.AppNotificationEvent,
                    EventId = users.FirstOrDefault().ToString(),
                    EventIdentifierName = "UserId",
                    SenderUserId = null,
                    DisplayEnabled = true,
                    EmailEnabled = true && emailClientConfig.Enable,
                    MessageIdentifier = Guid.NewGuid().ToString("N").ToLower(),
                    PushNotificationEnabled = false,
                    SmsEnabled = false
                };

                int notificationId = await _mediator.Send(createNotificationCommand);

                foreach (var userId in users)
                {

                    CreateNotificationRecipientCommand createNotificationRecipientCommand = new()
                    {
                        NotificationId = notificationId,
                        UserId = userId,
                        DisplayMessage = body,
                        IsEmailSent = null,
                        HasErrorInEmail = null,
                        EmailSentDate = DateTime.UtcNow,
                        EmailErrorMessage = null,
                        EmailRetryCount = 0
                    };

                    await _mediator.Send(createNotificationRecipientCommand);
                }
            }
        }
    }
}
