﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Notifications.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.UpdateNotificationRecipient
{
    public class UpdateNotificationRecipientHandler : IRequestHandler<UpdateNotificationRecipientCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateNotificationRecipientHandler> _logger;
        private readonly IMapper _mapper;

        public UpdateNotificationRecipientHandler(IUnitOfWork context,
                                             ILogger<UpdateNotificationRecipientHandler> logger,
                                             IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<ResponseModel> Handle(UpdateNotificationRecipientCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            bool result = false;

            await _context.Execute(async () =>
            {
                result = await _context.NotificationRecipients.Update(new Domain.Entities.NotificationRecipient()
                {
                    NotificationRecipientId = command.NotificationRecipientId,
                    UserId = command.UserId,
                    NotificationId = command.NotificationId,
                    DisplayMessage = command.DisplayMessage,
                    IsRead = command.IsRead,
                    ReadDate = command.ReadDate,
                    EmailRetryCount = command.EmailRetryCount,
                    IsEmailSent = command.IsEmailSent,
                    EmailSentDate = command.EmailSentDate,
                    HasErrorInEmail = command.HasErrorInEmail,
                    EmailErrorMessage = command.EmailErrorMessage,
                    SmsRetryCount = command.SmsRetryCount,
                    IsSmsSent = command.IsSmsSent,
                    SmsSentDate = command.SmsSentDate,
                    HasErrorInSms = command.HasErrorInSms,
                    SmsErrorMessage = command.SmsErrorMessage,
                    SmsMessage = command.SmsMessage,
                    StoreId = command.StoreId,
                });
            });

            _logger.TraceExitMethod(nameof(Handle), result);

            return new ResponseModel() { Success = true, Message = result ? "Success" : "Fail" };
        }
    }
}
