﻿using FluentValidation;
using SpiTech.Notifications.Domain.Entities;

namespace SpiTech.Notifications.Application.Commands.UpdateNotificationRecipient
{
    public class UpdateNotificationRecipientValidator : AbstractValidator<NotificationRecipient>
    {
        public UpdateNotificationRecipientValidator()
        {
            RuleFor(x => x.NotificationRecipientId).NotNull().WithMessage("NotificationRecipientId is required");
            RuleFor(x => x.NotificationId).NotNull().WithMessage("NotificationId is requied");
        }
    }
}
