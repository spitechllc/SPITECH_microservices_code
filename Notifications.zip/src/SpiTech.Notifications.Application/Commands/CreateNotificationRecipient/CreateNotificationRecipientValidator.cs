﻿using FluentValidation;
using SpiTech.Notifications.Domain.Entities;

namespace SpiTech.Notifications.Application.Commands.CreateNotificationRecipient
{
    public class CreateNotificationRecipientValidator : AbstractValidator<NotificationRecipient>
    {
        public CreateNotificationRecipientValidator()
        {
            RuleFor(x => x.UserId).NotNull().WithMessage("Recipient UserId is required");
            RuleFor(x => x.NotificationId).NotNull().WithMessage("NotificationId is requied");
        }
    }
}
