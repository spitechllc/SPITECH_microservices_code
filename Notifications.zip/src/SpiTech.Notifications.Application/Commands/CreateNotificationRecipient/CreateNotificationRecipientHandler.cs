﻿using AutoMapper;
using Dapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Notifications.Application.UnitOfWorks;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Twilio.TwiML.Voice;

namespace SpiTech.Notifications.Application.Commands.CreateNotificationRecipient
{
    public class CreateNotificationRecipientHandler : IRequestHandler<CreateNotificationRecipientCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<CreateNotificationRecipientHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IIdentityServiceClient _identityapiclient;

        public CreateNotificationRecipientHandler(IUnitOfWork context,
                                             ILogger<CreateNotificationRecipientHandler> logger,
                                             IMapper mapper, IIdentityServiceClient identityapiclient)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
            _identityapiclient = identityapiclient;
        }

        public async Task<ResponseModel> Handle(CreateNotificationRecipientCommand command, CancellationToken cancellationToken)
        {
            var userTenantDetail = await _identityapiclient.GetUserTeanantByIdAsync((int)command.UserId);
            var strTenantName = userTenantDetail.Data.TenantName;
            _logger.Warn("NotificationRecipientsForAddCardTenantName:", strTenantName);

            switch (strTenantName)
            {
                case "THEStation":
                    command.DisplayMessage = command.DisplayMessage.Replace("SpiTech", "THEStation");
                    break;
                case "Verifone":
                    command.DisplayMessage = command.DisplayMessage.Replace("SpiTech", "Verifone");
                    break;
                case "Velocity":
                    command.DisplayMessage = command.DisplayMessage.Replace("SpiTech", "Velocity");
                    break;
                case "SpiTech":
                    command.DisplayMessage = command.DisplayMessage.Replace("SpiTech", "SpiTech");
                    break;
                default:
                    command.DisplayMessage = command.DisplayMessage;
                    break;
            }

            _logger.Warn(nameof(Handle), command);
            try
            {
                _logger.Warn("NotificationRecipientsUserIdRam:", command.UserId + command.DisplayMessage);
                
                int id = await _context.NotificationRecipients.Add(new Domain.Entities.NotificationRecipient()
                {
                    UserId = command.UserId,
                    NotificationId = command.NotificationId,
                    DisplayMessage = command.DisplayMessage,
                    IsRead = command.IsRead,
                    ReadDate = command.ReadDate,

                    EmailRetryCount = command.EmailRetryCount,
                    IsEmailSent = command.IsEmailSent,
                    EmailSentDate = command.EmailSentDate,
                    HasErrorInEmail = command.HasErrorInEmail,
                    EmailErrorMessage = command.EmailErrorMessage,

                    PushNotificationRetryCount = command.PushNotificationRetryCount,
                    IsPushNotificationSent = command.IsPushNotificationSent,
                    PushNotificationSentDate = command.PushNotificationSentDate,
                    HasErrorInPushNotification = command.HasErrorInPushNotification,
                    PushNotificationErrorMessage = command.PushNotificationErrorMessage,

                    SmsRetryCount = command.SmsRetryCount,
                    IsSmsSent = command.IsSmsSent,
                    SmsSentDate = command.SmsSentDate,
                    HasErrorInSms = command.HasErrorInSms,
                    SmsErrorMessage = command.SmsErrorMessage,
                    SmsMessage = command.SmsMessage,

                    StoreId = command.StoreId,
                    SaleAgentId = command.SaleAgentId,
                    ResellerId = command.ResellerId,
                    IsActive = true,
                    DisplayMessageES=command.DisplayMessageES
                });

                _logger.TraceExitMethod(nameof(Handle), id);
                _context.Commit();
            }
            catch (Exception ex)
            {
                _context.Rollback();
                _logger.Error(ex);
                throw;
            }
            return new ResponseModel() { Success = true, Message = "Success" };
        }
    }
}
