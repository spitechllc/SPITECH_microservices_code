﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;
using System;

namespace SpiTech.Notifications.Application.Commands.CreateNotificationRecipient
{
    public class CreateNotificationRecipientCommand : IRequest<ResponseModel>
    {
        public int? UserId { get; set; }
        public int? StoreId { get; set; }
        public int? SaleAgentId { get; set; }
        public int? ResellerId { get; set; }
        public int NotificationId { get; set; }
        public string DisplayMessage { get; set; }
        public string SmsMessage { get; set; }
        public bool IsRead { get; set; }
        public DateTime? ReadDate { get; set; }
        public int EmailRetryCount { get; set; }
        public bool? IsEmailSent { get; set; }
        public DateTime? EmailSentDate { get; set; }
        public bool? HasErrorInEmail { get; set; }
        public string EmailErrorMessage { get; set; }
        public int PushNotificationRetryCount { get; set; }
        public bool? IsPushNotificationSent { get; set; }
        public DateTime? PushNotificationSentDate { get; set; }
        public bool? HasErrorInPushNotification { get; set; }
        public string PushNotificationErrorMessage { get; set; }
        public int SmsRetryCount { get; set; }
        public bool? IsSmsSent { get; set; }
        public DateTime? SmsSentDate { get; set; }
        public bool? HasErrorInSms { get; set; }
        public string SmsErrorMessage { get; set; }
        public string DisplayMessageES { get; set; }
    }
}
