﻿using FluentValidation;

namespace SpiTech.Notifications.Application.Commands.CreatePushNotification
{
    public class CreatePushNotificationValidator : AbstractValidator<CreatePushNotificationCommand>
    {
        public CreatePushNotificationValidator()
        {
            RuleFor(x => x.DeviceToken).NotNull().NotEmpty().WithMessage("DeviceToken is not required");
            RuleFor(x => x.Body).NotNull().NotEmpty().WithMessage("Body is not required");
            RuleFor(x => x.Title).NotNull().NotEmpty().WithMessage("Title is not required");
        }
    }
}
