﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Notifications.Application.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.CreatePushNotification
{
    public class CreatePushNotificationHandler : IRequestHandler<CreatePushNotificationCommand, ResponseModel>
    {
        private readonly IPushNotificationService pushNotificationService;
        private readonly ILogger<CreatePushNotificationHandler> logger;
        public CreatePushNotificationHandler(IPushNotificationService pushNotificationService,
                                        ILogger<CreatePushNotificationHandler> logger)
        {
            this.pushNotificationService = pushNotificationService;
            this.logger = logger;
        }

        public async Task<ResponseModel> Handle(CreatePushNotificationCommand command, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), command);

            ResponseModel result = new()
            {
                Success = await pushNotificationService.SendNotification((DeviceType)command.DeviceTypeId, MobileAppType.Consumer, command.DeviceToken, "", command.Title, command.Body, null, "", 0, null)
            };

            logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
