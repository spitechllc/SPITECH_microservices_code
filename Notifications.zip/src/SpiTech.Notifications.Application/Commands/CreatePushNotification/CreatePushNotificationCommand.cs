﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.CreatePushNotification
{
    public class CreatePushNotificationCommand : IRequest<ResponseModel>
    {
        public string DeviceToken { get; set; }
        public string Title { get; set; }
        public string Body { get; set; }
        public int DeviceTypeId { get; set; }
    }
}
