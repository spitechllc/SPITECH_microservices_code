﻿using FluentValidation;

namespace SpiTech.Notifications.Application.Commands.UpdateNotification
{
    public class UpdateNotificationValidator : AbstractValidator<UpdateNotificationCommand>
    {
        public UpdateNotificationValidator()
        {
            RuleFor(x => x.NotificationId).GreaterThan(0).WithMessage("NotificationId must be greater than 0");
            RuleFor(x => x.EventId).NotNull().WithMessage("EventId is not required");
            RuleFor(x => x.EventIdentifierName).NotNull().WithMessage("EventIdentifierName is not required");
            RuleFor(x => x.MessageIdentifier).NotNull().WithMessage("MessageIdentifier is not required");
        }
    }
}
