﻿using MediatR;
using SpiTech.ApplicationCore.Domain.Models;

namespace SpiTech.Notifications.Application.Commands.UpdateNotification
{
    public class UpdateNotificationCommand : IRequest<ResponseModel>
    {
        public int NotificationId { get; set; }
        public string EventId { get; set; }
        public string EventIdentifierName { get; set; }
        public string MessageIdentifier { get; set; }
        public string JsonData { get; set; }
        public int? SenderUserId { get; set; }
        public int NotificationTypeId { get; set; }
        public bool DisplayEnabled { get; set; }
        public bool SmsEnabled { get; set; }
        public bool EmailEnabled { get; set; }
        public bool PushNotificationEnabled { get; set; }
    }
}
