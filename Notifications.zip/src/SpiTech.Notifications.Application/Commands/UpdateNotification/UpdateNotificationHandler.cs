﻿using AutoMapper;
using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Notifications.Application.UnitOfWorks;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Commands.UpdateNotification
{
    public class UpdateNotificationHandler : IRequestHandler<UpdateNotificationCommand, ResponseModel>
    {
        private readonly IUnitOfWork _context;
        private readonly ILogger<UpdateNotificationHandler> _logger;
        private readonly IMapper _mapper;

        public UpdateNotificationHandler(IUnitOfWork context,
                                        ILogger<UpdateNotificationHandler> logger,
                                        IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<ResponseModel> Handle(UpdateNotificationCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            bool status = false;

            await _context.Execute(async () =>
            {
                status = await _context.Notifications.Update(new Domain.Entities.Notification()
                {
                    NotificationId = command.NotificationId,
                    EventId = command.EventId,
                    EventIdentifierName = command.EventIdentifierName,
                    MessageIdentifier = command.MessageIdentifier,
                    JsonData = command.JsonData,
                    SenderUserId = command.SenderUserId,
                    NotificationTypeId = command.NotificationTypeId,
                    DisplayEnabled = command.DisplayEnabled,
                    SmsEnabled = command.SmsEnabled,
                    EmailEnabled = command.EmailEnabled,
                    PushNotificationEnabled = command.PushNotificationEnabled,
                });
            });

            _logger.TraceExitMethod(nameof(Handle), status);
            return new ResponseModel { Success = status, Message = status ? "Success" : "Fail" };
        }
    }
}
