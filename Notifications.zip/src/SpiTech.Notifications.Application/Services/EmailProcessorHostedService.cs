﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SpiTech.Notifications.Application.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Services
{
    internal class EmailProcessorHostedService : BackgroundService
    {
        private readonly IEmailBatchProcessor emailBatchProcessor;

        public EmailProcessorHostedService(IServiceScopeFactory scopeFactory)
        {
            IServiceScope scope = scopeFactory.CreateScope();
            emailBatchProcessor = scope.ServiceProvider.GetService<IEmailBatchProcessor>();
        }
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            await emailBatchProcessor.Process(stoppingToken);
        }
    }
}
