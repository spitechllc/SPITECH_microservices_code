﻿using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Converters;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Processors;
using System;
using System.IO;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Services
{
    public interface IEmailTemplateProcessService
    {
        Task<string> ProcessHtmlTemplateFromView(string templateViewFilePath, object model);
        string ProcessHtmlTemplate(string templateFilePath, params object[] models);
    }

    public class EmailTemplateProcessService : IEmailTemplateProcessService
    {
        private readonly ILogger<EmailTemplateProcessService> logger;
        private readonly IViewToStringConverter viewToStringConverter;

        public EmailTemplateProcessService(ILogger<EmailTemplateProcessService> logger, IViewToStringConverter viewToStringConverter)
        {
            this.logger = logger;
            this.viewToStringConverter = viewToStringConverter;
            this.logger = logger;
        }

        public async Task<string> ProcessHtmlTemplateFromView(string templateViewFilePath, object model)
        {
            string viewFile = Path.Combine("Resources", "Emails", templateViewFilePath);
            if (model != null)
            {
                return await viewToStringConverter.RenderViewToStringAsync(viewFile, model);
            }
            else
            {
                return await viewToStringConverter.RenderViewToStringAsync(viewFile, model);
            }
        }

        public string ProcessHtmlTemplate(string templateFilePath, params object[] models)
        {
            if (models != null)
            {
                Func<string, string> emailBodyTemplateMacroBinder = t => TextTemplateMacroProcessor.Process(t, models);
                return EmailTemplate(templateFilePath, emailBodyTemplateMacroBinder);
            }
            else
            {
                return EmailTemplate(templateFilePath, null);
            }
        }

        private string EmailTemplate(string emailTemplateFile, Func<string, string> emailBodyTemplateMacroBinder)
        {
            string emailBody = "";
            string filepath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "Emails", emailTemplateFile);

            //Path.Combine(_webHostEnvironment.ContentRootPath, "Resources", emailTemplateFile)
            if (!File.Exists(filepath))
            {
                throw new InvalidApplicationConfigurationException($"Filepath({filepath}) is not found in system for Email sent",
                   $"Configure - {emailTemplateFile}");
            }
            else
            {
                string template = File.ReadAllText(filepath);
                logger.Info($"template: {template}");

                if (emailBodyTemplateMacroBinder == null)
                {
                    return template;
                }

                emailBody = emailBodyTemplateMacroBinder(template);
            }

            logger.Info($"emailBody: {emailBody}");
            return emailBody;
        }

    }
}
