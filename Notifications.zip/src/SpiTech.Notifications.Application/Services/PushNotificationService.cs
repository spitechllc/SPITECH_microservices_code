﻿using CorePush.Google;
using CorePush.Interfaces;
using Newtonsoft.Json;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Domain.Models;
using System;
using System.IO;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Services
{
    public class PushNotificationService : IPushNotificationService
    {
        private readonly IBusinessFcmSender businessFcmSender;
        private readonly IConsumerFcmSender consumerFcmSender;
        private readonly ILogger<PushNotificationService> logger;

        public PushNotificationService(IBusinessFcmSender businessFcmSender,
                                        IConsumerFcmSender consumerFcmSender,
                                        ILogger<PushNotificationService> logger)
        {
            this.businessFcmSender = businessFcmSender;
            this.consumerFcmSender = consumerFcmSender;
            this.logger = logger;
        }

        public async Task<bool> SendNotification(MobileAppType mobileAppType, string userToken, PushNotification notification)
        {
            IFcmSender fcmSender = mobileAppType == MobileAppType.Business ? businessFcmSender : consumerFcmSender;

            FcmResponse response = await fcmSender.SendAsync(userToken,
                           new
                           {
                               notification = new
                               {
                                   title = notification.Title,
                                   body = notification.Body,
                                   Vibrate = new[] { 500, 110, 500, 110, 450, 110, 200, 110, 170, 40, 450, 110, 200, 110, 170, 40, 500 },
                                   //Icon = "",
                                   //ClickAction = "",
                                   Tag = Guid.NewGuid().ToString("N")
                               },
                           });

            return response.IsSuccess();
        }


        public async Task<bool> SendNotification(DeviceType Dtype, MobileAppType mobileAppType, string userToken, string type,
           string title, string body, object objdata, string bodyTemplate, int UnReadCount, Func<string, string> bodyTemplateMacroBinder = null)
        {
            IFcmSender fcmSender = mobileAppType == MobileAppType.Business ? businessFcmSender : consumerFcmSender;

            string dataJson = "";
            if (!string.IsNullOrEmpty(bodyTemplate))
            {
                body = BodyTemplate(bodyTemplate, bodyTemplateMacroBinder);
            }

            if (objdata != null)
            {
                dataJson = JsonConvert.SerializeObject(objdata, new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore });
            }
            FcmResponse response = new();
            if (Dtype == DeviceType.iOS)
            {
                response = await fcmSender.SendAsync(userToken,
                               new
                               {
                                   notification = new
                                   {
                                       title = title,
                                       type = type,
                                       body = body,
                                       data = dataJson,
                                       Vibrate = new[] { 500, 110, 500, 110, 450, 110, 200, 110, 170, 40, 450, 110, 200, 110, 170, 40, 500 },
                                       unreadcount = UnReadCount,
                                       //Icon = "",
                                       //ClickAction = "",
                                       Tag = Guid.NewGuid().ToString("N")
                                   }

                               });
            }
            if (Dtype == DeviceType.Android)
            {
                response = await fcmSender.SendAsync(userToken,
                               new
                               {
                                   data = new
                                   {
                                       title = title,
                                       type = type,
                                       body = body,
                                       data = dataJson,
                                       Vibrate = new[] { 500, 110, 500, 110, 450, 110, 200, 110, 170, 40, 450, 110, 200, 110, 170, 40, 500 },
                                       unreadcount = UnReadCount,
                                       //Icon = "",
                                       //ClickAction = "",
                                       Tag = Guid.NewGuid().ToString("N")
                                   }

                               });
            }

            return response.IsSuccess();
        }
        private string BodyTemplate(string template, Func<string, string> bodyTemplateMacroBinder)
        {
            string body = "";

            if (string.IsNullOrWhiteSpace(template))
            {
                return body;
            }

            if (bodyTemplateMacroBinder == null)
            {
                return template;
            }

            body = bodyTemplateMacroBinder(template);

            logger.Info($"PushNotifications Body: {body}");

            return body;
        }
    }
}
