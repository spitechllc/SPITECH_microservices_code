﻿using SpiTech.Application.Logging.Interfaces;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Domain.Configs;
using System;
using System.Threading.Tasks;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace SpiTech.Notifications.Application.Services
{
    public class MobileNotificationservice : IMobileNotificationservice
    {
        private readonly TwilioConfig twilioConfig;
        private readonly ILogger<MobileNotificationservice> logger;

        public MobileNotificationservice(TwilioConfig twilioConfig, ILogger<MobileNotificationservice> logger)
        {
            this.twilioConfig = twilioConfig;
            this.logger = logger;
        }
        public async Task<string> SendSms(string text, string mobileNumber)
        {
            try
            {
                CreateMessageOptions messageOptions = new(new PhoneNumber(mobileNumber))
                {
                    Body = text,
                    MessagingServiceSid = twilioConfig.MessagingServiceSid
                };
                MessageResource message = await MessageResource.CreateAsync(messageOptions);

                return message.Status.ToString();
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                return "Error";
            }
        }
    }
}
