﻿namespace SpiTech.Notifications.Application.Services
{
    public class BusinessFCMSender//: FcmSender
    {
    }
}
