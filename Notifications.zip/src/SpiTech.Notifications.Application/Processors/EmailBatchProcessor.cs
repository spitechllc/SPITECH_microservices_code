﻿using MediatR;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.Notifications.Application.Interfaces;
using SpiTech.Notifications.Domain.Configs;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Application.Processors
{
    public class EmailBatchProcessor : IEmailBatchProcessor
    {
        private readonly IMediator mediator;
        private readonly ILogger<EmailBatchProcessor> logger;
        private readonly BatchProcessorConfig batchProcessorConfig;
        private readonly EmailClientConfig emailClientConfig;

        public EmailBatchProcessor(IMediator mediator,
                                    ILogger<EmailBatchProcessor> logger,
                                    BatchProcessorConfig batchProcessorConfig,
                                    EmailClientConfig emailClientConfig)
        {
            this.mediator = mediator;
            this.logger = logger;
            this.batchProcessorConfig = batchProcessorConfig;
            this.emailClientConfig = emailClientConfig;
        }

        public async Task Process(CancellationToken cancellationToken = default)
        {
            if (batchProcessorConfig.Enable && emailClientConfig.Enable)
            {
                while (!cancellationToken.IsCancellationRequested)
                {
                    int batchResultCount = 0;
                    try
                    {
                        //var emailBatch = (await this.mediator.Send(new GetUnsentEmailNotificationRequest { BatchSize = batchProcessorConfig.BatchSize }, cancellationToken)).ToList();
                        //batchResultCount = emailBatch.Count;

                        //if (emailBatch != null && emailBatch.Any())
                        //{
                        //    foreach (var emailModel in emailBatch)
                        //    {
                        //        var result = await this.mediator.Send(new SendEmailCommand { NotificationEmailModel = emailModel }, cancellationToken);

                        //        await this.mediator.Send(new UpdateEmailSentNotificationCommand { NotificationEmails = emailBatch }, cancellationToken);
                        //    }
                        //}
                    }
                    catch (Exception ex)
                    {
                        logger.Error(ex);
                    }


                    await Task.Delay(TimeSpan.FromSeconds(batchResultCount == 0 ? batchProcessorConfig.BatchMaxIntervalInSec : batchProcessorConfig.BatchMinIntervalInSec));
                }
            }
        }
    }
}
