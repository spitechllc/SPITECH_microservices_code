﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Notifications.Application.Commands.CreatePushNotification;
using SpiTech.Notifications.Application.Commands.GuestUserNotification;
using SpiTech.Notifications.Application.Commands.ReportIssue;
using SpiTech.Notifications.Application.Commands.SendBroadCastNotification;
using SpiTech.Notifications.Application.Commands.SendEmailNotification;
using SpiTech.Notifications.Application.Commands.TextNotification;
using SpiTech.Notifications.Application.Commands.UpdateEmailBanner;
using SpiTech.Notifications.Application.Commands.UpdateNotificationType;
using SpiTech.Notifications.Application.Commands.UpdateReadNotification;
using SpiTech.Notifications.Application.Queries.AppNotification;
using SpiTech.Notifications.Application.Queries.GetAppNotificationById;
using SpiTech.Notifications.Application.Queries.GetNotificationRecipientByFilter;
using SpiTech.Notifications.Application.Queries.GetNotificationType;
using SpiTech.Notifications.Application.Queries.GetNotificationUnreadCount;
using SpiTech.Notifications.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Notifications.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class NotificationsController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<NotificationsController> _logger;

        public NotificationsController(IMediator mediator, ILogger<NotificationsController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        /// <summary>
        /// Api to Create Case For Guest User
        /// </summary>
        /// <param name="model">Object of GuestUserNotificationCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("CreateCaseForGuestUser")]
        public async Task<ActionResult<ResponseModel>> CreateCaseForGuestUser(GuestUserNotificationCommand model)
        {
            _logger.TraceEnterMethod(nameof(GuestUserNotificationCommand), model);
            ResponseModel result = await _mediator.Send(model).ConfigureAwait(false);
            _logger.TraceExitMethod(nameof(GuestUserNotificationCommand), result);
            return Ok(result);
        }

        /// <summary>
        /// Api to Report an Issue to Support Team
        /// </summary>
        /// <param name="model">Object of ReportIssueCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("ReportIssue")]
        public async Task<ActionResult<ResponseModel>> ReportIssue([FromForm] ReportIssueCommand model)
        {
            _logger.TraceEnterMethod(nameof(ReportIssueCommand), model);
            ResponseModel result = await _mediator.Send(model).ConfigureAwait(false);
            _logger.TraceExitMethod(nameof(ReportIssueCommand), result);
            return Ok(result);
        }

        /// <summary>
        /// Method will return list of Notification Type
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of NotificationTypeModel</returns>
        [ApiPermissionAuthorize(Permissions = "Notificationapi_Notifications_GetNotificationType")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetNotificationType")]
        public async Task<ActionResult<ResponseList<NotificationTypeModel>>> GetNotificationType()
        {
            var result = await _mediator.Send(new GetNotificationTypeRequest()).ConfigureAwait(false);
            return Ok(result);
        }

        /// <summary>
        /// Method will return list of Notification by some fields
        /// </summary>
        /// <param name="request">Object of GetNotificationRecipientByFilterQuery</param>
        /// <returns>It will return PaginatedList in the form of NotificationRecipientModel</returns>
        [ApiPermissionAuthorize(Permissions = "Notificationapi_Notifications_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet]
        public async Task<ActionResult<PaginatedList<NotificationRecipientModel>>> GetNotifications([FromQuery] GetNotificationRecipientByFilterQuery request)
        {
            _logger.TraceEnterMethod(nameof(GetNotifications), request);
            PaginatedList<NotificationRecipientModel> result = await _mediator.Send(request).ConfigureAwait(false);
            _logger.TraceExitMethod(nameof(GetNotifications), result);

            return Ok(result);
        }

        /// <summary>
        /// Api To get unread notification count
        /// </summary>
        /// <param name="request">Object of GetNotificationUnreadCountRequest</param>
        /// <returns>It will return in the form of int</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ApiPermissionAuthorize(Permissions = "Notificationapi_Notifications_unread-count")]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("unread-count")]
        public async Task<ActionResult<int>> GetUnreadNotificationCount([FromQuery] GetNotificationUnreadCountRequest request)
        {
            _logger.TraceEnterMethod(nameof(GetUnreadNotificationCount), request);
            int result = await _mediator.Send(request).ConfigureAwait(false);
            _logger.TraceExitMethod(nameof(GetUnreadNotificationCount), result);

            return Ok(result);
        }

        /// <summary>
        /// Api To Mark notification read
        /// </summary>
        /// <param name="model">Object of UpdateReadNotificationCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "Notificationapi_Notifications_mark-read")]
        [HttpPost("mark-read")]
        public async Task<ActionResult<ResponseModel>> PostMarkReadNotifications(UpdateReadNotificationCommand model)
        {
            _logger.TraceEnterMethod(nameof(PostMarkReadNotifications), model);
            ResponseModel result = await _mediator.Send(model).ConfigureAwait(false);
            _logger.TraceExitMethod(nameof(PostMarkReadNotifications), result);
            return Ok(result);
        }

        /// <summary>
        /// Api To send push notification
        /// </summary>
        /// <param name="model">Object of CreatePushNotificationCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "Notificationapi_Notifications_SendPushNotification")]
        [HttpPost("SendPushNotification")]
        public async Task<ActionResult<ResponseModel>> SendPushNotification(CreatePushNotificationCommand model)
        {
            _logger.TraceEnterMethod(nameof(SendPushNotification), model);
            ResponseModel result = await _mediator.Send(model).ConfigureAwait(false);
            _logger.TraceExitMethod(nameof(SendPushNotification), result);
            return Ok(result);
        }

        /// <summary>
        /// Api To broad cast push notifications
        /// </summary>
        /// <param name="model">Object of SendBroadCastNotificationCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "Notificationapi_Notifications_SendOfferNotification")]
        [HttpPost("SendOfferNotification")]
        public async Task<ActionResult<ResponseModel>> SendBroadCastPushNotification(SendBroadCastNotificationCommand model)
        {
            _logger.TraceEnterMethod(nameof(SendBroadCastNotificationCommand), model);
            ResponseModel result = await _mediator.Send(model).ConfigureAwait(false);
            _logger.TraceExitMethod(nameof(SendBroadCastNotificationCommand), result);
            return Ok(result);
        }

        /// <summary>
        /// Api To Create Salesforce Case
        /// </summary>
        /// <remarks>Send NotificationConfigType 1 for HelpDesk and 2 for Admin</remarks>
        /// <param name="model">Object of SendEmailNotificationCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "Notificationapi_Notifications_EmailNotification")]
        [HttpPost("EmailNotification")]
        public async Task<ActionResult<ResponseModel>> SendEmailNotification(SendEmailNotificationCommand model)
        {
            _logger.TraceEnterMethod(nameof(SendEmailNotificationCommand), model);
            ResponseModel result = await _mediator.Send(model).ConfigureAwait(false);
            _logger.TraceExitMethod(nameof(SendEmailNotificationCommand), result);
            return Ok(result);
        }

        /// <summary>
        /// TextNotification is send the text message  by some fields
        /// </summary>
        /// <param name="model">Object of TextNotificationCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [ApiPermissionAuthorize(Permissions = "Notificationapi_Notifications_TextNotification")]
        [HttpPost("TextNotification")]
        public async Task<ActionResult<ResponseModel>> TextNotification(TextNotificationCommand model)
        {
            _logger.TraceEnterMethod(nameof(TextNotificationCommand), model);
            ResponseModel result = await _mediator.Send(model).ConfigureAwait(false);
            _logger.TraceExitMethod(nameof(TextNotificationCommand), result);
            return Ok(result);
        }

        /// <summary>
        /// Api to update banner image from helpsupport
        /// </summary>
        /// <param name="model">Object of UpdateEmailBannerCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Notificationapi_Notifications_UpdateEmailBanner")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("UpdateEmailBanner")]
        public async Task<ActionResult<ResponseModel>> UpdateEmailBanner([FromBody] UpdateEmailBannerCommand model)
        {
            ResponseModel result = await _mediator.Send(model).ConfigureAwait(false);

            return Ok(result);
        }

        /// <summary>
        /// Method will update existing Notification Type
        /// </summary>
        /// <param name="model">Object of UpdateNotificationTypeCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Notificationapi_Notifications_UpdateNotificationType")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("UpdateNotificationType")]
        public async Task<ActionResult<ResponseModel>> UpdateNotificationType([FromBody] UpdateNotificationTypeCommand model)
        {
            var result = await _mediator.Send(model).ConfigureAwait(false);
            return Ok(result);
        }
        /// <summary>
        /// Get AppNotification list 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Notificationapi_Notifications_GetAppNotification")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetAppNotification")]
        public async Task<ActionResult<PaginatedList<AppNotificationModel>>> GetAppNotification([FromQuery] AppNotificationRequest request)
        {
            var result = await _mediator.Send(request).ConfigureAwait(false);
            return Ok(result);
        }

        /// <summary>
        /// Get AppNotification detail by notificationId
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "Notificationapi_Notifications_GetAppNotificationById")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetAppNotificationById")]
        public async Task<ActionResult<AppNotificationDetailModel>> GetAppNotificationById([FromQuery] AppNotificationByIdRequest request)
        {
            return Ok(await _mediator.Send(request).ConfigureAwait(false));
        }
    }
}
