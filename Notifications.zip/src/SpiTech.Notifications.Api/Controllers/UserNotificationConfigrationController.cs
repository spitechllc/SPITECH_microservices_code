﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Domain.Models;
using SpiTech.Notifications.Application.Commands.CreateUserNotificationConfigration;
using SpiTech.Notifications.Application.Queries.GetUserNotificationConfigrationByUserId;
using SpiTech.Notifications.Domain.Models;
using System.Net;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.Notifications.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class UserNotificationConfigrationController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<UserNotificationConfigrationController> _logger;

        public UserNotificationConfigrationController(IMediator mediator, ILogger<UserNotificationConfigrationController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        /// <summary>
        /// Method will return User Notification Configration by user id. 
        /// </summary>
        /// <param name="userId">Varriable of int</param>
        /// <returns>It will return in the form of UserNotificationConfigrationModel</returns>
        [ApiPermissionAuthorize(Permissions = "Notificationapi_UserNotificationConfigration_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("{userId}")]
        public async Task<ActionResult<UserNotificationConfigrationModel>> UserNotificationConfigration([FromRoute] int userId)
        {
            UserNotificationConfigrationModel result = await _mediator.Send(new GetUserNotificationConfigrationByUserIdQuery { UserId = userId }).ConfigureAwait(false);
            return Ok(result);
        }

        /// <summary>
        /// Method will update existing User Notification Configration. 
        /// </summary>
        /// <param name="model">Object of UserNotificationConfigrationCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "Notificationapi_UserNotificationConfigration_Post")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost]
        public async Task<ActionResult<ResponseModel>> UpdateUserNotificationConfigration([FromBody] UserNotificationConfigrationCommand model)
        {
            ResponseModel result = await _mediator.Send(model).ConfigureAwait(false);
            return Ok(result);
        }
    }
}
