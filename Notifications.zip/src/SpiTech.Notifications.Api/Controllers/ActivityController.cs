﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.Pagination;
using SpiTech.Notifications.Application.Queries.GetActivityByFilter;
using SpiTech.Notifications.Domain.Models;
using System.Net;
using System.Threading.Tasks;

namespace SpiTech.Notifications.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class ActivityController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<ActivityController> _logger;

        public ActivityController(IMediator mediator, ILogger<ActivityController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        /// <summary>
        /// Method will return Activities List by some fields. 
        /// </summary>
        /// <param name="request">Object of GetActivityByFilterQuery</param>
        /// <returns>It will return PaginatedList in the form of ActivityReportModel</returns>
        [ApiPermissionAuthorize(Permissions = "Notificationapi_Activity_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet]
        public async Task<ActionResult<PaginatedList<ActivityReportModel>>> GetActivities([FromQuery] GetActivityByFilterQuery request)
        {
            _logger.TraceEnterMethod(nameof(GetActivities), request);
            PaginatedList<ActivityReportModel> result = await _mediator.Send(request).ConfigureAwait(false);
            _logger.TraceExitMethod(nameof(GetActivities), result);

            return Ok(result);
        }
    }
}
