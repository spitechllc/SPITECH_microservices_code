using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using SpiTech.Application.Logging;
using SpiTech.Application.Logging.Extensions;
using System;

namespace SpiTech.Notifications.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            LoggerExtensions.InitializeLogger();
            Logger.Information("Notifications API starting");
            try
            {
                CreateHostBuilder(args).Build().Run();
                Logger.Information($"Notifications Application started in environment: {Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")}");
            }
            catch (Exception e)
            {
                Logger.Error("Notifications API Host terminated unexpected", e);
                throw;
            }
            finally
            {
                Logger.Information("Notifications API stopped");
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            return Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseLogger();
                    webBuilder.UseStartup<Startup>();
                });
        }
    }
}
