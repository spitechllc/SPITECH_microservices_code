#!/bin/bash
cd .. 
echo "################################################DotNet Build########################################################"

dotnet build

echo "##############################################DotNet Publish########################################################"

dotnet publish

echo "################################################Docker Build########################################################"

docker build -f Deployment/dockerfile -t SpiTech/notifications .

echo "##################################################Docker Tag########################################################"

docker tag SpiTech/notifications SpiTechregistry00.azurecr.io/SpiTech/notifications
echo "successfully tagged the image "

echo "#################################################Docker Push########################################################"

docker push SpiTechregistry00.azurecr.io/SpiTech/notifications

