
------------------------------------------------14-11-2022-Start---------------------------------
INSERT [dbo].[NotificationType] ([NotificationTypeId],[NotificationTypeIdentifier], [NotificationTypeName], [NotificationModuleId], [DisplayTemplate], [DisplayEnabled], [SmsTemplate], [SmsEnabled], [EmailSubject],[EmailTemplatePath], [EmailEnabled], [PushNotificationTemplate], [PushNotificationEnabled],[DisplayTemplateES],[EmailSubjectES],[PushNotificationTemplateES]) 
VALUES 
(406,N'ResellerMonthlyBillingInvoiceEvent'  , N'ResellerMonthlyBillingInvoiceEvent', 4, N'[[InvoiceNumber]]-Monthly Payment for [[MonthName]], [[Year]] processed', 1, null, 0, '[[InvoiceNumber]]-Monthly Payment for [[MonthName]], [[Year]] processed','Transaction/ResellerMonthlyBillingInvoiceEvent.cshtml',1,'', 0,'','','')


GO

Alter TABLE [dbo].[NotificationRecipient] Add [ResellerId] INT NULL;

------------------------------------------------14-11-2022-End---------------------------------
-------------------------------start script 26 dec 2022-----------------

CREATE TABLE [dbo].[ActivityType]
(
                 [ActivityTypeId] INT NOT NULL IDENTITY(1,1)
               , [Name] NVARCHAR(50) NOT NULL
               , [IsActive] BIT NOT NULL DEFAULT((1))
               , [CreatedOn] DATETIME NOT NULL DEFAULT(getutcdate())
               , [CreatedBy] INT NULL
               , [UpdatedOn] DATETIME NULL
               , [UpdatedBy] INT NULL
               , CONSTRAINT [PK_ActivityType] PRIMARY KEY ([ActivityTypeId] ASC)
)

GO

CREATE TABLE [dbo].[Activity]
(
                 [ActivityId] INT NOT NULL IDENTITY(1,1)
               , [ActivityTypeId] INT NOT NULL
			   , [UserId] INT NOT NULL
               , [ActivityRecordKeyId] NVARCHAR(100) NULL
               , [ActivityPreData] NVARCHAR(MAX) NULL
               , [ActivityPostData] NVARCHAR(MAX) NULL
               , [ActivityTime] DATETIME NULL DEFAULT(getutcdate())
               , [ActivityIP] NVARCHAR(MAX) NULL
	           , [IsError] [bit] NULL
	           , [ErrorMessage] [nvarchar](500) NULL
               , [IsActive] BIT NOT NULL DEFAULT((1))
               , [CreatedOn] DATETIME NULL DEFAULT(getutcdate())
               , [CreatedBy] INT NULL
               , [UpdatedOn] DATETIME NULL
               , [UpdatedBy] INT NULL
               , CONSTRAINT [PK_ Activity] PRIMARY KEY ([ActivityId] ASC)
)

SET IDENTITY_INSERT [ActivityType] ON 
GO
INSERT INTO [ActivityType] ([Name],[ActivityTypeId])
VALUES 
        ('UserRegister', 1)
        ,('Login',2)
        ,('ForgotPassword', 3)
        ,('ChangePassword', 4)
        ,('UpdateProfile', 5)
        ,('LinkUser',6)
        ,('CreateClaim',7)
        ,('CreateRole',8)
        ,('DeleteUser',9)
        ,('RemoveLinkUser',10)
        ,('UnlockUser',11)
        ,('UpdateConsumerToBusiness',12)
        ,('UpdateMobileNo',13)
        ,('UpdatePermission',14)
        ,('UpdatePreferedLanguage',15)
        ,('UpdateRole',16)
        ,('UpdateUserDevice',17)
        ,('VerifyEmail',18)
        ,('VerifyMobile',19)
        ,('Logout', 20)
        ,('AddPaymentMethod', 21)
        ,('RemovePaymentMethod', 22)
        ,('AddNickName',23)
        ,('DeletePaymentMethod',24)
        ,('PreAuth',25)
        ,('ProcessPayment',26)
        ,('AddResellerConfig',27)
        ,('AddSaleAgentConfig',28)
        ,('AddStoreConfig',29)
        ,('UpdateMerchantNMI',30)
        ,('UpdatePreAuthPayment',31)
        ,('AddCompany',32)
        ,('AddStore',33)
        ,('CreateSaleagent',34)
        ,('CreateReseller',35)
        ,('UpdateCompany',36)
        ,('UpdateStore',37)
        ,('UpdateSaleAgent',38)
        ,('UpdateReseller',39)
        ,('CreateTransaction', 40)
        ,('CreateResellerFee',41)
        ,('CreateSaleAgentFee', 42)
        ,('CreateSettlement', 43)
        ,('CreateStoreBillingFee',44)
        ,('EODSettlement', 45)
        ,('GenerateResellerBilling', 46)
        ,('GenerateSaleAgentBilling', 47)
        ,('GenerateStoreBilling', 48)
        ,('ProcessPaymentResellerBilling', 49)
        ,('ProcessPaymentSaleAgentBilling', 50)
        ,('ProcessPaymentStoreBilling', 51)
        ,('ProcessResellerMonthlyInvoice', 52)
        ,('ProcessSaleAgentMonthlyInvoice', 53)
        ,('ProcessStoreMonthlyInvoice', 54)
        ,('ProcessStoreEodSettlement', 55)
        ,('ReconcileTransaction', 56)
        ,('UpdateResellerFee', 57)
        ,('UpdateSaleAgentFee', 58)
        ,('UpdateStoreBillingFee', 59)
        ,('UpdateTransaction', 60)
        ,('UpdateResellerNeedReview', 61)
        ,('UpdateResellerUnPaid', 62)
        ,('UpdateSaleAgentNeedReview', 63)
        ,('UpdateSaleAgentUnPaid', 64)
        ,('UpdateStoreBillingNeedReview', 65)
        ,('UpdateStoreBillingUnPaid', 66)
        ,('CreatePriceAdjustment', 67)
        ,('CreatePaymentInfo', 68)
        ,('CreateReceiptInfoLine', 69)
        ,('CreateSaleItem', 70)
        ,('ProcessBaiFile', 71)
        ,('UpdateEodUnpaid', 72)
        ,('UpdateEodNeedReview', 73)
        ,('AdminCredit', 74)
        ,('AdminDebit', 75)
        ,('WalletCredit', 76)
        ,('WalletDebit', 77)
		SET IDENTITY_INSERT [ActivityType] OFF
GO
GO
-------------------------end script 26 dec 2022-----------------
