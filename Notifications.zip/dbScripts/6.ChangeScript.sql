update  [dbo].[NotificationType] set [EmailTemplatePath] =replace([EmailTemplatePath],'.html','.cshtml')

delete from [dbo].[NotificationType] where NotificationTypeId>=401 and NotificationTypeId<=499;


INSERT [dbo].[NotificationType] ([NotificationTypeId],[NotificationTypeIdentifier], [NotificationTypeName], [NotificationModuleId], [DisplayTemplate], [DisplayEnabled], [SmsTemplate], [SmsEnabled], [EmailSubject],[EmailTemplatePath], [EmailEnabled], [PushNotificationTemplate], [PushNotificationEnabled]) 
VALUES 

  (401,N'StoreMonthlyBillingInvoiceEvent'  , N'StoreMonthlyBillingInvoiceEvent', 4, N'[[BillingNumber]]-Store monthly bill for [[MonthName]], [[Year]] processed', 1, null, 0, '[[BillingNumber]]-Store monthly bill for [[MonthName]], [[Year]] processed','Transaction/StoreMonthlyBillingInvoiceEvent.cshtml',1,'', 0),
 (402,N'SaleAgentMonthlyBillingInvoiceEvent'  , N'SaleAgentMonthlyBillingInvoiceEvent', 4, N'[[InvoiceNumber]]-Monthly Payment for [[MonthName]], [[Year]] processed', 1, null, 0, '[[InvoiceNumber]]-Monthly Payment for [[MonthName]], [[Year]] processed','Transaction/SaleAgentMonthlyBillingInvoiceEvent.cshtml',1,'', 0),
 (403,N'StoreEodSettlementEvent'  , N'StoreEodSettlementEvent', 4, N'Store EOD settlement reconciled for BussinessDate [[BusinessDateFormatted]]', 1, null, 0, 'Store EOD settlement reconciled for BussinessDate [[BusinessDateFormatted]]','Transaction/StoreEodSettlementEvent.cshtml',1,'', 0),
 (404,N'StoreEodSettlementInvoiceAdminEvent'  , N'StoreEodSettlementInvoiceAdminEvent',4,N'Store EOD settlement invoice for businessDate [[BusinessDateFormatted]] processed',1,NULL,0,N'Store EOD settlement invoice for businessDate [[BusinessDateFormatted]] processed',N'Transaction/StoreEodSettlementInvoiceAdminEvent.cshtml',1,'',0),
 (405,N'StoreEodSettlementInvoiceEvent'  , N'StoreEodSettlementInvoiceEvent', 4, N'Store EOD settlement invoice for businessDate [[BusinessDateFormatted]] processed', 1, null, 0, 'Store EOD settlement invoice for businessDate [[BusinessDateFormatted]] processed','Transaction/StoreEodSettlementInvoiceEvent.cshtml',1,'', 0)
 