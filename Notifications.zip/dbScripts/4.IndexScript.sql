
IF EXISTS (SELECT name FROM sys.indexes  
            WHERE name = N'IX_Notification_MessageIdentifier')   
    DROP INDEX IX_Notification_MessageIdentifier ON [dbo].[Notification];   
GO  

CREATE UNIQUE NONCLUSTERED INDEX IX_Notification_MessageIdentifier
    ON [dbo].[Notification] (MessageIdentifier);   
GO
GO
