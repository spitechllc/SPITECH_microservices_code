﻿GO
INSERT [dbo].[NotificationConfig] ([NotificationConfigId], [EmailIds], [Mobiles], [NotificationConfigTypeId], [IsActive], [CreatedOn]) 
VALUES 
(1, N'flexsinnb@gmail.com', N'', 1, 1, getutcdate()),
(2, N'flexsinnb@gmail.com', N'', 2, 1,  getutcdate()),
(3, N'Support@SpiTech.com', N'', 3, 1,  getutcdate());
GO


INSERT INTO [NotificationModule] ([NotificationModuleId], [NotificationModuleName])
VALUES 
(1, N'Identity'),
(2, N'Store'),
(3, N'MPPA'),
(4, N'Transaction'),
(5, N'Payment'),
(6, N'Marketing'),
(7, N'Finance'),
(8, N'Account');
GO


INSERT [dbo].[NotificationType] ([NotificationTypeId],[NotificationTypeIdentifier], [NotificationTypeName], [NotificationModuleId], [DisplayTemplate], [DisplayEnabled], [SmsTemplate], [SmsEnabled], [EmailSubject],[EmailTemplatePath], [EmailEnabled], [PushNotificationTemplate], [PushNotificationEnabled],[DisplayTemplateES],[EmailSubjectES],[PushNotificationTemplateES]) 
VALUES 
 (100,N'IdentityUserCreated', N'IdentityUserCreatedEvent', 1, N'Your account has been created.', 1, null, 0, 'SpiTech account created','Identity/UserCreated.cshtml',1,'', 0,'Tu cuenta ha sido creada.','Cuenta SpiTech creada',''),
 (101,N'IdentityUserUpdated'  , N'IdentityUserUpdatedEvent', 1, N'Your profile has been updated successfully.', 1, null, 0, 'SpiTech account updated','Identity/UserUpdated.cshtml',1,'Your profile has been updated successfully.',1,N'Tu perfil ha sido actualizado exitosamente.','Cuenta SpiTech actualizada','Tu perfil ha sido actualizado exitosamente.'),
 (102,N'IdentityForgotPassword'  , N'IdentityForgotPasswordEvent', 1, N'The forgot password for your SpiTech account is completed', 1, null, 0, 'The forgot password for your SpiTech account is completed','Identity/ForgotPassword.cshtml',1,'', 0,N'La contraseña olvidada para su cuenta de SpiTech está completa','Recuperación de contraseña de SpiTech',''),
 (103,N'IdentityPasswordChanged'  , N'IdentityPasswordChangedEvent', 1, N'Your Password has been changed successfully.', 1, null, 0, 'Your Password has been changed successfully.','Identity/PasswordChanged.cshtml',1,'Your Password has been changed successfully.',1,N'Tu contraseña ha sido cambiada exitosamente.', 'Contraseña de SpiTech cambiada.','Tu contraseña ha sido cambiada exitosamente.'),
 (104,N'IdentityUserSignIn'  , N'IdentityUserSignInEvent', 1, N'SpiTech Sign-in Success.', 1, null, 0, 'SpiTech Sign-in Success.','Identity/IdentityUserSignIn.cshtml',1,'You have successfully sign-in.',1, N'Exitoso inicio de sesión en SpiTech.','Exitoso inicio de sesión en SpiTech.','Has iniciado sesión correctamente.'),
 (106,N'UserLinkedAccepterEvent'  , N'UserLinkedAccepterEvent', 1, N'Your account linked with [[RequesterName]].', 1, null, 0, 'Your account linked.','Identity/UserLinkedAccepter.cshtml',1,'Your account linked with [[RequesterName]].',1, N'Su cuenta vinculada con  [[RequesterName]].','Tu cuenta vinculada.','Su cuenta vinculada con [[RequesterName]].'),
 (108,N'UserLinkedRequesterEvent'  , N'UserLinkedRequesterEvent', 1, N'You linked successfully with [[AccepterName]].', 1, null, 0, 'Your account linked.','Identity/UserLinkedRequester.cshtml',1,'You linked successfully with [[AccepterName]].',1, N'Se vinculó correctamente con [[AccepterName]].', 'Tu cuenta vinculada.','Se vinculó correctamente con [[AccepterName]].'),
 (109,N'IdentityUserEmailVerifiedEvent'  , N'IdentityUserEmailVerifiedEvent', 1, N'Your email verified successfully.', 1, null, 0, 'Your email verified successfully.','Identity/IdentityUserEmailVerified.cshtml',1,'Your email verified successfully.',1, N'Su correo electrónico verificado con éxito.','Correo Electrónico Verificado.','Su correo electrónico verificado con éxito.'),
 
 (200,N'StoreEvent',N'StoreEvent',2,N'Store information added',0,'',0,N'Store information added',N'Store/StoreCreated.cshtml',1,N'',0,'','',''),
(201,N'StoreUserEvent',N'StoreUserEvent',2,N'Store user information added',0,'',0,N'Store user information added',N'Store/StoreUserCreated.cshtml',1,'',0,'','',''),
 
 (307,N'TransactionSettlementEvent'  , N'TransactionSettlementEvent', 3, N'The Store Transaction Settlement', 1, null, 0, 'SpiTech transaction settlement status','Mppa/TransactionSettlement.cshtml',1,'', 0,'','',''),
 (308,N'MobilePumpReserveResponsesEvent'  , N'MobilePumpReserveResponsesEvent', 3, N'Pump reserved at fueling position [[FuelingPositionId]].', 0, null, 0, 'Pump Reserved Status','',0,'Pump reserved at fueling position [[FuelingPositionId]]',1,N'Bomba reservada en la posición de repostaje [[FuelingPositionId]].', 'Estado reservado de la bomba','Bomba reservada en la posición de repostaje [[FuelingPositionId]]'),
 (309,N'MobilePumpBeginFualResponsesEvent'  , N'MobilePumpBeginFualResponsesEvent', 3, N'Fueling is progress.', 0, null, 0, 'Fueling Progress Status','',0,'Fueling is progress',1, N'Alimentar es progresar.','Estado de progreso de combustible','Alimentar es progresar'),
 (314,N'MobileStacCaptureResponsesEvent'  , N'MobileStacCaptureResponsesEvent', 3, N'Your QR code scanned [[Status]]', 0, null, 0, 'QR Code Scanned Status','',0,'Your QR code scanned [[status]]',1,N'Tu código QR escaneado [[Status]]','Estado escaneado del código QR','Tu código QR escaneado [[status]]'),
 (316,N'MobileFinalizesDataResponseEvent'  , N'MobileFinalizesDataResponseEvent', 3, N'You have paid $[[Amount]] at [[StoreName]].', 1, null, 0, 'SpiTech transaction completed','Mppa/TransactionReceipt.cshtml',1,'You have paid $[[Amount]] at [[StoreName]].',1,N'Has pagado $[[Amount]] en [[StoreName]].', 'Transacción de SpiTech completada','Has pagado $[[Amount]] en [[StoreName]].'),

  
 (401,N'StoreMonthlyBillingInvoiceEvent'  , N'StoreMonthlyBillingInvoiceEvent', 4, N'[[BillingNumber]]-Store monthly bill for [[MonthName]], [[Year]] processed', 1, null, 0, '[[BillingNumber]]-Store monthly bill for [[MonthName]], [[Year]] processed','Transaction/StoreMonthlyBillingInvoiceEvent.cshtml',1,'', 0,'','',''),
 (402,N'SaleAgentMonthlyBillingInvoiceEvent'  , N'SaleAgentMonthlyBillingInvoiceEvent', 4, N'[[InvoiceNumber]]-Monthly Payment for [[MonthName]], [[Year]] processed', 1, null, 0, '[[InvoiceNumber]]-Monthly Payment for [[MonthName]], [[Year]] processed','Transaction/SaleAgentMonthlyBillingInvoiceEvent.cshtml',1,'', 0,'','',''),
 (403,N'StoreEodSettlementEvent'  , N'StoreEodSettlementEvent', 4, N'Store EOD settlement reconciled for BussinessDate [[BusinessDateFormatted]]', 1, null, 0, 'Store EOD settlement reconciled for BussinessDate [[BusinessDateFormatted]]','Transaction/StoreEodSettlementEvent.cshtml',1,'', 0,'','',''),
 (404,N'StoreEodSettlementInvoiceAdminEvent'  , N'StoreEodSettlementInvoiceAdminEvent',4,N'Store EOD settlement invoice for businessDate [[BusinessDateFormatted]] processed',1,NULL,0,N'Store EOD settlement invoice for businessDate [[BusinessDateFormatted]] processed',N'Transaction/StoreEodSettlementInvoiceAdminEvent.cshtml',1,'',0,'','',''),
 (405,N'StoreEodSettlementInvoiceEvent'  , N'StoreEodSettlementInvoiceEvent', 4, N'Store EOD settlement invoice of businessDate [[BusinessDateFormatted]] processed', 1, null, 0, 'Store EOD settlement invoice of businessDate [[BusinessDateFormatted]] processed','Transaction/StoreEodSettlementInvoiceEvent.cshtml',1,'', 0,'','',''),
 (406,N'ResellerMonthlyBillingInvoiceEvent'  , N'ResellerMonthlyBillingInvoiceEvent', 4, N'[[InvoiceNumber]]-Monthly Payment for [[MonthName]], [[Year]] processed', 1, null, 0, '[[InvoiceNumber]]-Monthly Payment for [[MonthName]], [[Year]] processed','Transaction/ResellerMonthlyBillingInvoiceEvent.cshtml',1,'', 0,'','',''),
 (407,N'AchNachaReturnFileEvent'  , N'AchNachaReturnFileEvent',4,N'Ach Nacha Return File received',1,NULL,0,N'Ach Nacha Return File received',N'Transaction/AchNachaReturnFileEvent.cshtml',1,'',0,'','',''),
 
 (501,N'PaymentMethodAddedEvent'  , N'PaymentMethodAddedEvent', 5, N'New Payment method has been added successfully.', 1, null, 0, 'New Payment method has been added successfully.','Payment/PaymentMethodAdded.cshtml',1,'', 0, N'El nuevo método de pago se ha agregado con éxito.', 'El nuevo método de pago se ha agregado con éxito.',''),
 (502,N'PaymentMethodRemovedEvent'  , N'PaymentMethodRemovedEvent', 5, N'Payment method has been deleted successfully', 1, null, 0, 'Payment method has been deleted successfully','Payment/PaymentMethodDeleted.cshtml',1,'', 0,N'El método de pago se ha eliminado correctamente','El método de pago se ha eliminado correctamente',''),
 (503,N'PaymentFailedEvent'  ,	N'PaymentFailedEvent'	,5,	N'Payment Failed',	1,	NULL,	0,	'Payment Failed', 'Payment/PaymentFailed.cshtml',	1,	'',	0,N'Pago fallido','Pago fallido',''),
 (504,N'PaymentFailureSupportTeamEvent'  ,	N'PaymentFailureSupportTeamEvent'	,5,	N'Payment Failed',	1,	NULL,	0,	'Payment Failed', 'Payment/PaymentFailedforSupportTeam.cshtml',	1,	'',	0,N'Pago fallido','Pago fallido',''),
 
 (600,N'ConsumerOfferSendEvent'  , N'ConsumerOfferSendEvent', 6, N'You Received an Offer', 1, null, 0, 'New offers around you','Marketing/Consumeroffer.cshtml',1,'Your have received offer from [[StoreName]]',1,N'Recibiste una oferta','Nuevas ofertas a tu alrededor','Has recibido una oferta de [[StoreName]]'),
 
 (700,N'WalletCreditEvent'  , N'WalletCreditEvent', 7, N'Your Wallet is credited with $[[CreditAmount]]', 1, null, 0, 'SpiTech Wallet Credited','Finance/WalletCredit.cshtml',1,'Your Wallet is credited with $[[CreditAmount]] as cash reward for paying at [[StoreName]]',1,N'A su billetera se le acreditan $[[CreditAmount]]', 'Monedero SpiTech acreditado','A su Monedero se le acreditan $[[CreditAmount]] como recompensa en efectivo por pagar en [[StoreName]]'),
 (700,N'WalletLinkUserTransferCreditEvent'  , N'WalletCreditEvent', 7, N'You received $[[CreditAmount]] from [[Name]]', 1, null, 0, 'SpiTech Wallet Credited','Finance/WalletCredit.cshtml',1,'You have received $[[CreditAmount]] from [[Name]]',1,N'Recibiste $[[CreditAmount]] de [[Name]]','Monedero SpiTech acreditado','Ha recibido $[[CreditAmount]] de [[Name]]'),
 (700, N'AdminCreditEvent',N'WalletCreditEvent', 7, N'Your Wallet is credited with $[[CreditAmount]] for [[TransactionDesc]]', 1, null, 0, 'SpiTech Wallet Credited','Finance/WalletCredit.cshtml',1,'Your Wallet is credited with $[[CreditAmount]] for [[TransactionDesc]]',1, N'A su Monedero se le acreditan $[[CreditAmount]] por [[TransactionDesc]]','Monedero SpiTech acreditado','A su Monedero se le acreditan $[[CreditAmount]] por [[TransactionDesc]]'),
 (700, N'AddCardEvent',N'WalletCreditEvent', 7, N'Congratulations, You have earned your 1st $5 bonus for downloading and Adding Payment Method SpiTech', 1, null, 0, 'SpiTech Wallet Credited','Finance/WalletCredit.cshtml',1,'Congratulations, You have earned your 1st $5 bonus for downloading and Adding Payment Method SpiTech',1,N'Felicitaciones, ha ganado su primer bono de $5 por descargar y agregar el método de pago SpiTech','Monedero SpiTech acreditado','Felicitaciones, ha ganado su primer bono de $5 por descargar y agregar el método de pago SpiTech'),
 (700,N'ACHTransaction'  , N'WalletCreditEvent', 7, N'Your Wallet is credited with $[[CreditAmount]] for paying at [[StoreName]]', 1, null, 0, 'SpiTech Wallet Credited','Finance/WalletCredit.cshtml',1,'Your Wallet is credited with $[[CreditAmount]] for paying at [[StoreName]]',1,N'A su billetera se le acreditan $[[CreditAmount]] por pagar en [[StoreName]]','Monedero SpiTech acreditado','A su billetera se le acreditan $[[CreditAmount]] por pagar en [[StoreName]]'),
 (700, N'CreditCardTransaction',N'WalletCreditEvent', 7, N'Your Wallet is credited with $[[CreditAmount]] for paying at [[StoreName]]', 1, null, 0, 'SpiTech Wallet Credited','Finance/WalletCredit.cshtml',1,'Your Wallet is credited with $[[CreditAmount]] for paying at [[StoreName]]',1,N'A su billetera se le acreditan $[[CreditAmount]] por pagar en [[StoreName]]', 'Monedero SpiTech acreditado','A su billetera se le acreditan $[[CreditAmount]] por pagar en [[StoreName]]'),
 (700, N'TransactionSequenceNo',N'WalletCreditEvent', 7, N'Congratulations, You�ve earned your $5 bonus for conducting [[TransactionCount]] transactions', 1, null, 0, 'SpiTech Wallet Credited','Finance/WalletCredit.cshtml',1,'Congratulations, You�ve earned your $5 bonus for conducting [[TransactionCount]] transactions',1,N'Felicitaciones, ha ganado su bono de $5 por realizar [[TransactionCount]] transacciones','Monedero SpiTech acreditado','Felicitaciones, ha ganado su bono de $5 por realizar [[TransactionCount]] transacciones'),

 (701,N'WalletDebitEvent'  , N'WalletDebitEvent', 7, N'Your Wallet is debited with $[[Amount]]', 1, null, 0, 'You Transferred from SpiTech Wallet','Finance/WalletDebit.cshtml',1,'Your Wallet is debited with $[[Amount]]',1,N'Su billetera se debita con $[[Amount]]','Transferiste desde SpiTech Wallet','Su billetera se debita con $[[Amount]]'),
 (701,N'WalletLinkUserTransferDebitEvent'  , N'WalletDebitEvent', 7, N'You Transferred $[[Amount]] to [[Name]]', 1, null, 0, 'You Transferred from SpiTech Wallet','Finance/WalletDebit.cshtml',1,'You have transferred $[[Amount]] to [[Name]] successfully.',1,N'Transferiste $[[Amount]] a [[Name]]','Transferiste desde SpiTech Wallet','Has transferido $[[Amount]] a [[Name]] con éxito.'), 
 (701, N'AdminDebitEvent',N'WalletDebitEvent', 7, N'Your Wallet is debited with $[[Amount]] for [[TransactionDesc]]', 1, null, 0, 'SpiTech Wallet Debited','Finance/WalletDebit.cshtml',1,'Your Wallet is debited with $[[Amount]] for [[TransactionDesc]]',1,N'Su Monedero se debita con $[[Amount]] por [[TransactionDesc]]','Monedero SpiTech debitado','Su Monedero se debita con $[[Amount]] por [[TransactionDesc]]'),
 (701,N'StoreWalletDebit'  , N'WalletDebitEvent', 7, N'You  have  redeemed $[[Amount]] cash reward against transaction on [[StoreName]].', 1, null, 0, 'You  have  redeemed wallet against transaction','',0,'You  have  redeemed $[[Amount]] cash reward against transaction on [[StoreName]].', 1,N'Has canjeado $[[Cantidad]] de recompensa en efectivo contra una transacción en [[StoreName]].','Has canjeado monedero por transacción','Has canjeado $[[Cantidad]] de recompensa en efectivo contra una transacción en [[StoreName]].'),

 (703,N'WalletVoidPaymentEvent'  , N'WalletVoidPaymentEvent', 7, N'Your SpiTech wallet amount has been refunded.', 1, null, 0, 'Your SpiTech wallet amount has been refunded','Finance/WalletVoidPayment.cshtml',1,'', 0,N'El monto de su billetera SpiTech ha sido reembolsado.','El monto de su billetera SpiTech ha sido reembolsado',''),
 (704,N'ExpiringWalletCreditEvent'  , N'ExpiringWalletCreditEvent', 7, N'Your SpiTech Wallet Credits are expiring soon.', 1, null, 0, 'Your SpiTech Wallet Credits are expiring soon','Finance/ExpiringWalletCredit.cshtml',1,'', 0,N'Los créditos de su billetera SpiTech expirarán pronto.','Los créditos de su billetera SpiTech caducan pronto',''), 
 
 
 (705,N'TransferRequestEvent'  , N'TransferRequestEvent', 7, N'[[FromName]] has requested a wallet transfer amount of $[[TransferRequestAmount]]', 1, null, 0, 'Wallet transfer request received','Finance/TransferRequest.cshtml',1,'[[FromName]] has requested a wallet transfer amount of $[[TransferRequestAmount]]',1,N'[[FromName]] ha solicitado un monto de transferencia de billetera de $[[TransferRequestAmount]]','Solicitud de transferencia de billetera recibida','[[FromName]] ha solicitado un monto de transferencia de billetera de $[[TransferRequestAmount]]'),
 (706,N'TransferRequestDeclinedEvent'  , N'TransferRequestDeclinedEvent', 7, N'[[ToName]] has declined your transfer request of $[[TransferRequestAmount]]', 1, null, 0, 'Your Wallet transfer request declined','Finance/TransferRequestDeclined.cshtml',1,'[[ToName]] has declined your transfer request of $[[TransferRequestAmount]]',1,N'[[ToName]] ha rechazado su solicitud de transferencia de $[[TransferRequestAmount]]','Su solicitud de transferencia de Wallet fue rechazada','[[ToName]] ha rechazado su solicitud de transferencia de $[[TransferRequestAmount]]'),

 
 (800,N'InvoiceSendEvent'  , N'InvoiceSendEvent', 8, N'Invoice Sent To [[UserName]]', 1, NULL, 0, N'Invoice Sent', N'Account/InvoiceSend.cshtml', 1, N'Invoice Payment Request Sent To [[ReceiverUserName]]', 1,'','',''),
 (801,N'InvoiceReceiveEvent'  , N'InvoiceReceiveEvent', 8, N'Invoice Received From [[UserName]]', 1, NULL, 0, N'Invoice Received', N'Account/InvoiceReceive.cshtml', 1, N'Invoice Payment Request Received From [[SenderUserName]]', 1,'','',''),
 (802,N'InvoiceCancelledEvent'  , N'InvoiceCancelledEvent', 8, N'Invoice Cancelled By [[SenderUserName]]', 0, NULL, 0, N'Invoice Cancelled', N'Account/InvoiceCancelled.cshtml', 1, N'Invoice Payment Request Cancelled By [[SenderUserName]]', 1,'','',''),
 (803,N'InvoiceRejectedEvent'  , N'InvoiceRejectedEvent', 8, N'Invoice Rejected By [[ReceiverUserName]]', 1, NULL, 0, N'Invoice Rejected', N'Account/InvoiceRejected.cshtml', 1, N'Invoice Payment Request Rejected By [[ReceiverUserName]]', 1,'','',''),
 (804,N'InvoicePaidEvent'  , N'InvoicePaidEvent', 8, N'Invoice Paid By [[ReceiverUserName]]', 1, NULL, 0, N'Invoice Paid', N'Account/InvoicePaid.cshtml', 1, N'Invoice Payment Done By [[ReceiverUserName]]', 1,'','','')
 GO
 
SET IDENTITY_INSERT [ActivityType] ON 
GO
INSERT INTO [ActivityType] ([Name],[ActivityTypeId])
VALUES 
        ('UserRegister', 1)
        ,('Login',2)
        ,('ForgotPassword', 3)
        ,('ChangePassword', 4)
        ,('UpdateProfile', 5)
        ,('LinkUser',6)
        ,('CreateClaim',7)
        ,('CreateRole',8)
        ,('DeleteUser',9)
        ,('RemoveLinkUser',10)
        ,('UnlockUser',11)
        ,('UpdateConsumerToBusiness',12)
        ,('UpdateMobileNo',13)
        ,('UpdatePermission',14)
        ,('UpdatePreferedLanguage',15)
        ,('UpdateRole',16)
        ,('UpdateUserDevice',17)
        ,('VerifyEmail',18)
        ,('VerifyMobile',19)
        ,('Logout', 20)
        ,('AddPaymentMethod', 21)
        ,('RemovePaymentMethod', 22)
        ,('AddNickName',23)
        ,('DeletePaymentMethod',24)
        ,('PreAuth',25)
        ,('ProcessPayment',26)
        ,('AddResellerConfig',27)
        ,('AddSaleAgentConfig',28)
        ,('AddStoreConfig',29)
        ,('UpdateMerchantNMI',30)
        ,('UpdatePreAuthPayment',31)
        ,('AddCompany',32)
        ,('AddStore',33)
        ,('CreateSaleagent',34)
        ,('CreateReseller',35)
        ,('UpdateCompany',36)
        ,('UpdateStore',37)
        ,('UpdateSaleAgent',38)
        ,('UpdateReseller',39)
        ,('CreateTransaction', 40)
        ,('CreateResellerFee',41)
        ,('CreateSaleAgentFee', 42)
        ,('CreateSettlement', 43)
        ,('CreateStoreBillingFee',44)
        ,('EODSettlement', 45)
        ,('GenerateResellerBilling', 46)
        ,('GenerateSaleAgentBilling', 47)
        ,('GenerateStoreBilling', 48)
        ,('ProcessPaymentResellerBilling', 49)
        ,('ProcessPaymentSaleAgentBilling', 50)
        ,('ProcessPaymentStoreBilling', 51)
        ,('ProcessResellerMonthlyInvoice', 52)
        ,('ProcessSaleAgentMonthlyInvoice', 53)
        ,('ProcessStoreMonthlyInvoice', 54)
        ,('ProcessStoreEodSettlement', 55)
        ,('ReconcileTransaction', 56)
        ,('UpdateResellerFee', 57)
        ,('UpdateSaleAgentFee', 58)
        ,('UpdateStoreBillingFee', 59)
        ,('UpdateTransaction', 60)
        ,('UpdateResellerNeedReview', 61)
        ,('UpdateResellerUnPaid', 62)
        ,('UpdateSaleAgentNeedReview', 63)
        ,('UpdateSaleAgentUnPaid', 64)
        ,('UpdateStoreBillingNeedReview', 65)
        ,('UpdateStoreBillingUnPaid', 66)
        ,('CreatePriceAdjustment', 67)
        ,('CreatePaymentInfo', 68)
        ,('CreateReceiptInfoLine', 69)
        ,('CreateSaleItem', 70)
        ,('ProcessBaiFile', 71)
        ,('UpdateEodUnpaid', 72)
        ,('UpdateEodNeedReview', 73)
        ,('AdminCredit', 74)
        ,('AdminDebit', 75)
        ,('WalletCredit', 76)
        ,('WalletDebit', 77)
		SET IDENTITY_INSERT [ActivityType] OFF
GO
