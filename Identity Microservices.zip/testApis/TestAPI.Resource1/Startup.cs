using IdentityServer4.AccessTokenValidation;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using PapiPay.ApplicationCore.Extensions;
using PapiPay.ApplicationCore.ServiceCollection;
using System;

namespace TestAPI.Resource1
{
    public class Startup
    {
        public const string Authentication_Scheme_Bearer = "Bearer";
        public const string Client_Id_Policy = "ClientIdPolicy";
        public const string Scope_UserStore_Api_Value = "UserStoreApi";
        public const string Scope_UserStore_Api_Text = "User Store Api";
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "TestAPI.Resource1", Version = "v1" });
                SwaggerGenSetup.Setup(c);
            });

            //services.AddAPIAuthentication(Configuration, "paymentapi");

            //services.AddAPIAuthentication(Configuration, "paymentapi").AddOAuth2Introspection("token", options =>
            //{
            //    options.Authority = Configuration.GetValue<string>("IdentityConfig:BaseUrl");

            //    // this maps to the API resource name and secret
            //    //options.ClientId = "resource1";
            //   // options.ClientSecret = "secret";
            //}); ;

            //services.AddAuthentication("Introspection")
            //// JWT tokens (default scheme)
            //.AddJwtBearer("Introspection", options =>
            //{
            //    options.Authority = Configuration["IdentityConfig:BaseUrl"];
            //    options.Audience = "paymentapi";

            //    options.TokenValidationParameters.ValidTypes = new[] { "at+jwt" };

            //    // if token does not contain a dot, it is a reference token
            //    options.ForwardDefaultSelector = SchemeSelector;
            //})

            //// reference tokens
            //.AddOAuth2Introspection("introspection", options =>
            //{
            //    options.Authority = Configuration["IdentityConfig:BaseUrl"];

            //    options.ClientId = "paymentapi";
            //    options.ClientSecret = "h$Je%Ah4m733Jtz8";
            //});
            services.AddAuthentication(IdentityServerAuthenticationDefaults.AuthenticationScheme)
                .AddIdentityServerAuthentication(options =>
                {
                    options.Authority = Configuration["IdentityConfig:BaseUrl"];
                    options.RequireHttpsMetadata = false;
                    options.ApiName = "paymentapi";
                    options.ApiSecret = "h$Je%Ah4m733Jtz8";
                    //options.SupportedTokens = SupportedTokens.Reference;
                    //options.SupportedTokens = SupportedTokens.Jwt;
                });

            //services.AddAuthorization(options =>
            //{
            //    options.AddPolicy("ApiScope", policy =>
            //    {
            //        //policy.RequireAuthenticatedUser();
            //        policy.RequireClaim("scope", "userstoreapi");
            //    });
            //});
        }

        public static string SchemeSelector(HttpContext context)
        {
            return "Introspection";
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "TestAPI.Resource1 v1"));
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
