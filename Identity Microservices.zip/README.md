
# Introduction 

Identity Server

https://localhost:5002/.well-known/openid-configuration

# Refresh Token

https://identity.papipayllc.com/connect/token
x-www-form-urlencorded
client_id:papipay_testportal
client_secret:jhXLaR&8=v5q5*Ve
refresh_token:E85089C08A824B0EB68AF757D84FCCA1726A9F6A4C271FBBC9B206979DA54D8D
grant_type:refresh_token
