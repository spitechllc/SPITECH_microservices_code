
SET XACT_ABORT ON;  
Begin Transaction;


set identity_insert dbo.Clients on
go
INSERT INTO dbo.Clients
 (Id, Enabled, ClientId, ProtocolType, RequireClientSecret, ClientName, Description, ClientUri, LogoUri, RequireConsent, AllowRememberConsent, AlwaysIncludeUserClaimsInIdToken, RequirePkce, AllowPlainTextPkce, RequireRequestObject, AllowAccessTokensViaBrowser, FrontChannelLogoutUri, FrontChannelLogoutSessionRequired, BackChannelLogoutUri, BackChannelLogoutSessionRequired, AllowOfflineAccess, IdentityTokenLifetime, AllowedIdentityTokenSigningAlgorithms, AccessTokenLifetime, AuthorizationCodeLifetime, ConsentLifetime, AbsoluteRefreshTokenLifetime, SlidingRefreshTokenLifetime, RefreshTokenUsage, UpdateAccessTokenClaimsOnRefresh, RefreshTokenExpiration, AccessTokenType, EnableLocalLogin, IncludeJwtId, AlwaysSendClientClaims, ClientClaimsPrefix, PairWiseSubjectSalt, Created, Updated, LastAccessed, UserSsoLifetime, UserCodeType, DeviceCodeLifetime, NonEditable)
 VALUES
(10, 1, N'papipay_signalr_test_local', N'oidc', 1, N'Papipay SignalR Test Local Portal Client', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 0, NULL, 1, NULL, 1, 1, 300, NULL, 86400, 300, NULL, 
2592000, 1296000, 1, 0, 1, 1, 1, 1, 0, N'client_', NULL, Getutcdate(), NULL, NULL, NULL, NULL, 300, 0),
(11, 1, N'papipay_signalr_test', N'oidc', 1, N'Papipay SignalR Test Portal Client', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 0, NULL, 1, NULL, 1, 1, 300, NULL, 86400, 300, NULL,
2592000, 1296000, 1, 0, 1, 1, 1, 1, 0, N'client_', NULL, Getutcdate(), NULL, NULL, NULL, NULL, 300, 0),
(12, 1, N'papipay_portal_local', N'oidc', 0, N'Papipay Local Development Portal Client', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 1, NULL, 1, NULL, 1, 0, 300, NULL, 86400, 300, NULL,
2592000, 1296000, 1, 0, 1, 1, 1, 1, 0, N'client_', NULL, Getutcdate(), NULL, NULL, NULL, NULL, 300, 0),
(13, 1, N'papipay_identity_test_local', N'oidc', 1, N'Papipay Identity Test Local Portal Client', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 0, NULL, 1, NULL, 1, 1, 300, NULL, 86400, 300, NULL, 
2592000, 1296000, 1, 0, 1, 1, 1, 1, 0, N'client_', NULL, Getutcdate(), NULL, NULL, NULL, NULL, 300, 0);
  
go
set identity_insert dbo.Clients off
go



set identity_insert dbo.ClientGrantTypes on
go
INSERT INTO dbo.ClientGrantTypes(Id, GrantType, ClientId)
VALUES
(10, N'authorization_code', 10),
(11, N'authorization_code', 11),
(12, N'authorization_code', 12),
(13, N'authorization_code', 13);
go
set identity_insert dbo.ClientGrantTypes off
go


set identity_insert dbo.ClientPostLogoutRedirectUris on
go
INSERT INTO dbo.ClientPostLogoutRedirectUris(Id, PostLogoutRedirectUri, ClientId)
VALUES
(10, N'https://localhost:5015/', 10),
(11, N'https://20.80.90.3:5015/', 11),
(12, N'http://localhost:4019', 12),
(13, N'https://localhost:4020/', 13);
go
set identity_insert dbo.ClientPostLogoutRedirectUris off
go



set identity_insert dbo.ClientRedirectUris on
go
INSERT INTO dbo.ClientRedirectUris(Id, RedirectUri, ClientId)
VALUES
(10, N'https://localhost:5015/signin-oidc', 10),
(11, N'https://20.80.90.3:5015/signin-oidc', 11),
(12, N'http://localhost:4019', 12),
(13, N'https://localhost:5020/signin-oidc', 13);
go
set identity_insert dbo.ClientRedirectUris off
go

--SELECT 1/0;
go
set identity_insert dbo.ClientScopes on
go

INSERT INTO dbo.ClientScopes(Id, Scope, ClientId)
VALUES

(1001, N'profile', 			10),
(1002, N'openid', 			10),
(1003, N'transactionapi', 	10),
(1004, N'mppaapi', 			10),
(1005, N'paymentapi', 		10),
(1006, N'userstoreapi', 	10),
(1007, N'IdentityServerApi',10),
(1008, N'helpsupportapi', 	10),
(1009, N'marketingapi', 	10),
(1010, N'financeapi', 		10),
(1011, N'accountapi', 		10),
(1012, N'notificationapi', 	10),
(1013, N'reportapi', 		10),

(1101, N'profile', 			11),
(1102, N'openid', 			11),
(1103, N'transactionapi', 	11),
(1104, N'mppaapi', 			11),
(1105, N'paymentapi', 		11),
(1106, N'userstoreapi', 	11),
(1107, N'IdentityServerApi',11),
(1108, N'helpsupportapi', 	11),
(1109, N'marketingapi', 	11),
(1110, N'financeapi', 		11),
(1111, N'accountapi', 		11),
(1112, N'notificationapi', 	11),
(1113, N'reportapi', 		11),

(1201, N'profile', 			12),
(1202, N'openid', 			12),
(1203, N'transactionapi', 	12),
(1204, N'mppaapi', 			12),
(1205, N'paymentapi', 		12),
(1206, N'userstoreapi', 	12),
(1207, N'IdentityServerApi',12),
(1208, N'helpsupportapi', 	12),
(1209, N'marketingapi', 	12),
(1210, N'financeapi', 		12),
(1211, N'accountapi', 		12),
(1212, N'notificationapi', 	12),
(1213, N'reportapi', 		12),


(1301, N'profile', 			13),
(1302, N'openid', 			13),
(1303, N'transactionapi', 	13),
(1304, N'mppaapi', 			13),
(1305, N'paymentapi', 		13),
(1306, N'userstoreapi', 	13),
(1307, N'IdentityServerApi',13),
(1308, N'helpsupportapi', 	13),
(1309, N'marketingapi', 	13),
(1310, N'financeapi', 		13),
(1311, N'accountapi', 		13),
(1312, N'notificationapi', 	13),
(1313, N'reportapi', 		13); 
go
set identity_insert dbo.ClientScopes off
go


set identity_insert dbo.ClientSecrets on
go
INSERT INTO dbo.ClientSecrets (Id, ClientId, Description, Value, Expiration, Type, Created)
VALUES
(10, 10, NULL, N'0WpMUCZpatFoW2e8izLYxUUbhhckiURFjfL/AHs5m3o=', NULL, N'SharedSecret', Getutcdate()),
(11, 11, NULL, N'0WpMUCZpatFoW2e8izLYxUUbhhckiURFjfL/AHs5m3o=', NULL, N'SharedSecret', Getutcdate()),
(12, 12, NULL, N'0WpMUCZpatFoW2e8izLYxUUbhhckiURFjfL/AHs5m3o=', NULL, N'SharedSecret', Getutcdate()),
(13, 13, NULL, N'0WpMUCZpatFoW2e8izLYxUUbhhckiURFjfL/AHs5m3o=', NULL, N'SharedSecret', Getutcdate());
go
set identity_insert dbo.ClientSecrets off
go

 IF (XACT_STATE()) = -1  
    BEGIN  
        PRINT N'The transaction is in an uncommittable state. Rolling back transaction.'  
        ROLLBACK TRANSACTION;  
    END;  
  
    -- Test whether the transaction is committable.
    -- You may want to commit a transaction in a catch block if you want to commit changes to statements that ran prior to the error.
 IF (XACT_STATE()) = 1  
    BEGIN  
        PRINT N'The transaction is committable. Committing transaction.'  
        COMMIT TRANSACTION;     
    END; 