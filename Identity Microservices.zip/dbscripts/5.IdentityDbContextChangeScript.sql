IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
GO

ALTER TABLE [UserProfile] ADD [IsLoggedIn] bit NULL;
GO

ALTER TABLE [UserProfile] ADD [LastLogin] datetime2 NULL ;
GO

ALTER TABLE [UserProfile] ADD [LastLoginIP] nvarchar(max) NULL;
GO

CREATE TABLE [UserLoginLog] (
    [UserLoginLogsId] uniqueidentifier NOT NULL,
    [UserId] int NOT NULL,
    [LoginIp] nvarchar(50) NULL,
    [LoginDate] datetime2 NOT NULL,
    [IsActive] bit NOT NULL,
    [CreatedOn] datetime2 NULL,
    [CreatedBy] nvarchar(max) NULL,
    [UpdatedOn] datetime2 NULL,
    [UpdatedBy] nvarchar(max) NULL,
    CONSTRAINT [PK_UserLoginLog] PRIMARY KEY ([UserLoginLogsId])
);
GO

CREATE INDEX [IX_UserLoginLog_UserId] ON [UserLoginLog] ([UserId]);
GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20221107120745_AddedUserLoginLog', N'5.0.9');
GO

COMMIT;
GO

----------Start script 21 nov 22--------------------
IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO


BEGIN TRANSACTION;
GO

ALTER TABLE [UserLoginLog] ADD [InvalidLogin] bit NOT NULL DEFAULT CAST(0 AS bit);
GO

ALTER TABLE [UserLoginLog] ADD [InvalidLoginCount] bit NOT NULL DEFAULT CAST(0 AS bit);
GO

CREATE TABLE [UserPasswordChangeLog] (
    [UserPasswordChangeLogId] uniqueidentifier NOT NULL,
    [UserId] int NOT NULL,
    [OldPassword] nvarchar(50) NULL,
    [NewPassword] nvarchar(50) NULL,
    [ChangeDate] datetime2 NOT NULL,
    [IsWrongAttempt] bit NOT NULL,
    [IsActive] bit NOT NULL,
    [CreatedOn] datetime2 NULL,
    [CreatedBy] nvarchar(max) NULL,
    [UpdatedOn] datetime2 NULL,
    [UpdatedBy] nvarchar(max) NULL,
    CONSTRAINT [PK_UserPasswordChangeLog] PRIMARY KEY ([UserPasswordChangeLogId])
);
GO

CREATE INDEX [IX_UserPasswordChangeLog_UserId] ON [UserPasswordChangeLog] ([UserId]);
GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20221121091018_AddedPasswordChangeLog', N'5.0.8');
GO

COMMIT;
GO


----------------------------end script 21 nov 22-----------------------------------

-----------------------Start Script 9 dec 22----------------------------

IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO



BEGIN TRANSACTION;
GO
INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20221212121931_RoleIdClaimIdDataTypeChange', N'5.0.8');
GO
DROP  TABLE [Permission] 
GO
DROP TABLE [Claim] 
GO
ALTER TABLE [dbo].[UserRole] DROP CONSTRAINT [FK_UserRole_Role_RoleId]
GO
ALTER TABLE [dbo].[UserRole] DROP CONSTRAINT [PK_UserRole]
GO
ALTER TABLE [dbo].[Role] DROP CONSTRAINT [PK_Role]
GO

ALTER TABLE [UserRole] ALTER COLUMN [RoleId] nvarchar(100) NOT NULL;
GO

ALTER TABLE [Role] ALTER COLUMN [RoleId] nvarchar(100) NOT NULL;
GO


ALTER TABLE [dbo].[Role] ADD CONSTRAINT [PK_Role] PRIMARY KEY CLUSTERED 
(
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
GO

ALTER TABLE [dbo].[UserRole] ADD CONSTRAINT [PK_UserRole] PRIMARY KEY CLUSTERED ([RoleId] ASC,[UserId] ASC)

ALTER TABLE [dbo].[UserRole]  WITH NOCHECK ADD  CONSTRAINT [FK_UserRole_Role_RoleId] FOREIGN KEY([RoleId])
REFERENCES [dbo].[Role] ([RoleId])
GO



CREATE TABLE [Claim] (
    [ClaimId] nvarchar(100) NOT NULL,
    [ClaimName] nvarchar(256) NOT NULL,
	[DisplayOrder] int NULL,
    [IsActive] bit NOT NULL DEFAULT CAST(1 AS bit),
    [CreatedOn] datetime2 NULL,
    [CreatedBy] nvarchar(256) NULL,
    [UpdatedOn] datetime2 NULL,
    [UpdatedBy] nvarchar(256) NULL,
    CONSTRAINT [PK_Claim] PRIMARY KEY ([ClaimId])
);
GO

CREATE TABLE [Permission] (
    [RoleId] nvarchar(100) NOT NULL,
    [ClaimId] nvarchar(100) NOT NULL,
    [IsActive] bit NOT NULL DEFAULT CAST(1 AS bit),
    [CreatedOn] datetime2 NULL,
    [CreatedBy] nvarchar(256) NULL,
    [UpdatedOn] datetime2 NULL,
    [UpdatedBy] nvarchar(256) NULL,
    CONSTRAINT [PK_Permission] PRIMARY KEY ([RoleId], [ClaimId]),
    CONSTRAINT [FK_Permission_Claim_ClaimId] FOREIGN KEY ([ClaimId]) REFERENCES [Claim] ([ClaimId]) ON DELETE NO ACTION,
    CONSTRAINT [FK_Permission_Role_RoleId] FOREIGN KEY ([RoleId]) REFERENCES [Role] ([RoleId]) ON DELETE NO ACTION);
	GO

update [UserRole] set RoleId='SuperAdmin' where roleid in('1','9')
update [UserRole] set RoleId='StoreOwner' where roleid='2'
update [UserRole] set RoleId='StoreRegional ' where roleid='3'
update [UserRole] set RoleId='StoreSupervisor' where roleid='4'
update [UserRole] set RoleId='StoreManager' where roleid='5'
update [UserRole] set RoleId='SupportL1' where roleid='6'
update [UserRole] set RoleId='SupportL2 ' where roleid='7'
update [UserRole] set RoleId='SupportL3' where roleid='8'


COMMIT;
GO
-------------------------------end script 9 dec 22--------------------------------------
-----------------------start script 13 dec 22-----------------------------------------

BEGIN TRANSACTION;
GO

CREATE TABLE [dbo].[APIResourcePermission](
	[APIResourceId] [nvarchar](100) NOT NULL,
	[ClaimId] [nvarchar](100) NOT NULL,
	[ClientId] [nvarchar](100) NOT NULL,
	[AllowAnonymous] [bit] NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedOn] [datetime2](7) NULL,
	[CreatedBy] [nvarchar](256) NULL,
	[UpdatedOn] [datetime2](7) NULL,
	[UpdatedBy] [nvarchar](256) NULL,
 CONSTRAINT [PK_APIResourcePermission] PRIMARY KEY CLUSTERED 
(
	[APIResourceId] ASC,
	[ClaimId] ASC,
	[ClientId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[APIResourcePermission] ADD  CONSTRAINT [DF__APIResour__IsAct__56E8E7AB]  DEFAULT (CONVERT([bit],(1))) FOR [IsActive]
GO


INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20221213044355_APIResourcePermissionEntity', N'5.0.8');
GO

COMMIT;
GO
----------------------------end script 13 dec 22-------------------------
----------------------------Start script 9 Jan 2023-------------------------
create index IX_APIResourcePermission_ClaimId on APIResourcePermission(ClaimId);
go
alter table CodeVerification alter column
  Code nvarchar(50);
go
alter table DeletedUser alter column
  ReasonforDeletion nvarchar(500);
go
alter table UserProfile add
  default (CONVERT([bit],(0))) for IsLoggedIn,
  default (GetUTCDATE()) for LastLogin;
go
----------------------------End script 9 Jan 2023-------------------------


----------------------------Start script 2 Aug 2023-------------------------
GO

CREATE TABLE [ConsumerCase] (
    [ConsumerCaseId] int NOT NULL IDENTITY,
    [UserId] int NOT NULL,
    [Subject] nvarchar(max) NULL,
    [Description] nvarchar(max) NULL,
    [Reason] nvarchar(max) NULL,
    [Status] nvarchar(max) NULL,
    [ClosedDate] datetime2 NOT NULL,
    [IsEscalated] bit NOT NULL,
    [Comments] nvarchar(max) NULL,
    [LastModifiedById] int NULL,
    [IsActive] bit NOT NULL,
    [CreatedOn] datetime2 NULL,
    [CreatedBy] nvarchar(max) NULL,
    [UpdatedOn] datetime2 NULL,
    [UpdatedBy] nvarchar(max) NULL,
    CONSTRAINT [PK_ConsumerCase] PRIMARY KEY ([ConsumerCaseId])
);
GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20230802063644_ConsumerCase entity added', N'5.0.8');
GO

----------------------------End script 2 Aug 2023-------------------------

