----------Start script 21 nov 22--------------------
BEGIN TRANSACTION;
GO
INSERT INTO [dbo].[ApiResourceSecrets]
           ([ApiResourceId]
           ,[Description]
           ,[Value]
           ,[Expiration]
           ,[Type]
           ,[Created])
SELECT [Id]
      ,[Name]
      ,'RYNbytVE0EkEVKSAPWReCABo48gDRwQm88TcOAOgH+E='
      ,null
      ,'SharedSecret'
      ,GETUTCDATE()
  FROM [dbo].[ApiResources]

 GO
 update Clients set AccessTokenType=1

GO

COMMIT;
GO
-------end script 21 nov 22-----------------------
-----start script 03feb2023-------------------
INSERT INTO dbo.APIResourcePermission(APIResourceId, ClaimId, ClientId, AllowAnonymous, IsActive)
VALUES 
(N'UserStoreApi_StoreCategory_Get', N'StoreMenu_StoreTab_Edit', N'', 0, 1)
,(N'UserStoreApi_StoreCategory_Get', N'StoreMenu_StoreTab_View', N'', 0, 1)
,(N'IdentityServerApi_AccountUsers_GetUsersByRole', N'', N'papipay_m2m', 0, 1)
----------end script 03feb2023-----------------------------------

------------------start script 02Mar2023------------------------
INSERT INTO dbo.APIResourcePermission(APIResourceId, ClaimId, ClientId, AllowAnonymous, IsActive)
VALUES
(N'Accountapi_InvoiceTransaction_InvoiceTransactionList', N'', N'papipay_businessmobile', 0, 1)

---------------------end script 02Mar2023-----------------------------------


 --------------------------------------start script 18 may 23---------------------

 INSERT [dbo].[Claim] ([ClaimId], [ClaimName], [DisplayOrder], [IsActive], [CreatedOn], [CreatedBy], [UpdatedOn], [UpdatedBy]) VALUES
(N'NachaReportMenu', N'NachaReportMenu Page View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NachaReportMenu_DailyProcessingActivity', N'NachaReportMenu Page DailyProcessingActivity', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NachaReportMenu_DailyProcessingActivity_Export', N'NachaReportMenu Page DailyProcessingActivity Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NachaReportMenu_DailyReturnActivity', N'NachaReportMenu Page ReturnActivity', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NachaReportMenu_DailyReturnActivity_Export', N'NachaReportMenu Page ReturnActivity Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NachaReportMenu_AchTransactionReport', N'NachaReportMenu AchTransactionReport', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NachaReportMenu_AchTransactionReport_Export', N'NachaReportMenu AchTransactionReport Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NachaReportMenu_AchReturnReport', N'NachaReportMenu AchReturnReport', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NachaReportMenu_AchReturnReport_Export', N'NachaReportMenu AchReturnReport Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)


INSERT INTO dbo.Permission ([RoleId],[ClaimId],[IsActive],[CreatedOn])
values
('SuperAdmin','NachaReportMenu',1,Getutcdate())
,('SuperAdmin','NachaReportMenu_DailyProcessingActivity',1,Getutcdate())
,('SuperAdmin','NachaReportMenu_DailyProcessingActivity_Export',1,Getutcdate())
,('SuperAdmin','NachaReportMenu_DailyReturnActivity',1,Getutcdate())
,('SuperAdmin','NachaReportMenu_DailyReturnActivity_Export',1,Getutcdate())
,('SuperAdmin','NachaReportMenu_AchTransactionReport',1,Getutcdate())
,('SuperAdmin','NachaReportMenu_AchTransactionReport_Export',1,Getutcdate())
,('SuperAdmin','NachaReportMenu_AchReturnReport',1,Getutcdate())
,('SuperAdmin','NachaReportMenu_AchReturnReport_Export',1,Getutcdate())




INSERT INTO dbo.APIResourcePermission(APIResourceId, ClaimId, ClientId, AllowAnonymous, IsActive)
VALUES
(N'Transactionapi_NachaReports_NachaDailyProcessingReport', N'NachaReportMenu_DailyProcessingActivity', N' ', 0, 1)
,(N'Transactionapi_NachaReports_NachaDailyProcessingReport', N'NachaReportMenu_DailyProcessingActivity_Export', N' ', 0, 1)
,(N'Transactionapi_NachaReports_NachaDailyReturnReport', N'NachaReportMenu_DailyReturnActivity', N' ', 0, 1)
,(N'Transactionapi_NachaReports_NachaDailyReturnReport', N'NachaReportMenu_DailyReturnActivity_Export', N' ', 0, 1)
,(N'Transactionapi_NachaReports_ACHTransactionReport', N'NachaReportMenu_AchTransactionReport', N' ', 0, 1)
,(N'Transactionapi_NachaReports_ACHTransactionReport', N'NachaReportMenu_AchTransactionReport_Export', N' ', 0, 1)
,(N'Transactionapi_NachaReports_ACHReturnReport', N'NachaReportMenu_AchReturnReport', N' ', 0, 1)
,(N'Transactionapi_NachaReports_ACHReturnReport', N'NachaReportMenu_AchReturnReport_Export', N' ', 0, 1)
,(N'Transactionapi_DashBoard_TransactionDetails', N'DashboardView', N' ', 0, 1)
,(N'UserStoreApi_Stores_GetCompaniesByStoreId', N'', N'papipay_m2m', 0, 1)

------------------------end script 18 may 23---------------------------------


------------------------start script 8 june 23---------------------------------
INSERT INTO dbo.APIResourcePermission(APIResourceId, ClaimId, ClientId, AllowAnonymous, IsActive)
VALUES
(N'Transactionapi_DashBoard_RewardDetails', N'DashboardView', N' ', 0, 1)
,(N'Transactionapi_DashBoard_ConsumersDetails', N'DashboardView', N' ', 0, 1)
,(N'Transactionapi_DashBoard_SaleItemsDetails', N'DashboardView', N' ', 0, 1)
,(N'Transactionapi_DashBoard_FailedTransactionDetails', N'DashboardView', N' ', 0, 1)
,(N'UserStoreApi_Stores_ForDashboard', N'', N'papipay_m2m', 0, 1)
------------------------end script 8 june 23---------------------------------

------------------------start script 27 june 23---------------------------------

INSERT [dbo].[Claim] ([ClaimId], [ClaimName], [DisplayOrder], [IsActive], [CreatedOn], [CreatedBy], [UpdatedOn], [UpdatedBy])
VALUES 
(N'getStoreGroup', N'getStoreGroup', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'addStoreGroup', N'addStoreGroup', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'updateStoreGroup', N'updateStoreGroup', 1, 1, GetUtcDate(), NULL, NULL, NULL)


INSERT INTO dbo.Permission ([RoleId],[ClaimId],[IsActive],[CreatedOn])
values
('SuperAdmin','getStoreGroup',1,Getutcdate())
,('SuperAdmin','addStoreGroup',1,Getutcdate())
,('SuperAdmin','updateStoreGroup',1,Getutcdate())


INSERT INTO dbo.APIResourcePermission(APIResourceId, ClaimId, ClientId, AllowAnonymous, IsActive)
VALUES 
(N'UserStoreApi_StoreGroup_Get', N'getStoreGroup', N'', 0, 1)
,(N'UserStoreApi_StoreGroup_StoreGroupAutoComplete', N'getStoreGroup', N'', 0, 1)
,(N'UserStoreApi_StoreGroup_Post', N'addStoreGroup', N'', 0, 1)
,(N'UserStoreApi_StoreGroup_Patch', N'updateStoreGroup', N'', 0, 1)


------------------------end script 27 june 23---------------------------------


------------------------start script 12 july 23---------------------------------

INSERT [dbo].[Claim] ([ClaimId], [ClaimName], [DisplayOrder], [IsActive], [CreatedOn], [CreatedBy], [UpdatedOn], [UpdatedBy]) VALUES
(N'StoreExcelData', N'StoreExcelData Page', 1, 1, GetUtcDate(), NULL, NULL, NULL)

INSERT INTO dbo.Permission ([RoleId],[ClaimId],[IsActive],[CreatedOn])
values
('SuperAdmin','StoreExcelData',1,Getutcdate())

INSERT INTO dbo.APIResourcePermission(APIResourceId, ClaimId, ClientId, AllowAnonymous, IsActive)
VALUES
(N'UserStoreApi_Stores_ProcessStoreExcelData', N'StoreExcelData', N' ', 0, 1)
,(N'UserStoreApi_Stores_SubmitStoreExcelData', N'StoreExcelData', N' ', 0, 1)
,(N'Paymentapi_StoreConfig_Post', N'', N'papipay_m2m', 0, 1)


------------------------end script 12 july 23---------------------------------

------------------------start script 18 july 23---------------------------------

INSERT [dbo].[Claim] ([ClaimId], [ClaimName], [DisplayOrder], [IsActive], [CreatedOn], [CreatedBy], [UpdatedOn], [UpdatedBy]) VALUES
(N'InhouseAccount', N'InhouseAccount Page', 1, 1, GetUtcDate(), NULL, NULL, NULL)

INSERT INTO dbo.Permission ([RoleId],[ClaimId],[IsActive],[CreatedOn])
values
('SuperAdmin','InhouseAccount',1,Getutcdate())

INSERT INTO dbo.APIResourcePermission(APIResourceId, ClaimId, ClientId, AllowAnonymous, IsActive)
VALUES
(N'Paymentapi_InhouseAccount_InhouseAccount', N'InhouseAccount', N' ', 0, 1)
,(N'Paymentapi_InhouseAccount_GetInhouseAccount', N'InhouseAccount', N' ', 0, 1)
,(N'Paymentapi_InhouseAccount_GetInhouseAccountById', N'InhouseAccount', N' ', 0, 1)
,(N'Paymentapi_InhouseAccount_RequestInhouseAccountApproval', N'InhouseAccount', N' ', 0, 1)
,(N'Paymentapi_InhouseAccount_ApproveInhouseAccount', N'InhouseAccount', N' ', 0, 1)

------------------------end script 18 july 23---------------------------------

------------------------start script 19 july 23---------------------------------
INSERT INTO dbo.APIResourcePermission(APIResourceId, ClaimId, ClientId, AllowAnonymous, IsActive)
VALUES (N'ConsumersRewardDetailsForDashBoard', N'', N'papipay_m2m', 0, 1)
------------------------end script 19 july 23---------------------------------

------------------------Start script 09 Aug 23---------------------------------
ALTER TABLE [UserProfile] ADD [Gender] nvarchar(1) NULL DEFAULT N'';
ALTER TABLE [DeletedUserProfile] ADD [Gender] nvarchar(1) NULL DEFAULT N'';

------------------------end script 09 Aug 23---------------------------------

------------------------Start script 26 Sep 23---------------------------------
if not exists(select count(*) from APIResourcePermission where APIResourceId='IdentityServerApi_AccountUsers_GetUserListForProfile')
begin
	insert into APIResourcePermission(APIResourceId,ClaimId,ClientId,AllowAnonymous,IsActive,CreatedOn) 
	values('IdentityServerApi_AccountUsers_GetUserListForProfile','','papipay_m2m',0,1,GETDATE())
end


if not exists(select count(*) from APIResourcePermission where APIResourceId='Paymentapi_GetUserPaymentMethod_UserId')
begin
	insert into APIResourcePermission(APIResourceId,ClaimId,ClientId,AllowAnonymous,IsActive,CreatedOn) 
   values('Paymentapi_GetUserPaymentMethod_UserId','ConsumerProfileMenu_Edit_CashRewardTab_View','',0,1,GETDATE())	
end

------------------------end script 26 Sep 23---------------------------------


------------------------Start script 11 Oct 23---------------------------------

insert into APIResourcePermission(APIResourceId,ClaimId,ClientId,AllowAnonymous,IsActive,CreatedOn) 
values('IdentityServerApi_AccountUsers_GetAllUserWithMOP','ConsumerProfileMenu','',0,1,GETDATE())


insert into APIResourcePermission(APIResourceId,ClaimId,ClientId,AllowAnonymous,IsActive,CreatedOn) 
values('Paymentapi_UserPaymentMethod_GetAllUserMOP','','papipay_m2m',0,1,GETDATE())
------------------------Start script 11 Oct 23---------------------------------

/****** Object:  Table [dbo].[TenantMaster]    Script Date: 29-01-2024 11:55:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TenantMaster](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[TenantName] [nvarchar](50) NULL,
	[IsActive] [bit] NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[UpdatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[TenantMaster] ON 
GO
INSERT [dbo].[TenantMaster] ([ID], [TenantName], [IsActive], [CreatedOn], [CreatedBy], [UpdatedOn], [UpdatedBy]) VALUES (1, N'PapiPay', 1, CAST(N'2023-12-27T11:09:49.097' AS DateTime), NULL, CAST(N'2023-12-27T11:09:59.003' AS DateTime), NULL)
GO
INSERT [dbo].[TenantMaster] ([ID], [TenantName], [IsActive], [CreatedOn], [CreatedBy], [UpdatedOn], [UpdatedBy]) VALUES (2, N'Velocity', 1, CAST(N'2023-12-27T11:09:49.097' AS DateTime), NULL, CAST(N'2023-12-27T11:09:59.003' AS DateTime), NULL)
GO
INSERT [dbo].[TenantMaster] ([ID], [TenantName], [IsActive], [CreatedOn], [CreatedBy], [UpdatedOn], [UpdatedBy]) VALUES (3, N'Verifone', 1, CAST(N'2023-12-27T11:09:49.097' AS DateTime), NULL, CAST(N'2023-12-27T11:09:59.003' AS DateTime), NULL)
GO
INSERT [dbo].[TenantMaster] ([ID], [TenantName], [IsActive], [CreatedOn], [CreatedBy], [UpdatedOn], [UpdatedBy]) VALUES (4, N'THEStation', 1, CAST(N'2023-12-27T11:09:49.097' AS DateTime), NULL, CAST(N'2023-12-27T11:09:59.003' AS DateTime), NULL)
GO
SET IDENTITY_INSERT [dbo].[TenantMaster] OFF
GO



/****** Object:  Table [dbo].[UserTenantMapping]    Script Date: 29-01-2024 11:27:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UserTenantMapping](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NULL,
	[TenantId] [int] NULL,
	[IsActive] [bit] NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[UpdatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
