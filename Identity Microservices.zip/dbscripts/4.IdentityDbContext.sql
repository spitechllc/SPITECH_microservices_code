IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
GO

CREATE TABLE [Claim] (
    [ClaimId] int NOT NULL,
    [ClaimName] nvarchar(256) NOT NULL,
    [IsActive] bit NOT NULL DEFAULT CAST(1 AS bit),
    [CreatedOn] datetime2 NULL,
    [CreatedBy] nvarchar(256) NULL,
    [UpdatedOn] datetime2 NULL,
    [UpdatedBy] nvarchar(256) NULL,
    CONSTRAINT [PK_Claim] PRIMARY KEY ([ClaimId])
);
GO

CREATE TABLE [CodeVerification] (
    [CodeVerificationId] int NOT NULL IDENTITY,
    [CodeType] int NOT NULL,
    [Code] nvarchar(50) NULL,
    [UserId] int NOT NULL,
    [GeneratedDate] datetime2 NOT NULL,
    [VerifyDate] datetime2 NULL,
    [ExpiryDate] datetime2 NOT NULL,
    [Receiver] nvarchar(100) NULL,
    [IsActive] bit NOT NULL DEFAULT CAST(1 AS bit),
    [CreatedOn] datetime2 NULL,
    [CreatedBy] nvarchar(256) NULL,
    [UpdatedOn] datetime2 NULL,
    [UpdatedBy] nvarchar(256) NULL,
    CONSTRAINT [PK_CodeVerification] PRIMARY KEY ([CodeVerificationId])
);
GO

CREATE TABLE [DeletedUser] (
    [UserId] int NOT NULL,
    [UserName] nvarchar(50) NOT NULL,
    [EnrolledBusinessUser] bit NOT NULL,
    [PasswordHash] nvarchar(256) NULL,
    [UserTypeId] int NOT NULL,
    [FirstName] nvarchar(50) NOT NULL,
    [LastName] nvarchar(50) NOT NULL,
    [Email] nvarchar(100) NULL,
    [MobileCountryCode] nvarchar(10) NULL,
    [MobileNumber] nvarchar(20) NULL,
    [EmailConfirmed] bit NOT NULL,
    [MobileConfirmed] bit NOT NULL,
    [AccessFailedCount] int NOT NULL,
    [Lockout] bit NOT NULL,
    [PreferedLanguage] nvarchar(20) NULL,
    [LastTimeAccess] datetime2 NULL,
    [DOB] datetime2 NULL,
    [ReasonforDeletion] nvarchar(max) NULL,
    [IsActive] bit NOT NULL,
    [CreatedOn] datetime2 NULL,
    [CreatedBy] nvarchar(256) NULL,
    [UpdatedOn] datetime2 NULL,
    [UpdatedBy] nvarchar(256) NULL,
    CONSTRAINT [PK_DeletedUser] PRIMARY KEY ([UserId])
);
GO

CREATE TABLE [RoleType] (
    [RoleTypeId] int NOT NULL,
    [RoleTypeName] nvarchar(100) NOT NULL,
    [IsActive] bit NOT NULL DEFAULT CAST(1 AS bit),
    [CreatedOn] datetime2 NULL,
    [CreatedBy] nvarchar(256) NULL,
    [UpdatedOn] datetime2 NULL,
    [UpdatedBy] nvarchar(256) NULL,
    CONSTRAINT [PK_RoleType] PRIMARY KEY ([RoleTypeId])
);
GO

CREATE TABLE [UserType] (
    [UserTypeId] int NOT NULL,
    [UserTypeName] nvarchar(20) NOT NULL,
    [IsActive] bit NOT NULL DEFAULT CAST(1 AS bit),
    [CreatedOn] datetime2 NULL,
    [CreatedBy] nvarchar(256) NULL,
    [UpdatedOn] datetime2 NULL,
    [UpdatedBy] nvarchar(256) NULL,
    CONSTRAINT [PK_UserType] PRIMARY KEY ([UserTypeId])
);
GO

CREATE TABLE [DeletedUserProfile] (
    [UserId] int NOT NULL,
    [PhotoUrl] nvarchar(500) NULL,
    [AddressLine1] nvarchar(500) NULL,
    [AddressLine2] nvarchar(500) NULL,
    [Country] nvarchar(100) NULL,
    [CountryCode] nvarchar(10) NULL,
    [State] nvarchar(100) NULL,
    [City] nvarchar(100) NULL,
    [Longitude] nvarchar(50) NULL,
    [Latitude] nvarchar(50) NULL,
    [ZipCode] nvarchar(10) NULL,
    [CompanyId] int NULL,
    [Company] nvarchar(200) NULL,
    [StoreId] int NULL,
    [Store] nvarchar(200) NULL,
    [BusinessName] nvarchar(200) NULL,
    [BusinessAccountNumber] nvarchar(50) NULL,
    [IsActive] bit NOT NULL DEFAULT CAST(1 AS bit),
    [CreatedOn] datetime2 NULL,
    [CreatedBy] nvarchar(256) NULL,
    [UpdatedOn] datetime2 NULL,
    [UpdatedBy] nvarchar(256) NULL,
    CONSTRAINT [PK_DeletedUserProfile] PRIMARY KEY ([UserId]),
    CONSTRAINT [FK_DeletedUserProfile_DeletedUser_UserId] FOREIGN KEY ([UserId]) REFERENCES [DeletedUser] ([UserId]) ON DELETE NO ACTION
);
GO

CREATE TABLE [Role] (
    [RoleId] int NOT NULL,
    [RoleName] nvarchar(100) NOT NULL,
    [RoleTypeId] int NOT NULL,
    [IsActive] bit NOT NULL DEFAULT CAST(1 AS bit),
    [CreatedOn] datetime2 NULL,
    [CreatedBy] nvarchar(256) NULL,
    [UpdatedOn] datetime2 NULL,
    [UpdatedBy] nvarchar(256) NULL,
    CONSTRAINT [PK_Role] PRIMARY KEY ([RoleId]),
    CONSTRAINT [FK_Role_RoleType_RoleTypeId] FOREIGN KEY ([RoleTypeId]) REFERENCES [RoleType] ([RoleTypeId]) ON DELETE NO ACTION
);
GO

CREATE TABLE [User] (
    [UserId] int NOT NULL IDENTITY,
    [UserName] nvarchar(50) NOT NULL,
    [EnrolledBusinessUser] bit NOT NULL,
    [PasswordHash] nvarchar(256) NULL,
    [UserTypeId] int NOT NULL,
    [FirstName] nvarchar(50) NOT NULL,
    [LastName] nvarchar(50) NOT NULL,
    [Email] nvarchar(100) NULL,
    [MobileCountryCode] nvarchar(10) NULL,
    [MobileNumber] nvarchar(20) NULL,
    [EmailConfirmed] bit NOT NULL,
    [MobileConfirmed] bit NOT NULL,
    [AccessFailedCount] int NOT NULL,
    [Lockout] bit NOT NULL,
    [PreferedLanguage] nvarchar(20) NULL,
    [LastTimeAccess] datetime2 NULL,
    [DOB] datetime2 NULL,
    [IsActive] bit NOT NULL,
    [CreatedOn] datetime2 NULL,
    [CreatedBy] nvarchar(256) NULL,
    [UpdatedOn] datetime2 NULL,
    [UpdatedBy] nvarchar(256) NULL,
    CONSTRAINT [PK_User] PRIMARY KEY ([UserId]),
    CONSTRAINT [FK_User_UserType_UserTypeId] FOREIGN KEY ([UserTypeId]) REFERENCES [UserType] ([UserTypeId]) ON DELETE NO ACTION
);
GO

CREATE TABLE [Permission] (
    [RoleId] int NOT NULL,
    [ClaimId] int NOT NULL,
    [IsActive] bit NOT NULL DEFAULT CAST(1 AS bit),
    [CreatedOn] datetime2 NULL,
    [CreatedBy] nvarchar(256) NULL,
    [UpdatedOn] datetime2 NULL,
    [UpdatedBy] nvarchar(256) NULL,
    CONSTRAINT [PK_Permission] PRIMARY KEY ([RoleId], [ClaimId]),
    CONSTRAINT [FK_Permission_Claim_ClaimId] FOREIGN KEY ([ClaimId]) REFERENCES [Claim] ([ClaimId]) ON DELETE NO ACTION,
    CONSTRAINT [FK_Permission_Role_RoleId] FOREIGN KEY ([RoleId]) REFERENCES [Role] ([RoleId]) ON DELETE NO ACTION
);
GO

CREATE TABLE [LinkUser] (
    [LinkUserId] int NOT NULL IDENTITY,
    [RequestedUserId] int NOT NULL,
    [AcceptUserId] int NOT NULL,
    [IsAccepted] bit NULL,
    [RequestDate] datetime2 NULL,
    [ActionDate] datetime2 NULL,
    [IsActive] bit NOT NULL DEFAULT CAST(1 AS bit),
    [CreatedOn] datetime2 NULL,
    [CreatedBy] nvarchar(256) NULL,
    [UpdatedOn] datetime2 NULL,
    [UpdatedBy] nvarchar(256) NULL,
    CONSTRAINT [PK_LinkUser] PRIMARY KEY ([LinkUserId]),
    CONSTRAINT [FK_LinkUser_User_AcceptUserId] FOREIGN KEY ([AcceptUserId]) REFERENCES [User] ([UserId]) ON DELETE NO ACTION,
    CONSTRAINT [FK_LinkUser_User_RequestedUserId] FOREIGN KEY ([RequestedUserId]) REFERENCES [User] ([UserId]) ON DELETE NO ACTION
);
GO

CREATE TABLE [UserDevice] (
    [UserDeviceId] int NOT NULL IDENTITY,
    [UserId] int NOT NULL,
    [DeviceTypeId] int NOT NULL,
    [MobileAppTypeId] int NOT NULL,
    [DeviceToken] nvarchar(255) NULL,
    [IsOnline] bit NOT NULL,
    [IsActive] bit NOT NULL DEFAULT CAST(1 AS bit),
    [CreatedOn] datetime2 NULL,
    [CreatedBy] nvarchar(256) NULL,
    [UpdatedOn] datetime2 NULL,
    [UpdatedBy] nvarchar(256) NULL,
    CONSTRAINT [PK_UserDevice] PRIMARY KEY ([UserDeviceId]),
    CONSTRAINT [FK_UserDevice_User_UserId] FOREIGN KEY ([UserId]) REFERENCES [User] ([UserId]) ON DELETE CASCADE
);
GO

CREATE TABLE [UserProfile] (
    [UserId] int NOT NULL,
    [PhotoUrl] nvarchar(500) NULL,
    [AddressLine1] nvarchar(500) NULL,
    [AddressLine2] nvarchar(500) NULL,
    [Country] nvarchar(100) NULL,
    [CountryCode] nvarchar(10) NULL,
    [State] nvarchar(100) NULL,
    [City] nvarchar(100) NULL,
    [Longitude] nvarchar(50) NULL,
    [Latitude] nvarchar(50) NULL,
    [ZipCode] nvarchar(10) NULL,
    [CompanyId] int NULL,
    [Company] nvarchar(200) NULL,
    [StoreId] int NULL,
    [Store] nvarchar(200) NULL,
    [BusinessName] nvarchar(200) NULL,
    [BusinessAccountNumber] nvarchar(50) NULL,
    [IsActive] bit NOT NULL DEFAULT CAST(1 AS bit),
    [CreatedOn] datetime2 NULL,
    [CreatedBy] nvarchar(256) NULL,
    [UpdatedOn] datetime2 NULL,
    [UpdatedBy] nvarchar(256) NULL,
    CONSTRAINT [PK_UserProfile] PRIMARY KEY ([UserId]),
    CONSTRAINT [FK_UserProfile_User_UserId] FOREIGN KEY ([UserId]) REFERENCES [User] ([UserId]) ON DELETE NO ACTION
);
GO

CREATE TABLE [UserRole] (
    [RoleId] int NOT NULL,
    [UserId] int NOT NULL,
    [IsActive] bit NOT NULL DEFAULT CAST(1 AS bit),
    [CreatedOn] datetime2 NULL,
    [CreatedBy] nvarchar(256) NULL,
    [UpdatedOn] datetime2 NULL,
    [UpdatedBy] nvarchar(256) NULL,
    CONSTRAINT [PK_UserRole] PRIMARY KEY ([RoleId], [UserId]),
    CONSTRAINT [FK_UserRole_Role_RoleId] FOREIGN KEY ([RoleId]) REFERENCES [Role] ([RoleId]) ON DELETE NO ACTION,
    CONSTRAINT [FK_UserRole_User_UserId] FOREIGN KEY ([UserId]) REFERENCES [User] ([UserId]) ON DELETE NO ACTION
);
GO

CREATE INDEX [IX_CodeVerification_UserId] ON [CodeVerification] ([UserId]);
GO

CREATE INDEX [IX_LinkUser_AcceptUserId] ON [LinkUser] ([AcceptUserId]);
GO

CREATE INDEX [IX_LinkUser_RequestedUserId] ON [LinkUser] ([RequestedUserId]);
GO

CREATE INDEX [IX_Permission_ClaimId] ON [Permission] ([ClaimId]);
GO

CREATE INDEX [IX_Role_RoleTypeId] ON [Role] ([RoleTypeId]);
GO

CREATE INDEX [IX_User_Email] ON [User] ([Email]);
GO

CREATE INDEX [IX_User_FirstName] ON [User] ([FirstName]);
GO

CREATE INDEX [IX_User_LastName] ON [User] ([LastName]);
GO

CREATE INDEX [IX_User_MobileNumber] ON [User] ([MobileNumber]);
GO

CREATE INDEX [IX_User_UserName] ON [User] ([UserName]);
GO

CREATE INDEX [IX_User_UserTypeId] ON [User] ([UserTypeId]);
GO

CREATE INDEX [IX_UserDevice_UserId] ON [UserDevice] ([UserId]);
GO

CREATE INDEX [IX_UserRole_UserId] ON [UserRole] ([UserId]);
GO

INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
VALUES (N'20220720165301_InitialCreate', N'5.0.9');
GO

COMMIT;
GO

