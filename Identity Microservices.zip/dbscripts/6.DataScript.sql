SET XACT_ABORT ON;  
Begin Transaction;

set identity_insert dbo.ApiResources on
go
INSERT INTO dbo.ApiResources
(Id, Enabled, [Name], DisplayName, Description, AllowedAccessTokenSigningAlgorithms, ShowInDiscoveryDocument, Created, Updated, LastAccessed, NonEditable)
VALUES
(1, 1, N'transactionapi', N'Transaction Api', N'Allow the application to access Transaction Api', NULL, 1, Getutcdate(), NULL, NULL, 0),
(2, 1, N'mppaapi', N'MPPA Api', N'Allow the application to access MPPA Api', NULL, 1, Getutcdate(), NULL, NULL, 0),
(3, 1, N'paymentapi', N'User Payment Api', N'Allow the application to access User Payment Api', NULL, 1, Getutcdate(), NULL, NULL, 0),
(4, 1, N'userstoreapi', N'User Store Management Api', N'Allow the application to access User Store Management Api', NULL, 1, Getutcdate(), NULL, NULL, 0),
(5, 1, N'IdentityServerApi', N'IdentityServerApi', N'IdentityServerApi', NULL, 1, Getutcdate(), NULL, NULL, 0),
(6, 1, N'helpsupportapi', N'Helpsupport api', N'Allow the application to access helpsupport api', NULL, 1, Getutcdate(), NULL, NULL, 0),
(7, 1, N'marketingapi', N'marketing api', N'marketing api', NULL, 1, Getutcdate(), NULL, NULL, 0),
(8, 1, N'financeapi', N'finance api', N'finance api', NULL, 1, Getutcdate(), NULL, NULL, 0),
(9, 1, N'accountapi', N'account api', N'account api', NULL, 1, Getutcdate(), NULL, NULL, 0),
(10, 1, N'notificationapi', N'notification api', N'notification api', NULL, 1, Getutcdate(), NULL, NULL, 0),
(11, 1, N'reportapi', N'report api', N'report api', NULL, 1, Getutcdate(), NULL, NULL, 0);
go
set identity_insert dbo.ApiResources off
go



set identity_insert dbo.ApiResourceScopes on
go
INSERT INTO dbo.ApiResourceScopes(Id, Scope, ApiResourceId)
VALUES
(1, N'transactionapi', 1),
(2, N'mppaapi', 2),
(3, N'paymentapi', 3),
(4, N'userstoreapi', 4),
(5, N'IdentityServerApi', 5),
(6, N'helpsupportapi', 6),
(7, N'marketingapi', 7),
(8, N'financeapi', 8),
(9, N'accountapi', 9),
(10, N'notificationapi', 10),
(11, N'reportapi', 11);
go
set identity_insert dbo.ApiResourceScopes off
go


set identity_insert dbo.ApiScopes on
go
INSERT INTO dbo.ApiScopes(Id, Enabled, [Name], DisplayName, Description, Required, Emphasize, ShowInDiscoveryDocument)
VALUES
(1, 1, N'transactionapi', N'Access to Transaction Api', NULL, 0, 0, 1),
(2, 1, N'mppaapi', N'Access to MPPA Api', NULL, 0, 0, 1),
(3, 1, N'paymentapi', N'Access to payment Api', NULL, 0, 0, 1),
(4, 1, N'userstoreapi', N'Access to User Store Management Api', NULL, 0, 0, 1),
(5, 1, N'IdentityServerApi', N'Access to IdentityServer Api', NULL, 0, 0, 1),
(6, 1, N'helpsupportapi', N'Access to HelpSupport Api', NULL, 0, 0, 1),
(7, 1, N'marketingapi', N'Access to Marketing Api', NULL, 0, 0, 1),
(8, 1, N'financeapi', N'Access to Finance API', NULL, 0, 0, 1),
(9, 1, N'accountapi', N'Access to Account API', NULL, 0, 0, 1),
(10, 1, N'notificationapi', N'Access to Notification API', NULL, 0, 0, 1),
(11, 1, N'reportapi', N'Access to Report API', NULL, 0, 0, 1);
go
set identity_insert dbo.ApiScopes off
go



set identity_insert dbo.IdentityResources on
go
INSERT INTO dbo.IdentityResources(Id, Enabled, [Name], DisplayName, Description, Required, Emphasize, ShowInDiscoveryDocument, Created, Updated, NonEditable)
VALUES
(1, 1, N'profile', N'User profile', N'Your user profile information (first name, last name, etc.)', 0, 1, 1, Getutcdate(), NULL, 0),
(2, 1, N'openid', N'Your user identifier', NULL, 1, 0, 1, Getutcdate(), NULL, 0);
go
set identity_insert dbo.IdentityResources off
go



set identity_insert dbo.IdentityResourceClaims on
go
INSERT INTO dbo.IdentityResourceClaims(Id, IdentityResourceId, Type)
VALUES
(1, 1, N'website'),
(2, 1, N'picture'),
(3, 1, N'profile'),
(4, 1, N'preferred_username'),
(5, 1, N'nickname'),
(6, 1, N'middle_name'),
(7, 1, N'given_name'),
(8, 1, N'family_name'),
(9, 1, N'name'),
(10, 1, N'gender'),
(11, 1, N'birthdate'),
(12, 1, N'zoneinfo'),
(13, 1, N'locale'),
(14, 1, N'updated_at'),
(15, 2, N'sub');
go
set identity_insert dbo.IdentityResourceClaims off
go


set identity_insert dbo.Clients on
go
INSERT INTO dbo.Clients
 (Id, Enabled, ClientId, ProtocolType, RequireClientSecret, ClientName, Description, ClientUri, LogoUri, RequireConsent, AllowRememberConsent, AlwaysIncludeUserClaimsInIdToken, RequirePkce, AllowPlainTextPkce, RequireRequestObject, AllowAccessTokensViaBrowser, FrontChannelLogoutUri, FrontChannelLogoutSessionRequired, BackChannelLogoutUri, BackChannelLogoutSessionRequired, AllowOfflineAccess, IdentityTokenLifetime, AllowedIdentityTokenSigningAlgorithms, AccessTokenLifetime, AuthorizationCodeLifetime, ConsentLifetime, AbsoluteRefreshTokenLifetime, SlidingRefreshTokenLifetime, RefreshTokenUsage, UpdateAccessTokenClaimsOnRefresh, RefreshTokenExpiration, AccessTokenType, EnableLocalLogin, IncludeJwtId, AlwaysSendClientClaims, ClientClaimsPrefix, PairWiseSubjectSalt, Created, Updated, LastAccessed, UserSsoLifetime, UserCodeType, DeviceCodeLifetime, NonEditable)
 VALUES
(1, 1, N'papipay_m2m', N'oidc', 1, N'Papipay API to API Client', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 0, NULL, 1, NULL, 1, 1, 300, NULL, 86400, 300, NULL, 2592000, 1296000, 1, 0, 1, 1, 1, 1, 0, N'client_', NULL, Getutcdate(), NULL, NULL, NULL, NULL, 300, 0),
 
(2, 1, N'papipay_portal', N'oidc', 0, N'Papipay Portal Client', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 1, NULL, 1, NULL, 1, 0, 300, NULL, 86400, 300, NULL, 2592000, 1296000, 1, 0, 1, 1, 1, 1, 0, N'client_', NULL, Getutcdate(), NULL, NULL, NULL, NULL, 300, 0),
 
(3, 1, N'papipay_consumermobile', N'oidc', 1, N'Papipay Consumer Mobile Client', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 0, NULL, 1, NULL, 1, 1, 300, NULL, 86400, 300, NULL, 2592000, 1296000, 1, 0, 1, 1, 1, 1, 0, N'client_', NULL, Getutcdate(), NULL, NULL, NULL, NULL, 300, 0),
 
(4, 1, N'papipay_businessmobile', N'oidc', 1, N'Papipay Business Mobile Client', NULL, NULL, NULL, 0, 0, 0, 1, 0, 0, 0, NULL, 1, NULL, 1, 1, 300, NULL, 86400, 300, NULL, 2592000, 1296000, 1, 0, 1, 1, 1, 1, 0, N'client_', NULL, Getutcdate(), NULL, NULL, NULL, NULL, 300, 0);
go
set identity_insert dbo.Clients off
go



set identity_insert dbo.ClientGrantTypes on
go
INSERT INTO dbo.ClientGrantTypes(Id, GrantType, ClientId)
VALUES
(1, N'client_credentials', 1),
(2, N'authorization_code', 2),
(3, N'password', 3),
(4, N'password', 4);
go
set identity_insert dbo.ClientGrantTypes off
go


set identity_insert dbo.ClientPostLogoutRedirectUris on
go
INSERT INTO dbo.ClientPostLogoutRedirectUris(Id, PostLogoutRedirectUri, ClientId)
VALUES
(1, N'http://papipayangular.flexsin.org', 2);
go
set identity_insert dbo.ClientPostLogoutRedirectUris off
go



set identity_insert dbo.ClientRedirectUris on
go
INSERT INTO dbo.ClientRedirectUris(Id, RedirectUri, ClientId)
VALUES
(1, N'http://papipayangular.flexsin.org', 2);
go
set identity_insert dbo.ClientRedirectUris off
go


set identity_insert dbo.ClientScopes on
go

INSERT INTO dbo.ClientScopes(Id, Scope, ClientId)
VALUES
(103, N'transactionapi', 	1),
(104, N'mppaapi', 			1),
(105, N'paymentapi', 		1),
(106, N'userstoreapi', 		1),
(107, N'IdentityServerApi', 1),
(108, N'helpsupportapi', 	1),
(109, N'marketingapi', 		1),
(110, N'financeapi', 		1),
(111, N'accountapi', 		1),
(112, N'notificationapi', 	1),
(113, N'reportapi', 		1),
 
(201, N'profile', 			2),
(202, N'openid', 			2),
(203, N'transactionapi', 	2),
(204, N'mppaapi', 			2),
(205, N'paymentapi', 		2),
(206, N'userstoreapi', 		2),
(207, N'IdentityServerApi', 2),
(208, N'helpsupportapi', 	2),
(209, N'marketingapi', 		2),
(210, N'financeapi', 		2),
(211, N'accountapi', 		2),
(212, N'notificationapi', 	2),
(213, N'reportapi', 		2),

(301, N'profile', 			3),
(302, N'openid', 			3),
(303, N'transactionapi', 	3),
(304, N'mppaapi', 			3),
(305, N'paymentapi', 		3),
(306, N'userstoreapi', 		3),
(307, N'IdentityServerApi', 3),
(308, N'helpsupportapi', 	3),
(309, N'marketingapi', 		3),
(310, N'financeapi', 		3),
(311, N'accountapi', 		3),
(312, N'notificationapi', 	3),
(313, N'reportapi', 		3),

(401, N'profile', 			4),
(402, N'openid', 			4),
(403, N'transactionapi', 	4),
(404, N'mppaapi', 			4),
(405, N'paymentapi', 		4),
(406, N'userstoreapi', 		4),
(407, N'IdentityServerApi', 4),
(408, N'helpsupportapi', 	4),
(409, N'marketingapi', 		4),
(410, N'financeapi', 		4),
(411, N'accountapi', 		4),
(412, N'notificationapi', 	4),
(413, N'reportapi', 		4);
go
set identity_insert dbo.ClientScopes off
go


set identity_insert dbo.ClientSecrets on
go
INSERT INTO dbo.ClientSecrets (Id, ClientId, Description, Value, Expiration, Type, Created)
VALUES
(1, 1, NULL, N'RYNbytVE0EkEVKSAPWReCABo48gDRwQm88TcOAOgH+E=', NULL, N'SharedSecret', Getutcdate()),
(2, 3, NULL, N'0WpMUCZpatFoW2e8izLYxUUbhhckiURFjfL/AHs5m3o=', NULL, N'SharedSecret', Getutcdate()),
(3, 4, NULL, N'0WpMUCZpatFoW2e8izLYxUUbhhckiURFjfL/AHs5m3o=', NULL, N'SharedSecret', Getutcdate());
go
set identity_insert dbo.ClientSecrets off
go


INSERT INTO dbo.UserType(UserTypeId,UserTypeName,IsActive,CreatedOn)
VALUES
(1, N'Consumer', 1, Getutcdate()),
(2, N'Store', 1, Getutcdate());
go


INSERT INTO dbo.RoleType(RoleTypeId,RoleTypeName,IsActive,CreatedOn)
VALUES
(1, N'Internal', 1, Getutcdate()),
(2, N'External', 1, Getutcdate());
go


INSERT INTO dbo.Role([RoleId],[RoleName],[RoleTypeId],[IsActive],[CreatedOn])
VALUES
(N'SuperAdmin', N'Super Admin', 1, 1, Getutcdate()),
(N'Admin', N'Admin', 1, 1, Getutcdate()),
(N'SupportL1', N'Support L1', 1, 1, Getutcdate()),
(N'SupportL2', N'Support L2', 1, 1, Getutcdate()),
(N'SupportL3', N'Support L3', 1, 1, Getutcdate()),
(N'StoreOwner', N'Store Owner', 2, 1, Getutcdate()),
(N'StoreRegional', N'Store Regional ', 2, 1, Getutcdate()),
(N'StoreSupervisor', N'Store Supervisor', 2, 1, Getutcdate()),
(N'StoreManager', N'Store Manager', 2, 1, Getutcdate()),
(N'ConsumerUser', N'Consumer User', 2, 1, Getutcdate());
go

INSERT [dbo].[Claim] ([ClaimId], [ClaimName], [DisplayOrder], [IsActive], [CreatedOn], [CreatedBy], [UpdatedOn], [UpdatedBy]) VALUES 
(N'AboutMenu', N'AboutMenu View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ActiveUserMenu', N'ActiveUser Page View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ActiveUserMenu_UserLogout', N'ActiveUser Page UserLogout', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'AdminMenu', N'AdminMenu View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'AppConfigurationMenu', N'AppConfiguration Page View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'AppConfigurationMenu_CreateUpdate', N'AppConfiguration Page CreateUpdate', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ApplicationSupportMenu', N'ApplicationSupport Page View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ApplicationSupportMenu_Create', N'ApplicationSupport Page Create', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ApplicationSupportMenu_Edit', N'ApplicationSupport Page Edit', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'BusinessUserMenu_Edit', N'BusinessUser Page Edit', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'BusinessUserProfileMenu', N'BusinessUser Page View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'CashRewardSetupMenu', N'CashRewardSetup Page View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'CashRewardSetupMenu_Create', N'CashRewardSetup Page Create', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'CashRewardSetupMenu_Edit', N'CashRewardSetup Page Edit', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ChangePassword', N'ChangePassword', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ConsumerProfileMenu', N'ConsumerProfile Page View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ConsumerProfileMenu_Edit', N'ConsumerProfile Page Edit', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ConsumerProfileMenu_Edit_CashRewardTab_EarnRedeem', N'ConsumerProfile Page Edit CashRewardTab EarnRedeem', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ConsumerProfileMenu_Edit_CashRewardTab_View', N'ConsumerProfile Page Edit CashRewardTab View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ConsumerProfileMenu_Edit_TransactionHistoryTab_View', N'ConsumerProfile Page Edit TransactionHistoryTab View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ConsumerProfileMenu_Edit_UpdateProfileTab_Update', N'ConsumerProfile Page Edit UpdateProfileTab Update', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ConsumerProfileMenu_Edit_UpdateProfileTab_View', N'ConsumerProfile Page Edit UpdateProfileTab View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ConsumerProfileMenu_Export', N'ConsumerProfile Page Grid Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'DashboardView', N'DashBoard view', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'DefaultBilling_Setup_Add', N'DefaultBilling Setup Menu Add', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'DefaultBilling_Setup_Edit', N'DefaultBilling Setup Page Edit', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'DefaultBilling_Setup_Menu', N'DefaultBilling_Setup_Menu_page', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'DefaultReseller_Setup_Add', N'DefaultReseller Setup Add', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'DefaultReseller_Setup_Edit', N'DefaultReseller Setup Edit', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'DefaultReseller_Setup_Menu', N'DefaultReseller Setup Page', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'DefaultSaleAgent_Setup_Add', N'Default SaleAgent Setup_Add', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'DefaultSaleAgent_Setup_Edit', N'Default SaleAgent Setup Edit', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'DefaultSaleAgent_Setup_Menu', N'Default SaleAgent Setup Page', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Login', N'Login', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'MarketingMenu', N'MarketingMenu View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'MarketingMenu_AllInactiveOffers', N'MarketingMenu AllInactiveOffers View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'MarketingMenu_AllInactiveOffers_Export', N'MarketingMenu AllInactiveOffersExport', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'MarketingMenu_AllInactiveOffers_Update', N'MarketingMenu AllInactiveOffers Update', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'MarketingMenu_AppNotification Send', N'MarketingMenu_AppNotification Send', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'MarketingMenu_OffersAndDeals', N'MarketingMenu_OffersAndDeals View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'MarketingMenu_OffersAndDeals_Create', N'MarketingMenu_OffersAndDeals_Create', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'MarketingMenu_OffersAndDeals_Export', N'MarketingMenu_OffersAndDeals Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'MarketingMenu_OffersAndDeals_SendOffer', N'MarketingMenu_OffersAndDeals_SendOffer', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'MarketingMenu_OffersAndDeals_Update', N'MarketingMenu_OffersAndDeals_Update', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NotificationMessageMenu', N'NotificationMessage Page View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NotificationMessageMenu_Edit', N'NotificationMessage Page  Edit', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NotificationMessageMenu_Export', N'NotificationMessage Page Grid Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu', N'ProcessesMenu View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_EODSettelement', N'ProcessesMenu EODSettelement View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_EODSettelement_Export', N'ProcessesMenu EODSettelement Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_EODSettelement_Paid', N'ProcessesMenu EODSettelement Paid', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_EODSettelement_PreviewNachaFile', N'ProcessesMenu EODSettelement PreviewNachaFile', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_EODSettelement_ProcessSettlement', N'ProcessesMenu EODSettelement ProcessSettlement', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_EODSettelement_ReviewUnreview', N'ProcessesMenu EODSettelement ReviewUnreview', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_EODSettelement_ViewNacha', N'ProcessesMenu EODSettelement ViewNacha', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_EODSettelement_ViewPdf', N'ProcessesMenu EODSettelement ViewPdf', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_ResellerMonthlyBilling_Export', N'ProcessesMenu ResellerMonthlyBilling Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_ResellerMonthlyBilling_GenerateBill', N'ProcessesMenu ResellerMonthlyBilling GenerateBill', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_ResellerMonthlyBilling_GetBill', N'ProcessesMenu ResellerMonthlyBilling GetBill', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_ResellerMonthlyBilling_MonthlyPdf', N'ProcessesMenu ResellerMonthlyBilling MonthlyPdf', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_ResellerMonthlyBilling_Paid', N'ProcessesMenu ResellerMonthlyBilling Paid', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_ResellerMonthlyBilling_PreviewNachaFile', N'ProcessesMenu ResellerMonthlyBilling PreviewNachaFile', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_ResellerMonthlyBilling_ProcessSettlement', N'ProcessesMenu ResellerMonthlyBilling ProcessSettlement', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_ResellerMonthlyBilling_ReviewUnreview', N'ProcessesMenu ResellerMonthlyBilling ReviewUnreview', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_ResellerMonthlyBilling_ViewNacha', N'ProcessesMenu ResellerMonthlyBilling ViewNacha', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_ResellerMonthlyBilling_ViewPdf', N'ProcessesMenu ResellerMonthlyBilling ViewPdf', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_SaleAgentMonthlyBilling_Export', N'ProcessesMenu SaleAgentMonthlyBilling Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_SaleAgentMonthlyBilling_GenerateBill', N'ProcessesMenu SaleAgentMonthlyBilling GenerateBill', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_SaleAgentMonthlyBilling_GetBill', N'ProcessesMenu SaleAgentMonthlyBilling GetBill', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_SaleAgentMonthlyBilling_MonthlyPdf', N'ProcessesMenu SaleAgentMonthlyBilling MonthlyPdf', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_SaleAgentMonthlyBilling_Paid', N'ProcessesMenu SaleAgentMonthlyBilling Paid', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_SaleAgentMonthlyBilling_PreviewNachaFile', N'ProcessesMenu SaleAgentMonthlyBilling PreviewNachaFile', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_SaleAgentMonthlyBilling_ProcessSettlement', N'ProcessesMenu SaleAgentMonthlyBilling ProcessSettlement', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_SaleAgentMonthlyBilling_ReviewUnreview', N'ProcessesMenu SaleAgentMonthlyBilling ReviewUnreview', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_SaleAgentMonthlyBilling_ViewNacha', N'ProcessesMenu SaleAgentMonthlyBilling ViewNacha', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_SaleAgentMonthlyBilling_ViewPdf', N'ProcessesMenu SaleAgentMonthlyBilling ViewPdf', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_StoreMonthlyBilling_Export', N'ProcessesMenu StoreMonthlyBilling Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_StoreMonthlyBilling_GenerateBill', N'ProcessesMenu StoreMonthlyBilling GenerateBill', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_StoreMonthlyBilling_GetBill', N'ProcessesMenu StoreMonthlyBilling GetBill', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_StoreMonthlyBilling_MonthlyPdf', N'ProcessesMenu StoreMonthlyBilling MonthlyPdf', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_StoreMonthlyBilling_Paid', N'ProcessesMenu StoreMonthlyBilling Paid', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_StoreMonthlyBilling_PreviewNachaFile', N'ProcessesMenu StoreMonthlyBilling PreviewNachaFile', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_StoreMonthlyBilling_ProcessSettlement', N'ProcessesMenu StoreMonthlyBilling ProcessSettlement', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_StoreMonthlyBilling_ReviewUnreview', N'ProcessesMenu StoreMonthlyBilling ReviewUnreview', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_StoreMonthlyBilling_TransactionDetails', N'ProcessesMenu StoreMonthlyBilling TransactionDetails', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_StoreMonthlyBilling_ViewNacha', N'ProcessesMenu StoreMonthlyBilling ViewNacha', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ProcessesMenu_StoreMonthlyBilling_ViewPdf', N'ProcessesMenu StoreMonthlyBilling ViewPdf', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'PromotionMenu', N'Promotionp Page View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'PromotionMenu_Create', N'Promotion Page Create', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'PromotionMenu_Edit', N'Promotion Page Edit', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Report_Menu_ConsumerTransation_ExportPrint', N'Report Menu ConsumerTransation ExportPrint', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Report_Menu_ConsumerTransation_Receipt', N'Report Menu ConsumerTransation Receipt', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Report_Menu_ConsumerTransation_View', N'Report Menu ConsumerTransation View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Report_Menu_Eod_Report', N'Report Menu Eod Report Page', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Report_Menu_Eod_Report_Export', N'Report Menu Eod Report Page Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Report_Menu_Eod_Report_TransactionDetails', N'Report Menu Eod Report Page TransactionDetails', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Report_Menu_MobileErrorMessage', N'ReportMenu MobileErrorMessage', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Report_Menu_MobileErrorMessage_Export', N'ReportMenu MobileErrorMessage Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Report_Menu_MonthlyStatementReport', N'Report Menu Monthly  Statement Report Page', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Report_Menu_MonthlyStatementReport_Export', N'Report Menu Monthly  Statement Report Page Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Report_Menu_PaymentFailed', N'Report Menu Payment Failed Page', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Report_Menu_PaymentFailed_Export', N'Report Menu Payment Failed Page Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Report_Menu_POSMessage', N'ReportMenu POSMessage', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Report_Menu_POSMessage_Export', N'ReportMenu POSMessage Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Report_Menu_POSMessage_ViewJsonMessage', N'ReportMenu POSMessage ViewJsonMessage', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Report_Menu_POSMessage_ViewXmlMessage', N'ReportMenu POSMessage ViewXmlMessage', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Report_Menu_SettlementReconcile', N'Report Menu Settlement  Reconcile Page', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'Report_Menu_SettlementReconcile_Export', N'Report Menu Settlement Page Reconcile Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ReportMenu', N'Report Menu View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ResellerMenu', N'Reseller Page View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ResellerMenu_Create', N'Reseller Page Create', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ResellerMenu_Edit', N'Reseller Page  Edit', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ResellerMenu_Edit_ResellerCompanyListTab_Create', N'Reseller Page_Edit_ResellerCompanyListTab Create', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ResellerMenu_Edit_ResellerCompanyListTab_View', N'ResellerMenu_Edit_ResellerCompanyListTab View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ResellerMenu_Edit_ResellerConfigTab_Update', N'Reseller Page Edit ResellerConfigTab Update', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ResellerMenu_Edit_ResellerTab_ResellerBillingFee_GetDefault', N'ResellerMenu_Edit ResellerTab ResellerBillingFee GetDefault', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ResellerMenu_Edit_ResellerTab_ResellerFee_Create', N'ResellerMenu_Edit_ResellerTab_ResellerFee Create', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ResellerMenu_Edit_UpdateResellerTab_Update', N'Reseller Page Edit UpdateResellerTab Update', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ResellerMenu_Edit_UpdateResellerTab_View', N'Reseller Page Edit UpdateResellerTab View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'ResellerMenu_Export', N'Reseller Page Grid Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'SaleAgentMenu', N'SaleAgent Page View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'SaleAgentMenu_Create', N'SaleAgent Page Create', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'SaleAgentMenu_Edit', N'SaleAgent Page  Edit', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'SaleAgentMenu_Edit_SaleAgentConfigTab_Update', N'SaleAgent Page Edit SaleAgentConfigTab Update', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'SaleAgentMenu_Edit_StoreListTab_Create', N'SaleAgentMenu_Edit_StoreListTab_Create', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'SaleAgentMenu_Edit_StoreListTab_SaleAgentFee_Create', N'SaleAgentMenu_Edit_StoreListTab_SaleAgentFee_Create', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'SaleAgentMenu_Edit_StoreListTab_SaleAgentFee_GetDefault', N'SaleAgentMenu_Edit_StoreListTab_SaleAgentFee_GetDefault', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'SaleAgentMenu_Edit_StoreListTab_View', N'SaleAgentMenu Edit_StoreListTab_View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'SaleAgentMenu_Edit_UpdateSaleAgentTab_Update', N'SaleAgent Page Edit UpdateSaleAgentTab Update', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'SaleAgentMenu_Edit_UpdateSaleAgentTab_View', N'SaleAgent  Page Edit UpdateSaleAgentTab View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'SaleAgentMenu_Export', N'SaleAgent Page Grid Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'StoreMenu', N'Store Page View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'StoreMenu_CompanyTab_Create', N'Store Page CompanyTab Create', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'StoreMenu_CompanyTab_Edit', N'Store Page CompanyTab Edit', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'StoreMenu_CompanyTab_Export', N'Store Page CompanyTab Grid Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'StoreMenu_CompanyTab_StoreCreate', N'Store Page CompanyTab StoreCreate', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'StoreMenu_CompanyTab_StoreEdit', N'Store Page CompanyTab StoreEdit', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'StoreMenu_CompanyTab_StoreManage', N'Store Page CompanyTab StoreManage', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'StoreMenu_CompanyTab_View', N'Store Page CompanyTab View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'StoreMenu_StoreTab_Edit', N'Store Page StoreTab Edit', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'StoreMenu_StoreTab_Export', N'Store Page StoreTab Grid Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'StoreMenu_StoreTab_StoreManage', N'Store Page StoreTab StoreManage', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'StoreMenu_StoreTab_View', N'Store Page StoreTab View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'SupportMenu', N'SupportMenu View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'SupportMenu_HelpSupport_Call', N'SupportMenu_HelpSupport Call', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'SupportMenu_HelpSupport_Chat', N'SupportMenu_HelpSupport Chat', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'SupportMenu_HelpSupport_SendMessage', N'SupportMenu_HelpSupport SendMessage', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'SystemStatusMenu', N'SystemStatus Page View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'SystemStatusMenu_Export', N'SystemStatus Page Grid Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'TutorialMenu', N'Tutorial Page View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'TutorialMenu_Create', N'Tutorial Page Create', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'TutorialMenu_Edit', N'Tutorial Page  Edit', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'TutorialMenu_Export', N'Tutorial Page Grid Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'UserMenu', N'User Page View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'UserMenu_PermissionTab_RoleClaimsAssociation', N'Role ClaimsAssociation', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'UserMenu_PermissionTab_View', N'UserPage PermissionTab View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'UserMenu_RolesTab_Create', N'User Page RolesTab Edit', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'UserMenu_RolesTab_Edit', N'User Page RolesTab Edit', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'UserMenu_RolesTab_View', N'UserPage RolesTab View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'UserMenu_StoreOwnerTab_ComapanyAssociation', N'StoreOwner ComapanyAssociation', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'UserMenu_StoreOwnerTab_View', N'StoreOwner UsersTab View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'UserMenu_UsersTab_Create', N'User Page UsersTab Create', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'UserMenu_UsersTab_Edit', N'User Page UsersTab Edit', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'UserMenu_UsersTab_Export', N'User Page UsersTab Grid Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'UserMenu_UsersTab_View', N'User Page UsersTab View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NachaReportMenu', N'NachaReportMenu Page View', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NachaReportMenu_DailyProcessingActivity', N'NachaReportMenu Page DailyProcessingActivity', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NachaReportMenu_DailyProcessingActivity_Export', N'NachaReportMenu Page DailyProcessingActivity Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NachaReportMenu_DailyReturnActivity', N'NachaReportMenu Page ReturnActivity', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NachaReportMenu_DailyReturnActivity_Export', N'NachaReportMenu Page ReturnActivity Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NachaReportMenu_AchTransactionReport', N'NachaReportMenu AchTransactionReport', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NachaReportMenu_AchTransactionReport_Export', N'NachaReportMenu AchTransactionReport Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NachaReportMenu_AchReturnReport', N'NachaReportMenu AchReturnReport', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'NachaReportMenu_AchReturnReport_Export', N'NachaReportMenu AchReturnReport Export', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'getStoreGroup', N'getStoreGroup', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'addStoreGroup', N'addStoreGroup', 1, 1, GetUtcDate(), NULL, NULL, NULL)
,(N'updateStoreGroup', N'updateStoreGroup', 1, 1, GetUtcDate(), NULL, NULL, NULL)

GO

INSERT INTO dbo.Permission ([RoleId],[ClaimId],[IsActive],[CreatedOn])
select 'SuperAdmin',[ClaimId],1,Getutcdate() FROM dbo.[Claim];
go

INSERT INTO dbo.Permission ([RoleId],[ClaimId],[IsActive],[CreatedOn])
select 'Admin',[ClaimId],1,Getutcdate() FROM dbo.[Claim] where ClaimId Not In ('UserMenu_PermissionTab_RoleClaimsAssociation','UserMenu_RolesTab_Create','UserMenu_RolesTab_Edit','UserMenu_RolesTab_View');

go

INSERT INTO dbo.Permission ([RoleId],[ClaimId],[IsActive],[CreatedOn])
select RoleId,'Login',1,Getutcdate() FROM dbo.[Role] where RoleId Not In ('SuperAdmin','Admin');

go

INSERT INTO dbo.APIResourcePermission(APIResourceId, ClaimId, ClientId, AllowAnonymous, IsActive)
VALUES 
 (N'Accountapi_Invoice_AddInvoice', N'', N'papipay_businessmobile', 0, 1)
,(N'Accountapi_Invoice_Cancel', N'', N'papipay_businessmobile', 0, 1)
,(N'Accountapi_Invoice_Decline', N'', N'papipay_businessmobile', 0, 1)
,(N'Accountapi_Invoice_GetInvoice', N'', N'papipay_businessmobile', 0, 1)
,(N'Accountapi_Invoice_InvoiceList', N'', N'papipay_businessmobile', 0, 1)
,(N'Accountapi_Invoice_InvoicePayment', N'', N'papipay_businessmobile', 0, 1)
,(N'Accountapi_Invoice_InvoiceSummary', N'', N'papipay_businessmobile', 0, 1)
,(N'Accountapi_Invoice_RecentInvoiceList', N'', N'papipay_businessmobile', 0, 1)
,(N'Accountapi_Invoice_TodaysInvoiceList', N'', N'papipay_businessmobile', 0, 1)
,(N'Accountapi_Invoice_UpdateInvoice', N'', N'papipay_businessmobile', 0, 1)
,(N'Accountsapi_Invoice_AddInvoice', N' ', N'papipay_businessmobile', 0, 1)
,(N'Accountsapi_Invoice_Cancel', N' ', N'papipay_businessmobile', 0, 1)
,(N'Accountsapi_Invoice_Decline', N' ', N'papipay_businessmobile', 0, 1)
,(N'Accountsapi_Invoice_GetInvoice', N' ', N'papipay_businessmobile', 0, 1)
,(N'Accountsapi_Invoice_GetInvoiceNo', N' ', N'papipay_businessmobile', 0, 1)
,(N'Accountsapi_Invoice_InvoiceList', N' ', N'papipay_businessmobile', 0, 1)
,(N'Accountsapi_Invoice_InvoicePayment', N' ', N'papipay_businessmobile', 0, 1)
,(N'Accountsapi_Invoice_InvoiceSummary', N' ', N'papipay_businessmobile', 0, 1)
,(N'Accountsapi_Invoice_RecentInvoiceList', N' ', N'papipay_businessmobile', 0, 1)
,(N'Accountsapi_Invoice_TodaysInvoiceList', N' ', N'papipay_businessmobile', 0, 1)
,(N'Accountsapi_Invoice_UpdateInvoice', N' ', N'papipay_businessmobile', 0, 1)
,(N'Accountapi_InvoiceTransaction_InvoiceTransactionList', N'', N'papipay_businessmobile', 0, 1)
,(N'Financeapi_AdminProcess_Credit', N'ConsumerProfileMenu_Edit_CashRewardTab_EarnRedeem', N' ', 0, 1)
,(N'Financeapi_AdminProcess_Debit', N'ConsumerProfileMenu_Edit_CashRewardTab_EarnRedeem', N' ', 0, 1)
,(N'FinanceApi_Wallet_AcceptAmountTransferRequest', N' ', N'papipay_businessmobile', 0, 1)
,(N'FinanceApi_Wallet_AcceptAmountTransferRequest', N' ', N'papipay_consumermobile', 0, 1)
,(N'FinanceApi_Wallet_DeclineAmountTransfer', N' ', N'papipay_businessmobile', 0, 1)
,(N'FinanceApi_Wallet_DeclineAmountTransfer', N' ', N'papipay_consumermobile', 0, 1)
,(N'FinanceApi_Wallet_GetCashRewardDetailsByStoreId', N' ', N'papipay_m2m', 0, 1)
,(N'FinanceApi_Wallet_GetCashRewardDetailsByTransactionIds', N' ', N'papipay_m2m', 0, 1)
,(N'FinanceApi_Wallet_GetExpiredWalletCredits', N' ', N'papipay_businessmobile', 0, 1)
,(N'FinanceApi_Wallet_GetExpiredWalletCredits', N' ', N'papipay_consumermobile', 0, 1)
,(N'FinanceApi_Wallet_GetExpiredWalletCredits', N' ', N'papipay_m2m', 0, 1)
,(N'FinanceApi_Wallet_GetExpiringWalletCredits', N' ', N'papipay_businessmobile', 0, 1)
,(N'FinanceApi_Wallet_GetExpiringWalletCredits', N' ', N'papipay_consumermobile', 0, 1)
,(N'FinanceApi_Wallet_GetExpiringWalletCredits', N' ', N'papipay_m2m', 0, 1)
,(N'FinanceApi_Wallet_GetLinkUserTransfer', N' ', N'papipay_businessmobile', 0, 1)
,(N'FinanceApi_Wallet_GetLinkUserTransfer', N' ', N'papipay_consumermobile', 0, 1)
,(N'FinanceApi_Wallet_GetLinkUserTransfer', N' ', N'papipay_m2m', 0, 1)
,(N'FinanceApi_Wallet_GetPendingAmountTransferRequestsByUserId', N' ', N'papipay_businessmobile', 0, 1)
,(N'FinanceApi_Wallet_GetPendingAmountTransferRequestsByUserId', N' ', N'papipay_consumermobile', 0, 1)
,(N'FinanceApi_Wallet_GetReceivedWalletCreditsByUserId', N' ', N'papipay_m2m', 0, 1)
,(N'FinanceApi_Wallet_GetRequestedAmountListByUserId', N' ', N'papipay_businessmobile', 0, 1)
,(N'FinanceApi_Wallet_GetRequestedAmountListByUserId', N' ', N'papipay_consumermobile', 0, 1)
,(N'FinanceApi_Wallet_GetTransferWalletCreditsByUserId', N' ', N'papipay_m2m', 0, 1)
,(N'FinanceApi_Wallet_GetUserWallet', N' ', N'papipay_businessmobile', 0, 1)
,(N'FinanceApi_Wallet_GetUserWallet', N' ', N'papipay_consumermobile', 0, 1)
,(N'FinanceApi_Wallet_GetUserWallet', N' ', N'papipay_m2m', 0, 1)
,(N'FinanceApi_Wallet_GetUserWalletList', N' ', N'papipay_m2m', 0, 1)
,(N'Financeapi_Wallet_GetUserWalletList', N'ConsumerProfileMenu_Edit_CashRewardTab_View', N'', 0, 1)
,(N'Financeapi_Wallet_GetWalletCreditByTransactionId', N'', N'papipay_businessmobile', 0, 1)
,(N'Financeapi_Wallet_GetWalletCreditByTransactionId', N'', N'papipay_consumermobile', 0, 1)
,(N'FinanceApi_Wallet_GetWalletCreditByTransactionId', N' ', N'papipay_m2m', 0, 1)
,(N'FinanceApi_Wallet_GetWalletCreditByTransactionIds', N' ', N'papipay_m2m', 0, 1)
,(N'FinanceApi_Wallet_GetWalletCreditsByStoreId', N' ', N'papipay_m2m', 0, 1)
,(N'FinanceApi_Wallet_GetWalletHistory', N' ', N'papipay_businessmobile', 0, 1)
,(N'FinanceApi_Wallet_GetWalletHistory', N' ', N'papipay_consumermobile', 0, 1)
,(N'FinanceApi_Wallet_GetWalletHistory', N' ', N'papipay_m2m', 0, 1)
,(N'FinanceApi_Wallet_GetWalletHistory', N'ConsumerProfileMenu_Edit_CashRewardTab_View', N' ', 0, 1)
,(N'FinanceApi_Wallet_PreAuthPayment', N' ', N'papipay_m2m', 0, 1)
,(N'FinanceApi_Wallet_ProcessPayment', N' ', N'papipay_m2m', 0, 1)
,(N'FinanceApi_Wallet_RequestAmountTransfer', N' ', N'papipay_businessmobile', 0, 1)
,(N'FinanceApi_Wallet_RequestAmountTransfer', N' ', N'papipay_consumermobile', 0, 1)
,(N'FinanceApi_Wallet_Transfer', N' ', N'papipay_businessmobile', 0, 1)
,(N'FinanceApi_Wallet_Transfer', N' ', N'papipay_consumermobile', 0, 1)
,(N'FinanceApi_Wallet_VoidPayment', N' ', N'papipay_m2m', 0, 1)
,(N'HelpSupportApi_AppConfiguration_Get', N' ', N' ', 1, 1)
,(N'HelpSupportApi_AppConfiguration_Get', N'AppConfigurationMenu', N' ', 0, 1)
,(N'HelpSupportApi_AppConfiguration_Get', N'SupportMenu_HelpSupport_Call', N' ', 0, 1)
,(N'HelpSupportApi_AppConfiguration_Patch', N'AppConfigurationMenu_CreateUpdate', N' ', 0, 1)
,(N'HelpSupportApi_AppConfiguration_Post', N'AppConfigurationMenu_CreateUpdate', N' ', 0, 1)
,(N'HelpSupportApi_ApplicationSupport_Get', N'ApplicationSupportMenu', N' ', 0, 1)
,(N'HelpSupportApi_ApplicationSupport_GetByFilter', N' ', N' ', 1, 1)
,(N'HelpSupportApi_ApplicationSupport_Post', N'ApplicationSupportMenu_Create', N' ', 0, 1)
,(N'HelpSupportApi_ApplicationSupport_Post', N'ApplicationSupportMenu_Edit', N' ', 0, 1)
,(N'HelpSupportApi_Tutorial_Get', N' ', N' ', 1, 1)
,(N'HelpSupportApi_Tutorial_Get', N'TutorialMenu', N' ', 0, 1)
,(N'HelpSupportApi_Tutorial_Get', N'TutorialMenu_Export ', N' ', 0, 1)
,(N'HelpSupportApi_Tutorial_GetTutorialById', N'TutorialMenu_Edit', N' ', 0, 1)
,(N'HelpSupportApi_Tutorial_GetTutorialCategory', N'TutorialMenu_Edit', N' ', 0, 1)
,(N'HelpSupportApi_Tutorial_Patch', N'TutorialMenu_Edit', N' ', 0, 1)
,(N'HelpSupportapi_Tutorial_Post', N'TutorialMenu_Create', N'', 0, 1)
,(N'IdentityServerApi_AccountUser_Claims', N'UserMenu_PermissionTab_View', N'', 0, 1)
,(N'IdentityServerApi_AccountUser_Claims', N'UserMenu_RolesTab_View', N'', 0, 1)
,(N'IdentityServerApi_AccountUser_ConsumerCase', N'', N'papipay_businessmobile', 0, 1)
,(N'IdentityServerApi_AccountUser_ConsumerCase', N' ', N'papipay_consumermobile', 0, 1)
,(N'IdentityServerApi_AccountUser_RoleType', N'UserMenu_RolesTab_Create', N' ', 0, 1)
,(N'IdentityServerApi_AccountUser_UpdateUserDevice', N' ', N'papipay_businessmobile', 0, 1)
,(N'IdentityServerApi_AccountUser_UpdateUserDevice', N' ', N'papipay_consumermobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_ActivePortalUsers', N'ActiveUserMenu', N'', 0, 1)
,(N'IdentityServerApi_AccountUsers_ChangePassword', N' ', N'papipay_businessmobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_ChangePassword', N' ', N'papipay_consumermobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_ChangePassword', N'ChangePassword', N' ', 0, 1)
,(N'IdentityServerApi_AccountUsers_Claims', N'UserMenu_PermissionTab_View ', N' ', 0, 1)
,(N'IdentityServerApi_AccountUsers_ConsumerRegister', N' ', N' ', 1, 1)
,(N'IdentityServerApi_AccountUsers_CopyRoleClaim', N'UserMenu_PermissionTab_RoleClaimsAssociation', N'', 0, 1)
,(N'IdentityServerApi_AccountUsers_CreateConsumerCase', N' ', N'papipay_businessmobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_CreateConsumerCase', N' ', N'papipay_consumermobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_GenerateConsumerPasswordResetCode', N' ', N' ', 1, 1)
,(N'IdentityServerApi_AccountUsers_GenerateEmailCode', N' ', N' ', 1, 1)
,(N'IdentityServerApi_AccountUsers_GenerateMobileCode', N' ', N' ', 1, 1)
,(N'IdentityServerApi_AccountUsers_GenerateMobileUpdateVerificationCode', N' ', N'papipay_businessmobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_GenerateMobileUpdateVerificationCode', N' ', N'papipay_consumermobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_GetAllUserWithPaging', N'ConsumerProfileMenu', N'', 0, 1)
,(N'IdentityServerApi_AccountUsers_GetUserByEmailOrPhone', N'BusinessUserMenu_Edit', N' ', 0, 1)
,(N'IdentityServerApi_AccountUsers_GetUserByEmailOrPhone', N'BusinessUserProfileMenu', N' ', 0, 1)
,(N'IdentityServerApi_AccountUsers_GetUserById', N' ', N'papipay_businessmobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_GetUserById', N' ', N'papipay_consumermobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_GetUserById', N' ', N'papipay_m2m', 0, 1)
,(N'IdentityServerApi_AccountUsers_GetUserById', N'ConsumerProfileMenu_Edit', N' ', 0, 1)
,(N'IdentityServerApi_AccountUsers_GetUserById', N'Login', N' ', 0, 1)
,(N'IdentityServerApi_AccountUsers_GetUserFromToken', N' ', N'papipay_businessmobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_GetUserFromToken', N' ', N'papipay_consumermobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_GetUserFromToken', N'Login', N' ', 0, 1)
,(N'IdentityServerApi_AccountUsers_GetUserList', N' ', N'papipay_m2m', 0, 1)
,(N'IdentityServerApi_AccountUsers_Logout', N'ActiveUserMenu_UserLogout', N'', 0, 1)
,(N'IdentityServerApi_AccountUsers_MapRoleClaim', N'UserMenu_PermissionTab_RoleClaimsAssociation', N' ', 0, 1)
,(N'IdentityServerApi_AccountUsers_RemoveAccount', N' ', N'papipay_businessmobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_RemoveAccount', N' ', N'papipay_consumermobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_ResetConsumerPassword', N' ', N'papipay_consumermobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_Roles', N'UserMenu_PermissionTab_View ', N' ', 0, 1)
,(N'IdentityServerApi_AccountUsers_Roles', N'UserMenu_RolesTab_Edit', N' ', 0, 1)
,(N'IdentityServerApi_AccountUsers_Roles', N'UserMenu_RolesTab_View ', N' ', 0, 1)
,(N'IdentityServerApi_AccountUsers_Roles', N'UserMenu_UsersTab_Create', N' ', 0, 1)
,(N'IdentityServerApi_AccountUsers_StoreUserRegister', N' ', N'papipay_m2m', 0, 1)
,(N'IdentityServerApi_AccountUsers_SyncUserById', N' ', N'papipay_m2m', 0, 1)
,(N'IdentityServerApi_AccountUsers_UpdateMobileNumber', N' ', N'papipay_businessmobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_UpdateMobileNumber', N' ', N'papipay_consumermobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_UpdatePreferredLanguage', N'', N'papipay_businessmobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_UpdatePreferredLanguage', N' ', N'papipay_consumermobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_UpdatePreferredLanguage', N' ', N'papipay_m2m', 0, 1)
,(N'IdentityServerApi_AccountUsers_UpdateProfile', N' ', N'papipay_businessmobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_UpdateProfile', N' ', N'papipay_consumermobile', 0, 1)
,(N'IdentityServerApi_AccountUsers_UpdateProfile', N' ', N'papipay_m2m', 0, 1)
,(N'IdentityServerApi_AccountUsers_UpdateProfileUsingPortal', N'ConsumerProfileMenu_Edit_UpdateProfileTab_Update', N' ', 0, 1)
,(N'IdentityServerApi_AccountUsers_VerifyEmail', N' ', N' ', 1, 1)
,(N'IdentityServerApi_AccountUsers_VerifyMobile', N' ', N' ', 1, 1)
,(N'IdentityServerApi_AccountUsers_VerifyResetPasswordCode', N' ', N' ', 1, 1)
,(N'IdentityServerApi_AccountUsers_GetUsersByRole', N'', N'papipay_m2m', 0, 1)
,(N'IdentityServerApi_LinkUser_GenerateCode', N' ', N'papipay_businessmobile', 0, 1)
,(N'IdentityServerApi_LinkUser_GenerateCode', N' ', N'papipay_consumermobile', 0, 1)
,(N'IdentityServerApi_LinkUser_Get', N' ', N'papipay_businessmobile', 0, 1)
,(N'IdentityServerApi_LinkUser_Get', N' ', N'papipay_consumermobile', 0, 1)
,(N'IdentityServerApi_LinkUser_Remove', N' ', N'papipay_businessmobile', 0, 1)
,(N'IdentityServerApi_LinkUser_Remove', N' ', N'papipay_consumermobile', 0, 1)
,(N'IdentityServerApi_LinkUser_Request', N' ', N'papipay_businessmobile', 0, 1)
,(N'IdentityServerApi_LinkUser_Request', N' ', N'papipay_consumermobile', 0, 1)
,(N'IdentityServerApi_LinkUser_Verify', N' ', N'papipay_businessmobile', 0, 1)
,(N'IdentityServerApi_LinkUser_Verify', N' ', N'papipay_consumermobile', 0, 1)
,(N'IdentityServerApi_LinkUser_Verify', N'', N'papipay_m2m', 0, 1)
,(N'MarketingApi_CashBack_rules', N' ', N'papipay_businessmobile', 0, 1)
,(N'MarketingApi_CashBack_rules', N' ', N'papipay_consumermobile', 0, 1)
,(N'MarketingApi_CashBack_rules', N' ', N'papipay_m2m', 0, 1)
,(N'MarketingApi_Loyalty_CashBackCrietriaByEventId', N'CashRewardSetupMenu_Edit', N' ', 0, 1)
,(N'MarketingApi_Loyalty_GetById', N'CashRewardSetupMenu_Edit', N' ', 0, 1)
,(N'MarketingApi_Loyalty_GetCashBackEvent', N'CashRewardSetupMenu', N' ', 0, 1)
,(N'MarketingApi_Loyalty_GetCashBackEvent', N'PromotionMenu', N' ', 0, 1)
,(N'Marketingapi_Loyalty_GetLoyalty', N'CashRewardSetupMenu', N'', 0, 1)
,(N'MarketingApi_Loyalty_Post', N'CashRewardSetupMenu_Create', N' ', 0, 1)
,(N'MarketingApi_Marketting_Appdownload', N' ', N' ', 1, 1)
,(N'MarketingApi_Offer_ByFilter', N' ', N'papipay_businessmobile', 0, 1)
,(N'MarketingApi_Offer_ByFilter', N' ', N'papipay_consumermobile', 0, 1)
,(N'MarketingApi_Offer_ByFilter', N'MarketingMenu_OffersAndDeals', N' ', 0, 1)
,(N'MarketingApi_Offer_ByFilter', N'MarketingMenu_OffersAndDeals_Export', N' ', 0, 1)
,(N'MarketingApi_Offer_ByFilter', N'MarketingMenu_OffersAndDeals_SendOffer', N' ', 0, 1)
,(N'MarketingApi_Offer_InactiveOfferByFilter', N'MarketingMenu_AllInactiveOffers', N' ', 0, 1)
,(N'MarketingApi_Offer_InactiveOfferByFilter', N'MarketingMenu_AllInactiveOffers_Export', N' ', 0, 1)
,(N'MarketingApi_Offer_InactiveOfferByFilter', N'MarketingMenu_AllInactiveOffers_Update', N' ', 0, 1)
,(N'MarketingApi_Offer_Patch', N'MarketingMenu_OffersAndDeals_Update', N' ', 0, 1)
,(N'MarketingApi_Offer_Post', N'MarketingMenu_OffersAndDeals_Create', N' ', 0, 1)
,(N'MarketingApi_Offer_SearchByFilter', N' ', N'papipay_businessmobile', 0, 1)
,(N'MarketingApi_Offer_SearchByFilter', N' ', N'papipay_consumermobile', 0, 1)
,(N'MarketingApi_Promotion_GetById', N'PromotionMenu_Edit', N' ', 0, 1)
,(N'MarketingApi_Promotion_GetPromotion', N'PromotionMenu', N' ', 0, 1)
,(N'Marketingapi_Promotion_Patch', N'PromotionMenu_Edit', N'', 0, 1)
,(N'MarketingApi_Promotion_Post', N'PromotionMenu_Create', N' ', 0, 1)
,(N'MarketingApi_Promotion_Post', N'TutorialMenu_Create', N' ', 0, 1)
,(N'MppaApi_Commander_messages', N'Report_Menu_POSMessage', N' ', 0, 1)
,(N'MppaApi_Commander_messages', N'Report_Menu_POSMessage_Export', N' ', 0, 1)
,(N'MppaApi_Commander_site-connections', N' ', N'papipay_m2m', 0, 1)
,(N'MppaApi_Commander_SiteStatuses', N' ', N'papipay_m2m', 0, 1)
,(N'MppaApi_Commander_Status', N' ', N'papipay_m2m', 0, 1)
,(N'MppaApi_Commander_Statuses', N' ', N'papipay_m2m', 0, 1)
,(N'MppaApi_Commander_user-connections', N' ', N'papipay_m2m', 0, 1)
,(N'Mppaapi_GasPump_ByStoreId', N'StoreMenu_CompanyTab_StoreManage', N' ', 0, 1)
,(N'Mppaapi_GasPump_Get', N'StoreMenu_CompanyTab_StoreManage', N'', 0, 1)
,(N'Mppaapi_GasPump_Get', N'StoreMenu_StoreTab_StoreManage', N'', 0, 1)
,(N'Mppaapi_GasPump_Patch', N'StoreMenu_CompanyTab_StoreManage', N'', 0, 1)
,(N'Mppaapi_GasPump_Patch', N'StoreMenu_StoreTab_StoreManage', N'', 0, 1)
,(N'Mppaapi_GasPump_Post', N'StoreMenu_CompanyTab_StoreManage', N'', 0, 1)
,(N'Mppaapi_GasPump_Post', N'StoreMenu_StoreTab_StoreManage', N'', 0, 1)
,(N'Mppaapi_HostConfigration_Adapter', N'StoreMenu_CompanyTab_StoreManage', N' ', 0, 1)
,(N'Mppaapi_HostConfigration_ByStoreId', N'StoreMenu_CompanyTab_StoreManage', N'', 0, 1)
,(N'Mppaapi_HostConfigration_ByStoreId', N'StoreMenu_StoreTab_StoreManage', N'', 0, 1)
,(N'Mppaapi_HostConfigration_Patch', N'StoreMenu_CompanyTab_StoreManage', N'', 0, 1)
,(N'Mppaapi_HostConfigration_Patch', N'StoreMenu_StoreTab_StoreManage', N'', 0, 1)
,(N'Mppaapi_HostConfigration_Post', N'StoreMenu_CompanyTab_StoreManage', N'', 0, 1)
,(N'Mppaapi_HostConfigration_Post', N'StoreMenu_StoreTab_StoreManage', N'', 0, 1)
,(N'Mppaapi_POS_ByStoreId', N'StoreMenu_CompanyTab_StoreManage', N' ', 0, 1)
,(N'Mppaapi_POS_Get', N'StoreMenu_CompanyTab_StoreManage', N'', 0, 1)
,(N'Mppaapi_POS_Get', N'StoreMenu_StoreTab_StoreManage', N'', 0, 1)
,(N'Mppaapi_POS_Patch', N'StoreMenu_CompanyTab_StoreManage', N'', 0, 1)
,(N'Mppaapi_POS_Patch', N'StoreMenu_StoreTab_StoreManage', N'', 0, 1)
,(N'Mppaapi_POS_Post', N'StoreMenu_CompanyTab_StoreManage', N'', 0, 1)
,(N'Mppaapi_POS_Post', N'StoreMenu_StoreTab_StoreManage', N'', 0, 1)
,(N'MppaApi_SiteProduct_BySiteId', N' ', N'papipay_m2m', 0, 1)
,(N'Mppaapi_SiteProduct_BySiteId', N'StoreMenu_CompanyTab_StoreManage', N' ', 0, 1)
,(N'MppaApi_SiteProduct_GetById', N' ', N'papipay_m2m', 0, 1)
,(N'NotificationApi_Notifications_CreateCaseForGuestUser', N' ', N' ', 1, 1)
,(N'Notificationapi_Notifications_EmailNotification', N'SupportMenu_HelpSupport_SendMessage', N' ', 0, 1)
,(N'NotificationApi_Notifications_Get', N' ', N'papipay_businessmobile', 0, 1)
,(N'NotificationApi_Notifications_Get', N' ', N'papipay_consumermobile', 0, 1)
,(N'NotificationApi_Notifications_GetNotificationType', N' ', N'papipay_m2m', 0, 1)
,(N'NotificationApi_Notifications_GetNotificationType', N'NotificationMessageMenu', N' ', 0, 1)
,(N'NotificationApi_Notifications_GetNotificationType', N'NotificationMessageMenu_Export ', N' ', 0, 1)
,(N'NotificationApi_Notifications_mark-read', N' ', N'papipay_businessmobile', 0, 1)
,(N'NotificationApi_Notifications_mark-read', N' ', N'papipay_consumermobile', 0, 1)
,(N'NotificationApi_Notifications_ReportIssue', N' ', N' ', 1, 1)
,(N'Notificationapi_Notifications_SendOfferNotification', N'MarketingMenu_AppNotification Send', N' ', 0, 1)
,(N'NotificationApi_Notifications_unread-count', N' ', N'papipay_businessmobile', 0, 1)
,(N'NotificationApi_Notifications_unread-count', N' ', N'papipay_consumermobile', 0, 1)
,(N'NotificationApi_Notifications_UpdateEmailBanner', N' ', N'papipay_m2m', 0, 1)
,(N'NotificationApi_Notifications_UpdateNotificationType', N'NotificationMessageMenu_Edit', N' ', 0, 1)
,(N'Notificationapi_UserNotificationConfigration_Get', N'', N'papipay_businessmobile', 0, 1)
,(N'Notificationapi_UserNotificationConfigration_Get', N'', N'papipay_consumermobile', 0, 1)
,(N'Notificationapi_UserNotificationConfigration_Post', N'', N'papipay_businessmobile', 0, 1)
,(N'Notificationapi_UserNotificationConfigration_Post', N'', N'papipay_consumermobile', 0, 1)
,(N'Paymentapi_Nacha_NachaConfig', N'', N'papipay_m2m', 0, 1)
,(N'Paymentapi_Payment_AddCard', N' ', N'papipay_businessmobile', 0, 1)
,(N'Paymentapi_Payment_AddCard', N' ', N'papipay_consumermobile', 0, 1)
,(N'Paymentapi_Payment_AddNickName', N' ', N'papipay_businessmobile', 0, 1)
,(N'Paymentapi_Payment_AddNickName', N' ', N'papipay_consumermobile', 0, 1)
,(N'Paymentapi_Payment_DeclineAch', N' ', N' ', 1, 1)
,(N'Paymentapi_Payment_DeleteACHBankDetails', N' ', N'papipay_businessmobile', 0, 1)
,(N'Paymentapi_Payment_DeleteACHBankDetails', N' ', N'papipay_consumermobile', 0, 1)
,(N'Paymentapi_Payment_DeleteUserPaymentMethod', N' ', N'papipay_businessmobile', 0, 1)
,(N'Paymentapi_Payment_DeleteUserPaymentMethod', N' ', N'papipay_consumermobile', 0, 1)
,(N'Paymentapi_Payment_DwollaCustomerByFilter', N' ', N'papipay_businessmobile', 0, 1)
,(N'Paymentapi_Payment_DwollaCustomerByFilter', N' ', N'papipay_consumermobile', 0, 1)
,(N'Paymentapi_Payment_error', N' ', N' ', 1, 1)
,(N'Paymentapi_Payment_GetDefaultUserPaymentMethod', N' ', N'papipay_businessmobile', 0, 1)
,(N'Paymentapi_Payment_GetDefaultUserPaymentMethod', N' ', N'papipay_consumermobile', 0, 1)
,(N'Paymentapi_Payment_incorrectinfo', N' ', N' ', 1, 1)
,(N'Paymentapi_Payment_PaymentMethod', N'', N'papipay_businessmobile', 0, 1)
,(N'Paymentapi_Payment_PaymentMethod', N'', N'papipay_consumermobile', 0, 1)
,(N'Paymentapi_Payment_PaymentMethod', N'', N'papipay_m2m', 0, 1)
,(N'Paymentapi_Payment_PaymentMethod', N'DefaultBilling_Setup_Menu', N' ', 0, 1)
,(N'Paymentapi_Payment_PaymentMethod', N'StoreMenu_CompanyTab_StoreManage', N' ', 0, 1)
,(N'Paymentapi_Payment_SaveToken', N' ', N'papipay_businessmobile', 0, 1)
,(N'Paymentapi_Payment_SaveToken', N' ', N'papipay_consumermobile', 0, 1)
,(N'Paymentapi_Payment_SaveTokenACH', N' ', N'papipay_businessmobile', 0, 1)
,(N'Paymentapi_Payment_SaveTokenACH', N' ', N'papipay_consumermobile', 0, 1)
,(N'Paymentapi_Payment_SetDefaultUserPaymentMethod', N' ', N'papipay_businessmobile', 0, 1)
,(N'Paymentapi_Payment_SetDefaultUserPaymentMethod', N' ', N'papipay_consumermobile', 0, 1)
,(N'Paymentapi_Payment_success', N' ', N' ', 1, 1)
,(N'Paymentapi_Payment_TransactionToken', N' ', N'papipay_businessmobile', 0, 1)
,(N'Paymentapi_Payment_TransactionToken', N' ', N'papipay_consumermobile', 0, 1)
,(N'Paymentapi_Payment_UserPaymentMethod', N' ', N'papipay_businessmobile', 0, 1)
,(N'Paymentapi_Payment_UserPaymentMethod', N' ', N'papipay_consumermobile', 0, 1)
,(N'Paymentapi_Payment_WebhookCreditCardSalesDetails', N' ', N' ', 1, 1)
,(N'Paymentapi_PaymentMethod_GetStorePaymentMethod', N'', N'papipay_m2m', 0, 1)
,(N'Paymentapi_PaymentMethod_PaymentGateway', N'', N'papipay_m2m', 0, 1)
,(N'Paymentapi_PaymentMethod_PaymentMethodConfiguration', N'', N'papipay_m2m', 0, 1)
,(N'Paymentapi_PaymentMethod_StorePaymentMethodByStoreId', N'', N'papipay_m2m', 0, 1)
,(N'Paymentapi_PaymentProcess_FailedPaymentList', N'Report_Menu_PaymentFailed', N' ', 0, 1)
,(N'Paymentapi_PaymentProcess_FailedPaymentList', N'Report_Menu_PaymentFailed_Export', N' ', 0, 1)
,(N'Paymentapi_PaymentProcess_Finalize', N'', N'papipay_m2m', 0, 1)
,(N'Paymentapi_PaymentProcess_Payment', N'', N'papipay_m2m', 0, 1)
,(N'Paymentapi_PaymentProcess_PaymentDue', N'', N'papipay_businessmobile', 0, 1)
,(N'Paymentapi_PaymentProcess_PaymentDue', N'', N'papipay_consumermobile', 0, 1)
,(N'Paymentapi_PaymentProcess_PreAuth', N'', N'papipay_m2m', 0, 1)
,(N'Paymentapi_PaymentProcess_Validate', N'', N'papipay_m2m', 0, 1)
,(N'Paymentapi_ResellerConfig_AllResellerConfigs', N'', N'papipay_m2m', 0, 1)
,(N'Paymentapi_ResellerConfig_Get', N'', N'papipay_m2m', 0, 1)
,(N'Paymentapi_ResellerConfig_Get', N'ResellerMenu_Create', N' ', 0, 1)
,(N'Paymentapi_ResellerConfig_Get', N'ResellerMenu_Edit', N' ', 0, 1)
,(N'Paymentapi_ResellerConfig_Get', N'ResellerMenu_Edit_ResellerConfigTab_Update', N' ', 0, 1)
,(N'Paymentapi_ResellerConfig_Get', N'ResellerMenu_Edit_UpdateResellerTab_View', N' ', 0, 1)
,(N'Paymentapi_ResellerConfig_Post', N'ResellerMenu_Edit_ResellerConfigTab_Update', N'', 0, 1)
,(N'Paymentapi_SaleAgentConfig_AllSaleAgentConfigs', N'', N'papipay_m2m', 0, 1)
,(N'Paymentapi_SaleAgentConfig_Get', N'SaleAgentMenu_Edit_SaleAgentConfigTab_Update', N' ', 0, 1)
,(N'Paymentapi_SaleAgentConfig_Post', N'SaleAgentMenu_Edit_SaleAgentConfigTab_Update', N'', 0, 1)
,(N'Paymentapi_StoreConfig_AllStoreConfigs', N'', N'papipay_m2m', 0, 1)
,(N'Paymentapi_StoreConfig_Get', N'', N'papipay_m2m', 0, 1)
,(N'Paymentapi_StoreConfig_Get', N'StoreMenu_CompanyTab_StoreManage', N' ', 0, 1)
,(N'Paymentapi_StoreConfig_Get', N'StoreMenu_StoreTab_StoreManage', N'', 0, 1)
,(N'Paymentapi_StoreConfig_MasterStoreConfig', N'', N'papipay_m2m', 0, 1)
,(N'Paymentapi_StoreConfig_Post', N'StoreMenu_CompanyTab_StoreManage', N'', 0, 1)
,(N'Paymentapi_StoreConfig_Post', N'StoreMenu_StoreTab_StoreManage', N'', 0, 1)
,(N'ReportApi_Consumer_Get', N'MarketingMenu_AppNotification Send', N' ', 0, 1)
,(N'ReportApi_Consumer_Get', N'MarketingMenu_OffersAndDeals_SendOffer', N' ', 0, 1)
,(N'Reportapi_ErrorLog_ErrorLog', N' ', N' ', 1, 1)
,(N'ReportApi_ErrorLog_GetErrorLog', N'Report_Menu_MobileErrorMessage', N' ', 0, 1)
,(N'ReportApi_ErrorLog_GetErrorLog', N'Report_Menu_MobileErrorMessage_Export', N' ', 0, 1)
,(N'ReportApi_Transaction_Get', N' ', N'papipay_businessmobile', 0, 1)
,(N'ReportApi_Transaction_Get', N' ', N'papipay_consumermobile', 0, 1)
,(N'ReportApi_Transaction_Get', N'ConsumerProfileMenu_Edit_TransactionHistoryTab_View', N' ', 0, 1)
,(N'ReportApi_Transaction_TransactionSearch', N'Report_Menu_ConsumerTransation_ExportPrint', N' ', 0, 1)
,(N'ReportApi_Transaction_TransactionSearch', N'Report_Menu_ConsumerTransation_View', N' ', 0, 1)
,(N'Transactionapi_ResellerBilling_reseller-all-monthly-invoice-pdf', N'ProcessesMenu_ResellerMonthlyBilling_MonthlyPdf', N' ', 0, 1)
,(N'Transactionapi_ResellerBilling_reseller-bills', N'ProcessesMenu_ResellerMonthlyBilling_Export', N' ', 0, 1)
,(N'Transactionapi_ResellerBilling_reseller-bills', N'ProcessesMenu_ResellerMonthlyBilling_GetBill', N' ', 0, 1)
,(N'Transactionapi_ResellerBilling_reseller-generate', N'ProcessesMenu_ResellerMonthlyBilling_GenerateBill', N' ', 0, 1)
,(N'Transactionapi_ResellerBilling_reseller-monthly-invoice-pdf', N'ProcessesMenu_ResellerMonthlyBilling_ViewPdf', N' ', 0, 1)
,(N'Transactionapi_ResellerBilling_reseller-preview-nacha', N'ProcessesMenu_ResellerMonthlyBilling_PreviewNachaFile', N' ', 0, 1)
,(N'Transactionapi_ResellerBilling_reseller-process-payment', N'ProcessesMenu_ResellerMonthlyBilling_ProcessSettlement', N' ', 0, 1)
,(N'Transactionapi_ResellerBilling_reseller-update-needreview', N'ProcessesMenu_ResellerMonthlyBilling_ReviewUnreview', N' ', 0, 1)
,(N'Transactionapi_ResellerBilling_reseller-update-unpaid', N'ProcessesMenu_ResellerMonthlyBilling_Paid', N' ', 0, 1)
,(N'Transactionapi_ResellerBilling_reseller-view-nacha', N'ProcessesMenu_ResellerMonthlyBilling_ViewNacha', N' ', 0, 1)
,(N'Transactionapi_ResellerFee_Get', N'DefaultReseller_Setup_Edit', N' ', 0, 1)
,(N'Transactionapi_ResellerFee_Get', N'ResellerMenu_Edit_ResellerTab_ResellerFee_Create', N' ', 0, 1)
,(N'Transactionapi_ResellerFee_Patch', N'DefaultReseller_Setup_Edit', N' ', 0, 1)
,(N'Transactionapi_ResellerFee_Post', N'DefaultReseller_Setup_Add', N' ', 0, 1)
,(N'Transactionapi_ResellerFee_Post', N'ResellerMenu_Edit_ResellerTab_ResellerFee_Create', N' ', 0, 1)
,(N'Transactionapi_ResellerFee_reseller-byresellerid', N'ResellerMenu_Edit', N' ', 0, 1)
,(N'Transactionapi_ResellerFee_reseller-byresellerid', N'ResellerMenu_Edit_UpdateResellerTab_View', N' ', 0, 1)
,(N'Transactionapi_ResellerFee_reseller-default', N'DefaultReseller_Setup_Menu', N' ', 0, 1)
,(N'Transactionapi_ResellerFee_reseller-default-clone', N'ResellerMenu_Edit_ResellerTab_ResellerBillingFee_GetDefault', N' ', 0, 1)
,(N'Transactionapi_SaleAgentBilling_saleagent-all-monthly-invoice-pdf', N'ProcessesMenu_SaleAgentMonthlyBilling_MonthlyPdf', N' ', 0, 1)
,(N'Transactionapi_SaleAgentBilling_saleagent-bills', N'ProcessesMenu_SaleAgentMonthlyBilling_Export', N' ', 0, 1)
,(N'Transactionapi_SaleAgentBilling_saleagent-bills', N'ProcessesMenu_SaleAgentMonthlyBilling_GetBill', N' ', 0, 1)
,(N'Transactionapi_SaleAgentBilling_saleagent-bills', N'ProcessesMenu_SaleAgentMonthlyBilling_Paid', N' ', 0, 1)
,(N'Transactionapi_SaleAgentBilling_saleagent-bills', N'ProcessesMenu_SaleAgentMonthlyBilling_ProcessSettlement', N' ', 0, 1)
,(N'Transactionapi_SaleAgentBilling_saleagent-bills', N'ProcessesMenu_SaleAgentMonthlyBilling_ReviewUnreview', N' ', 0, 1)
,(N'Transactionapi_SaleAgentBilling_saleagent-generate', N'ProcessesMenu_SaleAgentMonthlyBilling_GenerateBill', N' ', 0, 1)
,(N'Transactionapi_SaleAgentBilling_saleagent-monthly-invoice-pdf', N'ProcessesMenu_SaleAgentMonthlyBilling_ViewPdf', N' ', 0, 1)
,(N'Transactionapi_SaleAgentBilling_saleagent-preview-nacha', N'ProcessesMenu_SaleAgentMonthlyBilling_PreviewNachaFile', N' ', 0, 1)
,(N'Transactionapi_SaleAgentBilling_saleagent-process-payment', N'ProcessesMenu_SaleAgentMonthlyBilling_ProcessSettlement', N'', 0, 1)
,(N'Transactionapi_SaleAgentBilling_saleagent-update-needreview', N'ProcessesMenu_SaleAgentMonthlyBilling_ReviewUnreview', N' ', 0, 1)
,(N'Transactionapi_SaleAgentBilling_saleagent-update-unpaid', N'ProcessesMenu_SaleAgentMonthlyBilling_Paid', N' ', 0, 1)
,(N'Transactionapi_SaleAgentBilling_saleagent-view-nacha', N'ProcessesMenu_SaleAgentMonthlyBilling_ViewNacha', N' ', 0, 1)
,(N'Transactionapi_SaleAgentFee_Get', N'SaleAgentMenu_Edit_StoreListTab_SaleAgentFee_Create', N'', 0, 1)
,(N'Transactionapi_SaleAgentFee_Get', N'SaleAgentMenu_Edit_StoreListTab_SeleAgentFee_Create', N' ', 0, 1)
,(N'Transactionapi_SaleAgentFee_Patch', N'DefaultSaleAgent_Setup_Edit', N' ', 0, 1)
,(N'Transactionapi_SaleAgentFee_Patch', N'SaleAgentMenu_Edit_StoreListTab_SaleAgentFee_Create', N'', 0, 1)
,(N'Transactionapi_SaleAgentFee_Post', N'DefaultSaleAgent_Setup_Add', N' ', 0, 1)
,(N'Transactionapi_SaleAgentFee_Post', N'SaleAgentMenu_Edit_StoreListTab_SaleAgentFee_Create', N'', 0, 1)
,(N'Transactionapi_SaleAgentFee_salesagent-default', N'DefaultSaleAgent_Setup_Edit', N' ', 0, 1)
,(N'Transactionapi_SaleAgentFee_salesagent-default', N'DefaultSaleAgent_Setup_Menu', N' ', 0, 1)
,(N'Transactionapi_SaleAgentFee_salesagent-default', N'SaleAgentMenu_Edit_StoreListTab_SaleAgentFee_GetDefault', N' ', 0, 1)
,(N'Transactionapi_SettlementInvoice_DetailsBySettlementRequestId', N'Report_Menu_Eod_Report_TransactionDetails', N' ', 0, 1)
,(N'Transactionapi_SettlementInvoice_eod-preview-nacha', N'ProcessesMenu_EODSettelement_PreviewNachaFile', N' ', 0, 1)
,(N'Transactionapi_SettlementInvoice_eod-preview-nacha', N'ProcessesMenu_EODSettelement_ProcessSettlement', N' ', 0, 1)
,(N'Transactionapi_SettlementInvoice_EODReport', N'Report_Menu_Eod_Report', N' ', 0, 1)
,(N'Transactionapi_SettlementInvoice_EODReport', N'Report_Menu_Eod_Report_Export', N' ', 0, 1)
,(N'Transactionapi_SettlementInvoice_eod-settlement', N'ProcessesMenu_EODSettelement_ReviewUnreview', N' ', 0, 1)
,(N'Transactionapi_SettlementInvoice_eod-settlement-request', N'ProcessesMenu_EODSettelement', N' ', 0, 1)
,(N'Transactionapi_SettlementInvoice_eod-settlement-request', N'ProcessesMenu_EODSettelement_Export', N' ', 0, 1)
,(N'Transactionapi_SettlementInvoice_eod-settlement-request', N'ProcessesMenu_EODSettelement_Paid', N' ', 0, 1)
,(N'Transactionapi_SettlementInvoice_eod-settlement-request', N'ProcessesMenu_EODSettelement_PreviewNachaFile', N' ', 0, 1)
,(N'Transactionapi_SettlementInvoice_eod-settlement-request', N'ProcessesMenu_EODSettelement_ReviewUnreview', N' ', 0, 1)
,(N'Transactionapi_SettlementInvoice_eod-settlement-request', N'ProcessesMenu_EODSettelement_ViewNacha', N' ', 0, 1)
,(N'Transactionapi_SettlementInvoice_eod-settlement-request', N'ProcessesMenu_EODSettelement_ViewPdf', N' ', 0, 1)
,(N'Transactionapi_SettlementInvoice_eod-view-nacha', N'ProcessesMenu_EODSettelement_ViewNacha', N'', 0, 1)
,(N'Transactionapi_SettlementInvoice_preview-eod-invoice-pdf', N'ProcessesMenu_EODSettelement_ViewPdf', N' ', 0, 1)
,(N'Transactionapi_SettlementInvoice_update-eod-needreview', N'ProcessesMenu_EODSettelement_ReviewUnreview', N'', 0, 1)
,(N'Transactionapi_SettlementInvoice_update-eod-unpaid', N'ProcessesMenu_EODSettelement_Paid', N' ', 0, 1)
,(N'Transactionapi_StoreBilling_store-all-monthly-invoice-pdf', N'ProcessesMenu_StoreMonthlyBilling_MonthlyPdf', N'', 0, 1)
,(N'Transactionapi_StoreBilling_store-bills', N'ProcessesMenu_StoreMonthlyBilling_Export', N' ', 0, 1)
,(N'Transactionapi_StoreBilling_store-bills', N'ProcessesMenu_StoreMonthlyBilling_GetBill', N' ', 0, 1)
,(N'Transactionapi_StoreBilling_store-bills', N'ProcessesMenu_StoreMonthlyBilling_MonthlyPdf', N' ', 0, 1)
,(N'Transactionapi_StoreBilling_store-bills', N'ProcessesMenu_StoreMonthlyBilling_Paid', N' ', 0, 1)
,(N'Transactionapi_StoreBilling_store-bills', N'ProcessesMenu_StoreMonthlyBilling_PreviewNachaFile', N' ', 0, 1)
,(N'Transactionapi_StoreBilling_store-bills', N'ProcessesMenu_StoreMonthlyBilling_ProcessSettlement', N' ', 0, 1)
,(N'Transactionapi_StoreBilling_store-bills', N'ProcessesMenu_StoreMonthlyBilling_ReviewUnreview', N' ', 0, 1)
,(N'Transactionapi_StoreBilling_store-bills', N'ProcessesMenu_StoreMonthlyBilling_ViewNacha', N' ', 0, 1)
,(N'Transactionapi_StoreBilling_store-bills', N'ProcessesMenu_StoreMonthlyBilling_ViewPdf', N' ', 0, 1)
,(N'Transactionapi_StoreBilling_store-generate', N'ProcessesMenu_StoreMonthlyBilling_GenerateBill', N' ', 0, 1)
,(N'Transactionapi_StoreBilling_store-monthly-invoice-pdf', N'ProcessesMenu_StoreMonthlyBilling_ViewPdf', N'', 0, 1)
,(N'Transactionapi_StoreBilling_store-preview-nacha', N'ProcessesMenu_StoreMonthlyBilling_PreviewNachaFile', N'', 0, 1)
,(N'Transactionapi_StoreBilling_store-process-payment', N'ProcessesMenu_StoreMonthlyBilling_ProcessSettlement', N'', 0, 1)
,(N'Transactionapi_StoreBilling_store-update-needreview', N'ProcessesMenu_StoreMonthlyBilling_ReviewUnreview', N'', 0, 1)
,(N'Transactionapi_StoreBilling_store-view-nacha', N'ProcessesMenu_StoreMonthlyBilling_ViewNacha', N'', 0, 1)
,(N'Transactionapi_StoreBillingFee_Get', N'DefaultBilling_Setup_Edit', N' ', 0, 1)
,(N'Transactionapi_StoreBillingFee_Patch', N'DefaultBilling_Setup_Edit', N' ', 0, 1)
,(N'Transactionapi_StoreBillingFee_Post', N'DefaultBilling_Setup_Add', N' ', 0, 1)
,(N'Transactionapi_StoreBillingFee_storebillingFeeId', N'StoreMenu_CompanyTab_StoreManage', N'', 0, 1)
,(N'Transactionapi_StoreBillingFee_storebillingFeeId', N'StoreMenu_StoreTab_StoreManage', N'', 0, 1)
,(N'Transactionapi_StoreBillingFee_store-bystoreid', N'StoreMenu_CompanyTab_StoreManage', N' ', 0, 1)
,(N'Transactionapi_StoreBillingFee_store-bystoreid', N'StoreMenu_StoreTab_StoreManage', N'', 0, 1)
,(N'Transactionapi_StoreBillingFee_store-default', N'DefaultBilling_Setup_Menu', N' ', 0, 1)
,(N'Transactionapi_StoreBillingFee_store-default-clone', N'StoreMenu_CompanyTab_StoreManage', N'', 0, 1)
,(N'Transactionapi_StoreBillingFee_store-default-clone', N'StoreMenu_StoreTab_StoreManage', N'', 0, 1)
,(N'Transactionapi_Transaction_DetailsByStoreBillingId', N'ProcessesMenu_StoreMonthlyBilling_TransactionDetails', N' ', 0, 1)
,(N'Transactionapi_Transaction_LastTransactionByFilter', N'', N'papipay_m2m', 0, 1)
,(N'Transactionapi_Transaction_MonthlyTransactionBySiteId', N'Report_Menu_MonthlyStatementReport', N' ', 0, 1)
,(N'Transactionapi_Transaction_MonthlyTransactionBySiteId', N'Report_Menu_MonthlyStatementReport_Export', N' ', 0, 1)
,(N'Transactionapi_Transaction_Receipt', N'', N'papipay_consumermobile', 0, 1)
,(N'Transactionapi_Transaction_Receipt', N'Report_Menu_ConsumerTransation_Receipt', N' ', 0, 1)
,(N'Transactionapi_Transaction_StoreByTransactionIds', N' ', N'papipay_m2m', 0, 1)
,(N'Transactionapi_Transaction_TransactionReconcileReport', N'Report_Menu_SettlementReconcile', N' ', 0, 1)
,(N'Transactionapi_Transaction_TransactionReconcileReport', N'Report_Menu_SettlementReconcile_Export', N' ', 0, 1)
,(N'Transactionapi_NachaReports_NachaDailyProcessingReport', N'NachaReportMenu_DailyProcessingActivity', N' ', 0, 1)
,(N'Transactionapi_NachaReports_NachaDailyProcessingReport', N'NachaReportMenu_DailyProcessingActivity_Export', N' ', 0, 1)
,(N'Transactionapi_NachaReports_NachaDailyReturnReport', N'NachaReportMenu_DailyReturnActivity', N' ', 0, 1)
,(N'Transactionapi_NachaReports_NachaDailyReturnReport', N'NachaReportMenu_DailyReturnActivity_Export', N' ', 0, 1)
,(N'Transactionapi_NachaReports_ACHTransactionReport', N'NachaReportMenu_AchTransactionReport', N' ', 0, 1)
,(N'Transactionapi_NachaReports_ACHTransactionReport', N'NachaReportMenu_AchTransactionReport_Export', N' ', 0, 1)
,(N'Transactionapi_NachaReports_ACHReturnReport', N'NachaReportMenu_AchReturnReport', N' ', 0, 1)
,(N'Transactionapi_NachaReports_ACHReturnReport', N'NachaReportMenu_AchReturnReport_Export', N' ', 0, 1)
,(N'Transactionapi_DashBoard_TransactionDetails', N'DashboardView', N' ', 0, 1)
,(N'UserStoreApi_Amenity_Get', N'', N'', 1, 1)
,(N'UserStoreApi_CategoryTypeLevel_Get', N'ResellerMenu_Create', N'', 0, 1)
,(N'UserStoreApi_CategoryTypeLevel_Get', N'ResellerMenu_Edit', N'', 0, 1)
,(N'UserStoreApi_CategoryTypeLevel_Get', N'ResellerMenu_Edit_UpdateResellerTab_View', N'', 0, 1)
,(N'UserStoreApi_CategoryTypeLevel_Get', N'SaleAgentMenu_Create', N'', 0, 1)
,(N'UserStoreApi_CategoryTypeLevel_Get', N'SaleAgentMenu_Edit_UpdateSaleAgentTab_Update', N'', 0, 1)
,(N'UserStoreApi_CategoryTypeLevel_Get', N'SaleAgentMenu_Edit_UpdateSaleAgentTab_View', N'', 0, 1)
,(N'UserStoreApi_CategoryTypeLevel_Get', N'UserMenu_UsersTab_Create', N'', 0, 1)
,(N'UserStoreApi_Companies_AddOwnerCompanies', N'UserMenu_StoreOwnerTab_ComapanyAssociation', N'', 0, 1)
,(N'UserStoreApi_Companies_ByCompanyId', N'', N'papipay_m2m', 0, 1)
,(N'UserStoreApi_Companies_ByCompanyId', N'StoreMenu_CompanyTab_Edit', N'', 0, 1)
,(N'UserStoreApi_Companies_CompanyAutoComplete', N'ResellerMenu_Edit', N'', 0, 1)
,(N'UserStoreApi_Companies_CompanyAutoComplete', N'ResellerMenu_Edit_ResellerCompanyListTab_View', N'', 0, 1)
,(N'UserStoreApi_Companies_Get', N'UserMenu_StoreOwnerTab_ComapanyAssociation', N'', 0, 1)
,(N'UserStoreApi_Companies_GetAllOwners', N'UserMenu_StoreOwnerTab_View ', N'', 0, 1)
,(N'UserStoreApi_Companies_Patch', N'StoreMenu_CompanyTab_Edit', N'', 0, 1)
,(N'UserStoreApi_Companies_Post', N'StoreMenu_CompanyTab_Create', N'', 0, 1)
,(N'UserStoreApi_Companies_UpdateReseller', N'ResellerMenu_Edit_ResellerCompanyListTab_Create', N'', 0, 1)
,(N'UserStoreApi_Companies_WithPaging', N'MarketingMenu_AllInactiveOffers_Update', N'', 0, 1)
,(N'UserStoreApi_Companies_WithPaging', N'MarketingMenu_OffersAndDeals_Create', N'', 0, 1)
,(N'UserStoreApi_Companies_WithPaging', N'MarketingMenu_OffersAndDeals_Update', N'', 0, 1)
,(N'UserStoreApi_Companies_WithPaging', N'StoreMenu_CompanyTab_Export ', N'', 0, 1)
,(N'UserStoreApi_Companies_WithPaging', N'StoreMenu_CompanyTab_View', N'', 0, 1)
,(N'UserStoreApi_Country_Get', N'ConsumerProfileMenu_Edit_UpdateProfileTab_View', N'', 0, 1)
,(N'UserStoreApi_Country_Get', N'ResellerMenu_Create', N'', 0, 1)
,(N'UserStoreApi_Country_Get', N'ResellerMenu_Edit', N'', 0, 1)
,(N'UserStoreApi_Country_Get', N'ResellerMenu_Edit_UpdateResellerTab_View', N'', 0, 1)
,(N'UserStoreApi_Country_Get', N'StoreMenu_StoreTab_Edit', N'', 0, 1)
,(N'UserStoreApi_Region_Get', N'MarketingMenu_AllInactiveOffers_Update', N'', 0, 1)
,(N'UserStoreApi_Region_Get', N'MarketingMenu_OffersAndDeals_Create', N'', 0, 1)
,(N'UserStoreApi_Region_Get', N'MarketingMenu_OffersAndDeals_Update', N'', 0, 1)
,(N'UserStoreApi_Region_Get', N'SaleAgentMenu_Create', N'', 0, 1)
,(N'UserStoreApi_Region_Get', N'SaleAgentMenu_Edit_UpdateSaleAgentTab_Update', N'', 0, 1)
,(N'UserStoreApi_Region_Get', N'SaleAgentMenu_Edit_UpdateSaleAgentTab_View', N'', 0, 1)
,(N'UserStoreApi_Region_Get', N'UserMenu_UsersTab_Create', N'', 0, 1)
,(N'UserStoreApi_Reseller_Get', N'', N'papipay_m2m', 0, 1)
,(N'UserStoreApi_Reseller_Get', N'ResellerMenu_Create', N'', 0, 1)
,(N'UserStoreApi_Reseller_Get', N'ResellerMenu_Edit', N'', 0, 1)
,(N'UserStoreApi_Reseller_Get', N'ResellerMenu_Edit_ResellerCompanyListTab_Create', N'', 0, 1)
,(N'UserStoreApi_Reseller_Get', N'ResellerMenu_Edit_UpdateResellerTab_View', N'', 0, 1)
,(N'UserStoreApi_Reseller_GetAllResellers', N'ResellerMenu', N'', 0, 1)
,(N'UserStoreApi_Reseller_GetAllResellers', N'ResellerMenu_Export ', N'', 0, 1)
,(N'UserStoreApi_Reseller_Patch', N'ResellerMenu_Edit_UpdateResellerTab_Update', N'', 0, 1)
,(N'UserStoreApi_Reseller_Post', N'ResellerMenu_Create', N'', 0, 1)
,(N'UserStoreApi_Reseller_Resellers', N'', N'papipay_m2m', 0, 1)
,(N'UserStoreApi_SaleAgent_Get', N'', N'papipay_m2m', 0, 1)
,(N'UserStoreApi_SaleAgent_Get', N'SaleAgentMenu_Edit', N'', 0, 1)
,(N'UserStoreApi_SaleAgent_Get', N'SaleAgentMenu_Edit_StoreListTab_View', N'', 0, 1)
,(N'UserStoreApi_SaleAgent_Get', N'StoreMenu_CompanyTab_View', N'', 0, 1)
,(N'UserStoreApi_SaleAgent_GetAllSaleAgents', N'SaleAgentMenu', N'', 0, 1)
,(N'UserStoreApi_SaleAgent_GetAllSaleAgents', N'SaleAgentMenu_Export ', N'', 0, 1)
,(N'UserStoreApi_SaleAgent_Patch', N'SaleAgentMenu_Edit_UpdateSaleAgentTab_Update', N'', 0, 1)
,(N'UserStoreApi_SaleAgent_Post', N'SaleAgentMenu_Create', N'', 0, 1)
,(N'UserStoreApi_SaleAgent_SaleAgents', N'', N'papipay_m2m', 0, 1)
,(N'UserStoreApi_State_ByCountryId', N'ResellerMenu_Edit', N'', 0, 1)
,(N'UserStoreApi_State_ByCountryId', N'SaleAgentMenu_Create', N'', 0, 1)
,(N'UserStoreApi_State_ByCountryId', N'SaleAgentMenu_Edit_UpdateSaleAgentTab_Update', N'', 0, 1)
,(N'UserStoreApi_State_ByCountryId', N'SaleAgentMenu_Edit_UpdateSaleAgentTab_View', N'', 0, 1)
,(N'UserStoreApi_State_Get', N'StoreMenu_CompanyTab_View', N'', 0, 1)
,(N'UserStoreApi_State_Get', N'StoreMenu_StoreTab_View', N'', 0, 1)
,(N'UserStoreApi_State_StateAutoComplete', N'StoreMenu_CompanyTab_View', N'', 0, 1)
,(N'UserStoreApi_State_StateAutoComplete', N'StoreMenu_StoreTab_Edit', N'', 0, 1)
,(N'UserStoreApi_State_StateAutoComplete', N'StoreMenu_StoreTab_View', N'', 0, 1)
,(N'UserStoreApi_State_StateAutoComplete', N'UserMenu_UsersTab_View', N'', 0, 1)
,(N'UserStoreApi_StoreCategory_Get', N'StoreMenu_StoreTab_Edit', N'', 0, 1)
,(N'UserStoreApi_StoreCategory_Get', N'StoreMenu_StoreTab_View', N'', 0, 1)
,(N'UserStoreApi_Stores_ByCompanyId', N'MarketingMenu_AllInactiveOffers_Update', N'', 0, 1)
,(N'UserStoreApi_Stores_ByCompanyId', N'MarketingMenu_OffersAndDeals_Create', N'', 0, 1)
,(N'UserStoreApi_Stores_ByCompanyId', N'MarketingMenu_OffersAndDeals_Update', N'', 0, 1)
,(N'UserStoreApi_Stores_GetMasterStoreInfo', N'', N'papipay_m2m', 0, 1)
,(N'UserStoreApi_Stores_GetStoreInfo', N'', N'papipay_m2m', 0, 1)
,(N'UserStoreApi_Stores_GetStoresPrimaryDetailsBySiteIds', N'', N'papipay_m2m', 0, 1)
,(N'UserStoreApi_Stores_Hours', N'StoreMenu_CompanyTab_StoreManage', N'', 0, 1)
,(N'UserStoreApi_Stores_HoursPatch', N'StoreMenu_CompanyTab_StoreManage', N'', 0, 1)
,(N'UserStoreApi_Stores_HoursPatch', N'StoreMenu_StoreTab_StoreManage', N'', 0, 1)
,(N'UserStoreApi_Stores_HoursPost', N'StoreMenu_CompanyTab_StoreManage', N'', 0, 1)
,(N'UserStoreApi_Stores_HoursPost', N'StoreMenu_StoreTab_StoreManage', N'', 0, 1)
,(N'UserStoreApi_Stores_patch', N'StoreMenu_CompanyTab_StoreEdit', N'', 0, 1)
,(N'UserStoreApi_Stores_patch', N'StoreMenu_StoreTab_Edit', N'', 0, 1)
,(N'UserStoreApi_Stores_PosSystem', N'StoreMenu_StoreTab_View', N'', 0, 1)
,(N'UserStoreApi_Stores_Post', N'StoreMenu_CompanyTab_StoreCreate', N'', 0, 1)
,(N'UserStoreApi_Stores_search', N'', N'', 1, 1)
,(N'UserStoreApi_Stores_StoreAutoComplete', N'SaleAgentMenu_Create', N'', 0, 1)
,(N'UserStoreApi_Stores_StoreAutoComplete', N'SaleAgentMenu_Edit_UpdateSaleAgentTab_Update', N'', 0, 1)
,(N'UserStoreApi_Stores_StoreAutoComplete', N'SaleAgentMenu_Edit_UpdateSaleAgentTab_View', N'', 0, 1)
,(N'UserStoreApi_Stores_StoreAutoComplete', N'UserMenu_UsersTab_Create', N'', 0, 1)
,(N'UserStoreApi_Stores_StoreBySiteId', N'StoreMenu_CompanyTab_StoreManage', N'', 0, 1)
,(N'UserStoreApi_Stores_StoreBySiteId', N'StoreMenu_StoreTab_StoreManage', N'', 0, 1)
,(N'UserStoreApi_Stores_storeId', N'StoreMenu_CompanyTab_StoreEdit', N'', 0, 1)
,(N'UserStoreApi_Stores_storeId', N'StoreMenu_CompanyTab_StoreManage', N'', 1, 1)
,(N'UserStoreApi_Stores_StoreInfos', N'', N'papipay_m2m', 0, 1)
,(N'UserStoreApi_Stores_StoresList', N'', N'', 1, 1)
,(N'UserStoreApi_Stores_StoreSummary', N'', N'', 1, 1)
,(N'UserStoreApi_Stores_UpdateSaleAgent', N'SaleAgentMenu_Edit_StoreListTab_Create', N'', 0, 1)
,(N'UserStoreApi_Stores_WeekDays', N'StoreMenu_CompanyTab_StoreManage', N'', 0, 1)
,(N'UserStoreApi_Stores_WithPaging', N'SystemStatusMenu', N'', 0, 1)
,(N'UserStoreApi_Stores_WithPaging', N'SystemStatusMenu_Export ', N'', 0, 1)
,(N'UserStoreApi_Stores_GetCompaniesByStoreId', N'', N'papipay_m2m', 0, 1)
,(N'UserStoreApi_StoreGroup_Get', N'getStoreGroup', N'', 0, 1)
,(N'UserStoreApi_StoreGroup_StoreGroupAutoComplete', N'getStoreGroup', N'', 0, 1)
,(N'UserStoreApi_StoreGroup_Post', N'addStoreGroup', N'', 0, 1)
,(N'UserStoreApi_StoreGroup_Patch', N'updateStoreGroup', N'', 0, 1)
,(N'UserStoreApi_TimeZone_Get', N'', N'papipay_businessmobile', 0, 1)
,(N'UserStoreApi_TimeZone_Get', N'', N'papipay_consumermobile', 0, 1)
,(N'UserStoreApi_TimeZone_Get', N'StoreMenu_StoreTab_Edit', N'', 0, 1)
,(N'UserStoreApi_TimeZone_Get', N'StoreMenu_StoreTab_View', N'', 0, 1)
,(N'UserStoreApi_Title_Get', N'SaleAgentMenu_Create', N'', 0, 1)
,(N'UserStoreApi_Title_Get', N'SaleAgentMenu_Edit_UpdateSaleAgentTab_Update', N'', 0, 1)
,(N'UserStoreApi_Title_Get', N'SaleAgentMenu_Edit_UpdateSaleAgentTab_View', N'', 0, 1)
,(N'UserStoreApi_Title_Get', N'UserMenu_UsersTab_Create', N'', 0, 1)
,(N'UserStoreApi_Users_ByUserId', N'UserMenu_UsersTab_Edit', N'', 0, 1)
,(N'UserStoreApi_Users_Patch', N'UserMenu_UsersTab_Edit', N'', 0, 1)
,(N'UserStoreApi_Users_Post', N'UserMenu_UsersTab_Create', N'', 0, 1)
,(N'UserStoreApi_Users_WithPaging', N'UserMenu_UsersTab_Export ', N'', 0, 1)
,(N'UserStoreApi_Users_WithPaging', N'UserMenu_UsersTab_View', N'', 0, 1)
,(N'UserStoreApi_Users_WithPrimaryDetails', N'UserMenu_UsersTab_Edit', N'', 0, 1)
go
 IF (XACT_STATE()) = -1  
    BEGIN  
        PRINT N'The transaction is in an uncommittable state. Rolling back transaction.'  
        ROLLBACK TRANSACTION;  
    END;  
  
    -- Test whether the transaction is committable.
    -- You may want to commit a transaction in a catch block if you want to commit changes to statements that ran prior to the error.
 IF (XACT_STATE()) = 1  
    BEGIN  
        PRINT N'The transaction is committable. Committing transaction.'  
        COMMIT TRANSACTION;     
    END;


