using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using PapiPay.ApplicationCore.ServiceCollection;
using PapiPay.Service.Clients;

namespace TestClient.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddApplicationCore(Configuration);
            services.AddAuthentication(config =>
            {
                config.DefaultScheme = "Cookie";
                config.DefaultChallengeScheme = "oidc";
            })
            .AddCookie("Cookie")
            .AddOpenIdConnect("oidc", config =>
            {
                config.Authority = Configuration.GetValue<string>("IdentityConfig:BaseUrl");
                config.ClientId = Configuration.GetValue<string>("OpenId:ClientId");
                config.ClientSecret = Configuration.GetValue<string>("OpenId:ClientSecret");
                config.SaveTokens = true;
                config.ResponseType = "code";
                config.SignedOutCallbackPath = "/Home/Index";
                //config.RemoteAuthenticationTimeout = TimeSpan.FromSeconds(10);
                config.GetClaimsFromUserInfoEndpoint = true;
                //config.CallbackPath = "/signin-oidc";
                config.Scope.Clear();
                config.Scope.Add("openid");
                config.Scope.Add("profile");
                config.Scope.Add(Configuration.GetValue<string>("IdentityConfig:Scope"));
                //config.CallbackPath = Configuration.GetValue<string>("OpenId:CallbackPath");
            });

            services.AddHttpClient();
            services.AddIdentityClient(Configuration).AddPaymentClient(Configuration);

            services.AddControllersWithViews().AddRazorRuntimeCompilation();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseHttpsRedirection();

            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthentication();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapDefaultControllerRoute();
            });
        }
    }
}
