#!/bin/bash
cd ..
echo "################################################DotNet Build########################################################"

dotnet build

echo "##############################################DotNet Publish########################################################"

dotnet publish

echo "################################################Docker Build########################################################"

docker build -f Deployment/dockerfile -t papipay/identitymicroservices .

echo "##################################################Docker Tag########################################################"

docker tag papipay/identitymicroservices papipayregistry00.azurecr.io/papipay/identitymicroservices
echo "successfully tagged the image "

echo "#################################################Docker Push########################################################"

docker push papipayregistry00.azurecr.io/papipay/identitymicroservices

