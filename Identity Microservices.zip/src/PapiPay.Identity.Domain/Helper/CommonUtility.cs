﻿using FluentValidation.Results;
using PapiPay.ApplicationCore.Domain.Exceptions;
using System;
using System.Globalization;

namespace PapiPay.Identity.Domain.Helper
{
    public static class CommonUtility
    {
        public static DateTime? GetDate(string strdate)
        {
            string[] inputformate = { "M/d/yyyy h:mm:ss tt", "MM/dd/yyyy h:mm:ss tt", "MM-dd-yyyy", "M-d-yyyy" };

            return DateTime.TryParseExact(strdate, inputformate, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date) ? date : null;
        }

        public static DateTime? ValidateDateOfBirth(string date)
        {
            if (!string.IsNullOrWhiteSpace(date))
            {
                string[] inputformat = { "M/d/yyyy h:mm:ss tt", "MM/dd/yyyy h:mm:ss tt", "MM-dd-yyyy", "M-d-yyyy" };

                return DateTime.TryParseExact(date, inputformat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime parsedate)
                    ? (DateTime?)parsedate
                    : throw new ValidationException(new ValidationFailure("DOB", $"Invalid Date format in DOB. it should be MM-dd-yyyy."));
            }

            return null;
        }
    }
}
