﻿namespace PapiPay.Identity.Domain.Helper
{
    public class GoogleAPIOption
    {
        public string GoogleAPIKey { get; set; }
    }
}
