﻿namespace PapiPay.Identity.Domain.Helper
{
    public class AppSetting
    {
        public bool EnableInvoicingFeature { get; set; }
    }
}
