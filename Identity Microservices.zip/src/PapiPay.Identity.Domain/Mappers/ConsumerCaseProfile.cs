﻿using AutoMapper;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Domain.Mappers
{
    public class ConsumerCaseProfile : Profile
    {
        public ConsumerCaseProfile()
        {
            CreateMap<ConsumerCase, ConsumerCaseModel>().ReverseMap();
            CreateMap<ConsumerCase, SalesForceCaseModel>().ReverseMap();
        }
    }
}
