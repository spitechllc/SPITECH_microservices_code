﻿using AutoMapper;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Domain.Mappers
{
    public class LinkUserProfile : Profile
    {
        public LinkUserProfile()
        {
            CreateMap<LinkUser, LinkUserModel>().ReverseMap();
        }
    }
}
