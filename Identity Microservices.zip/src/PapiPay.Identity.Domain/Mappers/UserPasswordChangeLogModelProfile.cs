﻿using AutoMapper;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Models;
using PapiPay.Identity.Domain.Models.Consumers;
using PapiPay.Identity.Domain.Models.Stores;

namespace PapiPay.Identity.Domain.Mappers
{
    public class UserPasswordChangeLogModelProfile : Profile
    {
        public UserPasswordChangeLogModelProfile()
        {
            CreateMap<UserPasswordChangeLog, UserPasswordChangeLogModel>().ReverseMap();
        }
    }
}
