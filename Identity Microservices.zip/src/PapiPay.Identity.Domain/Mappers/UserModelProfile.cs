﻿using AutoMapper;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Models;
using PapiPay.Identity.Domain.Models.Consumers;
using PapiPay.Identity.Domain.Models.Stores;

namespace PapiPay.Identity.Domain.Mappers
{
    public class UserModelProfile : Profile
    {
        public UserModelProfile()
        {
            CreateMap<UserModel, ConsumerUserResponseModel>().ReverseMap();
            CreateMap<UserModel, StoreUserResponseModel>().ReverseMap();
            CreateMap<User, UserModel>().ForMember(dest => dest.Devices, opt => opt.MapFrom(src => src.UserDevices))
.ReverseMap();
            CreateMap<UserProfile, UserProfileModel>().ReverseMap();
            CreateMap<UserProfile, ConsumerUserProfileModel>().ReverseMap();
            CreateMap<UserProfile, StoreUserProfileModel>().ReverseMap();
            CreateMap<UserProfileModel, ConsumerUserProfileModel>().ReverseMap();
            CreateMap<UserProfileModel, StoreUserProfileModel>().ReverseMap();
            CreateMap<Role, RoleModel>().ReverseMap();
            CreateMap<Claim, ClaimModel>().ReverseMap();
            CreateMap<User, UserSearchResult>().ReverseMap();
            CreateMap<RoleType, RoleTypeModel>().ReverseMap();
            CreateMap<UserDevice, EventBus.DomainEvents.Models.Identity.UserDeviceModel>().ReverseMap();
            CreateMap<User, ActiveUsersSearchResult>().ReverseMap();
            CreateMap<UserProfile, ActiveUsersSearchResult>().ReverseMap();
            CreateMap<User, UserMOPModel>().ReverseMap();
            CreateMap<User, UserTenantModel>().ReverseMap();
            CreateMap<User, UserConsumerModel>().ReverseMap();
            
        }
    }
}
