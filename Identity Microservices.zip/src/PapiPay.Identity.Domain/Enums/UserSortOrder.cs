﻿using System.Text.Json.Serialization;

namespace PapiPay.Identity.Domain.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum UserSortBy
    {
        None = 0,
        UserId = 1,
        FirstName = 2,
        LastName = 3,
        CreatedDate = 4,
        Mobile = 5,
        Email = 6,
        IsActive = 7,
        Device = 8,
        LoginDatetime=9,
        LastAccessTime=10,
        ActiveDuration=11,
        LastTransactionDate=12
    }
}
