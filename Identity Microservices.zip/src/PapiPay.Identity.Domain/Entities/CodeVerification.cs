﻿using System;

namespace PapiPay.Identity.Domain.Entities
{
    public class CodeVerification : BaseEntity
    {
        public int CodeVerificationId { get; set; }
        public int CodeType { get; set; }
        public string Code { get; set; }
        public int UserId { get; set; }
        public DateTime GeneratedDate { get; set; }
        public DateTime? VerifyDate { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string Receiver { get; set; }
    }
}
