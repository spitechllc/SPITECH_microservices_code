﻿using System.Collections.Generic;

namespace PapiPay.Identity.Domain.Entities
{
    public class Role : BaseEntity
    {
        public string RoleId { get; set; }
        public string RoleName { get; set; }
        public int RoleTypeId { get; set; }
        public virtual IEnumerable<Permission> Permissions { get; set; } = new HashSet<Permission>();
        public virtual IEnumerable<UserRole> UserRoles { get; set; } = new HashSet<UserRole>();
        public virtual RoleType RoleType { get; set; }
    }
}
