﻿using Microsoft.AspNetCore.Components.Web.Virtualization;
using PapiPay.Identity.Domain.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace PapiPay.Identity.Domain.Entities
{
    public class User : BaseEntity
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public bool EnrolledBusinessUser { get; set; }
        public string PasswordHash { get; set; }
        public int UserTypeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
        public bool EmailConfirmed { get; set; }
        public bool MobileConfirmed { get; set; }
        public int AccessFailedCount { get; set; }
        public bool Lockout { get; set; }
        public string PreferedLanguage { get; set; }
        public DateTime? LastTimeAccess { get; set; }
        public DateTime? DOB { get; set; }
        public string TenantName { get; set; }
        public int TenantId { get; set; }

        public virtual UserType UserType { get; set; }
        public virtual UserProfile UserProfile { get; set; }

        public virtual ICollection<UserRole> UserRoles { get; set; } = new HashSet<UserRole>();

        public virtual ICollection<UserDevice> UserDevices { get; set; } = new HashSet<UserDevice>();

        public virtual ICollection<LinkUser> RequestedLinkUsers { get; set; } = new HashSet<LinkUser>();

        public virtual ICollection<LinkUser> AcceptedLinkUsers { get; set; } = new HashSet<LinkUser>();
        [NotMapped]
        public  List<TenantMasterList> TenantMasterLists { get; set; } 
    }
}
