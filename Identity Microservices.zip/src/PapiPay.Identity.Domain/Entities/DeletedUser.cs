﻿using System;

namespace PapiPay.Identity.Domain.Entities
{
    public class DeletedUser : BaseEntity
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public bool EnrolledBusinessUser { get; set; }
        public string PasswordHash { get; set; }
        public int UserTypeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
        public bool EmailConfirmed { get; set; }
        public bool MobileConfirmed { get; set; }
        public int AccessFailedCount { get; set; }
        public bool Lockout { get; set; }
        public string PreferedLanguage { get; set; }
        public DateTime? LastTimeAccess { get; set; }
        public DateTime? DOB { get; set; }
        public string ReasonforDeletion { get; set; }
        public virtual DeletedUserProfile DeletedUserProfile { get; set; }
    }
}
