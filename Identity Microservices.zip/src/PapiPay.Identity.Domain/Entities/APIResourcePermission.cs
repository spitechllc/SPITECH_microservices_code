﻿namespace PapiPay.Identity.Domain.Entities
{
    public class APIResourcePermission : BaseEntity
    {
        public string APIResourceId { get; set; }
        public string ClaimId { get; set; }
        public string ClientId { get; set; }
        public bool AllowAnonymous { get; set; }

        public virtual Claim Claim { get; set; }
    }
}
