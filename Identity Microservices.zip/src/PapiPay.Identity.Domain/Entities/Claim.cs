﻿using System.Collections.Generic;

namespace PapiPay.Identity.Domain.Entities
{
    public class Claim : BaseEntity
    {
        public string ClaimId { get; set; }
        public string ClaimName { get; set; }
        public int DisplayOrder { get; set; }

        public virtual ICollection<Permission> Permissions { get; set; } = new HashSet<Permission>();
        public virtual ICollection<APIResourcePermission> APIResourcePermissions { get; set; } = new HashSet<APIResourcePermission>();
    }
}
