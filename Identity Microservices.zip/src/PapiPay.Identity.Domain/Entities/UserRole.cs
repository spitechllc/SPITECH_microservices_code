﻿namespace PapiPay.Identity.Domain.Entities
{
    public class UserRole : BaseEntity
    {
        public string RoleId { get; set; }
        public int UserId { get; set; }

        public virtual User User { get; set; }
        public virtual Role Role { get; set; }
    }
}
