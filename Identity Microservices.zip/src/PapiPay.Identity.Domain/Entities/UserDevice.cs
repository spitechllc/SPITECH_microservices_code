﻿namespace PapiPay.Identity.Domain.Entities
{
    public class UserDevice : BaseEntity
    {
        public int UserDeviceId { get; set; }
        public int UserId { get; set; }
        public int DeviceTypeId { get; set; }
        public int MobileAppTypeId { get; set; }
        public string DeviceToken { get; set; }
        public bool IsOnline { get; set; }
        public virtual User User { get; set; }
    }
}
