﻿using System.Collections.Generic;

namespace PapiPay.Identity.Domain.Entities
{
    public class UserType : BaseEntity
    {
        public int UserTypeId { get; set; }
        public string UserTypeName { get; set; }

        public virtual ICollection<User> Users { get; set; } = new HashSet<User>();
    }
}
