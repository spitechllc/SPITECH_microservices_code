﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PapiPay.Identity.Domain.Entities
{
    public class TenantMaster
    {
        public int ID { get; set; }
        public string TenantName { get; set; }
        public bool IsActive { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public string UpdatedBy { get; set; }
    }
    public class TenantMasterResponse
    {
        public int ID { get; set; }
        public string TenantName { get; set; }
    }
}
