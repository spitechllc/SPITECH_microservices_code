﻿using PapiPay.ApplicationCore.Domain.Entities;
using System;

namespace PapiPay.Identity.Domain.Entities
{
    public class ConsumerCase : BaseEntity
    {
        public int ConsumerCaseId { get; set; }
        public int UserId { get; set; }
        public string Subject { get; set; }
        public string Description { get; set; }
        public string Reason { get; set; }
        public string Status { get; set; }
        public DateTime ClosedDate { get; set; }
        public bool IsEscalated { get; set; }
        public string Comments { get; set; }
        public int? LastModifiedById { get; set; }
    }
}