﻿using System;

namespace PapiPay.Identity.Domain.Entities
{
    public class UserLoginLog : BaseEntity
    {
        public Guid UserLoginLogsId { get; set; }
        public int UserId { get; set; }
        public string LoginIp { get; set; }
        public DateTime LoginDate { get; set; }
        public bool InvalidLogin { get; set; }
        public bool InvalidLoginCount { get; set; }
    }
}
