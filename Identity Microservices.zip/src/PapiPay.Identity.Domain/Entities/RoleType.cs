﻿using System.Collections.Generic;

namespace PapiPay.Identity.Domain.Entities
{
    public class RoleType : BaseEntity
    {
        public int RoleTypeId { get; set; }
        public string RoleTypeName { get; set; }
        public virtual IEnumerable<Role> Roles { get; set; } = new HashSet<Role>();
    }
}
