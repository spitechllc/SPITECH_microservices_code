﻿namespace PapiPay.Identity.Domain.Entities
{
    public class Permission : BaseEntity
    {
        public string RoleId { get; set; }
        public string ClaimId { get; set; }

        public virtual Claim Claim { get; set; }
        public virtual Role Role { get; set; }
    }
}
