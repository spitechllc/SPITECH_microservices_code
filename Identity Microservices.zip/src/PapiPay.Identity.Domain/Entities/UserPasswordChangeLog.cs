﻿using System;

namespace PapiPay.Identity.Domain.Entities
{
    public class UserPasswordChangeLog : BaseEntity
    {
        public Guid UserPasswordChangeLogId { get; set; }
        public int UserId { get; set; }
        public string OldPassword { get; set; }
        public string NewPassword { get; set; }
        public DateTime ChangeDate { get; set; }
        public bool IsWrongAttempt { get; set; }
    }
}
