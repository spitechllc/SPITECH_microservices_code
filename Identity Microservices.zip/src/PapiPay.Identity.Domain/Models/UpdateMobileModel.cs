﻿namespace PapiPay.Identity.Domain.Models
{
    public class UpdateMobileModel
    {
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
        public string VerificationCode { get; set; }
    }
}

