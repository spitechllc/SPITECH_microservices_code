﻿using PapiPay.EventBus.DomainEvents.Models.Identity;
using System.Collections.Generic;

namespace PapiPay.Identity.Domain.Models
{
    public class UserSearchResult
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
        public bool EmailConfirmed { get; set; }
        public bool MobileConfirmed { get; set; }
        public virtual UserProfileModel UserProfile { get; set; }
        public virtual IEnumerable<UserDeviceModel> Devices { get; set; }
        public virtual IEnumerable<RoleModel> Roles { get; set; }
    }
}
