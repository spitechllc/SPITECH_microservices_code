﻿using System.Collections.Generic;

namespace PapiPay.Identity.Domain.Models
{
    public class SalesforceConsumerModel
    {
        public int totalSize { get; set; }
        public bool done { get; set; }
        public List<Consumer> records { get; set; }
    }

    public class Consumer
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string User_ID__c { get; set; }
    }


}
