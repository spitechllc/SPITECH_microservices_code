﻿using System;

namespace PapiPay.Identity.Domain.Models
{
    public class UserProfileModel
    {
        public string Gender { get; set; }
        public string PhotoUrl { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string Country { get; set; }
        public string CountryCode { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public int? CountryId { get; set; }
        public int? StateId { get; set; }
        public int? CityId { get; set; }
        public string Longitude { get; set; }
        public string Latitude { get; set; }
        public string ZipCode { get; set; }
        public int? CompanyId { get; set; }
        public string Company { get; set; }
        public int? StoreId { get; set; }
        public string Store { get; set; }
        public string BusinessName { get; set; }
        public string BusinessAccountNumber { get; set; }
        public DateTime? LastLogin { get; set; }
        public string LastLoginIP { get; set; }
        public bool? IsLoggedIn { get; set; }
    }
}
