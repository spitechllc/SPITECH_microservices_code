﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PapiPay.Identity.Domain.Models
{
    public class UserMOPModel
    {
        public int UserId { get; set; }
        public string SubjectId => UserId.ToString();
        public bool EnrolledBusinessUser { get; set; }
        public string UserName { get; set; }
        public string PasswordHash { get; set; }
        public int UserTypeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string DisplayName => $"{FirstName} {LastName}";
        public string Email { get; set; }
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
        public bool EmailConfirmed { get; set; }
        public bool MobileConfirmed { get; set; }
        public int AccessFailedCount { get; set; }
        public bool Lockout { get; set; }
        public string PreferedLanguage { get; set; }
        public DateTime? LastTimeAccess { get; set; }
        public bool IsActive { get; set; }
        public DateTime? DOB { get; set; }
        public double TotalWalletAmount { get; set; }
        public bool EnableInvoicingFeature { get; set; }
        public DateTime? CreatedOn { get; set; }
        public string DeviceType { get; set; }
        public string MobileAppType { get; set; }
        public DateTime? LastTransactionDate { get; set; }
        public List<CardDetail> CardDetails { get; set; }
    }

    public class CardDetail
    {
        public int? UserId { get; set; }
        public string CardName { get; set; }
        public string CardType { get; set; }
        public string CardNumber { get; set; }
    }

}
