﻿namespace PapiPay.Identity.Domain.Models
{
    public class PreferredLanguageModel
    {        public string PreferredLanguage { get; set; }
    }
}
