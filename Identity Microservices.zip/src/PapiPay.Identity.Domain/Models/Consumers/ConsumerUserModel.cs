﻿using PapiPay.EventBus.DomainEvents.Enums;

namespace PapiPay.Identity.Domain.Models.Consumers
{
    public class ConsumerUserModel
    {
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
        public string Email { get; set; }
        public string DeviceToken { get; set; }
        public DeviceType DeviceType { get; set; }
        public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PreferedLanguage { get; set; }

        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string Country { get; set; }
        public string CountryCode { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string Longitude { get; set; }
        public string Latitude { get; set; }
        public string ZipCode { get; set; }
        public string DOB { get; set; }
        public string Gender { get; set; }
        public string TenantName { get; set; }
    }
}
