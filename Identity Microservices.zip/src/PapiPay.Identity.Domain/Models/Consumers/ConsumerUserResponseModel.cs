﻿using PapiPay.EventBus.DomainEvents.Models.Identity;
using System;
using System.Collections.Generic;

namespace PapiPay.Identity.Domain.Models.Consumers
{
    public class ConsumerUserResponseModel
    {
        public int UserId { get; set; }
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PreferedLanguage { get; set; }
        public DateTime? DOB { get; set; }
        public bool EnrolledBusinessUser { get; set; }
        public bool EmailConfirmed { get; set; }
        public bool MobileConfirmed { get; set; }
        public virtual ConsumerUserProfileModel UserProfile { get; set; }
        public virtual IEnumerable<UserDeviceModel> Devices { get; set; }
    }
}
