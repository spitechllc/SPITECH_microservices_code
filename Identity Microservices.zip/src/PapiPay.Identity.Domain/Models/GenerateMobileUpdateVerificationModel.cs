﻿namespace PapiPay.Identity.Domain.Models
{
    public class GenerateMobileUpdateVerificationModel
    {
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
    }
}

