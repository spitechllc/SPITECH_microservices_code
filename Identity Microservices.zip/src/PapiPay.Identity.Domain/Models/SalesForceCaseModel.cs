﻿using System;
using System.Collections.Generic;

namespace PapiPay.Identity.Domain.Models
{
    public class SalesForceCaseModel
    {
        public string CaseNumber { get; set; }
        public string Origin { get; set; }
        public string OwnerId { get; set; }
        public string Reason { get; set; }
        public string Case_Status__c { get; set; }
        public object AccountId { get; set; }
        public string Consumer__c { get; set; }
        public object ContactEmail { get; set; }
        public object ContactFax { get; set; }
        public object ContactMobile { get; set; }
        public object ContactId { get; set; }
        public object ContactPhone { get; set; }
        public string CreatedById { get; set; }
        public object ClosedDate { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Description { get; set; }
        public bool IsEscalated { get; set; }
        public object Comments { get; set; }
        public object Language { get; set; }
        public string LastModifiedById { get; set; }
        public object ParentId { get; set; }
        public string Priority { get; set; }
        public string Status { get; set; }
        public string Subject { get; set; }
        public string Support_Level__c { get; set; }
        public string Type { get; set; }
        public object SuppliedEmail { get; set; }
    }
    public class SalesForceCaseModels
    {
        public int totalSize { get; set; }
        public bool done { get; set; }
        public List<SalesForceCaseModel> records { get; set; }
    }
}
