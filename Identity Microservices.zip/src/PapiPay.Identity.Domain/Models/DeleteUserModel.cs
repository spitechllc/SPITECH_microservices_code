﻿namespace PapiPay.Identity.Domain.Models
{
    public class DeleteUserModel
    {
        public int UserId { get; set; }
        public string ReasonforDeletion { get; set; }
    }
}
