﻿using System;

namespace PapiPay.Identity.Domain.Models
{
    public class UserLoginLogModel
    {
        public int UserId { get; set; }
        public string LoginIp { get; set; }
        public DateTime LoginDate { get; set; }
    }
}
