﻿using System;

namespace PapiPay.Identity.Domain.Models
{
    public class UserPasswordChangeLogModel 
    {
        public int UserId { get; set; }
        public string OldPassword { get; set; }
        public string NewPassword { get; set; }
        public DateTime ChangeDate { get; set; }
        public bool IsWrongAttempt { get; set; }
    }
}
