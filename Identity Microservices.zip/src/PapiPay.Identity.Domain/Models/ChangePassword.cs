﻿namespace PapiPay.Identity.Domain.Models
{
    public class ChangePassword
    {
        public string Password { get; set; }
        public string NewPassword { get; set; }
    }
}
