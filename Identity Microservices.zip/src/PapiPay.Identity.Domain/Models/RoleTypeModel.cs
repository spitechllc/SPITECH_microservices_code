﻿namespace PapiPay.Identity.Domain.Models
{
    public class RoleTypeModel
    {
        public int RoleTypeId { get; set; }
        public string RoleTypeName { get; set; }
    }
}
