﻿namespace PapiPay.Identity.Domain.Models
{
    public class ClaimModel
    {
        public string ClaimId { get; set; }
        public string ClaimName { get; set; }
        public int DisplayOrder { get; set; }
    }
}
