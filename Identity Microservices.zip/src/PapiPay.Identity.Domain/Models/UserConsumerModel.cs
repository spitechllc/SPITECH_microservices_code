﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PapiPay.Identity.Domain.Models
{
    public class UserConsumerModel
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string DisplayName => $"{FirstName} {LastName}";
        public string Email { get; set; }
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
        public bool EmailConfirmed { get; set; }
        public bool MobileConfirmed { get; set; }
        public bool IsActive { get; set; }
        public string TenantName { get; set; }
        public decimal TotalCreditAmount { get; set; }
        public decimal TotalRedeemedAmount { get; set; }
        public decimal TotalReceivedAmount { get; set; }
        public decimal TotalSharedAmount { get; set; }
        public decimal TotalExpiredAmount { get; set; }
        public decimal TotalPromotionalAmount { get; set; }
        public decimal TotalAvailableAmount { get; set; }
    }
}
