﻿
using System.Collections.Generic;

namespace PapiPay.Identity.Domain.Models.Stores
{
    public class StoreUserModel
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string Country { get; set; }
        public string CountryCode { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string Longitude { get; set; }
        public string Latitude { get; set; }
        public string ZipCode { get; set; }
        public int? CompanyId { get; set; }
        public string Company { get; set; }
        public int? StoreId { get; set; }
        public string Store { get; set; }
        public IEnumerable<string> RoleIds { get; set; }
    }
}
