﻿using System.Collections.Generic;

namespace PapiPay.Identity.Domain.Models
{

    public class SalesforceContactModel
    {
        public int totalSize { get; set; }
        public bool done { get; set; }
        public List<Contact> records { get; set; }
    }

    public class Contact
    {
        public string Id { get; set; }
        public string PapiPay_UserId__c { get; set; }
    }

}
