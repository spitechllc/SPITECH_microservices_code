﻿using IdentityServer4;
using IdentityServer4.EntityFramework.DbContexts;
using IdentityServer4.EntityFramework.Mappers;
using IdentityServer4.Models;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PapiPay.Identity.Infrastructure
{
    public class IdentityConfiguration
    {
        public static IEnumerable<Client> GetClients()
        {
            return new Client[]
            {
                new Client {
                    ClientId = "papipay_m2m",
                    ClientName = "Papipay API to API Client",
                    ClientSecrets = { new Secret("h$Je%Ah4m733Jtz8".Sha256()) },
                    AllowedGrantTypes = GrantTypes.ClientCredentials,
                    RequireConsent = false,
                    AllowOfflineAccess = true,
                    AllowedScopes = new List<string>
                    {
                        IdentityServerConstants.LocalApi.ScopeName,
                        "userstoreapi",
                        "paymentapi",
                        "mppaapi",
                        "transactionapi",
                        "helpsupportapi",
                        "marketingapi"
                    }
                },
                new Client
                {
                    ClientId = "papipay_portal",
                    ClientName = "Papipay Portal Client",
                    AllowedGrantTypes = GrantTypes.Code,
                    RequirePkce = true,
                    RequireClientSecret = false,
                    AllowAccessTokensViaBrowser = true,
                    RequireConsent = false,
                    RedirectUris = new List<string>() { "http://localhost:4200" },
                    PostLogoutRedirectUris = new List<string>() { "http://localhost:4200"  },
                    AllowedCorsOrigins = { "http://localhost:4200" },
                    AllowedScopes = new List<string>
                    {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        IdentityServerConstants.LocalApi.ScopeName,
                        "userstoreapi",
                        "paymentapi",
                        "mppaapi",
                        "transactionapi",
                        "helpsupportapi",
                        "marketingapi"
                    }
                },
                new Client {
                    ClientId = "papipay_mobile",
                    ClientName = "Papipay Mobile Client",
                    AllowedGrantTypes = GrantTypes.Code,
                    RequirePkce = true,
                    RequireClientSecret=false,
                    RequireConsent = false,
                    AllowOfflineAccess = true,
                    RedirectUris = { "com.lib.papipayapp://callback" },
                    AllowedScopes = {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        IdentityServerConstants.LocalApi.ScopeName,
                        "userstoreapi",
                        "paymentapi",
                        "mppaapi",
                        "transactionapi",
                        "helpsupportapi",
                        "marketingapi"
                    },
                },
                new Client
                {
                    ClientId = "papipay_testportal",
                    ClientName = "Papipay Test Portal",
                    AllowedGrantTypes = GrantTypes.Code,
                    RequirePkce = true,
                    AllowRememberConsent = false,
                    RequireConsent = false,
                    AllowOfflineAccess = true,
                    RedirectUris = new List<string>() { "https://localhost:5015/signin-oidc" },
                    PostLogoutRedirectUris = new List<string>() { "https://localhost:5015/"  },
                    ClientSecrets = new List<Secret>
                    {
                        new Secret("jhXLaR&8=v5q5*Ve".Sha256())
                    },
                    AllowedScopes = new List<string>
                    {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        IdentityServerConstants.LocalApi.ScopeName,
                        "userstoreapi",
                        "paymentapi",
                        "mppaapi",
                        "transactionapi",
                        "helpsupportapi",
                        "marketingapi"
                    }
                },
                new Client
                {
                   ClientId = "papipay_testportal2",
                    ClientName = "Papipay Test Portal2",
                    AllowedGrantTypes = GrantTypes.Code,
                    RequirePkce = true,
                    AllowRememberConsent = false,
                    RequireConsent = false,
                    AllowOfflineAccess = true,
                    RedirectUris = new List<string>() { "https://20.80.90.3:5015/signin-oidc" },
                    PostLogoutRedirectUris = new List<string>() { "https://20.80.90.3:5015/"  },
                    ClientSecrets = new List<Secret>
                    {
                        new Secret("jhXLaR&8=v5q5*Ve".Sha256())
                    },
                    AllowedScopes = new List<string>
                    {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        IdentityServerConstants.LocalApi.ScopeName,
                        "userstoreapi",
                        "paymentapi",
                        "mppaapi",
                        "transactionapi",
                        "helpsupportapi",
                        "marketingapi"
                    }
                },
                new Client {
                    ClientId = "papipaybusiness_mobile",
                    ClientName = "Papipay Business Mobile Client",
                    AllowedGrantTypes = GrantTypes.Code,
                    RequirePkce = true,
                    RequireClientSecret=false,
                    RequireConsent = false,
                    AllowOfflineAccess = true,
                    RedirectUris = { "com.lib.papipaybusinessapp://callback" },
                    AllowedScopes = {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        IdentityServerConstants.LocalApi.ScopeName,
                        "userstoreapi",
                        "paymentapi",
                        "mppaapi",
                        "transactionapi",
                        "helpsupportapi",
                        "marketingapi"
                    },
                }
            };
        }

        public static IEnumerable<ApiResource> GetApiResources()
        {
            return new[]
            {
                new ApiResource
                {
                    Name = "userstoreapi",
                    DisplayName = "User Store Management Api",
                    Description = "Allow the application to access User Store Management Api",
                    Scopes = new List<string> { "userstoreapi" },
                },
                 new ApiResource
                {
                    Name = "paymentapi",
                    DisplayName = "User Payment Api",
                    Description = "Allow the application to access User Payment Api",
                    Scopes = new List<string> { "paymentapi" },
                },
                 new ApiResource
                {
                    Name = "mppaapi",
                    DisplayName = "MPPA Api",
                    Description = "Allow the application to access MPPA Api",
                    Scopes = new List<string> { "mppaapi" },
                },
                 new ApiResource
                {
                    Name = "transactionapi",
                    DisplayName = "Transaction Api",
                    Description = "Allow the application to access Transaction Api",
                    Scopes = new List<string> { "transactionapi" },
                },
                new ApiResource
                {
                    Name = "helpsupportapi",
                    DisplayName = "HelpSupport Api",
                    Description = "Allow the application to access HelpSupport Api",
                    Scopes = new List<string> { "helpsupportapi" },
                },
                new ApiResource
                {
                    Name = "marketingapi",
                    DisplayName = "Marketing Api",
                    Description = "Allow the application to access Marketing Api",
                    Scopes = new List<string> { "marketingapi" },
                }
            };
        }

        public static IEnumerable<ApiScope> GetApiScopes()
        {
            return new[]
            {
                new ApiScope(IdentityServerConstants.LocalApi.ScopeName, "Access to IdentityServer Api"),
                new ApiScope("userstoreapi", "Access to User Store Management Api"),
                new ApiScope("paymentapi", "Access to payment Api"),
                new ApiScope("mppaapi", "Access to MPPA Api"),
                new ApiScope("transactionapi", "Access to Transaction Api"),
                new ApiScope("helpsupportapi", "Access to HelpSupport Api"),
                new ApiScope("marketingapi", "Access to Marketing Api")
            };
        }

        public static IEnumerable<IdentityResource> GetIdentityResources()
        {
            return new IdentityResource[]
            {
                new IdentityResources.OpenId(),
                new IdentityResources.Profile(),
                //new IdentityResources.Address(),
                //new IdentityResources.Email(),
                //new IdentityResource(Constant.Scope_Role_Value, Constant.Scope_Role_Text, new List<string>() { Constant.Scope_Role_Value })
            };
        }

        public static void InitializeDatabase(IServiceProvider serviceProvider)
        {
            ConfigurationDbContext context = serviceProvider.GetRequiredService<ConfigurationDbContext>();

            foreach (Client client in IdentityConfiguration.GetClients())
            {
                IdentityServer4.EntityFramework.Entities.Client dbclient = context.Clients.FirstOrDefault(t => t.ClientId == client.ClientId);
                if (dbclient == null)
                {
                    context.Clients.Add(client.ToEntity());
                    context.SaveChanges();
                }
            }

            foreach (IdentityResource resource in IdentityConfiguration.GetIdentityResources())
            {
                if (!context.IdentityResources.Any(t => t.Name == resource.Name))
                {
                    context.IdentityResources.Add(resource.ToEntity());
                }
            }
            context.SaveChanges();

            foreach (ApiScope scope in IdentityConfiguration.GetApiScopes())
            {
                if (!context.ApiScopes.Any(t => t.Name == scope.Name))
                {
                    context.ApiScopes.Add(scope.ToEntity());
                }
            }
            context.SaveChanges();

            foreach (ApiResource resource in IdentityConfiguration.GetApiResources())
            {
                if (!context.ApiResources.Any(t => t.Name == resource.Name))
                {
                    context.ApiResources.Add(resource.ToEntity());
                }
            }
            context.SaveChanges();
        }
    }
}
