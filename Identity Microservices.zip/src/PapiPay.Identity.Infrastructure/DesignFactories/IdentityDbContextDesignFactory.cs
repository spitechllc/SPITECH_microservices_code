﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using PapiPay.Identity.Infrastructure.Persistence;
using System.Reflection;

namespace PapiPay.Identity.Infrastructure.DesignFactories
{
    internal class IdentityDbContextDesignFactory : IDesignTimeDbContextFactory<IdentityDbContext>
    {
        public IdentityDbContext CreateDbContext(string[] args)
        {
            string migrationsAssembly = typeof(IdentityDbContextDesignFactory).GetTypeInfo().Assembly.GetName().Name;
            DbContextOptionsBuilder<IdentityDbContext> optionsBuilder = new DbContextOptionsBuilder<IdentityDbContext>()
                  .UseSqlServer("Data Source=64.27.25.25;Initial Catalog=PapiPay_IdentityServer; UID=flexsin; Password=WeBhyd{_KJH1@fle;Integrated Security=false;MultipleActiveResultSets=True", sql => sql.MigrationsAssembly(migrationsAssembly));

            return new IdentityDbContext(optionsBuilder.Options);
        }
    }
}
