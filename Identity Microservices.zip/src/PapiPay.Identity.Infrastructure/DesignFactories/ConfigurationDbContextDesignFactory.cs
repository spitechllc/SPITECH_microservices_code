﻿using IdentityServer4.EntityFramework.DbContexts;
using IdentityServer4.EntityFramework.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using System.Reflection;

namespace PapiPay.Identity.Infrastructure.DesignFactories
{
    internal class ConfigurationDbContextDesignFactory : IDesignTimeDbContextFactory<ConfigurationDbContext>
    {
        public ConfigurationDbContext CreateDbContext(string[] args)
        {
            string migrationsAssembly = typeof(ConfigurationDbContextDesignFactory).GetTypeInfo().Assembly.GetName().Name;
            DbContextOptionsBuilder<ConfigurationDbContext> optionsBuilder = new DbContextOptionsBuilder<ConfigurationDbContext>()
                  .UseSqlServer("Data Source=64.27.25.25;Initial Catalog=PapiPay_IdentityServer; UID=flexsin; Password=WeBhyd{_KJH1@fle;Integrated Security=false;MultipleActiveResultSets=True", sql => sql.MigrationsAssembly(migrationsAssembly));

            return new ConfigurationDbContext(optionsBuilder.Options, new ConfigurationStoreOptions { });
        }
    }
}
