﻿using IdentityServer4.EntityFramework.DbContexts;
using IdentityServer4.EntityFramework.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using System.Reflection;

namespace PapiPay.Identity.Infrastructure.DesignFactories
{
    internal class PersistedGrantDbContextDesignFactory : IDesignTimeDbContextFactory<PersistedGrantDbContext>
    {
        public PersistedGrantDbContext CreateDbContext(string[] args)
        {
            string migrationsAssembly = typeof(PersistedGrantDbContextDesignFactory).GetTypeInfo().Assembly.GetName().Name;
            DbContextOptionsBuilder<PersistedGrantDbContext> optionsBuilder = new DbContextOptionsBuilder<PersistedGrantDbContext>()
                  .UseSqlServer("Data Source=64.27.25.25;Initial Catalog=PapiPay_IdentityServer; UID=flexsin; Password=WeBhyd{_KJH1@fle;Integrated Security=false;MultipleActiveResultSets=True", sql => sql.MigrationsAssembly(migrationsAssembly));

            return new PersistedGrantDbContext(optionsBuilder.Options, new OperationalStoreOptions { });
        }
    }
}
