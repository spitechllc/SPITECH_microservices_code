using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace PapiPay.Identity.Infrastructure.ServiceCollection
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            services
                .AddDbContext(configuration);

            return services;
        }
    }
}
