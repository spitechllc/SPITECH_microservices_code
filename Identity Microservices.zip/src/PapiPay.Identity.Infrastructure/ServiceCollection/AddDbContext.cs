using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Infrastructure.Persistence;
using System;

namespace PapiPay.Identity.Infrastructure.ServiceCollection
{
    public static class CustomServiceCollectionExtenstion
    {
        public static IServiceCollection AddDbContext(this IServiceCollection services, IConfiguration configuration)
        {
            string connectionString = configuration.GetConnectionString("IdentityServer");
            services.AddDbContext<IdentityDbContext>(options =>
            {
                options.UseSqlServer(connectionString,
                    sqlServerOptionsAction: sqlOptions =>
                    {
                        sqlOptions.EnableRetryOnFailure(
                        maxRetryCount: 3,
                        maxRetryDelay: TimeSpan.FromSeconds(10),
                        errorNumbersToAdd: null);
                    });
            });

            services.AddScoped<IIdentityDbContext>(provider => provider.GetService<IdentityDbContext>());
            return services;
        }

        public static IIdentityServerBuilder AddIdentityServerContext(this IIdentityServerBuilder identityServerBuilder, IConfiguration configuration)
        {
            string connectionString = configuration.GetConnectionString("IdentityServer");
            identityServerBuilder
                .AddConfigurationStore(options =>
                 {
                     options.ConfigureDbContext = b => b.UseSqlServer(connectionString);
                 })
                .AddOperationalStore(options =>
                {
                    options.ConfigureDbContext = b => b.UseSqlServer(connectionString);
                    options.EnableTokenCleanup = true;
                    options.TokenCleanupInterval = 30;
                });
            return identityServerBuilder;
        }
    }
}
