using Microsoft.EntityFrameworkCore;

namespace PapiPay.Identity.Infrastructure.Persistence
{
    public partial class IdentityDbContext : DbContext
    {
        public IdentityDbContext(DbContextOptions<IdentityDbContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            UseSingularTableNames(modelBuilder);
            modelBuilder.ApplyConfigurationsFromAssembly(GetType().Assembly);
            //UseSoftDeleteFilter(modelBuilder);
        }

        public static void UseSingularTableNames(ModelBuilder modelBuilder)
        {
            foreach (Microsoft.EntityFrameworkCore.Metadata.IMutableEntityType entityType in modelBuilder.Model.GetEntityTypes())
            {
                modelBuilder.Entity(entityType.ClrType).ToTable(entityType.ClrType.Name);
            }
        }

        //public static void UseSoftDeleteFilter(ModelBuilder modelBuilder)
        //{
        //    foreach (var entityType in modelBuilder.Model.GetEntityTypes())
        //    {
        //        SetSoftDeleteFilter(modelBuilder, entityType.ClrType);
        //    }
        //}

        //public static void SetSoftDeleteFilter(ModelBuilder modelBuilder, Type entityType)
        //{
        //    SetSoftDeleteFilterMethod.MakeGenericMethod(entityType)
        //        .Invoke(null, new object[] { modelBuilder });
        //}

        //private static readonly MethodInfo SetSoftDeleteFilterMethod = typeof(IdentityDbContext)
        //           .GetMethods(BindingFlags.Public | BindingFlags.Static)
        //           .Single(t => t.IsGenericMethod && t.Name == "SetSoftDeleteFilter");

        //public static void SetSoftDeleteFilter<TEntity>(ModelBuilder modelBuilder)
        //    where TEntity : class
        //{
        //    modelBuilder.Entity<TEntity>().HasQueryFilter(x => EF.Property<bool>(x, "IsActive"));
        //}
    }
}