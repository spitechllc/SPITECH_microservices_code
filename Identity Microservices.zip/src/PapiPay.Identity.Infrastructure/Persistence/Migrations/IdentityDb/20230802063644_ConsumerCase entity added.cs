﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace PapiPay.Identity.Infrastructure.Persistence.Migrations.IdentityDb
{
    public partial class ConsumerCaseentityadded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_APIResourcePermission",
                table: "APIResourcePermission");

            migrationBuilder.AlterColumn<string>(
                name: "ClientId",
                table: "APIResourcePermission",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_APIResourcePermission",
                table: "APIResourcePermission",
                columns: new[] { "APIResourceId", "ClaimId", "ClientId" });

            migrationBuilder.CreateTable(
                name: "ConsumerCase",
                columns: table => new
                {
                    ConsumerCaseId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    Subject = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Reason = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClosedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsEscalated = table.Column<bool>(type: "bit", nullable: false),
                    Comments = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastModifiedById = table.Column<int>(type: "int", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UpdatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ConsumerCase", x => x.ConsumerCaseId);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ConsumerCase");

            migrationBuilder.DropPrimaryKey(
                name: "PK_APIResourcePermission",
                table: "APIResourcePermission");

            migrationBuilder.AlterColumn<string>(
                name: "ClientId",
                table: "APIResourcePermission",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddPrimaryKey(
                name: "PK_APIResourcePermission",
                table: "APIResourcePermission",
                columns: new[] { "APIResourceId", "ClaimId" });
        }
    }
}
