﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace PapiPay.Identity.Infrastructure.Persistence.Migrations.IdentityDb
{
    public partial class AddedUserLoginLog : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsLoggedIn",
                table: "UserProfile",
                type: "bit",
                nullable: true,
                defaultValue: false);

            migrationBuilder.AddColumn<DateTime>(
                name: "LastLogin",
                table: "UserProfile",
                type: "datetime2",
                nullable: true,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "LastLoginIP",
                table: "UserProfile",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "UserLoginLog",
                columns: table => new
                {
                    UserLoginLogsId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    LoginIp = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    LoginDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UpdatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserLoginLog", x => x.UserLoginLogsId);
                });

            migrationBuilder.CreateIndex(
                name: "IX_UserLoginLog_UserId",
                table: "UserLoginLog",
                column: "UserId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "UserLoginLog");

            migrationBuilder.DropColumn(
                name: "IsLoggedIn",
                table: "UserProfile");

            migrationBuilder.DropColumn(
                name: "LastLogin",
                table: "UserProfile");

            migrationBuilder.DropColumn(
                name: "LastLoginIP",
                table: "UserProfile");
        }
    }
}
