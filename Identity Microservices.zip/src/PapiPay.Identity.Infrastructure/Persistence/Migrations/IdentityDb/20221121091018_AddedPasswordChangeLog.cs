﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace PapiPay.Identity.Infrastructure.Persistence.Migrations.IdentityDb
{
    public partial class AddedPasswordChangeLog : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "InvalidLogin",
                table: "UserLoginLog",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "InvalidLoginCount",
                table: "UserLoginLog",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.CreateTable(
                name: "UserPasswordChangeLog",
                columns: table => new
                {
                    UserPasswordChangeLogId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    OldPassword = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    NewPassword = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ChangeDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsWrongAttempt = table.Column<bool>(type: "bit", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UpdatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserPasswordChangeLog", x => x.UserPasswordChangeLogId);
                });

            migrationBuilder.CreateIndex(
                name: "IX_UserPasswordChangeLog_UserId",
                table: "UserPasswordChangeLog",
                column: "UserId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "UserPasswordChangeLog");

            migrationBuilder.DropColumn(
                name: "InvalidLogin",
                table: "UserLoginLog");

            migrationBuilder.DropColumn(
                name: "InvalidLoginCount",
                table: "UserLoginLog");
        }
    }
}
