﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PapiPay.Identity.Domain.Entities;

namespace PapiPay.Identity.Infrastructure.Persistence.EntityConfigurations
{
    public class APIResourcePermissionConfiguration : IEntityTypeConfiguration<APIResourcePermission>
    {
        public void Configure(EntityTypeBuilder<APIResourcePermission> builder)
        {
            builder.HasKey(x => new { x.APIResourceId, x.ClaimId ,x.ClientId});
            builder.Property(p => p.IsActive).HasDefaultValue(true).IsRequired();
            builder.Property(p => p.CreatedBy).HasMaxLength(256);
            builder.Property(p => p.UpdatedBy).HasMaxLength(256);

            builder.HasOne(d => d.Claim)
                .WithMany(p => p.APIResourcePermissions)
                .HasForeignKey(d => d.ClaimId)
                .OnDelete(DeleteBehavior.ClientSetNull);

            
        }
    }
}