﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PapiPay.Identity.Domain.Entities;

namespace PapiPay.Identity.Infrastructure.Persistence.EntityConfigurations
{

    public class CodeVerificationConfiguration : IEntityTypeConfiguration<CodeVerification>
    {
        public void Configure(EntityTypeBuilder<CodeVerification> builder)
        {
            builder.HasKey(x => x.CodeVerificationId);
            builder.Property(x => x.Receiver).HasMaxLength(100);

            builder.Property(p => p.IsActive).HasDefaultValue(true).IsRequired();
            builder.Property(p => p.CreatedBy).HasMaxLength(256);
            builder.Property(p => p.UpdatedBy).HasMaxLength(256);

            builder.HasIndex(p => p.UserId);
        }
    }
}
