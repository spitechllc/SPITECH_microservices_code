﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PapiPay.Identity.Domain.Entities;

namespace PapiPay.Identity.Infrastructure.Persistence.EntityConfigurations
{
    public class PermissionConfiguration : IEntityTypeConfiguration<Permission>
    {
        public void Configure(EntityTypeBuilder<Permission> builder)
        {
            builder.HasKey(x => new { x.RoleId, x.ClaimId });
            builder.Property(p => p.IsActive).HasDefaultValue(true).IsRequired();
            builder.Property(p => p.CreatedBy).HasMaxLength(256);
            builder.Property(p => p.UpdatedBy).HasMaxLength(256);

            builder.HasOne(d => d.Claim)
                .WithMany(p => p.Permissions)
                .HasForeignKey(d => d.ClaimId)
                .OnDelete(DeleteBehavior.ClientSetNull);

            builder.HasOne(d => d.Role)
                .WithMany(p => p.Permissions)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull);
        }
    }
}