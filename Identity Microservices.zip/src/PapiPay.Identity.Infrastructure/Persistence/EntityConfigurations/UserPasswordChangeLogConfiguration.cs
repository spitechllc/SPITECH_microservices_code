﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;

namespace PapiPay.Identity.Domain.Entities
{
    public class UserPasswordChangeLogConfiguration : IEntityTypeConfiguration<UserPasswordChangeLog>
    {
        public void Configure(EntityTypeBuilder<UserPasswordChangeLog> builder)
        {
            builder.HasKey(x => x.UserPasswordChangeLogId);

            builder.Property(p => p.OldPassword).HasMaxLength(50);
            builder.Property(p => p.NewPassword).HasMaxLength(50);

            builder.HasIndex(p => p.UserId);
        }
    }
}
