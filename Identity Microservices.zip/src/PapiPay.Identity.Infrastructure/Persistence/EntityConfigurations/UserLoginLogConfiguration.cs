﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PapiPay.Identity.Domain.Entities;

namespace PapiPay.Identity.Infrastructure.Persistence.EntityConfigurations
{
    public class UserLoginLogConfiguration : IEntityTypeConfiguration<UserLoginLog>
    {
        public void Configure(EntityTypeBuilder<UserLoginLog> builder)
        {
            builder.HasKey(x => x.UserLoginLogsId);
           
            builder.Property(p => p.LoginIp).HasMaxLength(50);

            builder.HasIndex(p => p.UserId);
        }
    }
}
