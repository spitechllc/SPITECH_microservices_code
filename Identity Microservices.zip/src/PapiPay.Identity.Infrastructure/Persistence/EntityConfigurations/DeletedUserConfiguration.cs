﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PapiPay.Identity.Domain.Entities;

namespace PapiPay.Identity.Infrastructure.Persistence.EntityConfigurations
{
    public class DeletedUserConfiguration : IEntityTypeConfiguration<DeletedUser>
    {
        public void Configure(EntityTypeBuilder<DeletedUser> builder)
        {

            builder.HasKey(x => x.UserId);
            builder.Property(x => x.UserId)
                .ValueGeneratedNever();
            builder.Property(p => p.UserName).HasMaxLength(50).IsRequired();
            builder.Property(p => p.FirstName).HasMaxLength(50).IsRequired();
            builder.Property(p => p.LastName).HasMaxLength(50).IsRequired();
            builder.Property(p => p.PasswordHash).HasMaxLength(256);
            builder.Property(p => p.Email).HasMaxLength(100);
            builder.Property(p => p.MobileCountryCode).HasMaxLength(10);
            builder.Property(p => p.MobileNumber).HasMaxLength(20);
            builder.Property(p => p.PreferedLanguage).HasMaxLength(20);
            builder.Property(p => p.MobileCountryCode).HasMaxLength(10);
            builder.Property(p => p.CreatedBy).HasMaxLength(256);
            builder.Property(p => p.UpdatedBy).HasMaxLength(256);
        }
    }
}
