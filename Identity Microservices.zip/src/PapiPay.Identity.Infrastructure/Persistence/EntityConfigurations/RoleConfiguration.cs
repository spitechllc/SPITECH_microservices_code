﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PapiPay.Identity.Domain.Entities;

namespace PapiPay.Identity.Infrastructure.Persistence.EntityConfigurations
{
    public class RoleConfiguration : IEntityTypeConfiguration<Role>
    {
        public void Configure(EntityTypeBuilder<Role> builder)
        {
            builder.Property(x => x.RoleId)
                .ValueGeneratedNever();

            builder.Property(p => p.RoleName).HasMaxLength(100).IsRequired();
            builder.Property(p => p.IsActive).HasDefaultValue(true).IsRequired();
            builder.Property(p => p.CreatedBy).HasMaxLength(256);
            builder.Property(p => p.UpdatedBy).HasMaxLength(256);
            builder.HasOne(d => d.RoleType)
               .WithMany(p => p.Roles)
               .HasForeignKey(d => d.RoleTypeId)
               .OnDelete(DeleteBehavior.ClientSetNull);
        }
    }
}