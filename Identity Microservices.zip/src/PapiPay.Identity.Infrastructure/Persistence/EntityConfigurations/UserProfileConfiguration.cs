﻿using ChoETL;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PapiPay.Identity.Domain.Entities;

namespace PapiPay.Identity.Infrastructure.Persistence.EntityConfigurations
{
    public class UserProfileConfiguration : IEntityTypeConfiguration<UserProfile>
    {
        public void Configure(EntityTypeBuilder<UserProfile> builder)
        {
            builder.HasKey(x => x.UserId);
            builder.Property(x => x.UserId)
                .ValueGeneratedNever();
            builder.Property(p => p.Gender).HasMaxLength(1).HasDefaultValue(string.Empty).IsNullOrDbNull();
            builder.Property(p => p.BusinessName).HasMaxLength(200);
            builder.Property(p => p.BusinessAccountNumber).HasMaxLength(50);
            builder.Property(p => p.AddressLine1).HasMaxLength(500);
            builder.Property(p => p.AddressLine2).HasMaxLength(500);
            builder.Property(p => p.Country).HasMaxLength(100);
            builder.Property(p => p.State).HasMaxLength(100);
            builder.Property(p => p.City).HasMaxLength(100);
            builder.Property(p => p.CountryCode).HasMaxLength(10);
            builder.Property(p => p.ZipCode).HasMaxLength(10);
            builder.Property(p => p.Latitude).HasMaxLength(50);
            builder.Property(p => p.Longitude).HasMaxLength(50);
            builder.Property(p => p.PhotoUrl).HasMaxLength(500);
            builder.Property(p => p.Store).HasMaxLength(200);
            builder.Property(p => p.Company).HasMaxLength(200);
            builder.Property(p => p.IsActive).HasDefaultValue(true).IsRequired();
            builder.Property(p => p.CreatedBy).HasMaxLength(256);
            builder.Property(p => p.UpdatedBy).HasMaxLength(256);

            builder.HasOne(d => d.User)
                .WithOne(p => p.UserProfile)
                .HasForeignKey<UserProfile>(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull);
        }
    }
}
