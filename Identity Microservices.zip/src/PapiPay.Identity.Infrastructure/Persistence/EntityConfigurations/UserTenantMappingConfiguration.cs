﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PapiPay.Identity.Domain.Entities;

namespace PapiPay.Identity.Infrastructure.Persistence.EntityConfigurations
{
    public class UserTenantMappingConfiguration : IEntityTypeConfiguration<UserTenantMapping>
    {
        public void Configure(EntityTypeBuilder<UserTenantMapping> builder)
        {
            builder.Property(x => x.ID);
            builder.Property(x => x.UserId);
            builder.Property(x => x.TenantId);

        }
    }
}
