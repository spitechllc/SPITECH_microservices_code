﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PapiPay.Identity.Domain.Entities;

namespace PapiPay.Identity.Infrastructure.Persistence.EntityConfigurations
{
    public class LinkUserConfiguration : IEntityTypeConfiguration<LinkUser>
    {
        public void Configure(EntityTypeBuilder<LinkUser> builder)
        {
            builder.HasKey(x => x.LinkUserId);


            builder.Property(p => p.IsActive).HasDefaultValue(true).IsRequired();
            builder.Property(p => p.CreatedBy).HasMaxLength(256);
            builder.Property(p => p.UpdatedBy).HasMaxLength(256);

            builder.HasOne(d => d.RequestedUser)
                .WithMany(p => p.RequestedLinkUsers)
                .HasForeignKey(d => d.RequestedUserId)
                .OnDelete(DeleteBehavior.ClientSetNull);

            builder.HasOne(d => d.AcceptUser)
               .WithMany(p => p.AcceptedLinkUsers)
               .HasForeignKey(d => d.AcceptUserId)
               .OnDelete(DeleteBehavior.ClientSetNull);
        }
    }
}
