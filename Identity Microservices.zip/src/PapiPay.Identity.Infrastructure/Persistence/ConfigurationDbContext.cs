﻿//using IdentityModel;
//using IdentityServer4.EntityFramework.Entities;
//using IdentityServer4.EntityFramework.Extensions;
//using IdentityServer4.EntityFramework.Options;
//using Microsoft.EntityFrameworkCore;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace PapiPay.Identity.Infrastructure.Persistence
//{
//    public class ConfigurationDbContext : IdentityServer4.EntityFramework.DbContexts.ConfigurationDbContext<ConfigurationDbContext>
//    {
//        private readonly ConfigurationStoreOptions _storeOptions;

//        public ConfigurationDbContext(DbContextOptions<ConfigurationDbContext> options, ConfigurationStoreOptions storeOptions) : base(options, storeOptions)
//        {
//            _storeOptions = storeOptions;
//        }

//        protected override void OnModelCreating(ModelBuilder modelBuilder)
//        {
//            modelBuilder.ConfigureClientContext(_storeOptions);
//            modelBuilder.ConfigureResourcesContext(_storeOptions);
//            base.OnModelCreating(modelBuilder);
//            ClientSeed(modelBuilder);
//        }

//        private void ClientSeed(ModelBuilder builder)
//        {
//            builder.Entity<ApiResource>()
//                .HasData(
//                    new ApiResource
//                    {
//                        Id = 1,
//                        Name = "userstoreapi",
//                        DisplayName = "User Store Management Api",
//                        Description= "Allow the application to access User Store Management Api",
//                    }
//                );

//            builder.Entity<ApiResourceScope>()
//                .HasData(
//                    new ApiResourceScope
//                    {
//                        Id = 1,
//                        Scope= "userstoreapi",
//                        ApiResourceId = 1
//                    }
//                );

//            builder.Entity<IdentityResource>().HasData
//                (
//                    new IdentityResource()
//                    {
//                        Id = 1,
//                        Enabled = true,
//                        Name = "openid",
//                        DisplayName = "User identifier",
//                        Description = null,
//                        Required = true,
//                        Emphasize = false,
//                        ShowInDiscoveryDocument = true,
//                        Created = DateTime.UtcNow,
//                        Updated = null,
//                        NonEditable = false
//                    },
//                    new IdentityResource()
//                    {
//                        Id = 2,
//                        Enabled = true,
//                        Name = "profile",
//                        DisplayName = "User profile",
//                        Description = "User profile information (first name, last name, etc.)",
//                        Required = false,
//                        Emphasize = true,
//                        ShowInDiscoveryDocument = true,
//                        Created = DateTime.UtcNow,
//                        Updated = null,
//                        NonEditable = false
//                    });

//            builder.Entity<Client>()
//                .HasData(
//                    new Client
//                    {
//                        Id = 1,
//                        Enabled = true,
//                        ClientId = "papipay_m2m",
//                        ProtocolType = "oidc",
//                        RequireClientSecret = true,
//                        RequireConsent = false,
//                        ClientName = "Papipay machine to machine Client",
//                        Description = "Papipay machine to machine Client",
//                        AllowRememberConsent = true,
//                        AlwaysIncludeUserClaimsInIdToken = false,
//                        RequirePkce = false,
//                        AllowAccessTokensViaBrowser = false,
//                        AllowOfflineAccess = false
//                    },
//                    new Client
//                    {
//                        Id = 2,
//                        Enabled = true,
//                        ClientId = "papipay_portal",
//                        ProtocolType = "oidc",
//                        RequireClientSecret = true,
//                        RequireConsent = false,
//                        ClientName = "Papipay Web Portal",
//                        Description = "Papipay Web Portal",
//                        AllowRememberConsent = true,
//                        AlwaysIncludeUserClaimsInIdToken = false,
//                        RequirePkce = false,
//                        AllowAccessTokensViaBrowser = false,
//                        AllowOfflineAccess = false
//                    },
//                    new Client
//                    {
//                        Id = 3,
//                        Enabled = true,
//                        ClientId = "papipay_mobile",
//                        ProtocolType = "oidc",
//                        RequireClientSecret = false,
//                        RequireConsent = false,
//                        ClientName = "Papipay Mobile Host",
//                        Description = "Papipay Mobile Host",
//                        AllowRememberConsent = true,
//                        AlwaysIncludeUserClaimsInIdToken = false,
//                        RequirePkce = false,
//                        AllowAccessTokensViaBrowser = false,
//                        AllowOfflineAccess = true
//                    });

//            builder.Entity<ClientGrantType>()
//                .HasData(
//                    new ClientGrantType
//                    {
//                        Id = 1,
//                        GrantType = "client_credentials",
//                        ClientId = 1
//                    },
//                    new ClientGrantType
//                    {
//                        Id = 2,
//                        GrantType = "authorization_code",
//                        ClientId = 2
//                    },
//                    new ClientGrantType
//                    {
//                        Id = 3,
//                        GrantType = "authorization_code",
//                        ClientId = 3
//                    });

//            builder.Entity<ClientScope>()
//                .HasData(
//                    new ClientScope
//                    {
//                        Id = 1,
//                        Scope = "userstoreapi",
//                        ClientId = 1
//                    },
//                    new ClientScope
//                    {
//                        Id = 2,
//                        Scope = "openid",
//                        ClientId = 2
//                    },
//                    new ClientScope
//                    {
//                        Id = 3,
//                        Scope = "userstoreapi",
//                        ClientId = 2
//                    },
//                    new ClientScope
//                    {
//                        Id = 4,
//                        Scope = "openid",
//                        ClientId = 4
//                    },
//                    new ClientScope
//                    {
//                        Id = 5,
//                        Scope = "userstoreapi",
//                        ClientId = 4
//                    });

//            builder.Entity<ClientSecret>()
//                .HasData(
//                        new ClientSecret
//                        {
//                            Id = 1,
//                            Value = "h$Je%Ah4m733Jtz8".ToSha256(),
//                            Type = "SharedSecret",
//                            ClientId = 1
//                        },
//                        new ClientSecret
//                        {
//                            Id = 2,
//                            Value = "jhXLaR&8=v5q5*Ve".ToSha256(),
//                            Type = "SharedSecret",
//                            ClientId = 2
//                        });

//            builder.Entity<ClientPostLogoutRedirectUri>()
//                .HasData(
//                new ClientPostLogoutRedirectUri
//                {
//                    Id = 1,
//                    PostLogoutRedirectUri = "https://localhost:5004/",
//                    ClientId = 2
//                });

//            builder.Entity<ClientRedirectUri>()
//                .HasData(
//                new ClientRedirectUri
//                {
//                    Id = 1,
//                    RedirectUri = "https://localhost:5004/signin-oidc",
//                    ClientId = 2
//                },
//                new ClientRedirectUri
//                {
//                    Id = 2,
//                    RedirectUri = "Papipayclients://callback",
//                    ClientId = 3
//                });

//            //builder.Entity<ClientCorsOrigin>()
//            //    .HasData(
//            //    new ClientCorsOrigin
//            //    {
//            //        Id = 1,
//            //        Origin = "http://localhost:5003",
//            //        ClientId = 4
//            //    });
//        }
//    }
//}
