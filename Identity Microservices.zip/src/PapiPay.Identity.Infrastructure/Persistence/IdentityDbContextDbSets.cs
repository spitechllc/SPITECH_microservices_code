﻿using Microsoft.EntityFrameworkCore;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Infrastructure.Persistence
{
    public partial class IdentityDbContext : IIdentityDbContext
    {
        public DbSet<Claim> Claims { get; set; }
        public DbSet<Permission> Permissions { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<UserDevice> UserDevices { get; set; }
        public DbSet<UserProfile> UserProfiles { get; set; }
        public DbSet<UserRole> UserRoles { get; set; }
        public DbSet<UserType> UserTypes { get; set; }
        public DbSet<RoleType> RoleTypes { get; set; }
        public DbSet<DeletedUser> DeletedUsers { get; set; }
        public DbSet<DeletedUserProfile> DeletedUserProfiles { get; set; }
        public DbSet<UserTenantMapping> TenantMasters { get; set; }
        public DbSet<TenantMaster> TenantMaster { get; set; }

        public DbSet<LinkUser> LinkUsers
        {
            get; set;
        }
        public DbSet<CodeVerification> CodeVerifications
        {
            get; set;
        }

        public DbSet<UserLoginLog> UserLoginLogs { get; set; }
        public DbSet<UserPasswordChangeLog> UserPasswordChangeLogs { get; set; }
        public DbSet<APIResourcePermission> APIResourcePermissions { get; set; }

        public DbSet<ConsumerCase> ConsumerCases { get; set; }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken)
        {
            UpdateAuditFields();
            return await base.SaveChangesAsync();
        }

        private void UpdateAuditFields()
        {
            //var currentUserId = this.GetService<ICurrentUserProvider>().Id;
            System.Collections.Generic.IEnumerable<Microsoft.EntityFrameworkCore.ChangeTracking.EntityEntry> trackedEntities = ChangeTracker.Entries();
            DateTime timestamp = DateTime.UtcNow;
            foreach (Microsoft.EntityFrameworkCore.ChangeTracking.EntityEntry entity in trackedEntities)
            {
                if (entity.State == EntityState.Added)
                {
                    //entity.Property("CreatedBy").CurrentValue = currentUserId;
                    entity.Property("CreatedOn").CurrentValue = timestamp;
                    entity.Property("IsActive").CurrentValue = true;
                }
                else if (entity.State == EntityState.Modified)
                {
                    entity.Property("UpdatedOn").CurrentValue = timestamp;
                    //entity.Property("UpdateBy").CurrentValue = currentUserId;
                }
            }
        }
    }
}