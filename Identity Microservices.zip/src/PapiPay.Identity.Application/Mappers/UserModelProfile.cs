﻿using AutoMapper;
using PapiPay.Identity.Application.Commands.RegisterUser;
using PapiPay.Identity.Domain.Models.Consumers;
using PapiPay.Identity.Domain.Models.Stores;

namespace PapiPay.Identity.Application.Mappers
{
    public class UserModelProfile : Profile
    {
        public UserModelProfile()
        {
            CreateMap<ConsumerUserModel, RegisterUserCommand>().ReverseMap();
            CreateMap<StoreUserModel, RegisterUserCommand>().ReverseMap();
        }
    }
}
