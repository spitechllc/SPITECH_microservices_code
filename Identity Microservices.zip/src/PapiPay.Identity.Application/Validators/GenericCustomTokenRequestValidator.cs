﻿using IdentityModel;
using IdentityServer4.Validation;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Application.Queries.GetAPIResourcePermissions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static PapiPay.ApplicationCore.Domain.DomainConstant;

namespace PapiPay.Identity.Application.Validators
{
    public class GenericCustomTokenRequestValidator : ICustomTokenRequestValidator
    {
        private readonly ILogger<GenericCustomTokenRequestValidator> logger;
        private readonly IMediator mediator;

        public GenericCustomTokenRequestValidator(ILogger<GenericCustomTokenRequestValidator> logger, IMediator mediator)
        {
            this.logger = logger;
            this.mediator = mediator;
        }
        public async Task ValidateAsync(CustomTokenRequestValidationContext context)
        {
            var client = context.Result.ValidatedRequest.Client;

            // we want to add custom claims to our "poop" client
            if (client.ClientId.Equals("spitech_m2m", StringComparison.InvariantCultureIgnoreCase) || client.ClientId.Equals("spitech_portal", StringComparison.InvariantCultureIgnoreCase))
            {
                var apiResourcePermissions = await mediator.Send(new APIResourcePermissionsRequest { ClientId = client.ClientId });
                context.Result.ValidatedRequest.ClientClaims.Add(new System.Security.Claims.Claim(JwtClaimTypes.Role, IdentityRoleType.APIClient));
                context.Result.ValidatedRequest.ClientClaims.Add(new System.Security.Claims.Claim(IdentityClaim.ApiResourceClaim, 
                                                                                                    String.Join(',', apiResourcePermissions)));
                // do some validation, etc.
                //var result = await DoSomeProcessingAsync(client);
                //if (result)
                //{
                //    context.Result.IsError = true;
                //    context.Result.Error = "Not enough poop!";
                //    return;
                //}

                // get list of custom claims we want to add
                //var claims = await GetYourCustomClaims();

                // add it
                //claims.ToList().ForEach(u => context.Result.ValidatedRequest.ClientClaims.Add(u));

                // don't want it to be prefixed with "client_" ? we change it here (or from global settings)
                context.Result.ValidatedRequest.Client.ClientClaimsPrefix = "";
            }
        }
    }
}
