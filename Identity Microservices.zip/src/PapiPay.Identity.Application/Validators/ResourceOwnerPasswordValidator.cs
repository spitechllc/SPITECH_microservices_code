﻿using IdentityModel;
using IdentityServer4.Models;
using IdentityServer4.Validation;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Identity;
using PapiPay.Identity.Application.Queries.GetUser;
using PapiPay.Identity.Domain.Models;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using static PapiPay.ApplicationCore.Domain.DomainConstant;
using Claim = System.Security.Claims.Claim;
using PapiPay.Identity.Application.Queries.GetAPIResourcePermissions;

namespace PapiPay.Identity.Application.Validators
{
    public class ResourceOwnerPasswordValidator : IResourceOwnerPasswordValidator
    {
        private readonly IMediator mediator;

        private readonly ILogger<ResourceOwnerPasswordValidator> logger;
        private readonly IEventDispatcher eventDispatcher;

        public ResourceOwnerPasswordValidator(IMediator mediator,
            ILogger<ResourceOwnerPasswordValidator> logger,
            IEventDispatcher eventDispatcher)
        {
            this.mediator = mediator;
            this.logger = logger;
            this.eventDispatcher = eventDispatcher;
        }

        public async Task ValidateAsync(ResourceOwnerPasswordValidationContext context)
        {
            try
            {
                var tenantName = context.Request.Raw.Get("tenantName");

                ApplicationCore.Domain.Models.ResponseModel<UserModel> userResponse = await mediator.Send(new GetUserRequest
                {
                    UserName = context.UserName,
                    Password = context.Password,
                    ClientId = context.Request.ClientId,
                    UserTypeId = (int)UserTypeEnum.Consumer,
                    TenantName= tenantName,
                });

                if (userResponse != null && userResponse.Success)
                {
                    //await mediator.Send(new RemovePersistedGrantCommand
                    //{
                    //    UserId = userResponse.Data.UserId,
                    //    ClientId = context?.Request.ClientId
                    //});

                    await DispatchSignInEvent(userResponse.Data.UserId);

                    IEnumerable<string> apiResourcePermissions = new List<string>();

                    if (context?.Request?.ClientId != null)
                    {
                        apiResourcePermissions = await mediator.Send(new APIResourcePermissionsRequest { ClientId = context?.Request?.ClientId });
                    }

                    context.Result = new GrantValidationResult(
                            subject: userResponse.Data.UserId.ToString(),
                            authenticationMethod: "custom",
                            claims: GetUserClaims(userResponse.Data, apiResourcePermissions));

                    return;
                }

                context.Result = new GrantValidationResult(TokenRequestErrors.InvalidGrant, userResponse.Message);
                return;
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                context.Result = new GrantValidationResult(TokenRequestErrors.InvalidGrant, "Invalid credential");
            }
        }

        public static Claim[] GetUserClaims(UserModel user, IEnumerable<string> apiResourcePermissions)
        {

            List<Claim> claims = new()
            {
                new Claim("userid", user.UserId.ToString() ?? ""),
                new Claim(JwtClaimTypes.Name, user.DisplayName),
                new Claim(JwtClaimTypes.GivenName, user.FirstName  ?? ""),
                new Claim(JwtClaimTypes.FamilyName, user.LastName  ?? ""),
                new Claim(JwtClaimTypes.Email, user.Email  ?? ""),
                //new Claim(JwtClaimTypes.Profile, JsonConvert.SerializeObject(user.UserProfile)),
               // new Claim(nameof(user.Devices).ToLower(), JsonConvert.SerializeObject(user.Devices ?? m)),
                new Claim(nameof(user.EmailConfirmed).ToLower(), user.EmailConfirmed.ToString()),
                new Claim(nameof(user.MobileConfirmed).ToLower(), user.MobileConfirmed.ToString()),
                new Claim(nameof(user.PreferedLanguage).ToLower(), user.PreferedLanguage ?? ""),
                new Claim(nameof(user.UserName).ToLower(), user.UserName),
                new Claim(nameof(user.UserTypeId).ToLower(), user.UserTypeId.ToString()),
            };

            if (user.Roles != null)
            {
                foreach (RoleModel role in user.Roles)
                {
                    claims.Add(new Claim(IdentityClaim.RoleTypeClaim, role.RoleName));
                }
            }

            if (user.UserTypeId == (int)UserTypeEnum.Consumer)
            {
                claims.Add(new Claim(IdentityClaim.ApiResourceClaim, String.Join(',', apiResourcePermissions)));

                if (user.EnrolledBusinessUser)
                {
                    claims.Add(new Claim(JwtClaimTypes.Role, IdentityRoleType.BusinessUser));
                }
                else
                {
                    claims.Add(new Claim(JwtClaimTypes.Role, IdentityRoleType.ConsumerUser));
                }
            }
            else
            {
                claims.Add(new Claim(IdentityClaim.ApiResourceClaim, String.Join(',', apiResourcePermissions)));

                if (user.Roles != null && user.Roles.Any(t => t.RoleName != null && (t.RoleName.Equals("SuperAdmin", StringComparison.InvariantCultureIgnoreCase) || t.RoleName.Equals("Admin", StringComparison.InvariantCultureIgnoreCase))))
                {
                    claims.Add(new Claim(JwtClaimTypes.Role, IdentityRoleType.SuperAdmin));
                }
                else
                {
                    claims.Add(new Claim(JwtClaimTypes.Role, IdentityRoleType.StoreUser));
                }
            }

            return claims.ToArray();
        }

        private Task DispatchSignInEvent(int userid)
        {
            return eventDispatcher.Dispatch(new IdentityUserSignInEvent
            {
                UserId = userid,
                LoginTime = DateTime.UtcNow
            });
        }
    }
}
