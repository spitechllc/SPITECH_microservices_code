﻿namespace PapiPay.Identity.Application.Interfaces
{
    public interface IRandomCodeProvider
    {
        string GetCode();
    }
}
