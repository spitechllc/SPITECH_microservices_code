﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using PapiPay.Identity.Domain.Entities;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Interfaces
{
    public interface IIdentityDbContext
    {
        DbSet<Claim> Claims { get; set; }
        DbSet<Permission> Permissions { get; set; }
        DbSet<Role> Roles { get; set; }
        DbSet<User> Users { get; set; }
        DbSet<UserDevice> UserDevices { get; set; }
        DbSet<UserProfile> UserProfiles { get; set; }
        DbSet<UserRole> UserRoles { get; set; }
        DbSet<UserType> UserTypes { get; set; }

        DbSet<RoleType> RoleTypes { get; set; }
        DbSet<UserTenantMapping> TenantMasters { get; set; }
        DbSet<TenantMaster> TenantMaster { get; set; }
        public DbSet<LinkUser> LinkUsers
        {
            get; set;
        }

        DbSet<CodeVerification> CodeVerifications
        {
            get; set;
        }

        public DbSet<DeletedUser> DeletedUsers
        {
            get; set;
        }

        DbSet<DeletedUserProfile> DeletedUserProfiles
        {
            get; set;
        }
        DbSet<UserLoginLog> UserLoginLogs 
        { 
            get; set;
        }
        DbSet<UserPasswordChangeLog> UserPasswordChangeLogs
        { get; set; }
        DbSet<APIResourcePermission> APIResourcePermissions
        { get; set; }
        DbSet<ConsumerCase> ConsumerCases
        {
            get; set;
        }
        Task<int> SaveChangesAsync(CancellationToken cancellationToken);
        DatabaseFacade Database { get; }
    }
}
