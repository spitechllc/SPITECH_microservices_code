﻿namespace PapiPay.Identity.Application.Interfaces
{
    public interface IHashProvider
    {
        string GetHashValue(string input);
    }
}
