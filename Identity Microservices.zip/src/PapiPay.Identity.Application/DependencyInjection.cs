﻿using FluentValidation;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using PapiPay.ApplicationCore.Salesforce;
using PapiPay.EventBus.DomainEvents.Events.Identity;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.EventBus.DomainEvents.ServiceCollection;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Application.Services;
using PapiPay.Identity.Application.Services.Interfaces;
using PapiPay.Identity.Domain.Models;
using PapiPay.PaymentGateWay.Application.Services;
using System.Reflection;

namespace PapiPay.Identity.Application
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services, IConfiguration configuration)
        {
            services
                .AddMediatR(Assembly.GetExecutingAssembly())
                .AddAutoMapper(typeof(ClaimModel))
                .AddAutoMapper(typeof(DependencyInjection))
                .AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());

            services.AddScoped<IHashProvider, HashProvider>();
            services.AddScoped<IRandomCodeProvider, RandomCodeProvider>();
            //userunlock service
            //services.AddTransient<IUserUnlockService, UserUnlockService>();
             //services.AddHostedService<UserUnlockJobService>();
            // salesforce service
            services.AddScoped<ISalesforceHttpClientRepository, SalesforceHttpClientRepository>();

            // MassTransit-RabbitMQ Configuration
            services.RegisterMessageQueue(configuration, null, (ctx, cfg) =>
             {
                 cfg.ConfigurePublishEvent<IdentityForgotPasswordEvent>();
                 cfg.ConfigurePublishEvent<UserLinkedAccepterEvent>();
                 cfg.ConfigurePublishEvent<UserLinkedRequesterEvent>();
                 cfg.ConfigurePublishEvent<IdentityPasswordChangedEvent>();
                 cfg.ConfigurePublishEvent<IdentityUserCreatedEvent>();
                 cfg.ConfigurePublishEvent<IdentityUserSignInEvent>();
                 cfg.ConfigurePublishEvent<IdentityUserUpdatedEvent>();
                 cfg.ConfigurePublishEvent<IdentityUserVerificationCodeEvent>();
                 cfg.ConfigurePublishEvent<IdentityUserEmailVerifiedEvent>();
                 cfg.ConfigurePublishEvent<UserActivityLogEvent>();
             });
            return services;
        }
    }
}