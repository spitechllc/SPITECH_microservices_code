﻿using Microsoft.Extensions.DependencyInjection;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.BackgroudSerices;
using PapiPay.Identity.Application.Services.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.PaymentGateWay.Application.Services
{
    public class UserUnlockJobService : SchedulerJobService
    {
        private IUserUnlockService userUnlockService;
        private readonly ILogger<ScopeJobService> _logger;

        public UserUnlockJobService(ILogger<ScopeJobService> logger, IServiceProvider serviceProvider) : base(logger, serviceProvider)
        {
            _logger = logger;
        }

        protected override void CreateScope(IServiceScope serviceScope)
        {
            userUnlockService = serviceScope.ServiceProvider.GetRequiredService<IUserUnlockService>();
        }

        protected override Task ExecuteScheduleTaskAsync(CancellationToken stoppingToken)
        {
            return userUnlockService.UnlockUser(stoppingToken);
        }

        protected override Task<string> GetScheduleCron(IServiceScope serviceScope)
        {
            return Task.FromResult("00 0 * * *");//"00 0 * * *"  12AM CST
        }
    }
}