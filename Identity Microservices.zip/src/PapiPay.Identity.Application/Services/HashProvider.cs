﻿using IdentityServer4.Models;
using PapiPay.Identity.Application.Interfaces;
using System;

namespace PapiPay.Identity.Application.Services
{
    internal class HashProvider : IHashProvider
    {
        public string GetHashValue(string input)
        {
            return string.IsNullOrWhiteSpace(input) ? throw new ArgumentNullException(nameof(input)) : input.Sha256();
        }
    }
}
