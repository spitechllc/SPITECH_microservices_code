﻿using AutoMapper;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Application.Services.Interfaces;
using PapiPay.Identity.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.PaymentGateWay.Application.Services
{
    public class UserUnlockService : IUserUnlockService
    {
        private readonly IIdentityDbContext context;
        private readonly ILogger<UserUnlockService> logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;

        public UserUnlockService(IIdentityDbContext context,
            ILogger<UserUnlockService> logger,
            IMediator mediator,
            IMapper mapper)
        {
            this.context = context;
            this.logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
        }

       
        public async Task UnlockUser(CancellationToken stoppingToken)
        {
            try
            {
                IEnumerable<User> users = null;

                users = context.Users.Where(t => t.Lockout == true).ToList();
                if (users != null && users.Count() > 0)
                {
                    foreach (User item in users)
                    {
                        item.Lockout = false;
                        context.Users.Update(item);
                    }
                    int rowaffected = await context.SaveChangesAsync(stoppingToken);

                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }
    }
}