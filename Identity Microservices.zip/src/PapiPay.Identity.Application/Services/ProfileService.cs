﻿using IdentityServer4.Models;
using IdentityServer4.Services;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Application.Queries.GetAPIResourcePermissions;
using PapiPay.Identity.Application.Queries.GetUser;
using PapiPay.Identity.Application.Queries.GetUserById;
using PapiPay.Identity.Application.Validators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Services
{
    public class ProfileService : IProfileService
    {
        private readonly IMediator mediator;
        private readonly ILogger<ProfileService> logger;
        private readonly IIdentityDbContext _context;

        public ProfileService(IMediator mediator, ILogger<ProfileService> logger, IIdentityDbContext context)
        {
            this.mediator = mediator;
            this.logger = logger;
            _context = context;
        }

        public async Task GetProfileDataAsync(ProfileDataRequestContext context)
        {
            try
            {
                System.Security.Claims.Claim userId = context.Subject.Claims.FirstOrDefault(x => x.Type == "sub");

                if (context.Subject.Claims != null && context.Subject.Claims.Any())
                {
                    context.IssuedClaims = context.Subject.Claims.ToList();
                }
                else if (userId != null && !string.IsNullOrEmpty(userId?.Value) && int.Parse(userId.Value) > 0)
                {
                    Domain.Models.UserModel user = await mediator.Send(new GetUserByIdRequest { UserId = int.Parse(userId.Value) });

                    if (user != null)
                    {
                        var apiResourcePermissions = await mediator.Send(new APIResourcePermissionsRequest { RoleIds = user.Roles.Select(t => t.RoleId).ToList(), ClientId = context?.Client?.ClientId });

                        System.Security.Claims.Claim[] claims = ResourceOwnerPasswordValidator.GetUserClaims(user, apiResourcePermissions);

                        //context.IssuedClaims = claims.Where(x => context.RequestedClaimTypes.Contains(x.Type)).ToList();
                        context.IssuedClaims = claims.ToList();
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        public Task IsActiveAsync(IsActiveContext context)
        {
            try
            {
                System.Security.Claims.Claim userId = context.Subject.Claims.FirstOrDefault(x => x.Type == "userid");
                int userid = 0;

                if (userId != null && !string.IsNullOrEmpty(userId?.Value) && int.TryParse(userId.Value, out userid))
                {
                }

                if (userid <= 0)
                {
                    userId = context.Subject.Claims.FirstOrDefault(x => x.Type == "sub");
                    if (userId != null && !string.IsNullOrEmpty(userId?.Value) && int.TryParse(userId.Value, out userid))
                    {
                    }
                }

                if (userid > 0)
                {
                    var user = _context.Users.FirstOrDefault(t => t.UserId == userid && t.IsActive);

                    if (user != null)
                    {
                        context.IsActive = user.IsActive;
                    }
                    else
                    {
                        context.IsActive = false;
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }

            return Task.CompletedTask;
        }
    }
}
