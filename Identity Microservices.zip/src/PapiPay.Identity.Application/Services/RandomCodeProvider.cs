﻿using PapiPay.Identity.Application.Interfaces;
using System;

namespace PapiPay.Identity.Application.Services
{
    internal class RandomCodeProvider : IRandomCodeProvider
    {
        private readonly Random _random = new();
        public string GetCode()
        {
            return GenerateRandomNo().ToString("D4");
        }

        private int GenerateRandomNo()
        {
            int min = 1000;
            int max = 9999;
            return _random.Next(min, max);
        }
    }
}
