﻿using MediatR;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetUserWithNoPaymentMethod
{
    public class GetUserProfileByIdsModel
    {
        public List<int> UserIds { get; set; }
    }
    public class GetUserWithNoPaymentMethodRequest : GetUserProfileByIdsModel, IRequest<IEnumerable<User>>
    {
    }
}
