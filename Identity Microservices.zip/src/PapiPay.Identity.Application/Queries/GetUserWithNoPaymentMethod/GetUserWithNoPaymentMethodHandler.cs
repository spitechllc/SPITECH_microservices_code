﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Identity.Domain.Models;
using Renci.SshNet.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetUserWithNoPaymentMethod
{
    public class GetUserWithNoPaymentMethodHandler : IRequestHandler<GetUserWithNoPaymentMethodRequest, IEnumerable<User>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetUserWithNoPaymentMethodHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly AppSetting _appSetting;

        public GetUserWithNoPaymentMethodHandler(IIdentityDbContext context, ILogger<GetUserWithNoPaymentMethodHandler> logger, IMediator mediator, IMapper mapper, IOptionsMonitor<AppSetting> appSetting)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _appSetting = appSetting.CurrentValue;
        }

        public async Task<IEnumerable<User>> Handle(GetUserWithNoPaymentMethodRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            List<User> list = _context.Users.Include(t => t.UserProfile).AsNoTracking()
             .Where(t => !request.UserIds.Contains(t.UserId)).Where(x => x.UserTypeId == 1).ToList();
            List<User> userModellist = new List<User>();
            foreach (var result in list)
            {
                List<int> number = new List<int>();
                List<UserTenantMapping> userTenantMappings = _context.TenantMasters.Where(w => w.UserId == result.UserId).ToList();
                List<TenantMasterList> tenantMasterdata = new List<TenantMasterList>();
                foreach (var res in userTenantMappings)
                {
                    var data = _context.TenantMaster.Where(x => x.ID == res.TenantId);
                    foreach (var obj2 in data)
                    {
                        TenantMasterList tenantMasterList = new TenantMasterList();
                        tenantMasterList.TenantId = obj2.ID;
                        tenantMasterList.TenantName = obj2.TenantName;
                        tenantMasterdata.Add(tenantMasterList);
                    }
                }
                result.TenantMasterLists = tenantMasterdata;
                userModellist.Add(result);
            }
            list = userModellist;
            return await Task.FromResult(list);
        }
    }
}
