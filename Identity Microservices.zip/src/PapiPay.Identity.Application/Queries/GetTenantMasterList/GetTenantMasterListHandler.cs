﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Options;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Pagination;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Application.Queries.GetTenantMaster;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Service.Clients.SyncDataServices.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetTenantMasterList
{
    public class GetTenantMasterListHandler : IRequestHandler<GetTenantMasterListRequest, List<TenantMasterResponse>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetTenantMasterListRequest> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly AppSetting _appSetting;
        private readonly ITransactionServiceClient _transactionapiclient;

        public GetTenantMasterListHandler(IIdentityDbContext context, ILogger<GetTenantMasterListRequest> logger, IMediator mediator, IMapper mapper, IOptionsMonitor<AppSetting> appSetting, ITransactionServiceClient transactionapiclient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _appSetting = appSetting.CurrentValue;
            _transactionapiclient = transactionapiclient;
        }
        public async Task<List<TenantMasterResponse>> Handle(GetTenantMasterListRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            List<TenantMaster> list =  _context.TenantMaster.ToList();

            if (list == null)
            {
                return null;
            }
            List<TenantMasterResponse> Listdata = new List<TenantMasterResponse>();
            foreach (var item in list)
            {
                TenantMasterResponse tenantMasterResponse = new TenantMasterResponse();
                tenantMasterResponse.ID = item.ID;
                tenantMasterResponse.TenantName = item.TenantName;
                Listdata.Add(tenantMasterResponse);
            }
            _logger.TraceExitMethod(nameof(Handle), Listdata);

            return await Task.FromResult(Listdata);
        }
    }
}
