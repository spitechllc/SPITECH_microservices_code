﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Options;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Application.Queries.GetUserById;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Identity.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetUserTenantById
{

    public class GetUserTenantHandler : IRequestHandler<GetUserTenantRequest, UserTenantModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetUserTenantHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly AppSetting _appSetting;

        public GetUserTenantHandler(IIdentityDbContext context, ILogger<GetUserTenantHandler> logger, IMediator mediator, IMapper mapper, IOptionsMonitor<AppSetting> appSetting)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _appSetting = appSetting.CurrentValue;
        }

        public async Task<UserTenantModel> Handle(GetUserTenantRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            Domain.Entities.User user = _context.Users.Where(t => t.UserId == request.UserId).FirstOrDefault();

            if (user == null)
            {
                return null;
            }
            UserTenantModel userTenantModel = mapper.Map<UserTenantModel>(user);
            return await Task.FromResult(userTenantModel);
        }
    }
}
