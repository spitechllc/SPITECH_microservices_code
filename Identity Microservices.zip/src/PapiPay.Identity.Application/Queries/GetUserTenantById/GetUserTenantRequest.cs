﻿using MediatR;
using PapiPay.Identity.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetUserTenantById
{
    public class GetUserTenantRequest : IRequest<UserTenantModel>
    {
        public int UserId { get; set; }
    }
}
