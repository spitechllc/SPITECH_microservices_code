﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Pagination;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Application.Queries.GetAllUsersWithPaging;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Service.Clients.SyncDataServices.Interfaces;
using PapiPay.Service.Clients.Transactions;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Threading;
using ChoETL;
using System.Linq;
using PapiPay.Identity.Domain.Models;
using PapiPay.EventBus.DomainEvents.Enums;

namespace PapiPay.Identity.Application.Queries.GetTenantMaster
{
    internal class GetTenantMasterHandler : IRequestHandler<GetTenantMasterRequest, PaginatedList<TenantMasterModel>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetTenantMasterRequest> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly AppSetting _appSetting;
        private readonly ITransactionServiceClient _transactionapiclient;

        public GetTenantMasterHandler(IIdentityDbContext context, ILogger<GetTenantMasterRequest> logger, IMediator mediator, IMapper mapper, IOptionsMonitor<AppSetting> appSetting, ITransactionServiceClient transactionapiclient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _appSetting = appSetting.CurrentValue;
            _transactionapiclient = transactionapiclient;
        }
        public async Task<PaginatedList<TenantMasterModel>> Handle(GetTenantMasterRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            List<Domain.Entities.User> user = new List<Domain.Entities.User>();
            var users = _context.Users
                .Include(t => t.UserProfile)
                .Include(t => t.UserDevices)
                 .AsNoTracking().Where(w => w.UserTypeId == (int)UserTypeEnum.Consumer).Where(x => x.TenantId !=0);

            var data = users.Select(s => new TenantMasterModel
            {
                TenantName = s.TenantName,
                TenantId = s.TenantId
            }).Distinct().ToList();
            List<TenantMasterModel> list = new List<TenantMasterModel>();
            foreach (var item in data)
            {
                TenantMasterModel tenantMaster = new TenantMasterModel();
                tenantMaster.TenantId = item.TenantId;  
                tenantMaster.TenantName = item.TenantName;
                list.Add(tenantMaster);
            }

            _logger.TraceExitMethod(nameof(Handle), list);

            return await Task.FromResult(new PaginatedList<TenantMasterModel>
            {
                Data = list,
                TotalCount = list.Count,
            });
        }
    }
}
