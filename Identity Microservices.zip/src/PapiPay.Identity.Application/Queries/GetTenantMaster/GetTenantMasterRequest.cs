﻿using MediatR;
using PapiPay.ApplicationCore.Pagination;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetTenantMaster
{
    public class GetTenantMasterRequest : IRequest<PaginatedList<TenantMasterModel>>
    {
    }
}
