﻿using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetAPIResourcePermissions
{
    public class APIResourcePermissionsHandler : IRequestHandler<APIResourcePermissionsRequest, IEnumerable<string>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<APIResourcePermissionsHandler> _logger;

        public APIResourcePermissionsHandler(IIdentityDbContext context, ILogger<APIResourcePermissionsHandler> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<string>> Handle(APIResourcePermissionsRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            List<APIResourcePermission> aPIResourcePermissions = new List<APIResourcePermission>();

            if (!string.IsNullOrWhiteSpace(request.ClientId))
            {
                aPIResourcePermissions.AddRange(_context.APIResourcePermissions.Where(t => t.ClientId == request.ClientId).ToList());
            }

            if (request.RoleIds != null && request.RoleIds.Any())
            {
                List<string> claims = _context.Permissions.Where(p => request.RoleIds.Contains(p.RoleId)).Select(t => t.ClaimId).ToList();

                aPIResourcePermissions.AddRange(_context.APIResourcePermissions.Where(t => claims.Contains(t.ClaimId)).ToList());
            }

            _logger.TraceExitMethod(nameof(Handle), aPIResourcePermissions);

            return await Task.FromResult(aPIResourcePermissions.Select(t => t.APIResourceId).Distinct());
        }
    }
}
