﻿using MediatR;
using PapiPay.Identity.Domain.Entities;
using System.Collections.Generic;

namespace PapiPay.Identity.Application.Queries.GetAPIResourcePermissions
{
    public class APIResourcePermissionsRequest : IRequest<IEnumerable<string>>
    {
        public List<string> RoleIds { get; set; }
        public string ClientId { get; set; }
    }
}
