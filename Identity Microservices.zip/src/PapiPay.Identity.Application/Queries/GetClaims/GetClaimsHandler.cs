﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetClaims
{
    public class GetClaimsHandler : IRequestHandler<GetClaimsRequest, IEnumerable<ClaimModel>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetClaimsHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;

        public GetClaimsHandler(IIdentityDbContext context, ILogger<GetClaimsHandler> logger, IMediator mediator, IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
        }

        public async Task<IEnumerable<ClaimModel>> Handle(GetClaimsRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            List<Domain.Entities.Claim> result = _context.Claims
                 .AsNoTracking()
                 .ToList();

            if (result == null)
            {
                return null;
            }

            List<ClaimModel> response = result.Select(t => mapper.Map<ClaimModel>(t)).ToList();

            _logger.TraceExitMethod(nameof(Handle), response);

            return await Task.FromResult(response);
        }
    }
}
