﻿using MediatR;
using PapiPay.Identity.Domain.Models;
using System.Collections.Generic;

namespace PapiPay.Identity.Application.Queries.GetClaims
{
    public class GetClaimsRequest : IRequest<IEnumerable<ClaimModel>>
    {
    }
}
