﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Application.Queries.GetRoleType
{
    public class GetRoleTypeRequest : IRequest<ResponseList<RoleTypeModel>>
    {
    }
}
