﻿using AutoMapper;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Models;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetRoleType
{
    public class GetRoleTypeHandler : IRequestHandler<GetRoleTypeRequest, ResponseList<RoleTypeModel>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetRoleTypeHandler> _logger;
        private readonly IMediator _mediator = null;
        private readonly IMapper _mapper;

        public GetRoleTypeHandler(IIdentityDbContext context,
                                   ILogger<GetRoleTypeHandler> logger,
                                   IMediator mediator,
                                   IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
        }

        public async Task<ResponseList<RoleTypeModel>> Handle(GetRoleTypeRequest query, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), query);

            System.Collections.Generic.List<RoleTypeModel> response = _context.RoleTypes.Select(t => _mapper.Map<RoleTypeModel>(t)).ToList();

            _logger.TraceExitMethod(nameof(Handle), response);
            return await Task.FromResult(new ResponseList<RoleTypeModel> { Data = response });
        }
    }
}
