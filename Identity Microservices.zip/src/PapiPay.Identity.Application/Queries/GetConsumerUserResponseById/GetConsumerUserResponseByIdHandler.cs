﻿using AutoMapper;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Application.Queries.GetUserById;
using PapiPay.Identity.Domain.Models.Consumers;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetConsumerUserResponseById
{
    public class GetConsumerUserResponseByIdHandler : IRequestHandler<GetConsumerUserResponseByIdRequest, ConsumerUserResponseModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetConsumerUserResponseByIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;

        public GetConsumerUserResponseByIdHandler(IIdentityDbContext context, ILogger<GetConsumerUserResponseByIdHandler> logger, IMediator mediator, IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
        }

        public async Task<ConsumerUserResponseModel> Handle(GetConsumerUserResponseByIdRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            ConsumerUserResponseModel result = null;
            Domain.Models.UserModel userModel = await _mediator.Send(new GetUserByIdRequest { UserId = request.UserId });

            if (userModel != null)
            {
                result = mapper.Map<ConsumerUserResponseModel>(userModel);
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
