﻿using MediatR;
using PapiPay.Identity.Domain.Models.Consumers;

namespace PapiPay.Identity.Application.Queries.GetConsumerUserResponseById
{
    public class GetConsumerUserResponseByIdRequest : IRequest<ConsumerUserResponseModel>
    {
        public int UserId { get; set; }
    }
}
