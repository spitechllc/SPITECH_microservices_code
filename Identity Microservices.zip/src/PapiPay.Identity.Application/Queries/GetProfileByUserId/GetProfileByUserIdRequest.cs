﻿using MediatR;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Application.Queries.GetProfileByUserId
{
    public class GetProfileByUserIdRequest : IRequest<UserProfileModel>
    {
        public int UserId { get; set; }
    }
}
