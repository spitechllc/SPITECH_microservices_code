﻿using AutoMapper;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Application.Queries.GetUserById;
using PapiPay.Identity.Domain.Models;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetProfileByUserId
{
    public class GetProfileByUserIdHandler : IRequestHandler<GetProfileByUserIdRequest, UserProfileModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetProfileByUserIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;

        public GetProfileByUserIdHandler(IIdentityDbContext context, ILogger<GetProfileByUserIdHandler> logger, IMediator mediator, IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
        }

        public async Task<UserProfileModel> Handle(GetProfileByUserIdRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            UserModel userModel = await _mediator.Send(new GetUserByIdRequest { UserId = request.UserId });

            _logger.TraceExitMethod(nameof(Handle), userModel.UserProfile);

            return userModel.UserProfile;
        }
    }
}
