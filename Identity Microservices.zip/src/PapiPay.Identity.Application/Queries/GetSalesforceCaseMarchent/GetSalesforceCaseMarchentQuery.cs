﻿using MediatR;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Application.Queries.GetSalesforceCaseMarchent
{
    public class GetSalesforceCaseMarchentQuery : IRequest<SalesForceCaseModels>
    {
        public int UserId { get; set; }
    }
}
