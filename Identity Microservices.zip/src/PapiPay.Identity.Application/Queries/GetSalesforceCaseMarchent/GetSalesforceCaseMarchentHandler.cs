﻿using FluentValidation.Results;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.ApplicationCore.Salesforce;
using PapiPay.Identity.Domain.Models;
using System;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetSalesforceCaseMarchent
{
    public class GetSalesforceCaseMarchentHandler : IRequestHandler<GetSalesforceCaseMarchentQuery, SalesForceCaseModels>
    {
        private readonly ILogger<GetSalesforceCaseMarchentHandler> logger;
        private readonly ISalesforceHttpClientRepository _salesforceHttpClient;
        public GetSalesforceCaseMarchentHandler(ILogger<GetSalesforceCaseMarchentHandler> logger,
            ISalesforceHttpClientRepository salesforceHttpClient)
        {
            this.logger = logger;
            _salesforceHttpClient = salesforceHttpClient;
        }

        public async Task<SalesForceCaseModels> Handle(GetSalesforceCaseMarchentQuery request, CancellationToken cancellationToken)
        {
            SalesForceCaseModels result = null;
            string contactid = await FindContact(request.UserId);
            if (string.IsNullOrEmpty(contactid))
            {
                throw new ValidationException(new ValidationFailure("SalesforceConsumer",
                    $" Userid not found in salesforce Contact entity"));
            }

            string querystring = string.Format(@"q=SELECT +
                                 CaseNumber
                                ,Origin
                                ,OwnerId
                                ,Reason
                                ,Case_Status__c
                                ,AccountId
                                ,Consumer__c
                                ,ContactEmail
                                ,ContactFax
                                ,ContactMobile
                                ,ContactId
                                ,ContactPhone
                                ,CreatedById
                                ,ClosedDate
                                ,CreatedDate
                                ,Description
                                ,IsEscalated
                                ,Comments
                                ,Language
                                ,LastModifiedById
                                ,ParentId
                                ,Priority
                                ,Status
                                ,Subject
                                ,Support_Level__c
                                ,Type
                                ,SuppliedEmail
                                + from+Case
                                +WHERE+contactId+ = '{0}'", contactid);

            HttpResponseMessage res = await _salesforceHttpClient.SendRequest(HttpMethod.Get, "query/", null, null, querystring);

            if (res.IsSuccessStatusCode)
            {
                //Saved succesfully.
                string strjson = await res.Content.ReadAsStringAsync();
                result = Newtonsoft.Json.JsonConvert.DeserializeObject<SalesForceCaseModels>(strjson);
            }

            return result;

        }
        private async Task<string> FindContact(int userid)
        {
            string contactid = string.Empty;
            try
            {
                string contactquery = string.Format(@"q=SELECT Id,PapiPay_UserId__c  from contact WHERE PapiPay_UserId__c = '{0}' ", userid);
                HttpResponseMessage contacts = await _salesforceHttpClient.SendRequest(HttpMethod.Get, "query/", null, null, contactquery);
                if (contacts.IsSuccessStatusCode)
                {
                    string strcontact = await contacts.Content.ReadAsStringAsync();
                    SalesforceContactModel contact = Newtonsoft.Json.JsonConvert.DeserializeObject<SalesforceContactModel>(strcontact);


                    if (contact != null && contact.records.Count > 0)
                    {
                        contactid = contact.records.Select(x => x.Id).FirstOrDefault();
                    }
                }
            }
            catch (Exception ex)
            {

                logger.Error(ex);
            };
            return contactid;
        }
    }
}
