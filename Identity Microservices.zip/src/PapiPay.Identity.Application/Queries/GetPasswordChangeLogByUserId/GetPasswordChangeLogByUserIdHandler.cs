﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Identity.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetPasswordChangeLogByUserId
{
    public class GetPasswordChangeLogByUserIdHandler : IRequestHandler<GetPasswordChangeLogByUserIdRequest, IEnumerable<UserPasswordChangeLogModel>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetPasswordChangeLogByUserIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly AppSetting _appSetting;

        public GetPasswordChangeLogByUserIdHandler(IIdentityDbContext context, ILogger<GetPasswordChangeLogByUserIdHandler> logger, IMediator mediator, IMapper mapper, IOptionsMonitor<AppSetting> appSetting)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _appSetting = appSetting.CurrentValue;
        }

        public async Task<IEnumerable<UserPasswordChangeLogModel>> Handle(GetPasswordChangeLogByUserIdRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            List<Domain.Entities.UserPasswordChangeLog> user = _context.UserPasswordChangeLogs.Where(t => t.UserId == request.UserId).ToList();

            if (user == null)
            {
                return null;
            }

            IEnumerable<UserPasswordChangeLogModel> userModel = mapper.Map<IEnumerable<UserPasswordChangeLogModel>>(user);

           
            _logger.TraceExitMethod(nameof(Handle), userModel);

            return await Task.FromResult(userModel);
        }
    }
}
