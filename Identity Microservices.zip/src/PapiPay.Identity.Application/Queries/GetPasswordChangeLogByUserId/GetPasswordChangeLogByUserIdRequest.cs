﻿using MediatR;
using PapiPay.Identity.Domain.Models;
using System.Collections.Generic;

namespace PapiPay.Identity.Application.Queries.GetPasswordChangeLogByUserId
{
    public class GetPasswordChangeLogByUserIdRequest : IRequest<IEnumerable<UserPasswordChangeLogModel>>
    {
        public int UserId { get; set; }
    }
}
