﻿using AutoMapper;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Application.Queries.GetUserById;
using PapiPay.Identity.Domain.Models.Stores;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetStoreUserResponseById
{
    public class GetStoreUserResponseByIdHandler : IRequestHandler<GetStoreUserResponseByIdRequest, StoreUserResponseModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetStoreUserResponseByIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;

        public GetStoreUserResponseByIdHandler(IIdentityDbContext context, ILogger<GetStoreUserResponseByIdHandler> logger, IMediator mediator, IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
        }

        public async Task<StoreUserResponseModel> Handle(GetStoreUserResponseByIdRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            StoreUserResponseModel result = null;
            Domain.Models.UserModel userModel = await _mediator.Send(new GetUserByIdRequest { UserId = request.UserId });

            if (userModel != null)
            {
                result = mapper.Map<StoreUserResponseModel>(userModel);
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
