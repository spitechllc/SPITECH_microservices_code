﻿using MediatR;
using PapiPay.Identity.Domain.Models.Stores;

namespace PapiPay.Identity.Application.Queries.GetStoreUserResponseById
{
    public class GetStoreUserResponseByIdRequest : IRequest<StoreUserResponseModel>
    {
        public int UserId { get; set; }
    }
}
