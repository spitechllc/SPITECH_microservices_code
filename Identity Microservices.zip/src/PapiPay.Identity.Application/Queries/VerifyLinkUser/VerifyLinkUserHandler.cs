﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.VerifyLinkUser
{
    public class VerifyLinkUserHandler : IRequestHandler<VerifyLinkUserQuery, List<LinkUserModel>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<VerifyLinkUserHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;

        public VerifyLinkUserHandler(IIdentityDbContext context, ILogger<VerifyLinkUserHandler> logger, IMediator mediator, IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
        }

        public async Task<List<LinkUserModel>> Handle(VerifyLinkUserQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            List<Domain.Entities.LinkUser> linkuser = _context.LinkUsers
                 .AsNoTracking()
                 .Where(t => ((t.RequestedUserId == request.FromUserId && t.AcceptUserId == request.ToUserId) || (t.RequestedUserId == request.ToUserId && t.AcceptUserId == request.FromUserId)) && t.IsAccepted == true && t.IsActive == true).ToList();

            if (linkuser == null)
            {
                return null;
            }

            List<LinkUserModel> linkuserModel = mapper.Map<List<LinkUserModel>>(linkuser);

            _logger.TraceExitMethod(nameof(Handle), linkuserModel);

            return await Task.FromResult(linkuserModel);
        }
    }
}