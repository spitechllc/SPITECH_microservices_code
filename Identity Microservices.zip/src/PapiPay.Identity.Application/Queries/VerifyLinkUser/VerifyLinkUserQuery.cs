﻿using MediatR;
using PapiPay.Identity.Domain.Models;
using System.Collections.Generic;

namespace PapiPay.Identity.Application.Queries.VerifyLinkUser
{
    public class VerifyLinkUserQuery : IRequest<List<LinkUserModel>>
    {
        public int FromUserId { get; set; }

        public int ToUserId { get; set; }
    }
}
