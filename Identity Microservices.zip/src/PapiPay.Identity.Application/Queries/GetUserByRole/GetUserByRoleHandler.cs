﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Identity.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetUserByRole
{
    public class GetUserByRoleHandler : IRequestHandler<GetUserByRoleRequest, List<UserModel>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetUserByRoleHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly AppSetting _appSetting;

        public GetUserByRoleHandler(IIdentityDbContext context, ILogger<GetUserByRoleHandler> logger, IMediator mediator, IMapper mapper, IOptionsMonitor<AppSetting> appSetting)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _appSetting = appSetting.CurrentValue;
        }

        public async Task<List<UserModel>> Handle(GetUserByRoleRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            List<Domain.Entities.User> users = _context.Users
                .Include(t => t.UserProfile)
                 .AsNoTracking()
                 .Where(t => t.UserTypeId ==(int)UserTypeEnum.Store).ToList();

            
            if (users == null)
            {
                return null;
            }
            var userModels = mapper.Map<List<UserModel>>(users.ToList());
            List<UserModel> result=new();
            foreach (var res in userModels)
            {
                List<Domain.Entities.UserRole> userRoles = _context.UserRoles
                                        .Include(t => t.Role)
                                        .ThenInclude(t => t.Permissions)
                                        .ThenInclude(t => t.Claim)
                                        .AsNoTracking()
                                        .Where(t => t.UserId == res.UserId).ToList();

                res.Roles = userRoles.Select(t =>
                {
                    RoleModel role = mapper.Map<RoleModel>(t.Role);
                    role.Claims = t.Role.Permissions.Select(t => mapper.Map<ClaimModel>(t.Claim));
                    return role;
                }).ToList();
                res.PasswordHash = string.Empty;
                if(res.Roles.Select(t=>t.RoleId==request.RoleId).Count()>0)
                {
                    result.Add(res);
                }
            }
           
            
            _logger.TraceExitMethod(nameof(Handle), result);

            return await Task.FromResult(result);
        }
    }
}
