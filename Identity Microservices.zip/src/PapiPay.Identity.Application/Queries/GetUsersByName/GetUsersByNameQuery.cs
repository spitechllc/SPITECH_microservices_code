﻿using MediatR;
using PapiPay.Identity.Domain.Models;
using System.Collections.Generic;

namespace PapiPay.Identity.Application.Queries.GetUsersByName
{
    public class GetUsersByNameQuery : IRequest<IEnumerable<UserModel>>
    {
        public string Name { get; set; }
    }
}
