﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Identity.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetUsersByName
{
    public class GetUsersByNameHandler : IRequestHandler<GetUsersByNameQuery, IEnumerable<UserModel>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetUsersByNameHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly AppSetting _appSetting;

        public GetUsersByNameHandler(IIdentityDbContext context, ILogger<GetUsersByNameHandler> logger, IMediator mediator, IMapper mapper, IOptionsMonitor<AppSetting> appSetting)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _appSetting = appSetting.CurrentValue;
        }

        public async Task<IEnumerable<UserModel>> Handle(GetUsersByNameQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            if (string.IsNullOrEmpty(request.Name))
            {
                return null;
            }

            IQueryable<Domain.Entities.User> ss = from u in _context.Users.Include(t => t.UserProfile) where (u.UserTypeId == (int)UserTypeEnum.Consumer) || (u.UserTypeId == (int)UserTypeEnum.Store && u.EnrolledBusinessUser == true) select u;

            IQueryable<Domain.Entities.User> userList = ss
                .Where(w => (w.FirstName.Trim() + " " + w.LastName.Trim()).Contains(request.Name))
                .Include(t => t.UserProfile)
                 .AsNoTracking().Distinct();

            if (userList == null)
            {
                return null;
            }

            IEnumerable<UserModel> userModel = mapper.Map<IEnumerable<UserModel>>(userList);
            foreach (UserModel user in userModel)
            {


                user.UserProfile = mapper.Map<UserProfileModel>(userList.Where(s => s.UserId == user.UserId).Select(s => s.UserProfile).FirstOrDefault());

                if (user.UserTypeId == (int)UserTypeEnum.Consumer)
                {
                    List<Domain.Entities.UserDevice> devices = _context.UserDevices.AsNoTracking().Where(t => t.UserId == user.UserId).ToList();

                    user.Devices = mapper.Map<List<EventBus.DomainEvents.Models.Identity.UserDeviceModel>>(devices);
                }
                else
                {
                    List<Domain.Entities.UserRole> userRoles = _context.UserRoles
                                            .Include(t => t.Role)
                                            .ThenInclude(t => t.Permissions)
                                            .ThenInclude(t => t.Claim)
                                            .AsNoTracking()
                                            .Where(t => t.UserId == user.UserId).ToList();

                    user.Roles = userRoles.Select(t =>
                    {
                        RoleModel role = mapper.Map<RoleModel>(t.Role);
                        role.Claims = t.Role.Permissions.Select(t => mapper.Map<ClaimModel>(t.Claim));
                        return role;
                    });
                }

                user.PasswordHash = string.Empty;
                user.EnableInvoicingFeature = _appSetting.EnableInvoicingFeature;
            }
            _logger.TraceExitMethod(nameof(Handle), userModel);

            return await Task.FromResult(userModel);
        }
    }
}
