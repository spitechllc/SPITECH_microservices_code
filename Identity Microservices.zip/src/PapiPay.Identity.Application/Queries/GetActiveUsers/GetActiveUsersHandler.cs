﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Extensions;
using PapiPay.ApplicationCore.Pagination;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Identity.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetActiveUsers
{
    public class GetActiveUsersHandler : IRequestHandler<GetActiveUsersRequest, PaginatedList<ActiveUsersSearchResult>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetActiveUsersHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly AppSetting _appSetting;

        public GetActiveUsersHandler(IIdentityDbContext context, ILogger<GetActiveUsersHandler> logger, IMediator mediator, IMapper mapper, IOptionsMonitor<AppSetting> appSetting)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _appSetting = appSetting.CurrentValue;
        }

        public async Task<PaginatedList<ActiveUsersSearchResult>> Handle(GetActiveUsersRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IEnumerable<ActiveUsersSearchResult> activeUsersSearchResult = null;
            var users = _context.Users
                 .Include(t => t.UserProfile)
                  .AsNoTracking().Where(w => w.UserTypeId == (int)UserTypeEnum.Store && w.UserProfile.IsLoggedIn == true);

            if (users == null)
            {
                return null;
            }

            var totalRecords = users.Count();

            string fname = string.Empty;

            if (request.UserId > 0)
            {
                users = users.Where(t => t.UserId == request.UserId);
            }

            if (!string.IsNullOrWhiteSpace(request.FirstName))
            {
                users = users.Where(t => t.FirstName.Contains(request.FirstName));
            }

            if (!string.IsNullOrWhiteSpace(request.LastName))
            {
                users = users.Where(t => t.LastName.Contains(request.LastName));
            }


            var userModels = mapper.Map<List<UserModel>>(users.ToList());



            activeUsersSearchResult = mapper.Map<IEnumerable<ActiveUsersSearchResult>>(users);

            List<Domain.Entities.UserLoginLog> userLoginLogs = _context.UserLoginLogs.AsNoTracking().Where(t => activeUsersSearchResult.Select(t => t.UserId).ToList().Contains(t.UserId)).ToList();

            foreach (ActiveUsersSearchResult activeUserModel in activeUsersSearchResult)
            {
                activeUserModel.LastAccessTime = userLoginLogs?.Where(t => t.UserId == activeUserModel.UserId).Reverse().Skip(1).Take(1).FirstOrDefault()?.LoginDate;
                activeUserModel.LoginDateTime = (DateTime)userModels.Where(t => t.UserId == activeUserModel.UserId).FirstOrDefault()?.UserProfile.LastLogin;
                if (activeUserModel.LoginDateTime!= null)
                {
                    TimeSpan duration = DateTime.UtcNow.Subtract(activeUserModel.LoginDateTime);
                    activeUserModel.ActiveDuration = duration.ToString(@"hh\:mm\:ss");
                }
            }

            
            if (request.SortOrder != null && request.SortBy != null)
            {
                if (request.SortOrder == SortOrderEnum.Asc)
                {
                    switch (request.SortBy.Value)
                    {
                        case Domain.Enums.UserSortBy.None:
                        case Domain.Enums.UserSortBy.UserId:
                        case Domain.Enums.UserSortBy.CreatedDate:
                            activeUsersSearchResult = activeUsersSearchResult.OrderBy(t => t.UserId);
                            break;
                        case Domain.Enums.UserSortBy.FirstName:
                            activeUsersSearchResult = activeUsersSearchResult.OrderBy(t => t.FirstName);
                            break;
                        case Domain.Enums.UserSortBy.LastName:
                            activeUsersSearchResult = activeUsersSearchResult.OrderBy(t => t.LastName);
                            break;
                        case Domain.Enums.UserSortBy.LoginDatetime:
                            activeUsersSearchResult = activeUsersSearchResult.OrderBy(t => t.LoginDateTime);
                            break;
                        case Domain.Enums.UserSortBy.LastAccessTime:
                            activeUsersSearchResult = activeUsersSearchResult.OrderBy(t => t.LastAccessTime);
                            break;
                        case Domain.Enums.UserSortBy.ActiveDuration:
                            activeUsersSearchResult = activeUsersSearchResult.OrderBy(t => t.ActiveDuration);
                            
                            break;
                    }
                }
                else
                {
                    switch (request.SortBy.Value)
                    {
                        case Domain.Enums.UserSortBy.None:
                        case Domain.Enums.UserSortBy.UserId:
                        case Domain.Enums.UserSortBy.CreatedDate:
                            activeUsersSearchResult = activeUsersSearchResult.OrderByDescending(t => t.UserId);
                            break;
                        case Domain.Enums.UserSortBy.FirstName:
                            activeUsersSearchResult = activeUsersSearchResult.OrderByDescending(t => t.FirstName);
                            break;
                        case Domain.Enums.UserSortBy.LastName:
                            activeUsersSearchResult = activeUsersSearchResult.OrderByDescending(t => t.LastName);
                            break;
                        case Domain.Enums.UserSortBy.LoginDatetime:
                            activeUsersSearchResult = activeUsersSearchResult.OrderByDescending(t => t.LoginDateTime);
                            break;
                        case Domain.Enums.UserSortBy.LastAccessTime:
                            activeUsersSearchResult = activeUsersSearchResult.OrderByDescending(t => t.LastAccessTime);
                            break;
                        case Domain.Enums.UserSortBy.ActiveDuration:
                            activeUsersSearchResult = activeUsersSearchResult.OrderByDescending(t => t.ActiveDuration);

                            break;
                    }
                }
            }
            else
            {
                activeUsersSearchResult = activeUsersSearchResult.OrderByDescending(t => t.UserId);
            }

            if (request.PageIndex > 0 && request.PageSize > 0)
            {
                activeUsersSearchResult = activeUsersSearchResult.Skip((request.PageIndex - 1) * request.PageSize).Take(request.PageSize);
            }


            _logger.TraceExitMethod(nameof(Handle), userModels);

            return await Task.FromResult(new PaginatedList<ActiveUsersSearchResult>
            {
                Data = activeUsersSearchResult.ToList(),
                PageIndex = request.PageIndex,
                PageSize = request.PageSize,
                TotalCount = totalRecords,
            });
        }
    }
}
