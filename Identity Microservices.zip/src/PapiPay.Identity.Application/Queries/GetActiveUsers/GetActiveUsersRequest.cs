﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.ApplicationCore.Pagination;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Domain.Enums;
using PapiPay.Identity.Domain.Models;
using System.Collections.Generic;

namespace PapiPay.Identity.Application.Queries.GetActiveUsers
{
    public class GetActiveUsersRequest : IRequest<PaginatedList<ActiveUsersSearchResult>>
    {
        public int? UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public UserSortBy? SortBy { get; set; }
        public SortOrderEnum? SortOrder { get; set; }
    }
}
