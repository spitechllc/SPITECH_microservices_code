﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Identity.Domain.Models;
using Renci.SshNet.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetUserByDate
{
    public class GetUserByDateHandler : IRequestHandler<GetUserByDateRequest, IEnumerable<UserModel>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetUserByDateHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly AppSetting _appSetting;

        public GetUserByDateHandler(IIdentityDbContext context, ILogger<GetUserByDateHandler> logger, IMediator mediator, IMapper mapper, IOptionsMonitor<AppSetting> appSetting)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _appSetting = appSetting.CurrentValue;
        }

        public async Task<IEnumerable<UserModel>> Handle(GetUserByDateRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            if (request == null || request.StartDate == null)
            {
                return null;
            }

            DateTime startDate = request.StartDate.Value.Date;
            DateTime endDate = request.EndDate.Value.Date.AddDays(1).AddSeconds(-1);

            List<Domain.Entities.User> users = _context.Users
            .Include(t => t.UserProfile)
                 .AsNoTracking()
                 .Where(x => x.CreatedOn >= startDate && x.CreatedOn <= endDate)
                 .Where(x => x.UserTypeId == 1).ToList();
            if (users == null)
            {
                return null;
            }

            IEnumerable<UserModel> userModels = mapper.Map<IEnumerable<UserModel>>(users);


            List<Domain.Entities.UserDevice> devices = _context.UserDevices.AsNoTracking()
                .Where(x => x.CreatedOn >= request.StartDate)
                 .Where(x => x.CreatedOn <= request.EndDate).ToList();

            foreach (UserModel userModel in userModels)
            {
                userModel.UserProfile = mapper.Map<UserProfileModel>(userModel.UserProfile);

                if (userModel.UserTypeId == (int)UserTypeEnum.Consumer)
                {
                    userModel.Devices = mapper.Map<List<EventBus.DomainEvents.Models.Identity.UserDeviceModel>>(devices.Where(x => x.CreatedOn >= request.StartDate)
                              .Where(x => x.CreatedOn <= request.EndDate).ToList());
                }

                userModel.PasswordHash = string.Empty;
                userModel.EnableInvoicingFeature = _appSetting.EnableInvoicingFeature;
            }
            List<UserModel> userModellist = new List<UserModel>();
            foreach (var result in userModels)
            {
                List<int> number = new List<int>();
                List<UserTenantMapping> userTenantMappings = _context.TenantMasters.Where(w => w.UserId == result.UserId).ToList();
                List<TenantMasterList> tenantMasterdata = new List<TenantMasterList>();
                foreach (var res in userTenantMappings)
                {
                    var data = _context.TenantMaster.Where(x => x.ID == res.TenantId);
                    foreach (var obj2 in data)
                    {
                        TenantMasterList tenantMasterList = new TenantMasterList();
                        tenantMasterList.TenantId = obj2.ID;
                        tenantMasterList.TenantName = obj2.TenantName;
                        tenantMasterdata.Add(tenantMasterList);
                    }
                }
                result.TenantMasterLists = tenantMasterdata;
                userModellist.Add(result);
            }
            userModels = userModellist;

            _logger.TraceExitMethod(nameof(Handle), userModels);

            return await Task.FromResult(userModels);
        }
    }
}
