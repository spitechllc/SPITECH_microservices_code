﻿using MediatR;
using PapiPay.Identity.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetUserByDate
{
    public class GetUserByDateModel
    {
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }

    public class GetUserByDateRequest : GetUserByDateModel, IRequest<IEnumerable<UserModel>>
    {

    }
}
