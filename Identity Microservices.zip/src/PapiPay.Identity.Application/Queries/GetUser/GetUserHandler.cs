﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Identity.Domain.Models;
using Polly;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using static PapiPay.ApplicationCore.Domain.DomainConstant;

namespace PapiPay.Identity.Application.Queries.GetUser
{
    public class GetUserHandler : IRequestHandler<GetUserRequest, ResponseModel<UserModel>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetUserHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IHashProvider hashProvider;
        private readonly AppSetting _appSetting;
        private readonly IAuthenticationProvider _authenticationProvider;

        public GetUserHandler(IIdentityDbContext context, ILogger<GetUserHandler> logger, IMediator mediator, IMapper mapper, IHashProvider hashProvider, IOptionsMonitor<AppSetting> appSetting,
            IAuthenticationProvider authenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.hashProvider = hashProvider;
            _appSetting = appSetting.CurrentValue;
            _authenticationProvider = authenticationProvider;
        }

        public async Task<ResponseModel<UserModel>> Handle(GetUserRequest request, CancellationToken cancellationToken)
        {
            _logger.Warn($"Hit Connect Token : {request.ClientId}");

            _logger.TraceEnterMethod(nameof(Handle), request);
            ResponseModel<UserModel> response = new() { Success = false };

            var tenant = _authenticationProvider.GetTenantAuthentication();
            
            User user = new User();
            User userTenantName = new User();
            var PassH = hashProvider.GetHashValue(request.Password);
            if (request.TenantName != null)
            {
                userTenantName = _context.Users.Where(x => x.UserName == request.UserName 
                && x.PasswordHash == PassH 
                && x.TenantName == request.TenantName).FirstOrDefault();
            }
            else
            {
                userTenantName = _context.Users.Where(x => x.UserName == request.UserName && x.PasswordHash == PassH).FirstOrDefault();
            }
            _logger.Warn($"User TenantName : {userTenantName}");
            if (userTenantName != null)
            {
                request.TenantName = userTenantName.TenantName;
            }
            else {
                request.TenantName = "";
            }
            if (request.TenantName == TenantName.TheStation)
            {
                _logger.Warn($"THEStation block");

                user = request.UserTypeId == (int)UserTypeEnum.Consumer
               ? _context.Users
                       .Include(t => t.UserProfile)
                       .AsNoTracking()
                       .Where(t => t.UserName == request.UserName && t.UserTypeId == request.UserTypeId
                       && t.TenantName == TenantName.TheStation && t.PasswordHash == PassH)
                       .FirstOrDefault()
               : _context.Users
                       .Include(t => t.UserProfile)
                       .Include(t => t.UserRoles).ThenInclude(t => t.Role).ThenInclude(t => t.Permissions)
                       .AsNoTracking()
                       .Where(t => t.UserName == request.UserName).Where(t => t.TenantName == TenantName.TheStation && t.PasswordHash == PassH)
                       .FirstOrDefault();
            }
            else if (request.TenantName == "Verifone")
            {
                _logger.Warn($"Verifone block");
                user = request.UserTypeId == (int)UserTypeEnum.Consumer
                               ? _context.Users
                                       .Include(t => t.UserProfile)
                                       .AsNoTracking()
                                       .Where(t => t.UserName == request.UserName && t.UserTypeId == request.UserTypeId
                                       && t.TenantName == "Verifone" && t.PasswordHash == PassH)
                                       .FirstOrDefault()
                               : _context.Users
                                       .Include(t => t.UserProfile)
                                       .Include(t => t.UserRoles).ThenInclude(t => t.Role).ThenInclude(t => t.Permissions)
                                       .AsNoTracking()
                                       .Where(t => t.UserName == request.UserName).Where(t => t.TenantName == "Verifone" && t.PasswordHash == PassH)
                                       .FirstOrDefault();
            }
            else
            {
                _logger.Warn($"Papipay block");

                user = request.UserTypeId == (int)UserTypeEnum.Consumer
               ? _context.Users
                       .Include(t => t.UserProfile)
                       .AsNoTracking()
                       .Where(t => t.UserName == request.UserName && t.PasswordHash == PassH
                       && t.UserTypeId == request.UserTypeId)
                       .FirstOrDefault()
               : _context.Users
                       .Include(t => t.UserProfile)
                       .Include(t => t.UserRoles).ThenInclude(t => t.Role).ThenInclude(t => t.Permissions)
                       .AsNoTracking()
                       .Where(t => t.UserName == request.UserName && t.PasswordHash == PassH)
                       .FirstOrDefault();
            }
           
            if (user == null)
            {
                _logger.Warn($"user not forund");

                response.Success = false;
                response.Message = "Invalid credential";
                return response;
            }

            if (!string.IsNullOrWhiteSpace(request.Password))
            {
                //if (user.PasswordHash != hashProvider.GetHashValue(request.Password))
                //{
                //    response.Success = false;
                //    response.Message = "Invalid credential";
                //    return response;
                //}
                if (user.UserTypeId == (int)UserTypeEnum.Consumer && !user.MobileConfirmed)
                {
                    response.Success = false;
                    response.Message = "Invalid credential"; //"Mobile not confirmed yet";
                    return response;
                }

                if (request.ClientId == "papipaybusiness_mobile" && !user.EnrolledBusinessUser)
                {
                    response.Success = false;
                    response.Message = "You are not enrolled as business user. Please contact support team";
                    return response;
                }
            }

            UserModel userModel = mapper.Map<UserModel>(user);
            userModel.UserProfile = mapper.Map<UserProfileModel>(user.UserProfile);

            if (user.UserTypeId == (int)UserTypeEnum.Consumer)
            {
                var rolesInDB = _context.Roles.Include(t => t.Permissions).ThenInclude(t=>t.Claim).Where(t => t.RoleId == "ConsumerUser").ToList();
                userModel.Roles = rolesInDB.Select(t =>
                {
                    RoleModel role = mapper.Map<RoleModel>(t);
                    role.Claims = t.Permissions.Select(t => mapper.Map<ClaimModel>(t.Claim));
                    return role;
                }).ToList();
            }
            else
            {
                userModel.Roles = user.UserRoles.Select(t =>
                {
                    RoleModel role = mapper.Map<RoleModel>(t.Role);
                    role.Claims = t.Role.Permissions.Select(t => mapper.Map<ClaimModel>(t.Claim));
                    return role;
                }).ToList();
            }

            userModel.EnableInvoicingFeature = _appSetting.EnableInvoicingFeature;
            _logger.TraceExitMethod(nameof(Handle), userModel);

            response.Data = userModel;
            response.Success = userModel != null;

            return await Task.FromResult(response);
        }
    }
}
