﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Application.Queries.GetUser
{
    public class GetUserRequest : IRequest<ResponseModel<UserModel>>
    {
        public string UserName { get; set; }
        public int UserTypeId { get; set; }
        public string Password { get; set; }
        public string ClientId { get; set; }
        public string TenantName { get; set; }
    }
}
