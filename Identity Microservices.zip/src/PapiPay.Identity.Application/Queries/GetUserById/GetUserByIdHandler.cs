﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Identity.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetUserById
{
    public class GetUserByIdHandler : IRequestHandler<GetUserByIdRequest, UserModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetUserByIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly AppSetting _appSetting;

        public GetUserByIdHandler(IIdentityDbContext context, ILogger<GetUserByIdHandler> logger, IMediator mediator, IMapper mapper, IOptionsMonitor<AppSetting> appSetting)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _appSetting = appSetting.CurrentValue;
        }

        public async Task<UserModel> Handle(GetUserByIdRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            Domain.Entities.User user = _context.Users
                .Include(t => t.UserProfile)
                 .AsNoTracking()
                 .FirstOrDefault(t => t.UserId == request.UserId);

            if (user == null)
            {
                return null;
            }

            UserModel userModel = mapper.Map<UserModel>(user);

            userModel.UserProfile = mapper.Map<UserProfileModel>(user.UserProfile);

            if (user.UserTypeId == (int)UserTypeEnum.Consumer)
            {
                List<Domain.Entities.UserDevice> devices = _context.UserDevices.AsNoTracking().Where(t => t.UserId == user.UserId).ToList();

                userModel.Devices = mapper.Map<List<EventBus.DomainEvents.Models.Identity.UserDeviceModel>>(devices);
            }
            else
            {
                List<Domain.Entities.UserRole> userRoles = _context.UserRoles
                                        .Include(t => t.Role)
                                        .ThenInclude(t => t.Permissions)
                                        .ThenInclude(t => t.Claim)
                                        .AsNoTracking()
                                        .Where(t => t.UserId == user.UserId).ToList();

                userModel.Roles = userRoles.Select(t =>
                {
                    RoleModel role = mapper.Map<RoleModel>(t.Role);
                    role.Claims = t.Role.Permissions.Select(t => mapper.Map<ClaimModel>(t.Claim));
                    return role;
                }).ToList();
            }

            userModel.PasswordHash = string.Empty;
            userModel.DeviceType = ((DeviceType)userModel.Devices.Select(d => d.DeviceTypeId).LastOrDefault()).ToString();
            userModel.MobileAppType = ((MobileAppType)userModel.Devices.Select(d => d.MobileAppTypeId).LastOrDefault()).ToString();

            userModel.EnableInvoicingFeature = _appSetting.EnableInvoicingFeature;
            _logger.TraceExitMethod(nameof(Handle), userModel);

            return await Task.FromResult(userModel);
        }
    }
}
