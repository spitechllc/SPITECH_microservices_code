﻿using MediatR;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Application.Queries.GetUserById
{
    public class GetUserByIdRequest : IRequest<UserModel>
    {
        public int UserId { get; set; }
    }
}
