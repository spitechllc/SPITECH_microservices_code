﻿using MediatR;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Identity.Domain.Models;
using System;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GoogleAPIAddress
{
    public class GoogleAPIAddressHandler : IRequestHandler<GoogleAPIAddressQuery, GoogleAddressModel>
    {
        private readonly ILogger<GoogleAPIAddressHandler> _logger;

        private readonly GoogleAPIOption _option;
        public GoogleAPIAddressHandler(ILogger<GoogleAPIAddressHandler> logger, IOptionsMonitor<GoogleAPIOption> option)
        {
            _logger = logger;
            _option = option.CurrentValue;
        }
        public async Task<GoogleAddressModel> Handle(GoogleAPIAddressQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            GoogleAddressModel model = new();
            using (HttpClient client = new())
            {
                HttpResponseMessage response = await client.GetAsync($"https://maps.googleapis.com/maps/api/geocode/json?address={request.Zipcode}&key={_option.GoogleAPIKey}");
                if (response.IsSuccessStatusCode)
                {
                    string strjson = await response.Content.ReadAsStringAsync();

                    GoogleAddressResponse res = JsonConvert.DeserializeObject<GoogleAddressResponse>(strjson);

                    if (res != null && res.results.Count > 0)
                    {
                        foreach (AddressComponent item in res.results[0].address_components)
                        {
                            if (item.types.FirstOrDefault() == "country")
                            {
                                model.Country = item.long_name;
                            }
                            else if (item.types.FirstOrDefault() == "administrative_area_level_1")
                            {
                                model.State = item.long_name;
                            }
                            else if (item.types.FirstOrDefault() == "locality")
                            {
                                model.City = item.long_name;
                            }
                        }

                        if (res.results.Count > 0 && res.results[0].geometry != null)
                        {
                            model.Latitude = Convert.ToString(res.results[0].geometry.location?.lat);
                            model.Longitude = Convert.ToString(res.results[0].geometry.location?.lng);
                        }
                    }
                }
            }

            return model;
        }
    }
}
