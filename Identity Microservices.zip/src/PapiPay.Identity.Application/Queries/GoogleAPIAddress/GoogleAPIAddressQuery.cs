﻿using MediatR;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Application.Queries.GoogleAPIAddress
{
    public class GoogleAPIAddressQuery : IRequest<GoogleAddressModel>
    {
        public string Zipcode { get; set; }
    }
}
