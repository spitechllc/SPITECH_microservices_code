﻿using AutoMapper;
using ChoETL;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.BankFileParsers;
using PapiPay.ApplicationCore.Pagination;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Application.Queries.GetAllUsersWithPaging;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Identity.Domain.Models;
using PapiPay.Service.Clients.Payments;
using PapiPay.Service.Clients.SyncDataServices.Interfaces;
using PapiPay.Service.Clients.Transactions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetUserWithMOP
{
    public class GetAllUserMopHandler : IRequestHandler<GetAllUserMopQuery, PaginatedList<UserMOPModel>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetAllUserMopHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly AppSetting _appSetting;
        private readonly ITransactionServiceClient _transactionapiclient;
        private readonly IPaymentServiceClient _paymentServiceClient;

        public GetAllUserMopHandler(IIdentityDbContext context, ILogger<GetAllUserMopHandler> logger, IMediator mediator, IMapper mapper, IOptionsMonitor<AppSetting> appSetting, ITransactionServiceClient transactionapiclient, IPaymentServiceClient paymentServiceClient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _appSetting = appSetting.CurrentValue;
            _transactionapiclient = transactionapiclient;
            _paymentServiceClient = paymentServiceClient;
        }
        public async Task<PaginatedList<UserMOPModel>> Handle(GetAllUserMopQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);


            var users = _context.Users
                  .Include(t => t.UserProfile)
                  .Include(t => t.UserDevices)
                   .AsNoTracking().Where(w => w.UserTypeId == (int)UserTypeEnum.Consumer);
                   
            string fname = string.Empty;

            ICollection<TransactionModel> lastTransactionDetails = new List<TransactionModel>();

            if (request.UserId > 0)
            {
                users = users.Where(t => t.UserId == request.UserId);
            }

            if (!string.IsNullOrWhiteSpace(request.FirstName))
            {
                users = users.Where(t => t.FirstName.Contains(request.FirstName));
            }

            if (!string.IsNullOrWhiteSpace(request.LastName))
            {
                users = users.Where(t => t.LastName.Contains(request.LastName));
            }

            if (!string.IsNullOrWhiteSpace(request.Email))
            {
                users = users.Where(t => t.Email.Contains(request.Email));
            }

            if (!string.IsNullOrWhiteSpace(request.Mobile))
            {
                users = users.Where(t => t.MobileNumber.Contains(request.Mobile));
            }
            if (request.Locked.HasValue)
            {
                users = users.Where(t => t.Lockout == request.Locked);
            }
            var totalRecords = users.Count();

            if (request.SortOrder != null && request.SortBy != null)
            {
                if (request.SortOrder == EventBus.DomainEvents.Enums.SortOrderEnum.Asc)
                {
                    switch (request.SortBy.Value)
                    {
                        case Domain.Enums.UserSortBy.None:
                        case Domain.Enums.UserSortBy.UserId:
                        case Domain.Enums.UserSortBy.CreatedDate:
                            users = users.OrderBy(t => t.UserId);
                            break;
                        case Domain.Enums.UserSortBy.FirstName:
                            users = users.OrderBy(t => t.FirstName);
                            break;
                        case Domain.Enums.UserSortBy.LastName:
                            users = users.OrderBy(t => t.LastName);
                            break;
                        case Domain.Enums.UserSortBy.Email:
                            users = users.OrderBy(t => t.Email);
                            break;
                        case Domain.Enums.UserSortBy.Mobile:
                            users = users.OrderBy(t => t.MobileNumber);
                            break;
                        case Domain.Enums.UserSortBy.IsActive:
                            users = users.OrderBy(t => t.IsActive);
                            break;
                        case Domain.Enums.UserSortBy.Device:
                            users = users.OrderBy(t => t.UserDevices.OrderByDescending(d => d.UserDeviceId).FirstOrDefault().DeviceTypeId);
                            break;
                    }
                }
                else
                {
                    switch (request.SortBy.Value)
                    {
                        case Domain.Enums.UserSortBy.None:
                        case Domain.Enums.UserSortBy.UserId:
                        case Domain.Enums.UserSortBy.CreatedDate:
                            users = users.OrderByDescending(t => t.UserId);
                            break;
                        case Domain.Enums.UserSortBy.FirstName:
                            users = users.OrderByDescending(t => t.FirstName);
                            break;
                        case Domain.Enums.UserSortBy.LastName:
                            users = users.OrderByDescending(t => t.LastName);
                            break;
                        case Domain.Enums.UserSortBy.Email:
                            users = users.OrderByDescending(t => t.Email);
                            break;
                        case Domain.Enums.UserSortBy.Mobile:
                            users = users.OrderByDescending(t => t.MobileNumber);
                            break;
                        case Domain.Enums.UserSortBy.IsActive:
                            users = users.OrderByDescending(t => t.IsActive);
                            break;
                        case Domain.Enums.UserSortBy.Device:
                            users = users.OrderByDescending(t => t.UserDevices.OrderByDescending(d => d.UserDeviceId).FirstOrDefault().DeviceTypeId);
                            break;
                    }
                }
            }
            else
            {
                users = users.OrderByDescending(t => t.UserId);
            }

            if (request.PageIndex > 0 && request.PageSize > 0)
            {
                users = users.Skip((request.PageIndex - 1) * request.PageSize).Take(request.PageSize);
            }

            var userModels = mapper.Map<List<UserMOPModel>>(users.ToList());

            _logger.TraceExitMethod(nameof(Handle), userModels);

            var UserMop = await _paymentServiceClient.GetAllUserMOPAsync();
            CardDetail itemD = new CardDetail();

            foreach (var item in userModels)
            {
                List<CardDetail> Details = new List<CardDetail>();
                var MOPDetails = UserMop.Data.Where(x => x.UserId == item.UserId).ToList();
                if (MOPDetails.Count() > 0)
                {
                    foreach (var dataItem in MOPDetails)
                    {
                        var itemDetail = new CardDetail()
                        {
                            UserId = dataItem.UserId,
                            CardName = dataItem.CardName,
                            CardType = dataItem.CardType,
                            CardNumber = dataItem.CardNumber
                        };
                        Details.Add(itemDetail);
                    }
                }
                item.CardDetails = Details;
            }

            return await Task.FromResult(new PaginatedList<UserMOPModel>
            {
                Data = userModels,
                PageIndex = request.PageIndex,
                PageSize = request.PageSize,
                TotalCount = totalRecords,
            });
        }
    }
}
