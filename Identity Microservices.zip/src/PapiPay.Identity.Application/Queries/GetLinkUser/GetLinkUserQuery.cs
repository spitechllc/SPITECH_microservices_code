﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Application.Queries.GetLinkUser
{
    public class GetLinkUserQuery : IRequest<ResponseList<UserModel>>
    {
        public int UserId { get; set; }
    }
}