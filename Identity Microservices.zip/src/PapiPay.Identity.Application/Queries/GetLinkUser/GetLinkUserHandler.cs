﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Application.Queries.GetUserByIds;
using PapiPay.Service.Clients.Finance;
using PapiPay.Service.Clients.SyncDataServices.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using UserModel = PapiPay.Identity.Domain.Models.UserModel;

namespace PapiPay.Identity.Application.Queries.GetLinkUser
{
    public class GetLinkUserHandler : IRequestHandler<GetLinkUserQuery, ResponseList<UserModel>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetLinkUserHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IFinanceServiceClient _financeapiclient;

        public GetLinkUserHandler(IIdentityDbContext context, ILogger<GetLinkUserHandler> logger, IMediator mediator, IMapper mapper, IFinanceServiceClient financeclient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _financeapiclient = financeclient;
        }

        public async Task<ResponseList<UserModel>> Handle(GetLinkUserQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            List<Domain.Entities.LinkUser> linkusers = _context.LinkUsers
                 .AsNoTracking()
                 .Where(t => (t.RequestedUserId == request.UserId || t.AcceptUserId == request.UserId)
                            && t.IsAccepted == true && t.IsActive == true).ToList();

            if (linkusers == null)
            {
                return null;
            }

            IEnumerable<UserModel> users = new List<UserModel>();

            List<int> requestedUserIds = linkusers.Where(t => t.RequestedUserId != request.UserId).Select(t => t.RequestedUserId).ToList();
            List<int> acceptedUserIds = linkusers.Where(t => t.AcceptUserId != request.UserId).Select(t => t.AcceptUserId).ToList();


            List<int> userIds = requestedUserIds.Concat(acceptedUserIds).Distinct().ToList();

            if (userIds != null && userIds.Any())
            {
                users = await _mediator.Send(new GetUserByIdsRequest() { UserIds = userIds });
                UserWalletModelResponseList usersWalletBalance = null;

                try
                {
                    usersWalletBalance = await _financeapiclient.GetUserWalletListAsync(userIds);
                }
                catch (Exception ex)
                {
                    _logger.Error(ex);
                }

                if (users != null && usersWalletBalance != null && usersWalletBalance.Data != null)
                {
                    foreach (int userId in userIds)
                    {
                        UserModel user = users.FirstOrDefault(t => t.UserId == userId);
                        UserWalletModel walletamount = usersWalletBalance.Data.FirstOrDefault(t => t.UserId == userId);

                        if (walletamount != null)
                        {
                            user.TotalWalletAmount = walletamount.TotalAvailableAmount;
                        }
                    }
                }
            }

            _logger.TraceExitMethod(nameof(Handle), users);

            return new ResponseList<UserModel>() { Data = users };
        }
    }
}