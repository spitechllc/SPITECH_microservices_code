﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Identity.Domain.Models;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetUserByNameForLog
{
    public class GetUserByNameForLogHandler : IRequestHandler<GetUserByNameForLogRequest, ResponseModel<UserModel>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetUserByNameForLogHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IHashProvider hashProvider;
        private readonly AppSetting _appSetting;

        public GetUserByNameForLogHandler(IIdentityDbContext context, ILogger<GetUserByNameForLogHandler> logger, IMediator mediator, IMapper mapper, IHashProvider hashProvider, IOptionsMonitor<AppSetting> appSetting)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.hashProvider = hashProvider;
            _appSetting = appSetting.CurrentValue;
        }

        public async Task<ResponseModel<UserModel>> Handle(GetUserByNameForLogRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            ResponseModel<UserModel> response = new() { Success = false };

            User user = _context.Users
                        .Include(t => t.UserProfile)
                        .AsNoTracking()
                        .Where(t => t.UserName == request.UserName)
                        .FirstOrDefault();
            if (user == null)
            {
                response.Success = false;
                response.Message = "Invalid credential";
                return response;
            }

            UserModel userModel = mapper.Map<UserModel>(user);
            userModel.UserProfile = mapper.Map<UserProfileModel>(user.UserProfile);

            

            _logger.TraceExitMethod(nameof(Handle), userModel);

            response.Data = userModel;
            response.Success = userModel != null;

            return await Task.FromResult(response);
        }
    }
}
