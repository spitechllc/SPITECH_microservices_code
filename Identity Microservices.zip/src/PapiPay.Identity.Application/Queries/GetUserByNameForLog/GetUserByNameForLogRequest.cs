﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Application.Queries.GetUserByNameForLog
{
    public class GetUserByNameForLogRequest:IRequest<ResponseModel<UserModel>>
    {
        public string UserName { get; set; }
    }
}
