﻿using MediatR;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Application.Queries.GetUserByEmailOrPhone
{
    public class GetUserByEmailOrPhoneRequest : IRequest<UserModel>
    {
        public string MobileOrEmail { get; set; }
    }
}
