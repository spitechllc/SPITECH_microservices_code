﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Extensions;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Identity.Domain.Models;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetUserByEmailOrPhone
{
    public class GetUserByEmailOrPhoneHandler : IRequestHandler<GetUserByEmailOrPhoneRequest, UserModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetUserByEmailOrPhoneHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly AppSetting _appSetting;

        public GetUserByEmailOrPhoneHandler(IIdentityDbContext context, ILogger<GetUserByEmailOrPhoneHandler> logger, IMediator mediator, IMapper mapper, IOptionsMonitor<AppSetting> appSetting)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _appSetting = appSetting.CurrentValue;
        }

        public async Task<UserModel> Handle(GetUserByEmailOrPhoneRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IQueryable<Domain.Entities.User> ss = from u in _context.Users.Include(t => t.UserProfile) where (u.UserTypeId == (int)UserTypeEnum.Consumer) || (u.UserTypeId == (int)UserTypeEnum.Store && u.EnrolledBusinessUser == true) select u;

            Domain.Entities.User user = ss
                .WhereIf(!string.IsNullOrEmpty(request.MobileOrEmail) && request.MobileOrEmail.Contains("@"), t => t.Email == request.MobileOrEmail)
                .WhereIf(!string.IsNullOrEmpty(request.MobileOrEmail) && !request.MobileOrEmail.Contains("@"), t => t.MobileNumber == request.MobileOrEmail)
                .Include(t => t.UserProfile)
                 .AsNoTracking()
                 .FirstOrDefault();

            if (user == null)
            {
                return null;
            }

            UserModel userModel = mapper.Map<UserModel>(user);

            userModel.UserProfile = mapper.Map<UserProfileModel>(user.UserProfile);

            if (user.UserTypeId == (int)UserTypeEnum.Consumer)
            {
                userModel.Devices = _context.UserDevices.AsNoTracking().Where(t => t.UserId == user.UserId).ToList().Select(t => new EventBus.DomainEvents.Models.Identity.UserDeviceModel
                {
                    UserDeviceId = t.UserDeviceId,
                    MobileAppTypeId = t.MobileAppTypeId,
                    DeviceToken = t.DeviceToken,
                    IsOnline = t.IsOnline,
                    DeviceTypeId = t.DeviceTypeId,
                    UserId = t.UserId,
                });
            }
            else
            {
                System.Collections.Generic.List<Domain.Entities.UserRole> userRoles = _context.UserRoles
                                        .Include(t => t.Role)
                                        .ThenInclude(t => t.Permissions)
                                        .ThenInclude(t => t.Claim)
                                        .AsNoTracking()
                                        .Where(t => t.UserId == user.UserId).ToList();

                userModel.Roles = userRoles.Select(t =>
                {
                    RoleModel role = mapper.Map<RoleModel>(t.Role);
                    role.Claims = t.Role.Permissions.Select(t => mapper.Map<ClaimModel>(t.Claim));
                    return role;
                });
            }

            userModel.PasswordHash = string.Empty;
            userModel.EnableInvoicingFeature = _appSetting.EnableInvoicingFeature;

            _logger.TraceExitMethod(nameof(Handle), userModel);

            return await Task.FromResult(userModel);
        }
    }
}
