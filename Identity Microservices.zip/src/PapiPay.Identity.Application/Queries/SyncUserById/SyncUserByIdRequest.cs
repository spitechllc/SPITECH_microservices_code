﻿using MediatR;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Application.Queries.SyncUserById
{
    public class SyncUserByIdRequest : IRequest<UserModel>
    {
        public int UserId { get; set; }
    }
}
