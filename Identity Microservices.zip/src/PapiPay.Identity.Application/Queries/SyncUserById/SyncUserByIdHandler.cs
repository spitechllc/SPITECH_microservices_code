﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.EventBus.DomainEvents;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using UserTypeEnum = PapiPay.EventBus.DomainEvents.Enums.UserTypeEnum;

namespace PapiPay.Identity.Application.Queries.SyncUserById
{
    public class SyncUserByIdHandler : IRequestHandler<SyncUserByIdRequest, UserModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<SyncUserByIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IEventDispatcher eventDispatcher;

        public SyncUserByIdHandler(IIdentityDbContext context, ILogger<SyncUserByIdHandler> logger, IMediator mediator, IMapper mapper,
            IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.eventDispatcher = eventDispatcher;
        }

        public async Task<UserModel> Handle(SyncUserByIdRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            Domain.Entities.User user = _context.Users
                .Include(t => t.UserProfile)
                 .AsNoTracking()
                 .FirstOrDefault(t => t.UserId == request.UserId);

            if (user == null)
            {
                return null;
            }

            UserModel userModel = mapper.Map<UserModel>(user);
            userModel.UserProfile = mapper.Map<UserProfileModel>(user.UserProfile);

            if (user.UserTypeId == (int)UserTypeEnum.Consumer)
            {
                List<Domain.Entities.UserDevice> devices = _context.UserDevices.AsNoTracking().Where(t => t.UserId == user.UserId).ToList();

                userModel.Devices = mapper.Map<List<EventBus.DomainEvents.Models.Identity.UserDeviceModel>>(devices);
            }
            else
            {
                List<Domain.Entities.UserRole> userRoles = _context.UserRoles
                                        .Include(t => t.Role)
                                        .ThenInclude(t => t.Permissions)
                                        .ThenInclude(t => t.Claim)
                                        .AsNoTracking()
                                        .Where(t => t.UserId == user.UserId).ToList();

                userModel.Roles = userRoles.Select(t =>
                {
                    RoleModel role = mapper.Map<RoleModel>(t.Role);
                    role.Claims = t.Role.Permissions.Select(t => mapper.Map<ClaimModel>(t.Claim));
                    return role;
                });
            }

            userModel.PasswordHash = string.Empty;
            _logger.TraceExitMethod(nameof(Handle), userModel);
            return await Task.FromResult(userModel);
        }
    }
}
