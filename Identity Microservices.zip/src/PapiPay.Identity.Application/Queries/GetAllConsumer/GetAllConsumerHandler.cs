﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Pagination;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Models;
using PapiPay.Service.Clients.SyncDataServices.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetAllConsumer
{
    public class GetAllConsumerHandler : IRequestHandler<GetAllConsumerQuery, PaginatedList<UserConsumerModel>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetAllConsumerHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;

        public GetAllConsumerHandler(IIdentityDbContext context, ILogger<GetAllConsumerHandler> logger, IMediator mediator, IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
        }
        public async Task<PaginatedList<UserConsumerModel>> Handle(GetAllConsumerQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            var users = _context.Users
                  .Include(t => t.UserProfile)
                  .Include(t => t.UserDevices)
                   .AsNoTracking().Where(w => w.UserTypeId == (int)UserTypeEnum.Consumer);

            var totalRecords = users.Count();

            if (request.PageIndex > 0 && request.PageSize > 0)
            {
                users = users.Skip((request.PageIndex - 1) * request.PageSize).Take(request.PageSize);
            }

            var userModels = mapper.Map<List<UserConsumerModel>>(users.ToList());

            _logger.TraceExitMethod(nameof(Handle), userModels);

            return await Task.FromResult(new PaginatedList<UserConsumerModel>
            {
                Data = userModels,
                PageIndex = request.PageIndex,
                PageSize = request.PageSize,
                TotalCount = totalRecords,
            });
        }
    }
}
