﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.EventBus.DomainEvents.Models.Identity;
using PapiPay.Identity.Application.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetUserDeviceByUserId
{
    public class GetUserDeviceByUserIdHandler : IRequestHandler<GetUserDeviceByUserIdRequest, List<UserDeviceModel>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetUserDeviceByUserIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;

        public GetUserDeviceByUserIdHandler(IIdentityDbContext context, ILogger<GetUserDeviceByUserIdHandler> logger, IMediator mediator, IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
        }

        public async Task<List<UserDeviceModel>> Handle(GetUserDeviceByUserIdRequest request, CancellationToken cancellationToken)
        {
            List<UserDeviceModel> devices = mapper.Map<List<UserDeviceModel>>(_context.UserDevices
                       .AsNoTracking()
                       .Where(t => t.UserId == request.UserId).ToList());

            _logger.TraceExitMethod(nameof(Handle), devices);

            return await Task.FromResult(devices);
        }
    }
}
