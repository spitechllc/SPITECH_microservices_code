﻿using MediatR;
using PapiPay.EventBus.DomainEvents.Models.Identity;
using System.Collections.Generic;

namespace PapiPay.Identity.Application.Queries.GetUserDeviceByUserId
{
    public class GetUserDeviceByUserIdRequest : IRequest<List<UserDeviceModel>>
    {
        public int UserId { get; set; }
    }
}
