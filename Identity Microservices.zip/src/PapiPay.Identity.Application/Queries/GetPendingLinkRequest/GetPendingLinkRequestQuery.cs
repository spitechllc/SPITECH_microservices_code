﻿using MediatR;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Application.Queries.GetPendingLinkRequest
{
    public class GetPendingLinkRequestQuery : IRequest<LinkUserModel>
    {
        public int UserId { get; set; }
    }
}
