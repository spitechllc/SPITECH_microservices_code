﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Models;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetPendingLinkRequest
{
    public class GetPendingLinkRequestHandler : IRequestHandler<GetPendingLinkRequestQuery, LinkUserModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetPendingLinkRequestHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;

        public GetPendingLinkRequestHandler(IIdentityDbContext context, ILogger<GetPendingLinkRequestHandler> logger, IMediator mediator, IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
        }

        public async Task<LinkUserModel> Handle(GetPendingLinkRequestQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            IQueryable<Domain.Entities.LinkUser> linkuser = _context.LinkUsers
                 .AsNoTracking()
                 .Where(t => t.AcceptUserId == request.UserId && t.IsAccepted == null);

            if (linkuser == null)
            {
                return null;
            }

            LinkUserModel linkuserModel = mapper.Map<LinkUserModel>(linkuser);


            _logger.TraceExitMethod(nameof(Handle), linkuserModel);

            return await Task.FromResult(linkuserModel);
        }
    }
}
