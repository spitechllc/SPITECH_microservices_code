﻿using MediatR;
using PapiPay.Identity.Domain.Models;
using System.Collections.Generic;

namespace PapiPay.Identity.Application.Queries.GetRoles
{
    public class GetRolesRequest : IRequest<IEnumerable<RoleModel>>
    {
    }
}
