﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetRoles
{
    public class GetRolesHandler : IRequestHandler<GetRolesRequest, IEnumerable<RoleModel>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetRolesHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;

        public GetRolesHandler(IIdentityDbContext context, ILogger<GetRolesHandler> logger, IMediator mediator, IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
        }

        public async Task<IEnumerable<RoleModel>> Handle(GetRolesRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            List<Domain.Entities.Role> roles = _context.Roles
                            .Include(t => t.Permissions)
                            .ThenInclude(t => t.Claim)
                            .AsNoTracking()
                            .ToList();

            if (roles == null)
            {
                return null;
            }

            IEnumerable<RoleModel> response = roles.Select(t =>
            {
                RoleModel role = mapper.Map<RoleModel>(t);
                role.RoleType = ((EntityRoleType)role.RoleTypeId).ToString();
                role.Claims = t.Permissions.Select(t => mapper.Map<ClaimModel>(t.Claim));
                return role;
            });

            _logger.TraceExitMethod(nameof(Handle), response);

            return await Task.FromResult(response);
        }
    }
}