﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Models;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetRoleById
{
    public class GetRoleByIdHandler : IRequestHandler<GetRoleByIdRequest, RoleModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetRoleByIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;

        public GetRoleByIdHandler(IIdentityDbContext context, ILogger<GetRoleByIdHandler> logger, IMediator mediator, IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
        }

        public async Task<RoleModel> Handle(GetRoleByIdRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            Domain.Entities.Role roles = _context.Roles
                            .Include(t => t.Permissions)
                            .ThenInclude(t => t.Claim)
                            .AsNoTracking()
                            .FirstOrDefault(t => t.RoleId == request.RoleId);

            if (roles == null)
            {
                return null;
            }

            RoleModel role = mapper.Map<RoleModel>(roles);
            role.RoleType = ((EntityRoleType)role.RoleTypeId).ToString(); ;
            role.Claims = roles.Permissions.Select(t => mapper.Map<ClaimModel>(t.Claim));

            _logger.TraceExitMethod(nameof(Handle), role);

            return await Task.FromResult(role);
        }
    }
}
