﻿using FluentValidation;

namespace PapiPay.Identity.Application.Queries.GetRoleById
{
    public class GetRoleByIdValidator : AbstractValidator<GetRoleByIdRequest>
    {
        public GetRoleByIdValidator()
        {
            RuleFor(x => x.RoleId).NotNull();

        }
    }
}
