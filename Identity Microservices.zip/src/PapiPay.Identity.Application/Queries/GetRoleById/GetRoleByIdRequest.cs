﻿using MediatR;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Application.Queries.GetRoleById
{
    public class GetRoleByIdRequest : IRequest<RoleModel>
    {
        public string RoleId { get; set; }
    }
}
