﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Identity.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetUserByIds
{
    public class GetUserByIdsHandler : IRequestHandler<GetUserByIdsRequest, IEnumerable<UserModel>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetUserByIdsHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly AppSetting _appSetting;

        public GetUserByIdsHandler(IIdentityDbContext context, ILogger<GetUserByIdsHandler> logger, IMediator mediator, IMapper mapper, IOptionsMonitor<AppSetting> appSetting)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _appSetting = appSetting.CurrentValue;
        }

        public async Task<IEnumerable<UserModel>> Handle(GetUserByIdsRequest request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            if (request == null || request.UserIds == null)
            {
                return null;
            }

            IEnumerable<int> userIds = request.UserIds.Distinct();

            List<Domain.Entities.User> users = _context.Users
                .Include(t => t.UserProfile)
                 .AsNoTracking()
                 .Where(t => userIds.Contains(t.UserId)).ToList();

            if (users == null)
            {
                return null;
            }

            IEnumerable<UserModel> userModels = mapper.Map<IEnumerable<UserModel>>(users);

            userIds = users.Select(t => t.UserId).ToList();

            List<Domain.Entities.UserDevice> devices = _context.UserDevices.AsNoTracking().Where(t => userIds.Contains(t.UserId)).ToList();

            foreach (UserModel userModel in userModels)
            {
                userModel.UserProfile = mapper.Map<UserProfileModel>(userModel.UserProfile);

                if (userModel.UserTypeId == (int)UserTypeEnum.Consumer)
                {
                    userModel.Devices = mapper.Map<List<EventBus.DomainEvents.Models.Identity.UserDeviceModel>>(devices.Where(t => t.UserId == userModel.UserId).ToList());
                }
                else
                {
                    List<Domain.Entities.UserRole> userRoles = _context.UserRoles
                                       .Include(t => t.Role)
                                       .ThenInclude(t => t.Permissions)
                                       .ThenInclude(t => t.Claim)
                                       .AsNoTracking()
                                       .Where(t => t.UserId == userModel.UserId).ToList();

                    userModel.Roles = userRoles.Select(t =>
                    {
                        RoleModel role = mapper.Map<RoleModel>(t.Role);
                        role.Claims = t.Role.Permissions.Select(t => mapper.Map<ClaimModel>(t.Claim));
                        return role;
                    });
                }

                userModel.PasswordHash = string.Empty;
                userModel.EnableInvoicingFeature = _appSetting.EnableInvoicingFeature;
            }

            List<UserModel> userModellist = new List<UserModel>();
            foreach (var result in userModels)
            {
                List<int> number = new List<int>();
                List<UserTenantMapping> userTenantMappings = _context.TenantMasters.Where(w => w.UserId == result.UserId).ToList();
                List<TenantMasterList> tenantMasterdata = new List<TenantMasterList>();
                foreach (var res in userTenantMappings)
                {
                    var data = _context.TenantMaster.Where(x => x.ID == res.TenantId);
                    foreach (var obj2 in data)
                    {
                        TenantMasterList tenantMasterList = new TenantMasterList();
                        tenantMasterList.TenantId = obj2.ID;
                        tenantMasterList.TenantName = obj2.TenantName;
                        tenantMasterdata.Add(tenantMasterList);
                    }
                }
                result.TenantMasterLists = tenantMasterdata;
                userModellist.Add(result);
            }
            userModels = userModellist;

            _logger.TraceExitMethod(nameof(Handle), userModels);

            return await Task.FromResult(userModels);
        }
    }
}
