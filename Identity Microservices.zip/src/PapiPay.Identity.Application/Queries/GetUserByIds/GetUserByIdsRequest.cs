﻿using MediatR;
using PapiPay.Identity.Domain.Models;
using System.Collections.Generic;

namespace PapiPay.Identity.Application.Queries.GetUserByIds
{
    public class GetUserByIdsRequest : IRequest<IEnumerable<UserModel>>
    {
        public List<int> UserIds { get; set; }
    }
}
