﻿using MediatR;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Application.Queries.GetSalesforceCase
{
    public class GetSalesforceCaseQuery : IRequest<SalesForceCaseModels>
    {
        public int UserId { get; set; }
    }
}
