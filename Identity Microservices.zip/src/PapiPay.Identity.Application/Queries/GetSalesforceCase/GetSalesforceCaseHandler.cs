﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.ApplicationCore.Salesforce;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Models;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Queries.GetSalesforceCase
{
    public class GetSalesforceCaseHandler : IRequestHandler<GetSalesforceCaseQuery, SalesForceCaseModels>
    {
        //  private readonly ISalesforceHttpClientRepository _salesforceHttpClient;
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetSalesforceCaseHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IUserAuthenticationProvider authenticationProvider;
        public GetSalesforceCaseHandler(IIdentityDbContext context,
            ILogger<GetSalesforceCaseHandler> logger,
            IMediator mediator,
            IMapper mapper, IUserAuthenticationProvider authenticationProvider)
        {
            //_salesforceHttpClient = salesforceHttpClient;
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.authenticationProvider = authenticationProvider;
        }

        public async Task<SalesForceCaseModels> Handle(GetSalesforceCaseQuery request, CancellationToken cancellationToken)
        {
            SalesForceCaseModels result=new();
            //string consumerid = await FindConsumer(request.UserId);
            //if (string.IsNullOrEmpty(consumerid))
            //{
            //    throw new ValidationException(new ValidationFailure("SalesforceConsumer",
            //        $" Userid not found in salesforce consumer entity"));
            //}

            //string querystring = string.Format(@"q=SELECT +
            //                     CaseNumber
            //                    ,Origin
            //                    ,OwnerId
            //                    ,Reason
            //                    ,Case_Status__c
            //                    ,AccountId
            //                    ,Consumer__c
            //                    ,ContactEmail
            //                    ,ContactFax
            //                    ,ContactMobile
            //                    ,ContactId
            //                    ,ContactPhone
            //                    ,CreatedById
            //                    ,ClosedDate
            //                    ,CreatedDate
            //                    ,Description
            //                    ,IsEscalated
            //                    ,Comments
            //                    ,Language
            //                    ,LastModifiedById
            //                    ,ParentId
            //                    ,Priority
            //                    ,Status
            //                    ,Subject
            //                    ,Support_Level__c
            //                    ,Type
            //                    ,SuppliedEmail
            //                    + from+Case
            //                    +WHERE+Consumer__c+ = '{0}' ORDER BY CaseNumber DESC", consumerid);

            //HttpResponseMessage res = await _salesforceHttpClient.SendRequest(HttpMethod.Get, "query/", null, null, querystring);

            //if (res.IsSuccessStatusCode)
            //{
            //    //Saved succesfully.
            //    string strjson = await res.Content.ReadAsStringAsync();
            //    result = Newtonsoft.Json.JsonConvert.DeserializeObject<SalesForceCaseModels>(strjson);

            //    result.records = result.records.Take(10).ToList();
            //}


           //User user = _context.Users
           //    .Include(u => u.UserProfile)
           //     .AsNoTracking()
           //     .FirstOrDefault(u => u.UserId == request.UserId && (!request.TenantId.HasValue || request.TenantId == 0 || u.TenantId == request.TenantId));

            List<ConsumerCase> consumerCase = _context.ConsumerCases.Where(t => t.UserId == request.UserId).ToList();

            if (consumerCase.Count() > 0)
            {
                result.totalSize = consumerCase.Count();
                List<ConsumerCaseModel> consumerCaseModels = mapper.Map<List<ConsumerCaseModel>>(consumerCase);
                result.records = mapper.Map<List<SalesForceCaseModel>>(consumerCase);
               
            }
            return await Task.FromResult(result);

        }
        //private async Task<string> FindConsumer(int userid)
        //{
        //    string consumerid = string.Empty;
        //    string consumerquery = string.Format(@"q=SELECT +
        //                         Id
        //                        ,Name
        //                        ,User_ID__c                                
        //                        + from+Consumer__c
        //                        +WHERE+User_ID__c+ = '{0}' ", userid);
        //    HttpResponseMessage consumerres = await _salesforceHttpClient.SendRequest(HttpMethod.Get, "query/", null, null, consumerquery);
        //    if (consumerres.IsSuccessStatusCode)
        //    {
        //        string strconsumer = await consumerres.Content.ReadAsStringAsync();
        //        SalesforceConsumerModel consumer = Newtonsoft.Json.JsonConvert.DeserializeObject<SalesforceConsumerModel>(strconsumer);


        //        if (consumer != null && consumer.records.Count > 0)
        //        {
        //            consumerid = consumer.records.Select(x => x.Id).FirstOrDefault();
        //        }
        //    }
        //    return consumerid;
        //}
    }
}
