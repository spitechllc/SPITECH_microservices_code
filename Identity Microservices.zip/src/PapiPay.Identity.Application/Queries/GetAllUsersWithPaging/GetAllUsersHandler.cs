﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Pagination;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Identity.Domain.Models;
using PapiPay.Service.Clients.Finance;
using PapiPay.Service.Clients.Stores;
using PapiPay.Service.Clients.SyncDataServices.Interfaces;
using PapiPay.Service.Clients.Transactions;
using Renci.SshNet.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using static AutoMapper.Internal.ExpressionFactory;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using static PapiPay.ApplicationCore.Domain.DomainConstant;
using SortOrderEnum = PapiPay.EventBus.DomainEvents.Enums.SortOrderEnum;
using UserModel = PapiPay.Identity.Domain.Models.UserModel;

namespace PapiPay.Identity.Application.Queries.GetAllUsersWithPaging
{
    public class GetAllUsersHandler : IRequestHandler<GetAllUsersQuery, PaginatedList<UserModel>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GetAllUsersHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly AppSetting _appSetting;
        private readonly ITransactionServiceClient _transactionapiclient;
        private readonly IFinanceServiceClient _financeServiceClient;

        public GetAllUsersHandler(IIdentityDbContext context, ILogger<GetAllUsersHandler> logger, IMediator mediator, IMapper mapper, IOptionsMonitor<AppSetting> appSetting, ITransactionServiceClient transactionapiclient, IFinanceServiceClient financeServiceClient)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _appSetting = appSetting.CurrentValue;
            _transactionapiclient = transactionapiclient;
            _financeServiceClient = financeServiceClient;
        }
        public async Task<PaginatedList<UserModel>> Handle(GetAllUsersQuery request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);

            var users = _context.Users
                  .Include(t => t.UserProfile)
                  .Include(t => t.UserDevices)
                   .AsNoTracking().Where(w => w.UserTypeId == (int)UserTypeEnum.Consumer);

            string fname = string.Empty;

            ICollection<TransactionModel> lastTransactionDetails = new List<TransactionModel>();

            if (request.UserId > 0)
            {
                users = users.Where(t => t.UserId == request.UserId);
            }

            if (!string.IsNullOrWhiteSpace(request.FirstName))
            {
                users = users.Where(t => t.FirstName.Contains(request.FirstName));
            }

            if (!string.IsNullOrWhiteSpace(request.LastName))
            {
                users = users.Where(t => t.LastName.Contains(request.LastName));
            }

            if (!string.IsNullOrWhiteSpace(request.Email))
            {
                users = users.Where(t => t.Email.Contains(request.Email));
            }

            if (!string.IsNullOrWhiteSpace(request.Mobile))
            {
                users = users.Where(t => t.MobileNumber.Contains(request.Mobile));
            }
            if (request.Locked.HasValue)
            {
                users = users.Where(t => t.Lockout == request.Locked);
            }
            var totalRecords = users.Count();

            if (request.SortOrder != null && request.SortBy != null)
            {
                if (request.SortOrder == SortOrderEnum.Asc)
                {
                    switch (request.SortBy.Value)
                    {
                        case Domain.Enums.UserSortBy.None:
                        case Domain.Enums.UserSortBy.UserId:
                        case Domain.Enums.UserSortBy.CreatedDate:
                            users = users.OrderBy(t => t.UserId);
                            break;
                        case Domain.Enums.UserSortBy.FirstName:
                            users = users.OrderBy(t => t.FirstName);
                            break;
                        case Domain.Enums.UserSortBy.LastName:
                            users = users.OrderBy(t => t.LastName);
                            break;
                        case Domain.Enums.UserSortBy.Email:
                            users = users.OrderBy(t => t.Email);
                            break;
                        case Domain.Enums.UserSortBy.Mobile:
                            users = users.OrderBy(t => t.MobileNumber);
                            break;
                        case Domain.Enums.UserSortBy.IsActive:
                            users = users.OrderBy(t => t.IsActive);
                            break;
                        case Domain.Enums.UserSortBy.Device:
                            users = users.OrderBy(t => t.UserDevices.OrderByDescending(d => d.UserDeviceId).FirstOrDefault().DeviceTypeId);
                            break;
                    }
                }
                else
                {
                    switch (request.SortBy.Value)
                    {
                        case Domain.Enums.UserSortBy.None:
                        case Domain.Enums.UserSortBy.UserId:
                        case Domain.Enums.UserSortBy.CreatedDate:
                            users = users.OrderByDescending(t => t.UserId);
                            break;
                        case Domain.Enums.UserSortBy.FirstName:
                            users = users.OrderByDescending(t => t.FirstName);
                            break;
                        case Domain.Enums.UserSortBy.LastName:
                            users = users.OrderByDescending(t => t.LastName);
                            break;
                        case Domain.Enums.UserSortBy.Email:
                            users = users.OrderByDescending(t => t.Email);
                            break;
                        case Domain.Enums.UserSortBy.Mobile:
                            users = users.OrderByDescending(t => t.MobileNumber);
                            break;
                        case Domain.Enums.UserSortBy.IsActive:
                            users = users.OrderByDescending(t => t.IsActive);
                            break;
                        case Domain.Enums.UserSortBy.Device:
                            users = users.OrderByDescending(t => t.UserDevices.OrderByDescending(d => d.UserDeviceId).FirstOrDefault().DeviceTypeId);
                            break;
                    }
                }
            }
            else
            {
                users = users.OrderByDescending(t => t.UserId);
            }

            if (request.PageIndex > 0 && request.PageSize > 0)
            {
                users = users.Skip((request.PageIndex - 1) * request.PageSize).Take(request.PageSize);
            }

            var userModels = mapper.Map<List<UserModel>>(users.ToList());
            userModels.ForEach(x => x.PasswordHash = "");
            userModels.ForEach(x => x.DeviceType = ((DeviceType)x.Devices.Select(d => d.DeviceTypeId).LastOrDefault()).ToString());
            userModels.ForEach(x => x.MobileAppType = ((MobileAppType)x.Devices.Select(d => d.MobileAppTypeId).LastOrDefault()).ToString());

            if (userModels != null && userModels.Count > 0)
            {                //Get Last Transaction
                List<int> storeIds = new List<int>();
                GetLastTransactionByFilterQuery query = new GetLastTransactionByFilterQuery();
                query.StoreIds = storeIds.ToArray();
                query.UserIds = userModels.Select(t => t.UserId).ToArray();
                lastTransactionDetails = (await _transactionapiclient.GetLastTransactionByFilterAsync(query, cancellationToken))?.Data ?? new List<TransactionModel>();
                if (request.UserId > 0 || !string.IsNullOrWhiteSpace(request.FirstName) || !string.IsNullOrWhiteSpace(request.LastName) || !string.IsNullOrWhiteSpace(request.Email) || !string.IsNullOrWhiteSpace(request.Mobile) || request.Locked != null)
                {
                    List<UserModel> userdata = new List<UserModel>();
                    foreach (var user in userModels)
                    {
                        List<UserTenantMapping> userTenantMappings = _context.TenantMasters.Where(w => w.UserId == user.UserId).ToList();
                        List<Domain.Models.TenantMasterList> tenantMasterdata = new List<Domain.Models.TenantMasterList>();
                        foreach (var res in userTenantMappings)
                        {
                            var result = _context.TenantMaster.Where(x => x.ID == res.TenantId);
                            foreach (var obj2 in result)
                            {
                                Domain.Models.TenantMasterList tenantMasterList = new Domain.Models.TenantMasterList();
                                tenantMasterList.TenantId = obj2.ID;
                                tenantMasterList.TenantName = obj2.TenantName;
                                tenantMasterdata.Add(tenantMasterList);
                            }
                        }
                        user.TenantMasterLists = tenantMasterdata;
                        userdata.Add(user);
                    }
                    userModels = userdata;
                }
                //foreach (var user in userModels)
                //{
                //    var uId = user.UserId;
                //    if (lastTransactionDetails != null && lastTransactionDetails.Count > 0)
                //    {
                //        user.LastTransactionDate = lastTransactionDetails.Where(t => t.UserId == user.UserId).FirstOrDefault()?.TransactionDate.DateTime;
                //    }
                //    //var walletResult = await _financeServiceClient.WalletDetailsByUserIdAsync(user.UserId);

                //    var result = await _financeServiceClient.WalletDetailsAsync();
                //    var walletResult = result.Where(s => s.UserId == uId).FirstOrDefault();

                //    if (walletResult != null)
                //    {
                //        user.TotalCreditAmount = (decimal)walletResult.TotalCreditAmount;
                //        user.TotalRedeemedAmount = (decimal)walletResult.TotalRedeemAmount;
                //        user.TotalReceivedAmount = (decimal)walletResult.TotalReceivedAmount;
                //        user.TotalSharedAmount = (decimal)walletResult.TotalExpiredAmount;
                //        user.TotalPromotionalAmount = (decimal)walletResult.TotalPromotionalAmount;
                //        user.TotalAvailableAmount = (decimal)walletResult.TotalAvailableAmount;
                //    }
                //    else
                //    {
                //        user.TotalCreditAmount = 0;
                //        user.TotalRedeemedAmount = 0;
                //        user.TotalReceivedAmount = 0;
                //        user.TotalSharedAmount = 0;
                //        user.TotalPromotionalAmount = 0;
                //        user.TotalAvailableAmount = 0;
                //    }
                //}
            }

            if (request.SortOrder != null && request.SortBy != null)
            {
                if (request.SortBy == Domain.Enums.UserSortBy.LastTransactionDate)
                {
                    if (request.SortOrder == EventBus.DomainEvents.Enums.SortOrderEnum.Asc)
                    {
                        userModels = userModels.OrderBy(t => t.LastTransactionDate).ToList();

                    }
                    else
                    {
                        userModels = userModels.OrderByDescending(t => t.LastTransactionDate).ToList();
                    }
                }
            }
            if (request.AppName != null && request.AppName != "" && request.TenantId != null)
            {
                List<UserModel> userdata = new List<UserModel>();
                for (int i = 0; i < request.TenantId.Length; i++)
                {
                    List<UserModel> user = new List<UserModel>();
                    int TenantId = request.TenantId[i];
                    List<UserTenantMapping> userTenantMappings = _context.TenantMasters.Where(w => w.TenantId == TenantId).ToList();
                    foreach (var res in userTenantMappings)
                    {
                        var usersdata = userModels.Where(w => w.UserId == res.UserId);
                        foreach (var obj in usersdata)
                        {
                            List<Domain.Models.TenantMasterList> tenantMasterdata = new List<Domain.Models.TenantMasterList>();
                            var result = _context.TenantMaster.Where(x => x.ID == res.TenantId);
                            foreach (var obj2 in result)
                            {
                                Domain.Models.TenantMasterList tenantMasterList = new Domain.Models.TenantMasterList();
                                tenantMasterList.TenantId = obj2.ID;
                                tenantMasterList.TenantName = obj2.TenantName;
                                tenantMasterdata.Add(tenantMasterList);
                            }
                            obj.TenantMasterLists = tenantMasterdata;
                            userdata.Add(obj);
                        }
                    }
                }
                userModels = userdata;
            }
            else if (request.UserId == 0 && string.IsNullOrWhiteSpace(request.FirstName) && string.IsNullOrWhiteSpace(request.LastName) && string.IsNullOrWhiteSpace(request.Email) && string.IsNullOrWhiteSpace(request.Mobile) && request.Locked == null)
            {
                List<UserModel> userdata = new List<UserModel>();
                List<UserModel> user = new List<UserModel>();
                List<UserTenantMapping> userTenantMappings = _context.TenantMasters.Where(w => w.TenantId == (int)TenantEnum.PapiPay).ToList();
                //foreach (var res in userTenantMappings)
                //{
                //    var usersdata = userModels.Where(w => w.UserId == res.UserId);
                //    foreach (var obj in usersdata)
                //    {
                //        List<Domain.Models.TenantMasterList> tenantMasterdata = new List<Domain.Models.TenantMasterList>();
                //        var result = _context.TenantMaster.Where(x => x.ID == res.TenantId);
                //        foreach (var obj2 in result)
                //        {
                //            Domain.Models.TenantMasterList tenantMasterList = new Domain.Models.TenantMasterList();
                //            tenantMasterList.TenantId = obj2.ID;
                //            tenantMasterList.TenantName = obj2.TenantName;
                //            tenantMasterdata.Add(tenantMasterList);
                //        }
                //        obj.TenantMasterLists = tenantMasterdata;
                //        userdata.Add(obj);
                //    }
                //}
                //userModels = userdata;

                foreach (var item in userModels)
                {
                    var data = userTenantMappings.Where(s => s.UserId == item.UserId).ToList();
                    foreach (var res in data)
                    {
                        Domain.Models.TenantMasterList tenantMasterList = new Domain.Models.TenantMasterList();
                        tenantMasterList.TenantId = res.TenantId;
                        switch (tenantMasterList.TenantId = res.TenantId)
                        {
                            case 1:
                                tenantMasterList.TenantName = TenantName.PapiPay;
                                break;
                            case 2:
                                tenantMasterList.TenantName = TenantName.Velocity;
                                break;
                            case 3:
                                tenantMasterList.TenantName = TenantName.varifone;
                                break;
                            case 4:
                                tenantMasterList.TenantName = TenantName.TheStation;
                                break;
                            default:
                                break;
                        }
                        item.TenantMasterLists.Add(tenantMasterList);
                    }
                }
            }

            _logger.TraceExitMethod(nameof(Handle), userModels);

            return await Task.FromResult(new PaginatedList<UserModel>
            {
                Data = userModels,
                PageIndex = request.PageIndex,
                PageSize = request.PageSize,
                TotalCount = userModels.Count(),
            });
        }
    }
}
