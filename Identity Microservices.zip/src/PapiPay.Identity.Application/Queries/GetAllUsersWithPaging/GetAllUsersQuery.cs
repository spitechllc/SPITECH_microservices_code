﻿using MediatR;
using PapiPay.ApplicationCore.Pagination;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Domain.Enums;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Application.Queries.GetAllUsersWithPaging
{
    public class GetAllUsersQuery : IRequest<PaginatedList<UserModel>>
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public bool? Locked { get; set; }
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public UserSortBy? SortBy { get; set; }
        public SortOrderEnum? SortOrder { get; set; }
        public string AppName { get; set;}
        public int[] TenantId { get; set;}
    }
}