﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.VerifyEmail
{
    public class VerifyEmailValidator : AbstractValidator<VerifyEmailCommand>
    {
        public VerifyEmailValidator()
        {
            RuleFor(x => x.EmailVerificationCode).NotNull().NotEmpty().Length(0, 50);
        }
    }
}
