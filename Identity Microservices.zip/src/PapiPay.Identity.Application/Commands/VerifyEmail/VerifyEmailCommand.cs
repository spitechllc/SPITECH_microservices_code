﻿using MediatR;

namespace PapiPay.Identity.Application.Commands.VerifyEmail
{
    public class VerifyEmailCommand : IRequest<bool>
    {
        public string EmailVerificationCode { get; set; }
    }
}
