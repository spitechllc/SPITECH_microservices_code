﻿using AutoMapper;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Identity;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Interfaces;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.VerifyEmail
{
    public class VerifyEmailHandler : IRequestHandler<VerifyEmailCommand, bool>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<VerifyEmailHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IEventDispatcher _eventDispatcher;


        public VerifyEmailHandler(IIdentityDbContext context,
            ILogger<VerifyEmailHandler> logger,
            IMediator mediator,
            IMapper mapper,
            IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _eventDispatcher = eventDispatcher;
        }

        public async Task<bool> Handle(VerifyEmailCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            Domain.Entities.CodeVerification code = _context.CodeVerifications.FirstOrDefault(t => t.Code == command.EmailVerificationCode
              && t.CodeType == (int)EventBus.DomainEvents.Enums.CodeType.EmailVerification);


            _logger.TraceExitMethod(nameof(Handle), code);

            if (code != null)
            {
                Domain.Entities.User user = _context.Users.FirstOrDefault(t => t.UserId == code.UserId);
                user.EmailConfirmed = true;
                _context.Users.Update(user);
                await _context.SaveChangesAsync(cancellationToken);
                await _eventDispatcher.Dispatch(new IdentityUserEmailVerifiedEvent
                {
                    UserId = user.UserId,
                });
                await DispatchActivityLogEvent(user.UserId, (int)ActivityType.VerifyEmail, "User Email Verified.");
                return true;
            }

            return await Task.FromResult(false);
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ""
            });
        }
    }
}
