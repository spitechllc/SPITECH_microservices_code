﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.CreateClaim
{
    public class CreateClaimValidator : AbstractValidator<CreateClaimCommand>
    {
        public CreateClaimValidator()
        {
            RuleFor(x => x.Name).NotNull().NotEmpty().Length(0, 256);
        }
    }
}
