﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Models;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.CreateClaim
{
    public class CreateClaimHandler : IRequestHandler<CreateClaimCommand, ClaimModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<CreateClaimHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider _authenticationProvider;

        public CreateClaimHandler(IIdentityDbContext context, ILogger<CreateClaimHandler> logger, IMediator mediator, IMapper mapper, IEventDispatcher eventDispatcher, IUserAuthenticationProvider authenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            _authenticationProvider = authenticationProvider;
        }

        public async Task<ClaimModel> Handle(CreateClaimCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            Claim result = _context.Claims.FirstOrDefault(t => t.ClaimName == command.Name);
            if (result != null)
            {
                throw new ValidationException(new ValidationFailure("Name", $"Name already exist"));
            }

          //  int maxClaimId = _context.Claims.Max(t => t.ClaimId);
            Claim Claim = new() { ClaimName = command.Name, ClaimId = command.Name };

            _context.Claims.Add(Claim);

            await _context.SaveChangesAsync(cancellationToken);
            await DispatchActivityLogEvent(_authenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.CreateClaim, "New Claim Created");
            _logger.TraceExitMethod(nameof(Handle), result);
            return mapper.Map<ClaimModel>(Claim);
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = GetIPAddress()
            });
        }
        public static string GetIPAddress()
        {
            String address = "";
            WebRequest request = WebRequest.Create("http://checkip.dyndns.org/");
            using (WebResponse response = request.GetResponse())
            using (StreamReader stream = new StreamReader(response.GetResponseStream()))
            {
                address = stream.ReadToEnd();
            }

            int first = address.IndexOf("Address: ") + 9;
            int last = address.LastIndexOf("</body>");
            address = address.Substring(first, last - first);

            return address;
        }
    }
}
