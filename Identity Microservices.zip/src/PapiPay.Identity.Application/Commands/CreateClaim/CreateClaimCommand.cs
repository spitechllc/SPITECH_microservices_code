﻿using MediatR;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Application.Commands.CreateClaim
{
    public class CreateClaimCommand : IRequest<ClaimModel>
    {
        public string Name { get; set; }
    }
}
