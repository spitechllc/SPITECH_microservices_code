﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.UpdateUserDeviceByUserId
{
    public class UpdateUserDeviceByUserIdValidator : AbstractValidator<UpdateUserDeviceByUserIdCommand>
    {
        public UpdateUserDeviceByUserIdValidator()
        {
            RuleFor(x => x.DeviceToken).NotNull().Length(1, 255);
            RuleFor(x => x.MobileAppType).IsInEnum();
            RuleFor(x => x.DeviceType).IsInEnum();
        }
    }
}
