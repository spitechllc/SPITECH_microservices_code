﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.EventBus.DomainEvents.Enums;

namespace PapiPay.Identity.Application.Commands.UpdateUserDeviceByUserId
{
    public class UpdateUserDeviceByUserIdCommand : IRequest<ResponseModel>
    {
        public int UserId { get; set; }
        public string DeviceToken { get; set; }
        public DeviceType DeviceType { get; set; }
        public MobileAppType MobileAppType { get; set; }
    }
}
