﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using Microsoft.Extensions.Localization;
using Newtonsoft.Json;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.ApplicationCore.Helpers;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.UpdateUserDeviceByUserId
{
    public class UpdateUserDeviceByUserIdHandler : IRequestHandler<UpdateUserDeviceByUserIdCommand, ResponseModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<UpdateUserDeviceByUserIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IStringLocalizer<UpdateUserDeviceByUserIdHandler> _localizer;

        public UpdateUserDeviceByUserIdHandler(IIdentityDbContext context,
            ILogger<UpdateUserDeviceByUserIdHandler> logger,
            IMediator mediator, IMapper mapper,
            IEventDispatcher eventDispatcher, IUserAuthenticationProvider userAuthenticationProvider, IStringLocalizer<UpdateUserDeviceByUserIdHandler> localizer)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _localizer = localizer;
        }

        public async Task<ResponseModel> Handle(UpdateUserDeviceByUserIdCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel result = new();
            UserDevice userDevice = null;

            User user = _context.Users.FirstOrDefault(t => t.UserId == command.UserId);
            if (user == null)
            {
                throw new ValidationException(new ValidationFailure(_localizer["UserId"].Value, _localizer["Invalid UserId"].Value));
            }
            this.userAuthenticationProvider.ValidateUserAccess(command.UserId);
            if (user.UserTypeId == (int)EventBus.DomainEvents.Enums.UserTypeEnum.Consumer)
            {
                //_context.Database.ExecuteSqlRaw("update UserDevice set IsOnline=0 where UserId={0}", command.UserId);
                //await _context.SaveChangesAsync(cancellationToken);
                string strPreData = string.Empty;
                string strPostData = string.Empty;
                userDevice = _context.UserDevices.FirstOrDefault(t => t.UserId == command.UserId && t.MobileAppTypeId == (int)command.MobileAppType);

                if (userDevice == null)
                {
                    if (!string.IsNullOrWhiteSpace(command.DeviceToken))
                    {
                        userDevice = new UserDevice
                        {
                            UserId = command.UserId,
                            DeviceTypeId = (int)command.DeviceType,
                            DeviceToken = command.DeviceToken,
                            IsOnline = true,
                            MobileAppTypeId = (int)command.MobileAppType
                        };
                        _context.UserDevices.Add(userDevice);
                    }
                }
                else
                {
                    strPreData = JsonObjectConverter.Serialize(userDevice);

                    if (!string.IsNullOrWhiteSpace(command.DeviceToken))
                    {
                        userDevice.UserId = command.UserId;
                        userDevice.DeviceToken = command.DeviceToken;
                        userDevice.DeviceTypeId = (int)command.DeviceType;
                        userDevice.IsOnline = true;
                        userDevice.MobileAppTypeId = (int)command.MobileAppType;
                        _context.UserDevices.Update(userDevice);
                        strPostData = JsonObjectConverter.Serialize(userDevice);
                    }
                }

                result.Success = (await _context.SaveChangesAsync(cancellationToken)) > 0;
                 
                await DispatchActivityLogEvent(command.UserId, (int)ActivityType.UpdateUserDevice, "User Device Updated", strPreData, strPostData);
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, string preData, string postData)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = "",
                ActivityPreData = preData,
                ActivityPostData = postData
            });
        }
    }
}