﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;

namespace PapiPay.Identity.Application.Commands.RemoveLinkUser
{
    public class RemoveLinkUserCommand : IRequest<ResponseModel>
    {
        public int FromUserId { get; set; }
        public int ToUserId { get; set; }
    }
}
