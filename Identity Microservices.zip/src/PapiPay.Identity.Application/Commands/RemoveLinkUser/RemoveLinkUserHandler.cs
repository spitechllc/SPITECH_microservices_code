﻿using AutoMapper;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Interfaces;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.RemoveLinkUser
{
    public class RemoveLinkUserHandler : IRequestHandler<RemoveLinkUserCommand, ResponseModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<RemoveLinkUserHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IEventDispatcher _eventDispatcher;
        private readonly IUserAuthenticationProvider _authenticationProvider;

        public RemoveLinkUserHandler(IIdentityDbContext context,
            ILogger<RemoveLinkUserHandler> logger,
            IMediator mediator,
            IMapper mapper,
            IEventDispatcher eventDispatcher, IUserAuthenticationProvider authenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _eventDispatcher = eventDispatcher;
            _authenticationProvider = authenticationProvider;
        }

        public async Task<ResponseModel> Handle(RemoveLinkUserCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            ResponseModel responseModel = new() { Success = false };

            Domain.Entities.LinkUser linkUser = _context.LinkUsers.FirstOrDefault(t => ((t.RequestedUserId == command.FromUserId && t.AcceptUserId == command.ToUserId) || (t.RequestedUserId == command.ToUserId && t.AcceptUserId == command.FromUserId)) && t.IsActive == true);

            if (linkUser == null)
            {
                responseModel.Message = "User linking not exist.";
                responseModel.Success = false;
                return responseModel;
            }

            linkUser.IsActive = false;

            _context.LinkUsers.Update(linkUser);

            int rowaffected = await _context.SaveChangesAsync(cancellationToken);
            if (rowaffected > 0)
            {
                responseModel.Success = true;
                responseModel.Message = "Link User Removed";
                await DispatchActivityLogEvent(_authenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.RemoveLinkUser, "Link User Removed");
            }

            _logger.TraceExitMethod(nameof(Handle), responseModel);
            return responseModel;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return _eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ""
            });
        }
    }
}