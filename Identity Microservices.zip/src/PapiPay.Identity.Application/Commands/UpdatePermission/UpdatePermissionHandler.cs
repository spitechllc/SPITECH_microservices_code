﻿using AutoMapper;
using MediatR;
using Newtonsoft.Json;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Helpers;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Interfaces;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.UpdatePermission
{
    public class UpdatePermissionHandler : IRequestHandler<UpdatePermissionCommand, bool>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<UpdatePermissionHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public UpdatePermissionHandler(IIdentityDbContext context, ILogger<UpdatePermissionHandler> logger, IMediator mediator, IMapper mapper, IEventDispatcher eventDispatcher,IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<bool> Handle(UpdatePermissionCommand request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            bool result = true;

            if (request.ClaimIds != null && request.ClaimIds.Any())
            {
                System.Collections.Generic.List<Domain.Entities.Permission> permissions = _context.Permissions.Where(t => t.RoleId == request.RoleId).ToList();
                string strPreData = JsonObjectConverter.Serialize(permissions);
                if (permissions.Any())
                {
                    _context.Permissions.RemoveRange(permissions);
                    await _context.SaveChangesAsync(cancellationToken);
                }

                foreach (string claimId in request.ClaimIds)
                {
                    if (!_context.Permissions.Any(t => t.RoleId == request.RoleId && t.ClaimId == claimId))
                    {
                        _context.Permissions.Add(new Domain.Entities.Permission
                        {
                            ClaimId = claimId,
                            RoleId = request.RoleId
                        });
                    }
                }

                await _context.SaveChangesAsync(cancellationToken);
                System.Collections.Generic.List<Domain.Entities.Permission> permissionsP = _context.Permissions.Where(t => t.RoleId == request.RoleId).ToList();
                string strPostData = JsonObjectConverter.Serialize(permissionsP);
                await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.UpdatePermission, "Permission Updated.", strPreData, strPostData);
            }

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, string preData, string postData)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = "",
                ActivityPreData = preData,
                ActivityPostData = postData
            });
        }
    }
}
