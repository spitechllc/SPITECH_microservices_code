﻿using MediatR;
using System.Collections.Generic;

namespace PapiPay.Identity.Application.Commands.UpdatePermission
{
    public class UpdatePermissionCommand : IRequest<bool>
    {
        public string RoleId { get; set; }
        public IEnumerable<string> ClaimIds { get; set; }
    }
}
