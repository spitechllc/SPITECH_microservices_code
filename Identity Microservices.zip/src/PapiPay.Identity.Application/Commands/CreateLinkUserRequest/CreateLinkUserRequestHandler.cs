﻿using AutoMapper;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Identity;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.CreateLinkUserRequest
{
    public class CreateLinkUserRequestHandler : IRequestHandler<CreateLinkUserRequestCommand, ResponseModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<CreateLinkUserRequestHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public CreateLinkUserRequestHandler(IIdentityDbContext context,
            ILogger<CreateLinkUserRequestHandler> logger,
            IMediator mediator,
            IMapper mapper,
            IEventDispatcher eventDispatcher, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<ResponseModel> Handle(CreateLinkUserRequestCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel responseModel = new() { Success = false };

            CodeVerification code = _context.CodeVerifications.FirstOrDefault(t => t.Code == command.LinkUserCode
                                                   && t.IsActive == true);


            if (code == null)
            {
                responseModel.Message = "Invalid Code";
                responseModel.Success = false;
                return responseModel;
            }

            if (command.RequestedUserId == code.UserId)
            {
                responseModel.Message = "Invalid Code";
                responseModel.Success = false;
                return responseModel;
            }

            if (code.ExpiryDate < DateTime.UtcNow)
            {
                responseModel.Message = "The Code Expired. Please regenerate.";
                responseModel.Success = false;
                return responseModel;
            }

            this.userAuthenticationProvider.ValidateUserAccess(code.UserId);
            code.VerifyDate = DateTime.UtcNow;

            _context.CodeVerifications.Update(code);

            await _context.SaveChangesAsync(cancellationToken);

            LinkUser dbUser = _context.LinkUsers.FirstOrDefault(t => ((t.RequestedUserId == command.RequestedUserId && t.AcceptUserId == code.UserId) || (t.RequestedUserId == code.UserId && t.AcceptUserId == command.RequestedUserId)) && t.IsActive == true);

            if (dbUser != null)
            {
                responseModel.Message = "User already linked.";
                responseModel.Success = false;
                return responseModel;
            }

            LinkUser linkuser = new()
            {
                RequestedUserId = command.RequestedUserId,
                AcceptUserId = code.UserId,
                RequestDate = DateTime.UtcNow,
                IsAccepted = true,
                ActionDate = DateTime.UtcNow,
            };

            _context.LinkUsers.Add(linkuser);

            int rowaffected = await _context.SaveChangesAsync(cancellationToken);

            if (rowaffected > 0)
            {
                responseModel.Success = true;
                responseModel.Message = "Member link successfully!";

                await eventDispatcher.Dispatch(new UserLinkedRequesterEvent
                {
                    LinkUserId = linkuser.LinkUserId,
                    AcceptUserId = linkuser.AcceptUserId,
                    RequestedUserId = linkuser.RequestedUserId,
                    ActionDate = DateTime.UtcNow,
                    RequestDate = code.CreatedOn
                });

                await eventDispatcher.Dispatch(new UserLinkedAccepterEvent
                {
                    LinkUserId = linkuser.LinkUserId,
                    AcceptUserId = linkuser.AcceptUserId,
                    RequestedUserId = linkuser.RequestedUserId,
                    ActionDate = DateTime.UtcNow,
                    RequestDate = code.CreatedOn
                });

                await DispatchActivityLogEvent(linkuser.AcceptUserId, (int)ActivityType.LinkUser, "LinkUser Request Accepted");
            }
            _logger.TraceExitMethod(nameof(Handle), responseModel);

            return responseModel;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ""
            });
        }

    }
}