﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;

namespace PapiPay.Identity.Application.Commands.CreateLinkUserRequest
{
    public class CreateLinkUserRequestCommand : IRequest<ResponseModel>
    {
        public int RequestedUserId { get; set; }
        public string LinkUserCode { get; set; }
    }
}
