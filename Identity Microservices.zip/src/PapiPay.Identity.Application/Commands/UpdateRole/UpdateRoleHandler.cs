﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using Newtonsoft.Json;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.ApplicationCore.Helpers;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Models;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.UpdateRole
{
    public class UpdateRoleHandler : IRequestHandler<UpdateRoleCommand, RoleModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<UpdateRoleHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public UpdateRoleHandler(IIdentityDbContext context, ILogger<UpdateRoleHandler> logger, IMediator mediator, IMapper mapper, IEventDispatcher eventDispatcher,
            IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<RoleModel> Handle(UpdateRoleCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            Domain.Entities.Role role = _context.Roles.FirstOrDefault(t => t.RoleId == command.RoleId);
            if (role == null)
            {
                throw new ValidationException(new ValidationFailure("RoleId", $"Invalid RoleId"));
            }
            string strPreData = JsonObjectConverter.Serialize(role);
            role.RoleId = command.RoleId;
            role.RoleName = command.RoleName;
            role.RoleTypeId = (int)Enum.Parse(typeof(EntityRoleType), command.RoleType);
            role.IsActive = command.IsActive;
            _context.Roles.Update(role);
            await _context.SaveChangesAsync(cancellationToken);
            string strPostData = JsonObjectConverter.Serialize(role);
            await DispatchActivityLogEvent(userAuthenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.UpdateRole, "Role Updated", strPreData, strPostData);
            _logger.TraceExitMethod(nameof(Handle), role);
            return mapper.Map<RoleModel>(role);
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, string preData, string postData)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = "",
                ActivityPreData = preData,
                ActivityPostData = postData
            });
        }
    }
}
