﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.UpdateRole
{
    public class UpdateRoleValidator : AbstractValidator<UpdateRoleCommand>
    {
        public UpdateRoleValidator()
        {
            RuleFor(x => x.RoleName).NotNull().NotEmpty().Length(1, 100);
            RuleFor(x => x.RoleType).NotNull().NotEmpty().Length(1, 50);
        }
    }
}
