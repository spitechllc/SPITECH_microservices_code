﻿using MediatR;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Application.Commands.UpdateRole
{
    public class UpdateRoleCommand : IRequest<RoleModel>
    {
        public string RoleId { get; set; }
        public string RoleName { get; set; }
        public string RoleType { get; set; }
        public bool IsActive { get; set; }
    }
}
