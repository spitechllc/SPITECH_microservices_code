﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;
using System;

namespace PapiPay.Identity.Application.Commands.CreateUserLoginLog
{
    public class CreateUserLoginLogCommand : IRequest<ResponseModel>
    {
        public int UserId { get; set; }
        public bool InvalidLogin { get; set; }
    }
}
