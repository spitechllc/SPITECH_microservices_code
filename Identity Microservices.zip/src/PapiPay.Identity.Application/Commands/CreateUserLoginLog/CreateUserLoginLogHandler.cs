﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.Identity.Application.Commands.GenerateUserUnlockVerificationCode;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Application.Queries.GetUserById;
using PapiPay.Identity.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.CreateUserLoginLog
{
    public class CreateUserLoginLogHandler : IRequestHandler<CreateUserLoginLogCommand, ResponseModel>
    {
        private readonly IIdentityDbContext context;
        private readonly ILogger<CreateUserLoginLogHandler> logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IStringLocalizer<CreateUserLoginLogHandler> _localizer;

        public CreateUserLoginLogHandler(IIdentityDbContext context,
            ILogger<CreateUserLoginLogHandler> logger,
            IMediator mediator,
            IMapper mapper, IStringLocalizer<CreateUserLoginLogHandler> localizer)
        {
            this.context = context;
            this.logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _localizer = localizer;
        }

        public async Task<ResponseModel> Handle(CreateUserLoginLogCommand command, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), command);

            ResponseModel res = new ResponseModel() { Success = false };
            User user = null;
           
            Domain.Models.UserModel dbUser = await _mediator.Send(new GetUserByIdRequest() { UserId = command.UserId });

            if (dbUser == null)
            {
                throw new ValidationException(new ValidationFailure(_localizer["UserId"].Value, _localizer["Invalid User."].Value));
            }
            if (dbUser.Lockout == false)
            {
                user = mapper.Map<User>(dbUser);
                if (user.UserProfile != null)
                {
                    user.UserProfile.UserId = user.UserId;
                    user.UserProfile.LastLogin = DateTime.UtcNow;
                    user.UserProfile.LastLoginIP = "";
                    user.UserProfile.IsLoggedIn = true;

                }
               
                List<Domain.Entities.UserLoginLog> dbUserLogin = new();
                if (context.UserLoginLogs.Where(t => t.UserId == command.UserId).Count() > 0)
                {

                    dbUserLogin = context.UserLoginLogs.Where(t => t.UserId == command.UserId && t.LoginDate>= DateTime.UtcNow.AddMinutes(-10)).ToList();

                    if (dbUserLogin != null && dbUserLogin.Count > 0)
                    {
                        var validLogin = dbUserLogin.Where(t => t.InvalidLogin == false).FirstOrDefault();

                        if (validLogin == null)
                        {
                            if (dbUserLogin.Count == 2)
                            {
                                //send email to admin & user
                            }
                            if (dbUserLogin.Count >= 4)
                            {
                                user.Lockout = true;
                                context.Users.Update(user);

                                await _mediator.Send(new GenerateUserUnlockVerificationCodeCommand { UserId = user.UserId });
                                res.Success = false;
                                res.Message = "Your account is locked.An email to unlock your account has been sent to your registered email address.";
                            }
                        }
                    }
                }
                UserProfile userProfile = mapper.Map<UserProfile>(user.UserProfile);


                UserLoginLog userLoginLogs = new()
                {
                    UserId = user.UserId,
                    LoginIp = "",
                    LoginDate = DateTime.UtcNow,
                    InvalidLogin = command.InvalidLogin
                };

                context.UserLoginLogs.Add(userLoginLogs);

                if (userProfile != null)
                {

                    context.UserProfiles.Update(userProfile);
                }

                int rowaffected = await context.SaveChangesAsync(cancellationToken);
                if (rowaffected > 0 && dbUserLogin.Count < 4)
                {
                    res.Success = true;
                    res.Message = "User Login Log created successfully.";
                }
            }
            else
            {
                res.Success = false;
                res.Message = "Your account is locked.An email to unlock your account has been sent to your registered email address.";
            }
            logger.TraceExitMethod(nameof(Handle), dbUser.UserId);
            return res;

        }
    }
}
