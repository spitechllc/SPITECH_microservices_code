﻿using MediatR;
using System.Collections.Generic;

namespace PapiPay.Identity.Application.Commands.CopyClaims
{
    public class CopyClaimsCommand : IRequest<bool>
    {
        public string FromRoleId { get; set; }
        public string ToRoleId { get; set; }

    }
}
