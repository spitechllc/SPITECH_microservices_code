﻿using AutoMapper;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.Identity.Application.Interfaces;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.CopyClaims
{
    public class CopyClaimsHandler : IRequestHandler<CopyClaimsCommand, bool>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<CopyClaimsHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;

        public CopyClaimsHandler(IIdentityDbContext context, ILogger<CopyClaimsHandler> logger, IMediator mediator, IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
        }

        public async Task<bool> Handle(CopyClaimsCommand request, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), request);
            bool result = true;

            
                System.Collections.Generic.List<Domain.Entities.Permission> permissions = _context.Permissions.Where(t => t.RoleId == request.ToRoleId).ToList();
                if (permissions.Any())
                {
                    _context.Permissions.RemoveRange(permissions);
                    await _context.SaveChangesAsync(cancellationToken);
                }

                System.Collections.Generic.List<Domain.Entities.Permission> copyPermissions = _context.Permissions.Where(t => t.RoleId == request.FromRoleId).ToList();
                foreach (var claims in copyPermissions)
                {
                   
                        _context.Permissions.Add(new Domain.Entities.Permission
                        {
                            ClaimId = claims.ClaimId,
                            RoleId = request.ToRoleId
                        });
                   
                }

                await _context.SaveChangesAsync(cancellationToken);
           

            _logger.TraceExitMethod(nameof(Handle), result);
            return result;
        }
    }
}
