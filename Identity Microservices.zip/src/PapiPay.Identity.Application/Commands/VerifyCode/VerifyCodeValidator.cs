﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.VerifyCode
{
    public class VerifyCodeValidator : AbstractValidator<VerifyCodeCommand>
    {
        public VerifyCodeValidator()
        {
            RuleFor(x => x.CodeType).IsInEnum();
            RuleFor(x => x.Code).NotNull().NotEmpty().WithMessage("Code Is required").Length(1,50);
            RuleFor(x => x.UserId).GreaterThan(0);
        }
    }
}
