﻿using AutoMapper;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.Identity.Application.Interfaces;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.VerifyCode
{
    public class VerifyCodeHandler : IRequestHandler<VerifyCodeCommand, ResponseModel<int>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<VerifyCodeHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;

        public VerifyCodeHandler(IIdentityDbContext context,
            ILogger<VerifyCodeHandler> logger,
            IMediator mediator,
            IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
        }

        public async Task<ResponseModel<int>> Handle(VerifyCodeCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel<int> response = new() { Success = false };

            Domain.Entities.CodeVerification code = _context.CodeVerifications.FirstOrDefault(t => t.Code == command.Code
                                                                    && t.UserId == command.UserId
                                                                    && t.CodeType == (int)command.CodeType
                                                                    && t.IsActive == true
                                                                    && t.VerifyDate == null);
            if (code == null)
            {
                response.Message = "Invalid Code";
                return response;
            }

            if (code.ExpiryDate < DateTime.UtcNow)
            {
                response.Message = "The Code Expired";
                return response;
            }

            code.VerifyDate = DateTime.UtcNow;

            _context.CodeVerifications.Update(code);
            await _context.SaveChangesAsync(cancellationToken);

            response.Data = code.UserId;
            response.Success = true;

            _logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }
    }
}
