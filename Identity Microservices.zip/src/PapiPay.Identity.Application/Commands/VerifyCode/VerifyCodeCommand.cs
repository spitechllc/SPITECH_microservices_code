﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.EventBus.DomainEvents.Enums;

namespace PapiPay.Identity.Application.Commands.VerifyCode
{
    public class VerifyCodeCommand : IRequest<ResponseModel<int>>
    {
        public CodeType CodeType { get; set; }
        public string Code { get; set; }
        public int UserId { get; set; }
    }
}
