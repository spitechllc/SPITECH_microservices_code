﻿using AutoMapper;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Application.Interfaces;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using static PapiPay.ApplicationCore.Domain.DomainConstant;

namespace PapiPay.Identity.Application.Commands.VerifyResetPasswordCode
{
    public class VerifyResetPasswordCodeHandler : IRequestHandler<VerifyResetPasswordCodeCommand, ResponseModel<string>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<VerifyResetPasswordCodeHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IHashProvider hashProvider;
        private readonly IRandomCodeProvider randomCodeProvider;
        private readonly IEventDispatcher eventDispatcher;

        public VerifyResetPasswordCodeHandler(IIdentityDbContext context,
            ILogger<VerifyResetPasswordCodeHandler> logger,
            IMediator mediator,
            IHashProvider hashProvider,
            IMapper mapper,
            IRandomCodeProvider randomCodeProvider,
            IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.hashProvider = hashProvider;
            this.mapper = mapper;
            this.randomCodeProvider = randomCodeProvider;
            this.eventDispatcher = eventDispatcher;
        }

        public async Task<ResponseModel<string>> Handle(VerifyResetPasswordCodeCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel<string> response = new() { Success = false };
            Domain.Entities.User user = new();
            if (string.IsNullOrEmpty(command.TenantName))
            {
                user = _context.Users.FirstOrDefault(t => t.MobileNumber == command.MobileNumber && t.TenantName == TenantName.PapiPay
                                            && t.MobileCountryCode == command.MobileCountryCode
                                            && t.UserTypeId == (int)EventBus.DomainEvents.Enums.UserTypeEnum.Consumer);
            }
            else {
                user = _context.Users.FirstOrDefault(t => t.MobileNumber == command.MobileNumber && t.TenantName == command.TenantName
                                                            && t.MobileCountryCode == command.MobileCountryCode
                                                            && t.UserTypeId == (int)EventBus.DomainEvents.Enums.UserTypeEnum.Consumer);
            }


            if (user == null)
            {
                response.Message = "Invalid Mobile Number or Mobile Country Code";
                return response;
            }

            Domain.Entities.CodeVerification codeVerification = _context.CodeVerifications.FirstOrDefault(t => t.Code == command.VerificationCode
                                                                    && t.UserId == user.UserId
                                                                    && t.CodeType == (int)CodeType.ForgotPasswordSms
                                                                    && t.IsActive == true
                                                                    && t.VerifyDate == null);
            if (codeVerification == null)
            {
                response.Message = "Invalid Code";
                return response;
            }

            if (codeVerification.ExpiryDate < DateTime.UtcNow)
            {
                response.Message = "The Code Expired";
                return response;
            }

            response.Success = true;
            response.Data = codeVerification.Code;
            _logger.TraceExitMethod(nameof(Handle), response);

            return await Task.FromResult(response);
        }
    }
}
