﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;

namespace PapiPay.Identity.Application.Commands.VerifyResetPasswordCode
{
    public class VerifyResetPasswordCodeCommand : IRequest<ResponseModel<string>>
    {
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
        public string VerificationCode { get; set; }
        public string TenantName { get; set; }
    }
}
