﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.VerifyResetPasswordCode
{
    public class VerifyResetPasswordCodeValidator : AbstractValidator<VerifyResetPasswordCodeCommand>
    {
        public VerifyResetPasswordCodeValidator()
        {
            RuleFor(x => x.MobileCountryCode).NotNull().NotEmpty().Length(0, 10);
            RuleFor(x => x.MobileNumber).NotNull().NotEmpty().Length(0, 20);
            RuleFor(x => x.VerificationCode).NotNull().NotEmpty().Length(0, 50);
        }
    }
}
