﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.ApplicationCore.Extensions;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Identity;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Commands.VerifyCode;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.ResetUnregisteredConsumerPassword
{
    public class ResetUnregisteredConsumerPasswordHandler : IRequestHandler<ResetUnregisteredConsumerPasswordCommand, ResponseModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<ResetUnregisteredConsumerPasswordHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IHashProvider hashProvider;
        private readonly IRandomCodeProvider randomCodeProvider;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IStringLocalizer<ResetUnregisteredConsumerPasswordHandler> _localizer;

        public ResetUnregisteredConsumerPasswordHandler(IIdentityDbContext context,
            ILogger<ResetUnregisteredConsumerPasswordHandler> logger,
            IMediator mediator,
            IHashProvider hashProvider,
            IMapper mapper,
            IRandomCodeProvider randomCodeProvider,
            IEventDispatcher eventDispatcher,IUserAuthenticationProvider userAuthenticationProvider, IStringLocalizer<ResetUnregisteredConsumerPasswordHandler> localizer)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.hashProvider = hashProvider;
            this.mapper = mapper;
            this.randomCodeProvider = randomCodeProvider;
            this.eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _localizer = localizer;
        }

        public async Task<ResponseModel> Handle(ResetUnregisteredConsumerPasswordCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel response = new() { Success = false };
            if (command.UserIds.Any())
            {
                foreach (var item in command.UserIds)
                {
                    User user = _context.Users.FirstOrDefault(t => t.UserId == item
                                                                && t.UserTypeId == (int)EventBus.DomainEvents.Enums.UserTypeEnum.Consumer);

                    if (user == null)
                    {
                        response.Message = "Invalid UserId";
                        return response;
                    }
                    string pass = user.FirstName + user.MobileNumber.Substring((user.MobileNumber.Length - 4), 4);
                    user.PasswordHash = hashProvider.GetHashValue(pass);
                    _context.Users.Update(user);
                    response.Success = true;
                    response.Message = "Password Reset Successfully";
                }
            }
            else
            {
                IQueryable<Domain.Entities.User> ss = from u in _context.Users.Include(t => t.UserProfile) where (u.UserTypeId == (int)UserTypeEnum.Consumer) select u;

                Domain.Entities.User user = ss
                    .WhereIf(!string.IsNullOrEmpty(command.MobileOrEmail) && command.MobileOrEmail.Contains("@"), t => t.Email == command.MobileOrEmail)
                    .WhereIf(!string.IsNullOrEmpty(command.MobileOrEmail) && !command.MobileOrEmail.Contains("@"), t => t.MobileNumber == command.MobileOrEmail)
                    .Include(t => t.UserProfile)
                     .AsNoTracking()
                     .FirstOrDefault();

                if (user == null)
                {
                    response.Message = "Invalid Email or Mobile Number";
                    return response;
                }

                user.PasswordHash = hashProvider.GetHashValue(command.Password);

                _context.Users.Update(user);
                response.Success = true;
                response.Message = "Password Reset Successfully";
            }

            await _context.SaveChangesAsync(cancellationToken);
            _logger.TraceExitMethod(nameof(Handle), response);

            return response;
        }


    }
}
