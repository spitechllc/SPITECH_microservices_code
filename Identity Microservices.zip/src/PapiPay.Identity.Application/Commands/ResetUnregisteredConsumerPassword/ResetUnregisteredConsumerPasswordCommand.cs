﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;
using System.ComponentModel.DataAnnotations;

namespace PapiPay.Identity.Application.Commands.ResetUnregisteredConsumerPassword
{
    public class ResetUnregisteredConsumerPasswordCommand : IRequest<ResponseModel>
    {
        public int[] UserIds { get; set; }
        public string MobileOrEmail { get; set; }
        public string Password { get; set; }
    }
}
