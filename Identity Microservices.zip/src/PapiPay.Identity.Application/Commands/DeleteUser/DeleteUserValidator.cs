﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.DeleteUser
{
    public class DeleteUserValidator : AbstractValidator<DeleteUserCommand>
    {
        public DeleteUserValidator()
        {
            RuleFor(x => x.UserId).GreaterThan(0).WithMessage("UserId is required");
            RuleFor(x => x.ReasonforDeletion).NotNull().NotEmpty().WithMessage("ReasonforDeletion is required").Length(1,500);
        }
    }
}
