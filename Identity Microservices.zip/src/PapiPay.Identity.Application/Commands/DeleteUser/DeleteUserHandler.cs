﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Application.Queries.GetUserById;
using PapiPay.Identity.Domain.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.DeleteUser
{
    public class DeleteUserHandler : IRequestHandler<DeleteUserCommand, ResponseModel>
    {
        private readonly IIdentityDbContext context;
        private readonly ILogger<DeleteUserHandler> logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IStringLocalizer<DeleteUserHandler> _localizer;
        private readonly IEventDispatcher eventDispatcher;

        public DeleteUserHandler(IIdentityDbContext context,
            ILogger<DeleteUserHandler> logger,
            IMediator mediator,
            IMapper mapper, IStringLocalizer<DeleteUserHandler> localizer, IEventDispatcher eventDispatcher)
        {
            this.context = context;
            this.logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _localizer = localizer;
            this.eventDispatcher = eventDispatcher;
        }

        public async Task<ResponseModel> Handle(DeleteUserCommand command, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), command);
            User user = null;

            if (command.UserId != command.TokenUserId)
            {
                throw new ValidationException(new ValidationFailure(_localizer["UserId"].Value, _localizer["Invalid UserId."].Value));
            }

            Domain.Models.UserModel dbUser = await _mediator.Send(new GetUserByIdRequest() { UserId = command.TokenUserId });

            if (dbUser == null)
            {
                throw new ValidationException(new ValidationFailure(_localizer["UserId"].Value, _localizer["Invalid User."].Value));
            }

            user = mapper.Map<User>(dbUser);
            if (user.UserProfile != null)
            {
                user.UserProfile.UserId = user.UserId;
            }

            UserProfile userProfile = mapper.Map<UserProfile>(user.UserProfile);

            IEnumerable<UserDevice> userDevices = mapper.Map<IEnumerable<UserDevice>>(user.UserDevices);

            List<UserRole> userRoles = null;

            if (user.UserRoles != null)
            {
                userRoles = context.UserRoles.Where(t => t.UserId == command.UserId).ToList();
            }

            List<LinkUser> linkUsers = context.LinkUsers.AsNoTracking().Where(t => t.RequestedUserId == command.UserId || t.AcceptUserId == command.UserId).ToList();

            DeletedUser deletedUser = new()
            {
                UserId = user.UserId,
                UserName = user.UserName,
                EnrolledBusinessUser = user.EnrolledBusinessUser,
                PasswordHash = user.PasswordHash,
                UserTypeId = user.UserTypeId,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                MobileCountryCode = user.MobileCountryCode,
                MobileNumber = user.MobileNumber,
                EmailConfirmed = user.EmailConfirmed,
                MobileConfirmed = user.MobileConfirmed,
                AccessFailedCount = user.AccessFailedCount,
                Lockout = user.Lockout,
                LastTimeAccess = user.LastTimeAccess,
                PreferedLanguage = user.PreferedLanguage,
                DOB = user.DOB,
                ReasonforDeletion = command.ReasonforDeletion
            };

            if (user.UserProfile != null)
            {
                deletedUser.DeletedUserProfile = new DeletedUserProfile
                {
                    UserId = user.UserId,
                    Gender = user.UserProfile.Gender,
                    PhotoUrl = user.UserProfile.PhotoUrl,
                    AddressLine1 = user.UserProfile.AddressLine1,
                    AddressLine2 = user.UserProfile.AddressLine2,
                    Country = user.UserProfile.Country,
                    CountryCode = user.UserProfile.CountryCode,
                    State = user.UserProfile.State,
                    City = user.UserProfile.City,
                    Longitude = user.UserProfile.Longitude,
                    Latitude = user.UserProfile.Latitude,
                    ZipCode = user.UserProfile.ZipCode,
                    Company = user.UserProfile.Company,
                    CompanyId = user.UserProfile.CompanyId,
                    Store = user.UserProfile.Store,
                    StoreId = user.UserProfile.StoreId,
                    BusinessName = user.UserProfile.BusinessName,
                    BusinessAccountNumber = user.UserProfile.BusinessAccountNumber
                };
            }

            context.DeletedUsers.Add(deletedUser);

            if (userDevices.Count() > 0)
            {
                context.UserDevices.RemoveRange(userDevices);
            }
            if (userRoles.Count > 0)
            {
                context.UserRoles.RemoveRange(userRoles);
            }
            if (linkUsers.Count > 0)
            {
                context.LinkUsers.RemoveRange(linkUsers);
            }
            if (userProfile != null)
            {
                context.UserProfiles.Remove(userProfile);
            }

            context.Users.Remove(user);

            int rowaffected = await context.SaveChangesAsync(cancellationToken);

            await DispatchActivityLogEvent(command.UserId, (int)ActivityType.DeleteUser, "User Deleted");

            logger.TraceExitMethod(nameof(Handle), dbUser.UserId);
            return rowaffected > 0
                ? new ResponseModel() { Success = true, Message = "User account removed successfully." }
                : new ResponseModel() { Success = false, Message = "User account not removed." };
        }

        public DeletedUser InserDeletedUser(User command, string reasonforDeletion)
        {
            DeletedUser deletedUser = new()
            {
                UserId = command.UserId,
                UserName = command.UserName,
                EnrolledBusinessUser = command.EnrolledBusinessUser,
                PasswordHash = command.PasswordHash,
                UserTypeId = command.UserTypeId,
                FirstName = command.FirstName,
                LastName = command.LastName,
                Email = command.Email,
                MobileCountryCode = command.MobileCountryCode,
                MobileNumber = command.MobileNumber,
                EmailConfirmed = command.EmailConfirmed,
                MobileConfirmed = command.MobileConfirmed,
                AccessFailedCount = command.AccessFailedCount,
                Lockout = command.Lockout,
                LastTimeAccess = command.LastTimeAccess,
                PreferedLanguage = command.PreferedLanguage,
                DOB = command.DOB,
                ReasonforDeletion = reasonforDeletion,
                DeletedUserProfile = new DeletedUserProfile
                {
                    UserId = command.UserProfile.UserId,
                    Gender = command.UserProfile.Gender,
                    PhotoUrl = command.UserProfile.PhotoUrl,
                    AddressLine1 = command.UserProfile.AddressLine1,
                    AddressLine2 = command.UserProfile.AddressLine2,
                    Country = command.UserProfile.Country,
                    CountryCode = command.UserProfile.CountryCode,
                    State = command.UserProfile.State,
                    City = command.UserProfile.City,
                    Longitude = command.UserProfile.Longitude,
                    Latitude = command.UserProfile.Latitude,
                    ZipCode = command.UserProfile.ZipCode,
                    Company = command.UserProfile.Company,
                    CompanyId = command.UserProfile.CompanyId,
                    Store = command.UserProfile.Store,
                    StoreId = command.UserProfile.StoreId,
                    BusinessName = command.UserProfile.BusinessName,
                    BusinessAccountNumber = command.UserProfile.BusinessAccountNumber
                }
            };

            return deletedUser;
        }

        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ""
            });
        }
    }
}
