﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Models;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.CreateRole
{
    public class CreateRoleHandler : IRequestHandler<CreateRoleCommand, RoleModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<CreateRoleHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider _authenticationProvider;

        public CreateRoleHandler(IIdentityDbContext context, ILogger<CreateRoleHandler> logger, IMediator mediator, IMapper mapper, IEventDispatcher eventDispatcher, IUserAuthenticationProvider authenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            _authenticationProvider = authenticationProvider;
        }

        public async Task<RoleModel> Handle(CreateRoleCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            Role result = _context.Roles.FirstOrDefault(t => t.RoleName == command.RoleName);
            if (result != null)
            {
                throw new ValidationException(new ValidationFailure("Name", $"Name already exist"));
            }

            //int maxRoleId = _context.Roles.Max(t => t.RoleId);
            Role role = new() { RoleName = command.RoleName, RoleTypeId = (int)command.RoleType, RoleId =command.RoleName };
            _context.Roles.Add(role);
            await _context.SaveChangesAsync(cancellationToken);
            await DispatchActivityLogEvent(_authenticationProvider.GetUserAuthentication().UserId, (int)ActivityType.CreateRole, "New Role Created");
            _logger.TraceExitMethod(nameof(Handle), result);
            return mapper.Map<RoleModel>(role);
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ""
            });
        }

    }
}
