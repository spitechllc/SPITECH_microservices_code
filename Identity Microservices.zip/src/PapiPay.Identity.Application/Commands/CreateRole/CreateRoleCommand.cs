﻿using MediatR;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Domain.Models;

namespace PapiPay.Identity.Application.Commands.CreateRole
{
    public class CreateRoleCommand : IRequest<RoleModel>
    {
        public string RoleName { get; set; }
        public EntityRoleType RoleType { get; set; }
    }
}
