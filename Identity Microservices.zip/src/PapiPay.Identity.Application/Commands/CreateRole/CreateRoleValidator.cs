﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.CreateRole
{
    public class CreateRoleValidator : AbstractValidator<CreateRoleCommand>
    {
        public CreateRoleValidator()
        {
            RuleFor(x => x.RoleName).NotNull().NotEmpty().Length(1, 100);
            RuleFor(x => x.RoleType).NotNull().NotEmpty();
        }
    }
}
