﻿using AutoMapper;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.Identity.Application.Commands.GenerateUserVerificationCode;
using PapiPay.Identity.Application.Interfaces;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.GenerateUserUnlockVerificationCode
{
    public class GenerateUserUnlockVerificationCodeHandler : IRequestHandler<GenerateUserUnlockVerificationCodeCommand, ResponseModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GenerateUserUnlockVerificationCodeHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IRandomCodeProvider randomCodeProvider;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GenerateUserUnlockVerificationCodeHandler(IIdentityDbContext context,
            ILogger<GenerateUserUnlockVerificationCodeHandler> logger,
            IMediator mediator,
            IMapper mapper,
            IRandomCodeProvider randomCodeProvider, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.randomCodeProvider = randomCodeProvider;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<ResponseModel> Handle(GenerateUserUnlockVerificationCodeCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel result = new() { Success = false };
            Domain.Entities.User user = _context.Users.FirstOrDefault(t => t.UserId == command.UserId);
          
            
            if (user == null)
            {
                result.Message = "Invalid UserId";
                return result;
            }

            //Call userunlockverificationcode generation method
            GenerateUserVerificationCodeCommand verificationcode = new()
            {
                CodeType = EventBus.DomainEvents.Enums.CodeType.UserUnlock,
                UserId = user.UserId,
                Receiver = user.Email.Trim()
            };
            Domain.Entities.CodeVerification res = await _mediator.Send(verificationcode);

            result.Success = true;
            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
