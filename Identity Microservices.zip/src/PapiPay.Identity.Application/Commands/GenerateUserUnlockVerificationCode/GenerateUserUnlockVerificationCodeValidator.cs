﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.GenerateUserUnlockVerificationCode
{
    public class GenerateUserUnlockVerificationCodeValidator : AbstractValidator<GenerateUserUnlockVerificationCodeCommand>
    {
        public GenerateUserUnlockVerificationCodeValidator()
        {
            RuleFor(x => x.UserId).GreaterThan(0).WithMessage("Invalid UserId");
        }
    }
}
