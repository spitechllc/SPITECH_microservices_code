﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;

namespace PapiPay.Identity.Application.Commands.GenerateUserUnlockVerificationCode
{
    public class GenerateUserUnlockVerificationCodeCommand : IRequest<ResponseModel>
    {
        public int UserId { get; set; }
    }
}
