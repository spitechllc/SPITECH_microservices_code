﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;
using System.ComponentModel.DataAnnotations;

namespace PapiPay.Identity.Application.Commands.ResetConsumerPassword
{
    public class ResetConsumerPasswordCommand : IRequest<ResponseModel>
    {
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
        public string VerificationCode { get; set; }
        public string Password { get; set; }
        public string TenantName { get; set; }
    }
}