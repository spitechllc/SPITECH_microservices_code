﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.ResetConsumerPassword
{
    public class ResetConsumerPasswordValidator : AbstractValidator<ResetConsumerPasswordCommand>
    {
        public ResetConsumerPasswordValidator()
        {
            RuleFor(x => x.Password).NotNull().NotEmpty().Length(1,20);
            RuleFor(x => x.MobileCountryCode).NotNull().NotEmpty().Length(1,10);
            RuleFor(x => x.MobileNumber).NotNull().NotEmpty().Length(1,20);
            RuleFor(x => x.VerificationCode).NotNull().NotEmpty().Length(1,50);
        }
    }
}
