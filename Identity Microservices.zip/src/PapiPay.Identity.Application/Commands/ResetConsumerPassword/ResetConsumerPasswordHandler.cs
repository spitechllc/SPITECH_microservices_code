﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using Microsoft.Extensions.Localization;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Identity;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Commands.VerifyCode;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using static PapiPay.ApplicationCore.Domain.DomainConstant;

namespace PapiPay.Identity.Application.Commands.ResetConsumerPassword
{
    public class ResetConsumerPasswordHandler : IRequestHandler<ResetConsumerPasswordCommand, ResponseModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<ResetConsumerPasswordHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IHashProvider hashProvider;
        private readonly IRandomCodeProvider randomCodeProvider;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IStringLocalizer<ResetConsumerPasswordHandler> _localizer;

        public ResetConsumerPasswordHandler(IIdentityDbContext context,
            ILogger<ResetConsumerPasswordHandler> logger,
            IMediator mediator,
            IHashProvider hashProvider,
            IMapper mapper,
            IRandomCodeProvider randomCodeProvider,
            IEventDispatcher eventDispatcher,IUserAuthenticationProvider userAuthenticationProvider, IStringLocalizer<ResetConsumerPasswordHandler> localizer)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.hashProvider = hashProvider;
            this.mapper = mapper;
            this.randomCodeProvider = randomCodeProvider;
            this.eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _localizer = localizer;
        }

        public async Task<ResponseModel> Handle(ResetConsumerPasswordCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel response = new() { Success = false };
            User user = new();
            if (!string.IsNullOrEmpty(command.Password))
            {
                Regex regex = new(@"(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}");
                Match match = regex.Match(command.Password);
                if (!match.Success)
                {
                    throw new ValidationException(new ValidationFailure(_localizer["Password"].Value, _localizer["The Password should atleast 8 characters with atleast  one upper case, one lower case and one numeric and one special character."].Value));
                }
            }

            if (string.IsNullOrEmpty(command.TenantName))
            {
                 user = _context.Users.FirstOrDefault(t => t.MobileNumber == command.MobileNumber
                                                            && t.MobileCountryCode == command.MobileCountryCode
                                                            && t.TenantName== TenantName.PapiPay
                                                            && t.UserTypeId == (int)EventBus.DomainEvents.Enums.UserTypeEnum.Consumer);
            }
            else
            {
                 user = _context.Users.FirstOrDefault(t => t.MobileNumber == command.MobileNumber
                                                && t.TenantName == command.TenantName
                                                && t.MobileCountryCode == command.MobileCountryCode
                                                && t.UserTypeId == (int)EventBus.DomainEvents.Enums.UserTypeEnum.Consumer);
            }


            if (user == null)
            {
                response.Message = "Invalid Mobile Number or Mobile Country Code";
                return response;
            }
            if(user.PasswordHash == hashProvider.GetHashValue(command.Password))
            {
                response.Message = "Password has been used previously, please choose another";
                return response;
            }

            this.userAuthenticationProvider.ValidateUserAccess(user.UserId);
            //verifycode
            VerifyCodeCommand verificationcode = new()
            {
                CodeType = EventBus.DomainEvents.Enums.CodeType.ForgotPasswordSms,
                Code = command.VerificationCode,
                UserId = user.UserId
            };
            ResponseModel<int> verificationResponse = await _mediator.Send(verificationcode);

            response.Success = verificationResponse.Success;
            response.Message = verificationResponse.Message;

            if (verificationResponse.Success && verificationResponse.Data == user.UserId)
            {
                user.PasswordHash = hashProvider.GetHashValue(command.Password);
                _context.Users.Update(user);
                await _context.SaveChangesAsync(cancellationToken);
                await DispatchChangePasswordEvent(user);
                await DispatchActivityLogEvent(user.UserId, (int)ActivityType.ForgotPassword, "ForgotPassword");
            }

            _logger.TraceExitMethod(nameof(Handle), response);

            return response;
        }

        private Task DispatchChangePasswordEvent(User user)
        {
            return eventDispatcher.Dispatch(new IdentityPasswordChangedEvent
            {
                Email = user.Email,
                UserId = user.UserId,
                FirstName = user.FirstName,
                LastName = user.LastName,
                MobileCountryCode = user.MobileCountryCode,
                MobileNumber = user.MobileNumber,
                UserName = user.UserName,
                UserTypeId = user.UserTypeId,
            });
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ""
            });
        }

    }
}
