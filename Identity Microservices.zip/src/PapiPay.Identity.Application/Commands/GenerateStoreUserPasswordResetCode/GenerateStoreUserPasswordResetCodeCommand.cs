﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;

namespace PapiPay.Identity.Application.Commands.GenerateStoreUserPasswordResetCode
{
    public class GenerateStoreUserPasswordResetCodeCommand : IRequest<ResponseModel>
    {
        public string UserName { get; set; }
    }
}
