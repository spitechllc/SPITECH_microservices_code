﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.GenerateStoreUserPasswordResetCode
{
    public class GenerateStoreUserPasswordResetCodeValidator : AbstractValidator<GenerateStoreUserPasswordResetCodeCommand>
    {
        public GenerateStoreUserPasswordResetCodeValidator()
        {
            RuleFor(x => x.UserName).NotNull().NotEmpty().Length(0, 50);
        }
    }
}
