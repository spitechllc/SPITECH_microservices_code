﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.UpdateProfileUsingPortal
{
    public class UpdateProfileUsingPortalValidator : AbstractValidator<UpdateProfileUsingPortalCommand>
    {
        public UpdateProfileUsingPortalValidator()
        {
            RuleFor(x => x.UserId).GreaterThan(0);
            RuleFor(x => x.AddressLine1).Length(0, 500);
            RuleFor(x => x.AddressLine2).Length(0, 500);
            RuleFor(x => x.Country).Length(0, 100);
            RuleFor(x => x.CountryCode).Length(0, 10);
            RuleFor(x => x.State).Length(0, 100);
            RuleFor(x => x.City).Length(0, 100);
            RuleFor(x => x.Longitude).Length(0, 50);
            RuleFor(x => x.Latitude).Length(0, 50);
            RuleFor(x => x.ZipCode).Length(0, 10);
            RuleFor(x => x.Store).Length(0, 200);
            RuleFor(x => x.Company).Length(0, 200);
            RuleForEach(x => x.RoleIds).NotNull().WithMessage("Role Ids Must be null or Greater than 0");
        }
    }
}
