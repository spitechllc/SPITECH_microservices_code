﻿using MediatR;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Domain.Models;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PapiPay.Identity.Application.Commands.UpdateProfileUsingPortal
{
    public class UpdateProfileUsingPortalCommand : IRequest<UserSearchResult>
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        [RegularExpression(@"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$", ErrorMessage = "Email is not valid.")]
        public string Email { get; set; }
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
        public bool IsActive { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string Country { get; set; }
        public string CountryCode { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string Longitude { get; set; }
        public string Latitude { get; set; }
        public string ZipCode { get; set; }
        public int? CompanyId { get; set; }
        public string Company { get; set; }
        public int? StoreId { get; set; }
        public string Store { get; set; }
        public string PhotoUrlbase64 { get; set; }
        public string DOB { get; set; }
        public string DeviceToken { get; set; }
        public string Gender { get; set; }
        public DeviceType DeviceType { get; set; }
        public MobileAppType MobileAppType { get; set; }
        public IEnumerable<string> RoleIds { get; set; }
    }
}
