﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;
using System;

namespace PapiPay.Identity.Application.Commands.UpdateUserSessionInactive
{
    public class UpdateUserSessionInactiveCommand : IRequest<ResponseModel>
    {
        public int UserId { get; set; }
    }
}
