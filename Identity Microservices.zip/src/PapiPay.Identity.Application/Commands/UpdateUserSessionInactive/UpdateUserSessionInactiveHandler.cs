﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Application.Queries.GetUserById;
using PapiPay.Identity.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.UpdateUserSessionInactive
{
    public class UpdateUserSessionInactiveHandler : IRequestHandler<UpdateUserSessionInactiveCommand, ResponseModel>
    {
        private readonly IIdentityDbContext context;
        private readonly ILogger<UpdateUserSessionInactiveHandler> logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IStringLocalizer<UpdateUserSessionInactiveHandler> _localizer;

        public UpdateUserSessionInactiveHandler(IIdentityDbContext context,
            ILogger<UpdateUserSessionInactiveHandler> logger,
            IMediator mediator,
            IMapper mapper, IStringLocalizer<UpdateUserSessionInactiveHandler> localizer)
        {
            this.context = context;
            this.logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _localizer = localizer;
        }

        public async Task<ResponseModel> Handle(UpdateUserSessionInactiveCommand command, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), command);
            User user = null;
           
            Domain.Models.UserModel dbUser = await _mediator.Send(new GetUserByIdRequest() { UserId = command.UserId });

            if (dbUser == null)
            {
                throw new ValidationException(new ValidationFailure(_localizer["UserId"].Value, _localizer["Invalid User."].Value));
            }
           
            user = mapper.Map<User>(dbUser);
            if (user.UserProfile != null)
            {
                user.UserProfile.UserId = user.UserId;
                user.UserProfile.IsLoggedIn = false;

            }

            UserProfile userProfile = mapper.Map<UserProfile>(user.UserProfile);


            if (userProfile != null)
            {
                context.UserProfiles.Update(userProfile);
            }
           


            int rowaffected = await context.SaveChangesAsync(cancellationToken);


            logger.TraceExitMethod(nameof(Handle), dbUser.UserId);
            return rowaffected > 0
                ? new ResponseModel() { Success = true, Message = "User Session Inactive." }
                : new ResponseModel() { Success = false, Message = "Not able to Inactive User Session." };
                }      


    }
}
