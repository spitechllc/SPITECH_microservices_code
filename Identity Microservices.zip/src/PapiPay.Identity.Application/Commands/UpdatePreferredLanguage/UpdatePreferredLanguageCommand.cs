﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;

namespace PapiPay.Identity.Application.Commands.UpdatePreferredLanguage
{
    public class UpdatePreferredLanguageCommand : IRequest<ResponseModel<int>>
    {
        public int UserId { get; set; }
        public string PreferredLanguage { get; set; }
    }
}
