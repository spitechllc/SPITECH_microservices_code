﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using Microsoft.Extensions.Localization;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.UpdatePreferredLanguage
{
    public class UpdatePreferredLanguageHandler : IRequestHandler<UpdatePreferredLanguageCommand, ResponseModel<int>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<UpdatePreferredLanguageHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IStringLocalizer<UpdatePreferredLanguageHandler> _localizer;
        private readonly IEventDispatcher eventDispatcher;

        public UpdatePreferredLanguageHandler(IIdentityDbContext context,
            ILogger<UpdatePreferredLanguageHandler> logger,
            IMediator mediator, IMapper mapper, IUserAuthenticationProvider userAuthenticationProvider, IStringLocalizer<UpdatePreferredLanguageHandler> localizer, IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _localizer = localizer;
            this.eventDispatcher = eventDispatcher;
        }

        public async Task<ResponseModel<int>> Handle(UpdatePreferredLanguageCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            bool result = true;
            ResponseModel<int> response = new() { Success = false };
            this.userAuthenticationProvider.ValidateUserAccess(command.UserId);
            User user = _context.Users.FirstOrDefault(t => t.UserId == command.UserId);
           
            if (user == null)
            {
                throw new ValidationException(new ValidationFailure(_localizer["UserId"].Value, _localizer["Invalid UserId"].Value));
            }
            

            if (user.UserTypeId == (int)EventBus.DomainEvents.Enums.UserTypeEnum.Consumer)
            {
                if (!string.IsNullOrEmpty(command.PreferredLanguage))
                {
                    string strPreData = user.PreferedLanguage;
                    user.PreferedLanguage = command.PreferredLanguage;

                    _context.Users.Update(user);
                    await _context.SaveChangesAsync(cancellationToken);
                    string strPostData = command.PreferredLanguage;
                    response.Data = user.UserId;
                    response.Success = true;
                    response.Message = "Preferred Language Updated.";
                    await DispatchActivityLogEvent(user.UserId,(int)ActivityType.UpdatePreferedLanguage, "User Prefered Language Updated.", strPreData, strPostData);
                }
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return response;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, string preData, string postData)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = "",
                ActivityPreData = preData,
                ActivityPostData = postData
            });
        }
    }
}
