﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.UpdatePreferredLanguage
{
    public class UpdatePreferredLanguageValidator : AbstractValidator<UpdatePreferredLanguageCommand>
    {
        public UpdatePreferredLanguageValidator()
        {
            RuleFor(x => x.UserId).GreaterThan(0);
            RuleFor(x => x.PreferredLanguage).NotNull().NotEmpty();
        }
    }
}
