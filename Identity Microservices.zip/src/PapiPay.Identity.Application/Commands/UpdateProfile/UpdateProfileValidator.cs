﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.UpdateProfile
{
    public class UpdateProfileValidator : AbstractValidator<UpdateProfileCommand>
    {
        public UpdateProfileValidator()
        {
            RuleFor(x => x.FirstName).NotNull().NotEmpty().Length(1, 50);
            RuleFor(x => x.LastName).NotNull().NotEmpty().Length(1, 50);
            //RuleFor(x => x.Email).NotNull().NotEmpty().Length(1, 100);
            RuleFor(x => x.UserId).GreaterThan(0);
            RuleFor(x => x.AddressLine1).Length(0, 500);
            RuleFor(x => x.AddressLine2).Length(0, 500);
            RuleFor(x => x.Country).Length(0, 100);
            RuleFor(x => x.CountryCode).Length(0, 10);
            RuleFor(x => x.State).Length(0, 100);
            RuleFor(x => x.City).Length(0, 100);
            RuleFor(x => x.Longitude).Length(0, 50);
            RuleFor(x => x.Latitude).Length(0, 50);
            RuleFor(x => x.ZipCode).Length(0, 10);
            RuleFor(x => x.Store).Length(0, 200);
            RuleFor(x => x.Company).Length(0, 200);
            When(t => !string.IsNullOrEmpty(t.Gender), () =>
            {
                RuleFor(x => x.Gender).Must(t => t == "M" || t == "F" || t == "N").WithMessage("Gender should be blank or M , F Or N");
            });
        }
    }
}
