﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using Microsoft.Extensions.Localization;
using Newtonsoft.Json;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.AzureServices.Containers;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.ApplicationCore.Helpers;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Identity;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Commands.GenerateEmailVerificationCode;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Application.Queries.GoogleAPIAddress;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Identity.Domain.Models;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.UpdateProfile
{
    public class UpdateProfileHandler : IRequestHandler<UpdateProfileCommand, UserSearchResult>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<UpdateProfileHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IStorageService storageService;
        private readonly IStringLocalizer<UpdateProfileHandler> _localizer;

        public UpdateProfileHandler(IIdentityDbContext context,
            ILogger<UpdateProfileHandler> logger,
            IMediator mediator, IMapper mapper,
            IStorageServiceFactory storageServiceFactory,
            IEventDispatcher eventDispatcher, IUserAuthenticationProvider userAuthenticationProvider, IStringLocalizer<UpdateProfileHandler> localizer)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
            storageService = storageServiceFactory.Get(ContainerType.UserProfileImage);
            _localizer = localizer;
        }

        public async Task<UserSearchResult> Handle(UpdateProfileCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            bool result = true;
            bool emailChanged = false;
            this.userAuthenticationProvider.ValidateUserAccess(command.UserId);
            User user = _context.Users.FirstOrDefault(t => t.UserId == command.UserId);

            if (user == null)
            {
                throw new ValidationException(new ValidationFailure(_localizer["UserId"].Value, _localizer["Invalid UserId"].Value));
            }

            if (user.UserTypeId == (int)EventBus.DomainEvents.Enums.UserTypeEnum.Consumer
                && !user.Email.Equals(command.Email, StringComparison.InvariantCultureIgnoreCase))
            {
                emailChanged = true;

                User emailMachedUser = _context.Users.FirstOrDefault(t => t.Email == command.Email
                                                                        && t.UserId != user.UserId
                                                                        && t.EmailConfirmed == true);

                if (emailMachedUser != null)
                {
                    throw new ValidationException(new ValidationFailure(_localizer["Email"].Value, _localizer["Email already registered"].Value));
                }

                user.EmailConfirmed = false;
            }

            string strPreData = JsonObjectConverter.Serialize(user);
            user.FirstName = command.FirstName;
            user.LastName = command.LastName;
            user.Email = command.Email;
            user.MobileNumber = command.MobileNumber;


            if (user.UserTypeId == (int)EventBus.DomainEvents.Enums.UserTypeEnum.Consumer)
            {
                user.DOB = CommonUtility.ValidateDateOfBirth(command.DOB);
            }

            if (user.UserTypeId == 2)
            {
                user.MobileNumber = command.MobileNumber;
                user.MobileCountryCode = command.MobileCountryCode;
            }

            UserProfile dbuserProfile = _context.UserProfiles.FirstOrDefault(t => t.UserId == command.UserId);
            if (dbuserProfile == null)
            {
                throw new ValidationException(new ValidationFailure(_localizer["UserId"].Value, _localizer["Invalid UserId"].Value));
            }

            if (user.UserTypeId == 1)
            {
                if (command.ZipCode != null)
                {
                    GoogleAddressModel googleaddr = await _mediator.Send(new GoogleAPIAddressQuery { Zipcode = command.ZipCode });

                    if (googleaddr != null)
                    {
                        command.Country = googleaddr.Country;
                        command.State = googleaddr.State;
                        command.City = googleaddr.City;
                        command.Latitude = googleaddr.Latitude;
                        command.Longitude = googleaddr.Longitude;
                    }
                }
            }

            UserProfile userProfile = user.UserProfile;
            userProfile.AddressLine1 = command.AddressLine1;
            userProfile.AddressLine2 = command.AddressLine2;
            userProfile.City = command.City;
            userProfile.State = command.State;
            userProfile.Country = command.Country;
            userProfile.CountryCode = command.CountryCode;
            userProfile.Latitude = command.Latitude;
            userProfile.Longitude = command.Longitude;
            userProfile.Company = command.Company;
            userProfile.CompanyId = command.CompanyId;
            userProfile.Store = command.Store;
            userProfile.StoreId = command.StoreId;
            userProfile.ZipCode = command.ZipCode;
            userProfile.Gender = command.Gender;

            if (user.UserTypeId == (int)EventBus.DomainEvents.Enums.UserTypeEnum.Consumer && !string.IsNullOrEmpty(command.DeviceToken))
            {
                UserDevice userDevice = _context.UserDevices.FirstOrDefault(t => t.UserId == command.UserId && t.MobileAppTypeId == (int)command.MobileAppType);

                if (userDevice == null)
                {
                    if (!string.IsNullOrWhiteSpace(command.DeviceToken))
                    {
                        userDevice = new UserDevice
                        {
                            UserId = command.UserId,
                            DeviceTypeId = (int)command.DeviceType,
                            DeviceToken = command.DeviceToken,
                            IsOnline = true,
                            MobileAppTypeId = (int)command.MobileAppType
                        };
                        _context.UserDevices.Add(userDevice);
                    }
                }
                else
                {
                    if (!string.IsNullOrWhiteSpace(command.DeviceToken))
                    {
                        userDevice.UserId = command.UserId;
                        userDevice.DeviceToken = command.DeviceToken;
                        userDevice.DeviceTypeId = (int)command.DeviceType;
                        userDevice.IsOnline = true;
                        userDevice.MobileAppTypeId = (int)command.MobileAppType;
                        _context.UserDevices.Update(userDevice);
                    }
                }
            }
            if (command.RoleIds != null)
            {
                if (command.RoleIds.Any())
                {
                    System.Collections.Generic.List<UserRole> roles = _context.UserRoles.Where(t => t.UserId == command.UserId).ToList();
                    if (roles.Any())
                    {
                        _context.UserRoles.RemoveRange(roles);
                        await _context.SaveChangesAsync(cancellationToken);
                    }
                    foreach (string roleid in command.RoleIds)
                    {
                        UserRole role = _context.UserRoles.FirstOrDefault(t => t.RoleId == roleid && t.UserId == command.UserId);

                        if (role == null)
                        {
                            user.UserRoles.Add(new UserRole { RoleId = roleid });
                        }

                    }
                }
            }
            #region upload image over Azure        
            if (!string.IsNullOrEmpty(command.PhotoUrlbase64))
            {
                if (!((command.PhotoUrlbase64.Length % 4 == 0) && Regex.IsMatch(command.PhotoUrlbase64, @"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.None)))
                {
                    throw new ValidationException(new ValidationFailure("PhotoUrlbase64", $"Invalid base64"));
                }
                else
                {
                    string filename = userProfile.UserId.ToString() + "_" + UniqueIdGenerator.Generate() + "_profileimage.jpeg";
                    string Azurefileurl = await SaveImage(command.PhotoUrlbase64, filename);
                    if (!string.IsNullOrEmpty(Azurefileurl))
                    {
                        userProfile.PhotoUrl = Azurefileurl;
                    }
                }
            }
            #endregion

            _context.Users.Update(user);

            await _context.SaveChangesAsync(cancellationToken);

            if (emailChanged)
            {
                await _mediator.Send(new GenerateEmailVerificationCodeCommand { UserId = command.UserId }).ConfigureAwait(false);
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            UserSearchResult userModel = mapper.Map<UserSearchResult>(user);
            userModel.UserProfile = mapper.Map<UserProfileModel>(user.UserProfile);
            string strPostData = JsonObjectConverter.Serialize(user);
            await DispatchUserUpdatedEvent(user, command);
            await DispatchActivityLogEvent(user.UserId, (int)ActivityType.UpdateProfile, "User Profile Updated", strPreData, strPostData);

            return mapper.Map<UserSearchResult>(userModel);
        }
        private async Task<string> SaveImage(string base64image, string filename)
        {
            await storageService.UploadBlob(base64image, filename);
            Blob res = await storageService.GetFile(filename);
            return res != null ? res.StorageUri : string.Empty;
        }

        private Task DispatchUserUpdatedEvent(User user, UpdateProfileCommand command)
        {
            return eventDispatcher.Dispatch(new IdentityUserUpdatedEvent
            {
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName,
                MobileCountryCode = user.MobileCountryCode,
                MobileNumber = user.MobileNumber,
                PreferedLanguage = user.PreferedLanguage,
                UserId = user.UserId,
                UserName = user.UserName,
                UserTypeId = user.UserTypeId,
                MobileConfirmed = user.MobileConfirmed,
                EmailConfirmed = user.EmailConfirmed,
                EnrolledBusinessUser = user.EnrolledBusinessUser,
                IsActive = user.IsActive,
                UserProfile = new EventBus.DomainEvents.Models.Identity.UserProfileModel
                {
                    AddressLine1 = user.UserProfile.AddressLine1,
                    AddressLine2 = user.UserProfile.AddressLine2,
                    City = user.UserProfile.City,
                    Company = user.UserProfile.Company,
                    CompanyId = user.UserProfile.CompanyId,
                    Country = user.UserProfile.Country,
                    CountryCode = user.UserProfile.CountryCode,
                    Latitude = user.UserProfile.Latitude,
                    Longitude = user.UserProfile.Longitude,
                    PhotoUrl = user.UserProfile.PhotoUrl,
                    State = user.UserProfile.State,
                    Store = user.UserProfile.Store,
                    StoreId = user.UserProfile.StoreId,
                    ZipCode = user.UserProfile.ZipCode,
                    BusinessName = user.UserProfile.BusinessName,
                    BusinessAccountNumber = user.UserProfile.BusinessAccountNumber,
                },
                UserDevices = mapper.Map<EventBus.DomainEvents.Models.Identity.UserDeviceModel[]>(user.UserDevices?.ToArray()),
                MobileAppType = command.MobileAppType,
            });
        }

        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, string preData, string postData)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = "",
                ActivityPreData = preData,
                ActivityPostData = postData
            });
        }
    }
}
