﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;

namespace PapiPay.Identity.Application.Commands.RemovePersistedGrant
{
    public class RemovePersistedGrantCommand : IRequest<ResponseModel>
    {
        public int UserId { get; set; }
        public string ClientId { get; set; }
    }
}
