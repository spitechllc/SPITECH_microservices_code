﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.Identity.Application.Interfaces;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.RemovePersistedGrant
{
    public class RemovePersistedGrantHandler : IRequestHandler<RemovePersistedGrantCommand, ResponseModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<RemovePersistedGrantHandler> _logger;

        public RemovePersistedGrantHandler(IIdentityDbContext context, ILogger<RemovePersistedGrantHandler> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<ResponseModel> Handle(RemovePersistedGrantCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            int count = 0;

            if (!string.IsNullOrWhiteSpace(command.ClientId))
            {
                count = await _context.Database.ExecuteSqlRawAsync("DELETE FROM [dbo].[PersistedGrants] Where SubjectId={0} and ClientId={1}", command.UserId.ToString(), command.ClientId);
            }
            else
            {
                count = await _context.Database.ExecuteSqlRawAsync("DELETE FROM [dbo].[PersistedGrants] Where SubjectId={0} ", command.UserId.ToString());
            }

            return new ResponseModel() { Success = count > 0 };
        }
    }
}
