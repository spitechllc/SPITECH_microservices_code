﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;

namespace PapiPay.Identity.Application.Commands.GenerateMobileUpdateVerificationCode
{
    public class GenerateMobileUpdateVerificationCodeCommand : IRequest<ResponseModel>
    {
        public int UserId { get; set; }
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
    }
}
