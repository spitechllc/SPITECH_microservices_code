﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.GenerateMobileUpdateVerificationCode
{
    public class GenerateMobileUpdateVerificationCodeValidator : AbstractValidator<GenerateMobileUpdateVerificationCodeCommand>
    {
        public GenerateMobileUpdateVerificationCodeValidator()
        {
            RuleFor(x => x.UserId).GreaterThan(0);
            RuleFor(x => x.MobileCountryCode).NotNull().NotEmpty().Length(0, 5);
            RuleFor(x => x.MobileNumber).NotNull().NotEmpty().Length(0, 20);
        }
    }
}
