﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using Microsoft.Extensions.Localization;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.Identity.Application.Commands.GenerateUserVerificationCode;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.GenerateMobileUpdateVerificationCode
{
    public class GenerateMobileUpdateVerificationCodeHandler : IRequestHandler<GenerateMobileUpdateVerificationCodeCommand, ResponseModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GenerateMobileUpdateVerificationCodeHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IRandomCodeProvider randomCodeProvider;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IStringLocalizer<GenerateMobileUpdateVerificationCodeHandler> _localizer;

        public GenerateMobileUpdateVerificationCodeHandler(IIdentityDbContext context,
            ILogger<GenerateMobileUpdateVerificationCodeHandler> logger,
            IMediator mediator,
            IMapper mapper,
            IRandomCodeProvider randomCodeProvider, IUserAuthenticationProvider userAuthenticationProvider, IStringLocalizer<GenerateMobileUpdateVerificationCodeHandler> localizer)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.randomCodeProvider = randomCodeProvider;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _localizer = localizer;
        }

        public async Task<ResponseModel> Handle(GenerateMobileUpdateVerificationCodeCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel result = new() { Success = false };
            this.userAuthenticationProvider.ValidateUserAccess(command.UserId);
            User dbUser = null;

            User user = _context.Users.FirstOrDefault(t => t.UserId == command.UserId);
            string prevMobile = user.MobileNumber;

            if (user == null)
            {
                result.Message = "Invalid UserId";
                return result;
            }

            if (prevMobile == command.MobileNumber)
            {
                throw new ValidationException(new ValidationFailure(_localizer["MobileNumber"].Value, _localizer["Mobile number can not be same with current mobile number"].Value));
            }

            System.Collections.Generic.List<User> dbUsers = _context.Users.Where(t => (t.MobileNumber == command.MobileNumber)
                                                 && (t.UserTypeId == (int)EventBus.DomainEvents.Enums.UserTypeEnum.Consumer)).ToList();

            if (dbUsers != null && dbUsers.Any())
            {
                dbUser = dbUsers.FirstOrDefault(t => t.MobileNumber == command.MobileNumber && t.MobileConfirmed);

                if (dbUser != null)
                {
                    throw new ValidationException(new ValidationFailure(_localizer["MobileNumber"].Value, _localizer["Mobile number is already register."]));
                }
            }
            if (user.UserTypeId == (int)EventBus.DomainEvents.Enums.UserTypeEnum.Consumer)
            {
                if (!string.IsNullOrEmpty(command.MobileNumber) && !string.IsNullOrEmpty(command.MobileCountryCode))
                {
                    //Call userverificationcode generation method
                    GenerateUserVerificationCodeCommand verificationcode = new()
                    {
                        CodeType = EventBus.DomainEvents.Enums.CodeType.MobileVerification,
                        UserId = command.UserId,
                        Receiver = command.MobileCountryCode.Trim() + command.MobileNumber.Trim()
                    };
                    CodeVerification res = await _mediator.Send(verificationcode);
                }
            }
            result.Success = true;



            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
