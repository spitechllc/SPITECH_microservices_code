﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.ChangePassword
{
    public class ChangePasswordValidator : AbstractValidator<ChangePasswordCommand>
    {
        public ChangePasswordValidator()
        {
            RuleFor(x => x.UserId).GreaterThan(0);
            RuleFor(x => x.Password).Length(1, 15);
            RuleFor(x => x.NewPassword).Length(1, 15);

        }
    }
}
