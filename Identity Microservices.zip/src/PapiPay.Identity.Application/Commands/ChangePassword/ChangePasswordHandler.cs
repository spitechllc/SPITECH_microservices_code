﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using Microsoft.Extensions.Localization;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Identity;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Commands.CreateUserPasswordChangeLog;
using PapiPay.Identity.Application.Commands.GenerateUserUnlockVerificationCode;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.ChangePassword
{
    public class ChangePasswordHandler : IRequestHandler<ChangePasswordCommand, ResponseModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<ChangePasswordHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IHashProvider hashProvider;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IStringLocalizer<ChangePasswordHandler> _localizer;

        public ChangePasswordHandler(IIdentityDbContext context, ILogger<ChangePasswordHandler> logger, IMediator mediator,
            IHashProvider hashProvider, IMapper mapper,
            IEventDispatcher eventDispatcher, IUserAuthenticationProvider userAuthenticationProvider, IStringLocalizer<ChangePasswordHandler> localizer)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.hashProvider = hashProvider;
            this.mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _localizer = localizer;
        }

        public async Task<ResponseModel> Handle(ChangePasswordCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);

            this.userAuthenticationProvider.ValidateUserAccess(command.UserId);


            if (!string.IsNullOrEmpty(command.NewPassword))
            {
                Regex regex = new(@"(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}");
                Match match = regex.Match(command.NewPassword);
                if (!match.Success)
                {
                    throw new ValidationException(new ValidationFailure(_localizer["Password"].Value, _localizer["The Password should atleast 8 charecters with atleast  one upper case, one lower case and one numeric and one special charecter."].Value));
                }
            }

            User user = null;

            user = _context.Users.FirstOrDefault(t => t.UserId == command.UserId);

            if (user == null)
            {
                throw new ValidationException(new ValidationFailure(_localizer["UserId"].Value, _localizer["Invalid UserId"].Value));
            }
            else
            {
                if(user.Lockout==true)
                {
                    throw new ValidationException(new ValidationFailure("Account", _localizer["Your account is locked for 24 hours.You can not change password"].Value));
                }
            }
          
            if (user.UserProfile != null)
            {
                user.UserProfile.UserId = user.UserId;

            }
            //match old password
            User dbUser = _context.Users.FirstOrDefault(t => t.PasswordHash == hashProvider.GetHashValue(command.Password) && t.UserId == command.UserId);
            bool wrongAttempt = false;
            if(dbUser==null)
            {
                wrongAttempt = true;
            }
            //password Change log entry
            await _mediator.Send(new CreateUserPasswordChangeLogCommand() { UserId = command.UserId, OldPassword = hashProvider.GetHashValue(command.Password), NewPassword = hashProvider.GetHashValue(command.NewPassword), IsWrongAttempt = wrongAttempt });

            //password change log in a second
            //List<Domain.Entities.UserPasswordChangeLog> dbPasswordChange = _context.UserPasswordChangeLogs.Where(t => t.UserId == command.UserId && t.ChangeDate >= DateTime.UtcNow.AddSeconds(-1)).ToList();
            if (_context.UserPasswordChangeLogs.Where(t => t.UserId == command.UserId).Count() > 0)
            {
                List<Domain.Entities.UserPasswordChangeLog> dbPasswordChange = _context.UserPasswordChangeLogs.Where(t => t.UserId == command.UserId && t.ChangeDate>= DateTime.UtcNow.AddMinutes(-5).AddSeconds(-1)).ToList();

                if (dbPasswordChange != null && dbPasswordChange.Count > 0)
                {
                    if (dbPasswordChange.Count >= 5)
                    {
                        user.Lockout = true;
                        _context.Users.Update(user);
                        await _context.SaveChangesAsync(cancellationToken);
                        await _mediator.Send(new GenerateUserUnlockVerificationCodeCommand { UserId = user.UserId });
                        throw new ValidationException(new ValidationFailure("Account", _localizer["Your account is locked.An email to unlock your account has been sent to your registered email address."].Value));
                    }
                }

                //password change log in 5 mins
                List<Domain.Entities.UserPasswordChangeLog> dbUserPasswordChange = _context.UserPasswordChangeLogs.Where(t => t.UserId == command.UserId && t.ChangeDate >= DateTime.UtcNow.AddMinutes(-10)).ToList();
              
                if (dbUserPasswordChange != null && dbUserPasswordChange.Count > 0)
                {
                    var validChangepassword = dbUserPasswordChange.Where(t => t.IsWrongAttempt == false).FirstOrDefault();

                    if (validChangepassword == null)
                    {
                        if (dbUserPasswordChange.Count == 3)
                        {
                            //send email to admin & user
                        }
                        if (dbUserPasswordChange.Count >= 5)
                        {
                            user.Lockout = true;
                            _context.Users.Update(user);
                            await _context.SaveChangesAsync(cancellationToken);
                            await _mediator.Send(new GenerateUserUnlockVerificationCodeCommand { UserId = user.UserId });
                            throw new ValidationException(new ValidationFailure("Account", _localizer["Your account is locked.An email to unlock your account has been sent to your registered email address."].Value));
                        }
                    }
                }
            }
            if (hashProvider.GetHashValue(command.Password) == hashProvider.GetHashValue(command.NewPassword))
            {
                throw new ValidationException(new ValidationFailure(_localizer["Password"].Value, _localizer["Password has been used previously, please choose another"].Value));
            }          

            if (dbUser == null)
            {
                throw new ValidationException(new ValidationFailure(_localizer["Password"].Value, _localizer["Old password not matched"].Value));
            }

            dbUser.PasswordHash = hashProvider.GetHashValue(command.NewPassword);
            _context.Users.Update(dbUser);

            int result = await _context.SaveChangesAsync(cancellationToken);

            UserModel userModel = mapper.Map<UserModel>(dbUser);

            await DispatchChangePasswordEvent(userModel);
            await DispatchActivityLogEvent(user.UserId, (int)ActivityType.ChangePassword, "ChangePassword");
            _logger.TraceExitMethod(nameof(Handle), result);

            return new ResponseModel() { Success = true, Message = "Success" };
        }

        private Task DispatchChangePasswordEvent(UserModel user)
        {
            return eventDispatcher.Dispatch(new IdentityPasswordChangedEvent
            {
                Email = user.Email,
                UserId = user.UserId,
                FirstName = user.FirstName,
                LastName = user.LastName,
                MobileCountryCode = user.MobileCountryCode,
                MobileNumber = user.MobileNumber,
                UserName = user.UserName,
                UserTypeId = user.UserTypeId,
            });
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ""
            });
        }
    }
}
