﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;
using System.ComponentModel.DataAnnotations;

namespace PapiPay.Identity.Application.Commands.ChangePassword
{
    public class ChangePasswordCommand : IRequest<ResponseModel>
    {
        public int UserId { get; set; }
        public string Password { get; set; }
        public string NewPassword { get; set; }
    }
}
