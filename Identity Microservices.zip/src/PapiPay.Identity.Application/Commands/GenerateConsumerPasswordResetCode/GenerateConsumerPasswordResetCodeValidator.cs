﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.GenerateConsumerPasswordResetCode
{
    public class GenerateConsumerPasswordResetCodeValidator : AbstractValidator<GenerateConsumerPasswordResetCodeCommand>
    {
        public GenerateConsumerPasswordResetCodeValidator()
        {
            RuleFor(x => x.MobileCountryCode).NotNull().NotEmpty().Length(0, 5);
            RuleFor(x => x.MobileNumber).NotNull().NotEmpty().Length(0, 20);
        }
    }
}
