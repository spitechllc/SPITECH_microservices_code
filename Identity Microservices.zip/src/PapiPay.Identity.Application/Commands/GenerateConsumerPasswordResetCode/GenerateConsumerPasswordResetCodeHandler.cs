﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using Microsoft.Extensions.Localization;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.Identity.Application.Commands.CreateUserPasswordChangeLog;
using PapiPay.Identity.Application.Commands.GenerateUserUnlockVerificationCode;
using PapiPay.Identity.Application.Commands.GenerateUserVerificationCode;
using PapiPay.Identity.Application.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.GenerateConsumerPasswordResetCode
{
    public class GenerateConsumerPasswordResetCodeHandler : IRequestHandler<GenerateConsumerPasswordResetCodeCommand, ResponseModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GenerateConsumerPasswordResetCodeHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IHashProvider hashProvider;
        private readonly IRandomCodeProvider randomCodeProvider;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IStringLocalizer<GenerateConsumerPasswordResetCodeHandler> _localizer;

        public GenerateConsumerPasswordResetCodeHandler(IIdentityDbContext context, ILogger<GenerateConsumerPasswordResetCodeHandler> logger, IMediator mediator,
            IHashProvider hashProvider, IMapper mapper, IRandomCodeProvider randomCodeProvider, IUserAuthenticationProvider userAuthenticationProvider, IStringLocalizer<GenerateConsumerPasswordResetCodeHandler> localizer)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.hashProvider = hashProvider;
            this.mapper = mapper;
            this.randomCodeProvider = randomCodeProvider;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _localizer = localizer;
        }

        public async Task<ResponseModel> Handle(GenerateConsumerPasswordResetCodeCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel result = new() { Success = false };
            Domain.Entities.User user = new();
            if (string.IsNullOrEmpty(command.TenantName))
            {
                user = _context.Users.FirstOrDefault(t => t.MobileNumber == command.MobileNumber && t.TenantName == "PapiPay"
                                                       && t.MobileCountryCode == command.MobileCountryCode
                                                       && t.UserTypeId == (int)PapiPay.EventBus.DomainEvents.Enums.UserTypeEnum.Consumer);
            }
            else
            {
                user = _context.Users.FirstOrDefault(t => t.MobileNumber == command.MobileNumber && t.TenantName == command.TenantName
                                                           && t.MobileCountryCode == command.MobileCountryCode
                                                           && t.UserTypeId == (int)PapiPay.EventBus.DomainEvents.Enums.UserTypeEnum.Consumer);
            }


            if (user == null)
            {
                result.Message = "Invalid Mobile Number or Mobile Country Code";
                return result;
            }
            this.userAuthenticationProvider.ValidateUserAccess(user.UserId);
            //password change log
            await _mediator.Send(new CreateUserPasswordChangeLogCommand() { UserId = user.UserId });

            //password change log in a second           
             
            if (_context.UserPasswordChangeLogs.Where(t => t.UserId == user.UserId).Count() > 0)
            {
                List<Domain.Entities.UserPasswordChangeLog> dbPasswordChange = _context.UserPasswordChangeLogs.Where(t => t.UserId == user.UserId && t.ChangeDate >= DateTime.UtcNow.AddMinutes(-5).AddSeconds(-1)).ToList();
                if (dbPasswordChange != null && dbPasswordChange.Count > 0)
            {
                if (dbPasswordChange.Count >= 5)
                {
                    user.Lockout = true;
                    _context.Users.Update(user);
                    await _context.SaveChangesAsync(cancellationToken);
                    await _mediator.Send(new GenerateUserUnlockVerificationCodeCommand { UserId = user.UserId });
                    throw new ValidationException(new ValidationFailure("Account", _localizer["Your account is locked.An email to unlock your account has been sent to your registered email address."].Value));
                }
            }

                //password change log in 5 mins

                List<Domain.Entities.UserPasswordChangeLog> dbUserPasswordChange = _context.UserPasswordChangeLogs.Where(t => t.UserId == user.UserId && t.ChangeDate >= DateTime.UtcNow.AddMinutes(-10)).ToList();

                if (dbUserPasswordChange != null && dbUserPasswordChange.Count > 0)
            {

                if (dbUserPasswordChange.Count == 3)
                {
                    //send email to admin & user
                }
                if (dbUserPasswordChange.Count >= 5)
                {
                    user.Lockout = true;
                    _context.Users.Update(user);
                    await _context.SaveChangesAsync(cancellationToken);
                    await _mediator.Send(new GenerateUserUnlockVerificationCodeCommand { UserId = user.UserId });
                    throw new ValidationException(new ValidationFailure("Account", _localizer["Your account is locked.An email to unlock your account has been sent to your registered email address."].Value));
                }

            }
        }
            //Call userverificationcode generation method
            GenerateUserVerificationCodeCommand verificationcode = new()
            {
                CodeType = EventBus.DomainEvents.Enums.CodeType.ForgotPasswordSms,
                UserId = user.UserId,
                Receiver = user.MobileCountryCode.Trim() + user.MobileNumber.Trim(),
                TenantName = command.TenantName
            };
            Domain.Entities.CodeVerification res = await _mediator.Send(verificationcode);

            result.Success = true;

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}