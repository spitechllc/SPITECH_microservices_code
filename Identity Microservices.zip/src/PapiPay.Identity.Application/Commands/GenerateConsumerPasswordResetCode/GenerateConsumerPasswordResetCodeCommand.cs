﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;

namespace PapiPay.Identity.Application.Commands.GenerateConsumerPasswordResetCode
{
    public class GenerateConsumerPasswordResetCodeCommand : IRequest<ResponseModel>
    {
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
        public string TenantName { get; set; }
    }
}
