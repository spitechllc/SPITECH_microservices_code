﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.EventBus.DomainEvents.Enums;

namespace PapiPay.Identity.Application.Commands.UnlockUserByUserId
{
    public class UnlockUserByUserIdCommand : IRequest<ResponseModel>
    {
        public string UserUnlockCode { get; set; }
    }
}
