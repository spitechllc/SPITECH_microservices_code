﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using Microsoft.Extensions.Localization;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.UnlockUserByUserId
{
    public class UnlockUserByUserIdHandler : IRequestHandler<UnlockUserByUserIdCommand, ResponseModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<UnlockUserByUserIdHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IStringLocalizer<UnlockUserByUserIdHandler> _localizer;

        public UnlockUserByUserIdHandler(IIdentityDbContext context,
            ILogger<UnlockUserByUserIdHandler> logger,
            IMediator mediator, IMapper mapper,
            IEventDispatcher eventDispatcher, IUserAuthenticationProvider userAuthenticationProvider, IStringLocalizer<UnlockUserByUserIdHandler> localizer)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _localizer = localizer;
        }

        public async Task<ResponseModel> Handle(UnlockUserByUserIdCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel result = new();
            Domain.Entities.CodeVerification code = _context.CodeVerifications.FirstOrDefault(t => t.Code == command.UserUnlockCode
             && t.CodeType == (int)EventBus.DomainEvents.Enums.CodeType.UserUnlock);


            if (code != null)
            {

                User user = _context.Users.FirstOrDefault(t => t.UserId == code.UserId && t.Lockout == true);
                if (user == null)
                {
                    throw new ValidationException(new ValidationFailure(_localizer["UserId"].Value, _localizer["Invalid UserId"].Value));
                }              
                user.Lockout = false;
                _context.Users.Update(user);

                result.Success = (await _context.SaveChangesAsync(cancellationToken)) > 0;
                if(result.Success)
                {

                    await DispatchActivityLogEvent(user.UserId, (int)ActivityType.UnlockUser, "User Unlocked.");
                }
            }
            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ""
            });
        }
    }
}