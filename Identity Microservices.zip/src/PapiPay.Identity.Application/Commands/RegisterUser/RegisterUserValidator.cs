﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.RegisterUser
{
    public class RegisterUserValidator : AbstractValidator<RegisterUserCommand>
    {
        public RegisterUserValidator()
        {
            RuleFor(x => x.FirstName).NotNull().NotEmpty().Length(1, 50);
            RuleFor(x => x.LastName).NotNull().NotEmpty().Length(1, 50);
            RuleFor(x => x.Password).NotNull().NotEmpty().Length(1, 20);

            When(t => !string.IsNullOrEmpty(t.Gender), () =>
            {
                RuleFor(x => x.Gender).Must(t => t == "M" || t == "F" || t == "N").WithMessage("Gender should be blank or M , F Or N");
            });

            When(t => t.UserType == EventBus.DomainEvents.Enums.UserTypeEnum.Consumer, () =>
            {
                RuleFor(x => x.MobileCountryCode).NotNull().NotEmpty().Length(1, 10);
                RuleFor(x => x.MobileNumber).NotNull().NotEmpty().Length(1, 20);
                RuleFor(x => x.Email).NotNull().NotEmpty().Length(1, 100);
                RuleFor(x => x.PreferedLanguage).Length(0, 20);
                RuleFor(x => x.DeviceToken).Length(0, 255);
                RuleFor(x => x.DeviceType).IsInEnum();
            });

            When(t => t.UserType == EventBus.DomainEvents.Enums.UserTypeEnum.Store, () =>
            {
                RuleFor(x => x.MobileCountryCode).Length(1, 10);
                RuleFor(x => x.MobileNumber).Length(1, 20);
                RuleFor(x => x.Email).Length(1, 100);
                RuleFor(x => x.PreferedLanguage).Length(0, 20);
                RuleFor(x => x.UserName).NotNull().NotEmpty().Length(0, 50);
            });

            RuleFor(x => x.AddressLine1).Length(0, 500);
            RuleFor(x => x.AddressLine2).Length(0, 500);
            RuleFor(x => x.Country).Length(0, 100);
            RuleFor(x => x.CountryCode).Length(0, 10);
            RuleFor(x => x.State).Length(0, 100);
            RuleFor(x => x.City).Length(0, 100);
            RuleFor(x => x.Longitude).Length(0, 50);
            RuleFor(x => x.Latitude).Length(0, 50);
            RuleFor(x => x.ZipCode).Length(0, 10);
            RuleFor(x => x.Store).Length(0, 200);
            RuleFor(x => x.Company).Length(0, 200);
        }
    }
}
