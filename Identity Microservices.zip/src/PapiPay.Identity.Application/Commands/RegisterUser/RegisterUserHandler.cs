using AutoMapper;
using FluentValidation.Results;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Commands.GenerateUserVerificationCode;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Application.Queries.GoogleAPIAddress;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Identity.Domain.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using static PapiPay.ApplicationCore.Domain.DomainConstant;

namespace PapiPay.Identity.Application.Commands.RegisterUser
{
    public class RegisterUserHandler : IRequestHandler<RegisterUserCommand, int>
    {
        private readonly IIdentityDbContext context;
        private readonly ILogger<RegisterUserHandler> logger;
        private readonly IMediator mediator;
        private readonly IMapper mapper;
        private readonly IHashProvider hashProvider;
        private readonly IRandomCodeProvider randomCodeProvider;
        private readonly IStringLocalizer<RegisterUserHandler> _localizer;
        private readonly IEventDispatcher eventDispatcher;

        public RegisterUserHandler(IIdentityDbContext context,
            ILogger<RegisterUserHandler> logger,
            IMediator mediator,
            IMapper mapper,
            IHashProvider hashProvider,
            IRandomCodeProvider randomCodeProvider,
            IStringLocalizer<RegisterUserHandler> localizer, IEventDispatcher eventDispatcher)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            this.mapper = mapper;
            this.hashProvider = hashProvider;
            this.randomCodeProvider = randomCodeProvider;
            _localizer = localizer;
            this.eventDispatcher = eventDispatcher;
        }

        public async Task<int> Handle(RegisterUserCommand command, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), command);
            User dbUser = null;

            if (command.UserType == EventBus.DomainEvents.Enums.UserTypeEnum.Consumer)
            {

                System.Collections.Generic.List<User> dbUsers = new System.Collections.Generic.List<User>();
                if (command.TenantName == TenantName.TheStation)
                {
                    dbUsers = context.Users.Where(t => (t.MobileNumber == command.MobileNumber || t.Email == command.Email) && (t.UserTypeId == (int)EventBus.DomainEvents.Enums.UserTypeEnum.Consumer) && (t.TenantName == TenantName.TheStation)).ToList();
                }
                else if (command.TenantName == TenantName.varifone)
                {
                    dbUsers = context.Users.Where(t => (t.MobileNumber == command.MobileNumber || t.Email == command.Email) && (t.UserTypeId == (int)EventBus.DomainEvents.Enums.UserTypeEnum.Consumer) && (t.TenantName == TenantName.varifone)).ToList();
                }
                else if (command.TenantName == TenantName.PapiPay)
                {
                    dbUsers = context.Users.Where(t => (t.MobileNumber == command.MobileNumber || t.Email == command.Email) && (t.UserTypeId == (int)EventBus.DomainEvents.Enums.UserTypeEnum.Consumer) && (t.TenantName == "PapiPay")).ToList();
                }
                else if (command.TenantName == "" || string.IsNullOrEmpty(command.TenantName))
                {
                    dbUsers = context.Users.Where(t => (t.MobileNumber == command.MobileNumber || t.Email == command.Email) && (t.UserTypeId == (int)EventBus.DomainEvents.Enums.UserTypeEnum.Consumer)).ToList();
                    command.TenantName = "PapiPay";
                }


                if (dbUsers != null || dbUsers.Any())
                {
                    dbUser = dbUsers.FirstOrDefault(t => t.MobileNumber == command.MobileNumber && t.MobileConfirmed);

                    if (dbUser != null)
                    {
                        throw new ValidationException(new ValidationFailure(_localizer["MobileNumber"].Value, _localizer["Mobile number is already register."].Value));
                    }


                    dbUser = dbUsers.FirstOrDefault(t => t.Email == command.Email && t.EmailConfirmed);

                    if (dbUser != null)
                    {
                        throw new ValidationException(new ValidationFailure(_localizer["Email"].Value, _localizer["Email already register."].Value));
                    }

                    dbUser = dbUsers.FirstOrDefault();
                }
            }
            else
            {
                dbUser = context.Users.FirstOrDefault(t => t.UserName == command.UserName && t.UserTypeId == (int)command.UserType);
                if (dbUser != null)
                {
                    throw new ValidationException(new ValidationFailure(_localizer["UserName"].Value, _localizer["User name already register"].Value));
                }
            }

            if (command.UserType == EventBus.DomainEvents.Enums.UserTypeEnum.Consumer)
            {
                if (!string.IsNullOrWhiteSpace(command.ZipCode))
                {
                    Domain.Models.GoogleAddressModel googleaddr = await mediator.Send(new GoogleAPIAddressQuery { Zipcode = command.ZipCode });

                    if (googleaddr != null)
                    {
                        command.Country = googleaddr.Country;
                        command.State = googleaddr.State;
                        command.City = googleaddr.City;
                        command.Latitude = googleaddr.Latitude;
                        command.Longitude = googleaddr.Longitude;
                    }
                }
            }

            User user = null;

            if (dbUser == null)
            {
                user = CreateNewUser(command);
                await DispatchActivityLogEvent(user.UserId, (int)ActivityType.UserRegister, "UserRegister");
                context.Users.Add(user);
            }
            else
            {
                user = context.Users.Include(t => t.UserProfile).Include(t => t.UserDevices).FirstOrDefault(t => t.UserId == dbUser.UserId);
                if (user != null)
                {
                    foreach (UserDevice userDevice in user.UserDevices)
                    {
                        user.UserDevices.Remove(userDevice);
                    }
                }

                user = UpdateUser(command, user);

                await DispatchActivityLogEvent(user.UserId, (int)ActivityType.UpdateProfile, "UpdateProfile");
                context.Users.Update(user);
            }


            int rowaffected = await context.SaveChangesAsync(cancellationToken);

            if (rowaffected > 0 && command.UserType == EventBus.DomainEvents.Enums.UserTypeEnum.Consumer)
            {
                if (!string.IsNullOrEmpty(command.MobileNumber) && !string.IsNullOrEmpty(command.MobileCountryCode))
                {

                    if (command.MobileNumber.StartsWith("+1"))
                    {
                        command.MobileNumber = command.MobileNumber.Substring(2);
                    }

                    if (command.MobileNumber.StartsWith("1"))
                    {
                        command.MobileNumber = command.MobileNumber.Substring(1);
                    }
                    GenerateUserVerificationCodeCommand verificationcode = new()
                    {
                        CodeType = EventBus.DomainEvents.Enums.CodeType.MobileVerification,
                        UserId = user.UserId,
                        Receiver = command.MobileCountryCode.Trim() + command.MobileNumber.Trim(),
                        TenantName = command.TenantName
                    };
                    CodeVerification res = await mediator.Send(verificationcode);
                }
                if (command.TenantName != null && command.TenantName != "")
                {
                    string[] TenantNames = command.TenantName.Split(',');
                    foreach (string TenantName in TenantNames)
                    {
                        string Name = TenantName.Trim();
                        var res = context.TenantMaster.Where(x => x.TenantName == Name).ToList();
                        var data = res.Select(s => new TenantMasterResponse
                        {
                            ID = s.ID
                        }).Distinct();
                        if (res.Count > 0)
                        {
                            foreach (var item in data)
                            {
                                UserTenantMapping consumerTenant = new UserTenantMapping();
                                try
                                {
                                    consumerTenant.TenantId = item.ID;
                                    consumerTenant.UserId = user.UserId;

                                    context.TenantMasters.Add(consumerTenant);
                                    await context.SaveChangesAsync(cancellationToken);
                                }
                                catch (Exception ex)
                                {

                                    throw;
                                }
                            }
                        }
                        else
                        {
                            TenantMaster tenantMaster = new TenantMaster();
                            try
                            {
                                tenantMaster.TenantName = Name;
                                context.TenantMaster.Add(tenantMaster);
                                await context.SaveChangesAsync(cancellationToken);
                                var result = context.TenantMaster.Where(x => x.TenantName == Name).ToList();
                                var datas = result.Select(s => new TenantMasterResponse
                                {
                                    ID = s.ID
                                }).Distinct();
                                if (datas != null)
                                {
                                    foreach (var item in datas)
                                    {
                                        UserTenantMapping consumerTenant = new UserTenantMapping();
                                        try
                                        {
                                            consumerTenant.TenantId = item.ID;
                                            consumerTenant.UserId = user.UserId;

                                            context.TenantMasters.Add(consumerTenant);
                                            await context.SaveChangesAsync(cancellationToken);
                                        }
                                        catch (Exception ex)
                                        {

                                            throw;
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                throw;
                            }
                        }
                    }
                }
               
            }
            logger.TraceExitMethod(nameof(Handle), user.UserId);

            return user.UserId;
        }

        private User CreateNewUser(RegisterUserCommand command)
        {
            User user = new()
            {
                Email = command.Email,
                FirstName = command.FirstName,
                LastName = command.LastName,
                MobileNumber = command.MobileNumber,
                MobileCountryCode = command.MobileCountryCode,
                PasswordHash = hashProvider.GetHashValue(command.Password),
                UserName = command.UserType != EventBus.DomainEvents.Enums.UserTypeEnum.Consumer ? command.UserName : command.MobileNumber,
                UserTypeId = (int)command.UserType,
                PreferedLanguage = command.PreferedLanguage,
                DOB = CommonUtility.ValidateDateOfBirth(command.DOB),
                TenantName = command.TenantName,
                UserProfile = new UserProfile
                {
                    AddressLine1 = command.AddressLine1,
                    AddressLine2 = command.AddressLine2,
                    City = command.City,
                    State = command.State,
                    Country = command.Country,
                    CountryCode = command.CountryCode,
                    Latitude = command.Latitude,
                    Longitude = command.Longitude,
                    Company = command.Company,
                    CompanyId = command.CompanyId,
                    Store = command.Store,
                    StoreId = command.StoreId,
                    ZipCode = command.ZipCode,
                    LastLogin = System.DateTime.UtcNow,
                    Gender = command.Gender,
                }
            };

            if (command.UserType == EventBus.DomainEvents.Enums.UserTypeEnum.Consumer)
            {
                if (!string.IsNullOrWhiteSpace(command.DeviceToken))
                {
                    user.UserDevices.Add(new UserDevice
                    {
                        DeviceTypeId = (int)command.DeviceType,
                        DeviceToken = command.DeviceToken,
                        IsOnline = true,
                        MobileAppTypeId = (int)EventBus.DomainEvents.Enums.MobileAppType.Consumer
                    });
                }
            }

            if (command.UserType == EventBus.DomainEvents.Enums.UserTypeEnum.Store)
            {
                if (!string.IsNullOrWhiteSpace(user.Email))
                {
                    user.EmailConfirmed = true;
                }

                if (!string.IsNullOrWhiteSpace(user.MobileNumber))
                {
                    user.MobileConfirmed = true;
                }
            }

            if (command.RoleIds != null)
            {
                foreach (string roleid in command.RoleIds)
                {
                    if (!string.IsNullOrWhiteSpace(roleid))
                    {
                        if (roleid != "1")
                        {
                            user.UserRoles.Add(new UserRole { RoleId = roleid });
                        }
                    }
                }
            }



            return user;
        }

        private User UpdateUser(RegisterUserCommand command, User user)
        {
            user.Email = command.Email;
            user.FirstName = command.FirstName;
            user.LastName = command.LastName;
            user.MobileNumber = command.MobileNumber;
            user.MobileCountryCode = command.MobileCountryCode;
            user.PasswordHash = hashProvider.GetHashValue(command.Password);
            user.UserName = command.UserType != EventBus.DomainEvents.Enums.UserTypeEnum.Consumer ? command.UserName : command.MobileNumber;
            user.UserTypeId = (int)command.UserType;
            user.PreferedLanguage = command.PreferedLanguage;
            user.TenantName = command.TenantName;
            user.DOB = CommonUtility.ValidateDateOfBirth(command.DOB);
            user.UserProfile.AddressLine1 = command.AddressLine1;
            user.UserProfile.AddressLine2 = command.AddressLine2;
            user.UserProfile.City = command.City;
            user.UserProfile.State = command.State;
            user.UserProfile.Country = command.Country;
            user.UserProfile.CountryCode = command.CountryCode;
            user.UserProfile.Latitude = command.Latitude;
            user.UserProfile.Longitude = command.Longitude;
            user.UserProfile.Company = command.Company;
            user.UserProfile.CompanyId = command.CompanyId;
            user.UserProfile.Store = command.Store;
            user.UserProfile.StoreId = command.StoreId;
            user.UserProfile.ZipCode = command.ZipCode;
            user.UserProfile.Gender = command.Gender;

            if (command.UserType == EventBus.DomainEvents.Enums.UserTypeEnum.Consumer)
            {
                if (!string.IsNullOrWhiteSpace(command.DeviceToken))
                {
                    user.UserDevices.Add(new UserDevice
                    {
                        DeviceTypeId = (int)command.DeviceType,
                        DeviceToken = command.DeviceToken,
                        IsOnline = true,
                        MobileAppTypeId = (int)EventBus.DomainEvents.Enums.MobileAppType.Consumer
                    });
                }
            }

            return user;
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ""
            });
        }
    }
}