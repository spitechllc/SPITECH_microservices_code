﻿using MediatR;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.Identity.Domain.Entities;

namespace PapiPay.Identity.Application.Commands.GenerateUserVerificationCode
{
    public class GenerateUserVerificationCodeCommand : IRequest<CodeVerification>
    {
        public CodeType CodeType { get; set; }
        public int UserId { get; set; }
        public string Receiver { get; set; }
        public string TenantName { get; set; }
    }
}
