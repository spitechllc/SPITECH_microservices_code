﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Identity;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.GenerateUserVerificationCode
{
    public class GenerateUserVerificationCodeHandler : IRequestHandler<GenerateUserVerificationCodeCommand, CodeVerification>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GenerateUserVerificationCodeHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IRandomCodeProvider randomCodeProvider;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GenerateUserVerificationCodeHandler(IIdentityDbContext context,
            ILogger<GenerateUserVerificationCodeHandler> logger,
            IMediator mediator, IMapper mapper,
            IEventDispatcher eventDispatcher,
            IRandomCodeProvider randomCodeProvider, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.randomCodeProvider = randomCodeProvider;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<CodeVerification> Handle(GenerateUserVerificationCodeCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            this.userAuthenticationProvider.ValidateUserAccess(command.UserId);
            CodeVerification usercodeverification = new()
            {
                CodeType = (int)command.CodeType,
                GeneratedDate = DateTime.UtcNow,
                UserId = command.UserId,
                Code = command.CodeType == CodeType.LinkUser || command.CodeType == CodeType.EmailVerification
                ? Guid.NewGuid().ToString("N").ToLower()
                : randomCodeProvider.GetCode()
            };

            if (command.CodeType == CodeType.ForgotPasswordEmail)
            {
                usercodeverification.ExpiryDate = DateTime.UtcNow.AddMinutes(10);
            }
            else if (command.CodeType == CodeType.ForgotPasswordSms || command.CodeType == CodeType.MobileVerification)
            {
                usercodeverification.Receiver = command.Receiver;
                usercodeverification.ExpiryDate = DateTime.UtcNow.AddMinutes(5);
            }
            else
            {

                usercodeverification.ExpiryDate = command.CodeType == CodeType.LinkUser
                    ? DateTime.UtcNow.AddMinutes(3)
                    : command.CodeType == CodeType.EmailVerification ? DateTime.UtcNow.AddDays(7) : command.CodeType == CodeType.UserUnlock ? DateTime.UtcNow.AddDays(7) : DateTime.UtcNow.AddMinutes(15);
            }

            _context.Database.ExecuteSqlRaw("UPDATE CodeVerification set IsActive=0 where VerifyDate is null and Codetype={0} and userid={1}", (int)command.CodeType, command.UserId);

            _context.CodeVerifications.Add(usercodeverification);
            await _context.SaveChangesAsync(cancellationToken);

            CodeVerification codeverification = mapper.Map<CodeVerification>(usercodeverification);

            if (command.CodeType != CodeType.LinkUser)
            {
                await eventDispatcher.Dispatch(new IdentityUserVerificationCodeEvent
                {
                    Code = codeverification.Code,
                    CodeType = (CodeType)codeverification.CodeType,
                    GeneratedDate = DateTime.UtcNow,
                    UserId = command.UserId,
                    Receiver = command.Receiver,
                    TenantName = command.TenantName,
                });
            }

            _logger.TraceExitMethod(nameof(Handle), codeverification);
            return codeverification;
        }
    }
}