﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.GenerateMobileVerificationCode
{
    public class GenerateMobileVerificationCodeValidator : AbstractValidator<GenerateMobileVerificationCodeCommand>
    {
        public GenerateMobileVerificationCodeValidator()
        {
            RuleFor(x => x.UserType).IsInEnum();
            RuleFor(x => x.MobileCountryCode).NotNull().NotEmpty().Length(0, 5);
            RuleFor(x => x.MobileNumber).NotNull().NotEmpty().Length(0, 20);
        }
    }
}
