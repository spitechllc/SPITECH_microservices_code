﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.EventBus.DomainEvents.Enums;

namespace PapiPay.Identity.Application.Commands.GenerateMobileVerificationCode
{
    public class GenerateMobileVerificationCodeCommand : IRequest<ResponseModel>
    {
        public UserTypeEnum UserType { get; set; }
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
        public string TenantName { get; set; }
    }
}
