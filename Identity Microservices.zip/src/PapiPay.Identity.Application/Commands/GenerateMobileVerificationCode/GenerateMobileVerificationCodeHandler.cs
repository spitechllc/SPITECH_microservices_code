﻿using AutoMapper;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.Identity.Application.Commands.GenerateUserVerificationCode;
using PapiPay.Identity.Application.Interfaces;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.GenerateMobileVerificationCode
{
    public class GenerateMobileVerificationCodeHandler : IRequestHandler<GenerateMobileVerificationCodeCommand, ResponseModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GenerateMobileVerificationCodeHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IRandomCodeProvider randomCodeProvider;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GenerateMobileVerificationCodeHandler(IIdentityDbContext context,
            ILogger<GenerateMobileVerificationCodeHandler> logger,
            IMediator mediator,
            IMapper mapper,
            IRandomCodeProvider randomCodeProvider, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.randomCodeProvider = randomCodeProvider;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<ResponseModel> Handle(GenerateMobileVerificationCodeCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel result = new() { Success = false };

            Domain.Entities.User user = new Domain.Entities.User ();
            if (command.TenantName == "THEStation")
            {
                user = _context.Users.FirstOrDefault(t => t.MobileNumber == command.MobileNumber
                                                        && t.MobileCountryCode == command.MobileCountryCode
                                                        && t.UserTypeId == (int)command.UserType
                                                        && t.TenantName== "THEStation");
            }
            else if (command.TenantName == "Verifone")
            {
                user = _context.Users.FirstOrDefault(t => t.MobileNumber == command.MobileNumber
                                                       && t.MobileCountryCode == command.MobileCountryCode
                                                       && t.UserTypeId == (int)command.UserType
                                                       && t.TenantName == "Verifone");
            }
            else
            {
                 user = _context.Users.FirstOrDefault(t => t.MobileNumber == command.MobileNumber
                                                        && t.MobileCountryCode == command.MobileCountryCode
                                                        && t.UserTypeId == (int)command.UserType);
            }
            

            if (user == null)
            {
                result.Message = "Invalid Mobile Number or Mobile Country Code";
                return result;
            }
            this.userAuthenticationProvider.ValidateUserAccess(user.UserId);

            if (user.MobileConfirmed)
            {
                result.Message = "The Mobile already verified";
                return result;
            }

            //Call userverificationcode generation method
            GenerateUserVerificationCodeCommand verificationcode = new()
            {
                CodeType = EventBus.DomainEvents.Enums.CodeType.MobileVerification,
                UserId = user.UserId,
                Receiver = user.MobileCountryCode.Trim() + user.MobileNumber.Trim(),
                TenantName= user.TenantName,
            };
            Domain.Entities.CodeVerification res = await _mediator.Send(verificationcode);

            result.Success = true;

            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
