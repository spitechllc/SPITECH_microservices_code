﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Application.Queries.GetPasswordChangeLogByUserId;
using PapiPay.Identity.Application.Queries.GetUserById;
using PapiPay.Identity.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.CreateUserPasswordChangeLog
{
    public class CreateUserPasswordChangeLogHandler : IRequestHandler<CreateUserPasswordChangeLogCommand, ResponseModel>
    {
        private readonly IIdentityDbContext context;
        private readonly ILogger<CreateUserPasswordChangeLogHandler> logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IStringLocalizer<CreateUserPasswordChangeLogHandler> _localizer;

        public CreateUserPasswordChangeLogHandler(IIdentityDbContext context,
            ILogger<CreateUserPasswordChangeLogHandler> logger,
            IMediator mediator,
            IMapper mapper, IStringLocalizer<CreateUserPasswordChangeLogHandler> localizer)
        {
            this.context = context;
            this.logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _localizer = localizer;
        }

        public async Task<ResponseModel> Handle(CreateUserPasswordChangeLogCommand command, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), command);


            User user = context.Users.FirstOrDefault(t => t.UserId == command.UserId);

            if (user == null)
            {
                throw new ValidationException(new ValidationFailure(_localizer["UserId"].Value, _localizer["Invalid User."].Value));
            }

           //create password change log
            UserPasswordChangeLog userPasswordChangeLog = new()
            {
                UserId = user.UserId,
                OldPassword = command.OldPassword,
                NewPassword = command.NewPassword,
                ChangeDate = DateTime.UtcNow,
                IsWrongAttempt = command.IsWrongAttempt
            };

            context.UserPasswordChangeLogs.Add(userPasswordChangeLog);

            ////lock user
            //user.Lockout = true;
            //context.Users.Update(user);

            int rowaffected = await context.SaveChangesAsync(cancellationToken);

            logger.TraceExitMethod(nameof(Handle), user.UserId);
            return rowaffected > 0
                ? new ResponseModel() { Success = true, Message = "User Change Password Logs successfully." }
                : new ResponseModel() { Success = false, Message = "User Change Password Log not created." };
        }






    }
}
