﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;
using System;

namespace PapiPay.Identity.Application.Commands.CreateUserPasswordChangeLog
{
    public class CreateUserPasswordChangeLogCommand : IRequest<ResponseModel>
    {
        public int UserId { get; set; }
        public string OldPassword { get; set; }
        public string NewPassword { get; set; }
        public bool IsWrongAttempt { get; set; }
    }
}
