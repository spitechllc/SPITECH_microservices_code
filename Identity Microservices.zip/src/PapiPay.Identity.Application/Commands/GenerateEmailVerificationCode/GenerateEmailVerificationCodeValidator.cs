﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.GenerateEmailVerificationCode
{
    public class GenerateEmailVerificationCodeValidator : AbstractValidator<GenerateEmailVerificationCodeCommand>
    {
        public GenerateEmailVerificationCodeValidator()
        {
            RuleFor(x => x.UserId).GreaterThan(0).WithMessage("Invalid UserId");
        }
    }
}
