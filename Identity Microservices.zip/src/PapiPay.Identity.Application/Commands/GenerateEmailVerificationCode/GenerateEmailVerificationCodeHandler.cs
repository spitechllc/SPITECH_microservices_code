﻿using AutoMapper;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.Identity.Application.Commands.GenerateUserVerificationCode;
using PapiPay.Identity.Application.Interfaces;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.GenerateEmailVerificationCode
{
    public class GenerateEmailVerificationCodeHandler : IRequestHandler<GenerateEmailVerificationCodeCommand, ResponseModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<GenerateEmailVerificationCodeHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IRandomCodeProvider randomCodeProvider;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;

        public GenerateEmailVerificationCodeHandler(IIdentityDbContext context,
            ILogger<GenerateEmailVerificationCodeHandler> logger,
            IMediator mediator,
            IMapper mapper,
            IRandomCodeProvider randomCodeProvider, IUserAuthenticationProvider userAuthenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.randomCodeProvider = randomCodeProvider;
            this.userAuthenticationProvider = userAuthenticationProvider;
        }

        public async Task<ResponseModel> Handle(GenerateEmailVerificationCodeCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel result = new() { Success = false };
           // this.userAuthenticationProvider.ValidateUserAccess(command.UserId);
            Domain.Entities.User user = _context.Users.FirstOrDefault(t => t.UserId == command.UserId);
                      
            if (user == null)
            {
                result.Message = "Invalid UserId";
                return result;
            }

            if (user.EmailConfirmed)
            {
                result.Message = "The Email already verified";
                return result;
            }

            //Call userverificationcode generation method
            GenerateUserVerificationCodeCommand verificationcode = new()
            {
                CodeType = EventBus.DomainEvents.Enums.CodeType.EmailVerification,
                UserId = user.UserId,
                Receiver = user.Email.Trim(),
                TenantName= user.TenantName
            };
            Domain.Entities.CodeVerification res = await _mediator.Send(verificationcode);

            result.Success = true;
            _logger.TraceExitMethod(nameof(Handle), result);

            return result;
        }
    }
}
