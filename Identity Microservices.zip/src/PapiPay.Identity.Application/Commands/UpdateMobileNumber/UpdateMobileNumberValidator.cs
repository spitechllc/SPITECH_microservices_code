﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.UpdateMobileNumber
{
    public class UpdateMobileNumberValidator : AbstractValidator<UpdateMobileNumberCommand>
    {
        public UpdateMobileNumberValidator()
        {
            RuleFor(x => x.UserId).GreaterThan(0);
            RuleFor(x => x.MobileCountryCode).NotNull().NotEmpty().Length(1,10);
            RuleFor(x => x.MobileNumber).NotNull().NotEmpty().Length(1,20);
            RuleFor(x => x.VerificationCode).NotNull().NotEmpty().Length(1,50);
        }
    }
}
