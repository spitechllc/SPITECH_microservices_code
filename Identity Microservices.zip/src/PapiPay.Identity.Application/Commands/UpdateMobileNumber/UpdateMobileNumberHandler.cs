﻿using AutoMapper;
using FluentValidation.Results;
using MediatR;
using Microsoft.Extensions.Localization;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Identity;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.UpdateMobileNumber
{
    public class UpdateMobileNumberHandler : IRequestHandler<UpdateMobileNumberCommand, ResponseModel<int>>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<UpdateMobileNumberHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IUserAuthenticationProvider userAuthenticationProvider;
        private readonly IStringLocalizer<UpdateMobileNumberHandler> _localizer;

        public UpdateMobileNumberHandler(IIdentityDbContext context,
            ILogger<UpdateMobileNumberHandler> logger,
            IMediator mediator, IMapper mapper,
            IEventDispatcher eventDispatcher, IUserAuthenticationProvider userAuthenticationProvider, IStringLocalizer<UpdateMobileNumberHandler> localizer)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.eventDispatcher = eventDispatcher;
            this.userAuthenticationProvider = userAuthenticationProvider;
            _localizer = localizer;
        }

        public async Task<ResponseModel<int>> Handle(UpdateMobileNumberCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            bool result = true;
            ResponseModel<int> response = new() { Success = false };
            this.userAuthenticationProvider.ValidateUserAccess(command.UserId);
            User user = _context.Users.FirstOrDefault(t => t.UserId == command.UserId);
            string prevMobile = user.MobileNumber;
            if (user == null)
            {
                throw new ValidationException(new ValidationFailure(_localizer["UserId"].Value, _localizer["Invalid UserId"].Value));
            }

            if (prevMobile == command.MobileNumber)
            {
                throw new ValidationException(new ValidationFailure(_localizer["MobileNumber"].Value, _localizer["Mobile number can not be same with current mobile number"].Value));
            }

            if (user.UserTypeId == (int)EventBus.DomainEvents.Enums.UserTypeEnum.Consumer)
            {
                if (!string.IsNullOrEmpty(command.MobileNumber) && !string.IsNullOrEmpty(command.MobileCountryCode))
                {
                    CodeVerification code = _context.CodeVerifications.FirstOrDefault(t => t.Code == command.VerificationCode
                                                               && t.UserId == command.UserId
                                                               && t.CodeType == (int)CodeType.MobileVerification
                                                               && t.IsActive == true
                                                               && t.VerifyDate == null
                                                               && t.Receiver == command.MobileCountryCode.Trim() + command.MobileNumber.Trim());
                    if (code == null)
                    {
                        response.Message = "Invalid Code";
                        return response;
                    }

                    if (code.ExpiryDate < DateTime.UtcNow)
                    {
                        response.Message = "The Code Expired";
                        return response;
                    }

                    code.VerifyDate = DateTime.UtcNow;
                    _context.CodeVerifications.Update(code);

                    string strPreData = user.MobileCountryCode + "-" + user.MobileNumber;
                    user.UserName = command.MobileNumber;
                    user.MobileConfirmed = true;
                    user.MobileNumber = command.MobileNumber;
                    user.MobileCountryCode = command.MobileCountryCode;
                    string strPostData = command.MobileCountryCode + "-" + command.MobileNumber;
                    _context.Users.Update(user);
                    await _context.SaveChangesAsync(cancellationToken);

                    response.Data = user.UserId;
                    response.Success = true;
                    await DispatchActivityLogEvent(user.UserId, (int)ActivityType.UpdateMobileNo, "User Mobile Number Updated.", strPreData, strPostData);
                }
            }

            _logger.TraceExitMethod(nameof(Handle), result);

            return response;
        }


        private Task DispatchUserUpdatedEvent(User user)
        {
            return eventDispatcher.Dispatch(new IdentityUserUpdatedEvent
            {
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName,
                MobileCountryCode = user.MobileCountryCode,
                MobileNumber = user.MobileNumber,
                PreferedLanguage = user.PreferedLanguage,
                UserId = user.UserId,
                UserName = user.UserName,
                UserTypeId = user.UserTypeId,
                MobileConfirmed = user.MobileConfirmed,
                EmailConfirmed = user.EmailConfirmed,
                EnrolledBusinessUser = user.EnrolledBusinessUser,
                IsActive = user.IsActive,
                UserProfile = new EventBus.DomainEvents.Models.Identity.UserProfileModel
                {
                    AddressLine1 = user.UserProfile.AddressLine1,
                    AddressLine2 = user.UserProfile.AddressLine2,
                    City = user.UserProfile.City,
                    Company = user.UserProfile.Company,
                    CompanyId = user.UserProfile.CompanyId,
                    Country = user.UserProfile.Country,
                    CountryCode = user.UserProfile.CountryCode,
                    Latitude = user.UserProfile.Latitude,
                    Longitude = user.UserProfile.Longitude,
                    PhotoUrl = user.UserProfile.PhotoUrl,
                    State = user.UserProfile.State,
                    Store = user.UserProfile.Store,
                    StoreId = user.UserProfile.StoreId,
                    ZipCode = user.UserProfile.ZipCode,
                    BusinessName = user.UserProfile.BusinessName,
                    BusinessAccountNumber = user.UserProfile.BusinessAccountNumber,
                },
                UserDevices = mapper.Map<EventBus.DomainEvents.Models.Identity.UserDeviceModel[]>(user.UserDevices?.ToArray())
            });
        }

        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey, string preData, string postData)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = "",
                ActivityPreData = preData,
                ActivityPostData = postData
            });
        }
    }
}
