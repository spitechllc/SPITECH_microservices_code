﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;

namespace PapiPay.Identity.Application.Commands.UpdateMobileNumber
{
    public class UpdateMobileNumberCommand : IRequest<ResponseModel<int>>
    {
        public int UserId { get; set; }
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
        public string VerificationCode { get; set; }
    }
}
