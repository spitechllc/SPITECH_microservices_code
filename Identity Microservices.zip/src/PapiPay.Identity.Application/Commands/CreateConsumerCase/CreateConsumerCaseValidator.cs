﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.CreateConsumerCase
{
    public class CreateConsumerCaseValidator : AbstractValidator<CreateConsumerCaseCommand>
    {
        public CreateConsumerCaseValidator()
        {
            RuleFor(x => x.UserId).GreaterThan(0).WithMessage("Reason Required");
            RuleFor(x => x.Reason).NotEmpty().NotNull().WithMessage("Reason Required");
            RuleFor(x => x.Description).NotEmpty().NotNull().WithMessage("Description Required");
            RuleFor(x => x.Subject).NotEmpty().NotNull().WithMessage("Subject Required");
        }
    }
}
