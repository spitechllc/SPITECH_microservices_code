﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;

namespace PapiPay.Identity.Application.Commands.CreateConsumerCase
{
    public class CreateConsumerCaseCommand:IRequest<ResponseModel>
    {
        public int UserId { get; set; }
        public string Subject { get; set; }
        public string Description { get; set; }
        public string Reason { get; set; }
    }
}
