﻿using AutoMapper;
using FluentValidation;
using FluentValidation.Results;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.ApplicationCore.Helpers;
using PapiPay.ApplicationCore.Salesforce;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Models;
using System;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.CreateConsumerCase
{
    public class CreateConsumerCaseHandler : IRequestHandler<CreateConsumerCaseCommand, ResponseModel>
    {
        //private readonly ISalesforceHttpClientRepository _salesforceHttpClient;
        //private readonly IAuthenticationProvider authenticationProvider;
        private readonly IIdentityDbContext _context;
        private readonly ILogger<CreateConsumerCaseHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IUserAuthenticationProvider authenticationProvider;

        public CreateConsumerCaseHandler(IIdentityDbContext context,
            ILogger<CreateConsumerCaseHandler> logger,
            IMediator mediator,
            IMapper mapper, IUserAuthenticationProvider authenticationProvider)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.authenticationProvider = authenticationProvider;
        }

        public async Task<ResponseModel> Handle(CreateConsumerCaseCommand request, CancellationToken cancellationToken)
        {
            ResponseModel responseModel = new() { Success = false, Message = "" };

            try
            {
                User user = _context.Users.FirstOrDefault(t => t.UserId == request.UserId);

               

                if (user == null)
                {                    
                    responseModel.Success = false;
                    responseModel.Message = "Userid not found in salesforce consumer entity";
                    return responseModel;
                }
                //var model = new { Subject = request.Subject, Description = request.Description, Reason = request.Reason, Consumer__c = consumerid, Type = "Consumer" };
                //string json = JsonObjectConverter.Serialize(model);
                //HttpContent content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
                //HttpResponseMessage res = await _salesforceHttpClient.SendRequest(HttpMethod.Post, "sobjects/Case", content);
                ConsumerCase consumerCase = new()
                {
                    UserId= request.UserId,
                   Subject =request.Subject,
                   Description=request.Description,
                   Reason=request.Reason
                };

                _context.ConsumerCases.Add(consumerCase);

                int rowaffected = await _context.SaveChangesAsync(cancellationToken);

                if (rowaffected > 0)
                {
                    responseModel.Success = true;
                    responseModel.Message = "Case Created Successfully";
                }
            }
            catch (Exception ex)
            {
                responseModel.Success = false;
                responseModel.Message = ex.Message;
            };
            return responseModel;
        }

      
    }
}