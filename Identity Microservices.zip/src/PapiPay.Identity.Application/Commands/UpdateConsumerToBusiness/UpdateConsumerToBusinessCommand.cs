﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;

namespace PapiPay.Identity.Application.Commands.UpdateConsumerToBusiness
{
    public class UpdateConsumerToBusinessCommand : IRequest<ResponseModel>
    {
        public int UserId { get; set; }
        public string BusinessName { get; set; }
        public string BusinessAccountNumber { get; set; }
        public bool IsBusinessUser { get; set; }
        public string UpdatedBy { get; set; }
    }
}
