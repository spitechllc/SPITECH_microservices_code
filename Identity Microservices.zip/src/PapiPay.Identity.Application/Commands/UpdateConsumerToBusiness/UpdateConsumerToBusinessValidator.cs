﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.UpdateConsumerToBusiness
{
    public class UpdateConsumerToBusinessValidator : AbstractValidator<UpdateConsumerToBusinessCommand>
    {
        public UpdateConsumerToBusinessValidator()
        {
            RuleFor(x => x.UserId).GreaterThan(0);
            RuleFor(x => x.BusinessName).NotNull().NotEmpty().WithMessage("BusinessName Is required").Length(1,200);
            RuleFor(x => x.IsBusinessUser).NotNull().NotEmpty().WithMessage("IsBusinessUser Is required");
            RuleFor(x => x.UpdatedBy).NotNull().NotEmpty().WithMessage("UpdatedBy Is required").Length(1,256);
            RuleFor(x => x.BusinessAccountNumber).Length(0, 50);
        }
    }
}
