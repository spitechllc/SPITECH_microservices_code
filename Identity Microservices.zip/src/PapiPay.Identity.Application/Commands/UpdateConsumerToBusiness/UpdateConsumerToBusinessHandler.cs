﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.ApplicationCore.Helpers;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Identity;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.UpdateConsumerToBusiness
{
    public class UpdateConsumerToBusinessHandler : IRequestHandler<UpdateConsumerToBusinessCommand, ResponseModel>
    {
        private readonly IIdentityDbContext context;
        private readonly ILogger<UpdateConsumerToBusinessHandler> logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IEventDispatcher eventDispatcher;

        public UpdateConsumerToBusinessHandler(IIdentityDbContext context, ILogger<UpdateConsumerToBusinessHandler> _logger,
            IMediator mediator, IMapper mapper, IEventDispatcher eventDispatcher)
        {
            this.context = context;
            logger = _logger;
            _mediator = mediator;
            this.mapper = mapper;
            this.eventDispatcher = eventDispatcher;
        }

        public async Task<ResponseModel> Handle(UpdateConsumerToBusinessCommand command, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel response = new() { Success = false, Message = "" };
            try
            {
                User user = context.Users.Include(t => t.UserProfile).FirstOrDefault(t => t.UserId == command.UserId && t.UserTypeId == (int)UserTypeEnum.Consumer);
                if (user != null)
                {
                    if (!user.EnrolledBusinessUser)
                    {
                        string strPreData = JsonObjectConverter.Serialize(user);
                        user.EnrolledBusinessUser = true;
                        user.UserProfile.BusinessAccountNumber = command.BusinessAccountNumber;
                        user.UserProfile.BusinessName = command.BusinessName;
                        user.UpdatedOn = DateTime.Now;
                        user.UpdatedBy = command.UpdatedBy;
                        user.UserProfile.UpdatedOn = DateTime.Now;
                        user.UserProfile.UpdatedBy = command.UpdatedBy;
                        context.Users.Update(user);
                        int result = await context.SaveChangesAsync(cancellationToken);
                        DispatchUserUpdatedEvent(user);
                        response.Success = true; response.Message = "User Profile Updated Successfully";
                        string strPostData = JsonObjectConverter.Serialize(user);
                        await DispatchActivityLogEvent(user.UserId, (int)ActivityType.UpdateConsumerToBusiness, "User Profile Updated To Business User Successfully.", strPreData, strPostData);
                    }
                    else
                    {
                        response.Success = false; response.Message = "Consumer Already A Business User";
                    }
                }
                else
                {
                    response.Success = false; response.Message = "Consumer Not Found";
                }
            }
            catch (Exception ex) { response.Success = false; response.Message = ex.Message; }
            logger.TraceExitMethod(nameof(Handle), response);
            return response;
        }

        private void DispatchUserUpdatedEvent(User user)
        {
            eventDispatcher.Dispatch(new IdentityUserUpdatedEvent
            {
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName,
                MobileCountryCode = user.MobileCountryCode,
                MobileNumber = user.MobileNumber,
                PreferedLanguage = user.PreferedLanguage,
                UserId = user.UserId,
                UserName = user.UserName,
                UserTypeId = user.UserTypeId,
                MobileConfirmed = user.MobileConfirmed,
                EmailConfirmed = user.EmailConfirmed,
                EnrolledBusinessUser = user.EnrolledBusinessUser,
                IsActive = user.IsActive,
                UserProfile = new EventBus.DomainEvents.Models.Identity.UserProfileModel
                {
                    AddressLine1 = user.UserProfile.AddressLine1,
                    AddressLine2 = user.UserProfile.AddressLine2,
                    City = user.UserProfile.City,
                    Company = user.UserProfile.Company,
                    CompanyId = user.UserProfile.CompanyId,
                    Country = user.UserProfile.Country,
                    CountryCode = user.UserProfile.CountryCode,
                    Latitude = user.UserProfile.Latitude,
                    Longitude = user.UserProfile.Longitude,
                    PhotoUrl = user.UserProfile.PhotoUrl,
                    State = user.UserProfile.State,
                    Store = user.UserProfile.Store,
                    StoreId = user.UserProfile.StoreId,
                    ZipCode = user.UserProfile.ZipCode,
                    BusinessName = user.UserProfile.BusinessName,
                    BusinessAccountNumber = user.UserProfile.BusinessAccountNumber,
                },
                //UserDevices = mapper.Map<EventBus.DomainEvents.Models.Identity.UserDeviceModel[]>(user.UserDevices?.ToArray())
            });
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey,string preData,string postData)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = "",
                ActivityPreData=preData,
                ActivityPostData=postData
            });
        }
    }
}
