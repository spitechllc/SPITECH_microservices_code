﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.ResetStoreUserPassword
{
    public class ResetStoreUserPasswordValidator : AbstractValidator<ResetStoreUserPasswordCommand>
    {
        public ResetStoreUserPasswordValidator()
        {
            RuleFor(x => x.Password).NotNull().NotEmpty().Length(1,20);
            RuleFor(x => x.UserName).NotNull().NotEmpty().Length(1,50);
            RuleFor(x => x.VerificationCode).NotNull().NotEmpty().Length(1,50);
        }
    }
}
