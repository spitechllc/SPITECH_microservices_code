﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;
using System.ComponentModel.DataAnnotations;

namespace PapiPay.Identity.Application.Commands.ResetStoreUserPassword
{
    public class ResetStoreUserPasswordCommand : IRequest<ResponseModel>
    {
        public string UserName { get; set; }
        public string VerificationCode { get; set; }
        public string Password { get; set; }
    }
}
