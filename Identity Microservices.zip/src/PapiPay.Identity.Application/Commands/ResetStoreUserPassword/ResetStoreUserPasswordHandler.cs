﻿using AutoMapper;
using MediatR;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Identity;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Commands.VerifyCode;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.ResetStoreUserPassword
{
    public class ResetStoreUserPasswordHandler : IRequestHandler<ResetStoreUserPasswordCommand, ResponseModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<ResetStoreUserPasswordHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IHashProvider hashProvider;
        private readonly IRandomCodeProvider randomCodeProvider;
        private readonly IEventDispatcher eventDispatcher;

        public ResetStoreUserPasswordHandler(IIdentityDbContext context,
            ILogger<ResetStoreUserPasswordHandler> logger,
            IMediator mediator,
            IHashProvider hashProvider,
            IMapper mapper,
            IRandomCodeProvider randomCodeProvider,
            IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.hashProvider = hashProvider;
            this.mapper = mapper;
            this.randomCodeProvider = randomCodeProvider;
            this.eventDispatcher = eventDispatcher;
        }

        public async Task<ResponseModel> Handle(ResetStoreUserPasswordCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel<int> response = new() { Success = false };

            User user = _context.Users.FirstOrDefault(t => t.UserName == command.UserName
                                                        && t.UserTypeId == (int)EventBus.DomainEvents.Enums.UserTypeEnum.Store);

            if (user == null)
            {
                response.Message = "Invalid User Name";
                return response;
            }

            //verifycode
            VerifyCodeCommand verificationcode = new()
            {
                CodeType = EventBus.DomainEvents.Enums.CodeType.ForgotPasswordEmail,
                Code = command.VerificationCode,
                UserId = user.UserId
            };
            response = await _mediator.Send(verificationcode);

            if (response.Success && response.Data == user.UserId)
            {
                response.Data = user.UserId;
                response.Success = true;
                user.PasswordHash = hashProvider.GetHashValue(command.Password);
                _context.Users.Update(user);
                await _context.SaveChangesAsync(cancellationToken);
                await DispatchChangePasswordEvent(user);
                await DispatchActivityLogEvent(user.UserId, (int)ActivityType.ForgotPassword, "ForgotPassword");
               
            }
            else
            {
                response.Message = "Invalid Verification Code";
                return response;
            }

            _logger.TraceExitMethod(nameof(Handle), response);

            return response;
        }

        private Task DispatchChangePasswordEvent(User user)
        {
            return eventDispatcher.Dispatch(new IdentityPasswordChangedEvent
            {
                Email = user.Email,
                UserId = user.UserId,
                FirstName = user.FirstName,
                LastName = user.LastName,
                MobileCountryCode = user.MobileCountryCode,
                MobileNumber = user.MobileNumber,
                UserName = user.UserName,
                UserTypeId = user.UserTypeId,
            });
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ""
            });
        }

    }
}
