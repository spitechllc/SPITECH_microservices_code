﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.ApplicationCore.Helpers;
using PapiPay.ApplicationCore.Salesforce;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Identity;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.EventBus.DomainEvents.Models.Identity;
using PapiPay.Identity.Application.Commands.GenerateUserVerificationCode;
using PapiPay.Identity.Application.Commands.VerifyCode;
using PapiPay.Identity.Application.Interfaces;
using PapiPay.Identity.Domain.Entities;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.VerifyMobile
{
    public class VerifyMobileHandler : IRequestHandler<VerifyMobileCommand, ResponseModel<int>>
    {
        private readonly IIdentityDbContext context;
        private readonly ILogger<VerifyMobileHandler> logger;
        private readonly IMediator mediator;
        private readonly IMapper mapper;
        private readonly IEventDispatcher eventDispatcher;

        public VerifyMobileHandler(IIdentityDbContext context,
            ILogger<VerifyMobileHandler> logger,
            IMediator mediator,
            IMapper mapper,
            IEventDispatcher eventDispatcher)
        {
            this.context = context;
            this.logger = logger;
            this.mediator = mediator;
            this.mapper = mapper;
            this.eventDispatcher = eventDispatcher;
        }

        public async Task<ResponseModel<int>> Handle(VerifyMobileCommand command, CancellationToken cancellationToken)
        {
            logger.TraceEnterMethod(nameof(Handle), command);
            ResponseModel<int> response = new() { Success = false };
            User user = new User();
            if (command.TenantName == "THEStation")
            {
                user = context.Users.Include(t => t.UserProfile).FirstOrDefault(t => t.MobileNumber == command.MobileNumber
                                                           && t.MobileCountryCode == command.MobileCountryCode
                                                           && t.UserTypeId == (int)command.UserType
                                                           && t.TenantName== "THEStation");
            }
            else if (command.TenantName == "Verifone")
            {
                user = context.Users.Include(t => t.UserProfile).FirstOrDefault(t => t.MobileNumber == command.MobileNumber
                                                           && t.MobileCountryCode == command.MobileCountryCode
                                                           && t.UserTypeId == (int)command.UserType
                                                           && t.TenantName == "Verifone");
            }
            else
            {
                user = context.Users.Include(t => t.UserProfile).FirstOrDefault(t => t.MobileNumber == command.MobileNumber
                                                                         && t.MobileCountryCode == command.MobileCountryCode
                                                                         && t.UserTypeId == (int)command.UserType && (t.TenantName == "PapiPay" || t.TenantName == ""  || t.TenantName == null));
            }



            if (user == null)
            {
                response.Message = "Invalid Mobile Number or Mobile Country Code";
                return response;
            }

            if (user.MobileConfirmed)
            {
                response.Message = "The Mobile already verified.Please go back and login.";
                return response;
            }

            //verifycode
            VerifyCodeCommand verificationcode = new()
            {
                CodeType = CodeType.MobileVerification,
                Code = command.VerificationCode,
                UserId = user.UserId
            };
            response = await mediator.Send(verificationcode);

            if (response.Success && response.Data == user.UserId)
            {
                response.Data = user.UserId;
                response.Success = true;
                user.MobileConfirmed = true;
                context.Users.Update(user);
                int result = await context.SaveChangesAsync(cancellationToken);

                await DispatchActivityLogEvent(user.UserId, (int)ActivityType.VerifyMobile, "User Mobile Verified.");
                if (user.UserTypeId == (int)UserTypeEnum.Consumer)
                {
                    await DispatchEmailVerification(user);
                    await DispatchNewUserCreatedEvent(user);
                }
            }
            else
            {
                response.Message = "Invalid Verification Code";
                return response;
            }

            logger.TraceExitMethod(nameof(Handle), response);

            return response;
        }

        private async Task DispatchEmailVerification(User user)
        {
            if (!string.IsNullOrEmpty(user.Email))
            {
                GenerateUserVerificationCodeCommand emailVerification = new()
                {
                    CodeType = CodeType.EmailVerification,
                    UserId = user.UserId,
                    Receiver = user.Email.Trim(),
                    TenantName= user.TenantName
                };
                CodeVerification res = await mediator.Send(emailVerification);
            }
        }

        private Task DispatchNewUserCreatedEvent(User user)
        {
            return eventDispatcher.Dispatch(new IdentityUserCreatedEvent
            {
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName,
                MobileCountryCode = user.MobileCountryCode,
                MobileNumber = user.MobileNumber,
                PreferedLanguage = user.PreferedLanguage,
                UserId = user.UserId,
                UserName = user.UserName,
                UserTypeId = user.UserTypeId,
                EmailConfirmed = user.EmailConfirmed,
                MobileConfirmed = user.MobileConfirmed,
                EnrolledBusinessUser = user.EnrolledBusinessUser,
                IsActive = user.IsActive,
                TenantName = user.TenantName,
                UserProfile = new UserProfileModel
                {
                    AddressLine1 = user.UserProfile.AddressLine1,
                    AddressLine2 = user.UserProfile.AddressLine2,
                    City = user.UserProfile.City,
                    Company = user.UserProfile.Company,
                    CompanyId = user.UserProfile.CompanyId,
                    Country = user.UserProfile.Country,
                    CountryCode = user.UserProfile.CountryCode,
                    Latitude = user.UserProfile.Latitude,
                    Longitude = user.UserProfile.Longitude,
                    PhotoUrl = user.UserProfile.PhotoUrl,
                    State = user.UserProfile.State,
                    Store = user.UserProfile.Store,
                    StoreId = user.UserProfile.StoreId,
                    ZipCode = user.UserProfile.ZipCode,
                    BusinessAccountNumber = user.UserProfile.BusinessAccountNumber,
                    BusinessName = user.UserProfile.BusinessName,
                },
                UserDevices = mapper.Map<UserDeviceModel[]>(user.UserDevices?.ToArray())
            });
        }

        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ""
            });
        }
    }
}
