﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.VerifyMobile
{
    public class VerifyMobileValidator : AbstractValidator<VerifyMobileCommand>
    {
        public VerifyMobileValidator()
        {
            RuleFor(x => x.UserType).IsInEnum();
            RuleFor(x => x.MobileCountryCode).NotNull().NotEmpty().Length(0, 10);
            RuleFor(x => x.MobileNumber).NotNull().NotEmpty().Length(0, 20);
            RuleFor(x => x.VerificationCode).NotNull().NotEmpty().Length(0, 50);
        }
    }
}
