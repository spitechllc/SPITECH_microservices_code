﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Localization;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Commands.RemovePersistedGrant;
using PapiPay.Identity.Application.Interfaces;
using System;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PapiPay.Identity.Application.Commands.Logout
{
    public class LogoutHandler : IRequestHandler<LogoutCommand, ResponseModel>
    {
        private readonly IIdentityDbContext _context;
        private readonly ILogger<LogoutHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper mapper;
        private readonly IStringLocalizer<LogoutHandler> _localizer;
        private readonly IEventDispatcher eventDispatcher;

        public LogoutHandler(IIdentityDbContext context,
            ILogger<LogoutHandler> logger,
            IMediator mediator, IMapper mapper,
            IStringLocalizer<LogoutHandler> localizer, IEventDispatcher eventDispatcher)
        {
            _context = context;
            _logger = logger;
            _mediator = mediator;
            this.mapper = mapper;
            _localizer = localizer;
            this.eventDispatcher = eventDispatcher;
        }

        public async Task<ResponseModel> Handle(LogoutCommand command, CancellationToken cancellationToken)
        {
            _logger.TraceEnterMethod(nameof(Handle), command);
            await DispatchActivityLogEvent(command.UserId, (int)ActivityType.Logout, "Logout");
            return  await _mediator.Send(new RemovePersistedGrantCommand
            {
                UserId = command.UserId
            });
            
        }
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ""
            });
        }
    }
}
