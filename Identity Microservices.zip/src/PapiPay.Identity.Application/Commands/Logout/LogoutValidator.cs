﻿using FluentValidation;

namespace PapiPay.Identity.Application.Commands.Logout
{
    public class LogoutValidator : AbstractValidator<LogoutCommand>
    {
        public LogoutValidator()
        {
            RuleFor(x => x.UserId).GreaterThan(0);
        }
    }
}
