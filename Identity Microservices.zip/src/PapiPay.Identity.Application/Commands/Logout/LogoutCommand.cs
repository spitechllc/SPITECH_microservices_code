﻿using MediatR;
using PapiPay.ApplicationCore.Domain.Models;

namespace PapiPay.Identity.Application.Commands.Logout
{
    public class LogoutCommand : IRequest<ResponseModel>
    {
        public int UserId { get; set; }
    }
}
