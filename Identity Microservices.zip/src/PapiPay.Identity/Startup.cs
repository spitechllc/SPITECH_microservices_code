using IdentityServer4.Services;
using IdentityServer4.Validation;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Primitives;
using Microsoft.OpenApi.Models;
using PapiPay.Application.Logging.Extensions;
using PapiPay.ApplicationCore.Extensions;
using PapiPay.ApplicationCore.Security;
using PapiPay.ApplicationCore.ServiceCollection;
using PapiPay.Identity.Application;
using PapiPay.Identity.Application.Services;
using PapiPay.Identity.Application.Validators;
using PapiPay.Identity.Domain.Helper;
using PapiPay.Identity.Infrastructure.ServiceCollection;
using PapiPay.Service.Clients;
using System;
using System.IO;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;

namespace PapiPay.Identity
{
    public class Startup
    {
        private const string XForwardedProto = "X-Forwarded-Proto";
        public IConfiguration Configuration { get; }
        private readonly string _policyname = "CorsPolicy";

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddLocalization(options => options.ResourcesPath = "Resources");

            services.AddControllersWithViews();

            services.AddFinanceClient(Configuration).AddTransactionClient(Configuration).AddPaymentClient(Configuration); 
            //services.AddPaymentClient(Configuration).AddPaymentClient(Configuration); 

            services.AddTransient<IResourceOwnerPasswordValidator, ResourceOwnerPasswordValidator>();
            services.AddTransient<IProfileService, ProfileService>();
            services.AddTransient<ICustomTokenRequestValidator, GenericCustomTokenRequestValidator>();
            services.AddTransient<ICustomAuthorizeRequestValidator, GenericCustomAuthorizeRequestValidator>();

            services.AddApplicationCore(Configuration).AddInfrastructure(Configuration).AddApplication(Configuration);

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "PapiPay IdentityServer Api",
                    Version = "v1",
                    Description = "The PapiPay IdentityServer Microservice HTTP API.",
                });

                string xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                string xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                options.IncludeXmlComments(xmlPath);
                SwaggerGenSetup.Setup(options);
            });

            services.AddLocalApiAuthentication();

            services.Configure<GoogleAPIOption>(Configuration.GetSection("GoogleAPI"));

            services.Configure<ApplicationCore.Domain.Helper.SalesforceOptions>(Configuration.GetSection("SalesForce"));
            var certificatePath = "";

            try
            {
                certificatePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Certificates", "Papipay.com.pfx");
                var cert = new X509Certificate2(certificatePath, "123456", X509KeyStorageFlags.DefaultKeySet);
                //var cert = new X509Certificate2(Path.Combine(_environment.ContentRootPath, "Papipay.com.pfx"), "password");

                services.AddIdentityServer()
                    .AddIdentityServerContext(Configuration)
                    .AddProfileService<ProfileService>()
                    //.AddDeveloperSigningCredential()
                    .AddSigningCredential(cert)
                    .AddCustomTokenRequestValidator<GenericCustomTokenRequestValidator>()
                    .AddCustomAuthorizeRequestValidator<GenericCustomAuthorizeRequestValidator>()
                    ;
            }
            catch (Exception ex)
            {
                PapiPay.Application.Logging.Logger.Error("Certificate Error", ex, certificatePath);
                throw;
            }

            services.AddCors(option => option.AddPolicy(_policyname, builder =>
            {
                builder.AllowAnyOrigin()
                       .WithMethods("PATCH", "POST", "GET")
                       .AllowAnyHeader();
            }));
            services.AddAPIAuthorization();
            services.AddMiniProfiler().AddEntityFramework();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseMiddleware(typeof(CustomResponseHeaderMiddleware));
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHttpsRedirection();
                app.UseHsts();
            }

            app.Use(async (ctx, next) =>
            {
                if (ctx.Request.Headers.TryGetValue(XForwardedProto, out StringValues proto))
                {
                    ctx.Request.Scheme = proto;
                }

                await next();
            });

            var supportedCultures = new[] { "en", "es" };

            var requestLocalizationOptions = new RequestLocalizationOptions().SetDefaultCulture(supportedCultures[0]).AddSupportedCultures(supportedCultures).AddSupportedUICultures(supportedCultures);

            requestLocalizationOptions.ApplyCurrentCultureToResponseHeaders = true;

            app.UseRequestLocalization(requestLocalizationOptions);

            app.UseLogger();
            app.UseRouting();

            app.UseStaticFiles();
            app.UseSwagger().UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "PapiPay IdentityServer API V1");
            });

            app.UseCookiePolicy(
                   new CookiePolicyOptions
                   {
                       Secure = CookieSecurePolicy.Always
                   });

            app.UseCors(_policyname);

            app.UseIdentityServer();

            app.UseAuthorization();

            app.UseMiniProfiler();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapDefaultControllerRoute();
            });
        }
    }
}
