namespace PapiPay.Identity.Controllers
{
    public class LogoutInputModel
    {
        public string LogoutId { get; set; }
    }
}
