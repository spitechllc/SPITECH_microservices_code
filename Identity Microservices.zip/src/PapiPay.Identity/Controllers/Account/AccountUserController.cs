using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Authorizations;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.ApplicationCore.Pagination;
using PapiPay.Identity.Application.Commands.ChangePassword;
using PapiPay.Identity.Application.Commands.CopyClaims;
using PapiPay.Identity.Application.Commands.CreateConsumerCase;
using PapiPay.Identity.Application.Commands.DeleteUser;
using PapiPay.Identity.Application.Commands.GenerateConsumerPasswordResetCode;
using PapiPay.Identity.Application.Commands.GenerateEmailVerificationCode;
using PapiPay.Identity.Application.Commands.GenerateMobileUpdateVerificationCode;
using PapiPay.Identity.Application.Commands.GenerateMobileVerificationCode;
using PapiPay.Identity.Application.Commands.Logout;
using PapiPay.Identity.Application.Commands.RegisterUser;
using PapiPay.Identity.Application.Commands.ResetConsumerPassword;
using PapiPay.Identity.Application.Commands.ResetUnregisteredConsumerPassword;
using PapiPay.Identity.Application.Commands.UnlockUserByUserId;
using PapiPay.Identity.Application.Commands.UpdateConsumerToBusiness;
using PapiPay.Identity.Application.Commands.UpdateMobileNumber;
using PapiPay.Identity.Application.Commands.UpdatePermission;
using PapiPay.Identity.Application.Commands.UpdatePreferredLanguage;
using PapiPay.Identity.Application.Commands.UpdateProfile;
using PapiPay.Identity.Application.Commands.UpdateProfileUsingPortal;
using PapiPay.Identity.Application.Commands.UpdateUserDeviceByUserId;
using PapiPay.Identity.Application.Commands.VerifyEmail;
using PapiPay.Identity.Application.Commands.VerifyMobile;
using PapiPay.Identity.Application.Commands.VerifyResetPasswordCode;
using PapiPay.Identity.Application.Queries.GetActiveUsers;
using PapiPay.Identity.Application.Queries.GetAllUsersWithPaging;
using PapiPay.Identity.Application.Queries.GetClaims;
using PapiPay.Identity.Application.Queries.GetConsumerUserResponseById;
using PapiPay.Identity.Application.Queries.GetRoleById;
using PapiPay.Identity.Application.Queries.GetRoles;
using PapiPay.Identity.Application.Queries.GetRoleType;
using PapiPay.Identity.Application.Queries.GetSalesforceCase;
using PapiPay.Identity.Application.Queries.GetSalesforceCaseMarchent;
using PapiPay.Identity.Application.Queries.GetStoreUserResponseById;
using PapiPay.Identity.Application.Queries.GetUserByDate;
using PapiPay.Identity.Application.Queries.GetUserByEmailOrPhone;
using PapiPay.Identity.Application.Queries.GetUserById;
using PapiPay.Identity.Application.Queries.GetUserByIds;
using PapiPay.Identity.Application.Queries.GetUserByRole;
using PapiPay.Identity.Application.Queries.GetUserDeviceByUserId;
using PapiPay.Identity.Application.Queries.GetUsersByName;
using PapiPay.Identity.Application.Queries.GetUserWithNoPaymentMethod;
using PapiPay.Identity.Application.Queries.SyncUserById;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Models;
using PapiPay.Identity.Domain.Models.Consumers;
using PapiPay.Identity.Domain.Models.Stores;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using static IdentityServer4.IdentityServerConstants;
using FluentValidation.Results;
using PapiPay.ApplicationCore.Domain.Exceptions;
using PapiPay.Identity.Application.Queries.GetUserWithMOP;
using PapiPay.Identity.Application.Queries.GetTenantMaster;
using PapiPay.Identity.Application.Queries.GetAllConsumer;
using PapiPay.Identity.Application.Queries.GetTenantMasterList;
using PapiPay.Identity.Application.Queries.GetUserTenantById;

namespace PapiPay.Identity.Controllers
{
    [Authorize(LocalApi.PolicyName)]
    [ApiController]
    [Route("api/[controller]")]
    public class AccountUserController : Controller
    {
        private readonly IMediator mediator;
        private readonly IMapper mapper;
        private readonly IUserAuthenticationProvider authenticationProvider;
        private readonly ILogger<AccountUserController> logger;
        private readonly IStringLocalizer<AccountUserController> _localizer;

        public AccountUserController(
            IMediator mediator,
            IMapper mapper,
            IUserAuthenticationProvider authenticationProvider, ILogger<AccountUserController> logger,
         IStringLocalizer<AccountUserController> localizer)
        {
            this.mediator = mediator;
            this.mapper = mapper;
            this.logger = logger;
            this.authenticationProvider = authenticationProvider;
            _localizer = localizer;
        }

        /// <summary>
        /// Register consumers with papipay
        /// </summary>
        /// <param name="model">Object of ConsumerUserModel</param>
        /// <returns>It will return in the form of ConsumerUserResponseModel</returns>
        //ConsumerMobile, BusinessMobile
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("ConsumerRegister")]
        public async Task<ActionResult<ConsumerUserResponseModel>> ConsumerRegister([FromBody] ConsumerUserModel model)
        {
            RegisterUserCommand command = mapper.Map<RegisterUserCommand>(model);
            command.UserType = EventBus.DomainEvents.Enums.UserTypeEnum.Consumer;
            command.MobileNumber = command.MobileNumber?.Trim();
            command.Email = command.Email?.Trim();

            int userid = await mediator.Send(command);

            return userid > 0
                ? (ActionResult<ConsumerUserResponseModel>)Ok(await mediator.Send(new GetConsumerUserResponseByIdRequest { UserId = userid }).ConfigureAwait(false))
                : (ActionResult<ConsumerUserResponseModel>)BadRequest("Unable to process your request");
        }

        /// <summary>
        /// Generate code to verify consumer mobile no
        /// </summary>
        /// <param name="command">Object of GenerateMobileVerificationCodeCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        //ConsumerMobile, BusinessMobile
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("GenerateMobileCode")]
        public async Task<ActionResult<ResponseModel>> GenerateMobileVerificationCode([FromBody] GenerateMobileVerificationCodeCommand command)
        {
            ResponseModel res = await mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// Verifies Consumer Mobile no
        /// </summary>
        /// <param name="command">Object of VerifyMobileCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        //ConsumerMobile, BusinessMobile
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("VerifyMobile")]
        public async Task<ActionResult<ResponseModel<int>>> VerifyMobile([FromBody] VerifyMobileCommand command)
        {
            ResponseModel<int> res = await mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// Generate code to verify user email address
        /// </summary>
        /// <param name="command">Object of GenerateEmailVerificationCodeCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        //ConsumerMobile, BusinessMobile
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("GenerateEmailCode")]
        public async Task<ActionResult<ResponseModel>> GenerateEmailCode([FromBody] GenerateEmailVerificationCodeCommand command)
        {
            ResponseModel res = await mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// Verifies users email address
        /// </summary>
        /// <param name="verificationCode">Varriable of string</param>
        /// <returns>It will return in the form of VerifyEmailModel</returns>
        //On Email Link click
        [AllowAnonymous]
        [HttpGet("VerifyEmail/{verificationCode}/{tenanName}")]
        public async Task<IActionResult> VerifyEmail([FromRoute] string verificationCode, string tenanName)
        {
            bool isVerify = await mediator.Send(new VerifyEmailCommand { EmailVerificationCode = verificationCode }).ConfigureAwait(false);
            VerifyEmailModel vm = new() { IsVerify = isVerify, TenantName= tenanName };
            return View(vm);
        }

        /// <summary>
        /// Generate code to reset consumer's password
        /// </summary>
        /// <param name="command">Object of GenerateConsumerPasswordResetCodeCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        //ConsumerMobile
        [AllowAnonymous]
        [ProducesResponseType(typeof(ResponseModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("GenerateConsumerPasswordResetCode")]
        public async Task<ActionResult<ResponseModel>> GenerateConsumerPasswordResetCode([FromBody] GenerateConsumerPasswordResetCodeCommand command)
        {
            ResponseModel res = await mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// Verifies Code to reset password
        /// </summary>
        /// <param name="command">Object of VerifyResetPasswordCodeCommand</param>
        /// <returns>It will return ResponseModel in the form of string</returns>
        //ConsumerMobile
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("VerifyResetPasswordCode")]
        public async Task<ActionResult<ResponseModel<string>>> VerifyResetPasswordCode([FromBody] VerifyResetPasswordCodeCommand command)
        {
            ResponseModel<string> res = await mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// Resets password after code verification
        /// </summary>
        /// <param name="command">object of ResetConsumerPasswordCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        //ConsumerMobile
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("ResetConsumerPassword")]
        public async Task<ActionResult<ResponseModel>> ResetConsumerPassword([FromBody] ResetConsumerPasswordCommand command)
        {

            ResponseModel res = await mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// Returns user's details based on token passed
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseModel in the form of UserModel</returns>
        //ConsumerMobile, BusinessMobile, Portal
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_GetUserFromToken")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetUserFromToken")]
        public async Task<ActionResult<ResponseModel<UserModel>>> GetUserFromToken()
        {
            int UserId = authenticationProvider.GetUserAuthentication().UserId;
            UserModel user = await mediator.Send(new GetUserByIdRequest() { UserId = UserId }).ConfigureAwait(false);
            return Ok(new ResponseModel<UserModel> { Data = user, Success = user != null });
        }

        /// <summary>
        /// Logged out user 
        /// </summary>
        /// <param name="command">Object of LogoutCommand</param>
        /// <returns>It will return ResponseModel in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_Logout")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("Logout")]
        public async Task<ActionResult<ResponseModel<ResponseModel>>> Logout([FromBody] LogoutCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Updates User profile information
        /// </summary>
        /// <param name="command">Object of UpdateProfileCommand</param>
        /// <returns>It will return ResponseModel in the form of UserSearchResult</returns>
        //ConsumerMobile, BusinessMobile, Portal, APIClient
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_UpdateProfile")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("UpdateProfile")]
        public async Task<ActionResult<ResponseModel<UserSearchResult>>> UpdateProfile([FromBody] UpdateProfileCommand command)
        {
            if (command.UserId <= 0)
            {
                command.UserId = authenticationProvider.GetUserAuthentication().UserId;
            }

            command.Email = command.Email?.Trim();
            command.MobileNumber = command.MobileNumber?.Trim();

            UserSearchResult user = await mediator.Send(command).ConfigureAwait(false);
            return Ok(new ResponseModel<UserSearchResult> { Data = user, Success = user != null });
        }

        /// <summary>
        /// Change User password
        /// </summary>
        /// <param name="model">Object of ChangePassword</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        //ConsumerMobile, BusinessMobile        
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("ChangePassword")]
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_ChangePassword")]
        public async Task<ActionResult<ResponseModel>> ChangePassword([FromBody] ChangePassword model)
        {

            ChangePasswordCommand command = new()
            {
                Password = model.Password,
                NewPassword = model.NewPassword,
                UserId = authenticationProvider.GetUserAuthentication().UserId
            };
            ResponseModel res = await mediator.Send(command).ConfigureAwait(false);
            res.Message = _localizer[res.Message].Value;
            return Ok(res);
        }

        /// <summary>
        /// Returns User's details by user Id
        /// </summary>
        /// <param name="UserId">Varriable of int</param>
        /// <returns>It will return ResponseModel in the form of UserModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_GetUserById")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetUserById")]
        public async Task<ActionResult<ResponseModel<UserModel>>> GetUserById([FromQuery] int UserId)
        {
            UserModel user = await mediator.Send(new GetUserByIdRequest() { UserId = UserId }).ConfigureAwait(false);
            return Ok(new ResponseModel<UserModel> { Data = user, Success = user != null });
        }

        /// <summary>
        /// Returns collection of users details by ids
        /// </summary>
        /// <param name="userIds">Varriable of  Int List</param>
        /// <returns>It will return IEnumerable in the form of UserModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_GetUserList")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetUserList")]
        public async Task<ActionResult<IEnumerable<UserModel>>> GetUserByIds([FromQuery] List<int> userIds)
        {
            return Ok(await mediator.Send(new GetUserByIdsRequest() { UserIds = userIds }).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns Collection of Users Details based on filter
        /// </summary>
        /// <param name="query">Object of GetAllUsersQuery</param>
        /// <returns>It will return PaginatedList in the form of UserModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_GetAllUserWithPaging")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetAllUserWithPaging")]
        public async Task<ActionResult<PaginatedList<UserModel>>> GetAllUserWithPaging([FromQuery] GetAllUsersQuery query)
        {
            return Ok(await mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Return User's Details to sync with other services
        /// </summary>
        /// <param name="UserId">Varriable of int</param>
        /// <returns>It will return ResponseModel in the form of UserModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_SyncUserById")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("SyncUserById")]
        public async Task<ActionResult<ResponseModel<UserModel>>> SyncUserById([FromQuery] int UserId)
        {
            UserModel user = await mediator.Send(new SyncUserByIdRequest() { UserId = UserId }).ConfigureAwait(false);
            return Ok(new ResponseModel<UserModel> { Data = user, Success = user != null });
        }

        /// <summary>
        /// Returns user's Details by email or mobile no.
        /// </summary>
        /// <param name="EmailorPhone">Varriable of string</param>
        /// <returns>It will return ResponseModel in the form of UserModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_GetUserByEmailOrPhone")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetUserByEmailOrPhone")]
        public async Task<ActionResult<ResponseModel<UserModel>>> GetUserByEmailOrPhone([FromQuery] string EmailorPhone)
        {
            UserModel user = await mediator.Send(new GetUserByEmailOrPhoneRequest() { MobileOrEmail = EmailorPhone }).ConfigureAwait(false);
            return Ok(new ResponseModel<UserModel> { Data = user, Success = user != null });
        }

        /// <summary>
        /// Method will return user data by user name.
        /// </summary>
        /// <param name="Name">Varriable of string</param>
        /// <returns>It will return ResponseModel in the form of UserModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_GetUsersByName")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetUsersByName")]
        public async Task<ActionResult<ResponseList<UserModel>>> GetUsersByName([FromQuery] string Name)
        {
            IEnumerable<UserModel> user = await mediator.Send(new GetUsersByNameQuery() { Name = Name }).ConfigureAwait(false);
            return Ok(new ResponseList<UserModel> { Data = user });

        }
        /// <summary>
        /// Method will return user device data by user id.
        /// </summary>
        /// <param name="userId">Varriable of int</param>
        /// <returns>It will return List in the form of UserDeviceModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_devices")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("devices/{userId}")]
        public async Task<ActionResult<List<EventBus.DomainEvents.Models.Identity.UserDeviceModel>>> GetUserDeviceByUserId([FromRoute] int userId)
        {
            return Ok(await mediator.Send(new GetUserDeviceByUserIdRequest() { UserId = userId }).ConfigureAwait(false));
        }

        /// <summary>
        /// Register portal user
        /// </summary>
        /// <param name="model">Object of StoreUserModel</param>
        /// <returns>It will return in the form of StoreUserResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_StoreUserRegister")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("StoreUserRegister")]
        public async Task<ActionResult<StoreUserResponseModel>> StoreUserRegister([FromBody] StoreUserModel model)
        {
            RegisterUserCommand command = mapper.Map<RegisterUserCommand>(model);
            command.UserType = EventBus.DomainEvents.Enums.UserTypeEnum.Store;
            int userid = await mediator.Send(command);

            return userid > 0
                ? (ActionResult<StoreUserResponseModel>)Ok(await mediator.Send(new GetStoreUserResponseByIdRequest { UserId = userid }).ConfigureAwait(false))
                : (ActionResult<StoreUserResponseModel>)BadRequest("Unable to process your request");
        }
        /// <summary>
        /// Assigns claims to a user role
        /// </summary>
        /// <param name="command">object of UpdatePermissionCommand</param>
        /// <returns>It will return in the form of bool</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_MapRoleClaim")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("MapRoleClaim")]
        public async Task<ActionResult<bool>> MapRoleClaim([FromBody] UpdatePermissionCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Updates consumer profile from web portal
        /// </summary>
        /// <param name="command">Object of UpdateProfileUsingPortalCommand</param>
        /// <returns>It will return ResponseModel in the form of UserSearchResult</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_UpdateProfileUsingPortal")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("UpdateProfileUsingPortal")]
        public async Task<ActionResult<ResponseModel<UserSearchResult>>> UpdateProfileUsingPortal([FromBody] UpdateProfileUsingPortalCommand command)
        {
            if (command.UserId <= 0)
            {
                command.UserId = authenticationProvider.GetUserAuthentication().UserId;
            }

            command.Email = command.Email?.Trim();
            command.MobileNumber = command.MobileNumber?.Trim();

            UserSearchResult user = await mediator.Send(command).ConfigureAwait(false);
            return Ok(new ResponseModel<UserSearchResult> { Data = user, Success = user != null });
        }

        /// <summary>
        /// Returns Collection of user roles
        /// </summary>
        /// <param></param>
        /// <returns>It will return IEnumerable in the form of RoleModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_Roles")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("Roles")]
        public async Task<ActionResult<IEnumerable<RoleModel>>> Roles()
        {
            return Ok(await mediator.Send(new GetRolesRequest()).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns role details with its claims by role id
        /// </summary>
        /// <param name="RoleId">Varriable of string</param>
        /// <returns>It will return in the form of RoleModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUser_GetRoleById")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetRoleById/{RoleId}")]
        public async Task<ActionResult<RoleModel>> GetRoleById(string RoleId)
        {
            return Ok(await mediator.Send(new GetRoleByIdRequest() { RoleId = RoleId }).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns Collection of type of User roles
        /// </summary>
        /// <param></param>
        /// <returns>It will return ResponseList in the form of RoleTypeModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUser_RoleType")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("RoleType")]
        public async Task<ActionResult<ResponseList<RoleTypeModel>>> RoleType()
        {
            return Ok(await mediator.Send(new GetRoleTypeRequest()).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns Collection of claims
        /// </summary>
        /// <param></param>
        /// <returns>It will return IEnumerable in the form of ClaimModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUser_Claims")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("Claims")]
        public async Task<ActionResult<IEnumerable<ClaimModel>>> Claims()
        {
            return Ok(await mediator.Send(new GetClaimsRequest()));
        }

        /// <summary>
        /// Updates user device information if user logged in with new device
        /// </summary>
        /// <param name="command">Object of UpdateUserDeviceByUserIdCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUser_UpdateUserDevice")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("UpdateUserDevice")]
        public async Task<ActionResult<ResponseModel>> UpdateUserDevice([FromBody] UpdateUserDeviceByUserIdCommand command)
        {
            command.UserId = authenticationProvider.GetUserAuthentication().UserId;
            ResponseModel res = await mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// Updates consumer to a business user
        /// </summary>
        /// <param name="command">Object of UpdateConsumerToBusinessCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUser_UpdateConsumerToBusiness")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("UpdateConsumerToBusiness")]
        public async Task<ActionResult<ResponseModel>> UpdateConsumerToBusiness([FromBody] UpdateConsumerToBusinessCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }
        /// <summary>
        /// Returns details of consumer case from sales force
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>

        /// <summary>
        /// Returns details of consumer case from sales force
        /// </summary>
        /// <returns>It will return in the form of SalesForceCaseModels</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUser_ConsumerCase")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("ConsumerCase")]
        public async Task<ActionResult<SalesForceCaseModels>> GetConsumerCase([FromQuery] GetSalesforceCaseQuery query)
        {
            return Ok(await mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to create case on salesforce
        /// </summary>
        /// <param name="command">Object of CreateConsumerCaseCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_CreateConsumerCase")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("CreateConsumerCase")]
        public async Task<ActionResult<ResponseModel>> CreateConsumerCase([FromBody] CreateConsumerCaseCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns details of merchant case register on salesforce
        /// </summary>
        /// <param name="query">Object of GetSalesforceCaseMarchentQuery</param>
        /// <returns>It will return in the form of SalesForceCaseModels</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_MerchantCase")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("MerchantCase")]
        public async Task<ActionResult<SalesForceCaseModels>> GetMerchantCase([FromQuery] GetSalesforceCaseMarchentQuery query)
        {
            return Ok(await mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to generate mobile verification code while updating mobile number
        /// </summary>
        /// <param name="model">Object of GenerateMobileUpdateVerificationModel</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_GenerateMobileUpdateVerificationCode")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("GenerateMobileUpdateVerificationCode")]
        public async Task<ActionResult<ResponseModel>> GenerateMobileUpdateVerificationCode([FromBody] GenerateMobileUpdateVerificationModel model)
        {
            int userId = authenticationProvider.GetUserAuthentication().UserId;

            ResponseModel res = await mediator.Send(new GenerateMobileUpdateVerificationCodeCommand() { UserId = userId, MobileCountryCode = model?.MobileCountryCode, MobileNumber = model?.MobileNumber }).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// Api to verify code and update mobile number
        /// </summary>
        /// <param name="model">object of UpdateMobileModel</param>
        /// <returns>It will return ResponseModel in the form of int</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_UpdateMobileNumber")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("UpdateMobileNumber")]
        public async Task<ActionResult<ResponseModel<int>>> UpdateMobileNumber([FromBody] UpdateMobileModel model)
        {
            int userId = authenticationProvider.GetUserAuthentication().UserId;

            ResponseModel res = await mediator.Send(new UpdateMobileNumberCommand() { UserId = userId, MobileCountryCode = model?.MobileCountryCode, MobileNumber = model?.MobileNumber, VerificationCode = model?.VerificationCode }).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// Api to remove user account 
        /// </summary>
        /// <param name="model">Object of DeleteUserModel</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_RemoveAccount")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("RemoveAccount")]
        public async Task<ActionResult<ResponseModel>> RemoveAccount([FromBody] DeleteUserModel model)
        {
            int UserId = authenticationProvider.GetUserAuthentication().UserId;

            ResponseModel res = await mediator.Send(new DeleteUserCommand() { UserId = model?.UserId ?? 0, TokenUserId = UserId, ReasonforDeletion = model?.ReasonforDeletion }).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// Api to copy claims of any user role to another user role
        /// </summary>
        /// <param name="command">Object of CopyClaimsCommand</param>
        /// <returns>It will return in the form of bool</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_CopyRoleClaim")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("CopyRoleClaim")]
        public async Task<ActionResult<bool>> CopyRoleClaim([FromBody] CopyClaimsCommand command)
        {
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to update user preferred language to use app 
        /// </summary>
        /// <param name="model">Object of PreferredLanguageModel</param>
        /// <returns>It will return ResponseModel in the form of int</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_UpdatePreferredLanguage")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("UpdatePreferredLanguage")]
        public async Task<ActionResult<ResponseModel<int>>> UpdatePreferredLanguage([FromBody] PreferredLanguageModel model)
        {

            UpdatePreferredLanguageCommand command = new()
            {
                PreferredLanguage = model.PreferredLanguage,
                UserId = authenticationProvider.GetUserAuthentication().UserId
            };

            ResponseModel<int> res = await mediator.Send(command).ConfigureAwait(false);
            return Ok(res);
        }

        /// <summary>
        /// Returns List of active users on portal
        /// </summary>
        /// <param name="query">Object of GetActiveUsersRequest</param>
        /// <returns>It will return PaginatedList in the form of ActiveUsersSearchResult</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_ActivePortalUsers")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("ActivePortalUsers")]
        public async Task<ActionResult<PaginatedList<ActiveUsersSearchResult>>> GetActivePortalUsers([FromQuery] GetActiveUsersRequest query)
        {
            return Ok(await mediator.Send(query).ConfigureAwait(false));
        }

        /// <summary>
        /// Api to unlock locked users account using portal
        /// </summary>
        /// <param name="command">Object of UnlockUserByUserIdCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("UnlockUserFromPortal")]
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_UnlockUserFromPortal")]
        public async Task<ActionResult<ResponseModel>> UnlockUser([FromBody] UnlockUserByUserIdCommand command)
        {
            ResponseModel res = await mediator.Send(command).ConfigureAwait(false);
            return Ok(res);
        }
        /// <summary>
        /// Sends a link on user's email to unlock user account
        /// </summary>
        /// <param name="verificationCode">Varriable of string</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        //On Email Link click
        [AllowAnonymous]
        [HttpGet("UnlockUser/{verificationCode}")]
        public async Task<ActionResult<ResponseModel>> UnlockUser([FromRoute] string verificationCode)
        {

            ResponseModel res = await mediator.Send(new UnlockUserByUserIdCommand { UserUnlockCode = verificationCode }).ConfigureAwait(false);
            UnlockUserModel vm = new() { IsUnlocked = res.Success };
            return View(vm);
        }
        /// <summary>
        /// Returns List of users based on a role id
        /// </summary>
        /// <param name="roleId">Object of string</param>
        /// <returns>It will return IEnumerable in the form of UserModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_GetUsersByRole")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetUsersByRole")]
        public async Task<ActionResult<IEnumerable<UserModel>>> GetUserByRole([FromQuery] string roleId)
        {
            return Ok(await mediator.Send(new GetUserByRoleRequest() { RoleId = roleId }).ConfigureAwait(false));
        }

        /// <summary>
        /// GetUserList By from start Date and end date
        /// </summary>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_GetUserByDate")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetUserByDate")]
        public async Task<ActionResult<IEnumerable<UserModel>>> GetUserListByDate([FromQuery] DateTime? StartDate, DateTime? EndDate)
        {
            return Ok(await mediator.Send(new GetUserByDateRequest(){ StartDate = StartDate, EndDate = EndDate }).ConfigureAwait(false));
        }

        /// <summary>
        /// Get last seven days user list by date
        /// </summary>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_GetLast7daysUser")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetLast7daysUser")]
        public async Task<ActionResult<IEnumerable<UserModel>>> GetLast7daysUserListByDate([FromQuery] DateTime? StartDate, DateTime? EndDate)
        {
            return Ok(await mediator.Send(new GetUserByDateRequest() { StartDate = StartDate, EndDate = EndDate }).ConfigureAwait(false));
        }

        /// <summary>
        /// Get User which have No PaymentMethod
        /// </summary>
        /// <param name="userIds"></param>
        /// <returns></returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_GetUserWithNoPaymentMethod")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetUserWithNoPaymentMethod")]
        public async Task<ActionResult<IEnumerable<User>>> GetUserWithNoPaymentMethod([FromQuery] List<int> userIds)
        {
            return Ok(await mediator.Send(new GetUserWithNoPaymentMethodRequest() { UserIds=userIds}).ConfigureAwait(false));
        }

        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("ResetUnregisteredConsumerPassword")]
        public async Task<ActionResult<ResponseModel>> ResetUnregisteredConsumerPassword([FromBody] ResetUnregisteredConsumerPasswordCommand command)
        {

            ResponseModel res = await mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_GetUserListForProfile")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("GetUserListForProfile")]
        public async Task<ActionResult<IEnumerable<UserModel>>> GetUserListForProfile([FromBody] List<int> userIds)
        {
            return Ok(await mediator.Send(new GetUserByIdsRequest() { UserIds = userIds }).ConfigureAwait(false));
        }

        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_AccountUsers_GetAllUserWithMOP")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetAllUserWithMOP")]
        public async Task<ActionResult<PaginatedList<UserMOPModel>>> GetAllUserWithMOP([FromQuery] GetAllUserMopQuery query)
        {
            return Ok(await mediator.Send(query).ConfigureAwait(false));
        }
        /// <summary>
        ///  Method will return the list of tenant master 
        /// </summary>
        /// <param></param>
        /// <returns>It will return list in the form of TenantMasterModel</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetTenantMaster")]
        public async Task<ActionResult<IEnumerable<TenantMasterModel>>> GetTenantMaster()
        {
            return Ok(await mediator.Send(new GetTenantMasterRequest()).ConfigureAwait(false));
        }
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetAllUser")]
        public async Task<ActionResult<PaginatedList<UserConsumerModel>>> GetAllUser([FromQuery] GetAllConsumerQuery query)
        {
            return Ok(await mediator.Send(query).ConfigureAwait(false));
        }
        /// <summary>
        ///  Method will return the list of tenant master 
        /// </summary>
        /// <param></param>
        /// <returns>It will return list in the form of TenantMasterResponse</returns>
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetTenantMasterList")]
        [AllowAnonymous]
        public async Task<ActionResult<List<TenantMasterResponse>>> GetTenantMasterList()
        {
            return Ok(await mediator.Send(new GetTenantMasterListRequest()).ConfigureAwait(false));
        }
        [AllowAnonymous]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("GetUserTeanantById")]
        public async Task<ActionResult<ResponseModel<UserTenantModel>>> GetUserTeanantId([FromQuery] int UserId)
        {
            UserTenantModel user = await mediator.Send(new GetUserTenantRequest() { UserId = UserId }).ConfigureAwait(false);
            return Ok(new ResponseModel<UserTenantModel> { Data = user, Success = user != null });
        }
    }
}
