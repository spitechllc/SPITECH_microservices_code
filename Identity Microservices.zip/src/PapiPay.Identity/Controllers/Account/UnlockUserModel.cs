namespace PapiPay.Identity.Controllers
{
    public class UnlockUserModel
    {
        public bool IsUnlocked { get; set; }
    }
}