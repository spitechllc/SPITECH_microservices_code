namespace PapiPay.Identity.Controllers
{
    public class ForgotPasswordInputModel
    {
        public string Username { get; set; }
        public string VerificationCode { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
        public string ReturnUrl { get; set; }
        public bool IsVerificationCodeSent { get; set; }
    }
}