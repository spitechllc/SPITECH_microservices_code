using IdentityModel;
using IdentityServer4;
using IdentityServer4.Events;
using IdentityServer4.Extensions;
using IdentityServer4.Models;
using IdentityServer4.Services;
using IdentityServer4.Stores;
using MediatR;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.EventBus.DomainEvents;
using PapiPay.EventBus.DomainEvents.Enums;
using PapiPay.EventBus.DomainEvents.Events.Identity;
using PapiPay.EventBus.DomainEvents.Events.Notification;
using PapiPay.Identity.Application.Commands.CreateUserLoginLog;
using PapiPay.Identity.Application.Commands.GenerateStoreUserPasswordResetCode;
using PapiPay.Identity.Application.Commands.ResetStoreUserPassword;
using PapiPay.Identity.Application.Queries.GetAPIResourcePermissions;
using PapiPay.Identity.Application.Queries.GetUser;
using PapiPay.Identity.Application.Queries.GetUserByNameForLog;
using PapiPay.Identity.Application.Validators;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PapiPay.Identity.Controllers
{

    [SecurityHeaders]
    [AllowAnonymous]
    public class AccountController : Controller
    {
        private readonly IIdentityServerInteractionService _interaction;
        private readonly IClientStore _clientStore;
        private readonly IAuthenticationSchemeProvider _schemeProvider;
        private readonly IEventService _events;
        private readonly IMediator mediator;
        private readonly ILogger<AccountController> _logger;
        private readonly IEventDispatcher eventDispatcher;
        private readonly IStringLocalizer<AccountController> _localizer;
        private readonly IUserAuthenticationProvider _authenticationProvider;

        public AccountController(
            IIdentityServerInteractionService interaction,
            IClientStore clientStore,
            IAuthenticationSchemeProvider schemeProvider,
            IEventService events,
            IMediator mediator, ILogger<AccountController> logger,
            IEventDispatcher eventDispatcher,
            IStringLocalizer<AccountController> localizer,
            IUserAuthenticationProvider authenticationProvider)
        {
            _interaction = interaction;
            _clientStore = clientStore;
            _schemeProvider = schemeProvider;
            _events = events;
            this.mediator = mediator;
            _logger = logger;
            this.eventDispatcher = eventDispatcher;
            _localizer = localizer;
            _authenticationProvider = authenticationProvider;
        }

        /// <summary>
        /// Entry point into the login workflow
        /// </summary>
        /// <param name="returnUrl">Varriable of string</param>
        /// <return>It will return in the form of LoginViewModel</return>
        [HttpGet]
        public async Task<IActionResult> Login(string returnUrl)
        {
            _logger.TraceEnterMethod(nameof(Login), returnUrl);
            // build a model so we know what to show on the login page
            LoginViewModel vm = await BuildLoginViewModelAsync(returnUrl);

            if (vm.IsExternalLoginOnly)
            {
                // we only have one option for logging in and it's an external provider
                return RedirectToAction("Challenge", "External", new { scheme = vm.ExternalLoginScheme, returnUrl });
            }
            _logger.TraceExitMethod(nameof(Login), vm);
            return View(vm);
        }

        /// <summary>
        /// Handle postback from username/password login
        /// </summary>
        /// <param name="model">Object of LoginInputModel</param>
        /// <param name="button">Varriable of string</param>
        /// <return>It will return in the form of LoginViewModel</return>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginInputModel model, string button)
        {
            _logger.TraceEnterMethod(nameof(Login), model, button);
            // check if we are in the context of an authorization request
            AuthorizationRequest context = await _interaction.GetAuthorizationContextAsync(model.ReturnUrl);

            // the user clicked the "cancel" button
            if (button != "login")
            {
                if (context != null)
                {
                    // if the user cancels, send a result back into IdentityServer as if they 
                    // denied the consent (even if this client does not require consent).
                    // this will send back an access denied OIDC error response to the client.
                    await _interaction.DenyAuthorizationAsync(context, AuthorizationError.AccessDenied);

                    // we can trust model.ReturnUrl since GetAuthorizationContextAsync returned non-null
                    if (context.IsNativeClient())
                    {
                        // The client is native, so this change in how to
                        // return the response is for better UX for the end user.
                        _logger.TraceExitMethod(nameof(Login), model, button);
                        return this.LoadingPage("Redirect", model.ReturnUrl);
                    }
                    _logger.TraceExitMethod(nameof(Login), model, button);
                    return Redirect(model.ReturnUrl);
                }
                else
                {
                    // since we don't have a valid context, then we just go back to the home page
                    _logger.TraceExitMethod(nameof(Login), model, button);
                    return Redirect("~/");
                }
            }

            if (ModelState.IsValid)
            {
                _logger.Trace("User Info", model);

                GetUserRequest loginRequest = new()
                {
                    UserName = model.Username,
                    Password = model.Password,
                    ClientId = context?.Client.ClientId,
                    UserTypeId = (int)EventBus.DomainEvents.Enums.UserTypeEnum.Store,
                    TenantName= model.TenantName,
                };

                _logger.Warn($"UserInfo Tenant: {model.TenantName}");
                _logger.Warn($"UserInfo 4: {model.Username + model.Password}");

                if (context?.Client.ClientId.Contains("testportal") ?? false)
                {
                    loginRequest.UserTypeId = (int)EventBus.DomainEvents.Enums.UserTypeEnum.Consumer;
                }

                ApplicationCore.Domain.Models.ResponseModel<Domain.Models.UserModel> userResponse = await mediator.Send(loginRequest);
                string errorMessage = string.Empty;
                if (userResponse != null && userResponse.Success && userResponse.Data.Lockout == false)
                {
                   
                    await mediator.Send(new CreateUserLoginLogCommand
                    {
                        UserId = userResponse.Data.UserId,
                        InvalidLogin = false
                    });

                    _logger.Warn($"UserInfo 2: {userResponse.Data.UserName + userResponse.Data.SubjectId + userResponse.Data.DisplayName}");


                    await _events.RaiseAsync(new UserLoginSuccessEvent(userResponse.Data.UserName,
                        userResponse.Data.SubjectId,
                        userResponse.Data.DisplayName,
                        clientId: context?.Client.ClientId));

                    // only set explicit expiration here if user chooses "remember me". 
                    // otherwise we rely upon expiration configured in cookie middleware.
                    AuthenticationProperties props = null;
                    if (AccountOptions.AllowRememberLogin && model.RememberLogin)
                    {
                        _logger.Trace("Remember login", model);
                        props = new AuthenticationProperties
                        {
                            IsPersistent = true,
                            ExpiresUtc = DateTimeOffset.UtcNow.Add(AccountOptions.RememberMeLoginDuration)
                        };
                    };

                    IEnumerable<string> apiResourcePermissions = new List<string>();

                    if (userResponse.Data.Roles != null && userResponse.Data.Roles.Any())
                    {
                        apiResourcePermissions = await mediator.Send(new APIResourcePermissionsRequest { RoleIds = userResponse.Data.Roles.Select(t => t.RoleId).ToList() });
                    }
                    else
                    {
                        apiResourcePermissions = await mediator.Send(new APIResourcePermissionsRequest { ClientId = context?.Client?.ClientId });
                    }

                    // issue authentication cookie with subject ID and username
                    IdentityServerUser isuser = new(userResponse.Data.SubjectId)
                    {
                        DisplayName = userResponse.Data.DisplayName,
                        AdditionalClaims = ResourceOwnerPasswordValidator.GetUserClaims(userResponse.Data, apiResourcePermissions),
                        AuthenticationTime = DateTime.Now,
                    };

                    await HttpContext.SignInAsync(isuser, null);
                    _logger.Warn($"UserInfo 3: {userResponse.Data.UserId}");
                    
                    await DispatchActivityLogEvent(userResponse.Data.UserId, (int)ActivityType.Login, "Login");
                    if (context != null)
                    {
                        _logger.Warn($"UserInfo 4: {"DispatchSignInEvent"}");

                        if (context.IsNativeClient())
                        {
                            await DispatchSignInEvent(userResponse.Data.UserId);
                            // The client is native, so this change in how to
                            // return the response is for better UX for the end user.
                            _logger.TraceExitMethod(nameof(Login), model);
                            return this.LoadingPage("Redirect", model.ReturnUrl);
                        }

                        // we can trust model.ReturnUrl since GetAuthorizationContextAsync returned non-null
                        _logger.TraceExitMethod(nameof(Login), model);
                        return Redirect(model.ReturnUrl);
                    }

                    // request for a local page
                    if (Url.IsLocalUrl(model.ReturnUrl))
                    {
                        _logger.TraceExitMethod(nameof(Login), model);
                        return Redirect(model.ReturnUrl);
                    }
                    else if (string.IsNullOrEmpty(model.ReturnUrl))
                    {
                        _logger.TraceExitMethod(nameof(Login), model);
                        return Redirect("~/");
                    }
                    else
                    {
                        // user might have clicked on a malicious link - should be logged
                        _logger.Trace("invalid return URL");
                        throw new Exception("invalid return URL");
                    }
                }
                else if (userResponse != null && userResponse.Success && userResponse.Data.Lockout)
                {
                    errorMessage = _localizer[userResponse?.Message ?? "Your account is locked for 24 hours."].Value;
                }
                else
                {
                    errorMessage = _localizer[userResponse?.Message ?? "Invalid credential"].Value;

                    _logger.Warn("UserInfo 5: ", errorMessage);

                    if (string.IsNullOrWhiteSpace(errorMessage))
                    {
                        errorMessage = userResponse.Message;
                    }
                    GetUserByNameForLogRequest loginLog = new()
                    {
                        UserName = model.Username
                    };
                    ApplicationCore.Domain.Models.ResponseModel<Domain.Models.UserModel> userByNameModel = await mediator.Send(loginLog);
                    if (userByNameModel != null && userByNameModel.Success)
                    {
                        if (userByNameModel.Data != null)
                        {
                            if (userByNameModel.Data.UserId > 0)
                            {
                                var UserloginLog = await mediator.Send(new CreateUserLoginLogCommand
                                {
                                    UserId = userByNameModel.Data.UserId,
                                    InvalidLogin = true
                                });
                                if (!UserloginLog.Success)
                                {
                                    userResponse.Message = UserloginLog.Message;
                                }

                            }
                        }
                    }

                }
                await _events.RaiseAsync(new UserLoginFailureEvent(model.Username, errorMessage, clientId: context?.Client.ClientId));
                ModelState.AddModelError(string.Empty, userResponse?.Message ?? AccountOptions.InvalidCredentialsErrorMessage);
            }

            // something went wrong, show form with error
            LoginViewModel vm = await BuildLoginViewModelAsync(model);
            _logger.TraceExitMethod(nameof(Login), vm);
            return View(vm);
        }


        /// <summary>
        /// Show logout page
        /// </summary>
        /// <param name="logoutId">Varriable of string</param>
        /// <returns>It will return in the form of LogoutViewModel</returns>
        [HttpGet]
        public async Task<IActionResult> Logout(string logoutId)
        {
            // build a model so the logout page knows what to display
            LogoutViewModel vm = await BuildLogoutViewModelAsync(logoutId);

            if (vm.ShowLogoutPrompt == false)
            {
                // if the request for logout was properly authenticated from IdentityServer, then
                // we don't need to show the prompt and can just log the user out directly.
                return await Logout(vm);
            }

            return View(vm);
        }

        /// <summary>
        /// Handle logout page postback
        /// </summary>
        /// <param name="model">Object of LogoutInputModel</param>
        /// <returns>It will return in the form of LoggedOutViewModel</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout(LogoutInputModel model)
        {
            _logger.TraceEnterMethod("Logout", model);
            _logger.Warn("LogoutFromSystem", model);
          
            // build a model so the logged out page knows what to display
            LoggedOutViewModel vm = await BuildLoggedOutViewModelAsync(model.LogoutId);

            if (User?.Identity.IsAuthenticated == true)
            {
                _logger.Trace("IsAuthenticatedTrue");
                // delete local authentication cookie
                await HttpContext.SignOutAsync();

                // raise the logout event
                await _events.RaiseAsync(new UserLogoutSuccessEvent(User.GetSubjectId(), User.GetDisplayName()));

            }

            // check if we need to trigger sign-out at an upstream identity provider
            if (vm.TriggerExternalSignout)
            {
                _logger.Trace("IsTriggerExternalSignout");
                // build a return URL so the upstream provider will redirect back
                // to us after the user has logged out. this allows us to then
                // complete our single sign-out processing.
                string url = Url.Action("Logout", new { logoutId = vm.LogoutId });

                // this triggers a redirect to the external provider for sign-out
                return SignOut(new AuthenticationProperties { RedirectUri = url }, vm.ExternalAuthenticationScheme);
            }

            _logger.TraceExitMethod("Logout", vm);            
            return View("LoggedOut", vm);
        }
        /// <summary>
        /// Method will return the Access Denied
        /// </summary>
        /// <param></param>
        /// <returns>It will return to the view</returns>
        [HttpGet]
        public IActionResult AccessDenied()
        {
            return View();
        }


        /*****************************************/
        /* helper APIs for the AccountController */
        /*****************************************/
        private async Task<LoginViewModel> BuildLoginViewModelAsync(string returnUrl)
        {
            AuthorizationRequest context = await _interaction.GetAuthorizationContextAsync(returnUrl);
            if (context?.IdP != null && await _schemeProvider.GetSchemeAsync(context.IdP) != null)
            {
                bool local = context.IdP == IdentityServerConstants.LocalIdentityProvider;

                // this is meant to short circuit the UI and only trigger the one external IdP
                LoginViewModel vm = new()
                {
                    EnableLocalLogin = local,
                    ReturnUrl = returnUrl,
                    Username = context?.LoginHint,
                    nativeclient = (bool)(context?.IsNativeClient()),
                };

                if (!local)
                {
                    vm.ExternalProviders = new[] { new ExternalProvider { AuthenticationScheme = context.IdP } };
                }

                return vm;
            }

            System.Collections.Generic.IEnumerable<AuthenticationScheme> schemes = await _schemeProvider.GetAllSchemesAsync();

            System.Collections.Generic.List<ExternalProvider> providers = schemes
                .Where(x => x.DisplayName != null)
                .Select(x => new ExternalProvider
                {
                    DisplayName = x.DisplayName ?? x.Name,
                    AuthenticationScheme = x.Name
                }).ToList();

            bool allowLocal = true;
            if (context?.Client.ClientId != null)
            {
                Client client = await _clientStore.FindEnabledClientByIdAsync(context.Client.ClientId);
                if (client != null)
                {
                    allowLocal = client.EnableLocalLogin;

                    if (client.IdentityProviderRestrictions != null && client.IdentityProviderRestrictions.Any())
                    {
                        providers = providers.Where(provider => client.IdentityProviderRestrictions.Contains(provider.AuthenticationScheme)).ToList();
                    }
                }
            }

            return new LoginViewModel
            {
                AllowRememberLogin = AccountOptions.AllowRememberLogin,
                EnableLocalLogin = allowLocal && AccountOptions.AllowLocalLogin,
                ReturnUrl = returnUrl,
                Username = context?.LoginHint,
                ExternalProviders = providers.ToArray(),
                nativeclient = (bool)(context?.IsNativeClient())
            };
        }

        private async Task<LoginViewModel> BuildLoginViewModelAsync(LoginInputModel model)
        {
            LoginViewModel vm = await BuildLoginViewModelAsync(model.ReturnUrl);
            vm.Username = model.Username;
            vm.RememberLogin = model.RememberLogin;
            return vm;
        }
        /// <summary>
        /// Assign values to logout model based on user authentication
        /// </summary>
        /// <param name="logoutId">Varriable of string</param>
        /// <returns>It will return in the form of LogoutViewModel</returns>

        private async Task<LogoutViewModel> BuildLogoutViewModelAsync(string logoutId)
        {
            LogoutViewModel vm = new() { LogoutId = logoutId, ShowLogoutPrompt = AccountOptions.ShowLogoutPrompt };

            if (User?.Identity.IsAuthenticated != true)
            {
                // if the user is not authenticated, then just show logged out page
                vm.ShowLogoutPrompt = false;
                return vm;
            }

            LogoutRequest context = await _interaction.GetLogoutContextAsync(logoutId);
            if (context?.ShowSignoutPrompt == false)
            {
                // it's safe to automatically sign-out
                vm.ShowLogoutPrompt = false;
                return vm;
            }

            // show the logout prompt. this prevents attacks where the user
            // is automatically signed out by another malicious web page.
            return vm;
        }

        /// <summary>
        /// assign values to logout model
        /// </summary>
        /// <param name="logoutId">Varriable of string</param>
        /// <returns>It will return in the form of LoggedOutViewModel</returns>
        private async Task<LoggedOutViewModel> BuildLoggedOutViewModelAsync(string logoutId)
        {
            // get context information (client name, post logout redirect URI and iframe for federated signout)
            LogoutRequest logout = await _interaction.GetLogoutContextAsync(logoutId);
            _logger.Trace("BuildLoggedOutViewModelAsync", logout);

            if (string.IsNullOrWhiteSpace(logout.PostLogoutRedirectUri))
            {
                Client client = await _clientStore.FindClientByIdAsync(logout.ClientId);

                if (client != null)
                {
                    logout.PostLogoutRedirectUri = client.PostLogoutRedirectUris.FirstOrDefault();
                }
                _logger.Trace("BuildLoggedOutViewModelAsync with PostLogoutRedirectUri", logout);
            }

            LoggedOutViewModel vm = new()
            {
                AutomaticRedirectAfterSignOut = AccountOptions.AutomaticRedirectAfterSignOut,
                PostLogoutRedirectUri = logout?.PostLogoutRedirectUri,
                ClientName = string.IsNullOrEmpty(logout?.ClientName) ? logout?.ClientId : logout?.ClientName,
                SignOutIframeUrl = logout?.SignOutIFrameUrl,
                LogoutId = logoutId
            };

            if (User?.Identity.IsAuthenticated == true)
            {
                string idp = User.FindFirst(JwtClaimTypes.IdentityProvider)?.Value;
                if (idp != null && idp != IdentityServerConstants.LocalIdentityProvider)
                {
                    bool providerSupportsSignout = await HttpContext.GetSchemeSupportsSignOutAsync(idp);
                    if (providerSupportsSignout)
                    {
                        if (vm.LogoutId == null)
                        {
                            // if there's no current logout context, we need to create one
                            // this captures necessary info from the current logged in user
                            // before we signout and redirect away to the external IdP for signout
                            vm.LogoutId = await _interaction.CreateLogoutContextAsync();
                        }

                        vm.ExternalAuthenticationScheme = idp;
                    }
                }
            }
            _logger.TraceExitMethod("BuildLoggedOutViewModelAsync", vm);
            return vm;
        }

        /// <summary>
        /// Show  registration page to user if user don't have an account with papipay
        /// </summary>
        /// <param name="returnurl">Varriable of string</param>
        /// <returns>It will return the URL</returns>
        [HttpGet]
        public async Task<IActionResult> DontHaveAccount(string returnurl)
        {
            _logger.TraceEnterMethod(nameof(DontHaveAccount), returnurl);
            try
            {
                returnurl = returnurl.Replace("papipay_mobile", "papipay_mobile&DontHaveAccount=true");
                returnurl = returnurl.Replace("state=", "state=DontHaveAccount-");
                AuthorizationRequest context = await _interaction.GetAuthorizationContextAsync(returnurl);

                if (context != null)
                {
                    await _interaction.DenyAuthorizationAsync(context, AuthorizationError.AccessDenied);

                    if (context.IsNativeClient())
                    {
                        _logger.TraceExitMethod(nameof(DontHaveAccount), context.RedirectUri, returnurl);
                        return this.LoadingPage("Redirect", returnurl);
                    }
                }

                _logger.TraceExitMethod(nameof(DontHaveAccount), "Context is Null", returnurl);
                return Redirect(returnurl);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }
        /// <summary>
        /// Show forgot password page
        /// </summary>
        /// <param name="returnurl">Object of string</param>
        /// <returns>It will return in the form of ForgotPasswordInputModel and redirect the url</returns>
        [HttpGet]
        public async Task<IActionResult> ForgotPassword(string returnurl)
        {
            _logger.TraceEnterMethod(nameof(ForgotPassword), returnurl);

            try
            {
                if (returnurl.Contains("papipay_mobile"))
                {
                    returnurl = returnurl.Replace("papipay_mobile", "papipay_mobile&ForgotPassword=true");
                    returnurl = returnurl.Replace("state=", "state=ForgotPassword-");
                }

                AuthorizationRequest context = await _interaction.GetAuthorizationContextAsync(returnurl);

                if (context != null)
                {
                    await _interaction.DenyAuthorizationAsync(context, AuthorizationError.AccessDenied);

                    if (context.IsNativeClient())
                    {

                        _logger.TraceExitMethod(nameof(ForgotPassword), context.RedirectUri, returnurl);
                        return this.LoadingPage("Redirect", returnurl);
                    }
                    else
                    {
                        ForgotPasswordInputModel vm = new() { ReturnUrl = returnurl };
                        return View(vm);
                    }
                }

                _logger.TraceExitMethod(nameof(ForgotPassword), "Context is Null", returnurl);
                return Redirect(returnurl);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// Handle forgot password page postback
        /// </summary>
        /// <param name="model">Object of ForgotPasswordInputModel</param>
        /// <returns>It will return in the form of ForgotPasswordInputModel</returns>
        [HttpPost]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordInputModel model)
        {
            _logger.TraceEnterMethod(nameof(ForgotPassword), model);

            if (!model.IsVerificationCodeSent)
            {
                if (string.IsNullOrEmpty(model.Username))
                {
                    ModelState.AddModelError(string.Empty, _localizer["Please Enter Username"].Value);
                }

                if (ModelState.ErrorCount > 0)
                {
                    return View(model);
                }

                GenerateStoreUserPasswordResetCodeCommand command = new()
                {
                    UserName = model.Username
                };
                ApplicationCore.Domain.Models.ResponseModel response = await mediator.Send(command);

                if (!response.Success)
                {
                    ModelState.AddModelError(string.Empty, _localizer[!string.IsNullOrWhiteSpace(response.Message) ? response.Message : "Fail"].Value);
                    return View(model);
                }

                model.IsVerificationCodeSent = true;

                _logger.TraceExitMethod("GenerateCode", model);
                return View(model);
            }

            if (model.IsVerificationCodeSent)
            {
                if (string.IsNullOrEmpty(model.Password))
                {
                    ModelState.AddModelError(string.Empty, _localizer["Please Enter Password"].Value);
                }

                if (!string.IsNullOrEmpty(model.Password))
                {
                    Regex regex = new(@"(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}");
                    Match match = regex.Match(model.Password);
                    if (!match.Success)
                    {
                        ModelState.AddModelError(string.Empty, _localizer["The Password should atleast 8 charecters with atleast  one upper case, one lower case and one numeric and one special charecter."].Value);
                    }
                }

                if (string.IsNullOrEmpty(model.ConfirmPassword))
                {
                    ModelState.AddModelError(string.Empty, _localizer["Please Enter Confirm Password"].Value);
                }

                if (string.IsNullOrEmpty(model.VerificationCode))
                {
                    ModelState.AddModelError(string.Empty, _localizer["Please Enter Verification Code"].Value);
                }

                if (model.Password != model.ConfirmPassword)
                {
                    ModelState.AddModelError(string.Empty, _localizer["Password and Confirm Password does not match"].Value);
                }

                if (ModelState.ErrorCount > 0)
                {
                    model.IsVerificationCodeSent = true;
                    return View(model);
                }

                ResetStoreUserPasswordCommand command = new()
                {
                    VerificationCode = model.VerificationCode,
                    Password = model.Password,
                    UserName = model.Username
                };
                ApplicationCore.Domain.Models.ResponseModel response = await mediator.Send(command);

                if (!response.Success)
                {
                    ModelState.AddModelError(string.Empty, _localizer[!string.IsNullOrWhiteSpace(response.Message) ? response.Message : "Success"].Value);
                    model.IsVerificationCodeSent = false;
                    return View(model);
                }

                _logger.TraceExitMethod("ResetPassword", model);

                return RedirectToAction("Login", "Account", new { returnUrl = model.ReturnUrl });
            }

            _logger.TraceExitMethod(nameof(ForgotPassword), model);
            return View(model);
        }

        /// <summary>
        /// Notify user sign in 
        /// </summary>
        /// <param name="userid"></param>
        /// <returns></returns>
        private Task DispatchSignInEvent(int userid)
        {
            return eventDispatcher.Dispatch(new IdentityUserSignInEvent
            {
                UserId = userid,
                LoginTime = DateTime.UtcNow
            });
        }
        /// <summary>
        /// Log User Activity
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="activityTypeId"></param>
        /// <param name="activityRecordkey"></param>
        /// <returns></returns>
        private Task DispatchActivityLogEvent(int userId, int activityTypeId, string activityRecordkey)
        {
            return eventDispatcher.Dispatch(new UserActivityLogEvent
            {
                ActivityTypeId = activityTypeId,
                UserId = userId,
                ActivityRecordKeyId = activityRecordkey,
                ActivityTime = DateTime.UtcNow,
                ActivityIP = ""
            });
        }
    }
}