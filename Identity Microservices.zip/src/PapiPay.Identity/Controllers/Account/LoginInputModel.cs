using System.ComponentModel.DataAnnotations;

namespace PapiPay.Identity.Controllers
{
    public class LoginInputModel
    {
        [Required]
        public string Username { get; set; }
        [Required]
        public string Password { get; set; }
        public bool RememberLogin { get; set; }
        public string ReturnUrl { get; set; }
        public bool nativeclient { get; set; }
        public string TenantName { get; set; }
    }
}