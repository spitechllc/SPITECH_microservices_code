namespace PapiPay.Identity.Controllers
{
    public class VerifyEmailModel
    {
        public bool IsVerify { get; set; }
        public string TenantName { get; set; }
    }
}
