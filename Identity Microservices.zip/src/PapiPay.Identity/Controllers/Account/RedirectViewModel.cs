namespace PapiPay.Identity.Controllers
{
    public class RedirectViewModel
    {
        public string RedirectUrl { get; set; }
    }
}