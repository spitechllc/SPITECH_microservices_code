using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using PapiPay.Application.Logging.Interfaces;
using PapiPay.ApplicationCore.Authentication;
using PapiPay.ApplicationCore.Authorizations;
using PapiPay.ApplicationCore.Domain.Models;
using PapiPay.Identity.Application.Commands.CreateLinkUserRequest;
using PapiPay.Identity.Application.Commands.GenerateUserVerificationCode;
using PapiPay.Identity.Application.Commands.RemoveLinkUser;
using PapiPay.Identity.Application.Queries.GetLinkUser;
using PapiPay.Identity.Application.Queries.VerifyLinkUser;
using PapiPay.Identity.Domain.Entities;
using PapiPay.Identity.Domain.Models;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using static IdentityServer4.IdentityServerConstants;
using static PapiPay.ApplicationCore.Domain.DomainConstant;

namespace PapiPay.Identity.Controllers
{
    [Authorize(LocalApi.PolicyName)]
    [ApiController]
    [Route("api/[controller]")]
    public class LinkUserController : Controller
    {
        private readonly IMediator mediator;
        private readonly IMapper mapper;
        private readonly IUserAuthenticationProvider authenticationProvider;
        private readonly ILogger<LinkUserController> logger;
        private readonly IStringLocalizer<LinkUserController> _localizer;

        public LinkUserController(
            IMediator mediator,
            IMapper mapper,
            IUserAuthenticationProvider authenticationProvider, ILogger<LinkUserController> logger, IStringLocalizer<LinkUserController> localizer)
        {
            this.mediator = mediator;
            this.mapper = mapper;
            this.logger = logger;
            this.authenticationProvider = authenticationProvider;
            _localizer = localizer;
        }

        /// <summary>
        /// Generates code to link users
        /// </summary>
        /// <param name="userId">Varriable of int</param>
        /// <returns>It will return in the form of CodeVerification</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_LinkUser_GenerateCode")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("GenerateCode")]
        public async Task<ActionResult<CodeVerification>> GenerateCode([FromQuery] int userId)
        {
            GenerateUserVerificationCodeCommand command = new()
            {
                UserId = userId,
                CodeType = EventBus.DomainEvents.Enums.CodeType.LinkUser
            };
            return Ok(await mediator.Send(command).ConfigureAwait(false));
        }

        /// <summary>
        /// Generates request to link two users together
        /// </summary>
        /// <param name="command">Object of CreateLinkUserRequestCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_LinkUser_Request")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("Request")]
        public async Task<ActionResult<ResponseModel>> CreateLinkUserRequest([FromBody] CreateLinkUserRequestCommand command)
        {
            ResponseModel res = await mediator.Send(command).ConfigureAwait(false);
            res.Message = _localizer[res.Message].Value;
            return Ok(res);
        }

        /// <summary>
        /// Removes linked users
        /// </summary>
        /// <param name="command">Object of RemoveLinkUserCommand</param>
        /// <returns>It will return in the form of ResponseModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_LinkUser_Remove")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpPost("Remove")]
        public async Task<ActionResult<ResponseModel>> RemoveLinkUser([FromBody] RemoveLinkUserCommand command)
        {
            ResponseModel res = await mediator.Send(command).ConfigureAwait(false);
            if (!string.IsNullOrWhiteSpace(res.Message))
            {
                res.Message = _localizer[res.Message].Value;
            }
            return Ok(res);
        }

        /// <summary>
        /// Verifies if users linked or not
        /// </summary>
        /// <param name="fromUserId">Varriable of int</param>
        /// <param name="toUserId">varriable of int</param>
        /// <returns>It will return List in the form of LinkUserModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_LinkUser_Verify")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("Verify")]
        public async Task<ActionResult<List<LinkUserModel>>> VerifyLinkUser([FromQuery] int fromUserId, [FromQuery] int toUserId)
        {
            return Ok(await mediator.Send(new VerifyLinkUserQuery() { FromUserId = fromUserId, ToUserId = toUserId }).ConfigureAwait(false));
        }

        /// <summary>
        /// Returns collections of users linked with a user
        /// </summary>
        /// <param name="UserId">Varriable of int</param>
        /// <returns>It will return ResponseList in the form of UserModel</returns>
        [ApiPermissionAuthorize(Permissions = "IdentityServerApi_LinkUser_Get")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ValidationProblemDetails), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ProblemDetails), (int)HttpStatusCode.InternalServerError)]
        [HttpGet("Get")]
        public async Task<ActionResult<ResponseList<UserModel>>> GetLinkUser([FromQuery] int UserId)
        {
            return Ok(await mediator.Send(new GetLinkUserQuery() { UserId = UserId }).ConfigureAwait(false));
        }
    }
}
