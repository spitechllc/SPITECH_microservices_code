using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;

namespace PapiPay.Identity.Controllers
{
    [SecurityHeaders]
    [Authorize]
    public class DiagnosticsController : Controller
    {
        /// <summary>
        /// Show the Diagnostics Screen
        /// </summary>
        /// <param></param>
        /// <returns>It will return in the form of DiagnosticsViewModel</returns>
        public async Task<IActionResult> Index()
        {
            string[] localAddresses = new string[] { "127.0.0.1", "::1", HttpContext.Connection.LocalIpAddress.ToString() };
            if (!localAddresses.Contains(HttpContext.Connection.RemoteIpAddress.ToString()))
            {
                return NotFound();
            }

            DiagnosticsViewModel model = new(await HttpContext.AuthenticateAsync());
            return View(model);
        }
    }
}