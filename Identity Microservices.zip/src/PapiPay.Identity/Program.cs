using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using PapiPay.Application.Logging;
using PapiPay.Application.Logging.Extensions;
using System;

namespace PapiPay.Identity
{
    public class Program
    {
        public static void Main(string[] args)
        {
            LoggerExtensions.InitializeLogger();
            Logger.Information("IdentityServer starting");
            try
            {
                IHost host = CreateHostBuilder(args).Build();
                host.Run();
                Logger.Information($"IdentityServer Application started in environment: {Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")}");
            }
            catch (Exception e)
            {
                Logger.Error("IdentityServer Host terminated unexpected", e);
                throw;
            }
            finally
            {
                Logger.Information("IdentityServer stopped");
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            return Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseLogger();
                    webBuilder.UseStartup<Startup>();
                });
        }
    }
}
