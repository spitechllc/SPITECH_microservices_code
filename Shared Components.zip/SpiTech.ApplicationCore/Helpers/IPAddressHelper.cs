﻿using System.Net;

namespace SpiTech.ApplicationCore.Helpers
{
    public static class IPAddressHelper
    {
        public static string GetIPAddress()
        {
            string externalIpString = "";

            try
            {
                externalIpString = new WebClient().DownloadString("http://icanhazip.com").Replace("\\r\\n", "").Replace("\\n", "").Trim();
            }
            catch { }
            return externalIpString;
        }
    }
}
