﻿using System;

namespace SpiTech.ApplicationCore.Helpers
{
    public class UniqueIdGenerator
    {
        public static string Generate()
        {
            return DateTime.Now.Ticks.ToString();
        }
    }
}
