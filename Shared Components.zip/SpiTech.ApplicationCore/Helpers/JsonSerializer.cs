﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;

namespace SpiTech.ApplicationCore.Helpers
{
    public static class ExceptionJsonSerializer
    {
        public static string Serialize(Exception ex)
        {
            try
            {
                Dictionary<string, string> error = new()
                {
                                    {"Type", ex.GetType().ToString()},
                                    {"Message", ex.Message},
                                    {"StackTrace", ex.StackTrace}
                                };

                foreach (DictionaryEntry data in ex.Data)
                {
                    error.Add(data.Key.ToString(), data.Value.ToString());
                }

                return JsonConvert.SerializeObject(error, Formatting.Indented, new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore });
            }
            catch
            {
                return ex.Message;
            }
        }
    }
}
