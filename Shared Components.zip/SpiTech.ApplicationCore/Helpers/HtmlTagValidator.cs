﻿using FluentValidation;
using Newtonsoft.Json;
using System;
using System.Text.RegularExpressions;

namespace SpiTech.ApplicationCore.Helpers
{
    public class HtmlTagValidator : JsonConverter
    {
        public override bool CanRead => true;
        public override bool CanWrite => false;

        public override bool CanConvert(Type objectType)
        {
            return objectType == typeof(string);
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, Newtonsoft.Json.JsonSerializer serializer)
        {
            string exp = "<(\"[^\"]*\"|'[^']*'|[^'\">])*>";
            string value = (string)reader.Value;
            if (!string.IsNullOrEmpty(value) && Regex.IsMatch(value, exp))
               throw new ValidationException("Invalid request");
             //throw new ValidationException(new FluentValidation.Results.ValidationFailure("Invalid", "Contains some html tags"));
            else
                return value;
            
        }

        public override void WriteJson(JsonWriter writer, object value, Newtonsoft.Json.JsonSerializer serializer)
        {
            throw new NotImplementedException();
        }
    }
}
