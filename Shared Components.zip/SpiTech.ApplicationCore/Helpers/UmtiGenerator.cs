﻿using System;

namespace SpiTech.ApplicationCore.Helpers
{
    public class UmtiGenerator
    {
        public static string Generate(string utmiPrefix)
        {
            return $"{utmiPrefix}{DateTime.Now.Ticks}";
        }
    }
}
