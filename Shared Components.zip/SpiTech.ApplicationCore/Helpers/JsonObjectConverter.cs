﻿using Newtonsoft.Json;
using System;

namespace SpiTech.ApplicationCore.Helpers
{
    public class JsonObjectConverter
    {
        public const string NullSerializeValue = "[null]";

        public const string ExceptionSerializeValue = "[Object could not be serialized]";

        public static string Serialize(
                                        object model,
                                        bool throwException = true,
                                        string exceptionSerializeValue = JsonObjectConverter.ExceptionSerializeValue,
                                        string nullSerializeValue = JsonObjectConverter.NullSerializeValue)
        {
            string serializedValue = string.Empty;

            // if (model == null)
            // {
            //     return nullSerializeValue;
            // }

            try
            {
                serializedValue = JsonConvert.SerializeObject(model, new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore });
            }
            catch (Exception)
            {
                if (throwException)
                {
                    throw;
                }
                else
                {
                    // Do not crash the application due to Json serialization issues.
                    serializedValue = exceptionSerializeValue;
                }
            }

            return serializedValue;
        }

        public static T Deserialize<T>(string value)
        {
            return JsonConvert.DeserializeObject<T>(value);
        }
    }
}
