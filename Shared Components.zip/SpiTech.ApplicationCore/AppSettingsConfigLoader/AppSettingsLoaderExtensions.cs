﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace SpiTech.ApplicationCore.AppSettingsConfigLoader
{
    public static class AppSettingsLoaderExtensions
    {
        public static T LoadConfig<T>(this IConfiguration configuration)
        {
            return configuration
                .LoadConfigSection<T>()
                .Get<T>();
        }


        public static IConfigurationSection LoadConfigSection<T>(this IConfiguration configuration)
        {
            string configSectionName = typeof(T).Name;
            return configuration.GetSection(configSectionName);

        }

        public static IServiceCollection AddConfig<T>(this IServiceCollection services, IConfiguration configuration) where T : class
        {
            T config = configuration.LoadConfig<T>();
            services.AddSingleton(config);
            return services;
        }

    }
}
