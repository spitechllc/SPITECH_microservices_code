using System;
using System.Collections.Generic;
using Org.BouncyCastle.Bcpg.OpenPgp;

namespace SpiTech.ApplicationCore.PgpCore
{
    public interface IEncryptionKeys
    {
        IEnumerable<PgpPublicKey> EncryptKeys { get; }
        IEnumerable<PgpPublicKey> VerificationKeys { get; }
        PgpPrivateKey SigningPrivateKey { get; }
        PgpSecretKey SigningSecretKey { get; }
        PgpPublicKey MasterKey { get; }
        [Obsolete("This property is obsolete and will be removed in a future release. Use the MasterKey or EncryptKeys.FirstOrDefault() properties instead.")]
        PgpPublicKey PublicKey { get; }
        [Obsolete("This property is obsolete and will be removed in a future release. Use the MasterKey and EncryptKeys properties instead.")]
        IEnumerable<PgpPublicKey> PublicKeys { get; }
        PgpPrivateKey PrivateKey { get; }
        PgpSecretKey SecretKey { get; }
        PgpSecretKeyRingBundle SecretKeys { get; }

        PgpPrivateKey FindSecretKey(long keyId);
    }
}