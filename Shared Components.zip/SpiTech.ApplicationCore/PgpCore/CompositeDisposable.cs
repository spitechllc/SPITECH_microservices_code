﻿using System;
using System.Collections.Concurrent;

namespace SpiTech.ApplicationCore.PgpCore
{
    internal sealed class CompositeDisposable : IDisposable
    {
        private readonly ConcurrentQueue<IDisposable> _disposables = new ConcurrentQueue<IDisposable>();

        public void Add(IDisposable disposable)
        {
            if (disposable == null)
                throw new ArgumentNullException(nameof(disposable));

            _disposables.Enqueue(disposable);
        }

        public void Dispose()
        {
            while (_disposables.TryDequeue(out IDisposable disposable))
                disposable.Dispose();
        }
    }
}
