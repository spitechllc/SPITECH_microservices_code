﻿using System;

namespace SpiTech.ApplicationCore.PgpCore
{
    internal static class DisposableExtensions
    {
        public static T DisposeWith<T>(this T @this, CompositeDisposable disposables)
            where T : IDisposable
        {
            if (@this == null)
                throw new ArgumentNullException(nameof(@this));
            if (disposables == null)
                throw new ArgumentNullException(nameof(disposables));

            disposables.Add(@this);
            return @this;
        }
    }
}
