﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.AzureServices.Containers
{
    internal class AzureStorageService : IStorageService
    {
        private CloudBlobContainer _cloudblobcontainer;
        private readonly string connectionString;

        public AzureStorageService(string connectionString)
        {
            this.connectionString = connectionString;
        }
        public IStorageService CreateContainer(string containerName)
        {
            CloudBlobClient cloudblobclient = CloudStorageAccount.Parse(connectionString).CreateCloudBlobClient();
            _cloudblobcontainer = cloudblobclient.GetContainerReference(containerName);
            return this;
        }

        public async Task<Blob> GetFile(string filename)
        {
            dynamic model = null;
            try
            {
                CloudBlockBlob blockBlob = _cloudblobcontainer.GetBlockBlobReference(filename);
                await blockBlob.FetchAttributesAsync();
                model = new Blob
                {
                    Id = Guid.NewGuid(),
                    ContainerName = blockBlob.Container.Name,
                    StorageUri = blockBlob.StorageUri.PrimaryUri.ToString(),
                    PrimaryUri = blockBlob.StorageUri.PrimaryUri.ToString(),
                    ActualFileName = blockBlob.Uri.AbsoluteUri.Substring(blockBlob.Uri.AbsoluteUri.LastIndexOf("/") + 1).Replace("%20", " "),
                    FileExtension = System.IO.Path.GetExtension(blockBlob.Uri.AbsoluteUri.Substring(blockBlob.Uri.AbsoluteUri.LastIndexOf("/") + 1)),
                    FileNameWithoutExtension = System.IO.Path.GetFileNameWithoutExtension(blockBlob.Uri.AbsoluteUri.Substring(blockBlob.Uri.AbsoluteUri.LastIndexOf("/") + 1)).Replace("%20", " ")
                };
            }
            catch
            {

            }

            return model;
        }

        public async Task<bool> CheckFileExists(string filename)
        {
            try
            {
                CloudBlockBlob blockBlob = _cloudblobcontainer.GetBlockBlobReference(filename);
                await blockBlob.FetchAttributesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> DeleteBolb(string filename)
        {
            CloudBlockBlob blockblob = _cloudblobcontainer.GetBlockBlobReference(filename);
            return await blockblob.DeleteIfExistsAsync();
        }

        public async Task<bool> DownloadBlobAsync(string filename, Stream stream)
        {
            CloudBlockBlob blockBlob = _cloudblobcontainer.GetBlockBlobReference(filename);
            await blockBlob.DownloadToStreamAsync(stream);
            return true;
        }

        public async Task<byte[]> DownloadBytesAsync(string filePath)
        {
            var wc = new WebClient();
            return await wc.DownloadDataTaskAsync(filePath);
        }

        public async Task<bool> DownloadBlobAsync(string filename)
        {
            CloudBlockBlob blockBlob = _cloudblobcontainer.GetBlockBlobReference(filename);

            string actualfilename = blockBlob.Uri.AbsoluteUri;
            using FileStream filestream = System.IO.File.OpenWrite(actualfilename);
            await blockBlob.DownloadToStreamAsync(filestream);
            return true;
        }
        public async Task<bool> UploadBlob(string base64, string filename)
        {
            bool retunvalue = false;
            if (base64 != null)
            {
                await _cloudblobcontainer.SetPermissionsAsync(new BlobContainerPermissions
                {
                    PublicAccess = BlobContainerPublicAccessType.Blob
                });

                CloudBlockBlob blockblob = _cloudblobcontainer.GetBlockBlobReference(filename);
                blockblob.Properties.ContentType = "image/jpeg";

                byte[] content = Convert.FromBase64String(base64);

                using (MemoryStream filestream = new(content))
                {
                    await blockblob.UploadFromStreamAsync(filestream);
                }
                retunvalue = true;

            }
            else
            {
                return retunvalue;
            }
            return retunvalue;
        }

        public async Task<bool> UploadBlob(byte[] content, string filename)
        {
            return await UploadBlob(content, filename, "image/jpeg");
        }
        public async Task<bool> UploadBlob(byte[] content, string filename, string contentType)
        {
            bool retunvalue = false;
            if (content != null && content.Length > 0)
            {
                await _cloudblobcontainer.SetPermissionsAsync(new BlobContainerPermissions
                {
                    PublicAccess = BlobContainerPublicAccessType.Blob
                });
                CloudBlockBlob blockblob = _cloudblobcontainer.GetBlockBlobReference(filename);
                blockblob.Properties.ContentType = contentType;
                using (MemoryStream filestream = new(content))
                {

                    await blockblob.UploadFromStreamAsync(filestream);
                }
                retunvalue = true;
            }
            else
            {
                return retunvalue;
            }
            return retunvalue;
        }
        public async Task<bool> UploadBlob(Stream content, string filename)
        {
            bool retunvalue = false;
            if (content != null && content.Length > 0)
            {
                await _cloudblobcontainer.SetPermissionsAsync(new BlobContainerPermissions
                {
                    PublicAccess = BlobContainerPublicAccessType.Blob
                });
                CloudBlockBlob blockblob = _cloudblobcontainer.GetBlockBlobReference(filename);
                blockblob.Properties.ContentType = "image/jpeg";
                await blockblob.UploadFromStreamAsync(content);

                retunvalue = true;

            }
            else
            {
                return retunvalue;
            }
            return retunvalue;
        }
        public async Task<bool> UploadBlob(Stream content, string filename, string contenttype)
        {
            bool returnvalue = false;
            if (content != null && content.Length > 0)
            {
                await _cloudblobcontainer.SetPermissionsAsync(new BlobContainerPermissions
                {
                    PublicAccess = BlobContainerPublicAccessType.Blob
                });
                CloudBlockBlob blockblob = _cloudblobcontainer.GetBlockBlobReference(filename);
                blockblob.Properties.ContentType = contenttype;
                await blockblob.UploadFromStreamAsync(content);

                returnvalue = true;

            }
            else
            {
                return returnvalue;
            }
            return returnvalue;
        }
        public async Task<bool> UploadBlobBase64(string base64, string filename, string contenttype)
        {
            bool retunvalue = false;
            if (base64 != null)
            {
                await _cloudblobcontainer.SetPermissionsAsync(new BlobContainerPermissions
                {
                    PublicAccess = BlobContainerPublicAccessType.Blob
                });

                CloudBlockBlob blockblob = _cloudblobcontainer.GetBlockBlobReference(filename);
                blockblob.Properties.ContentType = contenttype;

                byte[] content = Convert.FromBase64String(base64);

                using (MemoryStream filestream = new(content))
                {
                    await blockblob.UploadFromStreamAsync(filestream);
                }
                retunvalue = true;

            }
            else
            {
                return retunvalue;
            }
            return retunvalue;
        }
    }
}
