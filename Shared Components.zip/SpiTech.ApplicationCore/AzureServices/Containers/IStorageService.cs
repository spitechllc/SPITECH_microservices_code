﻿using System.IO;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.AzureServices.Containers
{
    public interface IStorageService
    {
        Task<Blob> GetFile(string filename);
        Task<bool> CheckFileExists(string filename);
        Task<bool> DeleteBolb(string filename);
        Task<bool> DownloadBlobAsync(string filename);
        Task<bool> DownloadBlobAsync(string filename, Stream stream);
        Task<bool> UploadBlob(string base64, string filename);
        Task<bool> UploadBlob(byte[] content, string filename);
        Task<bool> UploadBlob(byte[] content, string filename, string contentType);
        Task<bool> UploadBlob(Stream content, string filename);
        Task<bool> UploadBlob(Stream content, string filename, string contenttype);
        Task<bool> UploadBlobBase64(string base64, string filename, string contenttype);
        Task<byte[]> DownloadBytesAsync(string filePath);
    }
}
