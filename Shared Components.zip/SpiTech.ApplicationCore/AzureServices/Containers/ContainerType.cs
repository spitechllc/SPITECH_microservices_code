﻿using System.ComponentModel;

namespace SpiTech.ApplicationCore.AzureServices.Containers
{
    public enum ContainerType
    {
        [Description("none")]
        None = 0,
        [Description("accountsupport")]
        AccountSupport = 1,
        [Description("storeimages")]
        StoreImages = 2,
        [Description("profileimage")]
        UserProfileImage = 3,
        [Description("eodsettlementnachafiles")]
        EodSettlementNachaFile = 4,
        [Description("monthlyinvoicenachafiles")]
        MonthlyInvoiceNachaFile = 5,
        [Description("userachpaymentnachafiles")]
        UserAchPaymentNachaFile = 6,
        [Description("offerimages")]
        OfferImage = 7,
        [Description("issueimages")]
        IssueImages = 8,
        [Description("eodpdf")]
        EodPdf = 9,
        [Description("monthlyinvoicepdf")]
        MonthlyInvoicePdf = 10,
        [Description("auroragcsbucket")]
        AuroraGCSBucket = 11,
        [Description("monthlysaleagentinvoicenachafiles")]
        MonthlySaleAgentInvoiceNachaFile = 12,
        [Description("stridebaiincommingfiles")]
        StrideBAIIncommingFile = 13,
        [Description("saleagentmonthlyinvoicepdf")]
        SaleAgentMonthlyInvoicePdf = 14,
        [Description("monthlyresellerinvoicenachafile")]
        MonthlyResellerInvoiceNachaFile = 15,
        [Description("resellermonthlyinvoicepdf")]
        ResellerMonthlyInvoicePdf = 16,
        [Description("fnboreceivednachafile")]
        FNBOReceivedNachaFile = 17,
    }
}
