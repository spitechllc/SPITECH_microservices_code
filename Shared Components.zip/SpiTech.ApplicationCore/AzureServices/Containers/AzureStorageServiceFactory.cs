﻿using System.ComponentModel;

namespace SpiTech.ApplicationCore.AzureServices.Containers
{
    internal class AzureStorageServiceFactory : IStorageServiceFactory
    {
        private readonly IStorageService storageService;

        public AzureStorageServiceFactory(IStorageService storageService)
        {
            this.storageService = storageService;
        }
        public IStorageService Get(ContainerType container)
        {
            return (storageService as AzureStorageService).CreateContainer(GetDescription(container));
        }

        public static string GetDescription(ContainerType container)
        {
            DescriptionAttribute[] attributes = (DescriptionAttribute[])container
               .GetType()
               .GetField(container.ToString())
               .GetCustomAttributes(typeof(DescriptionAttribute), false);
            return attributes.Length > 0 ? attributes[0].Description : string.Empty;
        }
    }
}
