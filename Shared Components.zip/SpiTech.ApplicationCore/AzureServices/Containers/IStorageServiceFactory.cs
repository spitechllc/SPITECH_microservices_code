﻿namespace SpiTech.ApplicationCore.AzureServices.Containers
{
    public interface IStorageServiceFactory
    {
        IStorageService Get(ContainerType container);
    }
}
