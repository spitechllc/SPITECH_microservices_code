﻿using System;

namespace SpiTech.ApplicationCore.AzureServices.Containers
{
    public class Blob
    {
        public Guid Id { get; set; }
        public string ContainerName { get; set; }
        public string StorageUri { get; set; }
        public string PrimaryUri { get; set; }
        public string ActualFileName { get; set; }
        public string FileExtension { get; set; }
        public string FileNameWithoutExtension { get; set; }
    }
}
