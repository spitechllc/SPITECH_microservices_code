﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Linq;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.ApplicationCore.Authorizations
{
    public class ApiPermissionAuthorizeHandler : AuthorizationHandler<ApiPermissionAuthorizeRequirement>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, ApiPermissionAuthorizeRequirement requirement)
        {
            if (context.User == null || context.User.Identity == null || !context.User.Identity.IsAuthenticated)
            {
                context.Fail();
                return Task.CompletedTask;
            }

            if (string.IsNullOrEmpty(requirement.Permissions))
            {
                context.Fail();
                return Task.CompletedTask;
            }

            var assignedPermissionsForUser = new string[] { };

            var apiResourceClaim = context.User.Claims.FirstOrDefault(t => t.Type == IdentityClaim.ApiResourceClaim)?.Value;

            if (!string.IsNullOrWhiteSpace(apiResourceClaim))
            {
                var requiredPermissions = requirement.Permissions.Split(",");

                foreach (var requiredPermission in requiredPermissions)
                {
                    if (apiResourceClaim.Split(",").Any(t => t.Equals(requiredPermission, StringComparison.InvariantCultureIgnoreCase)))
                    {
                        //context.Succeed authorize's the user. 
                        //Note: If multiple authorize attributes are available, if you want the user to be authorized in both the all the attributes, then dont set the context.success here. Just return task completed
                        //setting context.succeed here will not take the control next attribute, it will be marked as authorized in all lower level attributes.
                        context.Succeed(requirement);
                        return Task.CompletedTask;
                    }
                }
            }

            //Setting user as not authorized
            context.Fail();
            return Task.CompletedTask;
        }
    }
}
