﻿using Microsoft.AspNetCore.Authorization;

namespace SpiTech.ApplicationCore.Authorizations
{
    public class ApiPermissionAuthorize : AuthorizeAttribute
    {
        const string POLICY_PREFIX = "ApiPermissionAuthPolicy";

        private string permissions;

        public string Permissions
        {
            get
            {
                return permissions;
            }
            set
            {
                permissions = value;
                Policy = POLICY_PREFIX + ":" + permissions;
            }
        }
    }
}
