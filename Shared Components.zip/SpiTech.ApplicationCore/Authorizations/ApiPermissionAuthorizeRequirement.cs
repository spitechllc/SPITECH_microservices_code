﻿using Microsoft.AspNetCore.Authorization;

namespace SpiTech.ApplicationCore.Authorizations
{
    public class ApiPermissionAuthorizeRequirement : IAuthorizationRequirement
    {
        public string Permissions { get; private set; }

        public ApiPermissionAuthorizeRequirement(string permissions)
        {
            Permissions = permissions;
        }
    }
}
