﻿using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Configs;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.ApplicationCore.Domain.Nacha;
using SpiTech.ApplicationCore.Domain.Nacha.Constants;
using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using SpiTech.ApplicationCore.Domain.Nacha.Models;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.ApplicationCore.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Nacha
{
    public class NachaFileBuilder : INachaFileBuilder
    {
        private readonly ILogger<NachaFileBuilder> logger;
        private readonly ISftpService sftpService;

        public NachaFileBuilder(ILogger<NachaFileBuilder> logger, ISftpService sftpService)
        {
            this.logger = logger;
            this.sftpService = sftpService;
        }

        //public Stream CreateStream(NachaConfig config, List<NachaModel> accounts)
        //{
        //    string fileName = string.Empty;
        //    MemoryStream stream = null;

        //    NachaFile nachaFile = CreateByOldProcess(config, accounts);

        //    if (nachaFile != null)
        //    {
        //        stream = new();
        //        bool result = CreateStream(nachaFile, stream);
        //        stream.Position = 0;
        //    }

        //    return stream;
        //}

        //public string CreateFile(NachaConfig config, List<NachaModel> accounts)
        //{
        //    string fileName = string.Empty;

        //    NachaFile nachaFile = CreateByOldProcess(config, accounts);

        //    if (nachaFile != null)
        //    {
        //        fileName = GetFileName(config.ProcessType);
        //        using MemoryStream stream = new();
        //        bool result = CreateStream(nachaFile, stream);
        //        using FileStream fileStream = new(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "NachaFiles", fileName), FileMode.Create);
        //        stream.Position = 0;
        //        stream.WriteTo(fileStream);
        //    }

        //    return fileName;
        //}

        public NachaFileBytesModel GetBytes(NachaConfig config, List<NachaModel> accounts)
        {
            NachaFileBytesModel nachaFileBytesModel = null;

            NachaFile nachaFile = CreateByOldProcess(config, accounts);
            if (nachaFile != null)
            {
                nachaFileBytesModel = new NachaFileBytesModel
                {
                    File = GetFileName(config.ProcessType)
                };
                using MemoryStream stream = new();
                bool result = CreateStream(nachaFile, stream);

                stream.Position = 0;

                nachaFileBytesModel.Bytes = new byte[stream.Length];
                stream.Read(nachaFileBytesModel.Bytes, 0, nachaFileBytesModel.Bytes.Length);
            }

            return nachaFileBytesModel;
        }

        public async Task<bool> UploadFileInSftp(NachaFileBytesModel nachaFileBytes, bool uploadToSftp, SftpConfig sftpConfig)
        {
            bool result = false;
            if (nachaFileBytes != null)
            {
                using MemoryStream stream = new(nachaFileBytes.Bytes);
                stream.Position = 0;

                if (uploadToSftp)
                {
                    result = await sftpService.UploadFile(stream, nachaFileBytes.File, sftpConfig);
                }
                else
                {
                    using (FileStream fileStream = new(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "NachaFiles", nachaFileBytes.File), FileMode.Create))
                    {
                        stream.Position = 0;
                        stream.WriteTo(fileStream);
                    }
                    result = true;
                }
            }

            return result;
        }

        //public string UploadFileInSftp(NachaProcessingModel nachaProcessingModel,
        //                                SftpConfig sftpConfig)
        //{
        //    string fileName = string.Empty;

        //    NachaFile nachaFile = CreateByOldProcess(nachaProcessingModel.Config, nachaProcessingModel.);

        //    if (nachaFile != null)
        //    {
        //        fileName = GetFileName(nachaProcessingModel.Config.ProcessType);
        //        using MemoryStream stream = new();
        //        bool result = CreateStream(nachaFile, stream);
        //        stream.Position = 0;
        //        sftpService.UploadFile(stream, fileName, sftpConfig);
        //    }

        //    return fileName;
        //}

        private string GetFileName(NachaProcessType nachaProcessType)
        {
            var fileNamePrefix = string.Empty;
            string date = string.Format("{0:yyyyMMddHHmmss}", DateTime.UtcNow);

            return $"{nachaProcessType}{fileNamePrefix}{UniqueIdGenerator.Generate()}_{date}.txt";
        }

        //private bool CreateByNewProcess(NachaConfig nachaConfig, 
        //                                MasterAccountModel masterAccount, 
        //                                IEnumerable<NachaModel> nachaAccounts, 
        //                                NachaProcessType nachaProcessType, 
        //                                Stream stream)
        //{
        //    if (!nachaAccounts.Any(t => t.Amount > 0))
        //    {
        //        return false;
        //    }

        //    using (StreamWriter sw = new(stream, Encoding.UTF8, 1024, true))
        //    {
        //        NACHAConfiguration config = new NACHAConfiguration();
        //        config.DestinationBankRoutingNumber = " " + nachaConfig.BankRoutingNo;
        //        config.OriginatingCompanyId = nachaConfig.RoutingNo;
        //        config.DestinationBankName = nachaConfig.BankName;
        //        config.OriginatingCompanyName = nachaConfig.CompanyName;
        //        config.ReferenceCode = "00000000";
        //        config.BatchNumber = 4100001;
        //        config.TraceNumber = 4100100;
        //        config.EntryDetailTraceSource = ChoEntryDetailTraceSource.OriginatingDFI;

        //        using (var nachaWriter = new NACHAWriter(sw, config))
        //        {
        //            using (var bw1 = nachaWriter.CreateBatch(BatchServiceClassCodeConstant.Mixed, StandardEntryClassCodeConstant.CCD,
        //                companyID: nachaConfig.AccountNo, companyName: masterAccount.AccountName,
        //                companyEntryDescription: nachaProcessType.ToString(),
        //                originatingDFIID: nachaConfig.RoutingNo))
        //            {
        //                foreach (NachaModel nachaAccount in nachaAccounts)
        //                {
        //                    if (nachaAccount.Amount == 0)
        //                    {
        //                        continue;
        //                    }

        //                    using (var entry1 = bw1.CreateEntryDetail(GetDebitTransactionCode(nachaAccount.AccountType, nachaProcessType), nachaAccount.RoutingNo, nachaAccount.AccountNo, nachaAccount.Amount, GetReceiverIdentificationNumber(nachaAccount, nachaProcessType), nachaAccount.ProcessingAccount.AccountName, null, IsNachaAccountCredit(nachaProcessType)))
        //                    {
        //                    }

        //                    if (nachaProcessType != NachaProcessType.USERACH)
        //                    {
        //                        using (var SpiTechmasterEntry = bw1.CreateEntryDetail(GetCreditTransactionCode(masterAccount.AccountType, nachaProcessType), nachaConfig.RoutingNo, nachaConfig.AccountNo, nachaAccount.Amount, masterAccount.IdentificationNumber, masterAccount.AccountName, null, !IsNachaAccountCredit(nachaProcessType)))
        //                        {
        //                        }
        //                    }
        //                }

        //                if (nachaProcessType == NachaProcessType.USERACH)
        //                {
        //                    using (var SpiTechmasterEntry = bw1.CreateEntryDetail(GetCreditTransactionCode(masterAccount.AccountType, nachaProcessType), nachaConfig.RoutingNo, nachaConfig.AccountNo, nachaAccounts.Sum(t => t.Amount), masterAccount.IdentificationNumber, masterAccount.AccountName, null, !IsNachaAccountCredit(nachaProcessType)))
        //                    {
        //                    }
        //                }
        //            }
        //        }
        //        sw.WriteLine();
        //        sw.Flush();
        //    }

        //    return true;
        //}

        private NachaFile CreateByOldProcess(NachaConfig config, List<NachaModel> accounts)
        {
            if (config == null || accounts == null || !accounts.Any())
            {
                return null;
            }

            NachaFile nachaFile = new();
            nachaFile.Header.Id = "A";
            nachaFile.Header.ImmediateDestination = config.BankRoutingNo;
            nachaFile.Header.ImmediateOrigin = config.RoutingNo;
            nachaFile.Header.ImmediateDestinationName = config.BankName;
            nachaFile.Header.ImmediateOriginName = config.ImmediateOriginName;

            var creditAccounts = accounts.Where(t => t.TransactionCodeType == TransactionCodeType.Credit).ToList();
            var debitAccounts = accounts.Where(t => t.TransactionCodeType == TransactionCodeType.Debit).ToList();

            ProcessCreditAccounts(config, nachaFile, creditAccounts);
            ProcessAchDebitAccounts(config, nachaFile, debitAccounts);

            return nachaFile;
        }

        private void ProcessCreditAccounts(NachaConfig config, NachaFile nachaFile, List<NachaModel> creditAccounts)
        {
            if (creditAccounts.Any())
            {
                foreach (var creditAccountGroup in creditAccounts.GroupBy(t => t.BatchCompanyName))
                {
                    nachaFile.AddBatch(new Batch());
                    var batchIndex = nachaFile.Batches.Count - 1;

                    nachaFile.Batches[batchIndex].Header.ServiceClassCode = BatchServiceClassCodeConstant.Mixed;
                    nachaFile.Batches[batchIndex].Header.CompanyName = string.IsNullOrWhiteSpace(creditAccountGroup.Key) ? config.BatchCompanyName : creditAccountGroup.Key;
                    nachaFile.Batches[batchIndex].Header.CompanyIdentification = "1" + config.AccountNo;
                    nachaFile.Batches[batchIndex].Header.StandardEntryClassCode = StandardEntryClassCodeConstant.CCD;
                    nachaFile.Batches[batchIndex].Header.CompanyEntryDescription = config.ProcessType.ToString();
                    nachaFile.Batches[batchIndex].Header.CompanyDescriptiveDate = config.EffectiveEntryDate;
                    nachaFile.Batches[batchIndex].Header.EffectiveEntryDate = config.EffectiveEntryDate;
                    nachaFile.Batches[batchIndex].Header.OriginatingDfi = config.RoutingNo.Substring(0, 8);

                    foreach (var nachaAccount in creditAccountGroup)
                    {
                        if (nachaAccount == null || nachaAccount.Amount == 0)
                        {
                            continue;
                        }

                        if (string.IsNullOrWhiteSpace(nachaAccount.ProcessingAccount.RoutingNo) || nachaAccount.ProcessingAccount.RoutingNo.Length < 9)
                        {
                            throw new ValidationException(new FluentValidation.Results.ValidationFailure("RoutingNo", $"Invalid RoutingNo({nachaAccount.ProcessingAccount.RoutingNo}) for account number({nachaAccount.ProcessingAccount.AccountNo}) and account name({nachaAccount.ProcessingAccount.AccountName})  Entity-{nachaAccount.AccountEntityId}"));
                        }

                        if (string.IsNullOrWhiteSpace(nachaAccount.ProcessingAccount.AccountNo))
                        {
                            throw new ValidationException(new FluentValidation.Results.ValidationFailure("AccountNo", $"Invalid AccountNo({nachaAccount.ProcessingAccount.AccountNo}) for RoutingNo({nachaAccount.ProcessingAccount.RoutingNo}) and account name({nachaAccount.ProcessingAccount.AccountName})  Entity-{nachaAccount.AccountEntityId}"));
                        }

                        nachaFile.Batches[batchIndex].AddEntry(new Entry(StandardEntryClassCodeConstant.CCD)
                        {
                            Amount = nachaAccount.Amount,
                            AddendaRecordIndicator = (short)AddendaRecordIndicatorEnum.NotIncluded,
                            CheckDigit = nachaAccount.ProcessingAccount.RoutingNo.Substring(8, 1),
                            RdfiAccountNumber = nachaAccount.ProcessingAccount.AccountNo,
                            DiscretionaryData = "",
                            ReceiverIdentificationNumber = nachaAccount.IdentificationNumber,
                            RdfiRtn = nachaAccount.ProcessingAccount.RoutingNo.Substring(0, 8),
                            ReceiverName = nachaAccount.ProcessingAccount.AccountName,
                            TransactionCode = GetTransactionCode(nachaAccount.ProcessingAccount.AccountType, nachaAccount.TransactionCodeType)
                        });
                    }
                }
            }
        }

        private void ProcessAchDebitAccounts(NachaConfig config, NachaFile nachaFile, List<NachaModel> debitAccounts)
        {
            if (debitAccounts.Any())
            {
                foreach (var debitAccountGroup in debitAccounts.GroupBy(t => t.BatchCompanyName))
                {
                    nachaFile.AddBatch(new Batch());
                    var batchIndex = nachaFile.Batches.Count - 1;

                    nachaFile.Batches[batchIndex].Header.ServiceClassCode = BatchServiceClassCodeConstant.Mixed;
                    nachaFile.Batches[batchIndex].Header.CompanyName = string.IsNullOrWhiteSpace(debitAccountGroup.Key) ? config.BatchCompanyName : debitAccountGroup.Key;
                    nachaFile.Batches[batchIndex].Header.CompanyIdentification = "2" + config.AccountNo;
                    nachaFile.Batches[batchIndex].Header.StandardEntryClassCode = StandardEntryClassCodeConstant.CCD;
                    nachaFile.Batches[batchIndex].Header.CompanyEntryDescription = config.ProcessType.ToString();
                    nachaFile.Batches[batchIndex].Header.CompanyDescriptiveDate = config.EffectiveEntryDate;
                    nachaFile.Batches[batchIndex].Header.EffectiveEntryDate = config.EffectiveEntryDate;
                    nachaFile.Batches[batchIndex].Header.OriginatingDfi = config.RoutingNo.Substring(0, 8);

                    foreach (var nachaAccount in debitAccountGroup)
                    {
                        if (nachaAccount == null || nachaAccount.Amount == 0)
                        {
                            continue;
                        }

                        if (string.IsNullOrWhiteSpace(nachaAccount.ProcessingAccount.RoutingNo) || nachaAccount.ProcessingAccount.RoutingNo.Length < 9)
                        {
                            throw new ValidationException(new FluentValidation.Results.ValidationFailure("RoutingNo", $"Invalid RoutingNo({nachaAccount.ProcessingAccount.RoutingNo}) for account number({nachaAccount.ProcessingAccount.AccountNo}) and account name({nachaAccount.ProcessingAccount.AccountName})  Entity-{nachaAccount.AccountEntityId}"));
                        }

                        if (string.IsNullOrWhiteSpace(nachaAccount.ProcessingAccount.AccountNo))
                        {
                            throw new ValidationException(new FluentValidation.Results.ValidationFailure("AccountNo", $"Invalid AccountNo({nachaAccount.ProcessingAccount.AccountNo}) for RoutingNo({nachaAccount.ProcessingAccount.RoutingNo}) and account name({nachaAccount.ProcessingAccount.AccountName})  Entity-{nachaAccount.AccountEntityId}"));
                        }

                        nachaFile.Batches[batchIndex].AddEntry(new Entry(StandardEntryClassCodeConstant.CCD)
                        {
                            Amount = nachaAccount.Amount,
                            AddendaRecordIndicator = (short)AddendaRecordIndicatorEnum.NotIncluded,
                            CheckDigit = nachaAccount.ProcessingAccount.RoutingNo.Substring(8, 1),
                            RdfiAccountNumber = nachaAccount.ProcessingAccount.AccountNo,
                            DiscretionaryData = "",
                            ReceiverIdentificationNumber = nachaAccount.IdentificationNumber,
                            RdfiRtn = nachaAccount.ProcessingAccount.RoutingNo.Substring(0, 8),
                            ReceiverName = nachaAccount.ProcessingAccount.AccountName,
                            TransactionCode = GetTransactionCode(nachaAccount.ProcessingAccount.AccountType, nachaAccount.TransactionCodeType)
                        });
                    }
                }
            }
        }

        private short GetTransactionCode(AccountType accountType, TransactionCodeType transactionCodeType)
        {
            short transactionCode = 0;

            switch (transactionCodeType)
            {
                case TransactionCodeType.Debit:
                    transactionCode = (short)(accountType == AccountType.Checking ? TransactionCodeEnum.AutomatedPaymentChecking : TransactionCodeEnum.AutomatedPaymentSavings);
                    break;
                case TransactionCodeType.Credit:
                    transactionCode = (short)(accountType == AccountType.Checking ? TransactionCodeEnum.AutomatedDepositChecking : TransactionCodeEnum.AutomatedDepositSavings);
                    break;
                default:
                    break;
            }
            return transactionCode;
        }

        private bool CreateStream(NachaFile nachaFile, MemoryStream stream)
        {
            List<FileHeader> fileHeaders = new()
            {
                nachaFile.Header
            };
            FileHelpers.FileHelperEngine<FileHeader> engine = new();

            StreamWriter sw = new(stream);
            engine.WriteStream(sw, fileHeaders);

            foreach (Batch batch in nachaFile.Batches)
            {
                List<BatchHeader> batchHeaders = new()
                {
                    batch.Header
                };

                FileHelpers.FileHelperEngine<BatchHeader> batchEngine = new();
                batchEngine.WriteStream(sw, batchHeaders);

                List<Entry> entries = new();
                foreach (Entry entry in batch.Entries)
                {
                    entries.Add(entry);
                }

                FileHelpers.FileHelperEngine<Entry> entryEngine = new();
                entryEngine.WriteStream(sw, entries);

                List<BatchControl> batchControls = new()
                {
                    batch.Control
                };

                FileHelpers.FileHelperEngine<BatchControl> batchControlEngine = new();
                batchControlEngine.WriteStream(sw, batchControls);
            }

            List<FileControl> fileControls = new()
            {
                nachaFile.Control
            };
            FileHelpers.FileHelperEngine<FileControl> fileControlEngine = new();
            fileControlEngine.WriteStream(sw, fileControls);

            sw.Flush();

            return true;
        }
    }
}
