﻿using ChoETL;
using SpiTech.ApplicationCore.Nacha.Core.Configuration;
using SpiTech.ApplicationCore.Nacha.Core.Records;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Nacha.Core
{
    public class NACHAReader : IDisposable, IEnumerable
    {
        private TextReader _textReader;
        private bool _closeStreamOnDispose = false;
        private Lazy<IEnumerator> _enumerator = null;
        public TraceSwitch TraceSwitch = ChoETLFramework.TraceSwitch;

        public NACHAConfiguration Configuration
        {
            get;
            private set;
        }

        public NACHAReader(string filePath, NACHAConfiguration configuration = null)
        {
            ChoGuard.ArgumentNotNullOrEmpty(filePath, "FilePath");
            Configuration = configuration;
            Init();

            _textReader = new StreamReader(ChoPath.GetFullPath(filePath), Configuration.GetEncoding(filePath), false, Configuration.BufferSize);
            _closeStreamOnDispose = true;
        }

        public NACHAReader(StringBuilder sb, NACHAConfiguration configuration = null) : this(new StringReader(sb.ToString()), configuration)
        {

        }

        public NACHAReader(TextReader textReader, NACHAConfiguration configuration = null)
        {
            ChoGuard.ArgumentNotNull(textReader, "TextReader");
            Configuration = configuration;
            Init();

            _textReader = textReader;
        }

        public NACHAReader(Stream inStream, NACHAConfiguration configuration = null)
        {
            ChoGuard.ArgumentNotNull(inStream, "Stream");
            Configuration = configuration;
            Init();

            if (inStream is MemoryStream)
                _textReader = new StreamReader(inStream);
            else
                _textReader = new StreamReader(inStream, Configuration.GetEncoding(inStream), false, Configuration.BufferSize);
        }

        private void Init()
        {
            _enumerator = new Lazy<IEnumerator>(() => GetEnumerator());
            if (Configuration == null)
                Configuration = new NACHAConfiguration();
        }

        public object Read()
        {
            if (_enumerator.Value.MoveNext())
                return _enumerator.Value.Current;
            else
                return null;
        }

        public static NACHAReader LoadText(string inputText, NACHAConfiguration configuration = null)
        {
            var r = new NACHAReader(inputText.ToStream(), configuration);
            r._closeStreamOnDispose = true;

            return r;
        }

        public void Dispose()
        {
            if (_closeStreamOnDispose)
                _textReader.Dispose();
        }

        public IEnumerator GetEnumerator()
        {
            ChoManifoldReader reader = new ChoManifoldReader(_textReader, Configuration as ChoManifoldRecordConfiguration).WithRecordSelector(0, 1, typeof(NACHABatchHeaderRecord), typeof(NACHABatchControlRecord),
               typeof(NACHAFileHeaderRecord), typeof(NACHAFileControlRecord), typeof(NACHAEntryDetailRecord), typeof(NACHAAddendaRecord));
            reader.AfterRecordConfigurationConstruct += Reader_AfterRecordConfigurationConstruct;
            reader.TraceSwitch = TraceSwitch;
            reader.Configuration.ObjectValidationMode = ChoObjectValidationMode.ObjectLevel;
            object state = null;
            return ChoNACHAEnumeratorWrapper.BuildEnumerable<object>(() => (state = reader.Read()) != null, () => state).GetEnumerator();
        }

        private void Reader_AfterRecordConfigurationConstruct(object sender, ChoRecordConfigurationConstructArgs e)
        {
            if (e.Configuration != null && e.Configuration is ChoFileRecordConfiguration)
            {
                ((ChoFileRecordConfiguration)e.Configuration).FieldValueTrimOption = Configuration.FieldValueTrimOption;
            }
        }

        public static NACHAReader LoadText(string inputText, Encoding encoding = null, NACHAConfiguration configuration = null, TraceSwitch traceSwitch = null)
        {
            var r = new NACHAReader(inputText.ToStream(encoding), configuration) { TraceSwitch = traceSwitch == null ? ChoETLFramework.TraceSwitch : traceSwitch };
            r._closeStreamOnDispose = true;

            return r;
        }

        public class ChoNACHAEnumeratorWrapper
        {
            public static IEnumerable<T> BuildEnumerable<T>(
                    Func<bool> moveNext, Func<T> current)
            {
                var po = new ChoEnumeratorWrapperInternal<T>(moveNext, current);
                foreach (var s in po)
                    yield return s;
            }

            private class ChoEnumeratorWrapperInternal<T>
            {
                private readonly Func<bool> _moveNext;
                private readonly Func<T> _current;
                private bool _isFileControlRecordFound = false;

                public ChoEnumeratorWrapperInternal(Func<bool> moveNext, Func<T> current)
                {
                    ChoGuard.ArgumentNotNull(moveNext, "MoveNext");
                    ChoGuard.ArgumentNotNull(current, "Current");

                    _moveNext = moveNext;
                    _current = current;
                }

                public ChoEnumeratorWrapperInternal<T> GetEnumerator()
                {
                    return this;
                }

                public bool MoveNext()
                {
                    if (_isFileControlRecordFound)
                        return false;
                    else
                        return _moveNext();
                }

                public T Current
                {
                    get
                    {
                        var ret = _current();
                        _isFileControlRecordFound = ret is NACHAFileControlRecord;
                        return ret;
                    }
                }
            }
        }
    }
}
