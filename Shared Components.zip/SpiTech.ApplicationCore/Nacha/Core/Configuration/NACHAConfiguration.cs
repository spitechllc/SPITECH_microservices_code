﻿using ChoETL;
using SpiTech.ApplicationCore.Nacha.Core.Exceptions;
using System;
using System.Linq;

namespace SpiTech.ApplicationCore.Nacha.Core.Configuration
{
    public class NACHAConfiguration : ChoManifoldRecordConfiguration
    {
        public string PriorityCode
        {
            get;
            set;
        }

        public string DestinationBankRoutingNumber
        {
            get;
            set;
        }

        public bool TurnOffDestinationBankRoutingNumber
        {
            get;
            set;
        }

        public string OriginatingCompanyId
        {
            get;
            set;
        }

        public bool TurnOffOriginatingCompanyIdValidation
        {
            get;
            set;
        }

        public char FileIDModifier
        {
            get;
            set;
        }

        public uint BlockingFactor
        {
            get;
            set;

        }

        public uint FormatCode { get; set; }

        public string DestinationBankName
        {
            get;
            set;
        }

        public string OriginatingCompanyName
        {
            get;
            set;
        }
        
        public string Reserved
        {
            get;
            set;
        }

        public string ReferenceCode { get; set; }
        public uint BatchNumber { get; set; }
        public uint TraceNumber { get; set; }
        public Func<uint> BatchNumberGenerator { get; set; }
        public ChoEntryDetailTraceSource EntryDetailTraceSource { get; set; }

        public NACHAConfiguration()
        {
            PriorityCode = "01";
            FileIDModifier = 'A';
            BlockingFactor = 10;
            FormatCode = 1;
        }

        public void Validate()
        {
            if (PriorityCode.IsNullOrWhiteSpace())
                throw new NACHAConfigurationException("Priority Code must be not empty.");
            if (DestinationBankRoutingNumber.IsNullOrWhiteSpace())
                throw new NACHAConfigurationException("Destination Bank Routing Number must be not empty.");
            string v = DestinationBankRoutingNumber;
            if (!(((v.Length == 9 && !v.Where(c => !Char.IsDigit(c)).Any()) /*|| (v.Length == 10 && v[0] == ' ' && !v.Skip(1).Where(c => !Char.IsDigit(c)).Any())*/)))
            {
                throw new NACHAConfigurationException("Invalid Destination Bank Routing Number specified.");
            }
            if (OriginatingCompanyId.IsNullOrWhiteSpace())
                throw new NACHAConfigurationException("Originating Company Id must be not empty.");
            v = OriginatingCompanyId;
            if (!(((v.Length == 9 && !v.Where(c => !Char.IsDigit(c)).Any()) || (v.Length == 10 && v[0] == ' ' && !v.Skip(1).Where(c => !Char.IsDigit(c)).Any()) || (v.Length == 10 && !v.Where(c => !Char.IsDigit(c)).Any()))))
            {
                throw new NACHAConfigurationException("Invalid Originating Company Id specified.");
            }
            if (FileIDModifier.ToString().IsNullOrWhiteSpace())
                throw new NACHAConfigurationException("FileIDModifier must be not empty.");
            if (DestinationBankName.IsNullOrWhiteSpace())
                throw new NACHAConfigurationException("Destination Bank Name must be not empty.");
            if (OriginatingCompanyName.ToString().IsNullOrWhiteSpace())
                throw new NACHAConfigurationException("Originating Company Name must be not empty.");

        }
    }
}
