﻿using SpiTech.ApplicationCore.Nacha.Core.Records;

namespace SpiTech.ApplicationCore.Nacha.Core.Shared
{
    internal class NACHARunningStat
    {
        public uint TraceNumber { get; set; }
        public uint BatchCount { get; set; }
        public uint TotalNoOfRecord { get; set; }
        public uint AddendaEntryCount { get; set; }
        public ulong EntryHash { get; set; }
        public decimal TotalDebitEntryDollarAmount { get; set; }
        public decimal TotalCreditEntryDollarAmount { get; set; }

        public NACHARunningStat()
        {
            TotalNoOfRecord = 2;
        }

        public uint NewBatch()
        {
            return ++BatchCount;
        }

        public void IncRecordCountBy(uint recCount = 1)
        {
            TotalNoOfRecord += recCount;
        }

        public void IncAddendaRecordCountBy(uint recCount = 1)
        {
            AddendaEntryCount += recCount;
        }

        public void UpdateStat(NACHAEntryDetailRecord record, bool isDebit = false)
        {
            IncRecordCountBy(1);
            IncAddendaRecordCountBy(1);
            EntryHash += record.ReceivingDFIID;
            if (isDebit)
                TotalDebitEntryDollarAmount += record.Amount;
            else
                TotalCreditEntryDollarAmount += record.Amount;
        }

        public void UpdateStat(NACHAAddendaRecord record)
        {
            IncRecordCountBy(1);
            IncAddendaRecordCountBy(1);
        }
        public void UpdateStat(NACHAReturnAddendaRecord record)
        {
            IncRecordCountBy(1);
            IncAddendaRecordCountBy(1);
        }

        public void UpdateStat(NACHARunningStat src)
        {
            if (this == src) return;

            IncRecordCountBy(src.TotalNoOfRecord);
            IncAddendaRecordCountBy(src.AddendaEntryCount);
            EntryHash += src.EntryHash;
            TotalDebitEntryDollarAmount += src.TotalDebitEntryDollarAmount;
            TotalCreditEntryDollarAmount += src.TotalCreditEntryDollarAmount;
        }
    }
}
