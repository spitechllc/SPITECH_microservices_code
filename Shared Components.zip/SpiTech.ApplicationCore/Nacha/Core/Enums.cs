﻿namespace SpiTech.ApplicationCore.Nacha.Core
{
    public enum ChoRecordTypeCode
    {
        FileHeader = 1,
        BatchHeader = 5,
        EntryDetail = 6,
        Addenda = 7,
        BatchControl = 8,
        FileControl = 9
    }

    public enum ChoEntryDetailTraceSource
    {
        DestinationBankRoutingNumber = 0,
        OriginatingDFI = 1
    }
}
