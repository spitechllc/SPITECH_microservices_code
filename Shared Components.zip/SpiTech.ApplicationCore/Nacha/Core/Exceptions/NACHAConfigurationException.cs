﻿using System;
using System.Runtime.Serialization;

namespace SpiTech.ApplicationCore.Nacha.Core.Exceptions
{
    [Serializable]
    public class NACHAConfigurationException : ApplicationException
    {
        public NACHAConfigurationException()
            : base()
        {
        }

        public NACHAConfigurationException(string message)
            : base(message)
        {
        }

        public NACHAConfigurationException(string message, Exception e)
            : base(message, e)
        {
        }

        protected NACHAConfigurationException(SerializationInfo si, StreamingContext sc)
            : base(si, sc)
        {
        }
    }
}
