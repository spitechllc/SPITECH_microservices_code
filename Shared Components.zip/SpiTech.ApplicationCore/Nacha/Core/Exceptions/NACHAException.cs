﻿using System;
using System.Runtime.Serialization;

namespace SpiTech.ApplicationCore.Nacha.Core.Exceptions
{
    [Serializable]
    public class NACHAException : ApplicationException
    {
        public NACHAException()
            : base()
        {
        }

        public NACHAException(string message)
            : base(message)
        {
        }

        public NACHAException(string message, Exception e)
            : base(message, e)
        {
        }

        protected NACHAException(SerializationInfo si, StreamingContext sc)
            : base(si, sc)
        {
        }
    }
}
