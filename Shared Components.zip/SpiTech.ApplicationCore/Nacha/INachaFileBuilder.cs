﻿using SpiTech.ApplicationCore.Domain.Configs;
using SpiTech.ApplicationCore.Domain.Nacha;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Nacha
{
    public interface INachaFileBuilder
    {
        NachaFileBytesModel GetBytes(NachaConfig config, List<NachaModel> accounts);

        Task<bool> UploadFileInSftp(NachaFileBytesModel nachaFileBytes, bool uploadToSftp, SftpConfig sftpConfig);
    }
}