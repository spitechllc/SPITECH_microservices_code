﻿using SpiTech.ApplicationCore.Domain.Entities;
using SpiTech.ApplicationCore.UnitOfWorks;

namespace SpiTech.ApplicationCore.Repositories
{
    public class GenericRepository<TEntity> : Repository<TEntity> where TEntity : BaseEntity
    {
        public GenericRepository(IBaseUnitOfWork unitOfWork, System.IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }
    }
}
