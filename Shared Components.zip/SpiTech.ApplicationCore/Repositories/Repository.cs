﻿using AutoMapper;
using Dapper.Contrib.Extensions;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Domain.Entities;
using SpiTech.ApplicationCore.UnitOfWorks;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Repositories
{
    public abstract class RepositoryBase : IRepository
    {
        public IBaseUnitOfWork UnitOfWork { get; private set; }
        protected IDbConnection DbConnection { get; private set; }
        protected IDbTransaction DbTransaction { get; private set; }
        protected readonly IUserAuthenticationProvider userAuthenticationProvider;

        public IMapper Mapper { get; private set; }

        public RepositoryBase(IBaseUnitOfWork unitOfWork, IServiceProvider serviceProvider)
        {
            UnitOfWork = unitOfWork;
            DbConnection = unitOfWork.DbConnection;
            DbTransaction = unitOfWork.DbTransaction;
            Mapper = serviceProvider.GetService<IMapper>();
            this.userAuthenticationProvider = serviceProvider.GetService<IUserAuthenticationProvider>();
        }
    }

    public abstract class Repository<TEntity> : RepositoryBase, IRepository<TEntity> where TEntity : BaseEntity
    {
        public Repository(IBaseUnitOfWork unitOfWork, IServiceProvider serviceProvider) : base(unitOfWork, serviceProvider)
        {
        }

        public virtual async Task<int> Add(TEntity entity)
        {
            entity.CreatedOn = DateTime.UtcNow;
            entity.CreatedBy = GetActionUserId();
            long result = UnitOfWork.DbConnection.Insert<TEntity>(entity, UnitOfWork.DbTransaction);
            return await Task.FromResult((int)result);
        }

        public virtual async Task<long> Insert(TEntity entity)
        {
            entity.CreatedBy = GetActionUserId();
            entity.CreatedOn = DateTime.UtcNow;
            long result = UnitOfWork.DbConnection.Insert<TEntity>(entity, UnitOfWork.DbTransaction);
            return await Task.FromResult(result);
        }
        public virtual async Task<IEnumerable<TEntity>> GetAll()
        {
            return await UnitOfWork.DbConnection.GetAllAsync<TEntity>(UnitOfWork.DbTransaction);
        }

        public virtual async Task<TEntity> Get(object id)
        {
            return await UnitOfWork.DbConnection.GetAsync<TEntity>(id, UnitOfWork.DbTransaction);
        }

        public virtual async Task<bool> Update(TEntity entity)
        {
            entity.UpdatedBy = GetActionUserId();
            entity.UpdatedOn = DateTime.UtcNow;
            bool result = UnitOfWork.DbConnection.Update<TEntity>(entity, UnitOfWork.DbTransaction, excludeProperties: new [] { "CreatedBy", "CreatedOn" });
            return await Task.FromResult(result);
        }

        public virtual async Task<bool> Delete(TEntity entity)
        {
            return await UnitOfWork.DbConnection.DeleteAsync(entity, UnitOfWork.DbTransaction);
        }

        protected int GetActionUserId()
        {
            var user = userAuthenticationProvider.GetUserAuthentication();
            return user?.UserId ?? 0;
        }
    }
}
