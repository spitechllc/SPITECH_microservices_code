﻿using AutoMapper;
using SpiTech.ApplicationCore.Domain.Entities;
using SpiTech.ApplicationCore.UnitOfWorks;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Repositories
{
    public interface IRepository
    {
        IBaseUnitOfWork UnitOfWork { get; }
        IMapper Mapper { get; }
    }
    public interface IRepository<TEntity> : IRepository where TEntity : BaseEntity
    {
        Task<IEnumerable<TEntity>> GetAll();
        Task<TEntity> Get(object id);
        Task<int> Add(TEntity entity);
        Task<long> Insert(TEntity entity);
        Task<bool> Update(TEntity entity);
        Task<bool> Delete(TEntity entity);
    }
}
