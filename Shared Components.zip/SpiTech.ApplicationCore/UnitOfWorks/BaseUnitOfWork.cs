﻿using SpiTech.ApplicationCore.Domain.Entities;
using SpiTech.ApplicationCore.Repositories;
using StackExchange.Profiling;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.UnitOfWorks
{
    public abstract class BaseUnitOfWork : IBaseUnitOfWork
    {
        private bool _disposed;
        private readonly string connectionString;
        private IDbConnection dbConnection;
        private IDbTransaction transaction;
        private readonly IsolationLevel isolationLevel;
        protected readonly System.IServiceProvider serviceProvider;
        private readonly Dictionary<Type, IRepository> repositoryList = new();

        public string Id { get; set; }
        public IDbTransaction DbTransaction
        {
            get
            {
                if (dbConnection == null)
                {
                    Reset();
                }
                else if (dbConnection.State == ConnectionState.Closed)
                {
                    Reset();
                }
                else if (transaction?.Connection == null)
                {
                    Reset();
                }

                return transaction;
            }
        }

        public IDbConnection DbConnection => DbTransaction.Connection;

        public BaseUnitOfWork(string connectionString,
            System.IServiceProvider serviceProvider,
            IsolationLevel isolationLevel)
        {
            Id = Guid.NewGuid().ToString();
            this.serviceProvider = serviceProvider;
            this.isolationLevel = isolationLevel;
            this.connectionString = connectionString;
            InitializeConnection();
        }

        private void Reset()
        {
            transaction?.Dispose();
            dbConnection?.Dispose();
            InitializeConnection();
            ResetRepositories();
        }

        private void InitializeConnection()
        {
            var connection = new SqlConnection(connectionString);
            dbConnection = new StackExchange.Profiling.Data.ProfiledDbConnection(connection, MiniProfiler.Current);
            dbConnection.Open();

            if (transaction?.Connection == null)
            {
                transaction = dbConnection.BeginTransaction();
            }
        }

        public IRepository<TEntity> GetRepository<TEntity>() where TEntity : BaseEntity
        {
            Type type = typeof(TEntity);

            if (!repositoryList.ContainsKey(type))
            {
                repositoryList.Add(type, new GenericRepository<TEntity>(this, this.serviceProvider));
            }

            return repositoryList[type] as IRepository<TEntity>;
        }

        public void Rollback()
        {
            transaction?.Rollback();
            transaction?.Dispose();
            transaction = null;
            //transaction = dbConnection?.BeginTransaction(isolationLevel);
            //ResetRepositories();
        }

        //private void CloseConnection()
        //{
        //    transaction?.Dispose();
        //    dbConnection?.Close();
        //    dbConnection?.Dispose();
        //    dbConnection = null;
        //    transaction = null;
        //}

        public void Commit()
        {
            try
            {
                transaction?.Commit();
            }
            catch (Exception)
            {
                if (transaction?.Connection != null)
                {
                    transaction?.Rollback();
                }

                throw;
            }
            finally
            {
                transaction?.Dispose();
                transaction = null;
                //transaction = dbConnection?.BeginTransaction(isolationLevel);
                //ResetRepositories();
            }
        }

        public abstract void ResetRepositories();

        public async Task Execute(Func<Task> action)
        {
            try
            {
                await action();
                Commit();
            }
            catch (Exception)
            {
                Rollback();
                throw;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        ~BaseUnitOfWork() => Dispose(false);

        protected virtual void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                CloseConnection();
            }

            transaction = null;
            dbConnection = null;

            _disposed = true;
        }

        private void CloseConnection()
        {
            transaction?.Dispose();
            if (dbConnection != null)
            {
                if (dbConnection.State == ConnectionState.Open)
                {
                    dbConnection.Close();
                }
            }
            dbConnection?.Dispose();
            transaction = null;
            dbConnection = null;
        }
    }
}
