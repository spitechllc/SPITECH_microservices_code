﻿using System;
using System.Data;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.UnitOfWorks
{
    public interface IBaseUnitOfWork : IDisposable
    {
        IDbTransaction DbTransaction { get; }
        IDbConnection DbConnection { get; }
        Task Execute(Func<Task> action);

        void Rollback();
        void Commit();
    }
}
