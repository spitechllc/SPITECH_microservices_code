﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SpiTech.Application.Logging.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.BackgroudSerices
{
    public abstract class ScopeJobService : BackgroundService
    {
        protected readonly ILogger<ScopeJobService> logger;
        protected readonly IServiceProvider serviceProvider;

        public ScopeJobService(ILogger<ScopeJobService> logger, IServiceProvider serviceProvider)
        {
            this.logger = logger;
            this.serviceProvider = serviceProvider;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    using IServiceScope scope = serviceProvider.CreateScope();
                    CreateScope(scope);

                    await ExecuteScheduleTaskAsync(stoppingToken);
                }
                catch (Exception ex)
                {
                    logger.Error(ex, $"Error at: {DateTimeOffset.Now}");
                }

                logger.Info("Ended at: {time}", DateTimeOffset.Now);
            }
        }

        protected abstract void CreateScope(IServiceScope serviceScope);

        protected abstract Task ExecuteScheduleTaskAsync(CancellationToken stoppingToken);
    }
}
