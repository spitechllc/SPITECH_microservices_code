﻿using Microsoft.Extensions.DependencyInjection;
using SpiTech.Application.Logging.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.BackgroudSerices
{
    public abstract class SchedulerJobService : ScopeJobService
    {
        private string scheduleCron;

        public SchedulerJobService(ILogger<ScopeJobService> logger, IServiceProvider serviceProvider)
            : base(logger, serviceProvider)
        {
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    using IServiceScope scope = serviceProvider.CreateScope();
                    scheduleCron = await GetScheduleCron(scope);
                    CreateScope(scope);
                    // Schedule the job.
                    await WaitForNextSchedule(scheduleCron, stoppingToken);

                    await ExecuteScheduleTaskAsync(stoppingToken);
                }
                catch (Exception ex)
                {
                    logger.Error(ex, $"Scheduler Error at: {DateTimeOffset.Now}");
                }
                logger.Info("Scheduler running at: {time}", DateTimeOffset.Now);
            }
        }

        protected abstract Task<string> GetScheduleCron(IServiceScope serviceScope);

        private async Task WaitForNextSchedule(string cronExpression, CancellationToken stoppingToken)
        {
            NCrontab.CrontabSchedule parsedExp = NCrontab.CrontabSchedule.Parse(cronExpression);
            DateTime currentUtcTime = DateTimeOffset.UtcNow.UtcDateTime;
            DateTime occurenceTime = parsedExp.GetNextOccurrence(currentUtcTime);

            TimeSpan delay = occurenceTime.Subtract(currentUtcTime);
            logger.Info("The run is delayed for {delay}. Current time: {time}", delay, DateTimeOffset.Now);

            await Task.Delay(delay, stoppingToken);
        }
    }
}
