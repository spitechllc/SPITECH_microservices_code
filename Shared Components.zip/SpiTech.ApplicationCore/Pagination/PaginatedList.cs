﻿using System;
using System.Collections.Generic;

namespace SpiTech.ApplicationCore.Pagination
{
    public class PaginatedList<TResult>
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public int TotalCount { get; set; }

        public int TotalPages => PageSize > 0 ? (int)Math.Ceiling(TotalCount / (double)PageSize) : TotalCount > 0 ? 1 : 0;

        public List<TResult> Data { get; set; } = new List<TResult>();

        public bool HasPreviousPage => PageIndex > 1;

        public bool HasNextPage => (PageIndex < 1 ? 1 : PageIndex) < TotalPages;
    }
}
