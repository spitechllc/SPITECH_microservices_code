﻿using Polly;
using System;
using System.Net.Http;

namespace SpiTech.ApplicationCore.HttpClients
{
    public static class HttpClientExtension
    {
        public static Polly.IAsyncPolicy<HttpResponseMessage> GetRetryPolicy()
        {
            return Polly.Extensions.Http.HttpPolicyExtensions
              .HandleTransientHttpError()
              .WaitAndRetryAsync(2, retryAttempt => TimeSpan.FromSeconds(3));
        }
        //public static Polly.IAsyncPolicy<HttpResponseMessage> GetReauthorizationPolicy()
        //{
        //    return Polly.Extensions.Http.HttpPolicyExtensions
        //      .HandleTransientHttpError()
        //      .OrResult(msg => msg.StatusCode == System.Net.HttpStatusCode.Unauthorized).
        //      .WaitAndRetryAsync(3, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));
        //}


        //private static void PerformReauthorization()
        //{

        //}
    }
}
