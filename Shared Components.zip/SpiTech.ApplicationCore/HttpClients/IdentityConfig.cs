﻿using Flurl;

namespace SpiTech.ApplicationCore.HttpClients
{
    public class IdentityConfig
    {
        public string BaseUrl { get; set; }
        public string TokenEndpoint { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string Scope { get; set; }
        public string TokenEndpointURL => Url.Combine(BaseUrl, TokenEndpoint);

    }
}
