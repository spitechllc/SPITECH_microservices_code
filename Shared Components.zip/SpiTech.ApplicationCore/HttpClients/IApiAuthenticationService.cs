﻿using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.HttpClients
{
    public interface IApiAuthenticationService
    {
        Task<string> RetrieveToken(bool fromCache);
    }
}
