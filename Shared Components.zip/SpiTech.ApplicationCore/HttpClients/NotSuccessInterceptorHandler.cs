﻿using SpiTech.Application.Logging.Interfaces;
using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.HttpClients
{
    public class NotSuccessInterceptorHandler : DelegatingHandler
    {
        private readonly ILogger<NotSuccessInterceptorHandler> logger;

        public NotSuccessInterceptorHandler(ILogger<NotSuccessInterceptorHandler> logger)
        {
            this.logger = logger;
        }

        protected override HttpResponseMessage Send(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            return SendAsync(request, cancellationToken).Result;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            HttpResponseMessage response = await base.SendAsync(request, cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                try
                {
                    if (request.RequestUri != null)
                    {
                        string requestContent = "";
                        string responseContent = "";

                        try
                        {
                            if (request.Content != null)
                            {
                                requestContent = await request.Content.ReadAsStringAsync();
                            }
                        }
                        catch (Exception ex)
                        {
                            logger.Error(ex, "Error while reading request Content");
                        }

                        try
                        {
                            if (response.Content != null)
                            {
                                responseContent = await response.Content.ReadAsStringAsync();
                            }
                        }
                        catch (Exception ex)
                        {
                            logger.Error(ex, "Error while reading response Content");
                        }

                        if (response.StatusCode == System.Net.HttpStatusCode.BadRequest || response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                        {
                            //logger.Warn("Request validation Details:", request.RequestUri.ToString(), request.Headers, requestContent, responseContent);
                            logger.Warn("Request validation Details:", request.RequestUri.ToString(), requestContent, responseContent);
                        }
                        else
                        {
                            //logger.Error(new System.Exception("Request Error Details:"), "Request Error Details:", request.RequestUri.ToString(), request.Headers, requestContent, responseContent);
                            logger.Error(new Exception("Request Error Details:"), "Request Error Details:", "StatusCode:" + response.StatusCode, request.Headers, response.Headers, request.RequestUri.ToString(), requestContent, responseContent);
                        }
                    }
                }
                catch (Exception ex)
                {
                    logger.Error(ex);
                }
            }

            return response;
        }
    }
}
