﻿using SpiTech.Application.Logging.Interfaces;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.HttpClients
{
    public class AuthenticationInterceptorHandler : DelegatingHandler
    {
        private readonly IApiAuthenticationService apiAuthenticationService;
        private readonly ILogger<AuthenticationInterceptorHandler> _logger;

        public AuthenticationInterceptorHandler(IApiAuthenticationService apiAuthenticationService,
             ILogger<AuthenticationInterceptorHandler> logger)
        {
            this.apiAuthenticationService = apiAuthenticationService;
            _logger = logger;
        }

        protected override HttpResponseMessage Send(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            return SendAsync(request, cancellationToken).Result;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            string token = await apiAuthenticationService.RetrieveToken(true);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            HttpResponseMessage response = await base.SendAsync(request, cancellationToken);
            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                token = await apiAuthenticationService.RetrieveToken(false);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
                response = await base.SendAsync(request, cancellationToken);
            }

            return response;
        }
    }
}
