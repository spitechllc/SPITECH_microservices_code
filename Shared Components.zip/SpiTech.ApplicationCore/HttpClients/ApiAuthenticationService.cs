﻿using IdentityModel.Client;
using Microsoft.Extensions.Caching.Memory;
using System.Net.Http;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.HttpClients
{
    public class ApiAuthenticationService : IApiAuthenticationService
    {
        private readonly IHttpClientFactory httpClientFactory;
        private readonly IMemoryCache _memoryCache;
        private readonly IdentityConfig identityConfig;
        private const string TokenKey = "PapiPay_Token";
        public ApiAuthenticationService(IHttpClientFactory httpClientFactory,
                                        IMemoryCache memoryCache,
                                        IdentityConfig identityConfig)
        {
            this.httpClientFactory = httpClientFactory;
            _memoryCache = memoryCache;
            this.identityConfig = identityConfig;
        }

        public async Task<string> RetrieveToken(bool fromCache = true)
        {
            if (fromCache && _memoryCache.TryGetValue(TokenKey, out string token))
            {
                if (!string.IsNullOrWhiteSpace(token))
                {
                    return token;
                }
            }

            HttpClient serverClient = httpClientFactory.CreateClient();

            TokenResponse tokenResponse = await serverClient.RequestClientCredentialsTokenAsync(
                new ClientCredentialsTokenRequest
                {
                    Address = identityConfig.TokenEndpointURL,
                    ClientId = "spitech_m2m",// identityConfig.ClientId,
                    ClientSecret = identityConfig.ClientSecret,
                    Scope = identityConfig.Scope,
                });

            _memoryCache.Set(TokenKey, tokenResponse.AccessToken);

            return tokenResponse.AccessToken;
        }
    }
}
