﻿using Dapper;
using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Database
{
    public static class TableValuedExtension
    {

        public static SqlMapper.ICustomQueryParameter GetTableValuedParameter(this int[] list, string tableTypeName, string columnName)
        {
            if (list == null)
            {
                list = new int[] { };
            }

            return CreateSqlDataRecord(list, columnName).AsTableValuedParameter(tableTypeName);
        }

        public static SqlMapper.ICustomQueryParameter GetTableValuedParameter(this string[] list, string tableTypeName, string columnName)
        {
            if (list == null)
            {
                list = new string[] { };
            }

            return CreateSqlDataRecord(list.Distinct(), columnName).AsTableValuedParameter(tableTypeName);
        }


        private static IEnumerable<SqlDataRecord> CreateSqlDataRecord(IEnumerable<string> list, string columnName)
        {
            var metaData = new SqlMetaData(columnName, SqlDbType.VarChar, 200);
            var record = new SqlDataRecord(metaData);
            foreach (var item in list)
            {
                record.SetString(0, item);
                yield return record;
            }
        }

        private static IEnumerable<SqlDataRecord> CreateSqlDataRecord(IEnumerable<int> list, string columnName)
        {
            var metaData = new SqlMetaData(columnName, SqlDbType.Int);
            var record = new SqlDataRecord(metaData);
            foreach (var item in list)
            {
                record.SetInt32(0, item);
                yield return record;
            }
        }
    }
}
