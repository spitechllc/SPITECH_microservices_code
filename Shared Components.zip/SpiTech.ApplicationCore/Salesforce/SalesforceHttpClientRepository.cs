﻿using Microsoft.Extensions.Options;
using SpiTech.ApplicationCore.Domain.Helper;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Salesforce
{
    public class SalesforceHttpClientRepository : ISalesforceHttpClientRepository
    {
        private readonly SalesforceOptions _Option;


        public SalesforceHttpClientRepository(IOptionsMonitor<SalesforceOptions> options)
        {
            _Option = options.CurrentValue;


        }
        public async Task<HttpResponseMessage> SendRequest(HttpMethod method, string entity,
            HttpContent content = null, string additional = null, string query = "")
        {
            using System.Net.Http.HttpClient httpClient = new();
            await SetClient(httpClient, $"{entity}{(string.IsNullOrEmpty(additional) ? string.Empty : $"/{additional}")}", query);
            return method == HttpMethod.Get ? await httpClient.GetAsync(httpClient.BaseAddress)
                 : method == HttpMethod.Delete ? await httpClient.DeleteAsync(httpClient.BaseAddress)
                 : method == HttpMethod.Post ? await httpClient.PostAsync(httpClient.BaseAddress, content)
                 : method == HttpMethod.Put ? await httpClient.PutAsync(httpClient.BaseAddress, content)
                 : await PatchClient(httpClient, content);
        }

        private async Task<HttpResponseMessage> PatchClient(System.Net.Http.HttpClient httpClient, HttpContent content)
        {
            HttpRequestMessage request = new(new HttpMethod("PATCH"), httpClient.BaseAddress) { Content = content };
            return await httpClient.SendAsync(request);
        }
        private async Task SetClient(System.Net.Http.HttpClient client, string entity, string query)
        {
            string baseurl = _Option.DomainUrl;
            client.BaseAddress = new Uri(baseurl + entity + (string.IsNullOrEmpty(query) ? string.Empty : "?" + query));

            await SetCredentials(client);
        }

        private async Task SetCredentials(HttpClient client)
        {

            SalesforceTokenResponse credential = new();

            using (HttpClient httpClient = new())
            {
                List<KeyValuePair<string, string>> pairs = new()
                {
                      new KeyValuePair<string, string>("client_id", _Option.Client_Id),
                      new KeyValuePair<string, string>("client_secret", _Option.Client_Secret),
                      new KeyValuePair<string, string>("refresh_token", _Option.Refresh_Token),
                      new KeyValuePair<string, string>("grant_type", "refresh_token")
                    };

                FormUrlEncodedContent content = new(pairs);
                HttpResponseMessage response = await httpClient.PostAsync(_Option.TokenEndpoint, content);


                if (response.IsSuccessStatusCode)
                {
                    string buffer = await response.Content.ReadAsStringAsync();

                    credential = Newtonsoft.Json.JsonConvert.DeserializeObject<SalesforceTokenResponse>(buffer);

                }
                else
                {
                    throw new InvalidOperationException("Couldn't retrieve auth data");
                }


            }


            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", credential.access_token);
        }
    }
}
