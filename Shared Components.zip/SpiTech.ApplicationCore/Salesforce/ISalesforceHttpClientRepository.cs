﻿using System.Net.Http;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Salesforce
{
    public interface ISalesforceHttpClientRepository
    {
        Task<HttpResponseMessage> SendRequest(HttpMethod method, string entity, HttpContent content = null,
            string additional = null, string query = "");

    }
}
