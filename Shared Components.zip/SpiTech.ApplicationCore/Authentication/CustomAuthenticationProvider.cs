﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.SignalR;
using SpiTech.Application.Logging.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.ApplicationCore.Authentication
{
    internal class CustomAuthenticationProvider : IAuthenticationProvider
    {
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly ILogger<CustomAuthenticationProvider> logger;

        public CustomAuthenticationProvider(IHttpContextAccessor httpContextAccessor, ILogger<CustomAuthenticationProvider> logger)
        {
            this.httpContextAccessor = httpContextAccessor;
            this.logger = logger;
        }

        public UserAuthentication GetUserAuthentication()
        {
            UserAuthentication user = null;
            try
            {
                if (httpContextAccessor != null &&
                    httpContextAccessor.HttpContext != null &&
                    httpContextAccessor.HttpContext.User != null &&
                    httpContextAccessor.HttpContext.User.Identity != null &&
                    httpContextAccessor.HttpContext.User.Identity.IsAuthenticated &&
                    httpContextAccessor.HttpContext.User.Claims != null &&
                    httpContextAccessor.HttpContext.User.Claims.Any())
                {
                    var subClaim = httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(i => i.Type == "sub");

                    if (subClaim != null && !string.IsNullOrWhiteSpace(subClaim.Value))
                    {
                        user = new UserAuthentication
                        {
                            UserId = int.Parse(subClaim.Value)
                        };
                    }
                    
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }

            return user;
        }

        public TenantAuthentication GetTenantAuthentication()
        {
            TenantAuthentication tenant = new TenantAuthentication
            {
                //UserId = int.Parse(subClaim.Value)
            };

            try
            {
                if (httpContextAccessor != null &&
                    httpContextAccessor.HttpContext != null &&
                    httpContextAccessor.HttpContext.User != null &&
                    httpContextAccessor.HttpContext.User.Identity != null &&
                    httpContextAccessor.HttpContext.User.Identity.IsAuthenticated &&
                    httpContextAccessor.HttpContext.User.Claims != null &&
                    httpContextAccessor.HttpContext.User.Claims.Any())
                {
                    var clientIdClaim = httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(i => i.Type == "client_id");

                    if (clientIdClaim != null && !string.IsNullOrWhiteSpace(clientIdClaim.Value))
                    {
                        tenant.ClientId = clientIdClaim.Value;
                    }

                    var tenantIdClaim = httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(i => i.Type == IdentityClaim.TenantId);

                    if (tenantIdClaim != null && !string.IsNullOrWhiteSpace(tenantIdClaim.Value))
                    {
                        tenant.TenantId = int.Parse(tenantIdClaim.Value);
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }

            return tenant;
        }
        public TenantAuthentication GetTenantAuthentication(HubCallerContext context)
        {
            TenantAuthentication tenant = new TenantAuthentication
            {
                //UserId = int.Parse(subClaim.Value)
            };

            try
            {
                if (context != null &&
                    context.User != null &&
                    context.User.Identity != null &&
                    context.User.Identity.IsAuthenticated &&
                    context.User.Claims != null &&
                    context.User.Claims.Any())
                {
                    var clientIdClaim = context.User.Claims.FirstOrDefault(i => i.Type == "client_id");

                    if (clientIdClaim != null && !string.IsNullOrWhiteSpace(clientIdClaim.Value))
                    {
                        tenant.ClientId = clientIdClaim.Value;
                    }

                    var tenantIdClaim = context.User.Claims.FirstOrDefault(i => i.Type == IdentityClaim.TenantId);

                    if (tenantIdClaim != null && !string.IsNullOrWhiteSpace(tenantIdClaim.Value))
                    {
                        tenant.TenantId = int.Parse(tenantIdClaim.Value);
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }

            return tenant;
        }
        public void ValidateApiAccess(int userId, string apiResourceId)
        {
            if (userId == 0)
            {
                return;
            }

            var tokenUserId = 0;

            try
            {
                if (httpContextAccessor != null &&
                    httpContextAccessor.HttpContext != null &&
                    httpContextAccessor.HttpContext.User != null &&
                    httpContextAccessor.HttpContext.User.Identity != null &&
                    httpContextAccessor.HttpContext.User.Identity.IsAuthenticated &&
                    httpContextAccessor.HttpContext.User.Claims != null &&
                    httpContextAccessor.HttpContext.User.Claims.Any())
                {
                    var clientId = httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(i => i.Type == "client_id");

                    if (clientId != null && !string.IsNullOrEmpty(clientId.Value) && clientId.Value.Equals("spitech_m2m", StringComparison.InvariantCultureIgnoreCase))
                    {
                        return;
                    }

                    var apiResourceClaims = httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(t => t.Type == IdentityClaim.ApiResourceClaim)?.Value;

                    if ((!string.IsNullOrEmpty(apiResourceClaims)) && apiResourceClaims.Split(",").Any(t => t.Equals(apiResourceId, StringComparison.InvariantCultureIgnoreCase)))
                    {
                        return;
                    }

                    var subClaim = httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(i => i.Type == "sub");

                    if (subClaim != null && !string.IsNullOrWhiteSpace(subClaim.Value))
                    {
                        tokenUserId = int.Parse(subClaim.Value);
                    }
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                throw;
            }

            if (tokenUserId > 0 && tokenUserId != userId)
            {
                logger.Warn($"Token UserId:{tokenUserId}, UserId:{userId}");
                throw new UnauthorizedAccessException("Unauthorize UserAccess");
            }
        }
    }
}
