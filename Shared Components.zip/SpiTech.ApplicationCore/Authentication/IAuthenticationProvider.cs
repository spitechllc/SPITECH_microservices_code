﻿using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Authentication
{
    public interface IAuthenticationProvider
    {
        TenantAuthentication GetTenantAuthentication();
        TenantAuthentication GetTenantAuthentication(HubCallerContext context);
        void ValidateApiAccess(int userId, string apiResourceId);
    }
}
