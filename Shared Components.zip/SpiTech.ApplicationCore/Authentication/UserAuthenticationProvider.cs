﻿using Microsoft.AspNetCore.Http;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using System;
using System.Linq;

namespace SpiTech.ApplicationCore.Authentication
{
    public class UserAuthenticationProvider : IUserAuthenticationProvider
    {
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly ILogger<UserAuthenticationProvider> logger;

        public UserAuthenticationProvider(IHttpContextAccessor httpContextAccessor, ILogger<UserAuthenticationProvider> logger)
        {
            this.httpContextAccessor = httpContextAccessor;
            this.logger = logger;
        }
        public UserAuthentication GetUserAuthentication()
        {
            UserAuthentication user = null;
            try
            {
                if (httpContextAccessor != null &&
                    httpContextAccessor.HttpContext != null &&
                    httpContextAccessor.HttpContext.User != null &&
                    httpContextAccessor.HttpContext.User.Identity != null &&
                    httpContextAccessor.HttpContext.User.Identity.IsAuthenticated &&
                    httpContextAccessor.HttpContext.User.Claims != null &&
                    httpContextAccessor.HttpContext.User.Claims.Any())
                {
                    var subClaim = httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(i => i.Type == "sub");

                    if (subClaim != null && !string.IsNullOrWhiteSpace(subClaim.Value))
                    {
                          if (httpContextAccessor.HttpContext.User.Identity.IsAuthenticated)
                          {
                              logger.Warn($"User IsAuthenticated"); 
                        }
                        logger.Warn($"Identifier get");
                        user = new UserAuthentication
                        {
                            UserId = int.Parse(subClaim.Value)
                        };
                    logger.Warn($"14", + user.UserId);}
                    logger.Warn($"13");
                }
                else
                {
                    logger.Warn($"17");
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return user;
        }

        public void ValidateUserAccess(int userId)
        {
            //if (!httpContextAccessor.HttpContext.User.Claims.First(i => i.Type == "client_id").Value.Equals("SpiTech_m2m",System.StringComparison.InvariantCultureIgnoreCase))
            //{

            //    UserAuthentication user = null;

            //    try
            //    {
            //        user = GetUserAuthentication();
            //    }
            //    catch(Exception ex)
            //    {
            //        logger.Error(ex);
            //    }

            //    if (user !=null && user.UserId != userId)
            //    {
            //        throw new ValidationException(new FluentValidation.Results.ValidationFailure("UserId", "Unauthorize access"));
            //    }
            //}
        }
    }
}
