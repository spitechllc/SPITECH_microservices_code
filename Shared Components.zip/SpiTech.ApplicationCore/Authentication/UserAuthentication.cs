﻿namespace SpiTech.ApplicationCore.Authentication
{
    public class UserAuthentication
    {
        public int UserId { get; set; }
    }
}
