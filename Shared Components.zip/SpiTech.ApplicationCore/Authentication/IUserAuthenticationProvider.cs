﻿namespace SpiTech.ApplicationCore.Authentication
{
    public interface IUserAuthenticationProvider
    {
        UserAuthentication GetUserAuthentication();
        void ValidateUserAccess(int userId);
    }
}
