﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.ExceptionHandlers
{
    internal class GlobalExceptionHandlerMiddleware
    {
        private static readonly JsonSerializerOptions _serializerOptions = new() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };

        private readonly RequestDelegate next;
        private readonly ILogger<GlobalExceptionHandlerMiddleware> logger;
        private readonly ICorrelationIdAccessor correlationIdAccessor;

        public GlobalExceptionHandlerMiddleware(RequestDelegate next,
            ILogger<GlobalExceptionHandlerMiddleware> logger,
            ICorrelationIdAccessor correlationIdAccessor)
        {
            this.next = next;
            this.logger = logger;
            this.correlationIdAccessor = correlationIdAccessor;
        }
        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await next(context);
            }
            catch (Exception ex)
            {
                await HandleException(context, ex);
            }
        }

        private async Task HandleException(HttpContext context, Exception ex)
        {
            HttpResponse response = context.Response;
            response.ContentType = "application/json";
            object responseObjet = null;


            switch (ex)
            {
                case ValidationException e:
                    responseObjet = new ValidationProblemDetails(e.Errors)
                    {
                        Type = "Validation",
                        Title = $"Validation Error (CorrelationId= {correlationIdAccessor.GetCorrelationId()})"
                    };
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    logger.Trace("HandleValidationException", e.Errors);
                    break;
                case BusinessRuleException e:
                    responseObjet = new ProblemDetails()
                    {
                        Type = "BusinessRule",
                        Title = $"Business Rule Error (CorrelationId= {correlationIdAccessor.GetCorrelationId()}).",
                        Detail = e?.Message
                    };
                    response.StatusCode = (int)HttpStatusCode.BadRequest;
                    break;
                case NotFoundException e:
                    responseObjet = new ProblemDetails()
                    {
                        Type = "NotFound",
                        Title = $"The specified resource was not found (CorrelationId= {correlationIdAccessor.GetCorrelationId()}).",
                        Detail = e?.Message
                    };
                    response.StatusCode = (int)HttpStatusCode.NotFound;
                    break;
                case UnauthorizedAccessException e:
                    responseObjet = new ProblemDetails
                    {
                        Type = "UnauthorizedAccess",
                        Status = StatusCodes.Status401Unauthorized,
                        Title = $"Unauthorized (CorrelationId= {correlationIdAccessor.GetCorrelationId()})"
                    };
                    response.StatusCode = (int)HttpStatusCode.Unauthorized;
                    break;
                default:
                    // unhandled error
                    response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    break;
            }

            string result = JsonSerializer.Serialize(responseObjet);
            await response.WriteAsync(result);
        }

        private Task WriteResponse(HttpContext context, Exception exception)
        {
            if (exception is BusinessRuleException || exception is ValidationException)
            {
                string result = JsonSerializer.Serialize(new
                {
                    ErrorType = "Business Rule",
                    exception.Message
                }, _serializerOptions);
                context.Response.StatusCode = 400;
                return context.Response.WriteAsync(result);
            }
            else
            {
                string result = JsonSerializer.Serialize(new
                {
                    ErrorType = "Execution",
                    Message = GetExceptions(exception)
                }, _serializerOptions);

                context.Response.StatusCode = 500;
                return context.Response.WriteAsync(result);
            }
        }

        private string GetExceptions(Exception exception)
        {
            List<string> exceptions = new();
            Exception currentException = exception;

            do
            {
                exceptions.Add(exception.Message);
                currentException = currentException.InnerException;
            }
            while (currentException != null);

            return string.Join("\n", exceptions);
        }
    }

    public static class GlobalExceptionHandlerMiddlewareExtensions
    {
        public static IApplicationBuilder UseGlobalExceptionHandler(
            this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<GlobalExceptionHandlerMiddleware>();
        }
    }
}
