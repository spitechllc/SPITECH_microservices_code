﻿namespace SpiTech.ApplicationCore.BankFileParsers
{
    public enum GroupStatus
    {
        Update = 1,
        Deletion = 2,
        Correction = 3,
        TestOnly = 4
    }
}