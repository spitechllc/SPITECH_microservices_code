﻿namespace SpiTech.ApplicationCore.BankFileParsers
{
    public enum UsageType
    {
        Both,
        Oracle,
        TreasurySoftware,
        Mbsi
    }
}