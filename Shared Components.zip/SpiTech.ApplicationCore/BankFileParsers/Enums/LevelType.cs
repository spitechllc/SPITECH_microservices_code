﻿namespace SpiTech.ApplicationCore.BankFileParsers
{
    public enum LevelType
    {
        Status,
        Summary,
        Detail
    }
}