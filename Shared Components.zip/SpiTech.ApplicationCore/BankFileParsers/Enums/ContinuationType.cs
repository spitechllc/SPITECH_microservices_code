namespace SpiTech.ApplicationCore.BankFileParsers
{
    public enum ContinuationType
    {
        Group,
        Account,
        Detail
    }
}