﻿namespace SpiTech.ApplicationCore.BankFileParsers
{
    public enum TransactionType
    {
        Credit,
        Debit,
        NotApplicable,
        Reference
    }
}