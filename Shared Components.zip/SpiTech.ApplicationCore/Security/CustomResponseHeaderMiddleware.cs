﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Security
{
   public class CustomResponseHeaderMiddleware
    {
        private readonly RequestDelegate _next;

        public CustomResponseHeaderMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            //To add Headers AFTER everything you need to do this
            context.Response.OnStarting(state =>
            {
                var httpContext = (HttpContext)state;
                if (!httpContext.Response.Headers.ContainsKey("Strict-Transport-Security"))
                {
                    httpContext.Response.Headers.Add("Strict-Transport-Security", "max-age=31536000");
                }
                if (!httpContext.Response.Headers.ContainsKey("X-Content-Type-Options"))
                {
                    httpContext.Response.Headers.Add("X-Content-Type-Options", "nosniff");
                }
                if (!httpContext.Response.Headers.ContainsKey("X-Xss-Protection"))
                {
                    httpContext.Response.Headers.Add("X-Xss-Protection", "1; mode=block");
                }
                if (!httpContext.Response.Headers.ContainsKey("X-Frame-Options"))
                {
                    httpContext.Response.Headers.Add("X-Frame-Options", "SAMEORIGIN");
                }
                if (!httpContext.Response.Headers.ContainsKey("Referrer-Policy"))
                {
                    httpContext.Response.Headers.Add("Referrer-Policy", "strict-origin-when-cross-origin");
                }
                if (httpContext.Response.Headers.ContainsKey("Server"))
                {
                    httpContext.Response.Headers.Remove("Server");
                }
                if (httpContext.Response.Headers.ContainsKey("X-AspNet-Version"))
                {
                    httpContext.Response.Headers.Remove("X-AspNet-Version");
                }
                if (httpContext.Response.Headers.ContainsKey("X-Powered-By"))
                {
                    httpContext.Response.Headers.Remove("X-Powered-By");
                }              
               if (!httpContext.Response.Headers.ContainsKey("Access-Control-Allow-Origin"))
            {
            httpContext.Response.Headers.Add("Access-Control-Allow-Origin", "*");
            }
                //... and so on
                return Task.CompletedTask;
            }, context);

            await _next(context);
        }
    }
}
