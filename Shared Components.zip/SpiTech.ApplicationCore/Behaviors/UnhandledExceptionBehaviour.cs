﻿using MediatR;
using Microsoft.Extensions.Logging;
using SpiTech.ApplicationCore.Domain.Exceptions;
//using SpiTech.Application.Logging.Interfaces;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Behaviors
{
    public class UnhandledExceptionBehaviour<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
    {
        private readonly ILogger<TRequest> _logger;

        public UnhandledExceptionBehaviour(ILogger<TRequest> logger)
        {
            _logger = logger;
        }

        public async Task<TResponse> Handle(TRequest request, CancellationToken cancellationToken, RequestHandlerDelegate<TResponse> next)
        {

            try
            {
                return await next();
            }
            catch (ValidationException validationRuleException)
            {
                string requestName = typeof(TRequest).Name;

                _logger.LogWarning(validationRuleException, "Request: ValidationRuleException for Request {Name} {@Request} with error - {@error}", requestName, request, validationRuleException.Errors);
                //_logger.Error(ex, $"Request: ValidationException for Request {requestName} {request}", ex.Errors);

                throw;
            }
            catch (Exception ex)
            {
                string requestName = typeof(TRequest).Name;
                //_logger.LogError(ex, $"Request: Unhandled Exception for Request {requestName} {request}");

                _logger.LogError(ex, "Request: Unhandled Exception for Request {Name} {@Request}", requestName, request);
                throw;
            }
        }
    }
}
