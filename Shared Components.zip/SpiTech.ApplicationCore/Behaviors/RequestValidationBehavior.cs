using FluentValidation;
using MediatR;
using Microsoft.Extensions.Logging;
using SpiTech.ApplicationCore.Domain.Validations;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Behaviors
{
    public class RequestValidationBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse> where TRequest : IRequest<TResponse>
    {
        private readonly IEnumerable<IValidator<TRequest>> _validators;
        private readonly ILogger<RequestValidationBehavior<TRequest, TResponse>> _logger;

        public RequestValidationBehavior(IEnumerable<IValidator<TRequest>> validators, ILogger<RequestValidationBehavior<TRequest, TResponse>> logger)
        {
            _validators = validators;
            _logger = logger;
        }

        public async Task<TResponse> Handle(TRequest request, CancellationToken cancellationToken, RequestHandlerDelegate<TResponse> next)
        {
            string requestName = typeof(TRequest).Name;

            _logger.LogInformation("Doing validation for Request {Name} {@Request}", requestName, request);

            foreach (IValidator<TRequest> validator in _validators)
            {
                await validator.HandleValidation(request);
            }
            return await next();
        }
    }
}
