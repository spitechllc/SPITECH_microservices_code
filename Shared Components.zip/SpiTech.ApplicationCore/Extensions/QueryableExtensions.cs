﻿using SpiTech.ApplicationCore.Pagination;
using System;
using System.Linq;
using System.Linq.Expressions;

namespace SpiTech.ApplicationCore.Extensions
{
    public static class QueryableExtensions
    {
        public static IQueryable<T> PageBy<T>(this IQueryable<T> query, int skipCount, int maxResultCount)
        {
            return query == null ? throw new ArgumentNullException("query") : query.Skip(skipCount).Take(maxResultCount);
        }

        public static IQueryable<T> PageBy<T>(this IQueryable<T> query, int pageIndex, int pageSize, out int totalCount)
        {
            if (query == null)
            {
                throw new ArgumentNullException("query");
            }

            if (pageIndex < 1)
            {
                pageIndex = 1;
            }

            int itemIndex = (pageIndex - 1) * pageSize;
            totalCount = query.Count();
            while (totalCount <= itemIndex && pageIndex > 1)
            {
                itemIndex = (--pageIndex - 1) * pageSize;
            }

            return query.Skip(itemIndex).Take(pageSize);
        }

        public static IQueryable<T> WhereIf<T>(this IQueryable<T> query, bool condition,
            Expression<Func<T, bool>> predicate)
        {
            return condition
                ? query.Where(predicate)
                : query;
        }

        public static IQueryable<T> WhereIf<T>(this IQueryable<T> query, bool condition,
            Expression<Func<T, int, bool>> predicate)
        {
            return condition
                ? query.Where(predicate)
                : query;
        }

        public static IQueryable<TSource> OrderByAndThenByIf<TSource, TOrderByKey, TThenByKey>(this IQueryable<TSource> source,
                                                                                                    bool condition,
                                                                                                    Expression<Func<TSource, TOrderByKey>> keySelector,
                                                                                                    bool descending,
                                                                                                    Expression<Func<TSource, TThenByKey>> thenByKeySelector,
                                                                                                    bool thenByDescending = false)
        {
            if (condition)
            {
                IOrderedQueryable<TSource> orderby = descending ? source.OrderByDescending(keySelector) : source.OrderBy(keySelector);
                if (thenByKeySelector != null)
                {
                    orderby = thenByDescending ? orderby.ThenByDescending(thenByKeySelector) : orderby.ThenBy(thenByKeySelector);
                }

                return orderby;
            }
            else
            {
                return source;
            }
        }

        public static IQueryable<TSource> OrderByIf<TSource, TKey>(this IQueryable<TSource> source,
                                                                        bool condition,
                                                                        Expression<Func<TSource, TKey>> keySelector,
                                                                        bool descending = false)
        {
            if (condition)
            {
                IOrderedQueryable<TSource> orderby = descending ? source.OrderByDescending(keySelector) : source.OrderBy(keySelector);
                return orderby;
            }
            else
            {
                return source;
            }
        }

        public static IQueryable<T> OrderBy<T>(this IQueryable<T> source, string columnName, bool isAscending = true)
        {
            if (String.IsNullOrEmpty(columnName))
            {
                return source;
            }

            ParameterExpression parameter = Expression.Parameter(source.ElementType, "");

            MemberExpression property = Expression.Property(parameter, columnName);
            LambdaExpression lambda = Expression.Lambda(property, parameter);

            string methodName = isAscending ? "OrderBy" : "OrderByDescending";

            Expression methodCallExpression = Expression.Call(typeof(Queryable), methodName,
                                  new Type[] { source.ElementType, property.Type },
                                  source.Expression, Expression.Quote(lambda));

            return source.Provider.CreateQuery<T>(methodCallExpression);
        }

        public static PaginatedList<TResult> PaginatedList<TSource, TResult>(this IQueryable<TSource> source, int pageIndex, int pageSize, Func<TSource, TResult> selector, IQueryable<TSource> totalCountSource = null)
        {
            return PaginatedList(source, pageIndex, pageSize, selector, () => new PaginatedList<TResult>(), totalCountSource);
        }

        public static TPaginatedList PaginatedList<TSource, TResult, TPaginatedList>(this IQueryable<TSource> source, int pageIndex, int pageSize, Func<TSource, TResult> selector, IQueryable<TSource> totalCountSource = null) where TPaginatedList : PaginatedList<TResult>, new()
        {
            return PaginatedList(source, pageIndex, pageSize, selector, () => new TPaginatedList(), totalCountSource);
        }

        private static TPaginatedList PaginatedList<TSource, TResult, TPaginatedList>(this IQueryable<TSource> source, int pageIndex, int pageSize, Func<TSource, TResult> selector, Func<TPaginatedList> func, IQueryable<TSource> totalCountSource = null) where TPaginatedList : PaginatedList<TResult>, new()
        {
            TPaginatedList result = func();

            result.PageIndex = pageIndex;
            result.PageSize = pageSize;
            result.TotalCount = totalCountSource != null ? totalCountSource.Count() : source.Count();

            if (result.TotalCount > 0)
            {
                if (pageSize > 0)
                {
                    result.Data.AddRange(source.Skip(pageIndex * pageSize).Take(pageSize).ToList().Select(selector));
                }
                else
                {
                    result.Data.AddRange(source.ToList().Select(selector));
                }
            }
            return result;
        }
    }
}
