﻿using System;

namespace SpiTech.ApplicationCore.Extensions
{
    public static class MathExtension
    {
        public static decimal ToMoney(this decimal value)
        {
            //Math.Truncate(100 * a) / 100
            return Math.Round(value, 2, MidpointRounding.AwayFromZero);
        }

        public static double ToMoney(this double value)
        {
            return Math.Round(value, 2, MidpointRounding.AwayFromZero);
        }

        public static string CastMoney(this decimal value)
        {
            return $"{value:0.00}";
        }

        public static string CastMoney(this double value)
        {
            return $"{value:0.00}";
        }

        public static decimal TruncateTwoDecimal(this decimal value)
        {
            return Math.Truncate(100 * value) / 100;
        }
    }
}
