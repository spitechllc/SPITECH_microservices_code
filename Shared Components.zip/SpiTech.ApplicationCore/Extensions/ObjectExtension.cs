﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Extensions
{
    public static class ObjectExtension
    {
        public static ExpandoObject ToExpandoObject(this object obj)
        {
            if (obj == null)
            {
                return new ExpandoObject();
            }

            var expando = new ExpandoObject();

            foreach (PropertyDescriptor property in TypeDescriptor.GetProperties(obj.GetType()))
            {
                expando.TryAdd(property.Name, property.GetValue(obj));
            }

            return expando;
        }
    }
}
