using MediatR;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.ApplicationCore.Behaviors;

namespace SpiTech.ApplicationCore.ServiceCollection
{
    public static class CustomRequestValidationExtenstion
    {
        public static IServiceCollection AddCustomRequestValidation(this IServiceCollection services)
        {
            services.AddScoped(typeof(IPipelineBehavior<,>), typeof(RequestValidationBehavior<,>));
            return services;
        }
    }
}
