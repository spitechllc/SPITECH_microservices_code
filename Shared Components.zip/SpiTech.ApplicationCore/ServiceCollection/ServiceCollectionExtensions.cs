using IdentityServer4.Models;
using MediatR;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using SpiTech.Application.Logging.Extensions;
using SpiTech.ApplicationCore.AppSettingsConfigLoader;
using SpiTech.ApplicationCore.Authentication;
using SpiTech.ApplicationCore.Authorizations;
using SpiTech.ApplicationCore.AzureServices.Containers;
using SpiTech.ApplicationCore.Behaviors;
using SpiTech.ApplicationCore.Converters;
using SpiTech.ApplicationCore.Domain.Configs;
using SpiTech.ApplicationCore.Filters;
using SpiTech.ApplicationCore.Helpers;
using SpiTech.ApplicationCore.HttpClients;
using SpiTech.ApplicationCore.Services;
using StackExchange.Profiling.Storage;
using System;
using System.Linq;
using static SpiTech.ApplicationCore.Domain.DomainConstant;

namespace SpiTech.ApplicationCore.ServiceCollection
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddApplicationCore(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddControllers(options =>
                   {
                       options.Filters.Add<ApiExceptionFilterAttribute>();
                   })
                //.AddJsonOptions(options =>
                //   {
                //       options.JsonSerializerOptions.Converters.Insert(0, new TrimmingStringConverter());
                //   })
                .AddNewtonsoftJson(x =>
                {
                    x.SerializerSettings.Converters.Insert(0, new HtmlTagValidator());
                    x.SerializerSettings.Converters.Insert(1, new TrimmingStringConverter());
                    x.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
                });

            string connectionString = configuration.GetConnectionString("AzureStorage");
            services.AddApplicationValidation(configuration).AddApplicationBehaviors();
            services.AddScoped<IStorageServiceFactory, AzureStorageServiceFactory>();
            services.AddScoped<IStorageService>(provider => new AzureStorageService(connectionString));
            services.AddScoped<IApiAuthenticationService, ApiAuthenticationService>();
            services.AddScoped<AuthenticationInterceptorHandler>();
            services.AddScoped<NotSuccessInterceptorHandler>();
            services.AddConfig<IdentityConfig>(configuration);
            services.AddHttpClient();
            services.AddMemoryCache();
            services.AddHttpContextAccessor();
            services.AddLogger();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddSingleton<IUserAuthenticationProvider, UserAuthenticationProvider>();
            services.AddSingleton<IAuthenticationProvider, CustomAuthenticationProvider>();

            var fileProvider = new UpdateableFileProvider();
            services.TryAddTransient<ITempDataProvider, SessionStateTempDataProvider>();
            services.TryAddSingleton(fileProvider);
            services.TryAddSingleton<IRazorViewEngine, RazorViewEngine>();
            services.AddMvc().AddRazorRuntimeCompilation(options => options.FileProviders.Add(fileProvider))
                .SetCompatibilityVersion(CompatibilityVersion.Latest);
            services.TryAddTransient<IViewToStringConverter, ViewToStringConverter>();

            AddMiniProfiller(services);
            return services;
        }

        private static void AddMiniProfiller(IServiceCollection services)
        {
            services.AddMiniProfiler(options =>
            {
                // All of this is optional. You can simply call .AddMiniProfiler() for all defaults

                // (Optional) Path to use for profiler URLs, default is /mini-profiler-resources
                options.RouteBasePath = "/profiler";

                // (Optional) Control storage
                // (default is 30 minutes in MemoryCacheStorage)
                // Note: MiniProfiler will not work if a SizeLimit is set on MemoryCache!
                //   See: https://github.com/MiniProfiler/dotnet/issues/501 for details
                (options.Storage as MemoryCacheStorage).CacheDuration = TimeSpan.FromMinutes(60);

                // (Optional) Control which SQL formatter to use, InlineFormatter is the default
                options.SqlFormatter = new StackExchange.Profiling.SqlFormatters.InlineFormatter();

                // (Optional) To control authorization, you can use the Func<HttpRequest, bool> options:
                // (default is everyone can access profilers)
                //options.ResultsAuthorize = request => MyGetUserFunction(request).CanSeeMiniProfiler;
                //options.ResultsListAuthorize = request => MyGetUserFunction(request).CanSeeMiniProfiler;
                // Or, there are async versions available:
                //options.ResultsAuthorizeAsync = async request => (await MyGetUserFunctionAsync(request)).CanSeeMiniProfiler;
                //options.ResultsAuthorizeListAsync = async request => (await MyGetUserFunctionAsync(request)).CanSeeMiniProfilerLists;

                // (Optional)  To control which requests are profiled, use the Func<HttpRequest, bool> option:
                // (default is everything should be profiled)
                //options.ShouldProfile = request => MyShouldThisBeProfiledFunction(request);

                // (Optional) Profiles are stored under a user ID, function to get it:
                // (default is null, since above methods don't use it by default)
                //options.UserIdProvider = request => MyGetUserIdFunction(request);

                // (Optional) Swap out the entire profiler provider, if you want
                // (default handles async and works fine for almost all applications)
                //options.ProfilerProvider = new MyProfilerProvider();

                // (Optional) You can disable "Connection Open()", "Connection Close()" (and async variant) tracking.
                // (defaults to true, and connection opening/closing is tracked)
                options.TrackConnectionOpenClose = true;

                // (Optional) Use something other than the "light" color scheme.
                // (defaults to "light")
                options.ColorScheme = StackExchange.Profiling.ColorScheme.Auto;

                // Optionally change the number of decimal places shown for millisecond timings.
                // (defaults to 2)
                //options.PopupDecimalPlaces = 1;

                // The below are newer options, available in .NET Core 3.0 and above:

                // (Optional) You can disable MVC filter profiling
                // (defaults to true, and filters are profiled)
                options.EnableMvcFilterProfiling = true;
                // ...or only save filters that take over a certain millisecond duration (including their children)
                // (defaults to null, and all filters are profiled)
                // options.MvcFilterMinimumSaveMs = 1.0m;

                // (Optional) You can disable MVC view profiling
                // (defaults to true, and views are profiled)
                options.EnableMvcViewProfiling = true;
                // ...or only save views that take over a certain millisecond duration (including their children)
                // (defaults to null, and all views are profiled)
                // options.MvcViewMinimumSaveMs = 1.0m;

                // (Optional) listen to any errors that occur within MiniProfiler itself
                // options.OnInternalError = e => MyExceptionLogger(e);

                // (Optional - not recommended) You can enable a heavy debug mode with stacks and tooltips when using memory storage
                // It has a lot of overhead vs. normal profiling and should only be used with that in mind
                // (defaults to false, debug/heavy mode is off)
                //options.EnableDebugMode = true;
            });
        }

        public static IServiceCollection AddSftpService(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddConfig<SftpConfigs>(configuration);
            services.AddScoped<ISftpService, SftpService>();
            return services;
        }

        public static IServiceCollection AddSecurityService(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddConfig<SecurityConfig>(configuration);
            services.AddScoped<ISecurityService, SecurityService>();
            return services;
        }

        public static IServiceCollection AddFnboService(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IFnboEncryptService, FnboEncryptService>();
            return services;
        }

        public static AuthenticationBuilder AddAPIAuthentication(this IServiceCollection services, IConfiguration configuration, string apiName)
        {
            IdentityConfig identityConfig = configuration.LoadConfig<IdentityConfig>();

            return services.AddAuthentication(options =>
                                        {
                                            options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                                            options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                                        })
                                        .AddIdentityServerAuthentication(JwtBearerDefaults.AuthenticationScheme,
                                        options =>
                                        {
                                            options.Authority = identityConfig.BaseUrl;
                                            options.TokenRetriever = CustomTokenRetriever.FromHeaderAndQueryString;
                                            options.RequireHttpsMetadata = false;
                                            options.JwtValidationClockSkew = TimeSpan.Zero;
                                            options.ApiName = apiName;
                                            options.ApiSecret = identityConfig.ClientSecret;
                                            //options.TokenValidationParameters.ValidTypes = new[] { "at+jwt" };
                                            //options.ForwardDefaultSelector = ForwardReferenceToken("introspection");
                                            //options.SupportedTokens = IdentityServer4.AccessTokenValidation.SupportedTokens.Reference;
                                        })
                                        //.AddOAuth2Introspection("introspection", options =>
                                        //{
                                        //    options.Authority = identityConfig.BaseUrl;
                                        //    options.ClientId = "mppaapi";
                                        //    options.ClientSecret = identityConfig.ClientSecret; 
                                        //})
                                        ;
        }

        public static IServiceCollection AddAPIAuthorization(this IServiceCollection services)
        {
            //services.AddAuthorization(options =>
            //{
            //    options.AddPolicy(IdentityPolicy.APIClient, policy => policy.RequireClaim(IdentityClaim.RoleTypeClaim, IdentityRoleType.APIClient));

            //    options.AddPolicy(IdentityPolicy.SuperAdmin, policy => policy.RequireClaim(IdentityClaim.RoleTypeClaim, IdentityRoleType.SuperAdmin));

            //    options.AddPolicy(IdentityPolicy.StoreUser, policy => policy.RequireClaim(IdentityClaim.RoleTypeClaim, IdentityRoleType.StoreUser));

            //    options.AddPolicy(IdentityPolicy.BusinessUser, policy => policy.RequireClaim(IdentityClaim.RoleTypeClaim, IdentityRoleType.BusinessUser));

            //    options.AddPolicy(IdentityPolicy.ConsumerUser, policy => policy.RequireClaim(IdentityClaim.RoleTypeClaim, IdentityRoleType.ConsumerUser));

            //    options.AddPolicy(IdentityPolicy.All, policy => policy.RequireClaim(IdentityClaim.RoleTypeClaim, IdentityRoleType.SuperAdmin, IdentityRoleType.APIClient, IdentityRoleType.ConsumerUser, IdentityRoleType.BusinessUser, IdentityRoleType.StoreUser));
            //});

            ///services.AddSingleton<IAuthorizationHandler, PermissionAuthorizationHandler>();

            //services.AddAuthorization(options =>
            //{
            //    options.AddPolicy("Permission", policyBuilder =>
            //    {
            //        policyBuilder.Requirements.Add(new PermissionAuthorizationRequirement());
            //    });
            //});

            services.AddSingleton<IAuthorizationPolicyProvider, ApiPermissionAuthPolicyProvider>();
            services.AddSingleton<IAuthorizationHandler, ApiPermissionAuthorizeHandler>();

            return services;
        }

        public static IServiceCollection AddApplicationValidation(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddCustomRequestValidation();
            return services;
        }

        public static IServiceCollection AddApplicationBehaviors(this IServiceCollection services)
        {
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(UnhandledExceptionBehaviour<,>));
            return services;
        }

        public static IHttpClientBuilder AddHttpClients(this IServiceCollection services, string httpClientName = "", string baseUrl = null, bool withAuthentication = true)
        {
            IHttpClientBuilder builder = string.IsNullOrWhiteSpace(baseUrl)
                ? services.AddHttpClient(httpClientName).AddPolicyHandler(HttpClientExtension.GetRetryPolicy())
                : services.AddHttpClient(httpClientName, c => { c.BaseAddress = new Uri(baseUrl); }).AddPolicyHandler(HttpClientExtension.GetRetryPolicy());
            if (withAuthentication)
            {
                builder.AddHttpMessageHandler<AuthenticationInterceptorHandler>();
            }

            builder.AddHttpMessageHandler<NotSuccessInterceptorHandler>();
            return builder;
        }


        /// <summary>
        /// Provides a forwarding func for JWT vs reference tokens (based on existence of dot in token)
        /// </summary>
        /// <param name="introspectionScheme">Scheme name of the introspection handler</param>
        /// <returns></returns>
        public static Func<HttpContext, string> ForwardReferenceToken(string introspectionScheme = "introspection")
        {
            string Select(HttpContext context)
            {
                var (scheme, credential) = GetSchemeAndCredential(context);

                if (scheme.Equals("Bearer", StringComparison.OrdinalIgnoreCase) &&
                    !credential.Contains("."))
                {
                    return introspectionScheme;
                }

                return null;
            }

            return Select;
        }

        /// <summary>
        /// Extracts scheme and credential from Authorization header (if present)
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static (string, string) GetSchemeAndCredential(HttpContext context)
        {
            var header = context.Request.Headers["Authorization"].FirstOrDefault();

            if (string.IsNullOrEmpty(header))
            {
                return ("", "");
            }

            var parts = header.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length != 2)
            {
                return ("", "");
            }

            return (parts[0], parts[1]);
        }
    }
}
