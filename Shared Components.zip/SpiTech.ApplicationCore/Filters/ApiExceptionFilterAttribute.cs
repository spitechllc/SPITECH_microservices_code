﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Filters
{
    public class ApiExceptionFilterAttribute : ExceptionFilterAttribute
    {
        private readonly ILogger<ApiExceptionFilterAttribute> _logger;
        private readonly ICorrelationIdAccessor _correlationIdAccessor;

        private readonly IDictionary<Type, Action<ExceptionContext>> _exceptionHandlers;

        public ApiExceptionFilterAttribute(ILogger<ApiExceptionFilterAttribute> logger, ICorrelationIdAccessor correlationIdAccessor)
        {
            _logger = logger;
            _correlationIdAccessor = correlationIdAccessor;
            // Register known exception types and handlers.
            _exceptionHandlers = new Dictionary<Type, Action<ExceptionContext>>
            {
                { typeof(ValidationException), HandleValidationException },
                { typeof(NotFoundException), HandleNotFoundException },
                { typeof(UnauthorizedAccessException), HandleUnauthorizedAccessException }
            };
        }

        public override void OnException(ExceptionContext context)
        {
            HandleException(context);

            base.OnException(context);
        }

        private void HandleException(ExceptionContext context)
        {
            Type type = context.Exception.GetType();
            if (_exceptionHandlers.ContainsKey(type))
            {
                _exceptionHandlers[type].Invoke(context);
                return;
            }

            if (!context.ModelState.IsValid)
            {
                HandleInvalidModelStateException(context);
                return;
            }

            HandleUnknownException(context);
        }

        private void HandleValidationException(ExceptionContext context)
        {
            ValidationException exception = context.Exception as ValidationException;
            _logger.Trace("HandleValidationException", exception.Errors);

            ValidationProblemDetails details = new(exception.Errors)
            {
                Type = "ValidationException",
                Title = $"Validation Error (CorrelationId= {_correlationIdAccessor.GetCorrelationId()})"
            };

            context.Result = new BadRequestObjectResult(details);

            context.ExceptionHandled = true;
        }

        private void HandleInvalidModelStateException(ExceptionContext context)
        {
            ValidationProblemDetails details = new(context.ModelState)
            {
                Type = "InvalidModelStateException",
                Title = $"Validation Error (CorrelationId= {_correlationIdAccessor.GetCorrelationId()})"
            };

            _logger.Trace("HandleInvalidModelStateException", details);
            context.Result = new BadRequestObjectResult(details);

            context.ExceptionHandled = true;
        }

        private void HandleNotFoundException(ExceptionContext context)
        {
            NotFoundException exception = context.Exception as NotFoundException;

            ProblemDetails details = new()
            {
                Title = $"The specified resource was not found (CorrelationId= {_correlationIdAccessor.GetCorrelationId()}).",
                Detail = exception?.Message
            };

            _logger.Trace("HandleNotFoundException", details);

            context.Result = new NotFoundObjectResult(details);

            context.ExceptionHandled = true;
        }

        private void HandleUnauthorizedAccessException(ExceptionContext context)
        {
            ProblemDetails details = new()
            {
                Status = StatusCodes.Status401Unauthorized,
                Title = $"Unauthorized (CorrelationId= {_correlationIdAccessor.GetCorrelationId()})"
            };

            context.Result = new ObjectResult(details)
            {
                StatusCode = StatusCodes.Status401Unauthorized
            };

            _logger.Trace("HandleUnauthorizedAccessException", details);

            context.ExceptionHandled = true;
        }

        private void HandleUnknownException(ExceptionContext context)
        {
            ProblemDetails details = new()
            {
                Status = StatusCodes.Status500InternalServerError,
                Title = $"An error occurred while processing your request (CorrelationId= {_correlationIdAccessor.GetCorrelationId()})."
            };

            _logger.Error(context.Exception, "UnhandledException", FormatRequest(context.HttpContext.Request).GetAwaiter().GetResult());

            context.Result = new ObjectResult(details)
            {
                StatusCode = StatusCodes.Status500InternalServerError
            };

            context.ExceptionHandled = true;
        }

        private async Task<string> FormatRequest(HttpRequest request)
        {
            var requestBody = string.Empty;
            try
            {
                //var inputStream = request.Body;

                //if (request.ContentLength > 0)
                //{
                //    request.EnableBuffering();

                //    request.Body.Position = 0;
                //    using var streamReader = new System.IO.StreamReader(inputStream, leaveOpen: true);
                //    requestBody = await streamReader.ReadToEndAsync();
                //    request.Body.Position = 0;
                //}
                //return requestBody;

                //request.EnableBuffering();
                //var buffer = new byte[Convert.ToInt32(request.ContentLength)];
                //await request.Body.ReadAsync(buffer, 0, buffer.Length);
                //var requestBody = Encoding.UTF8.GetString(buffer);
                //request.Body = body;
                return $"{request.Scheme} {request.Host}{request.Path} {request.QueryString} {requestBody}";
            }
            catch(Exception ex)
            {
                _logger.Error(ex);
            }

            return requestBody;
        }
    }
}
