﻿using System.IO;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Services
{
    public interface IFnboEncryptService
    {
        Task<Stream> Encrypt(Stream inputStream, string encryptKeyFile);
        Task<Stream> Decrypt(Stream inputStream, string decryptKeyFile, string decryptPassword);
    }
}
