﻿using SpiTech.ApplicationCore.PgpCore;
using System;
using System.IO;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Services
{
    internal class FnboEncryptService : IFnboEncryptService
    {
        public async Task<Stream> Encrypt(Stream inputStream, string encryptKeyFile)
        {
            string publicKeyFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", encryptKeyFile);
            // Load keys
            EncryptionKeys encryptionKeys = new EncryptionKeys(new FileInfo(publicKeyFilePath));

            // Encrypt
            PGP pgp = new PGP(encryptionKeys);

            var encryptedStream = await pgp.EncryptFileAsync(inputStream);
            encryptedStream.Position = 0;

            return encryptedStream;
        }

        public async Task<Stream> Decrypt(Stream inputStream, string decryptKeyFile, string decryptPassword)
        {
            string privateKeyFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", decryptKeyFile);

            // Load keys
            EncryptionKeys encryptionKeys = new EncryptionKeys(new FileInfo(privateKeyFilePath), decryptPassword);

            // Decrypt
            PGP pgp = new PGP(encryptionKeys);

            var decryptedStream = await pgp.DecryptFileAsync(inputStream);
            decryptedStream.Position = 0;

            return decryptedStream;
        }
    }
}
