﻿using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Services
{
    public interface ISecurityService
    {
        string Encrypt(string clearText);
        string Decrypt(string cipherText);
    }
}