﻿using SpiTech.ApplicationCore.Domain.Configs;
using SpiTech.ApplicationCore.Domain.Sftp;
using Renci.SshNet.Sftp;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Services
{
    public interface ISftpService
    {
        Task<bool> UploadFile(Stream stream, string fileName, SftpConfig sftpConfig);
        List<SftpFile> GetFiles(string folderName, SftpConfig sftpConfig);
        List<TransportResponse> DownloadFiles(List<SftpFile> sftpFiles, SftpConfig sftpConfig);
        List<string> TestConnection(SftpConfig sftpConfig);
    }
}