﻿using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Configs;
using SpiTech.ApplicationCore.Domain.Sftp;
using SpiTech.ApplicationCore.Helpers;
using Renci.SshNet;
using Renci.SshNet.Sftp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Services
{
    internal class SftpService : ISftpService
    {
        private readonly ILogger<SftpService> logger;
        private readonly IFnboEncryptService fnboEncryptService;

        public SftpService(ILogger<SftpService> logger, IFnboEncryptService fnboEncryptService)
        {
            this.logger = logger;
            this.fnboEncryptService = fnboEncryptService;
        }

        public async Task<bool> UploadFile(Stream stream, string fileName, SftpConfig sftpConfig)
        {
            logger.TraceEnterMethod(nameof(UploadFile), sftpConfig.Host);

            var messages = new List<string>();
            SftpClient client = GetSftpClient(sftpConfig, out messages);

            if (client != null)
            {
                using (client)
                {
                    var encryptedStream = await fnboEncryptService.Encrypt(stream, sftpConfig.EncryptKeyFile);
                    client.BufferSize = (uint)encryptedStream.Length; // bypass Payload error large files

                    if (!string.IsNullOrWhiteSpace(sftpConfig.UploadFolder))
                    {
                        client.UploadFile(encryptedStream, $"{sftpConfig.UploadFolder}{fileName}");
                    }
                    else
                    {
                        client.UploadFile(encryptedStream, fileName);
                    }

                    client.Disconnect();

                    logger.TraceExitMethod(nameof(UploadFile), true, $"Uploaded file -{fileName} to the Sftp");

                    return true;
                }
            }

            logger.TraceExitMethod(nameof(UploadFile), false);
            return false;
        }

        public List<SftpFile> GetFiles(string folderName, SftpConfig sftpConfig)
        {
            List<SftpFile> files = new List<SftpFile>();
            var messages = new List<string>();
            SftpClient client = GetSftpClient(sftpConfig, out messages);

            if (client != null)
            {
                using (client)
                {
                    ListDirectory(client, folderName, ref files);
                    logger.Info("SftpClient files completed");
                    client.Disconnect();
                }
            }

            return files;
        }

        public List<TransportResponse> DownloadFiles(List<SftpFile> sftpFiles, SftpConfig sftpConfig)
        {
            List<TransportResponse> files = new List<TransportResponse>();

            var messages = new List<string>();
            SftpClient client = GetSftpClient(sftpConfig, out messages);

            if (client != null)
            {
                using (client)
                {
                    files = DownloadFilesInDirectory(sftpFiles, client);
                    logger.Info("SftpClient files download completed");
                    client.Disconnect();
                }
            }

            return files;
        }

        public List<string> TestConnection(SftpConfig sftpConfig)
        {
            var messages = new List<string>();

            try
            {
                var externalIp = IPAddressHelper.GetIPAddress();
                var message = $"Connecting to the Sftp client- {externalIp}";
                messages.Add(message);

                SftpClient client = GetSftpClient(sftpConfig, out messages);

                if (client != null)
                {
                    using (client)
                    {
                        logger.Info("SftpClient completed");
                        client.Disconnect();
                    }
                }
            }
            catch (Exception ex)
            {
                messages.Add(ex.Message);
                messages.Add(ex.StackTrace);
                logger.Error(ex);
            }

            logger.TraceExitMethod(nameof(UploadFile), false);
            return messages;
        }

        private SftpClient GetSftpClient(SftpConfig sftpConfig, out List<string> messages)
        {
            messages = new List<string>();
            messages.Add("TestConnection started");

            SftpClient client = null;
            try
            {
                if (!sftpConfig.Enabled)
                {
                    var message = "The Sftp config is disabled";
                    messages.Add(message);
                    logger.Info(message);
                    return client;
                }

                if (!string.IsNullOrWhiteSpace(sftpConfig.PrivateKeyFile))
                {
                    var message = $"Connecting to the PrivateKeyFile Sftp client- {sftpConfig.Host}-{sftpConfig.Port}-{sftpConfig.PrivateKeyFile}";
                    messages.Add(message);

                    string privateKeyFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", sftpConfig.PrivateKeyFile);
                    var privateKeyFile = new PrivateKeyFile(privateKeyFilePath, sftpConfig.PassPhrase);
                    client = new(sftpConfig.Host, sftpConfig.Port, sftpConfig.UserName, privateKeyFile);
                }
                else
                {
                    var message = $"Connecting to the Password Sftp client- {sftpConfig.Host}-{sftpConfig.Port}";
                    messages.Add(message);
                    client = new(sftpConfig.Host, sftpConfig.Port, sftpConfig.UserName, sftpConfig.Password);
                }

                client.KeepAliveInterval = TimeSpan.FromSeconds(60);
                client.ConnectionInfo.Timeout = TimeSpan.FromMinutes(10);
                client.OperationTimeout = TimeSpan.FromMinutes(10);
                logger.Info("SftpClient connecting");
                client.Connect();

                var msg = $"Connecting to the Sftp client - {sftpConfig.Host}-{sftpConfig.Port}";
                messages.Add(msg);

                if (client.IsConnected)
                {
                    logger.Info("SftpClient connected");

                    return client;
                }
                else
                {
                    var message = $"Unable to connect to the Sftp client -{sftpConfig.Host}";
                    messages.Add(message);
                    logger.Info(message, sftpConfig.Host);

                    client.Dispose();
                }
            }
            catch (Exception ex)
            {
                messages.Add(ex.Message);
                messages.Add(ex.StackTrace);
                logger.Error(ex);
                throw;
            }

            return null;
        }

        private void ListDirectory(SftpClient client, string dirName, ref List<SftpFile> files)
        {
            foreach (var entry in client.ListDirectory(dirName).Where(f => !f.IsDirectory))
            {
                logger.Info($"FullName-{entry.FullName}");

                if (entry.IsDirectory)
                {
                    ListDirectory(client, entry.FullName, ref files);
                }
                else
                {
                    files.Add(entry);
                }
            }
        }

        private List<TransportResponse> DownloadFilesInDirectory(IEnumerable<SftpFile> files, SftpClient client)
        {
            List<TransportResponse> lstResponse = new List<TransportResponse>();
            foreach (var file in files)
            {
                if (!file.IsDirectory)
                {
                    if (file.Name != "." && file.Name != "..")
                    {
                        using (MemoryStream fs = new MemoryStream())
                        {
                            try
                            {
                                Console.WriteLine("Reading " + file.Name + "...");
                                client.DownloadFile(file.FullName, fs);
                                fs.Seek(0, SeekOrigin.Begin);
                                fs.Flush();
                                lstResponse.Add(new TransportResponse
                                {
                                    FileName = file.Name,
                                    FileTimeStamp = file.LastWriteTime,
                                    Bytes = fs.ToArray()
                                });
                            }
                            catch (Exception ex)
                            {
                                logger.Error(ex, "Error reading File. Exception Details: " + ex.Message);
                            }
                        }
                    }
                }
                else
                {
                    if (file.Name != "." && file.Name != "..")
                    {
                        lstResponse.Add(new TransportResponse
                        {
                            DirectoryName = file.Name,
                            TransportResponses = DownloadFilesInDirectory(client.ListDirectory(file.Name), client)
                        });
                    }
                }
            }

            return lstResponse;
        }
    }
}
