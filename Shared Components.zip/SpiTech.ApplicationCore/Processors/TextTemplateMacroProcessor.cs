﻿using SpiTech.Application.Logging;
using System;
using System.Text.RegularExpressions;

namespace SpiTech.ApplicationCore.Processors
{
    public class TextTemplateMacroProcessor
    {
        public static string Process(string template, params object[] macroObjects)
        {
            try
            {
                if (macroObjects == null || string.IsNullOrWhiteSpace(template))
                {
                    return template;
                }

                foreach (object macroObject in macroObjects)
                {
                    if (macroObject != null)
                    {
                        System.Reflection.PropertyInfo[] properties = macroObject.GetType().GetProperties();

                        if (properties != null)
                        {
                            foreach (System.Reflection.PropertyInfo property in properties)
                            {
                                if (property != null)
                                {
                                    string value = string.Empty;

                                    object propertyValue = property.GetValue(macroObject);

                                    if (propertyValue != null)
                                    {
                                        value = property.PropertyType == typeof(DateTime) ? ((DateTime)propertyValue).ToString("MMMM, dd yyyy") : propertyValue.ToString();
                                    }

                                    template = template.Replace($"[[{property.Name}]]", value, StringComparison.InvariantCultureIgnoreCase);
                                }
                            }

                            Regex rg = new("(?<=\\[\\[).+?(?=\\]\\])");

                            MatchCollection matchedMacros = rg.Matches(template);

                            if (matchedMacros != null)
                            {
                                for (int count = 0; count < matchedMacros.Count; count++)
                                {
                                    string macro = matchedMacros[count].Value;
                                    if (macro.Contains("."))
                                    {
                                        object value = GetPropertyValue(macroObject, macro);
                                        if (value != null)
                                        {
                                            template = template.Replace($"[[{macro}]]", value.ToString(), StringComparison.InvariantCultureIgnoreCase);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                return template;
            }
            catch (Exception ex)
            {
                Logger.Error(ex.Message, ex);
            }
            return template;
        }

        public static object GetPropertyValue(object src, string propName)
        {
            if (src == null)
            {
                return null;
            }

            if (propName == null)
            {
                return null;
            }

            if (propName.Contains("."))
            {
                string[] temp = propName.Split(new char[] { '.' }, 2);
                return GetPropertyValue(GetPropertyValue(src, temp[0]), temp[1]);
            }
            else
            {
                System.Reflection.PropertyInfo prop = src.GetType().GetProperty(propName);
                if (prop != null)
                {
                    object propValue = prop.GetValue(src, null);

                    return propValue == null ? string.Empty : propValue;
                }

                return null;
            }
        }
    }
}
