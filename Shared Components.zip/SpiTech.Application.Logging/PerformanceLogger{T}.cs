﻿namespace SpiTech.Application.Logging
{
    internal class PerformanceLogger<T> : PerformanceLogger, Interfaces.IPerformanceLogger<T>
    {
        public PerformanceLogger(Interfaces.ILogger<T> logger) : base(logger)
        {
        }
    }
}
