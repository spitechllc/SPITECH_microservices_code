﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.Application.Logging.Interfaces;
using Serilog;
using System;
using System.IO;

namespace SpiTech.Application.Logging.Extensions
{
    public static class LoggerExtensions
    {
        public static IServiceCollection AddLogger(this IServiceCollection services)
        {
            services.AddHttpContextAccessor();
            //services.AddSingleton(typeof(Interfaces.ILogger), typeof(Logger));
            services.AddSingleton(typeof(ILogger<>), typeof(Logger<>));
            services.AddSingleton(typeof(IPerformanceLogger<>), typeof(PerformanceLogger<>));
            services.AddScoped<ICorrelationIdAccessor, CorrelationIdAccessor>();
            return services;
        }

        public static IApplicationBuilder UseLogger(this IApplicationBuilder builder)
        {
            builder.UseSerilogRequestLogging();
            return builder;
        }

        public static IWebHostBuilder UseLogger(this IWebHostBuilder builder)
        {
            builder.UseSerilog((context, config) =>
            {
                config.ReadFrom.Configuration(context.Configuration);
            });

            return builder;
        }

        public static void InitializeLogger()
        {
            Environment.SetEnvironmentVariable("LogDir", AppDomain.CurrentDomain.BaseDirectory);

            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);

#if DEBUG
            configurationBuilder.AddJsonFile("appsettings.Development.json", optional: false, reloadOnChange: true);
#endif


            IConfigurationRoot configuration = configurationBuilder.Build();
            Log.Logger = new LoggerConfiguration()
                .ReadFrom.Configuration(configuration)
                .CreateLogger();

        }

        public static IPerformanceLogger LogPerformance(this Interfaces.ILogger logger, string methodName, string message = "")
        {
            PerformanceLogger performanceLogger = new(logger);
            performanceLogger.StartLogPerformance(methodName, message);
            return performanceLogger;
        }
    }
}
