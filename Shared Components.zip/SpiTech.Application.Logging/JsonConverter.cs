﻿using Newtonsoft.Json;
using System;

namespace SpiTech.Application.Logging
{
    public class JsonConverter
    {
        public const string NullSerializeValue = "[null]";

        public const string ExceptionSerializeValue = "[Object could not be serialized]";

        internal static string SerializeObject(
                                        object model,
                                        bool throwException = false,
                                        string exceptionSerializeValue = JsonConverter.ExceptionSerializeValue,
                                        string nullSerializeValue = JsonConverter.NullSerializeValue)
        {
            string serializedValue = string.Empty;

            if (model == null)
            {
                return nullSerializeValue;
            }

            try
            {
                Type instanceType = model.GetType();

                if (instanceType.IsPrimitive)
                {
                    serializedValue = model.ToString();
                }
                else if (instanceType == typeof(string))
                {
                    serializedValue = model as string;
                }
                else if (instanceType.IsClass)
                {
                    serializedValue = JsonConvert.SerializeObject(model, new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore });
                }
            }
            catch (Exception)
            {
                if (throwException)
                {
                    throw;
                }
                else
                {
                    // Do not crash the application due to Json serialization issues.
                    serializedValue = exceptionSerializeValue;
                }
            }

            return serializedValue;
        }

        public static T DeserializeObject<T>(string value)
        {
            return JsonConvert.DeserializeObject<T>(value);
        }
    }
}
