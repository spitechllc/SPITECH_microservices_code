﻿using Microsoft.AspNetCore.Http;
using SpiTech.Application.Logging.Interfaces;

namespace SpiTech.Application.Logging
{
    internal class CorrelationIdAccessor : ICorrelationIdAccessor
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public CorrelationIdAccessor(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }
        public string GetCorrelationId()
        {
            return _httpContextAccessor.HttpContext.TraceIdentifier;
        }
    }
}
