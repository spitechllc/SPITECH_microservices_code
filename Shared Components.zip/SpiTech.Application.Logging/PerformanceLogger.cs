﻿namespace SpiTech.Application.Logging
{
    using Microsoft.Extensions.Logging;
    using System;
    using System.Diagnostics;

    internal class PerformanceLogger : Interfaces.IPerformanceLogger
    {
        private readonly Interfaces.ILogger logger;

        private Stopwatch stopwatch;

        private string methodName;

        private string message;

        private bool isLogged = false;

        public PerformanceLogger(Interfaces.ILogger logger)
        {
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public void StartLogPerformance(string methodName, string message = "")
        {
            this.methodName = methodName;
            this.message = message;
            isLogged = false;
            stopwatch = new Stopwatch();
            stopwatch.Start();
        }

        public void EndLogPerformance()
        {
            if (!isLogged)
            {
                stopwatch.Stop();
                isLogged = true;
                logger.Log(LogLevel.Information, $"Method({methodName}) has execution Time = {stopwatch.ElapsedMilliseconds} miliseconds.{message ?? ""}");
            }
        }

        public void Dispose()
        {
            EndLogPerformance();
        }
    }
}
