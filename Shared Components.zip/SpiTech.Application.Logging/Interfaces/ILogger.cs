﻿using Microsoft.Extensions.Logging;
using System;

namespace SpiTech.Application.Logging.Interfaces
{
    public interface ILogger
    {
        void Trace(string message, params object[] args);

        void TraceEnterMethod(string methodName, params object[] args);

        void TraceExitMethod(string methodName, params object[] args);

        void Info(string message, params object[] args);

        void Warn(string message, params object[] args);

        void Error(Exception exception, params object[] args);

        void Error(Exception exception, string message, params object[] args);

        void Debug(string message, params object[] args);

        void Log(LogLevel level, string message, params object[] args);
    }
}