﻿namespace SpiTech.Application.Logging.Interfaces
{
    public interface ICorrelationIdAccessor
    {
        string GetCorrelationId();
    }
}
