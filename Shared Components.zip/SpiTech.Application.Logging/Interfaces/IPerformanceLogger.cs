﻿namespace SpiTech.Application.Logging.Interfaces
{
    using System;

    public interface IPerformanceLogger : IDisposable
    {
        void StartLogPerformance(string methodName, string message = "");

        void EndLogPerformance();
    }
}
