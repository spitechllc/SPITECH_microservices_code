﻿namespace SpiTech.Application.Logging.Interfaces
{
    public interface IPerformanceLogger<out T> : IPerformanceLogger
    {
    }
}
