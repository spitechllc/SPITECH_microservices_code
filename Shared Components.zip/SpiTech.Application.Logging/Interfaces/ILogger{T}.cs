﻿namespace SpiTech.Application.Logging.Interfaces
{
    public interface ILogger<out T> : ILogger
    {
    }
}
