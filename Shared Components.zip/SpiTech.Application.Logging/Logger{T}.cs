﻿using Microsoft.Extensions.Logging;

namespace SpiTech.Application.Logging
{
    internal class Logger<T> : Logger, Interfaces.ILogger<T>
    {
        public Logger(ILogger<T> logger) : base(logger)
        {
        }
    }
}