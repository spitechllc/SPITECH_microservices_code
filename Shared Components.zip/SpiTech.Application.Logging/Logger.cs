﻿using Microsoft.Extensions.Logging;
using Serilog.Events;
using System;
using System.Globalization;
using System.Text;

namespace SpiTech.Application.Logging
{
    public class Logger : SpiTech.Application.Logging.Interfaces.ILogger
    {
        #region variable declaration
        private const string TraceLogMessage = "Trace";

        private const string TraceMethodStartLogMessage = "Method Start";

        private const string TraceMethodEndLogMessage = "Method Exit";

        private const string ErrorLogMessage = "Error";

        private const string InfoLogMessage = "Info";

        private const string WarnLogMessage = "Warn";

        private const string DebugLogMessage = "Debug";

        private readonly ILogger _logger;

        #endregion

        public Logger(ILogger logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }


        public static void Fatal(string message, Exception exception, params object[] args)
        {
            if (Serilog.Log.IsEnabled(LogEventLevel.Fatal))
            {
                Serilog.Log.Fatal(exception, GetSerializeValue(message, args));
            }
        }

        public static void Information(string message, params object[] args)
        {
            if (Serilog.Log.IsEnabled(LogEventLevel.Information))
            {
                Serilog.Log.Information(GetSerializeValue(message, args));
            }
        }

        public static void DebugInfo(string message, params object[] args)
        {
            if (Serilog.Log.IsEnabled(LogEventLevel.Debug))
            {
                Serilog.Log.Debug(GetSerializeValue(message, args));
            }
        }

        public static void Error(string message, Exception exception, params object[] args)
        {
            if (Serilog.Log.IsEnabled(LogEventLevel.Error))
            {
                Serilog.Log.Error(exception, GetSerializeValue(message, args));
            }
        }

        public static void CloseAndFlush()
        {
            Serilog.Log.CloseAndFlush();
        }

        public void Trace(string message, params object[] args)
        {
            PerformLog(LogLevel.Trace, TraceLogMessage + " : " + message, null, args);
        }

        public void TraceEnterMethod(string methodName, params object[] args)
        {
            PerformLog(LogLevel.Trace, $"{methodName} {TraceMethodStartLogMessage}", null, args);
        }

        public void TraceExitMethod(string methodName, params object[] args)
        {
            PerformLog(LogLevel.Trace, $"{methodName} {TraceMethodEndLogMessage}", null, args);
        }

        public void Info(string message, params object[] args)
        {
            PerformLog(LogLevel.Information, InfoLogMessage + " : " + message, null, args);
        }

        public void Warn(string message, params object[] args)
        {
            PerformLog(LogLevel.Warning, WarnLogMessage + " : " + message, null, args);
        }

        public void Error(Exception exception, params object[] args)
        {
            PerformLog(LogLevel.Error, ErrorLogMessage, exception, args);
        }

        public void Error(Exception exception, string message, params object[] args)
        {
            PerformLog(LogLevel.Error, ErrorLogMessage + " : " + message, exception, args);
        }

        public void Debug(string message, params object[] args)
        {
            PerformLog(LogLevel.Debug, DebugLogMessage + " : " + message, null, args);
        }

        public void Log(LogLevel level, string message, params object[] args)
        {
            PerformLog(level, message, null, args);
        }

        private void PerformLog(LogLevel level, string message, Exception exception, params object[] args)
        {
            try
            {
                if (!_logger.IsEnabled(level))
                {
                    return;
                }

                string result = GetSerializeValue(message, args);

                Log(_logger, level, result, exception);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.WriteLine(ex.ToString());
            }
        }

        private static string GetSerializeValue(string message, object[] args)
        {
            StringBuilder result = new();
            try
            {
                result.Append(message);
                if (args != null && args.Length != 0)
                {
                    result.Append(" : Parameters are :");
                    int i = 0;
                    foreach (object argItem in args)
                    {
                        string serializeValue = JsonConverter.SerializeObject(argItem);
                        if (serializeValue == null)
                        {
                            serializeValue = "[null]";
                        }

                        result.Append("{");
                        result.Append(string.Format(CultureInfo.InvariantCulture, "Parameter{0}:{1}", i, serializeValue));
                        result.Append("}\t");
                        i++;
                    }
                }
            }
            catch(System.Exception ex)
            {
                Error(ex.Message, ex);
            }

            return result.ToString();
        }

        private static void Log(ILogger logger, LogLevel level, string loggerValue, Exception exception)
        {
            if (exception == null)
            {
                logger.Log(level, loggerValue);
            }
            else
            {
                logger.Log(level, exception, loggerValue);
            }
        }
    }
}