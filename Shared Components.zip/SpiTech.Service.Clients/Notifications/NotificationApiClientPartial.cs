namespace SpiTech.Service.Clients.Notifications
{
    internal partial class NotificationApiClient
    {
        partial void UpdateJsonSerializerSettings(Newtonsoft.Json.JsonSerializerSettings settings)
        {
            settings.ContractResolver = new SafeContractResolver();
        }
    }
}