namespace SpiTech.Service.Clients.Finance
{
    internal partial class FinanceApiClient
    {
        partial void UpdateJsonSerializerSettings(Newtonsoft.Json.JsonSerializerSettings settings)
        {
            settings.ContractResolver = new SafeContractResolver();
        }
    }

}