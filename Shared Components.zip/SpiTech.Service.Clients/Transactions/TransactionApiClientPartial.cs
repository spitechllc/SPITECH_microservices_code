namespace SpiTech.Service.Clients.Transactions
{
    internal partial class TransactionApiClient 
    {
        partial void UpdateJsonSerializerSettings(Newtonsoft.Json.JsonSerializerSettings settings)
        {
            settings.ContractResolver = new SafeContractResolver();
        }
    }
}