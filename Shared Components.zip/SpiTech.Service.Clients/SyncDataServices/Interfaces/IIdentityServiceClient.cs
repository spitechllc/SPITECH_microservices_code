﻿using SpiTech.Service.Clients.Identity;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Service.Clients.SyncDataServices.Interfaces
{
    public interface IIdentityServiceClient
    {
        Task<UserModelResponseModel> GetUserByIdAsync(int? userId, CancellationToken cancellationToken = default);
        Task<ICollection<LinkUserModel>> VerifyAsync(int? fromUserId, int? toUserId, CancellationToken cancellationToken = default);
        Task<ICollection<UserModel>> GetUserListAsync(IEnumerable<int> userIds, CancellationToken cancellationToken = default);
        Task<UserModelResponseModel> SyncUserByIdAsync(int? userId, CancellationToken cancellationToken = default);
        Task<StoreUserResponseModel> StoreUserRegisterAsync(StoreUserModel command, CancellationToken cancellationToken = default);
        Task<UserSearchResultResponseModel> UpdateProfileAsync(UpdateProfileCommand command, CancellationToken cancellationToken = default);
        Task<ICollection<UserModel>> GetUsersByRoleAsync(string roleId, CancellationToken cancellationToken = default);

        Task<ICollection<UserModel>> GetUserByDateAsync(System.DateTimeOffset? startDate, System.DateTimeOffset? endDate);
        Task<ICollection<UserModel>> GetLast7daysUserAsync(System.DateTimeOffset? startDate, System.DateTimeOffset? endDate);
        Task<ICollection<User>> GetUserWithNoPaymentMethodAsync(IEnumerable<int> userIds);

        Task<ICollection<UserModel>> GetUserListForProfileAsync(IEnumerable<int> body);        
        Task<UserTenantModelResponseModel> GetUserTeanantByIdAsync(int userId);

        Task<UserConsumerModelPaginatedList> GetAllUserAsync(int? pageIndex, int? pageSize);

        Task<ICollection<TenantMasterResponse>> GetTenantMasterListAsync();
    }
}
