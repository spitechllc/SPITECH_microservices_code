﻿using SpiTech.Service.Clients.Finance;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Service.Clients.SyncDataServices.Interfaces
{
    public interface IFinanceServiceClient
    {
        Task<WalletCreditSearchModelResponseList> GetWalletCreditByTransactionIdsAsync(GetWalletCreditByTransactionIdsQuery query, CancellationToken cancellationToken = default);

        Task<UserWalletModelResponseList> GetUserWalletListAsync(IEnumerable<int> userIds, CancellationToken cancellationToken = default);

        Task<WalletPreauthDebitModelResponseModel> PreAuthPaymentAsync(WalletPreauthPaymentCommand command, CancellationToken cancellationToken = default);

        Task<ResponseModel> VoidPaymentAsync(WalletVoidPaymentModel command, CancellationToken cancellationToken = default);

        Task<ResponseModel> ProcessPaymentAsync(WalletProcessPaymentCommand command, CancellationToken cancellationToken = default);

        Task<ICollection<CashRewardModel>> GetCashRewardDetailsByStoreIdAsync(GetCashRewardDetailsByFilterQuery query, CancellationToken cancellationToken = default);
        Task<ICollection<TransactionCashRewardModel>> GetCashRewardDetailsByTransactionIdsAsync(GetCashRewardDetailsByTransacionIdsQuery query, CancellationToken cancellationToken = default);
        Task<RewardDetailsDashboardModelResponseModel> CashRewardDetailsForDashBoardAsync(GetRewardDetailsDashboardQuery query);
        Task<UserRewardDetailsModelResponseList> ConsumersRewardDetailsForDashBoardAsync(GetConsumersRewardDetailsDashboardQuery body, System.Threading.CancellationToken cancellationToken=default);
        Task<IEnumerable<UserWalletDetailModel>> GetWalletDetailsListByIds(IEnumerable<int> userIds, CancellationToken cancellationToken = default);
        Task<WalletCreditDetailModelPaginatedList> WalletCreditDetailAsync(int? pageIndex, int? pageSize);

        Task<UserWalletDetailModelResponseModel> WalletDetailsByUserIdAsync(int? userId);

        Task<ICollection<UserWalletDetailModel>> WalletDetailsAsync();

    }
}
