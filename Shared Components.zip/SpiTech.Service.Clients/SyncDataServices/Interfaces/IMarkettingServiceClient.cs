﻿using SpiTech.Service.Clients.Marketting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Service.Clients.SyncDataServices.Interfaces
{
    public interface IMarkettingServiceClient
    {
        Task<CashBackRuleModelResponseList> RulesAsync(int? creditIdentifier, CreditType? creditType, CancellationToken cancellationToken=default);
    }
}
