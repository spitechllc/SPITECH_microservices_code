﻿using SpiTech.Service.Clients.Transactions;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Service.Clients.SyncDataServices.Interfaces
{
    public interface ITransactionServiceClient
    {
        Task<ICollection<TransactionModel>> GetStoreByTransactionIdsAsync(IEnumerable<long> transactionIds, CancellationToken cancellationToken = default);
        Task<TransactionModelResponseList> GetLastTransactionByFilterAsync(GetLastTransactionByFilterQuery query, CancellationToken cancellationToken = default);
    }
}
