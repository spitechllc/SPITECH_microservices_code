﻿using SpiTech.Service.Clients.Stores;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Service.Clients.SyncDataServices.Interfaces
{
    public interface IStoreServiceClient
    {
        Task<ICollection<StoreInfoModel>> GetStoreInfosAsync(IEnumerable<int> storeIds, CancellationToken cancellationToken = default);
        Task<ICollection<SaleAgent>> SaleAgentsAsync(IEnumerable<int> saleAgentIds, CancellationToken cancellationToken = default);
        Task<StoreInfoModel> GetMasterStoreInfoAsync(CancellationToken cancellationToken = default);
        Task<StoreInfoModel> GetStoreInfoAsync(int? storeId, string siteId, CancellationToken cancellationToken = default);
        Task<CompanyModel> GetCompanyByIdAsync(int companyId,  CancellationToken cancellationToken = default);
        Task<ICollection<StoreSearchResult>> GetStoresPrimaryDetailsBySiteIdsAsync(IEnumerable<string> siteIds, CancellationToken cancellationToken = default);
        Task<SaleAgentModel> SaleAgentAsync(int saleAgentId, CancellationToken cancellationToken = default);
        Task<ICollection<Reseller>> ResellersAsync(IEnumerable<int> resellerIds, CancellationToken cancellationToken = default);
        Task<ResellerModel> ResellerAsync(int resellerId, CancellationToken cancellationToken = default);
        Task<StoreSearchResultResponseList> GetCompaniesByStoreIdAsync(IEnumerable<int> storeId,CancellationToken cancellationToken = default);
        Task<StoresSearchModelResponseList> GetStoresForDashboard(GetStoresForDashboardQuery query, CancellationToken cancellationToken = default);
        Task<StoreGroupUsersModelResponseList> StoreGroupStoresByUserIdAsync(int? userId, CancellationToken cancellationToken = default);
    }
}
