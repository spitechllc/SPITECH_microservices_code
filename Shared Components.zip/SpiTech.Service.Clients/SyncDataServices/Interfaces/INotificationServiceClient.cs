﻿using SpiTech.Service.Clients.Notifications;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Service.Clients.SyncDataServices.Interfaces
{
    public interface INotificationServiceClient
    {
        Task<ResponseModel> UpdateEmailBannerAsync(UpdateEmailBannerCommand command, CancellationToken cancellationToken = default);
        Task<NotificationTypeModelResponseList> GetNotificationTypeAsync(CancellationToken cancellationToken = default);
    }
}
