﻿using SpiTech.Service.Clients.Payments;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Service.Clients.SyncDataServices.Interfaces
{
    public interface IPaymentServiceClient
    {
        Task<PaymentResponseModelResponseModel> PaymentAsync(PaymentCommand command, CancellationToken cancellationToken = default);

        Task<PreAuthPaymentResponseModelResponseModel> PreAuthAsync(PreAuthPaymentCommand command, CancellationToken cancellationToken = default);

        Task<PaymentResponseModelResponseModel> FinalizeAsync(ProcessPaymentCommand command, CancellationToken cancellationToken = default);

        Task<StoreConfigModelResponseList> AllStoreConfigsAsync(GetStoreConfigsQuery query, CancellationToken cancellationToken = default);

        Task<StoreConfigModelResponseList> MasterStoreConfigAsync(CancellationToken cancellationToken = default);

        Task<SaleAgentConfigModelResponseList> AllSaleAgentConfigsAsync(GetSaleAgentConfigsQuery query, CancellationToken cancellationToken = default);

        Task<ResellerConfigModelResponseList> AllResellerConfigsAsync(GetResellerConfigsQuery query, CancellationToken cancellationToken = default);

        Task<ICollection<UserPaymentMethodModel>> GetAsync(ICollection<int> userPaymentMethodIds, CancellationToken cancellationToken = default);

        Task<StoreConfigResponseModel> StoreConfigGETAsync(int storeId, System.Threading.CancellationToken cancellationToken=default);
        Task<UserWithPaymentMethodModelResponseList> GetUserWithPaymentMethodAsync();

        Task<UserPaymentMethodResponseList> GetUserPaymentMethodAsync(int userId);
        Task<UserPaymentMethodResponseList> GetUserMOPAsync(int userId);
        Task<UserPaymentMethodResponseList> GetAllUserMOPAsync();
    }
}
