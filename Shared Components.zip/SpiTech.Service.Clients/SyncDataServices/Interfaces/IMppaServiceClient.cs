﻿using SpiTech.Service.Clients.Mppa;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Service.Clients.SyncDataServices.Interfaces
{
    public interface IMppaServiceClient
    {
        Task<List<SiteModel>> SiteStatusesAsync(int? heartBeatInterval, bool? onlineOnly, CancellationToken cancellationToken = default);
        Task<SiteProductModelResponseList> SiteProductAsync(IEnumerable<string> siteIds, CancellationToken cancellationToken = default);
        Task<SiteModel> StatusAsync(string siteId, CancellationToken cancellationToken = default);
        Task<ICollection<SiteProduct>> BySiteIdAsync(string siteId, CancellationToken cancellationToken = default);
        Task<List<SiteModel>> StatusesAsync(int heartBeatInterval, string[] siteIds, CancellationToken cancellationToken = default);
    }
}
