﻿using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.Service.Clients.Execeptions;
using SpiTech.Service.Clients.Marketting;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Service.Clients.SyncDataServices.Implementation
{
    internal class MarkettingServiceClient : IMarkettingServiceClient
    {
        private readonly ILogger<MarkettingServiceClient> _logger;
        private readonly MarkettingApiClient _markettingApiClient;
        public MarkettingServiceClient(ILogger<MarkettingServiceClient> logger,
                                    MarkettingApiClient markettingApiClient)
        {
            this._logger = logger;
            this._markettingApiClient = markettingApiClient;
        }
        public async Task<CashBackRuleModelResponseList> RulesAsync(int? creditIdentifier, CreditType? creditType, CancellationToken cancellationToken = default)
        {
            try
            {
                return await _markettingApiClient.RulesAsync(creditIdentifier,creditType, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }
    }
}
