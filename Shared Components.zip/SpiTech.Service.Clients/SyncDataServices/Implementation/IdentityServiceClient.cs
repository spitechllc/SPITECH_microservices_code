﻿using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.Service.Clients.Execeptions;
using SpiTech.Service.Clients.Identity;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Service.Clients.SyncDataServices.Implementation
{
    internal class IdentityServiceClient : IIdentityServiceClient
    {
        private readonly ILogger<IdentityServiceClient> logger;
        private readonly IdentityApiClient identityClient;

        public IdentityServiceClient(ILogger<IdentityServiceClient> logger,
                                    IdentityApiClient identityClient)
        {
            this.logger = logger;
            this.identityClient = identityClient;
        }

        public async Task<UserModelResponseModel> GetUserByIdAsync(int? userId, CancellationToken cancellationToken = default)
        {
            try
            {
                return await identityClient.GetUserByIdAsync(userId, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<ICollection<LinkUserModel>> VerifyAsync(int? fromUserId, int? toUserId, CancellationToken cancellationToken = default)
        {
            try
            {
                return await identityClient.VerifyAsync(fromUserId, toUserId, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<ICollection<UserModel>> GetUserListAsync(IEnumerable<int> userIds, CancellationToken cancellationToken = default)
        {
            try
            {
                return await identityClient.GetUserListAsync(userIds, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<UserModelResponseModel> SyncUserByIdAsync(int? userId, CancellationToken cancellationToken = default)
        {
            try
            {
                return await identityClient.SyncUserByIdAsync(userId, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<StoreUserResponseModel> StoreUserRegisterAsync(StoreUserModel command, CancellationToken cancellationToken = default)
        {
            try
            {
                return await identityClient.StoreUserRegisterAsync(command, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<UserSearchResultResponseModel> UpdateProfileAsync(UpdateProfileCommand command, CancellationToken cancellationToken = default)
        {
            try
            {
                return await identityClient.UpdateProfileAsync(command, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }
        public async Task<ICollection<UserModel>> GetUsersByRoleAsync(string roleId, CancellationToken cancellationToken = default)
        {
            try
            {
                return await identityClient.GetUsersByRoleAsync(roleId, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<ICollection<UserModel>> GetUserByDateAsync(System.DateTimeOffset? startDate, System.DateTimeOffset? endDate)
        {
            try
            {
                return await identityClient.GetUserByDateAsync(startDate, endDate);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<ICollection<UserModel>> GetLast7daysUserAsync(System.DateTimeOffset? startDate, System.DateTimeOffset? endDate)
        {
            try
            {
                return await identityClient.GetLast7daysUserAsync(startDate, endDate);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }
        public async Task<ICollection<User>> GetUserWithNoPaymentMethodAsync(IEnumerable<int> userIds)
        {
            try
            {
                return await identityClient.GetUserWithNoPaymentMethodAsync(userIds);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<ICollection<UserModel>> GetUserListForProfileAsync(IEnumerable<int> body)
        {
            try
            {
                return await identityClient.GetUserListForProfileAsync(body);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<UserTenantModelResponseModel> GetUserTeanantByIdAsync(int userId)
        {
            try
            {
                return await identityClient.GetUserTeanantByIdAsync(userId);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<UserConsumerModelPaginatedList> GetAllUserAsync(int? pageIndex, int? pageSize)
        {
            try
            {
                return await identityClient.GetAllUserAsync(pageIndex, pageSize, System.Threading.CancellationToken.None);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public  async Task<ICollection<TenantMasterResponse>> GetTenantMasterListAsync()
        {
            try
            {
                return await identityClient.GetTenantMasterListAsync();
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }
    }
}
