﻿using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.Service.Clients.Execeptions;
using SpiTech.Service.Clients.Notifications;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Service.Clients.SyncDataServices.Implementation
{
    internal class NotificationServiceClient : INotificationServiceClient
    {
        private readonly ILogger<NotificationServiceClient> logger;
        private readonly NotificationApiClient notificationApiClient;

        public NotificationServiceClient(ILogger<NotificationServiceClient> logger,
                                    NotificationApiClient notificationApiClient)
        {
            this.logger = logger;
            this.notificationApiClient = notificationApiClient;
        }

        public async Task<NotificationTypeModelResponseList> GetNotificationTypeAsync(CancellationToken cancellationToken = default)
        {
            try
            {
                return await notificationApiClient.GetNotificationTypeAsync(cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<ResponseModel> UpdateEmailBannerAsync(UpdateEmailBannerCommand command, CancellationToken cancellationToken = default)
        {
            try
            {
                return await notificationApiClient.UpdateEmailBannerAsync(command, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }
    }
}
