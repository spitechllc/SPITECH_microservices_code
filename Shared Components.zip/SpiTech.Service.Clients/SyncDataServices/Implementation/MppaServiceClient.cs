﻿using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.Service.Clients.Execeptions;
using SpiTech.Service.Clients.Mppa;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Service.Clients.SyncDataServices.Implementation
{
    internal class MppaServiceClient : IMppaServiceClient
    {
        private readonly ILogger<MppaServiceClient> logger;
        private readonly MppaApiClient mppaApiClient;

        public MppaServiceClient(ILogger<MppaServiceClient> logger,
                                    MppaApiClient mppaApiClient)
        {
            this.logger = logger;
            this.mppaApiClient = mppaApiClient;
        }

        public async Task<SiteProductModelResponseList> SiteProductAsync(IEnumerable<string> siteIds, CancellationToken cancellationToken = default)
        {
            try
            {
                return await mppaApiClient.SiteProductAsync(siteIds, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<List<SiteModel>> SiteStatusesAsync(int? heartBeatInterval, bool? onlineOnly, CancellationToken cancellationToken = default)
        {
            try
            {
                var response = await mppaApiClient.SiteStatusesAsync(heartBeatInterval, onlineOnly, cancellationToken);

                if (response != null && response.Data != null)
                {
                    return response.Data.ToList();
                }
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }

            return null;
        }

        public async Task<ICollection<SiteProduct>> BySiteIdAsync(string siteId, CancellationToken cancellationToken = default)
        {
            try
            {
                return await mppaApiClient.BySiteIdAsync(siteId, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<SiteModel> StatusAsync(string siteId, CancellationToken cancellationToken = default)
        {
            try
            {
                return await mppaApiClient.StatusAsync(siteId, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<List<SiteModel>> StatusesAsync(int heartBeatInterval, string[] siteIds, CancellationToken cancellationToken = default)
        {
            try
            {
                var response = await mppaApiClient.StatusesAsync(new GetCommanderStatusesQuery
                {
                    HeartBeatInterval = heartBeatInterval,
                    SiteIds = siteIds
                }, cancellationToken);

                if (response != null && response.Data != null)
                {
                    return response.Data.ToList();
                }

                return null;
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }
    }
}
