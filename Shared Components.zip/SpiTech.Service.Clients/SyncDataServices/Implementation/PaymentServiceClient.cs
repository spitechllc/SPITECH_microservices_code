﻿using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.Service.Clients.Execeptions;
using SpiTech.Service.Clients.Payments;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Service.Clients.SyncDataServices.Implementation
{
    internal class PaymentServiceClient : IPaymentServiceClient
    {
        private readonly ILogger<PaymentServiceClient> logger;
        private readonly PaymentApiClient paymentApiClient;

        public PaymentServiceClient(ILogger<PaymentServiceClient> logger,
                                    PaymentApiClient paymentApiClient)
        {
            this.logger = logger;
            this.paymentApiClient = paymentApiClient;
        }

        public async Task<PaymentResponseModelResponseModel> PaymentAsync(PaymentCommand command, CancellationToken cancellationToken = default)
        {
            try
            {
                return await paymentApiClient.PaymentAsync(command, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<PreAuthPaymentResponseModelResponseModel> PreAuthAsync(PreAuthPaymentCommand command, CancellationToken cancellationToken = default)
        {
            try
            {
                return await paymentApiClient.PreAuthAsync(command, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<PaymentResponseModelResponseModel> FinalizeAsync(ProcessPaymentCommand command, CancellationToken cancellationToken = default)
        {
            try
            {
                return await paymentApiClient.FinalizeAsync(command, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<StoreConfigModelResponseList> AllStoreConfigsAsync(GetStoreConfigsQuery query, CancellationToken cancellationToken = default)
        {
            try
            {
                return await paymentApiClient.AllStoreConfigsAsync(query, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<StoreConfigModelResponseList> MasterStoreConfigAsync(CancellationToken cancellationToken = default)
        {
            try
            {
                return await paymentApiClient.MasterStoreConfigAsync(cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<SaleAgentConfigModelResponseList> AllSaleAgentConfigsAsync(GetSaleAgentConfigsQuery query, CancellationToken cancellationToken = default)
        {
            try
            {
                return await paymentApiClient.AllSaleAgentConfigsAsync(query, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<ResellerConfigModelResponseList> AllResellerConfigsAsync(GetResellerConfigsQuery query, CancellationToken cancellationToken = default)
        {
            try
            {
                return await paymentApiClient.AllResellerConfigsAsync(query, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<ICollection<UserPaymentMethodModel>> GetAsync(ICollection<int> userPaymentMethodIds, CancellationToken cancellationToken = default)
        {
            try
            {
                var result = await paymentApiClient.GetAsync(new GetUserPaymentMethodsQuery { UserPaymentMethodIds = userPaymentMethodIds }, cancellationToken);

                return result?.Data ?? new List<UserPaymentMethodModel>();
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }
        public async Task<StoreConfigResponseModel> StoreConfigGETAsync(int storeId, System.Threading.CancellationToken cancellationToken)
        {
            try
            {
                return await paymentApiClient.StoreConfigGETAsync(storeId, cancellationToken=default);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<UserWithPaymentMethodModelResponseList> GetUserWithPaymentMethodAsync()
        {
            try
            {
                return await paymentApiClient.GetUserWithPaymentMethodAsync();
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<UserPaymentMethodResponseList> GetUserPaymentMethodAsync(int userId)
        {
            try
            {
                return await paymentApiClient.GetUserPaymentMethodAsync(userId);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<UserPaymentMethodResponseList> GetUserMOPAsync(int userId)
        {
            try
            {
                return await paymentApiClient.GetUserMOPAsync(userId);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<UserPaymentMethodResponseList> GetAllUserMOPAsync()
        {
            try
            {
                return await paymentApiClient.GetAllUserMOPAsync();
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }
    }
}
