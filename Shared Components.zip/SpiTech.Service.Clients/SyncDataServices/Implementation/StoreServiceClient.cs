﻿using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.Service.Clients.Execeptions;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Service.Clients.SyncDataServices.Implementation
{
    internal class StoreServiceClient : IStoreServiceClient
    {
        private readonly ILogger<StoreServiceClient> logger;
        private readonly StoreApiClient storeApiClient;

        public StoreServiceClient(ILogger<StoreServiceClient> logger,
                                    StoreApiClient storeApiClient)
        {
            this.logger = logger;
            this.storeApiClient = storeApiClient;
        }

        public async Task<ICollection<StoreInfoModel>> GetStoreInfosAsync(IEnumerable<int> storeIds, CancellationToken cancellationToken = default)
        {
            try
            {
                var response = await storeApiClient.StoreInfosAsync(storeIds, cancellationToken);

                return response.Data;
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<StoreInfoModel> GetMasterStoreInfoAsync(CancellationToken cancellationToken = default)
        {
            try
            {
                var response = await storeApiClient.GetMasterStoreInfoAsync(cancellationToken);
                return response.Data;
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<StoreInfoModel> GetStoreInfoAsync(int? storeId, string siteId, CancellationToken cancellationToken = default)
        {
            try
            {
                var response = await storeApiClient.GetStoreInfoAsync(storeId, siteId, cancellationToken);
                return response.Data;
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<ICollection<StoreSearchResult>> GetStoresPrimaryDetailsBySiteIdsAsync(IEnumerable<string> siteIds, CancellationToken cancellationToken = default)
        {
            try
            {
                return await storeApiClient.GetStoresPrimaryDetailsBySiteIdsAsync(siteIds, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<ICollection<SaleAgent>> SaleAgentsAsync(IEnumerable<int> saleAgentIds, CancellationToken cancellationToken = default)
        {
            try
            {
                var response = await storeApiClient.SaleAgentsAsync(new GetSaleAgentByIdsQuery() { SaleAgentIds = saleAgentIds.ToList() }, cancellationToken);
                return response.Data;
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<ICollection<Reseller>> ResellersAsync(IEnumerable<int> resellerIds, CancellationToken cancellationToken = default)
        {
            try
            {
                var response = await storeApiClient.ResellersAsync(new GetResellerByIdsQuery() { ResellerIds = resellerIds.ToList() }, cancellationToken);
                return response.Data;
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<ResellerModel> ResellerAsync(int resellerId, CancellationToken cancellationToken = default)
        {
            try
            {
                return await storeApiClient.ResellerGETAsync(resellerId, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<SaleAgentModel> SaleAgentAsync(int saleAgentId, CancellationToken cancellationToken = default)
        {
            try
            {
                return await storeApiClient.SaleAgentGETAsync(saleAgentId, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<CompanyModel> GetCompanyByIdAsync(int companyId, CancellationToken cancellationToken = default)
        {
            try
            {
                var response = await storeApiClient.ByCompanyIdAsync(companyId, cancellationToken);
                return response;
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }
        public async Task<StoreSearchResultResponseList> GetCompaniesByStoreIdAsync(IEnumerable<int> storeId, CancellationToken cancellationToken = default)
        {
            try
            {
                var response = await storeApiClient.GetCompaniesByStoreIdAsync(storeId, cancellationToken);
                return response;
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }
        public async Task<StoresSearchModelResponseList> GetStoresForDashboard(GetStoresForDashboardQuery query, CancellationToken cancellationToken = default)
        {
            try
            {
                var response = await storeApiClient.ForDashboardAsync(query, cancellationToken);
                return response;
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }
        public async Task<StoreGroupUsersModelResponseList> StoreGroupStoresByUserIdAsync(int? userId, CancellationToken cancellationToken = default)
        {
            try
            {
                var response = await storeApiClient.StoreGroupStoresByUserIdAsync(userId, cancellationToken);
                return response;
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }
    }
}
