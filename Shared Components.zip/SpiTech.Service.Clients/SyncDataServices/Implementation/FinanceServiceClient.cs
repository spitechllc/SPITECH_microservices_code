﻿using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.Service.Clients.Execeptions;
using SpiTech.Service.Clients.Finance;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Service.Clients.SyncDataServices.Implementation
{
    internal class FinanceServiceClient : IFinanceServiceClient
    {
        private readonly ILogger<FinanceServiceClient> logger;
        private readonly FinanceApiClient financeApiClient;

        public FinanceServiceClient(ILogger<FinanceServiceClient> logger,
                                    FinanceApiClient financeApiClient)
        {
            this.logger = logger;
            this.financeApiClient = financeApiClient;
        }

        public async Task<WalletCreditSearchModelResponseList> GetWalletCreditByTransactionIdsAsync(GetWalletCreditByTransactionIdsQuery query, CancellationToken cancellationToken = default)
        {
            try
            {
                return await financeApiClient.GetWalletCreditByTransactionIdsAsync(query, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<UserWalletModelResponseList> GetUserWalletListAsync(IEnumerable<int> userIds, CancellationToken cancellationToken = default)
        {
            try
            {
                return await financeApiClient.GetUserWalletListAsync(userIds, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<WalletPreauthDebitModelResponseModel> PreAuthPaymentAsync(WalletPreauthPaymentCommand command, CancellationToken cancellationToken = default)
        {
            try
            {
                return await financeApiClient.PreAuthPaymentAsync(command, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<ResponseModel> VoidPaymentAsync(WalletVoidPaymentModel command, CancellationToken cancellationToken = default)
        {
            try
            {
                return await financeApiClient.VoidPaymentAsync(command, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<ResponseModel> ProcessPaymentAsync(WalletProcessPaymentCommand command, CancellationToken cancellationToken = default)
        {
            try
            {
                return await financeApiClient.ProcessPaymentAsync(command, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<ICollection<CashRewardModel>> GetCashRewardDetailsByStoreIdAsync(GetCashRewardDetailsByFilterQuery query, CancellationToken cancellationToken = default)
        {
            try
            {
                return await financeApiClient.GetCashRewardDetailsByStoreIdAsync(query, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<ICollection<TransactionCashRewardModel>> GetCashRewardDetailsByTransactionIdsAsync(GetCashRewardDetailsByTransacionIdsQuery query, CancellationToken cancellationToken = default)
        {
            try
            {
                return await financeApiClient.GetCashRewardDetailsByTransactionIdsAsync(query, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }
        public async Task<RewardDetailsDashboardModelResponseModel> CashRewardDetailsForDashBoardAsync(GetRewardDetailsDashboardQuery query)
        {
            try
            {
                return await financeApiClient.CashRewardDetailsForDashBoardAsync(query);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }
        public async Task<UserRewardDetailsModelResponseList> ConsumersRewardDetailsForDashBoardAsync(GetConsumersRewardDetailsDashboardQuery body, CancellationToken cancellationToken = default)
        {
            try
            {
                return await financeApiClient.ConsumersRewardDetailsForDashBoardAsync(body, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }
        public async Task<IEnumerable<UserWalletDetailModel>> GetWalletDetailsListByIds(IEnumerable<int> userIds, CancellationToken cancellationToken = default)
        {
            try
            {
                return await financeApiClient.GetWalletDetailsListByIdsAsync(userIds, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public virtual async Task<WalletCreditDetailModelPaginatedList> WalletCreditDetailAsync(int? pageIndex, int? pageSize)
        {
            try
            {
                return await financeApiClient.WalletCreditDetailAsync(pageIndex, pageSize);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<UserWalletDetailModelResponseModel> WalletDetailsByUserIdAsync(int? userId)
        {
            try
            {
                return await financeApiClient.WalletDetailsByUserIdAsync(userId, System.Threading.CancellationToken.None);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }

        public async Task<ICollection<UserWalletDetailModel>> WalletDetailsAsync()
        {
            try
            {
                return await financeApiClient.WalletDetailsAsync(System.Threading.CancellationToken.None);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }
    }
}
