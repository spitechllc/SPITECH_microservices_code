﻿using SpiTech.Application.Logging.Interfaces;
using SpiTech.ApplicationCore.Domain.Exceptions;
using SpiTech.Service.Clients.Execeptions;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Service.Clients.Transactions;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.Service.Clients.SyncDataServices.Implementation
{
    internal class TransactionServiceClient : ITransactionServiceClient
    {
        private readonly ILogger<TransactionServiceClient> logger;
        private readonly TransactionApiClient transactionApiClient;

        public TransactionServiceClient(ILogger<TransactionServiceClient> _logger,
                                    TransactionApiClient transactionApiClient)
        {
            this.logger = _logger;
            this.transactionApiClient = transactionApiClient;
        }

        public async Task<ICollection<TransactionModel>> GetStoreByTransactionIdsAsync(IEnumerable<long> transactionIds, CancellationToken cancellationToken = default)
        {
            try
            {
                GetStoreByTransactionIdsQuery request = new GetStoreByTransactionIdsQuery();
                request.TransactionIds = (ICollection<long>)transactionIds;
                var response = await transactionApiClient.StoreByTransactionIdsAsync(request, cancellationToken);

                return response;
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }
        public async Task<TransactionModelResponseList> GetLastTransactionByFilterAsync(GetLastTransactionByFilterQuery query, CancellationToken cancellationToken = default)
        {
            try
            {
                logger.Warn($"GetLastTransactionByFilterAsync step 1");
                return await transactionApiClient.LastTransactionByFilterAsync(query, cancellationToken);
            }
            catch (ApiException<ValidationProblemDetails> validationex)
            {
                throw new ValidationException(validationex.Result.Errors.ToDictionary(t => t.Key, e => e.Value.ToArray()));
            }
        }
    }
}
