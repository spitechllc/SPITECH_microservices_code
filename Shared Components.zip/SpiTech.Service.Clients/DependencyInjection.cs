﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SpiTech.ApplicationCore.AppSettingsConfigLoader;
using SpiTech.ApplicationCore.ServiceCollection;
using SpiTech.Service.Clients.Finance;
using SpiTech.Service.Clients.Identity;
using SpiTech.Service.Clients.Marketting;
using SpiTech.Service.Clients.Mppa;
using SpiTech.Service.Clients.Notifications;
using SpiTech.Service.Clients.Payments;
using SpiTech.Service.Clients.Stores;
using SpiTech.Service.Clients.SyncDataServices.Implementation;
using SpiTech.Service.Clients.SyncDataServices.Interfaces;
using SpiTech.Service.Clients.Transactions;
using System.Net.Http;

namespace SpiTech.Service.Clients
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddIdentityClient(this IServiceCollection services, IConfiguration configuration)
        {
            ApplicationCore.HttpClients.IdentityConfig identityConfig = configuration.LoadConfig<ApplicationCore.HttpClients.IdentityConfig>();

            services.AddHttpClients("Identity");
            services.AddScoped(c => new IdentityApiClient(identityConfig.BaseUrl, c.GetService<IHttpClientFactory>().CreateClient("Identity")));
            services.AddScoped<IIdentityServiceClient, IdentityServiceClient>();

            //services.AddHttpClient<ICountryRepositoryClient, CountryRepositoryClientV2>()
            //        .ConfigureHttpClient(c => c.BaseAddress = new Uri(Configuration.GetSection("Apis:CountryApi:Url").Value))
            //        .AddHttpMessageHandler<MyDelegatingHandler>();
            return services;
        }

        public static IServiceCollection AddStoreClient(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddHttpClients("Store");
            services.AddScoped(c => new StoreApiClient(configuration.GetValue<string>("MicroServices:Store"),
               c.GetService<IHttpClientFactory>().CreateClient("Store")));

            services.AddScoped<IStoreServiceClient, StoreServiceClient>();
            return services;
        }

        public static IServiceCollection AddFinanceClient(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddHttpClients("Finance");
            services.AddScoped(c => new FinanceApiClient(configuration.GetValue<string>("MicroServices:Finance"),
               c.GetService<IHttpClientFactory>().CreateClient("Finance")));

            services.AddScoped<IFinanceServiceClient, FinanceServiceClient>();
            return services;
        }

        public static IServiceCollection AddNotificationClient(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddHttpClients("Notification");
            services.AddScoped(c => new NotificationApiClient(configuration.GetValue<string>("MicroServices:Notification"),
                c.GetService<IHttpClientFactory>().CreateClient("Notification")));

            services.AddScoped<INotificationServiceClient, NotificationServiceClient>();
            return services;
        }

        public static IServiceCollection AddPaymentClient(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddHttpClients("Payment");
            services.AddScoped(c => new PaymentApiClient(configuration.GetValue<string>("MicroServices:Payment"),
                c.GetService<IHttpClientFactory>().CreateClient("Payment")));

            services.AddScoped<IPaymentServiceClient, PaymentServiceClient>();
            return services;
        }

        public static IServiceCollection AddMppaClient(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddHttpClients("Mppa");
            services.AddScoped(c => new MppaApiClient(configuration.GetValue<string>("MicroServices:Mppa"),
               c.GetService<IHttpClientFactory>().CreateClient("Mppa")));

            services.AddScoped<IMppaServiceClient, MppaServiceClient>();
            return services;
        }
        public static IServiceCollection AddTransactionClient(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddHttpClients("Transaction");
            services.AddScoped(c => new TransactionApiClient(configuration.GetValue<string>("MicroServices:Transaction"),
               c.GetService<IHttpClientFactory>().CreateClient("Transaction")));

            services.AddScoped<ITransactionServiceClient, TransactionServiceClient>();
            return services;
        }

    }
}
