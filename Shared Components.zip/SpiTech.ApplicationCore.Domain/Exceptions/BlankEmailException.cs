﻿using System;

namespace SpiTech.ApplicationCore.Domain.Exceptions
{
    public class BlankEmailException : Exception, IAppException
    {
        public string ExceptionName => "BlankEmailException";

        public string ExceptionMessage => Message;

        public string Resolution { get; }

        public BlankEmailException(string message = "Email not found") : base(message)
        {
        }
    }
}
