﻿using System;

namespace SpiTech.ApplicationCore.Domain.Exceptions
{
    public class ExecutionException : Exception, IAppException
    {
        public ExecutionException(string message) : base(message)
        {

        }

        public ExecutionException(string message, string resolution) : base(message)
        {
            Resolution = resolution;
        }

        public string ExceptionName => "Internal Application Error";

        public string ExceptionMessage => Message;

        public string Resolution { get; }
    }
}
