﻿using System;

namespace SpiTech.ApplicationCore.Domain.Exceptions
{
    public class RetryPolicyException : Exception, IAppException
    {
        public string ExceptionName => "Retry Policy Violation";

        public string ExceptionMessage => Message;

        public string Resolution { get; }

        public RetryPolicyException(string message) : base(message)
        {
        }

        public RetryPolicyException(string message, string resolution) : base(message)
        {
            Resolution = resolution;
        }
    }
}
