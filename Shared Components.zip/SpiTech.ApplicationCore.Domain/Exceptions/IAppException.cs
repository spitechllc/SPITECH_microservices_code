﻿namespace SpiTech.ApplicationCore.Domain.Exceptions
{
    public interface IAppException
    {
        public string ExceptionName { get; }
        public string ExceptionMessage { get; }
        public string Resolution { get; }
    }
}
