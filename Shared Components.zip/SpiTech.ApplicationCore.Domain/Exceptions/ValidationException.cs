using FluentValidation.Results;
using Newtonsoft.Json;
using SpiTech.ApplicationCore.Domain.Validations.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;

namespace SpiTech.ApplicationCore.Domain.Exceptions
{
    [Serializable]
    public class ValidationException : Exception, IAppException
    {
        public string ExceptionName => "Validation Error";

        public string ExceptionMessage => Message;

        public string Resolution { get; }

        public ValidationException()
            : base("One or more validation failures have occurred.")
        {
            Errors = new Dictionary<string, string[]>();
        }

        public ValidationException(IDictionary<string, string[]> failures) :
            base("One or more validation failures have occurred. " + Serialize(failures))
        {
            Errors = failures;
        }

        public ValidationException(params ValidationFailure[] failures)
            : base("One or more validation failures have occurred. " + Serialize(failures))
        {
            Errors = failures
                .GroupBy(e => e.PropertyName, e => e.ErrorMessage)
                .ToDictionary(failureGroup => failureGroup.Key, failureGroup => failureGroup.ToArray());
        }

        public ValidationException(ValidationResultModel validationResultModel)
            : base("One or more validation failures have occurred. " + Serialize(validationResultModel))
        {
            Errors = (validationResultModel?.Errors ?? new List<ValidationError>())
                .GroupBy(e => e.Field, e => e.Message)
                .ToDictionary(failureGroup => failureGroup.Key, failureGroup => failureGroup.ToArray());
        }

        protected ValidationException(
                  SerializationInfo info,
                  StreamingContext context) : base(info, context) { }


        public IDictionary<string, string[]> Errors { get; }

        private static string Serialize(object failures)
        {
            return JsonConvert.SerializeObject(failures, new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore });
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);

            if (info != null)
            {
                int i = 0;
                if (Errors != null)
                {
                    foreach (KeyValuePair<string, string[]> error in Errors)
                    {
                        if (error.Value != null)
                        {
                            foreach (string errorMessage in error.Value)
                            {
                                info.AddValue($"{error.Key}-{i}", errorMessage);
                                i++;
                            }
                        }
                    }
                }
            }
        }
    }
}
