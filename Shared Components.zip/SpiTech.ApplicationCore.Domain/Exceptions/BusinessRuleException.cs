﻿using System;

namespace SpiTech.ApplicationCore.Domain.Exceptions
{
    public class BusinessRuleException : Exception, IAppException
    {
        public string ExceptionName => "Business Rule Violation";

        public string ExceptionMessage => Message;

        public string Resolution { get; }

        public BusinessRuleException(string message) : base(message)
        {
        }

        public BusinessRuleException(string message, string resolution) : base(message)
        {
            Resolution = resolution;
        }
    }
}
