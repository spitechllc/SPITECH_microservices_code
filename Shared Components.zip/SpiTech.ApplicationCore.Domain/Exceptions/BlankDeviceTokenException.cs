﻿using System;

namespace SpiTech.ApplicationCore.Domain.Exceptions
{
    public class BlankDeviceTokenException : Exception, IAppException
    {
        public string ExceptionName => "BlankDeviceTokenException";

        public string ExceptionMessage => Message;

        public string Resolution { get; }

        public BlankDeviceTokenException(string message = "DeviceToken not found") : base(message)
        {
        }
    }
}
