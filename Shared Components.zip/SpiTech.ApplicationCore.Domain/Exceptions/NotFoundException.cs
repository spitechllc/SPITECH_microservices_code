﻿using System;

namespace SpiTech.ApplicationCore.Domain.Exceptions
{
    public class NotFoundException : Exception, IAppException
    {
        public NotFoundException()
           : base()
        {
        }
        public NotFoundException(string name, object key)
            : base($"Entity \"{name}\" ({key}) was not found.")
        {
        }
        public NotFoundException(string message) : base(message)
        {
        }
        public NotFoundException(string message, string resolution) : base(message)
        {
            Resolution = resolution;
        }

        public string ExceptionName => "InvalidApplicationConfiguration Error";

        public string ExceptionMessage => Message;

        public string Resolution { get; }
    }
}
