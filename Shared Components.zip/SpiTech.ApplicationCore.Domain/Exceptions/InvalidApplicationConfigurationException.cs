﻿using System;

namespace SpiTech.ApplicationCore.Domain.Exceptions
{
    public class InvalidApplicationConfigurationException : Exception, IAppException
    {
        public InvalidApplicationConfigurationException(string message) : base(message)
        {
        }
        public InvalidApplicationConfigurationException(string message, string resolution) : base(message)
        {
            Resolution = resolution;
        }

        public string ExceptionName => "InvalidApplicationConfiguration Error";

        public string ExceptionMessage => Message;

        public string Resolution { get; }
    }
}
