﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Domain.Sftp
{
    public class TransportResponse
    {
        public string DirectoryName { get; set; }
        public string FileName { get; set; }
        public DateTime FileTimeStamp { get; set; }
        public byte[] Bytes { get; set; }
        public List<TransportResponse> TransportResponses { get; set; }
    }
}
