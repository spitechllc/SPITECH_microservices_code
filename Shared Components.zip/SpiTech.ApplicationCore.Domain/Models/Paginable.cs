﻿using System;

namespace SpiTech.ApplicationCore.Domain.Models
{
    public class Paginable
    {

        /// <summary>
        /// From
        /// </summary>
        public virtual Nullable<int> Skip { get; set; } = 0;

        /// <summary>
        /// Take next
        /// </summary>
        /// 
        private Nullable<int> _take;

        public Nullable<int> Take
        {
            get => _take ?? 10;
            set => _take = value;
        }

    }
}
