﻿using System;
using System.ComponentModel.DataAnnotations;

namespace SpiTech.ApplicationCore.Domain.Models
{
    public class Sortable
    {
        /// <summary>
        /// Default column name
        /// </summary>
        public static string DEFAULT_SORT_BY = "CreatedOn";

        /// <summary>
        /// Default sorting direction
        /// </summary>
        public static string DEFAULT_SORT_ORDER = Direction.Desc;

        #region Props

        /// <summary>
        /// Criteria of sorting (column)
        /// </summary>
        public string SortBy { get; set; } = DEFAULT_SORT_BY;

        /// <summary>
        /// Direction of sorting (allowed for asc/desc)
        /// </summary>
        [RegularExpression("(^$)|(asc|desc)", ErrorMessage = "Allowed only asc/desc values")]
        public string SortOrder { get; set; } = DEFAULT_SORT_ORDER;

        #endregion

        /// <summary>
        /// Is it ascending sorting direction
        /// </summary>
        /// <returns></returns>
        public bool IsAscending()
        {
            return !string.IsNullOrEmpty(SortOrder) && SortOrder.Equals(Direction.Asc, StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Sorting direction options
        /// </summary>
        public static class Direction
        {
            /// <summary>
            /// Sorting by ascending
            /// </summary>
            public static readonly string Asc = "asc";

            /// <summary>
            /// Sorting by descending
            /// </summary>
            public static readonly string Desc = "desc";
        }
    }
}
