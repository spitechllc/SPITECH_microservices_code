﻿using System.Collections.Generic;

namespace SpiTech.ApplicationCore.Domain.Models
{
    public class ResponseList<T> where T : class
    {
        public ResponseList()
        {
        }
        public ResponseList(IEnumerable<T> data)
        {
            this.Data = data;
        } 
        public IEnumerable<T> Data { get; set; }
    }
}
