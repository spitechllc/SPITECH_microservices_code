﻿namespace SpiTech.ApplicationCore.Domain.Models
{
    public class ResponseModel
    {
        public bool Success { get; set; }
        public string Message { get; set; }
    }

    public class ResponseModel<T> : ResponseModel
    {
        public ResponseModel()
        {
        }
        public ResponseModel(T data)
        {
            Data = data;
            Success = object.Equals(data, default(T));
        }

        public T Data { get; set; }

        public ResponseModel GetResponse()
        {
            return new ResponseModel { Message = Message, Success = Success };
        }
    }
}
