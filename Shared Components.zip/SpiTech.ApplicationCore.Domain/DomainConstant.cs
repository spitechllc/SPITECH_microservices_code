﻿namespace SpiTech.ApplicationCore.Domain
{
    public static class DomainConstant
    {
        public static class SftpConfig
        {
            public const string STRIDE = "STRIDE";
            public const string FNBO = "FNBO";
        }
        public static class ProcessStatus
        {
            public const string None = "";
            public const string InProgress = "I";
            public const string Completed = "C";
            public const string Error = "E";
        }

        public static class IdentityRoleType
        {
            public const string ConsumerUser = "ConsumerUser";
            public const string BusinessUser = "BusinessUser";
            public const string StoreUser = "StoreUser";
            public const string SuperAdmin = "SuperAdmin";
            public const string APIClient = "APIClient";
        }

        //public static class IdentityPolicy
        //{
        //    public const string All = "All";
        //    public const string ConsumerUser = "ConsumerUser";
        //    public const string BusinessUser = "BusinessUser";
        //    public const string StoreUser = "StoreUser";
        //    public const string SuperAdmin = "SuperAdmin";
        //    public const string APIClient = "APIClient";
        //}
        public static class IdentityClaim
        {
            public const string RoleTypeClaim = "roletype";
            public const string ApiResourceClaim = "apiresource";
            public const string TenantId = "tenantid";
        }
        public static class StoreRoles
        {
            public const string StoreManager = "StoreManager";
            public const string StoreRegional = "StoreRegional";
            public const string StoreSupervisor = "StoreSupervisor";
        }

        public static class TenantName {
            public const string SpiTech = "SpiTech";
            public const string TheStation = "THEStation";
            public const string varifone = "Verifone";
            public const string Velocity = "Velocity";
        }
    }
}
