﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.ApplicationCore.Domain.Interfaces
{
    public interface ITenant
    {
        public int? TenantId { get; set; }
    }

    public interface ITenantClient : ITenant
    {
        public string ClientId { get; set; }
    }
}
