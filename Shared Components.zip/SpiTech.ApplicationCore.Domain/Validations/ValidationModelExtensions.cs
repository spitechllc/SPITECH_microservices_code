using FluentValidation;
using FluentValidation.Results;
using SpiTech.ApplicationCore.Domain.Validations.Models;
using System.Threading.Tasks;
using ValidationException = SpiTech.ApplicationCore.Domain.Exceptions.ValidationException;

namespace SpiTech.ApplicationCore.Domain.Validations
{
    public static class ValidationModelExtensions
    {
        private static ValidationResultModel ToValidationResultModel(this ValidationResult validationResult)
        {
            return new ValidationResultModel(validationResult);
        }

        public static async Task HandleValidation<TRequest>(this IValidator<TRequest> validator, TRequest request)
        {
            ValidationResult validationResult = await validator.ValidateAsync(request);
            if (!validationResult.IsValid)
            {
                throw new ValidationException(validationResult.ToValidationResultModel());
            }
        }
    }
}
