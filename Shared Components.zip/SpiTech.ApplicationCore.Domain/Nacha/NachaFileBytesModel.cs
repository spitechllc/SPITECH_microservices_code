﻿namespace SpiTech.ApplicationCore.Domain.Nacha
{
    public class NachaFileBytesModel
    {
        public byte[] Bytes { get; set; }
        public string File { get; set; }
    }
}
