﻿using SpiTech.ApplicationCore.Domain.Nacha.Constants;
using SpiTech.ApplicationCore.Domain.Nacha.Helpers;
using System;
using System.Collections.Generic;

namespace SpiTech.ApplicationCore.Domain.Nacha.Models
{
    public class NachaFile
    {
        public NachaFile()
        {
            _batches = new List<Batch>();

            Header = new FileHeader();
            Control = new FileControl();
        }

        private int _recordCount = 2;
        private int _nextBatchNumber = 4100001;
        private int _batchCount = 1;

        private readonly List<Batch> _batches;

        public FileHeader Header { get; }

        public FileControl Control { get; }

        public IReadOnlyList<Batch> Batches => _batches.AsReadOnly();

        public void Validate()
        {
            Header.Validate();
            Control.Validate();
        }

        public void AddBatch(Batch batch)
        {
            if (_nextBatchNumber > 9999999)
            {
                throw new InvalidOperationException(
                    ExceptionConstants.File_BatchMaximumExceeded);
            }

            _recordCount += 2;

            batch.Header.BatchNumber = _nextBatchNumber;
            batch.Control.BatchNumber = _nextBatchNumber;

            Control.BatchCount = _batchCount;
            Control.BlockCount = GetBlockCount(_recordCount);

            _nextBatchNumber++;
            _batchCount++;
            _batches.Add(batch);

            batch.EntryAdded += delegate (object sender, AddEntryEventArgs args)
            {
                _recordCount++;

                Control.BlockCount = GetBlockCount(_recordCount);

                Control.EntryAndAddendaCount++;

                Control.EntryHash = ControlHelper.GetEntryHash(args.Entry.RdfiRtn, Control.EntryHash);

                Control.TotalDebitAmount += ControlHelper.GetDebitAmount(args.Entry);

                Control.TotalCreditAmount += ControlHelper.GetCreditAmount(args.Entry);
            };
        }

        public int GetBlockCount(int recordCount)
        {
            decimal _recordCount = Convert.ToDecimal(recordCount);
            return Convert.ToInt32(Math.Ceiling(_recordCount / 10));
        }
    }
}
