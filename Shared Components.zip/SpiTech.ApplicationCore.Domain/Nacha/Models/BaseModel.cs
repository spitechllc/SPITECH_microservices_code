﻿using FileHelpers;
using SpiTech.ApplicationCore.Domain.Nacha.Constants;
using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using System;

namespace SpiTech.ApplicationCore.Domain.Nacha.Models
{
    public class BaseModel
    {
        [FieldOrder(10), FieldFixedLength(1)]
        private short _recordType;

        public short RecordType
        {
            get => _recordType;
            protected set => _recordType = Enum.IsDefined(typeof(RecordTypeEnum), value)
                    ? value
                    : throw new ArgumentOutOfRangeException(ExceptionConstants.BaseModel_RecordTypeInvalid);
        }
    }
}
