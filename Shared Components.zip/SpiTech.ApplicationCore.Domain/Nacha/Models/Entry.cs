﻿using FileHelpers;
using SpiTech.ApplicationCore.Domain.Nacha.Constants;
using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using SpiTech.ApplicationCore.Domain.Nacha.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SpiTech.ApplicationCore.Domain.Nacha.Models
{
    [FixedLengthRecord]
    public class Entry : BaseModel
    {
        private Entry()
        {
        }

        public Entry(string standardEntryClassCode)
        {
            RecordType = (short)RecordTypeEnum.EntryDetail;

            _addendaRecordIndicator = (short)AddendaRecordIndicatorEnum.NotIncluded;

            StandardEntryClassCode = standardEntryClassCode;
        }

        public string GetCheckDigit(string routingTransitNumber)
        {
            if (routingTransitNumber.Length != 8)
            {
                throw new ArgumentOutOfRangeException(
                    ExceptionConstants.Shared_RoutingNumberInvalid);
            }

            int _sum = 0;
            _sum += 3 * Convert.ToInt16(routingTransitNumber.Substring(0, 1));
            _sum += 7 * Convert.ToInt16(routingTransitNumber.Substring(1, 1));
            _sum += 1 * Convert.ToInt16(routingTransitNumber.Substring(2, 1));
            _sum += 3 * Convert.ToInt16(routingTransitNumber.Substring(3, 1));
            _sum += 7 * Convert.ToInt16(routingTransitNumber.Substring(4, 1));
            _sum += 1 * Convert.ToInt16(routingTransitNumber.Substring(5, 1));
            _sum += 3 * Convert.ToInt16(routingTransitNumber.Substring(6, 1));
            _sum += 7 * Convert.ToInt16(routingTransitNumber.Substring(7, 1));

            int _checkDigit = 10 - (_sum % 10);

            if (_checkDigit == 10) { _checkDigit = 0; }

            return Convert.ToString(_checkDigit);
        }

        public void Validate()
        {
            List<string> _message = new();

            FieldValidator.Validate(nameof(StandardEntryClassCode), StandardEntryClassCode, ref _message);

            FieldValidator.Validate(nameof(RecordType), RecordType, ref _message);
            FieldValidator.Validate(nameof(TransactionCode), TransactionCode, ref _message);
            FieldValidator.Validate(nameof(RdfiRtn), RdfiRtn, ref _message);
            FieldValidator.Validate(nameof(CheckDigit), CheckDigit, ref _message);
            FieldValidator.Validate(nameof(RdfiAccountNumber), RdfiAccountNumber, ref _message);
            //FieldValidator.ValidatePositive(nameof(Amount), Amount, ref _message);

            if (_message.Count > 0)
            {
                throw new ArgumentException(ExceptionConstants.Shared_RequiredProperties +
                    string.Join(", ", _message));
            }
        }

        public string StandardEntryClassCode
        {
            get => _standardEntryClassCode;
            set
            {
                if (!ConstantsHelper.IsValid(typeof(StandardEntryClassCodeConstant), value))
                {
                    throw new ArgumentOutOfRangeException(
                        ExceptionConstants.Entry_StandardEntryClassCodeInvalid);
                }

                _standardEntryClassCode = value;
            }
        }

        [FieldHidden]
        private string _standardEntryClassCode = "";

        [FieldOrder(20), FieldFixedLength(2)]
        private short _transactionCode;

        [FieldOrder(30), FieldFixedLength(8)]
        private string _rdfiRtn;

        [FieldOrder(40), FieldFixedLength(1)]
        private string _checkDigit;

        [FieldOrder(50), FieldFixedLength(17)]
        private string _rdfiAccountNumber;

        [FieldOrder(60), FieldFixedLength(10)]
        private string _amount;

        [FieldOrder(70), FieldFixedLength(15)]
        private string _receiverIdentificationNumber;

        [FieldOrder(80), FieldFixedLength(22)]
        private string _receiverName;

        [FieldOrder(90), FieldFixedLength(2)]
        private string _discretionaryData;

        [FieldOrder(100), FieldFixedLength(1)]
        private short _addendaRecordIndicator;

        [FieldOrder(110), FieldFixedLength(15)]
        private string _traceNumber;

        public short TransactionCode
        {
            get => _transactionCode;
            set
            {
                if (!Enum.IsDefined(typeof(TransactionCodeEnum), value))
                {
                    throw new ArgumentOutOfRangeException(
                        ExceptionConstants.Entry_TransactionCodeInvalid);
                }
                _transactionCode = value;
            }
        }

        //First 8 digits of the other party's ABA routing number
        public string RdfiRtn
        {
            get => _rdfiRtn;
            set
            {
                // value must be 8 chars and all numeric
                if (value.Length != 8 ||
                    !value.All(c => c >= '0' && c <= '9'))
                {
                    throw new ArgumentOutOfRangeException(
                        ExceptionConstants.Entry_RdfiRtnInvalid);
                }
                _rdfiRtn = value;
                //CheckDigit = GetCheckDigit(_rdfiRtn);
            }
        }

        //Last digit of the other party's ABA routing number
        public string CheckDigit
        {
            get => _checkDigit;
            set
            {
                // value must be 1 char and all numeric
                if (value.Length != 1 ||
                    !value.All(c => c >= '0' && c <= '9'))
                {
                    throw new ArgumentOutOfRangeException(
                        ExceptionConstants.Entry_CheckDigitInvalid);
                }
                _checkDigit = value;
            }
        }

        public string RdfiAccountNumber
        {
            get => _rdfiAccountNumber;
            set => _rdfiAccountNumber = value;
        }

        public long TotalAmount => long.Parse(_amount);


        public decimal Amount
        {
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException(
                        ExceptionConstants.Entry_AmountInvalid);
                }

                _amount = string.Format("{0:00000000.00}", value).Replace(".", "");
            }
        }

        public string ReceiverIdentificationNumber
        {
            get => _receiverIdentificationNumber;
            set => _receiverIdentificationNumber = value;
        }

        public string ReceiverName
        {
            get => _receiverName;
            set => _receiverName = value;
        }

        public string DiscretionaryData
        {
            get => _discretionaryData;
            set => _discretionaryData = value;
        }

        public short AddendaRecordIndicator
        {
            get => _addendaRecordIndicator;
            set
            {
                if (!Enum.IsDefined(typeof(AddendaRecordIndicatorEnum), value))
                {
                    throw new ArgumentOutOfRangeException(
                        ExceptionConstants.Entry_AddendaRecordIndicatorInvalid);
                }
                _addendaRecordIndicator = value;
            }
        }

        public string TraceNumber
        {
            get => _traceNumber;
            internal set => _traceNumber = value;
        }
    }
}
