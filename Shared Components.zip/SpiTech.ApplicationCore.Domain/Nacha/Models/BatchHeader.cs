﻿using FileHelpers;
using SpiTech.ApplicationCore.Domain.Nacha.Constants;
using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using SpiTech.ApplicationCore.Domain.Nacha.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace SpiTech.ApplicationCore.Domain.Nacha.Models
{
    [FixedLengthRecord]
    public class BatchHeader : BaseModel, INotifyPropertyChanged
    {

        #region Methods
        public BatchHeader()
        {
            RecordType = (short)RecordTypeEnum.BatchHeader;
            ServiceClassCode = BatchServiceClassCodeConstant.Mixed;
            OriginatorStatusCode = BatchHeaderOriginatorStatusCodeConstant.NonFederalGovernment;
            SettlementDate = "";
        }

        public void Validate()
        {
            List<string> _message = new();

            FieldValidator.Validate(nameof(RecordType), RecordType, ref _message);
            FieldValidator.Validate(nameof(ServiceClassCode), ServiceClassCode, ref _message);
            FieldValidator.Validate(nameof(CompanyName), CompanyName, ref _message);
            FieldValidator.Validate(nameof(CompanyIdentification), CompanyIdentification, ref _message);
            FieldValidator.Validate(nameof(StandardEntryClassCode), StandardEntryClassCode, ref _message);
            FieldValidator.Validate(nameof(CompanyEntryDescription), CompanyEntryDescription, ref _message);
            FieldValidator.Validate(nameof(OriginatorStatusCode), OriginatorStatusCode, ref _message);
            FieldValidator.Validate(nameof(OriginatingDfi), OriginatingDfi, ref _message);
            FieldValidator.Validate(nameof(BatchNumber), BatchNumber, ref _message);

            if (_message.Count > 0)
            {
                throw new ArgumentException(ExceptionConstants.Shared_RequiredProperties +
                    string.Join(", ", _message));
            }
        }

        protected void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        #region Fields
        [FieldOrder(20), FieldFixedLength(3)]
        private short _serviceClassCode;

        [FieldOrder(30), FieldFixedLength(16)]
        private string _companyName;

        [FieldOrder(40), FieldFixedLength(20)]
        private string _companyDiscretionaryData;

        [FieldOrder(50), FieldFixedLength(10)]
        private string _companyIdentification = "";

        [FieldOrder(60), FieldFixedLength(3)]
        private string _standardEntryClassCode;

        [FieldOrder(70), FieldFixedLength(10)]
        private string _companyEntryDescription;

        [FieldOrder(80), FieldFixedLength(6), FieldConverter(ConverterKind.Date, "yyMMdd")]
        private DateTime _companyDescriptiveDate;

        [FieldOrder(90), FieldFixedLength(6), FieldConverter(ConverterKind.Date, "yyMMdd")]
        private DateTime _effectiveEntryDate;

        [FieldOrder(100), FieldFixedLength(3)]
        private string _settlementDate;

        [FieldOrder(110), FieldFixedLength(1)]
        private short _originatorStatusCode;

        [FieldOrder(120), FieldFixedLength(8)]
        private string _originatingDfi;

        [FieldOrder(130), FieldFixedLength(7), FieldAlign(AlignMode.Right, '0')]
        private int _batchNumber;
        #endregion

        #region Properties
        public short ServiceClassCode
        {
            get => _serviceClassCode;
            set
            {
                if (!ConstantsHelper.IsValid(typeof(BatchServiceClassCodeConstant), value))
                {
                    throw new ArgumentOutOfRangeException(ExceptionConstants.BatchHeader_ServiceClassCodeInvalid);
                }

                if (!_serviceClassCode.Equals(value))
                {
                    _serviceClassCode = value;
                    NotifyPropertyChanged();
                }
            }
        }

        public string CompanyName
        {
            get => _companyName;
            set => _companyName = value;
        }

        public string CompanyDiscretionaryData
        {
            get => _companyDiscretionaryData;
            set => _companyDiscretionaryData = value;
        }

        //Typically a "1" + your Federal ID number(Account number). Determined by your bank.
        public string CompanyIdentification
        {
            get => _companyIdentification;
            set
            {
                // value must be 10 chars and all numeric
                if (value.Length > 10 ||
                    !value.All(c => c >= '0' && c <= '9'))
                {
                    throw new ArgumentException(
                        ExceptionConstants.BatchHeader_CompanyIdentificationInvalid);
                }

                if (!_companyIdentification.Equals(value))
                {
                    _companyIdentification = value.Trim();
                    NotifyPropertyChanged();
                }
            }
        }

        public string StandardEntryClassCode
        {
            get => _standardEntryClassCode;
            set
            {
                if (!ConstantsHelper.IsValid(typeof(StandardEntryClassCodeConstant), value))
                {
                    throw new ArgumentOutOfRangeException(
                        ExceptionConstants.BatchHeader_StandardEntryClassCodeInvalid);
                }

                _standardEntryClassCode = value;
            }
        }

        public string CompanyEntryDescription
        {
            get => _companyEntryDescription;
            set => _companyEntryDescription = value;
        }

        public DateTime CompanyDescriptiveDate
        {
            get => _companyDescriptiveDate;
            set => _companyDescriptiveDate = value;
        }

        public DateTime EffectiveEntryDate
        {
            get => _effectiveEntryDate;
            set => _effectiveEntryDate = value;
        }

        public string SettlementDate
        {
            get => _settlementDate;
            private set => _settlementDate = value;
        }

        public short OriginatorStatusCode
        {
            get => _originatorStatusCode;
            set
            {
                if (!ConstantsHelper.IsValid(
                    typeof(BatchHeaderOriginatorStatusCodeConstant), value))
                {
                    throw new ArgumentOutOfRangeException(
                        ExceptionConstants.BatchHeader_OriginatorStatusCodeInvalid);
                }

                _originatorStatusCode = value;
            }
        }

        //Enter the first 8 digits of your ABA routing number Must match the entry in the batch header.
        public string OriginatingDfi
        {
            get => _originatingDfi;
            set
            {
                // value must be 8 chars and all numeric
                if (value.Length != 8 ||
                    !value.All(c => c >= '0' && c <= '9'))
                {
                    throw new ArgumentException(
                        ExceptionConstants.BatchHeader_OriginatingDfiInvalid);
                }
                _originatingDfi = value;
                NotifyPropertyChanged();
            }
        }

        public int BatchNumber
        {
            get => _batchNumber;
            internal set => _batchNumber = value;
        }
        #endregion
    }
}
