﻿using SpiTech.ApplicationCore.Domain.Nacha.Constants;
using SpiTech.ApplicationCore.Domain.Nacha.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace SpiTech.ApplicationCore.Domain.Nacha.Models
{
    public class Batch
    {
        private int _nextEntryNumber = 4100101;
        private readonly List<Entry> _entries;

        public Batch()
        {
            _entries = new List<Entry>();

            Header = new BatchHeader();
            Control = new BatchControl();

            Header.PropertyChanged += delegate (object sender, PropertyChangedEventArgs e)
            {
                switch (e.PropertyName)
                {
                    case nameof(Header.CompanyIdentification):
                        Control.CompanyIdentification = Header.CompanyIdentification;
                        break;

                    case nameof(Header.ServiceClassCode):
                        Control.ServiceClassCode = Header.ServiceClassCode;
                        break;

                    case nameof(Header.OriginatingDfi):
                        Control.OriginatingDfi = Header.OriginatingDfi;
                        break;
                }
            };

            //Control.PropertyChanged += delegate (object sender, PropertyChangedEventArgs e)
            //{
            //    switch (e.PropertyName)
            //    {
            //        case nameof(Control.CompanyIdentification):
            //            Header.CompanyIdentification = Control.CompanyIdentification;
            //            break;

            //        case nameof(Control.ServiceClassCode):
            //            Header.ServiceClassCode = Control.ServiceClassCode;
            //            break;
            //    }
            //};
        }

        protected void NotifyEntryAdded(Entry entry)
        {
            EntryAdded?.Invoke(this, new AddEntryEventArgs { Entry = entry });
        }

        public event EventHandler<AddEntryEventArgs> EntryAdded;

        public BatchHeader Header { get; }

        public BatchControl Control { get; }

        public IReadOnlyList<Entry> Entries => _entries.AsReadOnly();

        public void AddEntry(Entry entry)
        {
            if (Header.StandardEntryClassCode == null)
            {
                Header.StandardEntryClassCode = entry.StandardEntryClassCode;
            }

            if (Header.StandardEntryClassCode != entry.StandardEntryClassCode)
            {
                throw new InvalidOperationException(
                    string.Format(ExceptionConstants.Batch_StandardEntryClassCodeMismatched,
                    Header.StandardEntryClassCode, entry.StandardEntryClassCode));
            }

            if (_nextEntryNumber >= 9999999)
            {
                throw new InvalidOperationException(
                    ExceptionConstants.Batch_EntryMaximumExceeded);
            }

            entry.Validate();

            Control.TotalCreditAmount += ControlHelper.GetCreditAmount(entry);

            Control.TotalDebitAmount += ControlHelper.GetDebitAmount(entry);

            entry.TraceNumber = CalculateEntryTraceNumber();

            _entries.Add(entry);
            _nextEntryNumber++;

            Control.EntryAndAddendaCount++;

            Control.EntryHash = ControlHelper.GetEntryHash(entry.RdfiRtn, Control.EntryHash);

            NotifyEntryAdded(entry);
        }

        private string CalculateEntryTraceNumber()
        {
            string _return = "000000" + _nextEntryNumber.ToString();
            _return = Header.OriginatingDfi + _return.Substring(_return.Length - 7, 7);
            return _return;
        }
    }
}
