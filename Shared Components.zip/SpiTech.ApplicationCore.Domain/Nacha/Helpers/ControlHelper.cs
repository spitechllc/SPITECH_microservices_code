﻿using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using SpiTech.ApplicationCore.Domain.Nacha.Models;
using System;

namespace SpiTech.ApplicationCore.Domain.Nacha.Helpers
{
    public static class ControlHelper
    {
        public static long GetCreditAmount(Entry entry)
        {
            switch (entry.TransactionCode)
            {
                case (short)TransactionCodeEnum.AutomatedDepositChecking:
                case (short)TransactionCodeEnum.AutomatedDepositSavings:
                case (short)TransactionCodeEnum.PrenoteOfCheckingCredit:
                case (short)TransactionCodeEnum.PrenoteOfSavingsCredit:
                    return entry.TotalAmount;

                default:
                    return 0;
            }
        }

        public static long GetDebitAmount(Entry entry)
        {
            switch (entry.TransactionCode)
            {
                case (short)TransactionCodeEnum.AutomatedPaymentChecking:
                case (short)TransactionCodeEnum.AutomatedPaymentSavings:
                case (short)TransactionCodeEnum.PrenoteOfCheckingDebit:
                case (short)TransactionCodeEnum.PrenoteOfSavingsDebit:
                    return entry.TotalAmount;

                default:
                    return 0;
            }
        }

        public static long GetEntryHash(string rdfiRtn, long currentHash)
        {
            long _newHash = currentHash + Convert.ToInt64(rdfiRtn);

            int _length = _newHash.ToString().Length;

            if (_length > 10)
            {
                _newHash = Convert.ToInt64(_newHash.ToString().Substring(_length - 10, 10));
            }

            return _newHash;
        }
    }
}
