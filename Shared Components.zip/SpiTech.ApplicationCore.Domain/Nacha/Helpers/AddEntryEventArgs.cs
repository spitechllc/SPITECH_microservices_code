﻿using SpiTech.ApplicationCore.Domain.Nacha.Models;
using System;

namespace SpiTech.ApplicationCore.Domain.Nacha.Helpers
{
    public class AddEntryEventArgs : EventArgs
    {
        public Entry Entry { get; set; }
    }
}
