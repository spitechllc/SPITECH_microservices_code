﻿using SpiTech.ApplicationCore.Domain.Nacha.Enums;

namespace SpiTech.ApplicationCore.Domain.Nacha
{
    public class MasterAccountModel
    {
        public string BankName { get; set; }
        public string AccountName { get; set; }
        public string RoutingNo { get; set; }
        public string AccountNo { get; set; }
        public AccountType AccountType { get; set; }
    }
}
