﻿namespace SpiTech.ApplicationCore.Domain.Nacha.Enums
{
    public enum TransactionCodeType
    {
        Credit = 1,
        Debit = 2
    }
}
