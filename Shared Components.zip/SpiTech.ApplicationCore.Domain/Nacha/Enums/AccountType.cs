﻿namespace SpiTech.ApplicationCore.Domain.Nacha.Enums
{
    public enum AccountType
    {
        Checking = 1,
        Savings = 2
    }
}
