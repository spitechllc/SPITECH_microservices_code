﻿namespace SpiTech.ApplicationCore.Domain.Nacha.Enums
{
    public enum AmountType
    {
        CreditDebit = 1,
        ACH = 2,
        CashReward = 3
    }
}
