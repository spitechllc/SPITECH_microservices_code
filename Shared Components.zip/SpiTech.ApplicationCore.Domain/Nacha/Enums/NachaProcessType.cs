﻿namespace SpiTech.ApplicationCore.Domain.Nacha.Enums
{
    //10 charecter only Allow in ENUM else it will break nachaFILE
    public enum NachaProcessType
    {
        NONE = 0,
        SETTLEMENT = 1,
        STOREBILL = 2,
        AGENTBILL = 3,
        RESELLERBILL = 4,
    }
}
