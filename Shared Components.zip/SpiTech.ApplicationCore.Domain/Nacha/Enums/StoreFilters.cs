﻿namespace SpiTech.ApplicationCore.Domain.Nacha.Enums
{
    public enum StoreFilters
    {
        None = 0,
        StoreSelection = 1,
        //ZipCode = 2,
        //City = 3,
        //State = 4,
        //GroupByCompany = 5,
    }
}
