﻿using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SpiTech.ApplicationCore.Domain.Nacha
{
    public class NachaProcessingModel
    {
        private readonly long identifier;
        public NachaProcessingModel()
        {
            identifier= DateTime.Now.Ticks;
        }
        public NachaConfig Config { get; set; }
        public List<NachaProcessingEntity> ProcessingEntities { get; set; }

        public string IdentificationNumber
        {
            get
            {
                return GetIdentification(Config.ProcessType);
            }
        }

        private string GetIdentification(NachaProcessType processType)
        {
            var key = "";
            switch (processType)
            {
                case NachaProcessType.NONE:
                    break;
                case NachaProcessType.SETTLEMENT:
                    key = "EOD";
                    break;
                case NachaProcessType.STOREBILL:
                    key = "SBL";
                    break;
                case NachaProcessType.AGENTBILL:
                    key = "ABL";
                    break;
                case NachaProcessType.RESELLERBILL:
                    key = "RBL";
                    break;
                default:
                    break;
            }

            return key + identifier.ToString(string.Concat(Enumerable.Repeat("0", 12)));
        }

    }

    public class NachaProcessingEntity
    {
        public virtual object Entity { get; set; }
        public List<NachaModel> Accounts { get; set; }

        public T GetEntity<T>()
        {
            return (T)Entity;
        }
    }

}
