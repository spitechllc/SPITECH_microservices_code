﻿using SpiTech.ApplicationCore.Domain.Nacha.Enums;
using System;

namespace SpiTech.ApplicationCore.Domain.Nacha
{
    public class NachaConfig
    {
        public string BankRoutingNo { get; set; }
        public string AccountNo { get; set; }
        public string RoutingNo { get; set; }
        public string BankName { get; set; }
        public string ImmediateOriginName { get; set; }
        public string BatchCompanyName { get; set; }
        public NachaProcessType ProcessType { get; set; }
        public DateTime EffectiveEntryDate { get; set; }
    }
}
