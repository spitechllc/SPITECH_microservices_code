﻿using SpiTech.ApplicationCore.Domain.Nacha.Enums;

namespace SpiTech.ApplicationCore.Domain.Nacha
{
    public class NachaModel
    {
        public string BatchCompanyName { get; set; }
        public object AccountEntityId { get; set; }
        public decimal Amount { get; set; }
        public AmountType AmountType { get; set; }
        public string IdentificationNumber { get; set; }
        public NachaAccount ProcessingAccount { get; set; }
        public TransactionCodeType TransactionCodeType { get; set; }
    }

    public class NachaAccount
    {
        public string BankName { get; set; }
        public string AccountName { get; set; }
        public string RoutingNo { get; set; }
        public string AccountNo { get; set; }
        public AccountType AccountType { get; set; }
    }
}
