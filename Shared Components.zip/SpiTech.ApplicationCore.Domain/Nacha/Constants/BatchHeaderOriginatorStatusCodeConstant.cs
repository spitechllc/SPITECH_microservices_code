﻿namespace SpiTech.ApplicationCore.Domain.Nacha.Constants
{
    public class BatchHeaderOriginatorStatusCodeConstant
    {
        public const short NonFederalGovernment = 1;
    }
}
