﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace SpiTech.ApplicationCore.Domain.Nacha.Constants
{
    public static class ConstantsHelper
    {
        public static bool IsValid(Type T, string Value)
        {
            IEnumerable<FieldInfo> _properties = GetFields(T);

            List<string> _constants = _properties.Select(constant => (string)constant.GetRawConstantValue()).ToList();

            string _match = _constants.SingleOrDefault(contantValue => contantValue == Value);

            return _match != null;
        }

        public static bool IsValid(Type T, short Value)
        {
            IEnumerable<FieldInfo> _properties = GetFields(T);

            List<short?> _constants = _properties.Select(constant => (short?)constant.GetRawConstantValue()).ToList();

            short? _match = _constants.SingleOrDefault(contantValue => contantValue == Value);

            return _match != null;
        }

        private static IEnumerable<FieldInfo> GetFields(Type T)
        {
            return T.GetFields(
                BindingFlags.Public |
                BindingFlags.Static |
                BindingFlags.FlattenHierarchy)
                .Where(fi => fi.IsLiteral && !fi.IsInitOnly);
        }
    }
}
