﻿namespace SpiTech.ApplicationCore.Domain.Nacha.Constants
{
    public class BatchServiceClassCodeConstant
    {
        public const short Credits = 220;
        public const short Debits = 225;
        public const short Mixed = 200;
    }
}
