﻿namespace SpiTech.ApplicationCore.Domain.Nacha.Constants
{
    public static class StandardEntryClassCodeConstant
    {
        public const string CCD = "CCD";
        public const string PPD = "PPD";
    }
}
