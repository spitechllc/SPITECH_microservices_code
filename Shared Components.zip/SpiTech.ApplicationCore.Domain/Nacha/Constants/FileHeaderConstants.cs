﻿namespace SpiTech.ApplicationCore.Domain.Nacha.Constants
{
    public static class FileHeaderConstants
    {
        public const string PriorityCode = "01";
        public const string RecordSize = "094";
        public const short FormatCode = 1;
        public const short BlockingFactor = 10;
    }
}
