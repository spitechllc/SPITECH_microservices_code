﻿using System.Collections.Generic;
using System.Linq;

namespace SpiTech.ApplicationCore.Domain.Configs
{
    public class SftpConfigs : List<SftpConfig>
    {
        public SftpConfig Get(string name)
        {
            return this.FirstOrDefault(t => t.Name.Equals(name, System.StringComparison.InvariantCultureIgnoreCase));
        }
    }

    public class SftpConfig
    {
        public string Name { get; set; }
        public string Host { get; set; }
        public int Port { get; set; }
        public string UserName { get; set; }
        public string PrivateKeyFile { get; set; }
        public string Password { get; set; }
        public string PassPhrase { get; set; }
        public string UploadFolder { get; set; }
        public string DownloadFolder { get; set; }
        public bool Enabled { get; set; }
        public string EncryptKeyFile { get; set; }
        public string DecryptKeyFile { get; set; }
        public string DecryptPassword { get; set; }
        public string ExecReturnFile { get; set; }
    }
}
