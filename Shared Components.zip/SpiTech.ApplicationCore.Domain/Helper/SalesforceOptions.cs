﻿namespace SpiTech.ApplicationCore.Domain.Helper
{
    public class SalesforceOptions
    {
        public string TokenEndpoint { get; set; }
        public string Client_Id { get; set; }
        public string Client_Secret { get; set; }
        public string Refresh_Token { get; set; }
        public string DomainUrl { get; set; }
    }
}
