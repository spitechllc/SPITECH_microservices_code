# Tools Update
npm i -g nswag

Go to Respective folder and  run command line --> nswag run swagger.nswag /runtime:Net50


OR

NSwag openapi2csclient /className:IdentityApiClient /namespace:SpiTech.Service.Clients.Identity /input:".\swagger.json" /output:".\IdentityApiClient.cs"

NSwag openapi2csclient /className:StoreApiClient /namespace:SpiTech.Service.Clients.Stores /input:".\swagger.json" /output:".\StoreApiClient.cs"

NSwag openapi2csclient /className:PaymentApiClient /namespace:SpiTech.Service.Clients.Payments /input:".\swagger.json" /output:".\PaymentApiClient.cs"

NSwag openapi2csclient /className:TransactionApiClient /namespace:SpiTech.Service.Clients.Transactions /input:".\swagger.json" /output:".\TransactionApiClient.cs"


NSwag openapi2csclient /className:ReportApiClient /namespace:SpiTech.Service.Clients.Reports /input:".\swagger.json" /output:".\ReportApiClient.cs"

NSwag openapi2csclient /className:MppaApiClient /namespace:SpiTech.Service.Clients.Mppa /input:".\swagger.json" /output:".\MppaApiClient.cs"



NSwag openapi2csclient /className:FinanceApiClient /namespace:SpiTech.Service.Clients.Finance /input:".\swagger.json" /output:".\FinanceApiClient.cs"
