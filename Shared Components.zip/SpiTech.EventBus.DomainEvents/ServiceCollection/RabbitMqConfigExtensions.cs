using GreenPipes;
using MassTransit;
using MassTransit.ExtensionsDependencyInjectionIntegration;
using MassTransit.RabbitMqTransport;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using RabbitMQ.Client;
using System;
using System.Linq;

namespace SpiTech.EventBus.DomainEvents.ServiceCollection
{
    public static class RabbitMqConfigExtensions
    {
        public static RabbitMqConfiguration RegisterRabbitMqConfiguration(IConfiguration configuration)
        {
            return configuration.GetSection(nameof(RabbitMqConfiguration)).Get<RabbitMqConfiguration>();
        }

        public static IServiceCollection RegisterMessageQueue(this IServiceCollection services,
                                                            IConfiguration configuration,
                                                            Action<IServiceCollectionBusConfigurator> busConfigurator = null,
                                                            Action<IBusRegistrationContext, IRabbitMqBusFactoryConfigurator> configureRabbitMqBusFactory = null)
        {
            services.AddScoped<IEventDispatcher, RabbitMqEventDispatcher>();
            services.AddAutoMapper(typeof(EventBusConstants));
            RabbitMqConfiguration rabbitmqConfig = RegisterRabbitMqConfiguration(configuration);

            string clusterName = rabbitmqConfig.UseCluster ? rabbitmqConfig.ClusterName : rabbitmqConfig.HostNames.First();

            // MassTransit-RabbitMQ Configuration
            services.AddMassTransit(config =>
            {

                if (busConfigurator != null)
                {
                    busConfigurator(config);
                }

                config.UsingRabbitMq((ctx, cfg) =>
                {
                    //config.UseCircuitBreaker(cb =>
                    //{
                    //    cb.TrackingPeriod = TimeSpan.FromMinutes(1);
                    //    cb.TripThreshold = 15;
                    //    cb.ActiveThreshold = 10;
                    //    cb.ResetInterval = TimeSpan.FromMinutes(5);
                    //});
                    cfg.UseMessageRetry(r => r.Interval(5, TimeSpan.FromSeconds(10)));
                    cfg.Host(new Uri($"rabbitmq://{clusterName}/{rabbitmqConfig.VirtualHost}"), h =>
                    {
                        h.Username(rabbitmqConfig.UserName);
                        h.Password(rabbitmqConfig.Password);
                        if (rabbitmqConfig.UseCluster)
                        {
                            h.UseCluster(c =>
                            {
                                foreach (string node in rabbitmqConfig.HostNames)
                                {
                                    c.Node(node);
                                }
                            });
                        }
                    });

                    cfg.AutoDelete = false;
                    cfg.Durable = true;
                    //  cfg.UseHealthCheck(ctx);

                    if (configureRabbitMqBusFactory != null)
                    {
                        configureRabbitMqBusFactory(ctx, cfg);
                    }
                });
            });
            services.AddMassTransitHostedService();

            return services;
        }


        public static void ConfigurePublishEvent<T>(this IRabbitMqBusFactoryConfigurator cfg) where T : class
        {
            string eventName = typeof(T).Name.ToLower();

            //cfg.Message<T>(e => e.SetEntityName(typeName)); // name of the primary exchange

            cfg.Send<T>(x =>
            {
                x.UseRoutingKeyFormatter(context => eventName);
            });
            cfg.Publish<T>(x =>
            {
                x.ExchangeType = ExchangeType.Direct; // primary exchange type
            });
        }

        public static void BindConsumer<T, C>(this IRabbitMqBusFactoryConfigurator configurator, IBusRegistrationContext ctx, string servicePrefix) where T : class where C : class, IConsumer
        {
            string typeName = servicePrefix + "-" + typeof(T).Name.ToLower() + "-queue";

            configurator.Publish<T>(e => e.ExchangeType = ExchangeType.Direct);
            configurator.ReceiveEndpoint(typeName, c =>
            {
                c.ConfigureConsumeTopology = false;
                //c.PrefetchCount = 1;
                //c.UseConcurrencyLimit(1);

                c.BindConsumer<T, C>(ctx);
            });
        }

        public static void BindConsumer<T, C>(this IRabbitMqReceiveEndpointConfigurator configurator, IBusRegistrationContext ctx) where T : class where C : class, IConsumer
        {
            string eventName = typeof(T).Name.ToLower();

            configurator.Bind<T>(x =>
            {
                x.ExchangeType = ExchangeType.Direct;
                x.RoutingKey = eventName;
            });

            configurator.ConfigureConsumer<C>(ctx);
        }
    }
}
