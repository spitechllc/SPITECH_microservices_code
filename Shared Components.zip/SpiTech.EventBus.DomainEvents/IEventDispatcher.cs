﻿using SpiTech.EventBus.DomainEvents.Events;
using System.Threading.Tasks;

namespace SpiTech.EventBus.DomainEvents
{
    public interface IEventDispatcher
    {
        Task Dispatch<T>(T domainEvent) where T : IntegrationBaseEvent;
    }
}
