﻿using System.Text.Json.Serialization;

namespace SpiTech.EventBus.DomainEvents.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum CodeType
    {
        None = 0,
        LinkUser = 1,
        ForgotPasswordEmail = 2,
        ForgotPasswordSms = 3,
        MobileVerification = 4,
        EmailVerification = 5,
        UserUnlock = 6,
    }
}
