﻿using System.Text.Json.Serialization;

namespace SpiTech.EventBus.DomainEvents.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum CreditType
    {
        None = 0,
        Loyalty = 1,
        Promotion = 2,
        LinkUserTransfer = 3,
        AdminCredit = 4
    }
}
