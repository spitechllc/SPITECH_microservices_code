﻿using System.Text.Json.Serialization;

namespace SpiTech.EventBus.DomainEvents.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum EntityRoleType
    {
        None = 0,
        External = 1,
        Internal = 2
    }
}
