﻿namespace SpiTech.EventBus.DomainEvents.Enums
{
    public enum StoreEmailCategoryTypeLevel
    {
        None = 0,
        Main = 11,
        Invoice = 12,
        EODSettlementSuccess = 13,
        EODSettlementFail = 14,
        DailySettlement = 15,
        MonthlySettlement = 16,
        SupportTeam = 17,
        EODSettlementNachaNotification = 30,
        ACHReturnNachaNotification = 31,

    }
    public enum CompanyEmailCategoryTypeLevel
    {
        None = 0,
        Main = 9,
        Others = 10
    }
}
