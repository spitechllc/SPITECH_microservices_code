﻿using System.Text.Json.Serialization;

namespace SpiTech.EventBus.DomainEvents.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum EnumPaymentMethod : int
    {
        None = 0,
        CreditCard = 1,
        ACH = 2,
        CashReward = 3
    }
}
