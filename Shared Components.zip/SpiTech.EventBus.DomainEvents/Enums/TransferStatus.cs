﻿using System.Text.Json.Serialization;

namespace SpiTech.EventBus.DomainEvents.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum TransferStatus
    {
        None = 0,
        New = 1,
        Accepted = 2,
        Transfered = 3,
        Rejected = 4,
        InsufficientBalance = 5,
        Error = 6,
    }
}
