﻿using System.Text.Json.Serialization;

namespace SpiTech.EventBus.DomainEvents.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum RequestType
    {
        None = 0,
        MobilePumpReserve = 1,
        MobileTransactionData = 2,
        MobileAuth = 3,
        MobileCancel = 4,
        BeginFueling = 5,
        MobileFinalize = 6,
        MobileReceiptData = 7,
        MobileStacCapture = 8,
        MobileSettlement = 9,
        MobileSiteData = 10,
        MobileHeartBeat = 11,
        MobileStacGenerate = 12,
        MobileLoyaltyAward = 13,
    }
}
