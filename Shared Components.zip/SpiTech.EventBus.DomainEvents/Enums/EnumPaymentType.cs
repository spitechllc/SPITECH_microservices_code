﻿using System.Text.Json.Serialization;

namespace SpiTech.EventBus.DomainEvents.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum PaymentType
    {
        None = 0,
        StorePumpReserve = 1,
        StorePos = 2,
        VehicleWash = 3,
        AccountInvoice = 4,
    }
}
