﻿using System.Text.Json.Serialization;

namespace SpiTech.EventBus.DomainEvents.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum DebitType
    {
        None = 0,
        StorePumpReserve = 1,
        StorePos = 2,
        LinkUserTransfer = 3,
        AdminDebit = 4
    }
}
