﻿namespace SpiTech.EventBus.DomainEvents.Enums
{
    public enum InvocieTemplateEnum
    {
        Template1 = 1,
        Template2 = 2,
        Template3 = 3,
        Template4 = 4
    }
}
