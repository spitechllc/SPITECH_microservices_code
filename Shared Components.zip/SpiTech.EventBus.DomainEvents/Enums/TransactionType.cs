﻿using System.Text.Json.Serialization;

namespace SpiTech.EventBus.DomainEvents.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum TransactionType
    {
        None = 0,
        FuelReserve = 1,
        CarWash = 2,
        PayAtPos = 3
    }
}
