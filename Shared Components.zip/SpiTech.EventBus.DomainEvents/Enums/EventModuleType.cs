﻿using System.Text.Json.Serialization;

namespace SpiTech.EventBus.DomainEvents.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum EventModuleType
    {
        None = 0,
        Identity = 1,
        Store = 2,
        MPPA = 3,
        Transaction = 4,
        Payment = 5,
        Marketing = 6,
        Finance = 7,
        Account = 8,
        Notification=9,
    }
}
