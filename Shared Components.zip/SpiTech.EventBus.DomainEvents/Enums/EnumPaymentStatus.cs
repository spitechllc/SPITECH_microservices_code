﻿using System.Text.Json.Serialization;

namespace SpiTech.EventBus.DomainEvents.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum EnumPaymentStatus
    {
        None = 0,
        Initiated = 1,
        Processed = 2,
        Success = 3,
        Void = 4,
        Fail = 5
    }
}
