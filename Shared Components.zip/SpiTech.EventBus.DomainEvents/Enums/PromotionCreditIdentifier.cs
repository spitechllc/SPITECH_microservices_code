﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.EventBus.DomainEvents.Enums
{
    public  enum PromotionCreditIdentifier:int
    {
        AddCard=1,
        TransactionSequenceNo=2,
        //TransactionSequenceNo=3,
    }
}
