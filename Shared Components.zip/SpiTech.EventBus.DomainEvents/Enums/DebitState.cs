﻿using System.Text.Json.Serialization;

namespace SpiTech.EventBus.DomainEvents.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum DebitState
    {
        None = 0,
        PreAuth = 1,
        Completed = 2,
        Error = 3,
    }
}
