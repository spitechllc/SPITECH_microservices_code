﻿using System.Text.Json.Serialization;

namespace SpiTech.EventBus.DomainEvents.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum MobileAppType
    {
        None = 0,
        Consumer = 1,
        Business = 2
    }
}
