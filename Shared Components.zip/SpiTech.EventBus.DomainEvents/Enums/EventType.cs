﻿using System.Text.Json.Serialization;

namespace SpiTech.EventBus.DomainEvents.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum EventType
    {
        None = 0,
        IdentityUserCreated = 100,
        IdentityUserUpdated = 101,
        IdentityForgotPassword = 102,
        IdentityPasswordChanged = 103,
        IdentityUserSignIn = 104,
        IdentityUserDeviceUpdated = 105,
        UserLinkedAccepterEvent = 106,
        IdentityUserVerificationCode = 107,
        UserLinkedRequesterEvent = 108,
        IdentityUserEmailVerifiedEvent = 109,
        IdentityUserUnlockedEvent = 110,

        StoreEvent = 200,
        StoreUserEvent = 201,
        StoreBillingFeeEvent = 202,

        MppaPaymentProcessEvent = 300,
        PumpReserveRequestEvent = 301,
        AuthMppaRequestEvent = 302,
        BeginFuelingRequestEvent = 303,
        FinalizeRequestEvent = 304,
        ReceiptDataRequestEvent = 305,
        TransactionUpdateEvent = 306,
        TransactionSettlementEvent = 307,
        MobilePumpReserveResponsesEvent = 308,
        MobilePumpBeginFualResponsesEvent = 309,
        MobileFinalReceiptResponsesEvent = 310,
        StaCaptureRequestEvent = 311,
        TransactionDataResponseEvent = 312,
        MobilePosTransactionDataProcessResponsesEvent = 313,
        MobileStacCaptureResponsesEvent = 314,
        MobileStacGenerationResponsesEvent = 315,
        MobileFinalizesDataResponseEvent = 316,
        MobilePumpProcessStatusResponsesEvent = 317,
        SiteEvent = 318,
        ReconcileFailTransactionEvent = 319,

        TransactionEvent = 400,
        StoreMonthlyBillingInvoiceEvent = 401,
        SaleAgentMonthlyBillingInvoiceEvent = 402,
        StoreEodSettlementEvent = 403,
        StoreEodSettlementInvoiceAdminEvent = 404,
        StoreEodSettlementInvoiceEvent = 405,
        ResellerMonthlyBillingInvoiceEvent = 406,
        AchNachaReturnFileEvent = 407,

        PaymentStatusEvent = 500,
        PaymentMethodAddedEvent = 501,
        PaymentMethodRemovedEvent = 502,
        PaymentFailedEvent = 503,
        PaymentFailureSupportTeamEvent = 504,

        ConsumerOfferSendEvent = 600,
        PromotionLoyaltyEvent = 601,

        WalletCreditEvent = 700,
        WalletDebitEvent = 701,
        WalletVoidPaymentEvent = 703,
        ExpiringWalletCreditEvent = 704,
        TransferRequestEvent = 705,
        TransferRequestDeclinedEvent = 706,

        InvoiceSendEvent = 800,
        InvoiceReceiveEvent = 801,
        InvoiceCancelledEvent = 802,
        InvoiceRejectedEvent = 803,
        InvoicePaidEvent = 804,

        UserActivityLogEvent=900,
        AppNotificationEvent = 901,
    }
}
