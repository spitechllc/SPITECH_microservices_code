﻿using System.Text.Json.Serialization;

namespace SpiTech.EventBus.DomainEvents.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum Status
    {
        None = 0,
        Inprogress = 1,
        Success = 2,
        Fail = 3,
        Canceled = 4,
    }
}
