﻿namespace SpiTech.EventBus.DomainEvents.Enums
{
    public enum DeviceType
    {
        None = 0,
        Android = 1,
        iOS = 2
    }
}
