﻿using System.Collections.Generic;

namespace SpiTech.EventBus.DomainEvents
{
    public class RabbitMqConfiguration
    {
        public string VirtualHost { get; set; }
        public bool UseCluster { get; set; }
        public string ClusterName { get; set; }
        public List<string> HostNames { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
