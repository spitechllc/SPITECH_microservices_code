﻿using MassTransit;
using SpiTech.Application.Logging.Interfaces;
using SpiTech.EventBus.DomainEvents.Events;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace SpiTech.EventBus.DomainEvents
{
    internal class RabbitMqEventDispatcher : IEventDispatcher
    {
        private readonly IPublishEndpoint _publishEndpoint;
        private readonly ILogger<RabbitMqEventDispatcher> logger;

        public RabbitMqEventDispatcher(IPublishEndpoint publishEndpoint, ILogger<RabbitMqEventDispatcher> logger)
        {
            _publishEndpoint = publishEndpoint;
            this.logger = logger;
        }
        public async Task Dispatch<T>(T eventMessage) where T : IntegrationBaseEvent
        {
            try
            {
                logger.Warn("RabbitMqEventDispatcher start");
                CancellationTokenSource cts = new();
                cts.CancelAfter(TimeSpan.FromSeconds(10));
                CancellationToken cancellationToken = cts.Token;
                logger.Warn("RabbitMqEventDispatcher for Publish");
                await _publishEndpoint.Publish(eventMessage, eventMessage.GetType(), cancellationToken);
            }
            catch (Exception ex)
            {
                logger.Warn("RabbitMqEventDispatcher Error for Publish");
                logger.Error(ex, ex.Message);
            }
        }
    }
}
