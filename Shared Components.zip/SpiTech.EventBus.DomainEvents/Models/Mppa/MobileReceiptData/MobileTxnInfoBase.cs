﻿namespace SpiTech.EventBus.DomainEvents.Models.Mppa.MobileReceiptData
{
    public class MobileTxnInfoBase
    {
        public string UMTI { get; set; }
        public string MerchantId { get; set; }
        public string TimeDateStamp { get; set; }
        public string SiteId { get; set; }
    }
}
