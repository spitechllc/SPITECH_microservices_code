﻿namespace SpiTech.EventBus.DomainEvents.Models.Mppa.MobileReceiptData
{

    public class ItemsPurchased
    {
        public SaleItem[] SaleItems { get; set; }
    }
}