﻿namespace SpiTech.EventBus.DomainEvents.Models.Mppa.MobileReceiptData
{
    public class MobileTxnInfoRequest : MobileTxnInfoBase
    {
        public string POSTransNumber { get; set; }
        public int FuelingPositionId { get; set; }
        public string SiteMPPAIdentifier { get; set; }
    }
}
