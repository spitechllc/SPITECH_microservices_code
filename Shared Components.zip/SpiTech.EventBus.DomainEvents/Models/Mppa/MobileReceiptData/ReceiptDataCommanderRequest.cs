﻿namespace SpiTech.EventBus.DomainEvents.Models.Mppa.MobileReceiptData
{

    public class ReceiptDataCommanderRequest : MessageCommand
    {
        public MobileTxnInfoRequest MobileTxnInfo { get; set; }
        public MobileReceiptDataRequest MobileReceiptDataRequest { get; set; }
    }

    public class MobileReceiptDataRequest
    {
        public ReceiptInfo ReceiptInfo { get; set; }
        public ItemsPurchased ItemsPurchased { get; set; }
    }
}
