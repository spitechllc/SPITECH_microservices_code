﻿namespace SpiTech.EventBus.DomainEvents.Models.Mppa.MobileReceiptData
{
    public class Response
    {
        public string OverallResult { get; set; }
        public string ResponseCode { get; set; }
        public string MessageCode { get; set; }
    }
}