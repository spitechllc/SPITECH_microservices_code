﻿namespace SpiTech.EventBus.DomainEvents.Models.Mppa.MobileReceiptData
{
    public class MobileResponse
    {
        public Response Response { get; set; }
    }
}