﻿namespace SpiTech.EventBus.DomainEvents.Models.Mppa.MobileReceiptData
{

    public class ReceiptDataMppaResponse : MessageCommand
    {
        public MobileTxnInfoResponse MobileTxnInfo { get; set; }
        public MobileResponse MobileReceiptDataResponse { get; set; }
    }
}
