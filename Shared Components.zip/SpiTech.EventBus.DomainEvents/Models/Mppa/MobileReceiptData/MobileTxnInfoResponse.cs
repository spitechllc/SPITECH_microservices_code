﻿namespace SpiTech.EventBus.DomainEvents.Models.Mppa.MobileReceiptData
{
    public class MobileTxnInfoResponse : MobileTxnInfoRequest
    {
        public string HostMPPAIdentifier { get; set; }
    }
}
