﻿namespace SpiTech.EventBus.DomainEvents.Models.Mppa.MobileReceiptData
{
    public class ReceiptInfo
    {
        public string[] ReceiptLines { get; set; }
    }
}