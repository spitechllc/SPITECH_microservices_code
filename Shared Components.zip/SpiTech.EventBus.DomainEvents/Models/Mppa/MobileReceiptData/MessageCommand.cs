﻿namespace SpiTech.EventBus.DomainEvents.Models.Mppa.MobileReceiptData
{
    public class MessageCommand
    {
        public string Version { get; set; }
    }
}
