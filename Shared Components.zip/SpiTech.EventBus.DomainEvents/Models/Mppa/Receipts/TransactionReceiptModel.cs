﻿using System.Collections.Generic;
using System.Linq;

namespace SpiTech.EventBus.DomainEvents.Models.Mppa.Receipts
{
    public class TransactionReceiptModel
    {
        public Transaction Transaction { get; set; }
        public PaymentInfo PaymentInfo { get; set; }
        public string SiteName { get; set; }
        public string SiteAddress { get; set; }
        public decimal Tax => SaleItems != null ? SaleItems.FirstOrDefault(t => t.Description.Equals("Tax"))?.OriginalAmount ?? 0m : 0;

        public decimal SubTotal => Total - Tax;
        public decimal Total => Transaction != null ? Transaction.FinalAmount : 0;

        public IEnumerable<SaleItem> SaleItems { get; set; }
        public IEnumerable<string> ReceiptInfoLines { get; set; }
    }
}
