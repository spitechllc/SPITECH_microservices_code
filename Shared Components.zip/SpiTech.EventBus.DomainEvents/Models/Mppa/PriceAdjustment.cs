﻿namespace SpiTech.EventBus.DomainEvents.Models.Mppa
{
    public class PriceAdjustment
    {
        public bool RewardApplied { get; set; }
        public string PriceAdjustmentId { get; set; }
        public string ProgramId { get; set; }
        public bool DoNotRelieveTaxFlag { get; set; }
        public string PromotionReason { get; set; }
        public decimal Amount { get; set; }
        public bool UnitPrice { get; set; }
        public decimal Quantity { get; set; }
        public string RebateLabel { get; set; }
    }
}
