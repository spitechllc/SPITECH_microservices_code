﻿namespace SpiTech.EventBus.DomainEvents.Models.Mppa
{
    public class PumpBeginFualResponseModel
    {
        public long TransactionId { get; set; }
        public string SiteId { get; set; }
        public string UMTI { get; set; }
        public int UserId { get; set; }
        public bool BeginFuel { get; set; }
        public string BeginFuelMessage { get; set; }
    }
}
