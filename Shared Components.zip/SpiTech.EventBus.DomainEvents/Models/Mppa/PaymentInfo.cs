﻿namespace SpiTech.EventBus.DomainEvents.Models.Mppa
{
    public class PaymentInfo
    {
        public string CardPANPrint { get; set; }
        public string CardISO { get; set; }
        public string CardCircuit { get; set; }
        public string PaymentMethod { get; set; }
        public string HostAuthNumber { get; set; }
        public string CardType { get; set; }
        public decimal PreAuthAmount { get; set; }
    }
}
