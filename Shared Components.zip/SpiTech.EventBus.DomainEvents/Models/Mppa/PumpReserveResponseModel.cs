﻿namespace SpiTech.EventBus.DomainEvents.Models.Mppa
{
    public class PumpReserveResponseModel
    {
        public long TransactionId { get; set; }
        public string UMTI { get; set; }
        public int UserId { get; set; }
        public string SiteId { get; set; }
        public int FuelingPositionId { get; set; }
        public string Status { get; set; }
        public bool Success { get; set; }
        public string Erorr { get; set; }
    }
}
