﻿namespace SpiTech.EventBus.DomainEvents.Models.Mppa
{
    public class TransactionReportEmail
    {
        public byte[] ReportPdf { get; set; }
        public string SiteId { get; set; }
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public int UserId { get; set; }
        public string ReportType { get; set; }
    }
}
