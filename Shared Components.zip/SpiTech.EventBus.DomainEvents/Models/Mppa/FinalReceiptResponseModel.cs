﻿using SpiTech.EventBus.DomainEvents.Models.Mppa.Receipts;

namespace SpiTech.EventBus.DomainEvents.Models.Mppa
{
    public class FinalReceiptResponseModel
    {
        public TransactionReceiptModel ReceiptData { get; set; }
    }
}


