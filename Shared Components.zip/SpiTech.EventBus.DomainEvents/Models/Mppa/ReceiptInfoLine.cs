﻿namespace SpiTech.EventBus.DomainEvents.Models.Mppa
{
    public class ReceiptInfoLine
    {

        public int? LineBreakAfter { get; set; }
    }
}
