﻿using System;

namespace SpiTech.EventBus.DomainEvents.Models.Finance
{
    public class WalletCredit
    {
        public long WalletCreditId { get; set; }
        public int WalletId { get; set; }
        public decimal CreditAmount { get; set; }
        public decimal CurrentAmount { get; set; }
        public decimal? TransactionAmount { get; set; }
        public int? StoreId { get; set; }
        public string StoreName { get; set; }
        public long? TransactionId { get; set; }
        public string TransactionDesc { get; set; }
        public int UserPaymentMethodId { get; set; }
        public int PaymentMethodId { get; set; }
        public int? LinkMemberTransferId { get; set; }
        public long? FromWalletCreditId { get; set; }
        public int CreditTypeId { get; set; }
        public DateTime CreditDate { get; set; }
        public DateTime? ExpireDate { get; set; }
        public DateTime? LastNotificationSentDate { get; set; }
        public int? CreditIdentifier { get; set; }
        public string NotificationTypeIdentifier { get; set; }
        public int? TransactionCount { get; set; }
    }
}
