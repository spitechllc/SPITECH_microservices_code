﻿using SpiTech.EventBus.DomainEvents.Enums;
using System.Linq;

namespace SpiTech.EventBus.DomainEvents.Models.Transactions
{
    public class StoreBillingInvoiceModel
    {
        public StoreBillingModel StoreBilling { get; set; }
        public decimal TotalCashBackEarned { get; set; }
        public decimal TotalCashBackRedeemed
        {
            get
            {
                return (StoreBilling?.StoreBillingDetails?.FirstOrDefault(t => t.PaymentMethodId == (int)EnumPaymentMethod.CashReward)?.TransactionAmount ?? 0);
            }
        }
    }
}
