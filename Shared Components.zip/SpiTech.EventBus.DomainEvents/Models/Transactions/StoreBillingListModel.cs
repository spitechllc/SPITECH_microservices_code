﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.EventBus.DomainEvents.Models.Transactions
{
    public class StoreBillingListModel
    {
        public List<StoreBillingModel> StoreBillings { get; set; }
        public decimal TransactionAmount
        {
            get
            {
                return StoreBillings?.Sum(x => x.TransactionAmount) ?? 0;
            }
        }

        public int TransactionCount
        {
            get
            {
                return StoreBillings?.Sum(x => x.TransactionCount) ?? 0;
            }
        }

        public decimal TransactionPercentageFee
        {
            get
            {
                return Math.Round(((StoreBillings?.Any() ?? false) ? StoreBillings.Sum(x => x.TransactionPercentageFee) / StoreBillings.Count : 0), 2, MidpointRounding.AwayFromZero);
            }
        }

        public decimal TransactionFee
        {
            get
            {
                return StoreBillings?.Sum(x => x.TransactionFee) ?? 0;
            }
        }

        public decimal MonthlySaasFee
        {
            get
            {
                return StoreBillings?.Sum(x => x.MonthlySaasFee) ?? 0;
            }
        }

        public decimal TotalFee
        {
            get
            {
                return StoreBillings?.Sum(x => x.TotalFee) ?? 0;
            }
        }

        public DateTime BillGenerateDate
        {
            get
            {
                return StoreBillings?.FirstOrDefault()?.BillGenerateDate ?? DateTime.UtcNow;
            }
        }

        public string MonthName
        {
            get
            {
                return System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(Month);
            }
        }

        public int Month
        {
            get
            {
                return StoreBillings?.FirstOrDefault()?.Month ?? DateTime.UtcNow.Month;
            }
        }

        public int Year
        {
            get
            {
                return StoreBillings?.FirstOrDefault()?.Year ?? DateTime.UtcNow.Year;
            }
        }


        public decimal WalletTransactionAmount
        {
            get
            {
                if (StoreBillings == null)
                {
                    return 0;
                }

                return StoreBillings.Sum(t => t.WalletTransactionAmount);
            }
        }
        public decimal WalletTransactionCount
        {
            get
            {
                if (StoreBillings == null)
                {
                    return 0;
                }

                return StoreBillings.Sum(t => t.WalletTransactionCount);
            }
        }
        public decimal WalletTransactionFee
        {
            get
            {
                if (StoreBillings == null)
                {
                    return 0;
                }

                return StoreBillings.Sum(t => t.WalletTransactionFee);
            }
        }
        public decimal WalletTransactionPercentageFee
        {
            get
            {
                if (StoreBillings == null)
                {
                    return 0;
                }

                return StoreBillings.Sum(t => t.WalletTransactionPercentageFee);
            }
        }
        public decimal CardTransactionAmount
        {
            get
            {
                if (StoreBillings == null)
                {
                    return 0;
                }

                return StoreBillings.Sum(t => t.CardTransactionAmount);
            }
        }
        public decimal CardTransactionCount
        {
            get
            {
                if (StoreBillings == null)
                {
                    return 0;
                }

                return StoreBillings.Sum(t => t.CardTransactionCount);
            }
        }
        public decimal CardTransactionFee
        {
            get
            {
                if (StoreBillings == null)
                {
                    return 0;
                }

                return StoreBillings.Sum(t => t.CardTransactionFee);
            }
        }
        public decimal CardTransactionPercentageFee
        {
            get
            {
                if (StoreBillings == null)
                {
                    return 0;
                }

                return StoreBillings.Sum(t => t.CardTransactionPercentageFee);
            }
        }
        public decimal AchTransactionAmount
        {
            get
            {
                if (StoreBillings == null)
                {
                    return 0;
                }

                return StoreBillings.Sum(t => t.AchTransactionAmount);
            }
        }
        public decimal AchTransactionCount
        {
            get
            {
                if (StoreBillings == null)
                {
                    return 0;
                }

                return StoreBillings.Sum(t => t.AchTransactionCount);
            }
        }
        public decimal AchTransactionFee
        {
            get
            {
                if (StoreBillings == null)
                {
                    return 0;
                }

                return StoreBillings.Sum(t => t.AchTransactionFee);
            }
        }
        public decimal AchTransactionPercentageFee
        {
            get
            {
                if (StoreBillings == null)
                {
                    return 0;
                }

                return StoreBillings.Sum(t => t.AchTransactionPercentageFee);
            }
        }
    }
}
