﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SpiTech.EventBus.DomainEvents.Models.Transactions
{
    public class SaleAgentBillingListModel
    {
        public List<SaleAgentBillingModel> SaleAgentBillings { get; set; }
        public decimal TransactionAmount
        {
            get
            {
                return SaleAgentBillings?.Select(x => x.TransactionAmount).Sum() ?? 0;
            }
        }
        public decimal DefineTransactionPercentageFee
        {
            get
            {
                return (SaleAgentBillings?.Any() ?? false) ? SaleAgentBillings.Select(x => x.DefineTransactionPercentageFee).Sum() / (SaleAgentBillings?.Count ?? 0) : 0;
            }
        }

        public decimal DefineMonthlySaasFee
        {
            get
            {
                return SaleAgentBillings?.Select(x => x.DefineMonthlySaasFee).Sum() ?? 0;
            }
        }

        public decimal TransactionPercentageFee
        {
            get
            {
                return SaleAgentBillings?.Select(x => x.TransactionPercentageFee).Sum() ?? 0;
            }
        }

        public decimal TotalFee
        {
            get
            {
                return SaleAgentBillings?.Select(x => x.TotalFee).Sum() ?? 0;
            }
        }
        public DateTime BillGenerateDate
        {
            get
            {
                return SaleAgentBillings?.FirstOrDefault()?.CreatedOn ?? DateTime.UtcNow;
            }
        }

        public string MonthName
        {
            get
            {
                return System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(Month);
            }
        }


        public int Month
        {
            get
            {
                return SaleAgentBillings?.FirstOrDefault()?.Month ?? DateTime.UtcNow.Month;
            }
        }

        public int Year
        {
            get
            {
                return SaleAgentBillings?.FirstOrDefault()?.Year ?? DateTime.UtcNow.Year;
            }
        }
    }
}
