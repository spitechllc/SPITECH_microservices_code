﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SpiTech.EventBus.DomainEvents.Models.Transactions
{
    public class ResellerBillingListModel
    {
        public List<ResellerBillingModel> ResellerBillings { get; set; }

        public int TotalStoreCount
        {
            get
            {
                return ResellerBillings?.Sum(x => x.StoreCount)?? 0;
            }
        }
        public decimal TotalTransactionAmount
        {
            get
            {
                return ResellerBillings?.Sum(x => x.TransactionAmount) ?? 0;
            }
        }

        public decimal TotalACHTransactionAmount
        {
            get
            {
                return ResellerBillings?.Sum(x => x.ACHTransactionAmount) ?? 0;
            }
        }

        public decimal TotalCardTransactionAmount
        {
            get
            {
                return ResellerBillings?.Sum(x => x.CardTransactionAmount) ?? 0;
            }
        }

        public decimal TotalCashRewardTransactionAmount
        {
            get
            {
                return ResellerBillings?.Sum(x => x.CashRewardTransactionAmount) ?? 0;
            }
        }

        public decimal TotalACHTransactionFee
        {
            get
            {
                return ResellerBillings?.Sum(x => x.ACHTransactionFee) ?? 0;
            }
        }

        public decimal TotalCardTransactionFee
        {
            get
            {
                return ResellerBillings?.Sum(x => x.CardTransactionFee) ?? 0;
            }
        }

        public decimal TotalCashRewardTransactionFee
        {
            get
            {
                return ResellerBillings?.Sum(x => x.CashRewardTransactionFee) ?? 0;
            }
        }

        public decimal TotalACHProcessingFee
        {
            get
            {
                return ResellerBillings?.Sum(x => x.ACHProcessingFee) ?? 0;
            }
        }

        public decimal TotalFee
        {
            get
            {
                return ResellerBillings?.Select(x => x.TotalFee).Sum() ?? 0;
            }
        }



        public decimal DefineACHTransactionFee
        {
            get
            {
                return ResellerBillings?.Sum(x => x.DefineACHTransactionFee) ?? 0;
            }
        }

        public decimal DefineCardTransactionFee
        {
            get
            {
                return ResellerBillings?.Sum(x => x.DefineCardTransactionFee) ?? 0;
            }
        }

        public decimal DefineCashRewardTransactionFee
        {
            get
            {
                return ResellerBillings?.Sum(x => x.DefineCashRewardTransactionFee) ?? 0;
            }
        }

        public decimal DefineACHProcessingFee
        {
            get
            {
                return ResellerBillings?.Sum(x => x.DefineACHProcessingFee) ?? 0;
            }
        }

        public decimal DefineMonthlySaasFee
        {
            get
            {
                return ResellerBillings?.Sum(x => x.DefineMonthlySaasFee) ?? 0;
            }
        }    
        
        public DateTime BillGenerateDate
        {
            get
            {
                return ResellerBillings?.FirstOrDefault()?.CreatedOn ?? DateTime.UtcNow;
            }
        }

        public string MonthName
        {
            get
            {
                return System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(Month);
            }
        }


        public int Month
        {
            get
            {
                return ResellerBillings?.FirstOrDefault()?.Month ?? DateTime.UtcNow.Month;
            }
        }

        public int Year
        {
            get
            {
                return ResellerBillings?.FirstOrDefault()?.Year ?? DateTime.UtcNow.Year;
            }
        }
    }
}
