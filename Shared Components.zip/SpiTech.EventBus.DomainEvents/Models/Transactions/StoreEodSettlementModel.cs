﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SpiTech.EventBus.DomainEvents.Models.Transactions
{
    public class StoreEodSettlementModel
    {
        public int SettlementRequestId { get; set; }
        public string SiteID { get; set; }
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public string StoreAddress { get; set; }
        public DateTime BusinessDate { get; set; }
        public string ClosingTime { get { return BusinessDate.ToString("hh:mm tt"); } }
        public int TerminalCounts { get; set; }
        public int MppaCounts { get; set; }
        public string SettlementFileName { get; set; }
        public string SettlementFilePath { get; set; }
        public string ProcessStatus { get; set; }
        public decimal TerminalTotalAmount { get; set; }
        public decimal MppaTotalAmount { get; set; }
        public int CardCount
        {
            get
            {
                return PaymentMethodDetails.Count(t => t.PaymentMethodId == 1 && t.CardAmount > 0);
            }
        }
        public decimal CardAmount
        {
            get
            {
                return PaymentMethodDetails.Where(t => t.PaymentMethodId == 1 ).Sum(t => t.CardAmount);
            }
        }
        public int ACHCount
        {
            get
            {
                return PaymentMethodDetails.Count(t => t.PaymentMethodId == 2 && t.CardAmount > 0);
            }
        }
        public decimal ACHAmount
        {
            get
            {
                return PaymentMethodDetails.Where(t => t.PaymentMethodId == 2).Sum(t => t.CardAmount);
            }
        }
        public int CashRewardCount
        {
            get
            {
                return PaymentMethodDetails.Count(t => t.PaymentMethodId == 3 || t.WalletAmount > 0);
            }
        }
        public decimal CashRewardAmount
        {
            get
            {
                return PaymentMethodDetails.Sum(t => t.WalletAmount);
            }
        }
        public double TotalCashRewardAwarded { get; set; }
        public double TotalCashRewardRedeemed { get; set; }
        public List<PaymentMethodDetail> PaymentMethodDetails { get; set; } = new List<PaymentMethodDetail>();
        public List<PaymentMethodDetail> CreditDebitDetails
        {
            get
            {
                return PaymentMethodDetails.Where(t => t.PaymentMethodId == 1).ToList();
            }
        }

        public List<PaymentMethodDetail> AchDetails
        {
            get
            {
                return PaymentMethodDetails.Where(t => t.PaymentMethodId == 2).ToList();
            }
        }
    }

    public class PaymentMethodDetail
    {
        public string Type { get; set; }
        public decimal CardAmount { get; set; }
        public decimal WalletAmount { get; set; }
        public int TransactionCount { get; set; }
        public int PaymentMethodId { get; set; }
    }
}
