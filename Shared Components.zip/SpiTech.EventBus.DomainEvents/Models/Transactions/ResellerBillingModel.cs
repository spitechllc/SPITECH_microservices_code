﻿using System;

namespace SpiTech.EventBus.DomainEvents.Models.Transactions
{
    public class ResellerBillingModel
    {
        public int ResellerBillingId { get; set; }
        public int ResellerId { get; set; }
        public string ResellerName { get; set; }
        public string InvoiceNumber { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public int StoreCount { get; set; }
        public int TransactionCount { get; set; }
        public decimal TransactionAmount { get; set; }
        public decimal ACHTransactionAmount { get; set; }
        public decimal CardTransactionAmount { get; set; }
        public decimal CashRewardTransactionAmount { get; set; }
        public int DefineMinStoreRange { get; set; }
        public int DefineMaxStoreRange { get; set; }
        public decimal DefineACHTransactionFee { get; set; }
        public decimal DefineCardTransactionFee { get; set; }
        public decimal DefineCashRewardTransactionFee { get; set; }
        public decimal DefineACHProcessingFee { get; set; }
        public decimal DefineMonthlySaasFee { get; set; }
        public string DefineCoreProcessingName { get; set; }
        public decimal ACHTransactionFee { get; set; }
        public decimal CardTransactionFee { get; set; }
        public decimal CashRewardTransactionFee { get; set; }
        public decimal ACHProcessingFee { get; set; }
        public decimal TotalFee { get; set; }
        public bool NeedReview { get; set; }
        public bool IsPaid { get; set; }
        public string InvoiceFileName { get; set; }
        public string InvoiceFilePath { get; set; }
        public string ProcessStatus { get; set; }

        public string MonthName
        {
            get
            {
                return System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(Month);
            }
        }
        public DateTime? CreatedOn { get; set; }
        public DateTime BillGenerateDate
        {
            get
            {
                return CreatedOn ?? DateTime.UtcNow;
            }
        }

        [System.Text.Json.Serialization.JsonIgnore]
        [Newtonsoft.Json.JsonIgnore]
        public int TotalRecord { get; set; }
    }
}
