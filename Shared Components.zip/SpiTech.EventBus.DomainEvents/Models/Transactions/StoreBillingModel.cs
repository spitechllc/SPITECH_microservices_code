﻿using SpiTech.EventBus.DomainEvents.Enums;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SpiTech.EventBus.DomainEvents.Models.Transactions
{
    public class StoreBillingModel
    {
        public int StoreBillingId { get; set; }
        public string GroupBillingIdentifier { get; set; }
        public string BillingNumber { get; set; }
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public string SiteId { get; set; }
        public Address StoreAddress { get; set; }

        public string MonthName
        {
            get
            {
                return System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(Month);
            }
        }

        public int Month { get; set; }
        public int Year { get; set; }
        public int TransactionCount { get; set; }
        public decimal TransactionAmount { get; set; }
        public decimal TransactionFee { get; set; }
        public decimal TransactionPercentageFee { get; set; }
        public decimal MonthlySaasFee { get; set; }
        public decimal TotalFee { get; set; }
        public int BillGenerateBy { get; set; }
        public DateTime BillGenerateDate { get; set; }
        public bool NeedReview { get; set; }
        public bool IsPaid { get; set; }
        public string InvoiceFileName { get; set; }
        public string InvoiceFilePath { get; set; }
        public string ProcessStatus { get; set; }

        public decimal WalletTransactionAmount
        {
            get
            {
                if (StoreBillingDetails == null)
                {
                    return 0;
                }

                return StoreBillingDetails.Where(t => t.PaymentMethodId == (int)EnumPaymentMethod.CashReward).Sum(t => t.TransactionAmount);
            }
        }
        public decimal WalletTransactionCount
        {
            get
            {
                if (StoreBillingDetails == null)
                {
                    return 0;
                }

                return StoreBillingDetails.Where(t => t.PaymentMethodId == (int)EnumPaymentMethod.CashReward).Sum(t => t.TransactionCount);
            }
        }
        public decimal WalletTransactionFee
        {
            get
            {
                if (StoreBillingDetails == null)
                {
                    return 0;
                }

                return StoreBillingDetails.Where(t => t.PaymentMethodId == (int)EnumPaymentMethod.CashReward).Sum(t => t.TransactionFee);
            }
        }
        public decimal WalletTransactionPercentageFee
        {
            get
            {
                if (StoreBillingDetails == null)
                {
                    return 0;
                }

                return StoreBillingDetails.Where(t => t.PaymentMethodId == (int)EnumPaymentMethod.CashReward).Sum(t => t.TransactionPercentageFee);
            }
        }
        public decimal CardTransactionAmount
        {
            get
            {
                if (StoreBillingDetails == null)
                {
                    return 0;
                }

                return StoreBillingDetails.Where(t => t.PaymentMethodId == (int)EnumPaymentMethod.CreditCard).Sum(t => t.TransactionAmount);
            }
        }
        public decimal CardTransactionCount
        {
            get
            {
                if (StoreBillingDetails == null)
                {
                    return 0;
                }

                return StoreBillingDetails.Where(t => t.PaymentMethodId == (int)EnumPaymentMethod.CreditCard).Sum(t => t.TransactionCount);
            }
        }
        public decimal CardTransactionFee
        {
            get
            {
                if (StoreBillingDetails == null)
                {
                    return 0;
                }

                return StoreBillingDetails.Where(t => t.PaymentMethodId == (int)EnumPaymentMethod.CreditCard).Sum(t => t.TransactionFee);
            }
        }
        public decimal CardTransactionPercentageFee
        {
            get
            {
                if (StoreBillingDetails == null)
                {
                    return 0;
                }

                return StoreBillingDetails.Where(t => t.PaymentMethodId == (int)EnumPaymentMethod.CreditCard).Sum(t => t.TransactionPercentageFee);
            }
        }
        public decimal AchTransactionAmount
        {
            get
            {
                if (StoreBillingDetails == null)
                {
                    return 0;
                }

                return StoreBillingDetails.Where(t => t.PaymentMethodId == (int)EnumPaymentMethod.ACH).Sum(t => t.TransactionAmount);
            }
        }
        public decimal AchTransactionCount
        {
            get
            {
                if (StoreBillingDetails == null)
                {
                    return 0;
                }

                return StoreBillingDetails.Where(t => t.PaymentMethodId == (int)EnumPaymentMethod.ACH).Sum(t => t.TransactionCount);
            }
        }
        public decimal AchTransactionFee
        {
            get
            {
                if (StoreBillingDetails == null)
                {
                    return 0;
                }

                return StoreBillingDetails.Where(t => t.PaymentMethodId == (int)EnumPaymentMethod.ACH).Sum(t => t.TransactionFee);
            }
        }
        public decimal AchTransactionPercentageFee
        {
            get
            {
                if (StoreBillingDetails == null)
                {
                    return 0;
                }

                return StoreBillingDetails.Where(t => t.PaymentMethodId == (int)EnumPaymentMethod.ACH).Sum(t => t.TransactionPercentageFee);
            }
        }

        public ICollection<StoreBillingDetailModel> StoreBillingDetails { get; set; } = new List<StoreBillingDetailModel>();

        [System.Text.Json.Serialization.JsonIgnore]
        [Newtonsoft.Json.JsonIgnore]
        public int TotalRecord { get; set; }
    }
}
