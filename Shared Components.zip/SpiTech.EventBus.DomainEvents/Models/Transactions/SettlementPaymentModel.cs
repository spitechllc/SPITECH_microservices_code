﻿using System;
using System.Collections.Generic;

namespace SpiTech.EventBus.DomainEvents.Models.Transactions
{
    public class SettlementPaymentModel
    {
        public int SettlementPaymentId { get; set; }
        public DateTime BusinessDate { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal TotalRewardAmount { get; set; }
        public decimal TotalCardAmount { get; set; }
        public decimal TotalAchAmount { get; set; }
        public string AccountName { get; set; }
        public string Bank { get; set; }
        public string AccountNo { get; set; }
        public string RoutingNo { get; set; }
        public bool IsChecking { get; set; }
        public string NachaFilePath { get; set; }
        public string NachaFileName { get; set; }
        public bool IsNachaUploaded { get; set; }
        public string NachaUploadError { get; set; }

        public List<SettlementPaymentDetailModel> SettlementPaymentDetails { get; set; } = new List<SettlementPaymentDetailModel>();
    }
}