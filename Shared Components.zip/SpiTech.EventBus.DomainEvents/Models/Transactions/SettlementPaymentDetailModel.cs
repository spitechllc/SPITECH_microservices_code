﻿namespace SpiTech.EventBus.DomainEvents.Models.Transactions
{
    public class SettlementPaymentDetailModel
    {
        public int SettlementPaymentDetailId { get; set; }
        public int SettlementPaymentId { get; set; }
        public int SettlementRequestId { get; set; }
        public decimal Amount { get; set; }
        public int AmountTypeId { get; set; }
        public int StoreId { get; set; }
        public string AccountName { get; set; }
        public string AccountNo { get; set; }
        public string RoutingNo { get; set; }
        public string IdentificationNumber { get; set; }
        public bool IsChecking { get; set; }
        public bool MarkUnPaid { get; set; }
        public string Reason { get; set; }
    }
}