﻿using System;


namespace SpiTech.EventBus.DomainEvents.Models.Identity
{
    public class LinkUserModel
    {
        public int LinkUserId { get; set; }
        public int RequestedUserId { get; set; }
        public int AcceptUserId { get; set; }
        public bool? IsAccepted { get; set; }
        public DateTime? RequestDate { get; set; }
        public DateTime? ActionDate { get; set; }
    }
}
