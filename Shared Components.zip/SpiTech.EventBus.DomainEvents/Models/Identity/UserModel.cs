﻿namespace SpiTech.EventBus.DomainEvents.Models.Identity
{
    public class UserModel
    {
        public int UserId { get; set; }
    }
}
