﻿namespace SpiTech.EventBus.DomainEvents.Models.Identity
{
    public class UserDeviceModel
    {
        public int UserDeviceId { get; set; }
        public int UserId { get; set; }
        public int DeviceTypeId { get; set; }
        public int MobileAppTypeId { get; set; }
        public string DeviceToken { get; set; }
        public bool IsOnline { get; set; }
    }
}
