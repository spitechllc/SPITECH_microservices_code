﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.EventBus.DomainEvents.Events
{
    public class NotificationTypeIdentifierConstants
    {

        public const string IdentityUserCreated = "IdentityUserCreated";
        public const string IdentityUserUpdated = "IdentityUserUpdated";
        public const string IdentityForgotPassword = "IdentityForgotPassword";
        public const string IdentityPasswordChanged = "IdentityPasswordChanged";
        public const string IdentityUserSignIn = "IdentityUserSignIn";
        public const string IdentityUserDeviceUpdated = "IdentityUserDeviceUpdated";
        public const string UserLinkedAccepterEvent = "UserLinkedAccepterEvent";
        public const string IdentityUserVerificationCode = "IdentityUserVerificationCode";
        public const string UserLinkedRequesterEvent = "UserLinkedRequesterEvent";
        public const string IdentityUserEmailVerifiedEvent = "IdentityUserEmailVerifiedEvent";
        public const string IdentityUserUnlockedEvent = "IdentityUserUnlockedEvent";

        public const string StoreEvent = "StoreEvent";
        public const string StoreUserEvent = "StoreUserEvent";
        public const string StoreBillingFeeEvent = "StoreBillingFeeEvent";

        public const string MppaPaymentProcessEvent = "MppaPaymentProcessEvent";
        public const string PumpReserveRequestEvent = "PumpReserveRequestEvent";
        public const string AuthMppaRequestEvent = "AuthMppaRequestEvent";
        public const string BeginFuelingRequestEvent = "BeginFuelingRequestEvent";
        public const string FinalizeRequestEvent = "FinalizeRequestEvent";
        public const string ReceiptDataRequestEvent = "ReceiptDataRequestEvent";
        public const string TransactionUpdateEvent = "TransactionUpdateEvent";
        public const string ReconcileFailTransactionEvent = "ReconcileFailTransactionEvent";
        public const string TransactionSettlementEvent = "TransactionSettlementEvent";
        public const string MobilePumpReserveResponsesEvent = "MobilePumpReserveResponsesEvent";
        public const string MobilePumpBeginFualResponsesEvent = "MobilePumpBeginFualResponsesEvent";
        public const string MobileFinalReceiptResponsesEvent = "MobileFinalReceiptResponsesEvent";
        public const string StaCaptureRequestEvent = "StaCaptureRequestEvent";
        public const string TransactionDataResponseEvent = "TransactionDataResponseEvent";
        public const string MobilePosTransactionDataProcessResponsesEvent = "MobilePosTransactionDataProcessResponsesEvent";
        public const string MobileStacCaptureResponsesEvent = "MobileStacCaptureResponsesEvent";
        public const string MobileStacGenerationResponsesEvent = "MobileStacGenerationResponsesEvent";
        public const string MobileFinalizesDataResponseEvent = "MobileFinalizesDataResponseEvent";
        public const string MobilePumpProcessStatusResponsesEvent = "MobilePumpProcessStatusResponsesEvent";
        public const string SiteEvent = "SiteEvent";
        
        public const string TransactionEvent = "TransactionEvent";
        public const string StoreMonthlyBillingInvoiceEvent = "StoreMonthlyBillingInvoiceEvent";
        public const string StoreEodSettlementInvoiceEvent = "StoreEodSettlementInvoiceEvent";
        public const string StoreEodSettlementInvoiceAdminEvent = "StoreEodSettlementInvoiceAdminEvent";
        public const string StoreEodSettlementEvent = "StoreEodSettlementEvent";
        public const string SaleAgentMonthlyBillingInvoiceEvent = "SaleAgentMonthlyBillingInvoiceEvent";
        public const string ResellerMonthlyBillingInvoiceEvent = "ResellerMonthlyBillingInvoiceEvent";
        public const string AchNachaReturnFileEvent = "AchNachaReturnFileEvent";
        
        public const string PaymentStatusEvent = "PaymentStatusEvent";
        public const string PaymentMethodAddedEvent = "PaymentMethodAddedEvent";
        public const string PaymentMethodRemovedEvent = "PaymentMethodRemovedEvent";
        public const string PaymentFailedEvent = "PaymentFailedEvent";
        public const string PaymentFailureSupportTeamEvent = "PaymentFailureSupportTeamEvent";
        
        public const string ConsumerOfferSendEvent = "ConsumerOfferSendEvent";
        public const string PromotionLoyaltyEvent = "PromotionLoyaltyEvent";
        
        public const string WalletCreditEvent = "WalletCreditEvent";
        public const string WalletLinkUserTransferCreditEvent = "WalletLinkUserTransferCreditEvent";
        public const string AdminCreditEvent = "AdminCreditEvent";
        public const string AddCardEvent = "AddCardEvent";
        public const string ACHTransaction = "ACHTransaction";
        public const string CreditCardTransaction = "CreditCardTransaction";
        public const string TransactionSequenceNo = "TransactionSequenceNo";

        public const string WalletDebitEvent = "WalletDebitEvent";
        public const string WalletLinkUserTransferDebitEvent = "WalletLinkUserTransferDebitEvent";
        public const string AdminDebitEvent = "AdminDebitEvent";
        public const string StoreWalletDebit = "StoreWalletDebit";
       
        public const string WalletVoidPaymentEvent = "WalletVoidPaymentEvent";
        public const string ExpiringWalletCreditEvent = "ExpiringWalletCreditEvent";
        public const string TransferRequestEvent = "TransferRequestEvent";
        public const string TransferRequestDeclinedEvent = "TransferRequestDeclinedEvent";
        
        public const string InvoiceSendEvent = "InvoiceSendEvent";
        public const string InvoiceReceiveEvent = "InvoiceReceiveEvent";
        public const string InvoiceCancelledEvent = "InvoiceCancelledEvent";
        public const string InvoiceRejectedEvent = "InvoiceRejectedEvent";
        public const string InvoicePaidEvent = "InvoicePaidEvent";

        public const string UserActivityLogEvent = "UserActivityLogEvent";
        public const string AppNotificationEvent = "AppNotificationEvent";
    }
}
