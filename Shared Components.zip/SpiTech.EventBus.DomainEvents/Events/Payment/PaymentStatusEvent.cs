﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using System;

namespace SpiTech.EventBus.DomainEvents.Events.Payment
{
    [EntityName(EventBusConstants.PaymentServiceExchange)]
    public class PaymentStatusEvent : IntegrationBaseEvent
    {
        public long TransactionId { get; set; }
        public int UserId { get; set; }
        public string PreauthConfirmationNo { get; set; }
        public decimal Amount { get; set; }
        public decimal CardAmount { get; set; }
        public decimal WalletAmount { get; set; }
        public string StoreName { get; set; }
        public bool IsSuccess { get; set; }
        public string ErrorMessage { get; set; }
        public DateTime ProcessDate { get; set; }
        public override string EventId => TransactionId.ToString();
        public override string EventIdentifierName => nameof(TransactionId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.PaymentStatusEvent;
        public override EventModuleType EventModuleType => EventModuleType.Payment;
        public override EventType EventType => EventType.PaymentStatusEvent;
    }
}
