﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using System;

namespace SpiTech.EventBus.DomainEvents.Events.Payment
{
    [EntityName(EventBusConstants.PaymentServiceExchange)]
    public class PaymentMethodRemovedEvent : IntegrationBaseEvent
    {
        public int UserPaymentMethodId { get; set; }
        public int PaymentMethodId { get; set; }
        public int UserId { get; set; }
        public DateTime? CardExpDate { get; set; }
        public string CardNumber { get; set; }
        public string CardType { get; set; }
        public string AccountNumber { get; set; }
        public string AccountType { get; set; }
        public string BankName { get; set; }
        public string CustId { get; set; }
        public string Operation { get; set; }
        public string Source { get; set; }
        public string Token { get; set; }
        public bool IsDefault { get; set; }
        public override string EventId => UserPaymentMethodId.ToString();
        public override string EventIdentifierName => nameof(UserPaymentMethodId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.PaymentMethodRemovedEvent;
        public override EventModuleType EventModuleType => EventModuleType.Payment;
        public override EventType EventType => EventType.PaymentMethodRemovedEvent;
    }
}
