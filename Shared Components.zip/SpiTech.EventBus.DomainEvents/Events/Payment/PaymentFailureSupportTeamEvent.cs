﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;

namespace SpiTech.EventBus.DomainEvents.Events.Payment
{


    [EntityName(EventBusConstants.PaymentServiceExchange)]
    public class PaymentFailureSupportTeamEvent : IntegrationBaseEvent
    {
        public long TransactionId { get; set; }
        public int UserId { get; set; }
        public decimal Amount { get; set; }
        public decimal CardAmount { get; set; }
        public decimal WalletAmount { get; set; }
        public string StoreName { get; set; }
        public int StoreId { get; set; }
        public bool IsSuccess { get; set; }
        public bool IsPaymentRequired { get; set; }
        public override string EventId => TransactionId.ToString();
        public override string EventIdentifierName => nameof(TransactionId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.PaymentFailureSupportTeamEvent;
        public override EventModuleType EventModuleType => EventModuleType.Payment;
        public override EventType EventType => EventType.PaymentStatusEvent;
    }
}
