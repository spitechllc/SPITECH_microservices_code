﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Mppa;
using SpiTech.EventBus.DomainEvents.Models.Transactions;
using System.Collections.Generic;

namespace SpiTech.EventBus.DomainEvents.Events.Transactions
{
    [EntityName(EventBusConstants.TransactionServiceExchange)]
    public class AchNachaReturnFileEvent : IntegrationBaseEvent
    {
        public string TranGuid { get; set; }
        public string ReturnFileName { get; set; }
        public string DecryptFileName { get; set; }
        public string ReturnFilePath { get; set; }
        public string DecryptFilePath { get; set; }
        public override string EventId => TranGuid.ToString();
        public override string EventIdentifierName => nameof(TranGuid);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.AchNachaReturnFileEvent;
        public override EventModuleType EventModuleType => EventModuleType.Transaction;
        public override EventType EventType => EventType.AchNachaReturnFileEvent;
    }
}
