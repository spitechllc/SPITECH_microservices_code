﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Transactions;

namespace SpiTech.EventBus.DomainEvents.Events.Transactions
{
    [EntityName(EventBusConstants.TransactionServiceExchange)]
    public class ResellerMonthlyBillingInvoiceEvent : IntegrationBaseEvent
    {
        public ResellerBillingModel ResellerBilling { get; set; }
        public override string EventId => ResellerBilling.ResellerBillingId.ToString();
        public override string EventIdentifierName => nameof(ResellerBilling.ResellerBillingId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.ResellerMonthlyBillingInvoiceEvent;
        public override EventModuleType EventModuleType => EventModuleType.Transaction;
        public override EventType EventType => EventType.ResellerMonthlyBillingInvoiceEvent;
    }
}
