﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Transactions;

namespace SpiTech.EventBus.DomainEvents.Events.Transactions
{
    [EntityName(EventBusConstants.TransactionServiceExchange)]
    public class SaleAgentMonthlyBillingInvoiceEvent : IntegrationBaseEvent
    {
        public SaleAgentBillingModel SaleAgentBilling { get; set; }
        public override string EventId => SaleAgentBilling.SaleAgentBillingId.ToString();
        public override string EventIdentifierName => nameof(SaleAgentBilling.SaleAgentBillingId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.SaleAgentMonthlyBillingInvoiceEvent;
        public override EventModuleType EventModuleType => EventModuleType.Transaction;
        public override EventType EventType => EventType.SaleAgentMonthlyBillingInvoiceEvent;
    }
}
