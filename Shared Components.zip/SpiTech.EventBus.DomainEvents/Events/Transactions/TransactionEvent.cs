﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Mppa;

namespace SpiTech.EventBus.DomainEvents.Events.Transactions
{
    [EntityName(EventBusConstants.TransactionServiceExchange)]
    public class TransactionEvent : IntegrationBaseEvent
    {
        public Transaction Transaction { get; set; }
        public override string EventId => Transaction?.TransactionId.ToString();
        public override string EventIdentifierName => nameof(Transaction.TransactionId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.TransactionEvent;
        public override EventModuleType EventModuleType => EventModuleType.Transaction;
        public override EventType EventType => EventType.TransactionEvent;
    }
}
