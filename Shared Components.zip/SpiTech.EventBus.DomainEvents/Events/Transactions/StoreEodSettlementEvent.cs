﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Transactions;

namespace SpiTech.EventBus.DomainEvents.Events.Transactions
{
    [EntityName(EventBusConstants.TransactionServiceExchange)]
    public class StoreEodSettlementEvent : IntegrationBaseEvent
    {
        public StoreEodSettlementModel StoreEodSettlement { get; set; }
        public override string EventId => StoreEodSettlement.SettlementRequestId.ToString();
        public override string EventIdentifierName => nameof(StoreEodSettlement.SettlementRequestId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.StoreEodSettlementEvent;
        public override EventModuleType EventModuleType => EventModuleType.Transaction;
        public override EventType EventType => EventType.StoreEodSettlementEvent;
    }
}
