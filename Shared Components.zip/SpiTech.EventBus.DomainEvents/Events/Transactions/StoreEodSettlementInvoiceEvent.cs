﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using System;

namespace SpiTech.EventBus.DomainEvents.Events.Transactions
{
    [EntityName(EventBusConstants.TransactionServiceExchange)]
    public class StoreEodSettlementInvoiceEvent : IntegrationBaseEvent
    {
        public int StoreId { get; set; }
        public DateTime BusinessDate { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal TotalRewardAmount { get; set; }
        public decimal TotalCardAmount { get; set; }
        public decimal TotalAchAmount { get; set; }
        public string AccountNo { get; set; }
        public string IdentificationNumber { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public override string EventId => StoreId.ToString();
        public override string EventIdentifierName => nameof(StoreId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.StoreEodSettlementInvoiceEvent;
        public override EventModuleType EventModuleType => EventModuleType.Transaction;
        public override EventType EventType => EventType.StoreEodSettlementInvoiceEvent;
    }
}
