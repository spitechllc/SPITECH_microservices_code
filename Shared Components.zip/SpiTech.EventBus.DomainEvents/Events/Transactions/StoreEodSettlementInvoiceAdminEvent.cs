﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Transactions;

namespace SpiTech.EventBus.DomainEvents.Events.Transactions
{
    [EntityName(EventBusConstants.TransactionServiceExchange)]
    public class StoreEodSettlementInvoiceAdminEvent : IntegrationBaseEvent
    {
        public SettlementPaymentModel SettlementPayment { get; set; }
        public override string EventId => SettlementPayment.SettlementPaymentId.ToString();
        public override string EventIdentifierName => nameof(SettlementPayment.SettlementPaymentId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.StoreEodSettlementInvoiceAdminEvent;
        public override EventModuleType EventModuleType => EventModuleType.Transaction;
        public override EventType EventType => EventType.StoreEodSettlementInvoiceAdminEvent;
    }
}
