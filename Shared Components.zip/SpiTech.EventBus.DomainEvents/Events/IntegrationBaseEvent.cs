﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using System;

namespace SpiTech.EventBus.DomainEvents.Events
{
    [ExcludeFromTopology]
    public abstract class IntegrationBaseEvent : IEvent
    {
        public IntegrationBaseEvent()
        {
            CreationDate = DateTime.UtcNow;
            MessageIdentifier = Guid.NewGuid();
        }

        public virtual string EventId { get; } = Guid.NewGuid().ToString();
        public virtual string EventIdentifierName { get; }
        public virtual string NotificationTypeIdentifier { get; set; }
        public DateTime CreationDate { get; private set; }
        public Guid MessageIdentifier { get; private set; }
        public abstract EventModuleType EventModuleType { get; }
        public abstract EventType EventType { get; }
    }
}
