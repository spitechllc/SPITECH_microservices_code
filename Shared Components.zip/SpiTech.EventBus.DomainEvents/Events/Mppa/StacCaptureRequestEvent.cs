﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions;

namespace SpiTech.EventBus.DomainEvents.Events.Mppa
{
    [EntityName(EventBusConstants.MppaServiceExchange)]
    public class StacCaptureRequestEvent : TransactionBaseRequestEvent
    {
        public override EventType EventType => EventType.StaCaptureRequestEvent;
    }
}
