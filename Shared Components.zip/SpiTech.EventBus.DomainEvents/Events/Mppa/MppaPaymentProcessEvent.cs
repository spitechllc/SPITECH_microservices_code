﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;

namespace SpiTech.EventBus.DomainEvents.Events.Mppa
{
    [EntityName(EventBusConstants.MppaServiceExchange)]
    public class MppaPaymentProcessEvent : IntegrationBaseEvent
    {
        public long TransactionId { get; set; }
        public string UMTI { get; set; }
        public int UserId { get; set; }
        public decimal Amount { get; set; }
        public string PaymentDescription { get; set; }
        public string PreAuthConfirmationNo { get; set; }
        public override string EventId => TransactionId.ToString();
        public override string EventIdentifierName => nameof(TransactionId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.MppaPaymentProcessEvent;
        public override EventModuleType EventModuleType => EventModuleType.MPPA;
        public override EventType EventType => EventType.MppaPaymentProcessEvent;
    }
}
