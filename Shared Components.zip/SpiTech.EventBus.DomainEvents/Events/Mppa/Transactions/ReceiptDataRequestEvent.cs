﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;

namespace SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions
{
    [EntityName(EventBusConstants.MppaServiceExchange)]
    public class ReceiptDataRequestEvent : TransactionBaseRequestEvent
    {
        public string[] ReceiptLines { get; set; }

        public override EventType EventType => EventType.ReceiptDataRequestEvent;
    }
}
