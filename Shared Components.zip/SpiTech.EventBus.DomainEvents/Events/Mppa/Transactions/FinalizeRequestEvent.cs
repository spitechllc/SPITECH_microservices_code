﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Mppa;

namespace SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions
{
    [EntityName(EventBusConstants.MppaServiceExchange)]
    public class FinalizeRequestEvent : TransactionBaseRequestEvent
    {
        public SaleItem[] SaleItems { get; set; }
        public int TransactionSequenceNo { get; set; }

        public override EventType EventType => EventType.FinalizeRequestEvent;
    }
}
