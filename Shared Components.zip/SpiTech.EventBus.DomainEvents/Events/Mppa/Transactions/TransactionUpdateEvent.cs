﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Mppa;

namespace SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions
{
    [EntityName(EventBusConstants.MppaServiceExchange)]
    public class TransactionUpdateEvent : TransactionBaseRequestEvent
    {
        public override string EventId => Transaction.TransactionId.ToString();
        public override string EventIdentifierName => nameof(Transaction.TransactionId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.TransactionUpdateEvent;
        public override EventModuleType EventModuleType => EventModuleType.MPPA;

        public override EventType EventType => EventType.TransactionUpdateEvent;
    }
}
