﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Mppa;

namespace SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions
{
    [ExcludeFromTopology]
    public abstract class TransactionBaseRequestEvent : IntegrationBaseEvent
    {
        public Transaction Transaction { get; set; }
        public int RequestTypeId { get; set; }

        public override string EventId => Transaction.TransactionId.ToString();
        public override string EventIdentifierName => nameof(Transaction.TransactionId);
        public override EventModuleType EventModuleType => EventModuleType.MPPA;
    }
}
