﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Mppa;

namespace SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions
{
    [EntityName(EventBusConstants.MppaServiceExchange)]
    public class AuthMppaRequestEvent : TransactionBaseRequestEvent
    {
        public PaymentInfo PaymentInfo { get; set; }

        public override EventType EventType => EventType.AuthMppaRequestEvent;
    }
}
