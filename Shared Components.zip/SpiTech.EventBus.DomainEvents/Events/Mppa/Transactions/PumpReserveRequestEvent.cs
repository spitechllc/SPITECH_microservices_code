﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;

namespace SpiTech.EventBus.DomainEvents.Events.Mppa.Transactions
{
    [EntityName(EventBusConstants.MppaServiceExchange)]
    public class PumpReserveRequestEvent : TransactionBaseRequestEvent
    {
        public override EventType EventType => EventType.PumpReserveRequestEvent;
    }
}
