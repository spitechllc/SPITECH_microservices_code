﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Mppa;

namespace SpiTech.EventBus.DomainEvents.Events.Mppa
{
    [EntityName(EventBusConstants.MppaServiceExchange)]
    public class TransactionSettlementEvent : IntegrationBaseEvent
    {
        public SettlementRequest SettlementRequest { get; set; }
        public long[] TransactionIds { get; set; }

        public override string EventId => SettlementRequest.SettlementRequestId.ToString();
        public override string EventIdentifierName => "SettlementRequestId";
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.TransactionSettlementEvent;
        public override EventModuleType EventModuleType => EventModuleType.MPPA;
        public override EventType EventType => EventType.TransactionSettlementEvent;
    }
}
