﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using System;

namespace SpiTech.EventBus.DomainEvents.Events.Mppa
{
    [EntityName(EventBusConstants.MppaServiceExchange)]
    public class ReconcileFailTransactionEvent : IntegrationBaseEvent
    {
        public long[] TransactionIds { get; set; }
        public override string EventId => Guid.NewGuid().ToString();
        public override string EventIdentifierName => "Guid";
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.ReconcileFailTransactionEvent;
        public override EventModuleType EventModuleType => EventModuleType.MPPA;
        public override EventType EventType => EventType.ReconcileFailTransactionEvent;
    }
}
