﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Mppa;

namespace SpiTech.EventBus.DomainEvents.Events.Mppa.Mobiles
{
    [EntityName(EventBusConstants.MppaServiceExchange)]
    public class MobilePumpReserveResponsesEvent : IntegrationBaseEvent
    {
        public PumpReserveResponseModel PumpReserveResponse { get; set; }
        public override string EventId => PumpReserveResponse?.TransactionId.ToString();
        public override string EventIdentifierName => nameof(PumpReserveResponse.TransactionId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.MobilePumpReserveResponsesEvent;
        public override EventModuleType EventModuleType => EventModuleType.MPPA;
        public override EventType EventType => EventType.MobilePumpReserveResponsesEvent;
    }
}
