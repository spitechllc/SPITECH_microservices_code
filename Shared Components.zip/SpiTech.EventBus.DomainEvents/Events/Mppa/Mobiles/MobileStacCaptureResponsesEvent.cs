﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using System;

namespace SpiTech.EventBus.DomainEvents.Events.Mppa.Mobiles
{
    [EntityName(EventBusConstants.MppaServiceExchange)]
    public class MobileStacCaptureResponsesEvent : IntegrationBaseEvent
    {
        public long TransactionId { get; set; }
        public string UMTI { get; set; }
        public int UserId { get; set; }
        public string SiteId { get; set; }
        public string Stac { get; set; }
        public string POSTransNumber { get; set; }
        public string WorkstationId { get; set; }
        public DateTime? CaptureDate { get; set; }
        public bool IsMatched { get; set; }
        public bool IsExpired { get; set; }
        public bool Success { get; set; }
        public string Erorr { get; set; }
        public override string EventId => TransactionId.ToString();
        public override string EventIdentifierName => nameof(TransactionId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.MobileStacCaptureResponsesEvent;
        public override EventModuleType EventModuleType => EventModuleType.MPPA;
        public override EventType EventType => EventType.MobileStacCaptureResponsesEvent;
    }
}
