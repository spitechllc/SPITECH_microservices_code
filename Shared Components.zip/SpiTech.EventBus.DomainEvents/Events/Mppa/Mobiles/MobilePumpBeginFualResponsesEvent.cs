﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Mppa;

namespace SpiTech.EventBus.DomainEvents.Events.Mppa.Mobiles
{
    [EntityName(EventBusConstants.MppaServiceExchange)]
    public class MobilePumpBeginFualResponsesEvent : IntegrationBaseEvent
    {
        public PumpBeginFualResponseModel PumpBeginFualResponse { get; set; }
        public override string EventId => PumpBeginFualResponse?.TransactionId.ToString();
        public override string EventIdentifierName => nameof(PumpBeginFualResponse.TransactionId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.MobilePumpBeginFualResponsesEvent;
        public override EventModuleType EventModuleType => EventModuleType.MPPA;
        public override EventType EventType => EventType.MobilePumpBeginFualResponsesEvent;
    }
}
