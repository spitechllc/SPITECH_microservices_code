﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Mppa.Receipts;

namespace SpiTech.EventBus.DomainEvents.Events.Mppa.Mobiles
{
    [EntityName(EventBusConstants.MppaServiceExchange)]
    public class MobileFinalizesDataResponseEvent : IntegrationBaseEvent
    {
        public TransactionReceiptModel ReceiptData { get; set; }
        public override string EventId => ReceiptData?.Transaction?.TransactionId.ToString();
        public override string EventIdentifierName => "TransactionId";
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.MobileFinalizesDataResponseEvent;
        public override EventModuleType EventModuleType => EventModuleType.MPPA;
        public override EventType EventType => EventType.MobileFinalizesDataResponseEvent;
    }
}
