﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;

namespace SpiTech.EventBus.DomainEvents.Events.Mppa
{
    [EntityName(EventBusConstants.MppaServiceExchange)]
    public class SiteEvent : IntegrationBaseEvent
    {
        public string SiteId { get; set; }
        public string SiteName { get; set; }
        public string SiteMPPAIdentifier { get; set; }
        public string MerchantId { get; set; }
        public string LocationId { get; set; }
        public bool? SiteMobileActive { get; set; }
        public string SiteAddress { get; set; }
        public string SettlementEmployee { get; set; }
        public bool? PartialAuthAllowed { get; set; }
        public int? PumpTimeout { get; set; }
        public int? StoreId { get; set; }
        public string StoreName { get; set; } = null;

        public override string EventId => SiteId.ToString();
        public override string EventIdentifierName => nameof(SiteId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.SiteEvent;
        public override EventModuleType EventModuleType => EventModuleType.MPPA;
        public override EventType EventType => EventType.SiteEvent;
    }
}
