﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using System;

namespace SpiTech.EventBus.DomainEvents.Events.Identity
{
    [EntityName(EventBusConstants.IdentityServiceExchange)]
    public class IdentityUserSignInEvent : IntegrationBaseEvent
    {
        public int UserId { get; set; }
        public DateTime LoginTime { get; set; }
        public override string EventId => UserId.ToString();
        public override string EventIdentifierName => nameof(UserId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.IdentityUserSignIn;
        public override EventModuleType EventModuleType => EventModuleType.Identity;
        public override EventType EventType => EventType.IdentityUserSignIn;
    }
}
