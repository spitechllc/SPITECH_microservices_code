﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;

namespace SpiTech.EventBus.DomainEvents.Events.Identity
{
    [EntityName(EventBusConstants.IdentityServiceExchange)]
    public class IdentityUserUpdatedEvent : IdentityBaseEvent
    {
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.IdentityUserUpdated;
        public override EventType EventType => EventType.IdentityUserUpdated;
    }
}
