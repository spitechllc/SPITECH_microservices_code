﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Identity;

namespace SpiTech.EventBus.DomainEvents.Events.Identity
{
    [ExcludeFromTopology]
    public abstract class IdentityBaseEvent : IntegrationBaseEvent
    {
        public int UserId { get; set; }
        public bool EnrolledBusinessUser { get; set; }
        public string UserName { get; set; }
        public int UserTypeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }
        public string PreferedLanguage { get; set; }
        public bool EmailConfirmed { get; set; }
        public bool MobileConfirmed { get; set; }
        public bool IsActive { get; set; }
        public virtual UserProfileModel UserProfile { get; set; }
        public virtual UserDeviceModel[] UserDevices { get; set; }
        public virtual MobileAppType MobileAppType { get; set; }
        public override string EventId => UserId.ToString();
        public override string EventIdentifierName => nameof(UserId);
        public override string NotificationTypeIdentifier { get; set; }
        public override EventModuleType EventModuleType => EventModuleType.Identity;
    }
}
