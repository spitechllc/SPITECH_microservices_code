﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;

namespace SpiTech.EventBus.DomainEvents.Events.Identity
{
    [EntityName(EventBusConstants.IdentityServiceExchange)]
    public class IdentityUserCreatedEvent : IdentityBaseEvent
    {
        public string TenantName  { get; set; }
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.IdentityUserCreated;

        public override EventType EventType => EventType.IdentityUserCreated;
    }
}
