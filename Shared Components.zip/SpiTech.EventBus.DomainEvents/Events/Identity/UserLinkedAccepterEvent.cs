﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using System;

namespace SpiTech.EventBus.DomainEvents.Events.Identity
{
    [EntityName(EventBusConstants.IdentityServiceExchange)]
    public class UserLinkedAccepterEvent : IntegrationBaseEvent
    {
        public int LinkUserId { get; set; }
        public int RequestedUserId { get; set; }
        public int AcceptUserId { get; set; }
        public DateTime? RequestDate { get; set; }
        public DateTime? ActionDate { get; set; }
        public override string EventId => LinkUserId.ToString();
        public override string EventIdentifierName => nameof(LinkUserId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.UserLinkedAccepterEvent;
        public override EventModuleType EventModuleType => EventModuleType.Identity;
        public override EventType EventType => EventType.UserLinkedAccepterEvent;
    }
}
