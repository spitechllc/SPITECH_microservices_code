﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using System;

namespace SpiTech.EventBus.DomainEvents.Events.Identity
{
    [EntityName(EventBusConstants.IdentityServiceExchange)]
    public class IdentityUserVerificationCodeEvent : IntegrationBaseEvent
    {
        public CodeType CodeType { get; set; }
        public string Receiver { get; set; }
        public string Code { get; set; }
        public int UserId { get; set; }
        public string TenantName { get; set; }
        public DateTime GeneratedDate { get; set; }
        public override string EventId => UserId.ToString();
        public override string EventIdentifierName => nameof(UserId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.IdentityUserVerificationCode;
        public override EventModuleType EventModuleType => EventModuleType.Identity;
        public override EventType EventType => EventType.IdentityUserVerificationCode;
    }
}
