﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;

namespace SpiTech.EventBus.DomainEvents.Events.Identity
{
    [EntityName(EventBusConstants.IdentityServiceExchange)]
    public class IdentityUserEmailVerifiedEvent : IntegrationBaseEvent
    {
        public int UserId { get; set; }
        public override string EventId => UserId.ToString();
        public override string EventIdentifierName => nameof(UserId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.IdentityUserEmailVerifiedEvent;
        public override EventModuleType EventModuleType => EventModuleType.Identity;
        public override EventType EventType => EventType.IdentityUserEmailVerifiedEvent;
    }
}
