﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;

namespace SpiTech.EventBus.DomainEvents.Events.Identity
{
    [EntityName(EventBusConstants.IdentityServiceExchange)]
    public class IdentityPasswordChangedEvent : IntegrationBaseEvent
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public int UserTypeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string MobileCountryCode { get; set; }
        public string MobileNumber { get; set; }

        public override string EventId => UserId.ToString();
        public override string EventIdentifierName => nameof(UserId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.IdentityPasswordChanged;
        public override EventModuleType EventModuleType => EventModuleType.Identity;
        public override EventType EventType => EventType.IdentityPasswordChanged;
    }
}
