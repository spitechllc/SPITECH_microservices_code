﻿using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Account;

namespace SpiTech.EventBus.DomainEvents.Events.Account
{
    public class InvoiceRejectedEvent : IntegrationBaseEvent
    {
        public Invoice Invoice { get; set; }
        public override string EventId => Invoice.InvoiceId.ToString();
        public override string EventIdentifierName => nameof(Invoice.InvoiceId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.InvoiceRejectedEvent;
        public override EventModuleType EventModuleType => EventModuleType.Account;
        public override EventType EventType => EventType.InvoiceRejectedEvent;
    }
}
