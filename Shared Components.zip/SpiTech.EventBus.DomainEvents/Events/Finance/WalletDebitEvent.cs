﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Finance;

namespace SpiTech.EventBus.DomainEvents.Events.Finance
{
    [EntityName(EventBusConstants.FinanceServiceExchange)]
    public class WalletDebitEvent : IntegrationBaseEvent
    {
        public WalletDebit WalletDebit { get; set; }
        public int UserId { get; set; }
        public int ToUserId { get; set; }
        public override string EventId => WalletDebit.WalletDebitId.ToString();
        public override string EventIdentifierName => "WalletDebitId";
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.AdminDebitEvent;
        public override EventModuleType EventModuleType => EventModuleType.Finance;
        public override EventType EventType => EventType.WalletDebitEvent;
    }
}
