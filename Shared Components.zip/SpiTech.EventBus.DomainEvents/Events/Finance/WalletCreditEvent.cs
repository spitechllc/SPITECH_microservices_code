﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Finance;

namespace SpiTech.EventBus.DomainEvents.Events.Finance
{
    [EntityName(EventBusConstants.FinanceServiceExchange)]
    public class WalletCreditEvent : IntegrationBaseEvent
    {
        public WalletCredit WalletCredit { get; set; }
        public int UserId { get; set; }
        public int ToUserId { get; set; }
        public override string EventId => WalletCredit.WalletCreditId.ToString();
        public override string EventIdentifierName => "WalletCreditId";
        public override string NotificationTypeIdentifier { get; set; }= NotificationTypeIdentifierConstants.WalletCreditEvent;
        public override EventModuleType EventModuleType => EventModuleType.Finance;
        public override EventType EventType => EventType.WalletCreditEvent;
    }
}
