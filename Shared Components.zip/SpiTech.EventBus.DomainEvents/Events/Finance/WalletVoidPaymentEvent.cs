﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using System;

namespace SpiTech.EventBus.DomainEvents.Events.Finance
{
    [EntityName(EventBusConstants.FinanceServiceExchange)]
    public class WalletVoidPaymentEvent : IntegrationBaseEvent
    {
        public int UserId { get; set; }
        public string AuthNumber { get; set; }
        public DateTime? RefundDate { get; set; }
        public bool IsRefunded { get; set; }
        public long WalletDebitId { get; set; }
        public decimal Amount { get; set; }
        public int WalletId { get; set; }

        public override string EventId => WalletDebitId.ToString();
        public override string EventIdentifierName => nameof(WalletDebitId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.WalletVoidPaymentEvent;
        public override EventModuleType EventModuleType => EventModuleType.Finance;
        public override EventType EventType => EventType.WalletVoidPaymentEvent;
    }
}