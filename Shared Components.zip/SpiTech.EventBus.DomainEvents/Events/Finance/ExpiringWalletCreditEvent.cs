﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Finance;
using System.Collections.Generic;
using System.Linq;

namespace SpiTech.EventBus.DomainEvents.Events.Finance
{
    [EntityName(EventBusConstants.FinanceServiceExchange)]
    public class ExpiringWalletCreditEvent : IntegrationBaseEvent
    {
        public List<WalletCredit> WalletCredits { get; set; }
        public int UserId { get; set; }
        public override string EventId => WalletCredits.FirstOrDefault()?.WalletId.ToString();
        public override string EventIdentifierName => "WalletId";
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.ExpiringWalletCreditEvent;
        public override EventModuleType EventModuleType => EventModuleType.Finance;
        public override EventType EventType => EventType.ExpiringWalletCreditEvent;
    }
}
