﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using System;

namespace SpiTech.EventBus.DomainEvents.Events.Finance
{
    [EntityName(EventBusConstants.FinanceServiceExchange)]
    public class TransferRequestEvent : IntegrationBaseEvent
    {
        public int LinkMemberTransferId { get; set; }
        public int FromUserId { get; set; }
        public int ToUserId { get; set; }
        public decimal TransferAmount { get; set; }
        public int TransferStatusId { get; set; }
        public DateTime RequestedDate { get; set; }
        public override string EventId => LinkMemberTransferId.ToString();
        public override string EventIdentifierName => nameof(LinkMemberTransferId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.TransferRequestEvent;
        public override EventModuleType EventModuleType => EventModuleType.Finance;
        public override EventType EventType => EventType.TransferRequestEvent;
    }
}
