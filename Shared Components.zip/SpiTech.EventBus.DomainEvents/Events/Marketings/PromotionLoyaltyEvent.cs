﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using SpiTech.EventBus.DomainEvents.Models.Marketings;
using System.Collections.Generic;

namespace SpiTech.EventBus.DomainEvents.Events.Marketings
{
    [EntityName(EventBusConstants.MarketingServiceExchange)]
    public class PromotionLoyaltyEvent : IntegrationBaseEvent
    {
        public List<PromotionLoyaltyModel> PromotionLoyalties { get; set; }
        public int UserId { get; set; }
        public string CashbackEvent { get; set; }
        public EventType CashbackEventType { get; set; }
        public override string EventId => UserId.ToString();
        public override string EventIdentifierName => nameof(UserId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.PromotionLoyaltyEvent;
        public override EventModuleType EventModuleType => EventModuleType.Marketing;
        public override EventType EventType => EventType.PromotionLoyaltyEvent;
    }
}
