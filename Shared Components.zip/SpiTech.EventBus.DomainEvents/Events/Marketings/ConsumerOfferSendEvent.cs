﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using System;

namespace SpiTech.EventBus.DomainEvents.Events.Marketings
{
    [EntityName(EventBusConstants.MarketingServiceExchange)]
    public class ConsumerOfferSendEvent : IntegrationBaseEvent
    {
        public int[] UserIds { get; set; }
        public DateTime ProcessDate { get; set; }
        public int OfferId { get; set; }
        public int CompanyId { get; set; }
        public int Region { get; set; }
        public int StoreId { get; set; }
        public string Store { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string OfferDeal { get; set; }
        public string UPCCode { get; set; }
        public string Description { get; set; }
        public string ImageUrl { get; set; }
        public bool QRCode { get; set; }
        public bool SingleUse { get; set; }

        public override string EventId => OfferId.ToString();
        public override string EventIdentifierName => nameof(OfferId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.ConsumerOfferSendEvent;
        public override EventModuleType EventModuleType => EventModuleType.Marketing;
        public override EventType EventType => EventType.ConsumerOfferSendEvent;
    }
}
