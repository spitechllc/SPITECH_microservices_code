﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpiTech.EventBus.DomainEvents.Events.Notification
{
    [EntityName(EventBusConstants.NotificationServiceExchange)]
    public class UserActivityLogEvent : IntegrationBaseEvent
    {
        public int ActivityTypeId { get; set; }
        public int UserId { get; set; }
        public string ActivityRecordKeyId { get; set; }
        public string ActivityPreData { get; set; }
        public string ActivityPostData { get; set; }
        public DateTime ActivityTime { get; set; }
        public string ActivityIP { get; set; }
        public bool? IsError { get; set; }
        public string ErrorMessage { get; set; }
        public override string EventId => ActivityTypeId.ToString();
        public override string EventIdentifierName => "ActivityTypeId";
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.UserActivityLogEvent;
        public override EventModuleType EventModuleType => EventModuleType.Notification;
        public override EventType EventType => EventType.UserActivityLogEvent;
    }
}
