﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using System.Collections.Generic;

namespace SpiTech.EventBus.DomainEvents.Events.Store
{

    [EntityName(EventBusConstants.StoreServiceExchange)]
    public class StoreUserEvent : IntegrationBaseEvent
    {
        public int UserId { get; set; }
        public int Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int DesignationId { get; set; }
        public int CompanyId { get; set; }
        public int StoreId { get; set; }
        public int ManagerId { get; set; }
        public int RegionId { get; set; }

        public bool IsCreated { get; set; }
        public List<string> Emails { get; set; }
        public override string EventId => UserId.ToString();
        public override string EventIdentifierName => nameof(UserId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.StoreUserEvent;
        public override EventModuleType EventModuleType => EventModuleType.Store;
        public override EventType EventType => EventType.StoreUserEvent;
    }
}
