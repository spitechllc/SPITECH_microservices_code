﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;

namespace SpiTech.EventBus.DomainEvents.Events.Store
{

    [EntityName(EventBusConstants.StoreServiceExchange)]
    public class StoreEvent : IntegrationBaseEvent
    {
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public string SiteId { get; set; }
        public string StoreUrl { get; set; }
        public string Description { get; set; }
        public string Note { get; set; }
        public string StoreImage { get; set; }
        public decimal MaxAuthorizeAmount { get; set; }
        public int AddressId { get; set; }
        public int CategoryTypeLevelId { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public int CountryId { get; set; }
        public string State { get; set; }
        public int StateId { get; set; }
        public int CityId { get; set; }
        public double? Longitude { get; set; }
        public double? Latitude { get; set; }
        public string ZipCode { get; set; }
        public int? CompanyId { get; set; }
        public string EmailIds { get; set; }
        public string PhoneNos { get; set; }
        public bool IsActive { get; set; }
        public bool IsCreated { get; set; }
        public override string EventId => StoreId.ToString();
        public override string EventIdentifierName => nameof(StoreId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.StoreEvent;
        public override EventModuleType EventModuleType => EventModuleType.Store;

        public override EventType EventType => EventType.StoreEvent;
    }
}
