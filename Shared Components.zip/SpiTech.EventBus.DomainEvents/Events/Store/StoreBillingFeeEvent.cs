﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using System;

namespace SpiTech.EventBus.DomainEvents.Events.Store
{
    [EntityName(EventBusConstants.StoreServiceExchange)]
    public class StoreBillingFeeEvent : IntegrationBaseEvent
    {
        public int StoreBillingFeeId { get; set; }
        public int StoreId { get; set; }
        public string SiteId { get; set; }
        public decimal TransactionFee { get; set; }
        public decimal TransactionPercentageFee { get; set; }
        public decimal MonthlySaasFee { get; set; }
        public DateTimeOffset EffectiveDate { get; set; }

        public bool IsCreated { get; set; }
        public bool IsActive { get; set; } = true;
        public override string EventId => StoreBillingFeeId.ToString();
        public override string EventIdentifierName => nameof(StoreBillingFeeId);
        public override string NotificationTypeIdentifier { get; set; } = NotificationTypeIdentifierConstants.StoreBillingFeeEvent;
        public override EventModuleType EventModuleType => EventModuleType.Store;
        public override EventType EventType => EventType.StoreBillingFeeEvent;
    }
}
