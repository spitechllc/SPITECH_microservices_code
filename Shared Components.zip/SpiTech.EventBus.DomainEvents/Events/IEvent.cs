﻿using MassTransit.Topology;
using SpiTech.EventBus.DomainEvents.Enums;
using System;

namespace SpiTech.EventBus.DomainEvents.Events
{
    [ExcludeFromTopology]
    public interface IEvent
    {
        string EventId { get; }
        string EventIdentifierName { get; }
        string NotificationTypeIdentifier { get; set; }
        EventModuleType EventModuleType { get; }
        EventType EventType { get; }
        Guid MessageIdentifier { get; }
        DateTime CreationDate { get; }
    }
}
