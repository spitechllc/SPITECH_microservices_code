﻿namespace SpiTech.EventBus.DomainEvents
{
    public static class EventBusConstants
    {
        public const string IdentityService = "identity";
        public const string MppaService = "mppa";
        public const string PaymentService = "payment";
        public const string TransactionService = "transaction";
        public const string StoreService = "store";
        public const string NotificationService = "notification";
        public const string ReportService = "report";
        public const string FinanceService = "finance";
        public const string MarketingService = "marketing";
        public const string AccountService = "account";

        public const string IdentityServiceExchange = "identity-exchange";
        public const string MppaServiceExchange = "mppa-exchange";
        public const string PaymentServiceExchange = "payment-exchange";
        public const string TransactionServiceExchange = "transaction-exchange";
        public const string StoreServiceExchange = "store-exchange";
        public const string NotificationServiceExchange = "notification-exchange";
        public const string FinanceServiceExchange = "finance-exchange";
        public const string MarketingServiceExchange = "marketing-exchange";

    }
}
